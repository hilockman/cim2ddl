// PGReli.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "../stdafx.h"
#include "../DistributionTraceTraverse.h"

#include "../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif

#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="ACLineSegmentTrip.log";
extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);

static	CDistributionTraceTraverse	m_Tracer;
static	tagPGBlock*			m_pBlock;

int main(int argc, char** argv, char** envp)
{
	int		nRetCode=0;
	clock_t	dBeg, dEnd;
	int		nDur;
	int		nDev;

	ClearLog(g_lpszLogFile);

	dBeg=clock();
	m_pBlock=(tagPGBlock*)Init_PGBlock();
	if (!m_pBlock)
	{
		Log(g_lpszLogFile, "��ȡ�ڴ�����\n");
		return 0;
	}

	m_pBlock->m_System.sa_LinePassRate=1;
	m_pBlock->m_System.sa_LineLossPower=0;

	m_Tracer.InitSaAbility(m_pBlock);

	//nDev = 1;
	for (nDev=0; nDev<m_pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		m_Tracer.TripOneLine(m_pBlock, nDev);

		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		Log(g_lpszLogFile, "N-1 Line(%d/%d)����ʱ %d ����\n", nDev, m_pBlock->m_nRecordNum[PG_ACLINESEGMENT], dEnd);
	}

	int	nPassLine = 0;
	for (nDev=0; nDev<m_pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (m_pBlock->m_ACLineSegmentArray[nDev].sa_Result != PGEnumSaResult_Failed)
			nPassLine++;
		else
		{
			m_pBlock->m_System.sa_LineLossPower += m_pBlock->m_ACLineSegmentArray[nDev].sa_Failure;
		}
	}
	m_pBlock->m_System.sa_LinePassRate=(float)nPassLine/((float)m_pBlock->m_nRecordNum[PG_ACLINESEGMENT]);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	Log(g_lpszLogFile, "��ʱ�� %d ���� \n", nDur);

	return nRetCode;
}
