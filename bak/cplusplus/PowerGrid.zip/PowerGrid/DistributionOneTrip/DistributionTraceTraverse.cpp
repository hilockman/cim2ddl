#include "stdafx.h"
#include "DistributionTraceTraverse.h"

extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	const	char*	g_lpszLogFile;

static	std::vector<unsigned char>	m_bNodeProcArray;	//	TraceSource��TraceJointʹ��

CDistributionTraceTraverse::CDistributionTraceTraverse(void)
{
}

CDistributionTraceTraverse::~CDistributionTraceTraverse(void)
{
}

int	CDistributionTraceTraverse::IsNodeJointSourceWithinVoltage(tagPGBlock* pPGBlock, const int nJudgeNode)
{
	std::vector<int>	nSrcArray;
	return IsNodeJointSourceWithinVoltage(pPGBlock, nJudgeNode, nSrcArray);
}

int	CDistributionTraceTraverse::IsNodeJointSourceWithinVoltage(tagPGBlock* pPGBlock, const int nJudgeNode, std::vector<int>& nSrcArray)
{
	register int	i;
	int		nNode, nNodeNum, nNodeArray[1000];

	nSrcArray.clear();
	PGTraverseVolt(pPGBlock, nJudgeNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
			nSrcArray.push_back(i);
	}

	if (nSrcArray.empty())
		return 0;
	return 1;
}

void CDistributionTraceTraverse::SetRecursivePower(tagPGBlock* pPGBlock, std::vector<tagPGRecursiveChannel>& channelArray)
{
	register int	i, j;
	int		bFrLinked, bToLinked, nPrevDeep, nPrevBran;
	std::vector<int>	nPrevFrNodeArray;
	int		nFrNodeNum, nFrNodeArray[1000];
	int		nToNodeNum, nToNodeArray[1000];

	//Log(g_lpszLogFile, "    SetRecursivePower(TraceChannelNum=%d)\n", channelArray.size());
	nPrevFrNodeArray.clear();
	nPrevDeep=channelArray[channelArray.size()-1].nDeep;
	nPrevBran=(int)channelArray.size()-1;
	PGTraverseVolt(pPGBlock, channelArray[nPrevBran].nFrNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nFrNodeNum, nFrNodeArray);
	PGTraverseVolt(pPGBlock, channelArray[nPrevBran].nToNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);

	for (i=(int)channelArray.size()-1; i>=0; i--)
	{
		if (channelArray[i].bMarked)
			break;

		// 		Log(g_lpszLogFile, "CheckTraceChannel FrNode=%s.%s %s.%s\n", i, 
		// 			pPGBlock->m_ConnectivityNodeArray[channelArray[i].nFrNode].szSub, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nFrNode].szName, 
		// 			pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szSub, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szName);

		if (channelArray[i].nDeep == nPrevDeep)
		{
			bFrLinked=bToLinked=0;
			for (j=0; j<nFrNodeNum; j++)
			{
				if (channelArray[i].nFrNode == nFrNodeArray[j])
				{
					bFrLinked=1;
					break;
				}
			}
			for (j=0; j<nToNodeNum; j++)
			{
				if (channelArray[i].nToNode == nToNodeArray[j])
				{
					bToLinked=1;
					break;
				}
			}
			if (bFrLinked && bToLinked)
			{
				channelArray[i].bMarked=1;
				//Log(g_lpszLogFile, "            Pal (Bran=%s FrNode=%s.%sToNode=%s.%s)\n", pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].szName, 
				//	pPGBlock->m_ConnectivityNodeArray[channelArray[i].nFrNode].szSub, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nFrNode].szName, 
				//	pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szSub, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szName);
			}
		}
		else if (channelArray[i].nDeep == nPrevDeep-1)
		{
			PGTraverseVolt(pPGBlock, channelArray[nPrevBran].nFrNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nFrNodeNum, nFrNodeArray);
			bToLinked=0;
			for (j=0; j<nFrNodeNum; j++)
			{
				if (channelArray[i].nToNode == nFrNodeArray[j])
				{
					bToLinked=1;
					break;
				}
			}

			for (j=0; j<(int)nPrevFrNodeArray.size(); j++)
			{
				Log(g_lpszLogFile, "                    PrevFrNode[%d]=%s.%s\n", j, pPGBlock->m_ConnectivityNodeArray[nPrevFrNodeArray[j]].szSub, pPGBlock->m_ConnectivityNodeArray[nPrevFrNodeArray[j]].szName);
			}
			if (bToLinked)
			{
				channelArray[i].bMarked=1;
				nPrevDeep--;
				nPrevBran=i;
				PGTraverseVolt(pPGBlock, channelArray[nPrevBran].nFrNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nFrNodeNum, nFrNodeArray);
				PGTraverseVolt(pPGBlock, channelArray[nPrevBran].nToNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);
				//Log(g_lpszLogFile, "            Linked(Bran=%s ToNode=%s.%s)\n", pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].szName, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szSub, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szName);
			}
			else
			{
				//Log(g_lpszLogFile, "            NoLink(Bran=%s ToNode=%s.%s)\n", pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].szName, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szSub, pPGBlock->m_ConnectivityNodeArray[channelArray[i].nToNode].szName);
			}
		}
	}
}


void CDistributionTraceTraverse::TraceJoint(tagPGBlock* pPGBlock, std::vector<tagPGRecursiveChannel>& channelArray, const int bCheckOpen, const int nPrevDevType, const int nPrevDevIndex, const int nIniNode, const int nDeep)
{
	register int	i, j, k, l;
	int		nNode, nOppNode, nBran, nIniChain;
	int		nPalOppNode, nPalBran, bFlaged;
	int		nNodeNum, nNodeArray[1000];
	int		nToNodeNum, nToNodeArray[1000];
	tagPGRecursiveChannel	dChain;

	if (m_bNodeProcArray[nIniNode] != 0)
		return;
	m_bNodeProcArray[nIniNode]=1;

	//Log(g_lpszLogFile, "TraceJoint(Deep=%d): IniNode=%s.%s\n", nDeep, pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName);
	if (IsNodeJointSourceWithinVoltage(pPGBlock, nIniNode) && nDeep > 0)
	{
		SetRecursivePower(pPGBlock, channelArray);
		return;
	}

	nIniChain=(int)channelArray.size();
	if (bCheckOpen)
		PGTraverseVolt(pPGBlock, nIniNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	else
		PGTraverseVolt(pPGBlock, nIniNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (i=0; i<nNodeNum; i++)
		m_bNodeProcArray[nNodeArray[i]]=1;

	//	�����Ӻ���
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
		{
			nBran=pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;
			if (nBran < 0)
				continue;
			if (nPrevDevType == PG_ACLINESEGMENT && nPrevDevIndex == nBran)
				continue;
			if (pPGBlock->m_ACLineSegmentArray[nBran].bOpen != 0 || pPGBlock->m_ACLineSegmentArray[nBran].bOutage != 0)
				continue;

			nOppNode=(nNodeArray[nNode] == pPGBlock->m_ACLineSegmentArray[nBran].nNodeI) ? pPGBlock->m_ACLineSegmentArray[nBran].nNodeJ : pPGBlock->m_ACLineSegmentArray[nBran].nNodeI;
			if (nOppNode < 0)
				continue;
			if (m_bNodeProcArray[nOppNode] != 0)
				continue;

			bFlaged=0;
			for (j=(int)channelArray.size()-1; j>=0; j--)
			{
				if (channelArray[j].nChannelIndex == nBran && channelArray[j].nDeep == nDeep)
				{
					bFlaged=1;
					break;
				}
			}
			if (bFlaged)
				continue;

			if (bCheckOpen)
				PGTraverseVolt(pPGBlock, nOppNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);
			else
				PGTraverseVolt(pPGBlock, nOppNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);
			for (j=0; j<nNodeNum; j++)
			{
				for (k=pPGBlock->m_ConnectivityNodeArray[nNodeArray[j]].nACLineSegmentRange; k<pPGBlock->m_ConnectivityNodeArray[nNodeArray[j]+1].nACLineSegmentRange; k++)
				{
					nPalBran=pPGBlock->m_EdgeACLineSegmentArray[k].nACLineSegment;
					if (nPalBran < 0)
						continue;
					if (nPrevDevType == PG_ACLINESEGMENT && nPrevDevIndex == nPalBran)
						continue;
					if (nBran == nPalBran)
						continue;
					if (pPGBlock->m_ACLineSegmentArray[nPalBran].bOpen != 0 || pPGBlock->m_ACLineSegmentArray[nPalBran].bOutage != 0)
						continue;

					nPalOppNode=(nNodeArray[j] == pPGBlock->m_ACLineSegmentArray[nPalBran].nNodeI) ? pPGBlock->m_ACLineSegmentArray[nPalBran].nNodeJ : pPGBlock->m_ACLineSegmentArray[nPalBran].nNodeI;

					bFlaged=0;
					for (l=0; l<nToNodeNum; l++)
					{
						if (nToNodeArray[l] == nPalOppNode)
						{
							bFlaged=1;
							break;
						}
					}
					if (bFlaged)
					{
						memset(&dChain, 0, sizeof(tagPGRecursiveChannel));
						dChain.nDeep=nDeep;
						dChain.bDirect=(pPGBlock->m_ACLineSegmentArray[nPalBran].nNodeI == nNodeArray[j]) ? 1 : 2;
						dChain.nChannelType=PG_ACLINESEGMENT;
						dChain.nChannelIndex=nPalBran;
						dChain.nFrNode=nNodeArray[j];
						dChain.nToNode=nPalOppNode;
						channelArray.push_back(dChain);
					}
				}
			}

			memset(&dChain, 0, sizeof(tagPGRecursiveChannel));
			dChain.nDeep=nDeep;
			dChain.bDirect=(pPGBlock->m_ACLineSegmentArray[nBran].nNodeI == nNodeArray[nNode]) ? 1 : 2;
			dChain.nChannelType=PG_ACLINESEGMENT;
			dChain.nChannelIndex=nBran;
			dChain.nFrNode=nNodeArray[nNode];
			dChain.nToNode=nOppNode;
			channelArray.push_back(dChain);

			//Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_ACLineSegmentArray[dChain.nChannelIndex].szName, 
			//	pPGBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pPGBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
			//	pPGBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pPGBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
			TraceJoint(pPGBlock, channelArray, bCheckOpen, PG_ACLINESEGMENT, nBran, nOppNode, nDeep+1);
		}
		for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; i++)
		{
			nBran=pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding;
			if (nBran < 0)
				continue;
			if (nPrevDevType == PG_TRANSFORMERWINDING && nPrevDevIndex == nBran)
				continue;
			if (pPGBlock->m_TransformerWindingArray[nBran].bOpen != 0 || pPGBlock->m_TransformerWindingArray[nBran].bOutage != 0)
				continue;

			nOppNode=(nNodeArray[nNode] == pPGBlock->m_TransformerWindingArray[nBran].nNodeI) ? pPGBlock->m_TransformerWindingArray[nBran].nNodeJ : pPGBlock->m_TransformerWindingArray[nBran].nNodeI;
			if (nOppNode < 0)
				continue;
			if (m_bNodeProcArray[nOppNode] != 0)
				continue;

			bFlaged=0;
			for (j=(int)channelArray.size()-1; j>=0; j--)
			{
				if (channelArray[j].nChannelIndex == nBran && channelArray[j].nDeep == nDeep)
				{
					bFlaged=1;
					break;
				}
			}
			if (bFlaged)
				continue;

			if (bCheckOpen)
				PGTraverseVolt(pPGBlock, nOppNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);
			else
				PGTraverseVolt(pPGBlock, nOppNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);
			for (j=0; j<nNodeNum; j++)
			{
				for (k=pPGBlock->m_ConnectivityNodeArray[nNodeArray[j]].nTransformerWindingRange; k<pPGBlock->m_ConnectivityNodeArray[nNodeArray[j]+1].nTransformerWindingRange; k++)
				{
					nPalBran=pPGBlock->m_EdgeTransformerWindingArray[k].nTransformerWinding;
					if (nPalBran < 0)
						continue;
					if (nPrevDevType == PG_TRANSFORMERWINDING && nPrevDevIndex == nPalBran)
						continue;
					if (nBran == nPalBran)
						continue;
					if (pPGBlock->m_TransformerWindingArray[nPalBran].bOpen != 0 || pPGBlock->m_TransformerWindingArray[nPalBran].bOutage != 0)
						continue;

					nPalOppNode=(nNodeArray[j] == pPGBlock->m_TransformerWindingArray[nPalBran].nNodeI) ? pPGBlock->m_TransformerWindingArray[nPalBran].nNodeJ : pPGBlock->m_TransformerWindingArray[nPalBran].nNodeI;

					bFlaged=0;
					for (l=0; l<nToNodeNum; l++)
					{
						if (nToNodeArray[l] == nPalOppNode)
						{
							bFlaged=1;
							break;
						}
					}
					if (bFlaged)
					{
						memset(&dChain, 0, sizeof(tagPGRecursiveChannel));
						dChain.nDeep=nDeep;
						dChain.bDirect=(pPGBlock->m_TransformerWindingArray[nPalBran].nNodeI == nNodeArray[j]) ? 1 : 2;
						dChain.nChannelType=PG_TRANSFORMERWINDING;
						dChain.nChannelIndex=nPalBran;
						dChain.nFrNode=nNodeArray[j];
						dChain.nToNode=nPalOppNode;
						channelArray.push_back(dChain);
					}
				}
			}

			memset(&dChain, 0, sizeof(tagPGRecursiveChannel));
			dChain.nDeep=nDeep;
			dChain.bDirect=(pPGBlock->m_TransformerWindingArray[nBran].nNodeI == nNodeArray[nNode]) ? 1 : 2;
			dChain.nChannelType=PG_TRANSFORMERWINDING;
			dChain.nChannelIndex=nBran;
			dChain.nFrNode=nNodeArray[nNode];
			dChain.nToNode=nOppNode;
			channelArray.push_back(dChain);

			//Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_TransformerWindingArray[dChain.nChannelIndex].szName, 
			//	pPGBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pPGBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
			//	pPGBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pPGBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
			TraceJoint(pPGBlock, channelArray, bCheckOpen, PG_TRANSFORMERWINDING, nBran, nOppNode, nDeep+1);
		}
	}
}


int CDistributionTraceTraverse::TraceConnection(tagPGBlock* pPGBlock, const int nMaxOp, const int nDestNode, const int nPrevDevType, const int nPrevDevIndex, const int nPrevOp, const int nIniNode, const int nDeep, std::vector<int>& nRouteNodeArray)
{
	register int	i;
	int		nOppNode, nEdge;

	if (m_bNodeProcArray[nIniNode] != 0)
		return 0;
	m_bNodeProcArray[nIniNode]=1;

	nRouteNodeArray.push_back(nIniNode);

	//Log(g_lpszLogFile, "TraceConnection(Deep=%d): IniNode=%s.%s\n", nDeep, pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName);
	for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nIniNode].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nIniNode].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
	{
		if (pPGBlock->m_SynchronousMachineArray[i].nNode == nIniNode)
			return 0;
	}
	if (nIniNode == nDestNode)
		return 1;

	for (i=pPGBlock->m_ConnectivityNodeArray[nIniNode].nBreakerRange; i<pPGBlock->m_ConnectivityNodeArray[nIniNode+1].nBreakerRange; i++)
	{
		nEdge=pPGBlock->m_EdgeBreakerArray[i].nBreaker;
		if (nEdge < 0)
			continue;
		if (nPrevDevType == PG_BREAKER && nPrevDevIndex == nEdge)
			continue;
		nOppNode=(nIniNode == pPGBlock->m_BreakerArray[nEdge].nNodeI) ? pPGBlock->m_BreakerArray[nEdge].nNodeJ : pPGBlock->m_BreakerArray[nEdge].nNodeI;
		if (nOppNode < 0)
			continue;
		if (m_bNodeProcArray[nOppNode] != 0)
			continue;

// 		Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_BreakerArray[nEdge].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nOppNode].szSub, pPGBlock->m_ConnectivityNodeArray[nOppNode].szName);
		if (pPGBlock->m_BreakerArray[nEdge].nStatus != 0)
		{
// 			if (nPrevOp+1 > nMaxOp)
// 				continue;
// 			else
			{
				TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_BREAKER, nEdge, nPrevOp+1, nOppNode, nDeep+1, nRouteNodeArray);
			}
		}
		else
		{
			TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_BREAKER, nEdge, nPrevOp, nOppNode, nDeep+1, nRouteNodeArray);
		}
	}
	for (i=pPGBlock->m_ConnectivityNodeArray[nIniNode].nDisconnectorRange; i<pPGBlock->m_ConnectivityNodeArray[nIniNode+1].nDisconnectorRange; i++)
	{
		nEdge=pPGBlock->m_EdgeDisconnectorArray[i].nDisconnector;
		if (nEdge < 0)
			continue;
		if (nPrevDevType == PG_DISCONNECTOR && nPrevDevIndex == nEdge)
			continue;
		nOppNode=(nIniNode == pPGBlock->m_DisconnectorArray[nEdge].nNodeI) ? pPGBlock->m_DisconnectorArray[nEdge].nNodeJ : pPGBlock->m_DisconnectorArray[nEdge].nNodeI;
		if (nOppNode < 0)
			continue;
		if (m_bNodeProcArray[nOppNode] != 0)
			continue;

// 		Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_DisconnectorArray[nEdge].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nOppNode].szSub, pPGBlock->m_ConnectivityNodeArray[nOppNode].szName);
		if (pPGBlock->m_DisconnectorArray[nEdge].nStatus != 0)
		{
// 			if (nPrevOp+1 > nMaxOp)
// 			{
// 				continue;
// 			}
// 			else
			{
				TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_DISCONNECTOR, nEdge, nPrevOp+1, nOppNode, nDeep+1, nRouteNodeArray);
			}
		}
		else
		{
			TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_DISCONNECTOR, nEdge, nPrevOp, nOppNode, nDeep+1, nRouteNodeArray);
		}
	}
	for (i=pPGBlock->m_ConnectivityNodeArray[nIniNode].nSeriesCompensatorRange; i<pPGBlock->m_ConnectivityNodeArray[nIniNode+1].nSeriesCompensatorRange; i++)
	{
		nEdge=pPGBlock->m_EdgeSeriesCompensatorArray[i].nSeriesCompensator;
		if (nEdge < 0)
			continue;
		if (nPrevDevType == PG_SERIESCOMPENSATOR && nPrevDevIndex == nEdge)
			continue;
		if (pPGBlock->m_SeriesCompensatorArray[nEdge].bOpen != 0 || pPGBlock->m_SeriesCompensatorArray[nEdge].bOutage != 0)
			continue;

		nOppNode=(nIniNode == pPGBlock->m_SeriesCompensatorArray[nEdge].nNodeI) ? pPGBlock->m_SeriesCompensatorArray[nEdge].nNodeJ : pPGBlock->m_SeriesCompensatorArray[nEdge].nNodeI;
		if (nOppNode < 0)
			continue;
		if (m_bNodeProcArray[nOppNode] != 0)
			continue;

// 		Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_SeriesCompensatorArray[nEdge].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nOppNode].szSub, pPGBlock->m_ConnectivityNodeArray[nOppNode].szName);
		TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_SERIESCOMPENSATOR, nEdge, nPrevOp, nOppNode, nDeep+1, nRouteNodeArray);
	}
	for (i=pPGBlock->m_ConnectivityNodeArray[nIniNode].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nIniNode+1].nACLineSegmentRange; i++)
	{
		nEdge=pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;
		if (nEdge < 0)
			continue;
		if (nPrevDevType == PG_ACLINESEGMENT && nPrevDevIndex == nEdge)
			continue;
		if (pPGBlock->m_ACLineSegmentArray[nEdge].bOpen != 0 || pPGBlock->m_ACLineSegmentArray[nEdge].bOutage != 0)
			continue;

		nOppNode=(nIniNode == pPGBlock->m_ACLineSegmentArray[nEdge].nNodeI) ? pPGBlock->m_ACLineSegmentArray[nEdge].nNodeJ : pPGBlock->m_ACLineSegmentArray[nEdge].nNodeI;
		if (nOppNode < 0)
			continue;
		if (m_bNodeProcArray[nOppNode] != 0)
			continue;

// 		Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_ACLineSegmentArray[nEdge].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName, 
// 			pPGBlock->m_ConnectivityNodeArray[nOppNode].szSub, pPGBlock->m_ConnectivityNodeArray[nOppNode].szName);
		TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_ACLINESEGMENT, nEdge, nPrevOp, nOppNode, nDeep+1, nRouteNodeArray);
	}
	for (i=pPGBlock->m_ConnectivityNodeArray[nIniNode].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nIniNode+1].nTransformerWindingRange; i++)
	{
		nEdge=pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding;
		if (nEdge < 0)
			continue;
		if (nPrevDevType == PG_TRANSFORMERWINDING && nPrevDevIndex == nEdge)
			continue;
		if (pPGBlock->m_TransformerWindingArray[nEdge].bOpen != 0 || pPGBlock->m_TransformerWindingArray[nEdge].bOutage != 0)
			continue;
		nOppNode=(nIniNode == pPGBlock->m_TransformerWindingArray[nEdge].nNodeI) ? pPGBlock->m_TransformerWindingArray[nEdge].nNodeJ : pPGBlock->m_TransformerWindingArray[nEdge].nNodeI;
		if (nOppNode < 0)
			continue;
		if (m_bNodeProcArray[nOppNode] != 0)
			continue;

		Log(g_lpszLogFile, "    JointLine=%s FrNode=%s.%s ToNode=%s.%s\n", pPGBlock->m_TransformerWindingArray[nEdge].szName, 
			pPGBlock->m_ConnectivityNodeArray[nIniNode].szSub, pPGBlock->m_ConnectivityNodeArray[nIniNode].szName, 
			pPGBlock->m_ConnectivityNodeArray[nOppNode].szSub, pPGBlock->m_ConnectivityNodeArray[nOppNode].szName);
		TraceConnection(pPGBlock, nMaxOp, nDestNode, PG_TRANSFORMERWINDING, nEdge, nPrevOp, nOppNode, nDeep+1, nRouteNodeArray);
	}
	return 0;
}

int CDistributionTraceTraverse::TraceSource(tagPGBlock* pPGBlock, const int nStartNode, const int bCheckOpen, std::vector<tagPGRecursiveChannel>& channelArray)
{
	register int	i;
	int		nDeep;

	channelArray.clear();

	if (IsNodeJointSourceWithinVoltage(pPGBlock, nStartNode))
		return 0;

	m_bNodeProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_bNodeProcArray[i]=0;

	//Log(g_lpszLogFile, "TraceSource Start=%s.%s\n", pPGBlock->m_ConnectivityNodeArray[nStartNode].szSub, pPGBlock->m_ConnectivityNodeArray[nStartNode].szName);
	nDeep=0;
	TraceJoint(pPGBlock, channelArray, bCheckOpen, 0, -1, nStartNode, nDeep);

	i=0;
	while (i < (int)channelArray.size())
	{
		if (!channelArray[i].bMarked)
		{
			channelArray.erase(channelArray.begin()+i);
		}
		else
			i++;
	}
	return 0;
}

int CDistributionTraceTraverse::TraceSource(tagPGBlock* pPGBlock, const int nStartNode, const int bCheckOpen, std::vector<tagPGRecursiveChannel>& channelArray, std::vector<int>& nSrcArray)
{
	register int	i, j, k;
	int		nDeep;
	unsigned char	bFind;
	std::vector<int>	tmpSrcArray;

	nSrcArray.clear();
	channelArray.clear();
	m_bNodeProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_bNodeProcArray[i]=0;

	//Log(g_lpszLogFile, "TraceSource Start=%s.%s\n", pPGBlock->m_ConnectivityNodeArray[nStartNode].szSub, pPGBlock->m_ConnectivityNodeArray[nStartNode].szName);
	nDeep=0;
	TraceJoint(pPGBlock, channelArray, bCheckOpen, 0, -1, nStartNode, nDeep);

	i=0;
	while (i < (int)channelArray.size())
	{
		if (!channelArray[i].bMarked)
		{
			channelArray.erase(channelArray.begin()+i);
		}
		else
			i++;
	}
	for (i=0; i<(int)channelArray.size(); i++)
	{
		if (IsNodeJointSourceWithinVoltage(pPGBlock, channelArray[i].nFrNode, tmpSrcArray))
		{
			for (j=0; j<(int)tmpSrcArray.size(); j++)
			{
				bFind=0;
				for (k=0; k<(int)nSrcArray.size(); k++)
				{
					if (nSrcArray[k] == tmpSrcArray[j])
					{
						bFind=1;
						break;
					}
				}
				if (!bFind)
				{
					nSrcArray.push_back(tmpSrcArray[j]);
				}
			}
		}
		if (IsNodeJointSourceWithinVoltage(pPGBlock, channelArray[i].nToNode, tmpSrcArray))
		{
			for (j=0; j<(int)tmpSrcArray.size(); j++)
			{
				bFind=0;
				for (k=0; k<(int)nSrcArray.size(); k++)
				{
					if (nSrcArray[k] == tmpSrcArray[j])
					{
						bFind=1;
						break;
					}
				}
				if (!bFind)
				{
					nSrcArray.push_back(tmpSrcArray[j]);
				}
			}
		}
	}
	return 0;
}

void CDistributionTraceTraverse::InitChannelAbility(tagPGBlock* pPGBlock, const int nIniDev, const int nIniDeep, double& fMinChannenSpare, std::vector<tagPGRecursiveChannel>& channelArray)
{
	int			nDev, nLine;
	double		fSpareMva, fChannelMvaLimit, fChannelMva;

	fSpareMva=fChannelMvaLimit=fChannelMva=0;
	nLine=channelArray[nIniDev].nChannelIndex;
	for (nDev=nIniDev; nDev<(int)channelArray.size(); nDev++)
	{
		if (channelArray[nDev].bTraced)
			continue;
		if (channelArray[nDev].nDeep < nIniDeep)
			return;

		if (channelArray[nDev].nDeep == nIniDeep)
		{
			channelArray[nDev].bTraced=1;
			nLine=channelArray[nDev].nChannelIndex;
			fChannelMvaLimit += pPGBlock->m_ACLineSegmentArray[nLine].fRatedMva;
			if (channelArray[nDev].bDirect == 1)
			{
				fChannelMva += sqrt(pow((double)pPGBlock->m_ACLineSegmentArray[nLine].fPi, 2.0)+pow((double)pPGBlock->m_ACLineSegmentArray[nLine].fQi, 2.0));
			}
			else
			{
				fChannelMva += sqrt(pow((double)pPGBlock->m_ACLineSegmentArray[nLine].fPz, 2.0)+pow((double)pPGBlock->m_ACLineSegmentArray[nLine].fQz, 2.0));
			}

		}
	}
	fSpareMva = fChannelMvaLimit-fChannelMva;
	if (fMinChannenSpare > fSpareMva)	fMinChannenSpare=fSpareMva;
	for (nDev=nIniDev; nDev<(int)channelArray.size(); nDev++)
	{
		if (channelArray[nDev].bTraced)
			continue;
		if (channelArray[nDev].nDeep < nIniDeep)
			return;

		if (channelArray[nDev].nDeep > nIniDeep)
		{
			InitChannelAbility(pPGBlock, nDev, channelArray[nDev].nDeep, fMinChannenSpare, channelArray);
		}
	}
}

void CDistributionTraceTraverse::TraceChannelAbility(tagPGBlock* pPGBlock, const int nIniDev, const int nIniDeep, double& fMinChannelSpare, std::vector<tagPGRecursiveChannel>& channelArray)
{
	int			nDev, nChannelNode, nLine;
	double		fSpareMva, fChannelMvaLimit, fChannelMva;
	double		fBufP, fBufQ;

	fSpareMva=fChannelMvaLimit=fChannelMva=0;
	nLine=channelArray[nIniDev].nChannelIndex;
	nChannelNode=-1;
	for (nDev=nIniDev; nDev<(int)channelArray.size(); nDev++)
	{
		if (channelArray[nDev].bTraced)
			continue;
		if (channelArray[nDev].nDeep < nIniDeep)
			return;

		if (channelArray[nDev].nDeep == nIniDeep)
		{
			channelArray[nDev].bTraced=1;
			nLine=channelArray[nDev].nChannelIndex;
			if (pPGBlock->m_ACLineSegmentArray[nLine].bOpen == 0 && pPGBlock->m_ACLineSegmentArray[nLine].bOutage == 0)
			{
				fChannelMvaLimit += pPGBlock->m_ACLineSegmentArray[nLine].fRatedMva;
				nChannelNode=(channelArray[nDev].bDirect == 1) ? pPGBlock->m_ACLineSegmentArray[nLine].nNodeI : pPGBlock->m_ACLineSegmentArray[nLine].nNodeJ;
			}

		}
	}
	if (nChannelNode >= 0)
	{
		fBufP=m_NodeAbilityArray[nChannelNode].fLoadP+m_NodeAbilityArray[nChannelNode].fFlowOutP;
		fBufQ=m_NodeAbilityArray[nChannelNode].fLoadQ+m_NodeAbilityArray[nChannelNode].fFlowOutQ;
		fChannelMva += sqrt(fBufP*fBufP+fBufQ*fBufQ);
	}
	fSpareMva = fChannelMvaLimit-fChannelMva;
	if (fMinChannelSpare > fSpareMva)	fMinChannelSpare=fSpareMva;
	for (nDev=nIniDev; nDev<(int)channelArray.size(); nDev++)
	{
		if (channelArray[nDev].bTraced)
			continue;
		if (channelArray[nDev].nDeep < nIniDeep)
			return;

		if (channelArray[nDev].nDeep > nIniDeep)
		{
			TraceChannelAbility(pPGBlock, nDev, channelArray[nDev].nDeep, fMinChannelSpare, channelArray);
		}
	}
}

void CDistributionTraceTraverse::InitNodeAbility(tagPGBlock* pPGBlock, const int nJudgeNode, tagNodeAbility& nodeAbility)
{
	register int	i, j;
	int		nVolt, nDev;
	double	fBufP, fBufQ;
	std::vector<int>	nSrcArray;
	int		nNodeNum, nNodeArray[1000];
	std::vector<tagPGRecursiveChannel>	channelArray;

	nodeAbility.nLoadArray.clear();
	nodeAbility.fAbility=
		nodeAbility.fLoadP=nodeAbility.fLoadQ=
		nodeAbility.fFlowInP =nodeAbility.fFlowInQ =
		nodeAbility.fFlowOutP=nodeAbility.fFlowOutQ=0;
	if (IsNodeJointSourceWithinVoltage(pPGBlock, nJudgeNode, nSrcArray))
	{
		nodeAbility.bPowered=1;
		nodeAbility.fAbility=0;
		for (nDev=0; nDev<(int)nSrcArray.size(); nDev++)
			nodeAbility.fAbility += pPGBlock->m_SynchronousMachineArray[nSrcArray[nDev]].fPMax-pPGBlock->m_SynchronousMachineArray[nSrcArray[nDev]].fPlanP;
		return;
	}

	channelArray.clear();
	TraceSource(pPGBlock, nJudgeNode, 1, channelArray);
	if (channelArray.empty())
		return;

	nodeAbility.bPowered=1;
	for (nDev=0; nDev<(int)channelArray.size(); nDev++)
		channelArray[nDev].bTraced=0;

	nodeAbility.fAbility=10000;
	InitChannelAbility(pPGBlock, 0, channelArray[0].nDeep, nodeAbility.fAbility, channelArray);

	PGTraverseVolt(pPGBlock, nJudgeNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	nodeAbility.nLoadArray.clear();
	nodeAbility.fLoadP=nodeAbility.fLoadQ=0;

	nVolt=pPGBlock->m_ConnectivityNodeArray[nJudgeNode].nVoltageLevelPtr;
	for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
	{
		for (j=0; j<nNodeNum; j++)
		{
			if (pPGBlock->m_EnergyConsumerArray[i].nNode == nNodeArray[j])
			{
				nodeAbility.nLoadArray.push_back(i);
				nodeAbility.fLoadP += pPGBlock->m_EnergyConsumerArray[i].fPlanP;
				nodeAbility.fLoadQ += pPGBlock->m_EnergyConsumerArray[i].fPlanQ;
			}
		}
	}
	fBufP=fBufQ=0;
	nodeAbility.fFlowInP=nodeAbility.fFlowInQ=0;
	for (i=0; i<(int)channelArray.size(); i++)
	{
		if (channelArray[i].nDeep == 0)
		{
			if (channelArray[i].bDirect == 1)
			{
				fBufP += fabs(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fPi);
				fBufQ += fabs(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fQi);
				nodeAbility.fFlowInP += -(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fPi);
				nodeAbility.fFlowInQ += -(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fQi);
			}
			else
			{
				fBufP += fabs(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fPz);
				fBufQ += fabs(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fQz);
				nodeAbility.fFlowInP += -(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fPz);
				nodeAbility.fFlowInQ += -(pPGBlock->m_ACLineSegmentArray[channelArray[i].nChannelIndex].fQz);
			}
		}
	}
	if (fabs(nodeAbility.fFlowInP-fBufP) > 0.0000001)
	{
		//TRACE("P Node=%s.%s.%s\n", pPGBlock->m_ConnectivityNodeArray[nJudgeNode].szSub, pPGBlock->m_ConnectivityNodeArray[nJudgeNode].szVolt, pPGBlock->m_ConnectivityNodeArray[nJudgeNode].szName);
		//ASSERT(FALSE);
	}
	if (fabs(nodeAbility.fFlowInQ-fBufQ) > 0.0000001)
	{
		//TRACE("Q Node=%s.%s.%s\n", pPGBlock->m_ConnectivityNodeArray[nJudgeNode].szSub, pPGBlock->m_ConnectivityNodeArray[nJudgeNode].szVolt, pPGBlock->m_ConnectivityNodeArray[nJudgeNode].szName);
		//ASSERT(FALSE);
	}
	nodeAbility.fFlowOutP=nodeAbility.fFlowInP-nodeAbility.fLoadP;
	nodeAbility.fFlowOutQ=nodeAbility.fFlowInQ-nodeAbility.fLoadQ;
}

double CDistributionTraceTraverse::FormNodeAbility(tagPGBlock* pPGBlock, const int nJudgeNode, std::vector<tagPGRecursiveChannel>& channelArray)
{
	int		nDev;
	double	fAbility;
	std::vector<int>	nSrcArray;

	fAbility=0;
	if (IsNodeJointSourceWithinVoltage(pPGBlock, nJudgeNode, nSrcArray))
	{
		for (nDev=0; nDev<(int)nSrcArray.size(); nDev++)
		{
			fAbility += pPGBlock->m_SynchronousMachineArray[nSrcArray[nDev]].fPMax-pPGBlock->m_SynchronousMachineArray[nSrcArray[nDev]].fPlanP;
		}
		return fAbility;
	}

	TraceSource(pPGBlock, nJudgeNode, 1, channelArray);
	if (channelArray.empty())
		return 0;

	for (nDev=0; nDev<(int)channelArray.size(); nDev++)
		channelArray[nDev].bTraced=0;

	fAbility=100000;
	TraceChannelAbility(pPGBlock, 0, channelArray[0].nDeep, fAbility, channelArray);
	return fAbility;
}

void CDistributionTraceTraverse::TraverseLoad(tagPGBlock* pPGBlock, const int nStartNode, const int bCheckOpen, std::vector<int>& nJointLoadArray)
{
	register int	i;
	int		nDev;

	nJointLoadArray.clear();

	int		nNodeNum;
	int*	pnNodeArray = (int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnNodeArray)
		return;

	unsigned char	bCheckStatus = (bCheckOpen) ? Y_CheckStatus : N_CheckStatus;
	PGTraverseNet(pPGBlock, nStartNode, bCheckStatus, 0, nNodeNum, pnNodeArray);
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		for (i=0; i<nNodeNum; i++)
		{
			if (pnNodeArray[i] == pPGBlock->m_EnergyConsumerArray[nDev].nNode)
			{
				nJointLoadArray.push_back(nDev);
				break;
			}
		}
	}
	free(pnNodeArray);

// 	std::vector<int> nNodeArray;
// 	TraverseNet(pPGBlock, nStartNode, bCheckOpen, nNodeArray);
// 	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
// 	{
// 		for (i=0; i<(int)nNodeArray.size(); i++)
// 		{
// 			if (nNodeArray[i] == pPGBlock->m_EnergyConsumerArray[nDev].nNode)
// 			{
// 				nJointLoadArray.push_back(nDev);
// 				break;
// 			}
// 		}
// 	}
}

// void CDistributionTraceTraverse::TraverseNet(tagPGBlock* pPGBlock, const int nStartNode, const int bCheckOpen, std::vector<int>& nNodeArray)
// {
// 	register int	i, j;
// 	int		nDev, nNode;
// 	int		nNodeNumOfLayer;
// 	std::vector<int> nMidNodeArray;
// 	std::vector<unsigned char>	bNodeUnProcArray;
// 
// 	nNodeArray.clear();
// 
// 	bNodeUnProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
// 	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
// 		bNodeUnProcArray[i]=1;
// 
// 	nNodeArray.push_back(nStartNode);
// 	bNodeUnProcArray[nStartNode]=0;
// 	nNodeNumOfLayer=0;
// 	while (1)
// 	{
// 		nMidNodeArray.clear();
// 		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
// 		{
// 			for (j=pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBreakerRange; j<pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nBreakerRange; j++)
// 			{
// 				nDev=pPGBlock->m_EdgeBreakerArray[j].nBreaker;
// 				if (bCheckOpen)
// 				{
// 					if (pPGBlock->m_BreakerArray[nDev].nStatus != 0)
// 						continue;
// 				}
// 
// 				nNode=(nNodeArray[i] == pPGBlock->m_BreakerArray[nDev].nNodeI) ? pPGBlock->m_BreakerArray[nDev].nNodeJ:pPGBlock->m_BreakerArray[nDev].nNodeI;
// 				if (bNodeUnProcArray[nNode])
// 				{
// 					nMidNodeArray.push_back(nNode);
// 					bNodeUnProcArray[nNode]=0;
// 				}
// 			}
// 			for (j=pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nDisconnectorRange; j<pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nDisconnectorRange; j++)
// 			{
// 				nDev=pPGBlock->m_EdgeDisconnectorArray[j].nDisconnector;
// 				if (bCheckOpen)
// 				{
// 					if (pPGBlock->m_DisconnectorArray[nDev].nStatus != 0)
// 						continue;
// 				}
// 
// 				nNode=(nNodeArray[i] == pPGBlock->m_DisconnectorArray[nDev].nNodeI) ? pPGBlock->m_DisconnectorArray[nDev].nNodeJ : pPGBlock->m_DisconnectorArray[nDev].nNodeI;
// 				if (bNodeUnProcArray[nNode])
// 				{
// 					nMidNodeArray.push_back(nNode);
// 					bNodeUnProcArray[nNode]=0;
// 				}
// 			}
// 			for (j=pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; j<pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; j++)
// 			{
// 				nDev=pPGBlock->m_EdgeACLineSegmentArray[j].nACLineSegment;
// 				if (pPGBlock->m_ACLineSegmentArray[nDev].bOpen != 0 || pPGBlock->m_ACLineSegmentArray[nDev].bOutage != 0)
// 					continue;
// 				if (!IsNodeJointSourceWithinVoltage(pPGBlock, nNodeArray[i]))
// 				{
// 					nNode=(nNodeArray[i] == pPGBlock->m_ACLineSegmentArray[nDev].nNodeI) ? pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ : pPGBlock->m_ACLineSegmentArray[nDev].nNodeI;
// 					if (bNodeUnProcArray[nNode])
// 					{
// 						nMidNodeArray.push_back(nNode);
// 						bNodeUnProcArray[nNode]=0;
// 					}
// 				}
// 			}
// 			for (j=pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nTransformerWindingRange; j<pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nTransformerWindingRange; j++)
// 			{
// 				nDev=pPGBlock->m_EdgeTransformerWindingArray[j].nTransformerWinding;
// 				if (pPGBlock->m_TransformerWindingArray[nDev].bOpen != 0 || pPGBlock->m_TransformerWindingArray[nDev].bOutage != 0)
// 					continue;
// 				if (!IsNodeJointSourceWithinVoltage(pPGBlock, nNodeArray[i]))
// 				{
// 					nNode=(nNodeArray[i] == pPGBlock->m_TransformerWindingArray[nDev].nNodeI) ? pPGBlock->m_TransformerWindingArray[nDev].nNodeJ:pPGBlock->m_TransformerWindingArray[nDev].nNodeI;
// 					if (bNodeUnProcArray[nNode])
// 					{
// 						nMidNodeArray.push_back(nNode);
// 						bNodeUnProcArray[nNode]=0;
// 					}
// 				}
// 			}
// 			for (j=pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nSeriesCompensatorRange; j<pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nSeriesCompensatorRange; j++)
// 			{
// 				nDev=pPGBlock->m_EdgeSeriesCompensatorArray[j].nSeriesCompensator;
// 				nNode=(nNodeArray[i] == pPGBlock->m_SeriesCompensatorArray[nDev].nNodeI) ? pPGBlock->m_SeriesCompensatorArray[nDev].nNodeJ : pPGBlock->m_SeriesCompensatorArray[nDev].nNodeI;
// 				if (bNodeUnProcArray[nNode])
// 				{
// 					nMidNodeArray.push_back(nNode);
// 					bNodeUnProcArray[nNode]=0;
// 				}
// 			}
// 		}
// 		if (nMidNodeArray.empty())
// 			break;
// 		nNodeNumOfLayer=(int)nNodeArray.size();
// 		for (i=0; i<(int)nMidNodeArray.size(); i++)
// 			nNodeArray.push_back(nMidNodeArray[i]);
// 	}
// }

int CDistributionTraceTraverse::CheckNodeSource(tagPGBlock* pPGBlock, const int nStartNode)
{
	register int	i;
	int		nNode;

	int		nNodeNum;
	int*	pnNodeArray = (int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnNodeArray)
		return 0;

	PGTraverseNet(pPGBlock, nStartNode, Y_CheckStatus, 0, nNodeNum, pnNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[i].nNode == pnNodeArray[nNode])
				return 1;
		}
	}
	free(pnNodeArray);

	//std::vector<int>	nNodeArray;
	//TraverseNet(pPGBlock, nStartNode, 1, nNodeArray);
	//for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
	//{
	//	for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
	//	{
	//		if (pPGBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
	//			return 1;
	//	}
	//}

	return 0;
}

int CDistributionTraceTraverse::CheckNodeSplit(tagPGBlock* pPGBlock, const int nNodeI , const int nNodeJ)
{
	register int	i;

	int		nNodeNum;
	int*	pnNodeArray = (int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnNodeArray)
		return 0;

	PGTraverseNet(pPGBlock, nNodeI, Y_CheckStatus, 0, nNodeNum, pnNodeArray);
	for (i=0; i<nNodeNum; i++)
	{
		if (pnNodeArray[i] == nNodeJ)
			return 0;
	}
	free(pnNodeArray);

// 	std::vector<int>	nNodeArray;
// 	TraverseNet(pPGBlock, nNodeI, 1, nNodeArray);
// 	for (i=0; i<(int)nNodeArray.size(); i++)
// 	{
// 		if (nNodeArray[i] == nNodeJ)
// 			return 0;
// 	}
	return 1;
}

int CDistributionTraceTraverse::CheckRouter(tagPGBlock* pPGBlock, const int nStartNode , const int nDestNode)
{
	register int	i;
	std::vector<int>	nNodeArray;

	m_bNodeProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_bNodeProcArray[i]=0;

	nNodeArray.clear();
	TraceConnection(pPGBlock, 1, nDestNode, -1, -1, 0, nStartNode, 0, nNodeArray);
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (nNodeArray[i] == nDestNode)
			return 1;
	}

	return 0;
}

int CDistributionTraceTraverse::TraverseShift(tagPGBlock* pPGBlock, const int nStartNode, std::vector<int>& nShiftNodeArray)
{
	register int	i;
	int		nNode, nNodeNum, nNodeArray[4000];
	std::vector<unsigned char>	bNodeUnProcArray;

	nShiftNodeArray.clear();
	bNodeUnProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		bNodeUnProcArray[i]=1;

	int		nJointNum;
	int*	nJointArray;
	nJointArray=(int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!nJointArray)
		return -1;

	PGTraverseNet(pPGBlock, nStartNode, Y_CheckStatus, 0, nJointNum, nJointArray);
	for (i=0; i<nJointNum; i++)
		bNodeUnProcArray[nJointArray[i]]=0;

	for (nNode=0; nNode<nJointNum; nNode++)
	{
		//PGTraverseVolt(pPGBlock, nJointArray[nNode], N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
		PGTraverseLine(pPGBlock, nJointArray[nNode], N_CheckStatus, nNodeNum, nNodeArray);
		for (i=0; i<nNodeNum; i++)
		{
			if (!bNodeUnProcArray[nNodeArray[i]])
				continue;
			if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].sa_Ability <= 0)
				continue;

			if (CheckNodeSource(pPGBlock, nNodeArray[i]))
				nShiftNodeArray.push_back(nNodeArray[i]);
		}
	}

	free(nJointArray);

	if (nShiftNodeArray.empty())
	{
		Log(g_lpszLogFile, "                ShiftNodeArrayΪ��\n");
		return -1;
	}

#ifdef _DEBUG
	for (i=0; i<(int)nShiftNodeArray.size(); i++)
		Log(g_lpszLogFile, "                ��ͨ��Դ�ڵ�[%d/%d] %s.%s.%s\n", i, nShiftNodeArray.size(), 
				pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].szSub, 
				pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].szVolt, 
				pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].szName);
#endif // _DEBUG

	i=0;
	while (i < (int)nShiftNodeArray.size())
	{
		int	nRet=CheckRouter(pPGBlock, nStartNode, nShiftNodeArray[i]);
		if (!nRet)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "                    ɾ����Դ�ڵ�[%d/%d] %s.%s.%s\n", i, nShiftNodeArray.size(), 
					pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].szSub, 
					pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].szVolt, 
					pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].szName);
#endif // _DEBUG
			nShiftNodeArray.erase(nShiftNodeArray.begin()+i);
		}
		else
		{
			i++;
		}
	}
	if (!nShiftNodeArray.empty())
	{
		double	fMax=pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[0]].sa_Ability;
		double	fMin=pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[0]].sa_Ability;
		int		nMax=0;
		int		nMin=0;
		for (i=1; i<(int)nShiftNodeArray.size(); i++)
		{
			if (fMax < pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].sa_Ability)
			{
				fMax = pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].sa_Ability;
				nMax=i;
			}
			if (fMin > pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].sa_Ability)
			{
				fMin = pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[i]].sa_Ability;
				nMin=i;
			}
		}
#ifdef _DEBUG
		Log(g_lpszLogFile, "                ����Դ�ڵ�[%d/%d] %s.%s.%s %f\n", i, nShiftNodeArray.size(), 
			pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[nMax]].szSub, pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[nMax]].szVolt, pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[nMax]].szName, fMax);
		Log(g_lpszLogFile, "                ��С��Դ�ڵ�[%d/%d] %s.%s.%s %f\n", i, nShiftNodeArray.size(), 
			pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[nMax]].szSub, pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[nMax]].szVolt, pPGBlock->m_ConnectivityNodeArray[nShiftNodeArray[nMax]].szName, fMin);
#endif // _DEBUG

		return nMax;
	}
	return -1;
}

void CDistributionTraceTraverse::InitSaAbility(tagPGBlock* pPGBlock)
{
	int		nDev;

	tagNodeAbility	nodeAbility;

	m_NodeAbilityArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; nDev++)
		pPGBlock->m_ConnectivityNodeArray[nDev].sa_Ability=0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		InitNodeAbility(pPGBlock, pPGBlock->m_ACLineSegmentArray[nDev].nNodeI, m_NodeAbilityArray[pPGBlock->m_ACLineSegmentArray[nDev].nNodeI]);
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ACLineSegmentArray[nDev].nNodeI].sa_Ability=(float)m_NodeAbilityArray[pPGBlock->m_ACLineSegmentArray[nDev].nNodeI].fAbility;

		InitNodeAbility(pPGBlock, pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ, m_NodeAbilityArray[pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ]);
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ].sa_Ability=(float)m_NodeAbilityArray[pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ].fAbility;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		InitNodeAbility(pPGBlock, pPGBlock->m_TransformerWindingArray[nDev].nNodeI, m_NodeAbilityArray[pPGBlock->m_TransformerWindingArray[nDev].nNodeI]);
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_TransformerWindingArray[nDev].nNodeI].sa_Ability=(float)m_NodeAbilityArray[pPGBlock->m_TransformerWindingArray[nDev].nNodeI].fAbility;

		InitNodeAbility(pPGBlock, pPGBlock->m_TransformerWindingArray[nDev].nNodeJ, m_NodeAbilityArray[pPGBlock->m_TransformerWindingArray[nDev].nNodeJ]);
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_TransformerWindingArray[nDev].nNodeJ].sa_Ability=(float)m_NodeAbilityArray[pPGBlock->m_TransformerWindingArray[nDev].nNodeJ].fAbility;
	}
}

int CDistributionTraceTraverse::CheckNodeOneSource(tagPGBlock* pPGBlock, const int nStartNode)
{
	std::vector<tagPGRecursiveChannel>	traceChannelArray;
	std::vector<int>					nSrcArray;

	TraceSource(pPGBlock, nStartNode, 1, traceChannelArray, nSrcArray);

	if (!nSrcArray.empty())	//	�ж����з�����Ƿ���һ����վ����ͨ�������ͨ�򷢵������һ����Դ�㣬�������ڶ����Դ��
	{
		register int	i;
		int				nUnit;
		int				nNodeNum, nNodeArray[1000];
		unsigned char	bInNode;

		PGTraverseSub(pPGBlock, pPGBlock->m_SynchronousMachineArray[nSrcArray[0]].nNode, Y_CheckStatus, nNodeNum, nNodeArray);
		for (nUnit=0; nUnit<(int)nSrcArray.size(); nUnit++)
		{
			bInNode=0;
			for (i=0; i<nNodeNum; i++)
			{
				if (nNodeArray[i] == pPGBlock->m_SynchronousMachineArray[nSrcArray[nUnit]].nNode)
				{
					bInNode=1;
					break;
				}
			}
			if (!bInNode)
			{
				return 0;
			}
		}
	}
	return 1;
}

void CDistributionTraceTraverse::GetParallelLine(tagPGBlock* pPGBlock, const int nLine, std::vector<int>& nParaLineArray)
{
	register int	i;
	int		nINode, nZNode;
	unsigned char	bInNode;
	int	nINodeNum, nINodeArray[1000];
	int	nZNodeNum, nZNodeArray[1000];

	nParaLineArray.clear();
	PGTraverseSub(pPGBlock, pPGBlock->m_ACLineSegmentArray[nLine].nNodeI, Y_CheckStatus, nINodeNum, nINodeArray);
	PGTraverseSub(pPGBlock, pPGBlock->m_ACLineSegmentArray[nLine].nNodeJ, Y_CheckStatus, nZNodeNum, nZNodeArray);

	for (nINode=0; nINode<nINodeNum; nINode++)
	{
		for (i=pPGBlock->m_ConnectivityNodeArray[nINodeArray[nINode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nINodeArray[nINode]+1].nACLineSegmentRange; i++)
		{
			bInNode=0;
			for (nZNode=0; nZNode<nZNodeNum; nZNode++)
			{
				if (pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment].nNodeI == nZNodeArray[nZNode] ||
					pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment].nNodeJ == nZNodeArray[nZNode])
				{
					bInNode=1;
					break;
				}
			}
			if (bInNode)
			{
				nParaLineArray.push_back(pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment);
			}
		}
	}
}

void CDistributionTraceTraverse::GetParallelTran(tagPGBlock* pPGBlock, const int nTran, std::vector<int>& nParaTranArray)
{
	register int	i;
	int		nINode, nZNode;
	unsigned char	bInNode;
	int	nINodeNum, nINodeArray[1000];
	int	nZNodeNum, nZNodeArray[1000];

	nParaTranArray.clear();
	PGTraverseSub(pPGBlock, pPGBlock->m_TransformerWindingArray[nTran].nNodeI, Y_CheckStatus, nINodeNum, nINodeArray);
	PGTraverseSub(pPGBlock, pPGBlock->m_TransformerWindingArray[nTran].nNodeJ, Y_CheckStatus, nZNodeNum, nZNodeArray);

	for (nINode=0; nINode<nINodeNum; nINode++)
	{
		for (i=pPGBlock->m_ConnectivityNodeArray[nINodeArray[nINode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nINodeArray[nINode]+1].nTransformerWindingRange; i++)
		{
			bInNode=0;
			for (nZNode=0; nZNode<nZNodeNum; nZNode++)
			{
				if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nNodeI == nZNodeArray[nZNode] ||
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nNodeJ == nZNodeArray[nZNode])
				{
					bInNode=1;
					break;
				}
			}
			if (bInNode)
			{
				nParaTranArray.push_back(pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding);
			}
		}
	}
}

int CDistributionTraceTraverse::CheckLineOneSource(tagPGBlock* pPGBlock, const int nLine)
{
	register int	i;
	int	nISrc, nZSrc;
	std::vector<int>	nParaLineArray;

	GetParallelLine(pPGBlock, nLine, nParaLineArray);

	for (i=0; i<(int)nParaLineArray.size(); i++)
		pPGBlock->m_ACLineSegmentArray[nParaLineArray[i]].bOpen=1;

	nISrc=CheckNodeSource(pPGBlock, pPGBlock->m_ACLineSegmentArray[nLine].nNodeI);
	nZSrc=CheckNodeSource(pPGBlock, pPGBlock->m_ACLineSegmentArray[nLine].nNodeJ);

	for (i=0; i<(int)nParaLineArray.size(); i++)
		pPGBlock->m_ACLineSegmentArray[nParaLineArray[i]].bOpen=0;

	if (!nISrc && !nZSrc)	return -1;
	if (nISrc == nZSrc)		return 0;

	if (nISrc)	return 1;
	return 2;
}

int CDistributionTraceTraverse::CheckTranOneSource(tagPGBlock* pPGBlock, const int nTran)
{
	register int	i;
	int	nISrc, nZSrc;
	std::vector<int>	nParaTranArray;

	GetParallelTran(pPGBlock, nTran, nParaTranArray);

	for (i=0; i<(int)nParaTranArray.size(); i++)
		pPGBlock->m_TransformerWindingArray[nParaTranArray[i]].bOpen=1;

	nISrc=CheckNodeSource(pPGBlock, pPGBlock->m_TransformerWindingArray[nTran].nNodeI);
	nZSrc=CheckNodeSource(pPGBlock, pPGBlock->m_TransformerWindingArray[nTran].nNodeJ);

	for (i=0; i<(int)nParaTranArray.size(); i++)
		pPGBlock->m_TransformerWindingArray[nParaTranArray[i]].bOpen=0;

	if (!nISrc && !nZSrc)	return -1;
	if (nISrc == nZSrc)		return 0;

	if (nISrc)	return 1;
	return 2;
}

void CDistributionTraceTraverse::TripOneLine(tagPGBlock* pPGBlock, const int nLine)
{
	register int	i;
	int		nSrcNode, nNonSrcNode, nLineSource;
	double	fAbility;
	std::vector<int>					nBlackOutLoadArray;
	std::vector<tagPGRecursiveChannel>	SourceChannelArray;

	pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Unknow;
	pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure=0;
	pPGBlock->m_ACLineSegmentArray[nLine].sa_ShiftNode=-1;

	nBlackOutLoadArray.clear();
	SourceChannelArray.clear();

	if (pPGBlock->m_ACLineSegmentArray[nLine].bOutage != 0)
	{
		pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Ceased;
#ifdef _DEBUG
		Log(g_lpszLogFile, "��·[%s]����\n", pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
		return;
	}

	nLineSource=CheckLineOneSource(pPGBlock, nLine);
	if (nLineSource <= 0)
	{
		pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Ringed;
#ifdef _DEBUG
		Log(g_lpszLogFile, "��·[%s]�ǵ����Դ����\n", pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
		return;
	}

	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pPGBlock->m_ACLineSegmentArray[i].bOpen=0;
	pPGBlock->m_ACLineSegmentArray[nLine].bOpen=1;

	nNonSrcNode=nSrcNode=-1;
	if (nLineSource == 1)
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "��·[%s]������I->J, �ǵ�Դ��Ϊ:%s\n", pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ACLineSegmentArray[nLine].szSubJ);
#endif // _DEBUG
		nSrcNode=pPGBlock->m_ACLineSegmentArray[nLine].nNodeI;
		nNonSrcNode=pPGBlock->m_ACLineSegmentArray[nLine].nNodeJ;
	}
	else
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "��·[%s]������J->I, �ǵ�Դ��Ϊ:%s\n", pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ACLineSegmentArray[nLine].szSubI);
#endif // _DEBUG
		nSrcNode=pPGBlock->m_ACLineSegmentArray[nLine].nNodeJ;
		nNonSrcNode=pPGBlock->m_ACLineSegmentArray[nLine].nNodeI;
	}
	if (nNonSrcNode < 0)
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "  nNonSrcNode < 0\n");
#endif // _DEBUG
		return;
	}
	if (CheckNodeSplit(pPGBlock, nNonSrcNode, nSrcNode))
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "  ��·[%s]N-1�⻷\n", pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
		if (CheckNodeSource(pPGBlock, nNonSrcNode))
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "    �⻷��·���ɲ���ԴPrevAbility=%.3f\n", pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
			fAbility=FormNodeAbility(pPGBlock, nNonSrcNode, SourceChannelArray);
#ifdef _DEBUG
			Log(g_lpszLogFile, "    �⻷��·���ɲ���ԴPostAbility=%.3f\n", fAbility);
#endif // _DEBUG

			if (fAbility > 0)
			{
				pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Passed;
#ifdef _DEBUG
				Log(g_lpszLogFile, "            ��·[%d] %s N-1ͨ��\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
			}
			else
			{
				pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Failed;
				pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure=(float)fabs(fAbility);
#ifdef _DEBUG
				Log(g_lpszLogFile, "            ��·[%d] %s N-1��ͨ������ʧ���� %f\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure);
#endif // _DEBUG
			}
		}
		else
		{
			double	fLoadP=0, fLoadQ=0, fTotal=0;
#ifdef _DEBUG
			Log(g_lpszLogFile, "    �⻷��·���ɲ���Դ\n", pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
			TraverseLoad(pPGBlock, nNonSrcNode, 1, nBlackOutLoadArray);
			for (i=0; i<(int)nBlackOutLoadArray.size(); i++)
			{
				fLoadP += pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanP;
				fLoadQ += pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanQ;
#ifdef _DEBUG
				Log(g_lpszLogFile, "            ����[%d/%d] %s.%s ʧ�� %f MW\n", i, nBlackOutLoadArray.size(), pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].szSub, pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].szName, pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanP);
#endif // _DEBUG
			}

			fTotal=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
			if (fTotal > FLT_MIN)
			{
				std::vector<int>	nShiftNodeArray;
				int	nMaxNode=TraverseShift(pPGBlock, nNonSrcNode, nShiftNodeArray);
				if (nMaxNode >= 0)
				{
					pPGBlock->m_ACLineSegmentArray[nLine].sa_ShiftNode=nShiftNodeArray[nMaxNode];
					if (sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ) > pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ACLineSegmentArray[nLine].sa_ShiftNode].sa_Ability)
					{
						pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Failed;
						pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure=(float)(sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ)-pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ACLineSegmentArray[nLine].sa_ShiftNode].sa_Ability*fLoadP/fTotal);

#ifdef _DEBUG
						Log(g_lpszLogFile, "            ��·[%d] %s N-1��ͨ������ʧ���� %f\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure);
#endif // _DEBUG
					}
					else
					{
						pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Passed;
#ifdef _DEBUG
						Log(g_lpszLogFile, "            ��·[%d] %s N-1ͨ��\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
					}
				}
				else
				{
					pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Failed;
					pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure=(float)fLoadP;
#ifdef _DEBUG
					Log(g_lpszLogFile, "            ��·[%d] %s N-1��ͨ������ʧ���� %f\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName, fLoadP);
#endif // _DEBUG
				}
			}
			else
			{
				pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Passed;
			}
		}
	}
	else
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "    ��·[%s]N-1���⻷ PrevAbility=%.3f\n", pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ConnectivityNodeArray[nNonSrcNode].sa_Ability);		
#endif // _DEBUG
		fAbility=FormNodeAbility(pPGBlock, nNonSrcNode, SourceChannelArray);
#ifdef _DEBUG
		Log(g_lpszLogFile, "    ��·[%s]N-1���⻷ PostAbility=%.3f\n", pPGBlock->m_ACLineSegmentArray[nLine].szName, fAbility);
#endif // _DEBUG
		if (fAbility > 0)
		{
			pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Passed;
#ifdef _DEBUG
			Log(g_lpszLogFile, "            ��·[%d] %s N-1ͨ��\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName);
#endif // _DEBUG
		}
		else
		{
			pPGBlock->m_ACLineSegmentArray[nLine].sa_Result=PGEnumSaResult_Failed;
			pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure=(float)fabs(fAbility);
#ifdef _DEBUG
			Log(g_lpszLogFile, "            ��·[%d] %s N-1��ͨ������ʧ���� %f\n", nLine, pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ACLineSegmentArray[nLine].sa_Failure);
#endif // _DEBUG
		}

		//TV_INSERTSTRUCT itemTree;
		//HTREEITEM		hItem;
		//char			szBuf[260];
		//CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_TRACE_TREE);
		//pTreeCtrl->DeleteAllItems();
		//
		//sprintf(szBuf, "%s(%s.%s)", pPGBlock->m_ACLineSegmentArray[nLine].szName, pPGBlock->m_ACLineSegmentArray[nLine].szSubI, pPGBlock->m_ACLineSegmentArray[nLine].szSubJ);
		//itemTree.hParent=TVI_ROOT;
		//itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
		//itemTree.item.pszText=_T(szBuf);
		//itemTree.item.cchTextMax=260;
		//itemTree.item.lParam=0;
		//itemTree.item.state=TVIS_EXPANDED;
		//itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
		//hItem=pTreeCtrl->InsertItem(&itemTree);
		//
		//if (!lineNodeAbility.ChannelArray.empty())
		//	FillTrace(hItem, lineNodeAbility.ChannelArray);
	}
	pPGBlock->m_ACLineSegmentArray[nLine].bOpen=0;
}

void CDistributionTraceTraverse::TripOneTran(tagPGBlock* pPGBlock, const int nTran)
{
	register int	i;
	int		nSrcNode, nNonSrcNode, nTranSource;
	double	fAbility;
	std::vector<int>					nBlackOutLoadArray;
	std::vector<tagPGRecursiveChannel>	SourceChannelArray;

	pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Unknow;
	pPGBlock->m_TransformerWindingArray[nTran].sa_Failure=0;
	pPGBlock->m_TransformerWindingArray[nTran].sa_ShiftNode=-1;

	nBlackOutLoadArray.clear();
	SourceChannelArray.clear();

	if (pPGBlock->m_TransformerWindingArray[nTran].bOutage != 0)
	{
		pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Ceased;
#ifdef _DEBUG
		Log(g_lpszLogFile, "��ѹ��[%s]����\n", pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
		return;
	}

	nTranSource=CheckTranOneSource(pPGBlock, nTran);
	if (nTranSource <= 0)
	{
		pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Ringed;
#ifdef _DEBUG
		Log(g_lpszLogFile, "��ѹ��[%s]�ǵ����Դ����\n", pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
		return;
	}

	for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		pPGBlock->m_TransformerWindingArray[i].bOpen=0;
	pPGBlock->m_TransformerWindingArray[nTran].bOpen=1;

	nNonSrcNode=nSrcNode=-1;
	if (nTranSource == 1)
	{
		//Log(g_lpszLogFile, "��ѹ��[%s]������I->J, �ǵ�Դ��Ϊ:%s\n", pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_TransformerWindingArray[nTran].szSubJ);
		nSrcNode=pPGBlock->m_TransformerWindingArray[nTran].nNodeI;
		nNonSrcNode=pPGBlock->m_TransformerWindingArray[nTran].nNodeJ;
	}
	else
	{
		//Log(g_lpszLogFile, "��ѹ��[%s]������J->I, �ǵ�Դ��Ϊ:%s\n", pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_TransformerWindingArray[nTran].szSubI);
		nSrcNode=pPGBlock->m_TransformerWindingArray[nTran].nNodeJ;
		nNonSrcNode=pPGBlock->m_TransformerWindingArray[nTran].nNodeI;
	}
	if (nNonSrcNode < 0)
		return;

	if (CheckNodeSplit(pPGBlock, nNonSrcNode, nSrcNode))
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "  ��ѹ��[%s]N-1�⻷\n", pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
		if (CheckNodeSource(pPGBlock, nNonSrcNode))
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "    �⻷��ѹ�����ɲ���ԴPrevAbility=%.3f\n", pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
			fAbility=FormNodeAbility(pPGBlock, nNonSrcNode, SourceChannelArray);
#ifdef _DEBUG
			Log(g_lpszLogFile, "    �⻷��ѹ�����ɲ���ԴPostAbility=%.3f\n", fAbility);
#endif // _DEBUG

			if (fAbility > 0)
			{
				pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Passed;
#ifdef _DEBUG
				Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1ͨ��\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
			}
			else
			{
				pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Failed;
				pPGBlock->m_TransformerWindingArray[nTran].sa_Failure=(float)fabs(fAbility);
#ifdef _DEBUG
				Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1��ͨ������ʧ���� %f\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_TransformerWindingArray[nTran].sa_Failure);
#endif // _DEBUG
			}
		}
		else
		{
			double	fLoadP=0, fLoadQ=0, fTotal=0;
#ifdef _DEBUG
			Log(g_lpszLogFile, "    �⻷��ѹ�����ɲ���Դ\n", pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
			TraverseLoad(pPGBlock, nNonSrcNode, 1, nBlackOutLoadArray);
			for (i=0; i<(int)nBlackOutLoadArray.size(); i++)
			{
				fLoadP += pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanP;
				fLoadQ += pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanQ;
#ifdef _DEBUG
				Log(g_lpszLogFile, "            ����[%d/%d]%s.%sʧ��\n", i, nBlackOutLoadArray.size(), pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].szSub, pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].szName);
#endif // _DEBUG
			}

			fTotal=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
			if (fTotal > FLT_MIN)
			{
				std::vector<int>	nShiftNodeArray;
				int	nMaxNode=TraverseShift(pPGBlock, nNonSrcNode, nShiftNodeArray);
				if (nMaxNode >= 0)
				{
					pPGBlock->m_TransformerWindingArray[nTran].sa_ShiftNode=nShiftNodeArray[nMaxNode];
					if (sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ) > pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_TransformerWindingArray[nTran].sa_ShiftNode].sa_Ability)
					{
						pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Failed;
						pPGBlock->m_TransformerWindingArray[nTran].sa_Failure=(float)(sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ)-pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_TransformerWindingArray[nTran].sa_ShiftNode].sa_Ability*fLoadP/fTotal);

#ifdef _DEBUG
						Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1��ͨ������ʧ���� %f\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_TransformerWindingArray[nTran].sa_Failure);
#endif // _DEBUG
					}
					else
					{
						pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Passed;
#ifdef _DEBUG
						Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1ͨ��\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
					}
				}
				else
				{
					pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Failed;
					pPGBlock->m_TransformerWindingArray[nTran].sa_Failure=(float)fLoadP;
#ifdef _DEBUG
					Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1��ͨ������ʧ���� %f\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName, fLoadP);
#endif // _DEBUG
				}
			}
		}
	}
	else
	{
#ifdef _DEBUG
		Log(g_lpszLogFile, "  ��ѹ��[%s]N-1���⻷ PrevAbility=%.3f\n", pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_ConnectivityNodeArray[nNonSrcNode].sa_Ability);
#endif // _DEBUG
		fAbility=FormNodeAbility(pPGBlock, nNonSrcNode, SourceChannelArray);
#ifdef _DEBUG
		Log(g_lpszLogFile, "  ��ѹ��[%s]N-1���⻷ PostAbility=%.3f\n", pPGBlock->m_TransformerWindingArray[nTran].szName, fAbility);
#endif // _DEBUG
		if (fAbility > 0)
		{
			pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Passed;
#ifdef _DEBUG
			Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1ͨ��\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName);
#endif // _DEBUG
		}
		else
		{
			pPGBlock->m_TransformerWindingArray[nTran].sa_Result=PGEnumSaResult_Failed;
			pPGBlock->m_TransformerWindingArray[nTran].sa_Failure=(float)fabs(fAbility);
#ifdef _DEBUG
			Log(g_lpszLogFile, "            ��ѹ��[%d] %s N-1��ͨ������ʧ���� %f\n", nTran, pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_TransformerWindingArray[nTran].sa_Failure);
#endif // _DEBUG
		}

		//TV_INSERTSTRUCT itemTree;
		//HTREEITEM		hItem;
		//char			szBuf[260];
		//CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_TRACE_TREE);
		//pTreeCtrl->DeleteAllItems();
		//
		//sprintf(szBuf, "%s(%s.%s)", pPGBlock->m_TransformerWindingArray[nTran].szName, pPGBlock->m_TransformerWindingArray[nTran].szSubI, pPGBlock->m_TransformerWindingArray[nTran].szSubJ);
		//itemTree.hParent=TVI_ROOT;
		//itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
		//itemTree.item.pszText=_T(szBuf);
		//itemTree.item.cchTextMax=260;
		//itemTree.item.lParam=0;
		//itemTree.item.state=TVIS_EXPANDED;
		//itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
		//hItem=pTreeCtrl->InsertItem(&itemTree);
		//
		//if (!lineNodeAbility.ChannelArray.empty())
		//	FillTrace(hItem, lineNodeAbility.ChannelArray);
	}
	pPGBlock->m_TransformerWindingArray[nTran].bOpen=0;
}

void CDistributionTraceTraverse::TripOneSub(tagPGBlock* pPGBlock, const int nSub)
{
	register int	i, j;
	int		nVolt, nNode;
	unsigned char	bPassed;
	std::vector<double>					fNodeAbilityArray;
	std::vector<int>					nBlackOutLoadArray;
	std::vector<tagPGRecursiveChannel>	SourceChannelArray;
	std::vector<int>			nJointNodeArray, nChkNodeArray;
	std::vector<unsigned char>	uChkNodeProcArray;

	pPGBlock->m_SubstationArray[nSub].sa_Result=PGEnumSaResult_Unknow;
	pPGBlock->m_SubstationArray[nSub].sa_Failure=0;
	pPGBlock->m_SubstationArray[nSub].sa_Outages=0;
	nBlackOutLoadArray.clear();
	SourceChannelArray.clear();

	int		nNodeNum;
	int*	pnNodeArray = (int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnNodeArray)
		return;




	bPassed=1;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pPGBlock->m_ACLineSegmentArray[i].bOpen=0;

	fNodeAbilityArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE], 0);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		fNodeAbilityArray[i]=pPGBlock->m_ConnectivityNodeArray[i].sa_Ability;

	nChkNodeArray.clear();
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (pPGBlock->m_ACLineSegmentArray[i].bOutage != 0)
			continue;

		if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szSubI, pPGBlock->m_SubstationArray[nSub].szName) == 0)
		{
			nChkNodeArray.push_back(pPGBlock->m_ACLineSegmentArray[i].nNodeJ);
			pPGBlock->m_ACLineSegmentArray[i].bOpen=1;
		}
		else if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szSubJ, pPGBlock->m_SubstationArray[nSub].szName) == 0)
		{
			nChkNodeArray.push_back(pPGBlock->m_ACLineSegmentArray[i].nNodeI);
			pPGBlock->m_ACLineSegmentArray[i].bOpen=1;
		}
	}
	uChkNodeProcArray.resize(nChkNodeArray.size(), 0);
	for (i=0; i<(int)nChkNodeArray.size(); i++)
		uChkNodeProcArray[i]=0;

	for (nNode=0; nNode<(int)nChkNodeArray.size(); nNode++)
	{
		if (uChkNodeProcArray[nNode])
			continue;
		uChkNodeProcArray[nNode]=1;

		PGTraverseNet(pPGBlock, nChkNodeArray[nNode], Y_CheckStatus, 0, nNodeNum, pnNodeArray);
		for (j=nNode+1; j<(int)nChkNodeArray.size(); j++)
		{
			for (i=0; i<nNodeNum; i++)
			{
				if (nChkNodeArray[j] == pnNodeArray[i])
				{
					uChkNodeProcArray[j]=1;
					break;
				}
			}
		}
		//TraverseNet(pPGBlock, nChkNodeArray[nNode], 1, nJointNodeArray);
		//for (j=nNode+1; j<(int)nChkNodeArray.size(); j++)
		//{
		//	for (i=0; i<(int)nJointNodeArray.size(); i++)
		//	{
		//		if (nChkNodeArray[j] == nJointNodeArray[i])
		//		{
		//			uChkNodeProcArray[j]=1;
		//			break;
		//		}
		//	}
		//}
		if (CheckNodeSource(pPGBlock, nChkNodeArray[nNode]) != 0)
			continue;

		double	fLoadP=0, fLoadQ=0;
		TraverseLoad(pPGBlock, nChkNodeArray[nNode], 1, nBlackOutLoadArray);
		for (i=0; i<(int)nBlackOutLoadArray.size(); i++)
		{
			fLoadP += pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanP;
			fLoadQ += pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].fPlanQ;
			//Log(g_lpszLogFile, "            ����[%d/%d]%s.%sʧ��\n", i, nBlackOutLoadArray.size(), pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].szSub, pPGBlock->m_EnergyConsumerArray[nBlackOutLoadArray[i]].szName);
		}

		std::vector<int>	nShiftNodeArray;
		int	nMaxNode=TraverseShift(pPGBlock, nChkNodeArray[nNode], nShiftNodeArray);
		if (nMaxNode >= 0)
		{
			if (sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ) > fNodeAbilityArray[nShiftNodeArray[nMaxNode]])
			{
				double	fBuf=0;
				if (sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ) > DBL_MIN)
					fBuf=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ)-fNodeAbilityArray[nShiftNodeArray[nMaxNode]]*fLoadP/sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
				fNodeAbilityArray[nShiftNodeArray[nMaxNode]]=0;
				//Log(g_lpszLogFile, "                ��ʧ���� %f\n", fBuf);

				pPGBlock->m_SubstationArray[nSub].sa_Failure += (float)fBuf;
				bPassed=0;
			}
			else
			{
				fNodeAbilityArray[nShiftNodeArray[nMaxNode]] -= sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
			}
		}
		else
		{
			pPGBlock->m_SubstationArray[nSub].sa_Failure += (float)fLoadP;
			//Log(g_lpszLogFile, "                ��ʧ���� %f\n", fLoadP);
			bPassed=0;
		}
	}
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pPGBlock->m_ACLineSegmentArray[i].bOpen=0;
	if (!bPassed)
	{
		pPGBlock->m_SubstationArray[nSub].sa_Result=PGEnumSaResult_Failed;
		Log(g_lpszLogFile, "    ������ʧ���� %f\n", pPGBlock->m_SubstationArray[nSub].sa_Failure);
	}
	else
	{
		pPGBlock->m_SubstationArray[nSub].sa_Result=PGEnumSaResult_Passed;
		Log(g_lpszLogFile, "    N-1ͨ��\n");
	}
	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
		{
			if (pPGBlock->m_EnergyConsumerArray[i].bOutage != 0)
				continue;

			pPGBlock->m_SubstationArray[nSub].sa_Outages += pPGBlock->m_EnergyConsumerArray[i].fPlanP;
		}
	}

	free(pnNodeArray);
}
