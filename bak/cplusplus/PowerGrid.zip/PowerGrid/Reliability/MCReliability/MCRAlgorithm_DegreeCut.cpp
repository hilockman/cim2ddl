#include "StdAfx.h"
#include "MCRAlgorithm.h"

//#define _Breaker_Degree_

//////////////////////////////////////////////////////////////////////////
//	��·�����·��֮�䲻����
void CMCRAlgorithm::FormDegreeShortCut(const unsigned char bBreakerFaultFailure)
{
	register int	i;
	int		nFComp, nSComp, nTComp;
	int		nCommIndex;
	tagMCRAlgMinCut1	sCut1Buf;

	for (i=0; i<(int)m_MinCut2Array.size(); i++)
		m_MinCut2Array[i].bDegree = 0;
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
		m_MinCut3Array[i].bDegree = 0;

	//һ�׸������

	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		nFComp=m_MinCut2Array[i].nComp[0];
		nSComp=m_MinCut2Array[i].nComp[1];

#ifdef _Breaker_Degree_
		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp == PG_BREAKER)
			continue;
#endif // _Breaker_Degree_

		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER)
		{
			if (!bBreakerFaultFailure && m_CompArray[nSComp].nPhyTyp == PG_BREAKER)	//	��·���ǹ��Ϲ������ý��ף����뼴��
			{
			}
			else
			{
				nCommIndex = SeekBreakerComm(nFComp, nSComp);
				if (nCommIndex >= 0)
				{
					if (SeekMCut01(m_MinCut1Array, nSComp) < 0 && SeekCommMCut01(m_CmMCut1Array, nSComp) < 0)
					{
						if (m_CompArray[nSComp].fRerr > FLT_MIN && m_CompArray[nSComp].fTrep > FLT_MIN)
						{
							memset(&sCut1Buf, 0, sizeof(tagMCRAlgMinCut1));
							sCut1Buf.nSwitchComp = -1;

							sCut1Buf.nCutType = MCREnumCutType_2Degree1;
							sCut1Buf.nComp = nSComp;
							sCut1Buf.fR = m_CompArray[nSComp].fRerr;
							sCut1Buf.fT = m_CompArray[nSComp].fTrep;

							sCut1Buf.nDegreeComp[0] = m_MinCut2Array[i].nComp[0];
							sCut1Buf.nDegreeComp[1] = m_MinCut2Array[i].nComp[1];

							m_MinCut2Array[i].bDegree = 1;

							m_MinCut1Array.push_back(sCut1Buf);

#ifdef _DEBUG
							Log(g_lpszLogFile,  "    1�����׸��Ϊһ�׸� : [%s %s] R=%f T=%f\n", m_CompArray[nFComp].strName.c_str(), m_CompArray[nSComp].strName.c_str(), sCut1Buf.fR, sCut1Buf.fT);
#endif
						}
					}
				}
			}
		}
		else if (m_CompArray[nSComp].nPhyTyp == PG_BREAKER)
		{
			if (!bBreakerFaultFailure && m_CompArray[nFComp].nPhyTyp == PG_BREAKER)	//	��·���ǹ��Ϲ������ý��ף����뼴��
			{
			}
			else
			{
				nCommIndex = SeekBreakerComm(nSComp, nFComp);
				if (nCommIndex >= 0)
				{
					if (SeekMCut01(m_MinCut1Array, nFComp) < 0 && SeekCommMCut01(m_CmMCut1Array, nFComp) < 0)
					{
						if (m_CompArray[nFComp].fRerr > FLT_MIN && m_CompArray[nFComp].fTrep > FLT_MIN)
						{
							memset(&sCut1Buf, 0, sizeof(tagMCRAlgMinCut1));
							sCut1Buf.nSwitchComp = -1;

							sCut1Buf.nCutType = MCREnumCutType_2Degree1;
							sCut1Buf.nComp = nFComp;
							sCut1Buf.fR = m_CompArray[nFComp].fRerr;
							sCut1Buf.fT = m_CompArray[nFComp].fTrep;

							sCut1Buf.nDegreeComp[0] = m_MinCut2Array[i].nComp[0];
							sCut1Buf.nDegreeComp[1] = m_MinCut2Array[i].nComp[1];

							m_MinCut2Array[i].bDegree = 1;
							m_MinCut1Array.push_back(sCut1Buf);

#ifdef _DEBUG
							Log(g_lpszLogFile,  "    2�����׸��Ϊһ�׸� : [%s %s] R=%f T=%f\n", m_CompArray[nFComp].strName.c_str(), m_CompArray[nSComp].strName.c_str(), sCut1Buf.fR, sCut1Buf.fT);
#endif
						}
					}
				}
			}
		}
	}

	//���ף�
	//	����Ϊ����ʱ��ģ�豸���޸�ʱ����Ҫ�ù��϶�λʱ��
	//	����Ϊһ��ʱ��ģ�豸���޸�ʱ����Ҫ����С���϶�λʱ��
	//	һ�����ؽ�Ϊ����
	//	�������ؽ�Ϊһ��
	//	�������ؽ�Ϊһ�׻����
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		nFComp=m_MinCut3Array[i].nComp[0];
		nSComp=m_MinCut3Array[i].nComp[1];
		nTComp=m_MinCut3Array[i].nComp[2];

#ifdef _Breaker_Degree_
		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp == PG_BREAKER && m_CompArray[nTComp].nPhyTyp == PG_BREAKER)
			continue;
#endif // _Breaker_Degree_

		if (bBreakerFaultFailure && m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp == PG_BREAKER && m_CompArray[nTComp].nPhyTyp == PG_BREAKER)
		{
			FormDegreeShortcut3BreakerTo1(i, nFComp, nSComp, nTComp);
			FormDegreeShortcut3BreakerTo2(i, nFComp, nSComp, nTComp);
		}
		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp == PG_BREAKER && m_CompArray[nTComp].nPhyTyp != PG_BREAKER)
		{
			FormDegreeShortcut3To1(i, nFComp, nSComp, nTComp);
		}
		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nTComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp != PG_BREAKER)
		{
			FormDegreeShortcut3To1(i, nFComp, nTComp, nSComp);
		}
		if (m_CompArray[nSComp].nPhyTyp == PG_BREAKER && m_CompArray[nTComp].nPhyTyp == PG_BREAKER && m_CompArray[nFComp].nPhyTyp != PG_BREAKER)
		{
			FormDegreeShortcut3To1(i, nSComp, nTComp, nFComp);
		}
		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp != PG_BREAKER && m_CompArray[nTComp].nPhyTyp != PG_BREAKER)
		{
			FormDegreeShortcut3To2(i, nFComp, nSComp, nTComp);
		}
		if (m_CompArray[nSComp].nPhyTyp == PG_BREAKER && m_CompArray[nFComp].nPhyTyp != PG_BREAKER && m_CompArray[nTComp].nPhyTyp != PG_BREAKER)
		{
			FormDegreeShortcut3To2(i, nSComp, nFComp, nTComp);
		}
		if (m_CompArray[nTComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp != PG_BREAKER && m_CompArray[nSComp].nPhyTyp != PG_BREAKER)
		{
			FormDegreeShortcut3To2(i, nTComp, nFComp, nSComp);
		}
	}
}

void CMCRAlgorithm::FormDegreeShortcut3BreakerTo1(const int nMCut, const int nBreaker1, const int nBreaker2, const int nBreaker3)
{
	int		nCommIndexA, nCommIndexB;

	nCommIndexA = SeekBreakerComm(nBreaker1, nBreaker3);	//	CmComp��Breaker1�Ĺ�ģ�豸��
	nCommIndexB = SeekBreakerComm(nBreaker2, nBreaker3);	//	CmComp��Breaker2�Ĺ�ģ�豸��
	if (nCommIndexA >= 0 && nCommIndexB >= 0)
	{
		if (SeekMCut01(m_MinCut1Array, nBreaker3) < 0 && SeekCommMCut01(m_CmMCut1Array, nBreaker3) < 0)
		{
			if (m_CompArray[nBreaker3].fRerr > FLT_MIN && m_CompArray[nBreaker3].fTrep > FLT_MIN)
			{
				tagMCRAlgMinCut1	sCut1Buf;
				memset(&sCut1Buf, 0, sizeof(tagMCRCmMinCut1));
				sCut1Buf.nSwitchComp = -1;
				sCut1Buf.nCutType = MCREnumCutType_3Degree1;
				sCut1Buf.nComp = nBreaker3;

				sCut1Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
				sCut1Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
				sCut1Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

				m_MinCut3Array[nMCut].bDegree = 1;
				m_MinCut1Array.push_back(sCut1Buf);
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸�˫���ؽ�12-3Ϊһ�� : [%s %s %s]\n", m_CompArray[nBreaker1].strName.c_str(), m_CompArray[nBreaker2].strName.c_str(), m_CompArray[nBreaker3].strName.c_str());
#endif
		}
	}

	nCommIndexA = SeekBreakerComm(nBreaker1, nBreaker2);	//	CmComp��Breaker1�Ĺ�ģ�豸��
	nCommIndexB = SeekBreakerComm(nBreaker3, nBreaker2);	//	CmComp��Breaker2�Ĺ�ģ�豸��
	if (nCommIndexA >= 0 && nCommIndexB >= 0)
	{
		if (SeekMCut01(m_MinCut1Array, nBreaker2) < 0 && SeekCommMCut01(m_CmMCut1Array, nBreaker2) < 0)
		{
			if (m_CompArray[nBreaker2].fRerr > FLT_MIN && m_CompArray[nBreaker2].fTrep > FLT_MIN)
			{
				tagMCRAlgMinCut1	sCut1Buf;
				memset(&sCut1Buf, 0, sizeof(tagMCRCmMinCut1));
				sCut1Buf.nSwitchComp = -1;
				sCut1Buf.nCutType = MCREnumCutType_3Degree1;
				sCut1Buf.nComp = nBreaker2;

				sCut1Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
				sCut1Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
				sCut1Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

				m_MinCut3Array[nMCut].bDegree = 1;
				m_MinCut1Array.push_back(sCut1Buf);
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸�˫���ؽ�12-3Ϊһ�� : [%s %s %s]\n", m_CompArray[nBreaker1].strName.c_str(), m_CompArray[nBreaker3].strName.c_str(), m_CompArray[nBreaker2].strName.c_str());
#endif
		}
	}

	nCommIndexA = SeekBreakerComm(nBreaker3, nBreaker1);	//	CmComp��Breaker1�Ĺ�ģ�豸��
	nCommIndexB = SeekBreakerComm(nBreaker2, nBreaker1);	//	CmComp��Breaker2�Ĺ�ģ�豸��
	if (nCommIndexA >= 0 && nCommIndexB >= 0)
	{
		if (SeekMCut01(m_MinCut1Array, nBreaker1) < 0 && SeekCommMCut01(m_CmMCut1Array, nBreaker1) < 0)
		{
			if (m_CompArray[nBreaker1].fRerr > FLT_MIN && m_CompArray[nBreaker1].fTrep > FLT_MIN)
			{
				tagMCRAlgMinCut1	sCut1Buf;
				memset(&sCut1Buf, 0, sizeof(tagMCRCmMinCut1));
				sCut1Buf.nSwitchComp = -1;
				sCut1Buf.nCutType = MCREnumCutType_3Degree1;
				sCut1Buf.nComp = nBreaker1;

				sCut1Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
				sCut1Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
				sCut1Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

				m_MinCut3Array[nMCut].bDegree = 1;
				m_MinCut1Array.push_back(sCut1Buf);
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸�˫���ؽ�12-3Ϊһ�� : [%s %s %s]\n", m_CompArray[nBreaker3].strName.c_str(), m_CompArray[nBreaker2].strName.c_str(), m_CompArray[nBreaker1].strName.c_str());
#endif
		}
	}
}

void CMCRAlgorithm::FormDegreeShortcut3BreakerTo2(const int nMCut, const int nBreaker1, const int nBreaker2, const int nBreaker3)
{
	int		nCommIndexA, nCommIndexB;
	double	fR1, fT1, fR2, fT2;

	//	2��3��1�Ĺ�ģ�豸
	nCommIndexA = SeekBreakerComm(nBreaker1, nBreaker2);
	nCommIndexB = SeekBreakerComm(nBreaker1, nBreaker3);
	if (nCommIndexA >= 0 || nCommIndexB >= 0)
	{
		if (SeekMCut02(m_MinCut2Array, nBreaker2, nBreaker3) < 0 && SeekMCut01(m_MinCut1Array, nBreaker2) < 0 && SeekMCut01(m_MinCut1Array, nBreaker3) < 0)
		{
			tagMCRAlgMinCut2	sCut2Buf;
			memset(&sCut2Buf, 0, sizeof(tagMCRAlgMinCut2));
			sCut2Buf.nSwitchComp[0]=-1;
			sCut2Buf.nSwitchComp[1]=-1;

			fR1=m_CompArray[nBreaker2].fRerr;
			fR2=m_CompArray[nBreaker3].fRerr;
			fT1=m_CompArray[nBreaker2].fTrep;
			fT2=m_CompArray[nBreaker3].fTrep;

			sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
			if (8760*sCut2Buf.fR > FLT_MIN)
				sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

			if (sCut2Buf.fT > FLT_MIN && sCut2Buf.fR > FLT_MIN)
			{
				sCut2Buf.nCutType = MCREnumCutType_3Degree2;
				sCut2Buf.nComp[0]=nBreaker2;
				sCut2Buf.nComp[1]=nBreaker3;

				sCut2Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
				sCut2Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
				sCut2Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

				m_MinCut3Array[nMCut].bDegree = 1;
				m_MinCut2Array.push_back(sCut2Buf);
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸���ؽ�Ϊ���� : [%s %s %s]\n", m_CompArray[nBreaker1].strName.c_str(), m_CompArray[nBreaker2].strName.c_str(), m_CompArray[nBreaker3].strName.c_str());
#endif
		}
	}

	//	1��3��2�Ĺ�ģ�豸
	nCommIndexA = SeekBreakerComm(nBreaker2, nBreaker1);
	nCommIndexB = SeekBreakerComm(nBreaker2, nBreaker3);
	if (nCommIndexA >= 0 || nCommIndexB >= 0)
	{
		if (SeekMCut02(m_MinCut2Array, nBreaker1, nBreaker3) < 0 && SeekMCut01(m_MinCut1Array, nBreaker1) < 0 && SeekMCut01(m_MinCut1Array, nBreaker3) < 0)
		{
			tagMCRAlgMinCut2	sCut2Buf;
			memset(&sCut2Buf, 0, sizeof(tagMCRAlgMinCut2));
			sCut2Buf.nSwitchComp[0]=-1;
			sCut2Buf.nSwitchComp[1]=-1;

			fR1=m_CompArray[nBreaker1].fRerr;
			fR2=m_CompArray[nBreaker3].fRerr;
			fT1=m_CompArray[nBreaker1].fTrep;
			fT2=m_CompArray[nBreaker3].fTrep;

			sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
			if (8760*sCut2Buf.fR > FLT_MIN)
				sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

			if (sCut2Buf.fT > FLT_MIN && sCut2Buf.fR > FLT_MIN)
			{
				sCut2Buf.nCutType = MCREnumCutType_3Degree2;
				sCut2Buf.nComp[0]=nBreaker1;
				sCut2Buf.nComp[1]=nBreaker3;

				sCut2Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
				sCut2Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
				sCut2Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

				m_MinCut3Array[nMCut].bDegree = 1;
				m_MinCut2Array.push_back(sCut2Buf);
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸���ؽ�Ϊ���� : [%s %s %s]\n", m_CompArray[nBreaker2].strName.c_str(), m_CompArray[nBreaker1].strName.c_str(), m_CompArray[nBreaker3].strName.c_str());
#endif
		}
	}

	//	1��2��3�Ĺ�ģ�豸
	nCommIndexA = SeekBreakerComm(nBreaker3, nBreaker2);
	nCommIndexB = SeekBreakerComm(nBreaker3, nBreaker1);
	if (nCommIndexA >= 0 || nCommIndexB >= 0)
	{
		if (SeekMCut02(m_MinCut2Array, nBreaker2, nBreaker1) < 0 && SeekMCut01(m_MinCut1Array, nBreaker2) < 0 && SeekMCut01(m_MinCut1Array, nBreaker1) < 0)
		{
			tagMCRAlgMinCut2	sCut2Buf;
			memset(&sCut2Buf, 0, sizeof(tagMCRAlgMinCut2));
			sCut2Buf.nSwitchComp[0]=-1;
			sCut2Buf.nSwitchComp[1]=-1;

			fR1=m_CompArray[nBreaker2].fRerr;
			fR2=m_CompArray[nBreaker1].fRerr;
			fT1=m_CompArray[nBreaker2].fTrep;
			fT2=m_CompArray[nBreaker1].fTrep;

			sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
			if (8760*sCut2Buf.fR > FLT_MIN)
				sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

			if (sCut2Buf.fT > FLT_MIN && sCut2Buf.fR > FLT_MIN)
			{
				sCut2Buf.nCutType = MCREnumCutType_3Degree2;
				sCut2Buf.nComp[0]=nBreaker2;
				sCut2Buf.nComp[1]=nBreaker1;

				sCut2Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
				sCut2Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
				sCut2Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

				m_MinCut3Array[nMCut].bDegree = 1;
				m_MinCut2Array.push_back(sCut2Buf);
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸���ؽ�Ϊ���� : [%s %s %s]\n", m_CompArray[nBreaker3].strName.c_str(), m_CompArray[nBreaker2].strName.c_str(), m_CompArray[nBreaker1].strName.c_str());
#endif
		}
	}
}

void CMCRAlgorithm::FormDegreeShortcut3To1(const int nMCut, const int nBreaker1, const int nBreaker2, const int nCmComp)
{
	int		nCommIndex1, nCommIndex2;

	nCommIndex1 = SeekBreakerComm(nBreaker1, nCmComp);	//	CmComp��Breaker1�Ĺ�ģ�豸��
	nCommIndex2 = SeekBreakerComm(nBreaker2, nCmComp);	//	CmComp��Breaker2�Ĺ�ģ�豸��
	if (nCommIndex1 < 0 || nCommIndex2 < 0)
		return;

	if (SeekMCut01(m_MinCut1Array, nCmComp) >= 0 || SeekMCut02(m_MinCut2Array, nBreaker1, nCmComp) >= 0 || SeekMCut02(m_MinCut2Array, nBreaker2, nCmComp) >= 0)
		return;

	if (m_CompArray[nCmComp].fRerr > FLT_MIN && m_CompArray[nCmComp].fTrep > FLT_MIN)
	{
		tagMCRAlgMinCut1	sCut1Buf;
		memset(&sCut1Buf, 0, sizeof(tagMCRCmMinCut1));
		sCut1Buf.nSwitchComp = -1;
		sCut1Buf.nCutType = MCREnumCutType_3Degree1;
		sCut1Buf.nComp = nCmComp;

		sCut1Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
		sCut1Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
		sCut1Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

		m_MinCut3Array[nMCut].bDegree = 1;
		m_MinCut1Array.push_back(sCut1Buf);
	}
#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ���׸�˫���ؽ�Ϊһ�� : [%s %s %s]\n", m_CompArray[nBreaker1].strName.c_str(), m_CompArray[nBreaker2].strName.c_str(), m_CompArray[nCmComp].strName.c_str());
#endif
}

void CMCRAlgorithm::FormDegreeShortcut3To2(const int nMCut, const int nFCmBreaker, const int nComp1, const int nComp2)
{
	int		nCommIndex1, nCommIndex2;
	double	fR1, fT1, fR2, fT2;

	nCommIndex1 = SeekBreakerComm(nFCmBreaker, nComp1);
	nCommIndex2 = SeekBreakerComm(nFCmBreaker, nComp2);
	if (nCommIndex1 < 0 && nCommIndex2 < 0)
		return;

	if (SeekMCut02(m_MinCut2Array, nComp1, nComp2) >= 0)
		return;

	tagMCRAlgMinCut2	sCut2Buf;
	memset(&sCut2Buf, 0, sizeof(tagMCRAlgMinCut2));
	sCut2Buf.nSwitchComp[0]=-1;
	sCut2Buf.nSwitchComp[1]=-1;

	fR1=m_CompArray[nComp1].fRerr;
	fR2=m_CompArray[nComp2].fRerr;
	fT1=m_CompArray[nComp1].fTrep;
	fT2=m_CompArray[nComp2].fTrep;

	sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
	if (8760*sCut2Buf.fR > FLT_MIN)
		sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

	if (sCut2Buf.fT > FLT_MIN && sCut2Buf.fR > FLT_MIN)
	{
		sCut2Buf.nCutType = MCREnumCutType_3Degree2;
		sCut2Buf.nComp[0]=nComp1;
		sCut2Buf.nComp[1]=nComp2;

		sCut2Buf.nDegreeComp[0] = m_MinCut3Array[nMCut].nComp[0];
		sCut2Buf.nDegreeComp[1] = m_MinCut3Array[nMCut].nComp[1];
		sCut2Buf.nDegreeComp[2] = m_MinCut3Array[nMCut].nComp[2];

		m_MinCut3Array[nMCut].bDegree = 1;
		m_MinCut2Array.push_back(sCut2Buf);
	}
#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ���׸���ؽ�Ϊ���� : [%s %s %s]\n", m_CompArray[nFCmBreaker].strName.c_str(), m_CompArray[nComp1].strName.c_str(), m_CompArray[nComp2].strName.c_str());
#endif
}

void CMCRAlgorithm::EraseDegreeShortCut()
{
	register int	i;

	std::vector<tagMCRAlgMinCut2>	sAlgMCut02Array;
	sAlgMCut02Array.clear();
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		if (m_MinCut2Array[i].bDegree)
			continue;
		sAlgMCut02Array.push_back(m_MinCut2Array[i]);
	}
	m_MinCut2Array.assign(sAlgMCut02Array.begin(), sAlgMCut02Array.end());
	sAlgMCut02Array.clear();

	std::vector<tagMCRAlgMinCut3>	sAlgMCut03Array;
	sAlgMCut03Array.clear();
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		if (m_MinCut3Array[i].bDegree)
			continue;
		sAlgMCut03Array.push_back(m_MinCut3Array[i]);
	}
	m_MinCut3Array.assign(sAlgMCut03Array.begin(), sAlgMCut03Array.end());
	sAlgMCut03Array.clear();
}