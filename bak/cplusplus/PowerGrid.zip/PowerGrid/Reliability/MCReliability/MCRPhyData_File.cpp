#include "StdAfx.h"
#include "MCRPhyData.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

int CMCRPhyData::ReadPhyFile(const char* lpszFileName)
{
	tagMCRPhyBus			sBusBuffer;
	tagMCRPhyLine			sLineBuffer;
	tagMCRPhyTran			sTranBuffer;
	tagMCRPhyScap			sScapBuffer;
	tagMCRPhyBreaker		sBreakerBuffer;
	tagMCRPhyDisconnector	sDisconnectorBuffer;

	m_BusArray.clear();
	m_LineArray.clear();
	m_TranArray.clear();
	m_ScapArray.clear();
	m_BreakerArray.clear();
	m_DisconnectorArray.clear();

	TiXmlElement*	pLine;
	TiXmlDocument	doc(lpszFileName);
	if (!doc.LoadFile())
	{
		Log(g_lpszLogFile, "װ�������߲����ļ�ʧ��(MCDataFile = %s ) XMLError=%s\n", lpszFileName, doc.ErrorDesc());
		//AfxMessageBox("װ�������ļ�ʧ��");
		return 0;
	}

	TiXmlAttribute*	pAttr;
	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "MCReliabilityData") != 0)
	{
		doc.Clear();
		return 0;
	}

	m_strMCDataFileName = lpszFileName;

	int		nField;
	// Traverse children of pRoot, populating the list of lines
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), PGGetTableName(PG_BUSBARSECTION)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_BUSBARSECTION)) == 0)
		{
			InitializePhyBus(&sBusBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_BUSBARSECTION, pAttr->Name());
				if (nField >= 0)
					SetPhyBusData(&sBusBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_BusArray.push_back(sBusBuffer);
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_ACLINESEGMENT)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_ACLINESEGMENT)) == 0)
		{
			InitializePhyLine(&sLineBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_ACLINESEGMENT, pAttr->Name());
				if (nField >= 0)
					SetPhyLineData(&sLineBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_LineArray.push_back(sLineBuffer);
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_TRANSFORMERWINDING)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_TRANSFORMERWINDING)) == 0)
		{
			InitializePhyTran(&sTranBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_TRANSFORMERWINDING, pAttr->Name());
				if (nField >= 0)
					SetPhyTranData(&sTranBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_TranArray.push_back(sTranBuffer);
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_SERIESCOMPENSATOR)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_SERIESCOMPENSATOR)) == 0)
		{
			InitializePhyScap(&sScapBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_SERIESCOMPENSATOR, pAttr->Name());
				if (nField >= 0)
					SetPhyScapData(&sScapBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_ScapArray.push_back(sScapBuffer);
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_BREAKER)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_BREAKER)) == 0)
		{
			InitializePhyBreaker(&sBreakerBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_BREAKER, pAttr->Name());
				if (nField >= 0)
					SetPhyBreakerData(&sBreakerBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_BreakerArray.push_back(sBreakerBuffer);
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_DISCONNECTOR)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_DISCONNECTOR)) == 0)
		{
			InitializePhyDisconnector(&sDisconnectorBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_DISCONNECTOR, pAttr->Name());
				if (nField >= 0)
					SetPhyDisconnectorData(&sDisconnectorBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_DisconnectorArray.push_back(sDisconnectorBuffer);
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_ENERGYCONSUMER)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_ENERGYCONSUMER)) == 0)
		{
			InitializePhyLine(&sLineBuffer);

			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				nField = GetPhyDataField(PG_ENERGYCONSUMER, pAttr->Name());
				if (nField >= 0)
					SetPhyLineData(&sLineBuffer, nField, pAttr->Value());

				pAttr=pAttr->Next();
			}
			m_LineArray.push_back(sLineBuffer);
		}

		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();

	PhyTopo();

	return 1;
}

void CMCRPhyData::SavePhyFile(const char* lpszFileName)
{
	int		nField, nRecord;
	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement		*pRootElement, *pTableElement;

	pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("MCReliabilityData");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	for (nRecord=0; nRecord<(int)m_BusArray.size(); nRecord++)
	{
		pTableElement = new TiXmlElement(PGGetTableName(PG_BUSBARSECTION));
		pRootElement->LinkEndChild(pTableElement);

		for (nField=0; nField<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); nField++)
			pTableElement->SetAttribute(PGGetFieldName(PG_BUSBARSECTION, g_MCPhyBusField[nField].nMDBField),	GetPhyDataValue(PG_BUSBARSECTION, nField, nRecord));
	}

	for (nRecord=0; nRecord<(int)m_LineArray.size(); nRecord++)
	{
		pTableElement = new TiXmlElement(PGGetTableName(PG_ACLINESEGMENT));
		pRootElement->LinkEndChild(pTableElement);

		for (nField=0; nField<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); nField++)
			pTableElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, g_MCPhyLineField[nField].nMDBField),	GetPhyDataValue(PG_ACLINESEGMENT, nField, nRecord));
	}

	for (nRecord=0; nRecord<(int)m_TranArray.size(); nRecord++)
	{
		pTableElement = new TiXmlElement(PGGetTableName(PG_TRANSFORMERWINDING));
		pRootElement->LinkEndChild(pTableElement);

		for (nField=0; nField<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); nField++)
			pTableElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, g_MCPhyTranField[nField].nMDBField),	GetPhyDataValue(PG_TRANSFORMERWINDING, nField, nRecord));
	}

	for (nRecord=0; nRecord<(int)m_ScapArray.size(); nRecord++)
	{
		pTableElement = new TiXmlElement(PGGetTableName(PG_SERIESCOMPENSATOR));
		pRootElement->LinkEndChild(pTableElement);

		for (nField=0; nField<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); nField++)
			pTableElement->SetAttribute(PGGetFieldName(PG_SERIESCOMPENSATOR, g_MCPhyScapField[nField].nMDBField),	GetPhyDataValue(PG_SERIESCOMPENSATOR, nField, nRecord));
	}

	for (nRecord=0; nRecord<(int)m_BreakerArray.size(); nRecord++)
	{
		pTableElement = new TiXmlElement(PGGetTableName(PG_BREAKER));
		pRootElement->LinkEndChild(pTableElement);

		for (nField=0; nField<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); nField++)
			pTableElement->SetAttribute(PGGetFieldName(PG_BREAKER, g_MCPhyBreakerField[nField].nMDBField),	GetPhyDataValue(PG_BREAKER, nField, nRecord));
	}

	for (nRecord=0; nRecord<(int)m_DisconnectorArray.size(); nRecord++)
	{
		pTableElement = new TiXmlElement(PGGetTableName(PG_DISCONNECTOR));
		pRootElement->LinkEndChild(pTableElement);

		for (nField=0; nField<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); nField++)
			pTableElement->SetAttribute(PGGetFieldName(PG_DISCONNECTOR, g_MCPhyDisconnectorField[nField].nMDBField),	GetPhyDataValue(PG_DISCONNECTOR, nField, nRecord));
	}

	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}

int CMCRPhyData::ReadPhyRParamFile(const char* lpszFileName)
{
	InitializeMCRPhyParam();

	TiXmlElement	*pLine, *pDev;
	register int	i;
	int				nVolt;
	TiXmlDocument	doc(lpszFileName);
	if (!doc.LoadFile())
	{
		Log(g_lpszLogFile, "װ�������߲����ļ�ʧ��(MCDataFile = %s ) XMLError=%s\n", lpszFileName, doc.ErrorDesc());
		//AfxMessageBox("װ�������ļ�ʧ��");
		return 0;
	}

	TiXmlAttribute*	pAttr;
	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "MCRParamData") != 0)
	{
		doc.Clear();
		return 0;
	}

	// Traverse children of pRoot, populating the list of lines
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), PGGetTableName(PG_BUSBARSECTION)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_BUSBARSECTION)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_MCRParam.fBusRerr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_MCRParam.fBusTrep = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_MCRParam.fBusRchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_MCRParam.fBusTchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)	m_MCRParam.fBusTopr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Invest") == 0)
				{
					for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
						m_MCRParam.sMCREconomy[nVolt].fBusInvest = atof(pAttr->Value());
				}

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_ACLINESEGMENT)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_ACLINESEGMENT)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_MCRParam.fLineRerr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_MCRParam.fLineTrep = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_MCRParam.fLineRchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_MCRParam.fLineTchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)	m_MCRParam.fLineTopr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Invest") == 0)
				{
					for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
						m_MCRParam.sMCREconomy[nVolt].fLineInvest = atof(pAttr->Value());
				}
				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_TRANSFORMERWINDING)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_TRANSFORMERWINDING)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_MCRParam.fTranRerr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_MCRParam.fTranTrep = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_MCRParam.fTranRchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_MCRParam.fTranTchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)	m_MCRParam.fTranTopr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Invest") == 0)
				{
					for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
						m_MCRParam.sMCREconomy[nVolt].fTranInvest = atof(pAttr->Value());
				}

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_SERIESCOMPENSATOR)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_SERIESCOMPENSATOR)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_MCRParam.fScapRerr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_MCRParam.fScapTrep = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_MCRParam.fScapRchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_MCRParam.fScapTchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)	m_MCRParam.fScapTopr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Invest") == 0)
				{
					for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
						m_MCRParam.sMCREconomy[nVolt].fScapInvest = atof(pAttr->Value());
				}

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_BREAKER)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_BREAKER)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)			m_MCRParam.fBreakerRerr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)		m_MCRParam.fBreakerTrep = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)		m_MCRParam.fBreakerRchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)		m_MCRParam.fBreakerTchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)		m_MCRParam.fBreakerTopr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "TSwitch") == 0)	m_MCRParam.fBreakerTSwitch = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Invest") == 0)
				{
					for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
						m_MCRParam.sMCREconomy[nVolt].fBreakerInvest = atof(pAttr->Value());
				}
				else if (stricmp(pAttr->Name(), "ChkBus") == 0)		m_MCRParam.bBreakerChkBus = atoi(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_DISCONNECTOR)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_DISCONNECTOR)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)			m_MCRParam.fDisconnectorRerr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)		m_MCRParam.fDisconnectorTrep = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)		m_MCRParam.fDisconnectorRchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)		m_MCRParam.fDisconnectorTchk = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)		m_MCRParam.fDisconnectorTopr = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "TSwitch") == 0)	m_MCRParam.fDisconnectorTSwitch = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Invest") == 0)
				{
					for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
					m_MCRParam.sMCREconomy[nVolt].fDisconnectorInvest = atof(pAttr->Value());
				}
				else if (stricmp(pAttr->Name(), "ChkBus") == 0)		m_MCRParam.bDisconnectorChkBus = atoi(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), "Invest") == 0)
		{
			pDev = pLine->FirstChildElement();
			while (pDev != NULL)
			{
				nVolt = -1;
				for (i=0; i<g_nVoltageLevelNum; i++)
				{
					if (stricmp(pDev->Value(), GetVoltageLevelTag(i)) == 0)
					{
						nVolt = i;
						break;
					}
				}
				if (nVolt >= 0)
				{
					pAttr=pLine->FirstAttribute();
					while (pAttr != NULL)
					{
						if (stricmp(pAttr->Name(), PGGetTableName(PG_BUSBARSECTION)) == 0 || stricmp(pAttr->Name(), PGGetTableDesp(PG_BUSBARSECTION)) == 0)					m_MCRParam.sMCREconomy[nVolt].fBusInvest= atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), PGGetTableName(PG_ACLINESEGMENT)) == 0 || stricmp(pAttr->Name(), PGGetTableDesp(PG_ACLINESEGMENT)) == 0)			m_MCRParam.sMCREconomy[nVolt].fLineInvest= atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), PGGetTableName(PG_TRANSFORMERWINDING)) == 0 || stricmp(pAttr->Name(), PGGetTableDesp(PG_TRANSFORMERWINDING)) == 0)	m_MCRParam.sMCREconomy[nVolt].fTranInvest= atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), PGGetTableName(PG_SERIESCOMPENSATOR)) == 0 || stricmp(pAttr->Name(), PGGetTableDesp(PG_SERIESCOMPENSATOR)) == 0)	m_MCRParam.sMCREconomy[nVolt].fScapInvest= atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), PGGetTableName(PG_BREAKER)) == 0 || stricmp(pAttr->Name(), PGGetTableDesp(PG_BREAKER)) == 0)						m_MCRParam.sMCREconomy[nVolt].fBreakerInvest= atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), PGGetTableName(PG_DISCONNECTOR)) == 0 || stricmp(pAttr->Name(), PGGetTableDesp(PG_DISCONNECTOR)) == 0)				m_MCRParam.sMCREconomy[nVolt].fDisconnectorInvest= atof(pAttr->Value());

						pAttr=pAttr->Next();
					}
				}
				if (stricmp(pDev->Value(), PGGetTableName(PG_DISCONNECTOR)) == 0 || stricmp(pDev->Value(), PGGetTableDesp(PG_DISCONNECTOR)) == 0)
					m_MCRParam.fDisconnectorRerr = atof(pAttr->Value());

				pDev = pDev->NextSiblingElement();
			}
		}

		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();

	PhyTopo();

	return 1;
}

void CMCRPhyData::SavePhyRParamFile(const char* lpszFileName)
{
	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement		*pRootElement, *pTableElement, *pVoltElement;
	int					nVolt;

	pDocument = new TiXmlDocument();							//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("MCRParamData");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	//////////////////////////////////////////////////////////////////////////
	//	Bus
	pTableElement = new TiXmlElement(PGGetTableName(PG_BUSBARSECTION));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_MCRParam.fBusRerr);
	pTableElement->SetDoubleAttribute("Trep",	m_MCRParam.fBusTrep);
	pTableElement->SetDoubleAttribute("Rchk",	m_MCRParam.fBusRchk);
	pTableElement->SetDoubleAttribute("Tchk",	m_MCRParam.fBusTchk);
	pTableElement->SetDoubleAttribute("Topr",	m_MCRParam.fBusTopr);
	pTableElement->SetDoubleAttribute("Invest",	m_MCRParam.sMCREconomy[VoltageLevel_220kV].fBusInvest);

	//////////////////////////////////////////////////////////////////////////
	//	Line
	pTableElement = new TiXmlElement(PGGetTableName(PG_ACLINESEGMENT));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_MCRParam.fLineRerr);
	pTableElement->SetDoubleAttribute("Trep",	m_MCRParam.fLineTrep);
	pTableElement->SetDoubleAttribute("Rchk",	m_MCRParam.fLineRchk);
	pTableElement->SetDoubleAttribute("Tchk",	m_MCRParam.fLineTchk);
	pTableElement->SetDoubleAttribute("Topr",	m_MCRParam.fLineTopr);
	pTableElement->SetDoubleAttribute("Invest",	m_MCRParam.sMCREconomy[VoltageLevel_220kV].fLineInvest);

	//////////////////////////////////////////////////////////////////////////
	//	Tran
	pTableElement = new TiXmlElement(PGGetTableName(PG_TRANSFORMERWINDING));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_MCRParam.fTranRerr);
	pTableElement->SetDoubleAttribute("Trep",	m_MCRParam.fTranTrep);
	pTableElement->SetDoubleAttribute("Rchk",	m_MCRParam.fTranRchk);
	pTableElement->SetDoubleAttribute("Tchk",	m_MCRParam.fTranTchk);
	pTableElement->SetDoubleAttribute("Topr",	m_MCRParam.fTranTopr);
	pTableElement->SetDoubleAttribute("Invest",	m_MCRParam.sMCREconomy[VoltageLevel_220kV].fTranInvest);

	//////////////////////////////////////////////////////////////////////////
	//	Scap
	pTableElement = new TiXmlElement(PGGetTableName(PG_SERIESCOMPENSATOR));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_MCRParam.fScapRerr);
	pTableElement->SetDoubleAttribute("Trep",	m_MCRParam.fScapTrep);
	pTableElement->SetDoubleAttribute("Rchk",	m_MCRParam.fScapRchk);
	pTableElement->SetDoubleAttribute("Tchk",	m_MCRParam.fScapTchk);
	pTableElement->SetDoubleAttribute("Topr",	m_MCRParam.fScapTopr);
	pTableElement->SetDoubleAttribute("Invest",	m_MCRParam.sMCREconomy[VoltageLevel_220kV].fScapInvest);

	//////////////////////////////////////////////////////////////////////////
	//	Breaker
	pTableElement = new TiXmlElement(PGGetTableName(PG_BREAKER));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_MCRParam.fBreakerRerr);
	pTableElement->SetDoubleAttribute("Trep",	m_MCRParam.fBreakerTrep);
	pTableElement->SetDoubleAttribute("Rchk",	m_MCRParam.fBreakerRchk);
	pTableElement->SetDoubleAttribute("Tchk",	m_MCRParam.fBreakerTchk);
	pTableElement->SetDoubleAttribute("Topr",	m_MCRParam.fBreakerTopr);
	pTableElement->SetDoubleAttribute("TSwitch",m_MCRParam.fBreakerTSwitch);
	pTableElement->SetDoubleAttribute("Invest",	m_MCRParam.sMCREconomy[VoltageLevel_220kV].fBreakerInvest);
	pTableElement->SetAttribute("ChkBus",		m_MCRParam.bBreakerChkBus);

	//////////////////////////////////////////////////////////////////////////
	//	Disconnector
	pTableElement = new TiXmlElement(PGGetTableName(PG_DISCONNECTOR));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_MCRParam.fDisconnectorRerr);
	pTableElement->SetDoubleAttribute("Trep",	m_MCRParam.fDisconnectorTrep);
	pTableElement->SetDoubleAttribute("Rchk",	m_MCRParam.fDisconnectorRchk);
	pTableElement->SetDoubleAttribute("Tchk",	m_MCRParam.fDisconnectorTchk);
	pTableElement->SetDoubleAttribute("Topr",	m_MCRParam.fDisconnectorTopr);
	pTableElement->SetDoubleAttribute("TSwitch",m_MCRParam.fDisconnectorTSwitch);
	pTableElement->SetDoubleAttribute("Invest",	m_MCRParam.sMCREconomy[VoltageLevel_220kV].fDisconnectorInvest);
	pTableElement->SetAttribute("ChkBus",		m_MCRParam.bDisconnectorChkBus);

	pTableElement = new TiXmlElement("Invest");
	pRootElement->LinkEndChild(pTableElement);

	for (nVolt=0; nVolt<g_nVoltageLevelNum; nVolt++)
	{
		pVoltElement = new TiXmlElement(GetVoltageLevelTag(nVolt));
		pTableElement->LinkEndChild(pVoltElement);

		pVoltElement->SetDoubleAttribute(PGGetTableName(PG_BUSBARSECTION),		m_MCRParam.sMCREconomy[nVolt].fBusInvest);
		pVoltElement->SetDoubleAttribute(PGGetTableName(PG_ACLINESEGMENT),		m_MCRParam.sMCREconomy[nVolt].fLineInvest);
		pVoltElement->SetDoubleAttribute(PGGetTableName(PG_TRANSFORMERWINDING),	m_MCRParam.sMCREconomy[nVolt].fTranInvest);
		pVoltElement->SetDoubleAttribute(PGGetTableName(PG_SERIESCOMPENSATOR),	m_MCRParam.sMCREconomy[nVolt].fScapInvest);
		pVoltElement->SetDoubleAttribute(PGGetTableName(PG_BREAKER),			m_MCRParam.sMCREconomy[nVolt].fBreakerInvest);
		pVoltElement->SetDoubleAttribute(PGGetTableName(PG_DISCONNECTOR),		m_MCRParam.sMCREconomy[nVolt].fDisconnectorInvest);
	}

	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}

void CMCRPhyData::ExportMCRTableField(const char* lpszFileName)
{
	register int	i;
	char	szField[MDB_CHARLEN];

	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement		*pRootElement, *pTableElement;

	pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("MCReliabilityTableField");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	pTableElement = new TiXmlElement(PGGetTableName(PG_BUSBARSECTION));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); i++)
	{
		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_BUSBARSECTION, g_MCPhyBusField[i].nMDBField));
	}

	pTableElement = new TiXmlElement(PGGetTableName(PG_ACLINESEGMENT));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); i++)
	{
		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_ACLINESEGMENT, g_MCPhyLineField[i].nMDBField));
	}

	pTableElement = new TiXmlElement(PGGetTableName(PG_TRANSFORMERWINDING));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); i++)
	{
		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_TRANSFORMERWINDING, g_MCPhyTranField[i].nMDBField));
	}

	pTableElement = new TiXmlElement(PGGetTableName(PG_SERIESCOMPENSATOR));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); i++)
	{
		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_SERIESCOMPENSATOR, g_MCPhyScapField[i].nMDBField));
	}

	pTableElement = new TiXmlElement(PGGetTableName(PG_BREAKER));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); i++)
	{
		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_BREAKER, g_MCPhyBreakerField[i].nMDBField));
	}

	pTableElement = new TiXmlElement(PGGetTableName(PG_DISCONNECTOR));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); i++)
	{
		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_DISCONNECTOR, g_MCPhyDisconnectorField[i].nMDBField));
	}

	pTableElement = new TiXmlElement(PGGetTableName(PG_ENERGYCONSUMER));
	pRootElement->LinkEndChild(pTableElement);
	for (i=0; i<sizeof(g_MCPhyLoadField)/sizeof(tagMCRPhyField); i++)
	{
		if (g_MCPhyLoadField[i].nMDBField < 0)
			continue;

		sprintf(szField, "Field%d", i+1);
		pTableElement->SetAttribute(szField, PGGetFieldName(PG_ENERGYCONSUMER, g_MCPhyLoadField[i].nMDBField));
	}

	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}
