#pragma once

#include "MCRPerturbDataDefine.h"

class CMCRPerturb
{
public:
	CMCRPerturb(void);
	~CMCRPerturb(void);

public:
	tagMCRPerturbParam	m_Param;


public:
	int		ReadParamFile(const char* lpszFileName);
	void	SaveParamFile(const char* lpszFileName);
};
