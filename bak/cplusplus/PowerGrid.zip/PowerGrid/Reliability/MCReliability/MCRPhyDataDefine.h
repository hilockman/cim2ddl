#pragma once

#include "MCRCommon.h"

typedef	struct	_MCRPhyComp_
{
	short	nCompTyp;
	int		nCompIdx;
	double	fRerr;
	double	fTrep;
}	tagMCRPhyComp;

typedef	struct	_MCRPhyResult_
{
	double	fR;			//��Чͣ���ʣ���/�꣩
	double	fT;			//��Чͣ��ʱ�䣨Сʱ��
	double	fU;			//���ɵĲ�������=r*t��Сʱ/�꣩
	double	fEns;
	double	fFaultR;	//��Ч����ͣ���ʣ���/�꣩
	double	fFaultT;	//��Ч����ͣ��ʱ�䣨Сʱ��
	double	fFaultU;	//���ɵ�Ч���ϲ�������=r*t��Сʱ/�꣩
	double	fFaultEns;
	double	fPlanR;		//��ЧԤ����ͣ���ʣ���/�꣩
	double	fPlanT;		//��ЧԤ����ͣ��ʱ�䣨Сʱ��
	double	fPlanU;		//���ɵ�ЧԤ����Ԥ���Ų�������=r*t��Сʱ/�꣩
	double	fPlanEns;
}	tagMCRPhyResult;

typedef	struct	_MCRPhyPath_
{
	std::vector<tagMCRPhyComp>	sCompArray;
}	tagMCRPhyPath;

typedef	struct	_MCRPhyFault1_
{
	unsigned char	nFType;
	tagMCRPhyComp	sComp;
	tagMCRPhyComp	sSwitchComp;		//	�л��豸
	tagMCRPhyComp	sDegreeComp[3];		//	�����豸
	tagMCRPhyComp	sCommonBreaker[2];		//	��ģ��·��

	double	fR;
	double	fT;
	double	fU;
	double	fFaultR;
	double	fFaultT;
	double	fFaultU;
	double	fPlanR;
	double	fPlanT;
	double	fPlanU;

	double	fRContribution;	//	���϶��豸ָ��Ĺ��׶�
	double	fUContribution;	//	���϶��豸ָ��Ĺ��׶�
}	tagMCRPhyFault1;

typedef	struct	_MCRPhyFault2_
{
	unsigned char	nFType;
	tagMCRPhyComp	sComp[2];
	tagMCRPhyComp	sSwitchComp[2];		//	�л��豸
	tagMCRPhyComp	sDegreeComp[3];		//	�����豸
	tagMCRPhyComp	sCommonBreaker[2];	//	��ģ��·��

	double	fR;
	double	fT;
	double	fU;
	double	fFaultR;
	double	fFaultT;
	double	fFaultU;
	double	fPlanR;
	double	fPlanT;
	double	fPlanU;

	double	fRContribution;	//	���϶��豸ָ��Ĺ��׶�
	double	fUContribution;	//	���϶��豸ָ��Ĺ��׶�
}	tagMCRPhyFault2;


typedef	struct	_MCRPhyFault3_
{
	unsigned char	nFType;
	tagMCRPhyComp	sComp[3];
	tagMCRPhyComp	sSwitchComp[3];		//	Comp���л��豸

	double	fR;
	double	fT;
	double	fU;
	double	fFaultR;
	double	fFaultT;
	double	fFaultU;
	double	fPlanR;
	double	fPlanT;
	double	fPlanU;

	double	fRContribution;	//	���϶��豸ָ��Ĺ��׶�
	double	fUContribution;	//	���϶��豸ָ��Ĺ��׶�
}	tagMCRPhyFault3;

//////////////////////////////////////////////////////////////////////////
//	ԭʼ���ݶ���

typedef	struct _MCRPhyField_
{
	short			nField;
	unsigned char	bEditable;
	short			nMDBField;
}	tagMCRPhyField;

enum	MCDataEnum_PhyBus
{
	MCPhyBus_Sub = 0,
	MCPhyBus_Volt,
	MCPhyBus_Name,
	MCPhyBus_Node,
	MCPhyBus_ByPass,
	MCPhyBus_Rerr,
	MCPhyBus_Trep,
	MCPhyBus_Rchk,
	MCPhyBus_Tchk,
	MCPhyBus_Topr,
	MCPhyBus_Invest,
};
static	tagMCRPhyField g_MCPhyBusField[]=
{
	{	MCPhyBus_Sub,		1,	PG_BUSBARSECTION_SUBSTATION,		},
	{	MCPhyBus_Volt,		1,	PG_BUSBARSECTION_VOLTAGELEVEL,		},
	{	MCPhyBus_Name,		1,	PG_BUSBARSECTION_NAME,				},
	{	MCPhyBus_Node,		1,	PG_BUSBARSECTION_CONNECTIVITYNODE,	},
	{	MCPhyBus_ByPass,	1,	PG_BUSBARSECTION_BYPASS,			},
	{	MCPhyBus_Rerr,		1,	PG_BUSBARSECTION_RI_RERR,			},
	{	MCPhyBus_Trep,		1,	PG_BUSBARSECTION_RI_TREP,			},
	{	MCPhyBus_Rchk,		1,	PG_BUSBARSECTION_RI_RCHK,			},
	{	MCPhyBus_Tchk,		1,	PG_BUSBARSECTION_RI_TCHK,			},
	{	MCPhyBus_Topr,		1,	PG_BUSBARSECTION_RI_TFLOC,			},
	{	MCPhyBus_Invest,	1,	PG_BUSBARSECTION_EI_INVEST,			},
};
typedef	struct _MCRPhyBus
{
	std::string		strSub;
	std::string		strVolt;
	std::string		strName;
	std::string		strNode;
	unsigned char	bByPass;

	double			fRerr;	//	��/��̨.��
	double			fTrep;	//	Сʱ/��
	double			fRchk;	//	��/��̨.��
	double			fTchk;	//	Сʱ/��
	double			fTopr;	//	Сʱ/��

	double			fInvest;	//	�豸���	��Ԫ/��

	int				nNode;

	double			ro_RContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_UContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_ENSContribution;	//	�豸��ϵͳָ��Ĺ��׶�
}	tagMCRPhyBus;

enum	MCDataEnum_PhyLine
{
	MCPhyLine_SubI = 0,
	MCPhyLine_SubJ,
	MCPhyLine_Volt,
	MCPhyLine_Name,
	MCPhyLine_Type,
	MCPhyLine_Length,
	MCPhyLine_Power,
	MCPhyLine_NodeI,
	MCPhyLine_NodeJ,
	MCPhyLine_Rerr,
	MCPhyLine_Trep,
	MCPhyLine_Rchk,
	MCPhyLine_Tchk,
	MCPhyLine_Topr,
	MCPhyLine_Invest,
};
static	tagMCRPhyField g_MCPhyLineField[]=
{
	{	MCPhyLine_SubI,		1,	PG_ACLINESEGMENT_ISUBSTATION,		},
	{	MCPhyLine_SubJ,		1,	PG_ACLINESEGMENT_JSUBSTATION,		},
	{	MCPhyLine_Volt,		1,	PG_ACLINESEGMENT_IVOLTAGELEVEL,		},
	{	MCPhyLine_Name,		1,	PG_ACLINESEGMENT_NAME,				},
	{	MCPhyLine_Type,		1,	PG_ACLINESEGMENT_MCRTYPE,			},
	{	MCPhyLine_Length,	1,	PG_ACLINESEGMENT_LENGTH,			},
	{	MCPhyLine_Power,	1,	PG_ACLINESEGMENT_MCRPOWER,			},
	{	MCPhyLine_NodeI,	1,	PG_ACLINESEGMENT_CONNECTIVITYNODEI,	},
	{	MCPhyLine_NodeJ,	1,	PG_ACLINESEGMENT_CONNECTIVITYNODEJ,	},
	{	MCPhyLine_Rerr,		1,	PG_ACLINESEGMENT_RI_RERR,			},
	{	MCPhyLine_Trep,		1,	PG_ACLINESEGMENT_RI_TREP,			},
	{	MCPhyLine_Rchk,		1,	PG_ACLINESEGMENT_RI_RCHK,			},
	{	MCPhyLine_Tchk,		1,	PG_ACLINESEGMENT_RI_TCHK,			},
	{	MCPhyLine_Topr,		1,	PG_ACLINESEGMENT_RI_TFLOC,			},
	{	MCPhyLine_Invest,	1,	PG_ACLINESEGMENT_EI_INVEST,			},
};
static	tagMCRPhyField g_MCPhyLoadField[]=
{
	{	MCPhyLine_SubI,		1,	PG_ENERGYCONSUMER_SUBSTATION,		},
	{	MCPhyLine_SubJ,		1,	-1,									},
	{	MCPhyLine_Volt,		1,	PG_ENERGYCONSUMER_VOLTAGELEVEL,		},
	{	MCPhyLine_Name,		1,	PG_ENERGYCONSUMER_NAME,				},
	{	MCPhyLine_Type,		1,	-1,									},
	{	MCPhyLine_Length,	1,	-1,									},
	{	MCPhyLine_Power,	1,	PG_ENERGYCONSUMER_PLANP,			},
	{	MCPhyLine_NodeI,	1,	PG_ENERGYCONSUMER_CONNECTIVITYNODE,	},
	{	MCPhyLine_NodeJ,	1,	-1,									},
	{	MCPhyLine_Rerr,		1,	-1,									},
	{	MCPhyLine_Trep,		1,	-1,									},
	{	MCPhyLine_Rchk,		1,	-1,									},
	{	MCPhyLine_Tchk,		1,	-1,									},
	{	MCPhyLine_Topr,		1,	-1,									},
	{	MCPhyLine_Invest,	1,	-1,									},
};
typedef	struct _MCRPhyLine
{
	std::string		strSubI;
	std::string		strSubJ;
	std::string		strVolt;
	std::string		strName;
	unsigned char	nType;	//	��·�����ɡ���Դ
	double			fLength;	//	����
	double			fPower;
	std::string		strNodeI;
	std::string		strNodeJ;

	double			fRerr;	//	��/��̨.��
	double			fTrep;	//	Сʱ/��
	double			fRchk;	//	��/��̨.��
	double			fTchk;	//	Сʱ/��
	double			fTopr;	//	Сʱ

	double			fInvest;	//	�豸���	��Ԫ/����

	int				nNodeI;
	int				nNodeJ;

	unsigned char	bSourceI;
	unsigned char	bSourceJ;
	unsigned char	nStatus;

	double			ro_RContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_UContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_ENSContribution;	//	�豸��ϵͳָ��Ĺ��׶�

	unsigned char	bAlone;
	//////////////////////////////////////////////////////////////////////////
	//	�������������
	tagMCRPhyResult	sResult;
	tagMCRPhyResult	sPerturbResult[2*g_nConstMaxReliabilityPerturb+1];

	double			fRCTime;
	unsigned char	nRCCase;
	std::vector<tagMCRPhyPath>		sMinPathArray;			//	��С·
	std::vector<tagMCRPhyFault1>	sFault1Array;			//	һ����С��
	std::vector<tagMCRPhyFault2>	sFault2Array;			//	������С��
	std::vector<tagMCRPhyFault3>	sFault3Array;			//	������С��
}	tagMCRPhyLine;

enum	MCDataEnum_PhyTran
{
	MCPhyTran_Sub = 0,
	MCPhyTran_VoltI,
	MCPhyTran_VoltJ,
	MCPhyTran_Name,
	MCPhyTran_Type,
	MCPhyTran_Power,
	MCPhyTran_NodeI,
	MCPhyTran_NodeJ,
	MCPhyTran_Rerr,
	MCPhyTran_Trep,
	MCPhyTran_Rchk,
	MCPhyTran_Tchk,
	MCPhyTran_Topr,
	MCPhyTran_Invest,
};
static	tagMCRPhyField g_MCPhyTranField[]=
{
	{	MCPhyTran_Sub,		1,	PG_TRANSFORMERWINDING_SUBSTATION,			},
	{	MCPhyTran_VoltI,	1,	PG_TRANSFORMERWINDING_VOLTAGELEVELI,		},
	{	MCPhyTran_VoltJ,	1,	PG_TRANSFORMERWINDING_VOLTAGELEVELJ,		},
	{	MCPhyTran_Name,		1,	PG_TRANSFORMERWINDING_NAME,					},
	{	MCPhyTran_Type,		1,	PG_TRANSFORMERWINDING_MCRTYPE,				},
	{	MCPhyTran_Power,	1,	PG_TRANSFORMERWINDING_MCRPOWER,				},
	{	MCPhyTran_NodeI,	1,	PG_TRANSFORMERWINDING_CONNECTIVITYNODEI,	},
	{	MCPhyTran_NodeJ,	1,	PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ,	},
	{	MCPhyTran_Rerr,		1,	PG_TRANSFORMERWINDING_RI_RERR,				},
	{	MCPhyTran_Trep,		1,	PG_TRANSFORMERWINDING_RI_TREP,				},
	{	MCPhyTran_Rchk,		1,	PG_TRANSFORMERWINDING_RI_RCHK,				},
	{	MCPhyTran_Tchk,		1,	PG_TRANSFORMERWINDING_RI_TCHK,				},
	{	MCPhyTran_Topr,		1,	PG_TRANSFORMERWINDING_RI_TFLOC,				},
	{	MCPhyTran_Invest,	1,	PG_TRANSFORMERWINDING_EI_INVEST,			},
};
typedef	struct _MCRPhyTran
{
	std::string		strSub;
	std::string		strVoltI;
	std::string		strVoltJ;
	std::string		strName;
	unsigned char	nType;	//	��ѹ�������ɡ���Դ
	double			fPower;	//	MW
	std::string		strNodeI;
	std::string		strNodeJ;
	double			fRerr;	//	��/��̨.��
	double			fTrep;	//	Сʱ/��
	double			fRchk;	//	��/��̨.��
	double			fTchk;	//	Сʱ/��
	double			fTopr;	//	Сʱ

	double			fInvest;	//	�豸���	��Ԫ/̨

	int				nNodeI;
	int				nNodeJ;
	unsigned char	bSourceI;
	unsigned char	bSourceJ;
	unsigned char	nStatus;

	double			ro_RContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_UContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_ENSContribution;	//	�豸��ϵͳָ��Ĺ��׶�

	unsigned char	bAlone;

	//////////////////////////////////////////////////////////////////////////
	//	�������������
	tagMCRPhyResult	sResult;
	tagMCRPhyResult	sPerturbResult[2*g_nConstMaxReliabilityPerturb+1];

	double			fRCTime;
	unsigned char	nRCCase;
	std::vector<tagMCRPhyPath>		sMinPathArray;			//	��С·
	std::vector<tagMCRPhyFault1>	sFault1Array;			//	һ����С��
	std::vector<tagMCRPhyFault2>	sFault2Array;			//	������С��
	std::vector<tagMCRPhyFault3>	sFault3Array;			//	������С��
}	tagMCRPhyTran;

enum	MCDataEnum_PhyScap
{
	MCPhyScap_Sub = 0,
	MCPhyScap_Volt,
	MCPhyScap_Name,
	MCPhyScap_NodeI,
	MCPhyScap_NodeJ,
	MCPhyScap_Rerr,
	MCPhyScap_Trep,
	MCPhyScap_Rchk,
	MCPhyScap_Tchk,
	MCPhyScap_Topr,
	MCPhyScap_Invest,
};
static	tagMCRPhyField g_MCPhyScapField[]=
{
	{	MCPhyScap_Sub,		1,	PG_SERIESCOMPENSATOR_SUBSTATION,		},
	{	MCPhyScap_Volt,		1,	PG_SERIESCOMPENSATOR_VOLTAGELEVEL,		},
	{	MCPhyScap_Name,		1,	PG_SERIESCOMPENSATOR_NAME,				},
	{	MCPhyScap_NodeI,	1,	PG_SERIESCOMPENSATOR_CONNECTIVITYNODEI,	},
	{	MCPhyScap_NodeJ,	1,	PG_SERIESCOMPENSATOR_CONNECTIVITYNODEJ,	},
	{	MCPhyScap_Rerr,		1,	PG_SERIESCOMPENSATOR_RI_RERR,			},
	{	MCPhyScap_Trep,		1,	PG_SERIESCOMPENSATOR_RI_TREP,			},
	{	MCPhyScap_Rchk,		1,	PG_SERIESCOMPENSATOR_RI_RCHK,			},
	{	MCPhyScap_Tchk,		1,	PG_SERIESCOMPENSATOR_RI_TCHK,			},
	{	MCPhyScap_Topr,		1,	PG_SERIESCOMPENSATOR_RI_TFLOC,			},
	{	MCPhyScap_Invest,	1,	PG_SERIESCOMPENSATOR_EI_INVEST,			},
};
typedef	struct _MCRPhyScap
{
	std::string		strSub;
	std::string		strVolt;
	std::string		strName;
	std::string		strNodeI;
	std::string		strNodeJ;

	double			fRerr;	//	��/��̨.��
	double			fTrep;	//	Сʱ/��
	double			fRchk;	//	��/��̨.��
	double			fTchk;	//	Сʱ/��
	double			fTopr;

	double			fInvest;	//	�豸���	��Ԫ/̨

	int				nNodeI;
	int				nNodeJ;
	unsigned char	bSourceI;
	unsigned char	bSourceJ;

	double			ro_RContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_UContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_ENSContribution;	//	�豸��ϵͳָ��Ĺ��׶�
}	tagMCRPhyScap;

enum	MCDataEnum_PhyBreaker
{
	MCPhyBreaker_Sub = 0,
	MCPhyBreaker_Volt,
	MCPhyBreaker_Name,
	MCPhyBreaker_NodeI,
	MCPhyBreaker_NodeJ,
	MCPhyBreaker_CTLoc,
	MCPhyBreaker_Type,
	MCPhyBreaker_Status,
	MCPhyBreaker_Rerr,
	MCPhyBreaker_Trep,
	MCPhyBreaker_Rchk,
	MCPhyBreaker_Tchk,
	MCPhyBreaker_Topr,
	MCPhyBreaker_TSwitch,
	MCPhyBreaker_Invest,
	MCPhyBreaker_ChkBus,
};
static	tagMCRPhyField g_MCPhyBreakerField[]=
{
	{	MCPhyBreaker_Sub,		1,	PG_BREAKER_SUBSTATION,			},
	{	MCPhyBreaker_Volt,		1,	PG_BREAKER_VOLTAGELEVEL,		},
	{	MCPhyBreaker_Name,		1,	PG_BREAKER_NAME,				},
	{	MCPhyBreaker_NodeI,		1,	PG_BREAKER_CONNECTIVITYNODEI,	},
	{	MCPhyBreaker_NodeJ,		1,	PG_BREAKER_CONNECTIVITYNODEJ,	},
	{	MCPhyBreaker_CTLoc,		1,	PG_BREAKER_MCRCTLOC,			},
	{	MCPhyBreaker_Type,		1,	PG_BREAKER_INNERTYPE,			},
	{	MCPhyBreaker_Status,	1,	PG_BREAKER_STATUS,				},
	{	MCPhyBreaker_Rerr,		1,	PG_BREAKER_RI_RERR,				},
	{	MCPhyBreaker_Trep,		1,	PG_BREAKER_RI_TREP,				},
	{	MCPhyBreaker_Rchk,		1,	PG_BREAKER_RI_RCHK,				},
	{	MCPhyBreaker_Tchk,		1,	PG_BREAKER_RI_TCHK,				},
	{	MCPhyBreaker_Topr,		1,	PG_BREAKER_RI_TFLOC,			},
	{	MCPhyBreaker_TSwitch,	1,	PG_BREAKER_RI_TSWITCH,			},
	{	MCPhyBreaker_Invest,	1,	PG_BREAKER_EI_INVEST,			},
	{	MCPhyBreaker_ChkBus,	1,	PG_BREAKER_MCRCHKBUS,			},
};
typedef	struct _MCRPhyBreaker
{
	std::string		strSub;
	std::string		strVolt;
	std::string		strName;
	std::string		strNodeI;
	std::string		strNodeJ;
	unsigned char	nCTLoc;
	unsigned char	nType;
	unsigned char	nStatus;

	double			fRerr;		//	��/��̨.��
	double			fTrep;		//	Сʱ/��
	double			fRchk;		//	��/��̨.��
	double			fTchk;		//	Сʱ/��
	double			fTopr;		//	Сʱ/��
	double			fTSwitch;	//	Сʱ/��

	double			fInvest;	//	�豸���	��Ԫ/̨

	unsigned char	bChkBus;

	int				nNodeI;
	int				nNodeJ;
	unsigned char	bSourceI;
	unsigned char	bSourceJ;

	double			ro_RContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_UContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_ENSContribution;	//	�豸��ϵͳָ��Ĺ��׶�
}	tagMCRPhyBreaker;

enum	MCDataEnum_PhyDisconnector
{
	MCPhyDisconnector_Sub = 0,
	MCPhyDisconnector_Volt,
	MCPhyDisconnector_Name,
	MCPhyDisconnector_NodeI,
	MCPhyDisconnector_NodeJ,
	MCPhyDisconnector_Type,
	MCPhyDisconnector_Status,
	MCPhyDisconnector_Rerr,
	MCPhyDisconnector_Trep,
	MCPhyDisconnector_Rchk,
	MCPhyDisconnector_Tchk,
	MCPhyDisconnector_Topr,
	MCPhyDisconnector_TSwitch,
	MCPhyDisconnector_Invest,
	MCPhyDisconnector_ChkBus,
};
static	tagMCRPhyField g_MCPhyDisconnectorField[]=
{
	{	MCPhyDisconnector_Sub,		1,	PG_DISCONNECTOR_SUBSTATION,			},
	{	MCPhyDisconnector_Volt,		1,	PG_DISCONNECTOR_VOLTAGELEVEL,		},
	{	MCPhyDisconnector_Name,		1,	PG_DISCONNECTOR_NAME,				},
	{	MCPhyDisconnector_NodeI,	1,	PG_DISCONNECTOR_CONNECTIVITYNODEI,	},
	{	MCPhyDisconnector_NodeJ,	1,	PG_DISCONNECTOR_CONNECTIVITYNODEJ,	},
	{	MCPhyDisconnector_Type,		1,	PG_DISCONNECTOR_INNERTYPE,			},
	{	MCPhyDisconnector_Status,	1,	PG_DISCONNECTOR_STATUS,				},
	{	MCPhyDisconnector_Rerr,		1,	PG_DISCONNECTOR_RI_RERR,			},
	{	MCPhyDisconnector_Trep,		1,	PG_DISCONNECTOR_RI_TREP,			},
	{	MCPhyDisconnector_Rchk,		1,	PG_DISCONNECTOR_RI_RCHK,			},
	{	MCPhyDisconnector_Tchk,		1,	PG_DISCONNECTOR_RI_TCHK,			},
	{	MCPhyDisconnector_Topr,		1,	PG_DISCONNECTOR_RI_TFLOC,			},
	{	MCPhyDisconnector_TSwitch,	1,	PG_DISCONNECTOR_RI_TSWITCH,			},
	{	MCPhyDisconnector_Invest,	1,	PG_DISCONNECTOR_EI_INVEST,			},
	{	MCPhyDisconnector_ChkBus,	1,	PG_DISCONNECTOR_MCRCHKBUS,			},
};
typedef	struct _MCRPhyDisconnector
{
	std::string		strSub;
	std::string		strVolt;
	std::string		strName;
	std::string		strNodeI;
	std::string		strNodeJ;
	unsigned char	nType;
	unsigned char	nStatus;

	double			fRerr;		//	��/��̨.��
	double			fTrep;		//	Сʱ/��
	double			fRchk;		//	��/��̨.��
	double			fTchk;		//	Сʱ/��
	double			fTopr;		//	Сʱ/��
	double			fTSwitch;	//	Сʱ/��

	double			fInvest;	//	�豸���	��Ԫ/̨

	unsigned char	bChkBus;

	int				nNodeI;
	int				nNodeJ;
	unsigned char	bSourceI;
	unsigned char	bSourceJ;

	double			ro_RContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_UContribution;	//	�豸��ϵͳָ��Ĺ��׶�
	double			ro_ENSContribution;	//	�豸��ϵͳָ��Ĺ��׶�
}	tagMCRPhyDisconnector;

typedef	struct _MCRPhyNode
{
	short				nParentType;
	std::string			strParentName;
	std::string			strName;
	std::string			strVolt;
	std::vector<int>	nLineArray;
	std::vector<int>	nTranArray;
	std::vector<int>	nScapArray;
	std::vector<int>	nBreakerArray;
	std::vector<int>	nDisconnectorArray;
	std::vector<int>	nBusArray;
	short				nNodeType;
	unsigned char		bUnproc;
	unsigned char		bBypass;
}	tagMCRPhyNode;

//////////////////////////////////////////////////////////////////////////
//	ϵͳ����ͳ�Ƹ��ɣ����ڷ�����ͳ��
typedef	struct	_MCRPhySystem
{
	//	����
	double	fEconomyRecip;				//	������
	double	fEconomyPrice;				//	�۵�۸�
	double	fEconomyLifeTime;			//	��������
	double	fEconomyPowerFactor;		//	��������
	double	fEconomyEValueRatio;		//	�����

	//	�ɿ������
	short	nPerturb;

	double	fAifi;
	double	fAidi;
	double	fAsai;
	double	fEns;

	double	fFaultAifi;
	double	fFaultAidi;
	double	fFaultAsai;
	double	fFaultEns;

	double	fPlanAifi;
	double	fPlanAidi;
	double	fPlanAsai;
	double	fPlanEns;

	//	���������
	double	fEconomyInvest;
	double	fEconomyAnnualWorth;		//	����ֵ
	double	fEconomyLoss;		//	�ۺ���ʧ
	double	fEconomyFaultLoss;	//	������ʧ
	double	fEconomyTotal;		//	����ֵ+�ۺ���ʧ
	double	fEconomyFaultTotal;	//	����ֵ+������ʧ
}	tagMCRPhySystem;
//////////////////////////////////////////////////////////////////////////

typedef	struct	_MCRPhyAugLoad
{
	tagMCRPhyResult	sResult;
	double			fRCTime;
	unsigned char	nRCCase;
	std::vector<tagMCRPhyPath>		sMinPathArray;			//	��С·
	std::vector<tagMCRPhyFault1>	sFault1Array;			//	һ����С��
	std::vector<tagMCRPhyFault2>	sFault2Array;			//	������С��
	std::vector<tagMCRPhyFault3>	sFault3Array;			//	������С��
}	tagMCRPhyAugLoad;

typedef	struct	_MCRPhyAugGen
{
	tagMCRPhyResult	sResult;
	double			fRCTime;
	unsigned char	nRCCase;
	std::vector<tagMCRPhyPath>		sMinPathArray;			//	��С·
	std::vector<tagMCRPhyFault1>	sFault1Array;			//	һ����С��
	std::vector<tagMCRPhyFault2>	sFault2Array;			//	������С��
	std::vector<tagMCRPhyFault3>	sFault3Array;			//	������С��
}	tagMCRPhyAugGen;

typedef	struct	_MCREconomy_
{
	std::string	strVolt;
	double	fBusInvest;
	double	fBreakerInvest;
	double	fDisconnectorInvest;
	double	fScapInvest;
	double	fLineInvest;
	double	fTranInvest;
}	tagMCREconomy;

typedef	struct	_MCRParam_
{
	double	fBusRerr;
	double	fBusTrep;
	double	fBusRchk;
	double	fBusTchk;
	double	fBusTopr;

	double	fBreakerRerr;
	double	fBreakerTrep;
	double	fBreakerRchk;
	double	fBreakerTchk;
	double	fBreakerTopr;
	double	fBreakerTSwitch;
	unsigned char	bBreakerChkBus;

	double	fDisconnectorRerr;
	double	fDisconnectorTrep;
	double	fDisconnectorRchk;
	double	fDisconnectorTchk;
	double	fDisconnectorTopr;
	double	fDisconnectorTSwitch;
	unsigned char	bDisconnectorChkBus;

	double	fScapRerr;
	double	fScapTrep;
	double	fScapRchk;
	double	fScapTchk;
	double	fScapTopr;

	double	fLineRerr;
	double	fLineTrep;
	double	fLineRchk;
	double	fLineTchk;
	double	fLineTopr;

	double	fTranRerr;
	double	fTranTrep;
	double	fTranRchk;
	double	fTranTchk;
	double	fTranTopr;

	std::vector<tagMCREconomy>	sMCREconomy;
}	tagMCRParam;

typedef	struct	_MCRDevIndex_
{
	double	fLOR;
	double	fLOU;
	double	fLOD;
	double	fASAI;
	double	fFaultLOR;
	double	fFaultLOU;
	double	fFaultLOD;
	double	fFaultASAI;
	double	fPlanLOR;
	double	fPlanLOU;
	double	fPlanLOD;
	double	fPlanASAI;
	std::vector<tagMCRPhyFault1>	sFault1Array;			//	һ����С��
	std::vector<tagMCRPhyFault2>	sFault2Array;			//	������С��
	std::vector<tagMCRPhyFault3>	sFault3Array;			//	������С��
}	tagMCRDevIndex;
