#include "StdAfx.h"
#include "MCRPhyData.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

void CMCRPhyData::PrevReliabilityEvaluate()
{
	register int	i, j;

	InitializePhyAugLoad(&m_AugLoad);
	InitializePhyAugGen	(&m_AugGen);

	for	(i=0; i<(int)m_LineArray.size(); i++)
	{
		memset(&m_LineArray[i].sResult, 0, sizeof(tagMCRPhyResult));
		for (j=0; j<2*g_nConstMaxReliabilityPerturb+1; j++)
			memset(&m_LineArray[i].sPerturbResult[j], 0, sizeof(tagMCRPhyResult));

		m_LineArray[i].ro_RContribution=m_LineArray[i].ro_UContribution=m_LineArray[i].ro_ENSContribution=0;
		m_LineArray[i].sMinPathArray.clear();			//	��С·
		m_LineArray[i].sFault1Array.clear();			//	һ����С��
		m_LineArray[i].sFault2Array.clear();			//	������С��
		m_LineArray[i].sFault3Array.clear();			//	������С��
	}

	for	(i=0; i<(int)m_TranArray.size(); i++)
	{
		memset(&m_TranArray[i].sResult, 0, sizeof(tagMCRPhyResult));
		for (j=0; j<2*g_nConstMaxReliabilityPerturb+1; j++)
			memset(&m_TranArray[i].sPerturbResult[j], 0, sizeof(tagMCRPhyResult));

		m_TranArray[i].ro_RContribution=m_TranArray[i].ro_UContribution=m_TranArray[i].ro_ENSContribution=0;
		m_TranArray[i].sMinPathArray.clear();			//	��С·
		m_TranArray[i].sFault1Array.clear();			//	һ����С��
		m_TranArray[i].sFault2Array.clear();			//	������С��
		m_TranArray[i].sFault3Array.clear();			//	������С��
	}

	for	(i=0; i<(int)m_BusArray.size(); i++)
	{
		m_BusArray[i].ro_RContribution=m_BusArray[i].ro_UContribution=m_BusArray[i].ro_ENSContribution=0;
	}
	for	(i=0; i<(int)m_LineArray.size(); i++)
	{
		m_LineArray[i].ro_RContribution=m_LineArray[i].ro_UContribution=m_LineArray[i].ro_ENSContribution=0;
	}
	for	(i=0; i<(int)m_TranArray.size(); i++)
	{
		m_TranArray[i].ro_RContribution=m_TranArray[i].ro_UContribution=m_TranArray[i].ro_ENSContribution=0;
	}
	for	(i=0; i<(int)m_ScapArray.size(); i++)
	{
		m_ScapArray[i].ro_RContribution=m_ScapArray[i].ro_UContribution=m_ScapArray[i].ro_ENSContribution=0;
	}
	for	(i=0; i<(int)m_BreakerArray.size(); i++)
	{
		m_BreakerArray[i].ro_RContribution=m_BreakerArray[i].ro_UContribution=m_BreakerArray[i].ro_ENSContribution=0;
	}
	for	(i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		m_DisconnectorArray[i].ro_RContribution=m_DisconnectorArray[i].ro_UContribution=m_DisconnectorArray[i].ro_ENSContribution=0;
	}

	{
		m_System.nPerturb=0;
		m_System.fAifi=0;
		m_System.fAidi=0;
		m_System.fAsai=0;
		m_System.fEns=0;
		m_System.fFaultAifi=0;
		m_System.fFaultAidi=0;
		m_System.fFaultAsai=0;
		m_System.fFaultEns=0;
		m_System.fPlanAifi=0;
		m_System.fPlanAidi=0;
		m_System.fPlanAsai=0;
		m_System.fPlanEns=0;
	}
	for (i=0; i<2*g_nConstMaxReliabilityPerturb+1; i++)
		memset(&m_SystemPerturb[i], 0, sizeof(tagMCRPhyResult));

	InitilizeMCRDevIndex(&m_L1Index);
	InitilizeMCRDevIndex(&m_T1Index);
	InitilizeMCRDevIndex(&m_L2Index);
	InitilizeMCRDevIndex(&m_T2Index);
	InitilizeMCRDevIndex(&m_LTIndex);
	InitilizeMCRDevIndex(&m_SubIndex);
}

void CMCRPhyData::SaveMCReliabilityResult(const char* lpszFileName, double fRThreshold, double fUThreshold)
{
	register int	i;
	double			fT;
	int				nDev, nPath, nFault, nType, nComp;
	TiXmlElement	*pElement, *pSecElement, *pAttrElement;

	TiXmlDocument*		pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����
	TiXmlDeclaration*	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	TiXmlElement*	pRoot=new TiXmlElement("ReliabilityResult");
	pDocument->LinkEndChild(pRoot);

	//////////////////////////////////////////////////////////////////////////
	//	�ɿ�������ϵͳ�豸����
	pElement = new TiXmlElement("ReliabilityDevices");	//��С·
	pRoot->LinkEndChild(pElement);
	for (i=0; i<(int)m_BusArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Deivce");
		pElement->LinkEndChild(pSecElement);

		pSecElement->SetAttribute("Name", GetCompString(PG_BUSBARSECTION, i).c_str());
		pSecElement->SetAttribute("ID", GetCompID(PG_BUSBARSECTION, i));
	}
	for (i=0; i<(int)m_LineArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Deivce");
		pElement->LinkEndChild(pSecElement);

		pSecElement->SetAttribute("Name", GetCompString(PG_ACLINESEGMENT, i).c_str());
		pSecElement->SetAttribute("ID", GetCompID(PG_ACLINESEGMENT, i));
	}
	for (i=0; i<(int)m_TranArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Deivce");
		pElement->LinkEndChild(pSecElement);

		pSecElement->SetAttribute("Name", GetCompString(PG_TRANSFORMERWINDING, i).c_str());
		pSecElement->SetAttribute("ID", GetCompID(PG_TRANSFORMERWINDING, i));
	}
	for (i=0; i<(int)m_ScapArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Deivce");
		pElement->LinkEndChild(pSecElement);

		pSecElement->SetAttribute("Name", GetCompString(PG_SERIESCOMPENSATOR, i).c_str());
		pSecElement->SetAttribute("ID", GetCompID(PG_SERIESCOMPENSATOR, i));
	}
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Deivce");
		pElement->LinkEndChild(pSecElement);

		pSecElement->SetAttribute("Name", GetCompString(PG_BREAKER, i).c_str());
		pSecElement->SetAttribute("ID", GetCompID(PG_BREAKER, i));
	}
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Deivce");
		pElement->LinkEndChild(pSecElement);

		pSecElement->SetAttribute("Name", GetCompString(PG_DISCONNECTOR, i).c_str());
		pSecElement->SetAttribute("ID", GetCompID(PG_DISCONNECTOR, i));
	}

	//////////////////////////////////////////////////////////////////////////
	//	�ɿ�������ϵͳ������
	pElement = new TiXmlElement("SystemReliabilityResult");	//��С·
	pRoot->LinkEndChild(pElement);

	fT = (m_System.fAifi < FLT_MIN) ? 0 : m_System.fAidi/m_System.fAifi;
	addXmlElement(pElement, "Aidi",		m_System.fAidi);
	addXmlElement(pElement, "Aifi",		m_System.fAifi);
	addXmlElement(pElement, "Mid",		fT);
	addXmlElement(pElement, "Asai",		100*m_System.fAsai);
	addXmlElement(pElement, "Ens",		m_System.fEns);

	fT = (m_System.fFaultAifi < FLT_MIN) ? 0 : m_System.fFaultAidi/m_System.fFaultAifi;
	addXmlElement(pElement, "FAidi",	m_System.fFaultAidi);
	addXmlElement(pElement, "FAifi",	m_System.fFaultAifi);
	addXmlElement(pElement, "FMid",		fT);
	addXmlElement(pElement, "FAsai",	100*m_System.fFaultAsai);
	addXmlElement(pElement, "FEns",		m_System.fFaultEns);

	fT = (m_System.fPlanAifi < FLT_MIN) ? 0 : m_System.fPlanAidi/m_System.fPlanAifi;
	addXmlElement(pElement, "AAidi",	m_System.fPlanAidi);
	addXmlElement(pElement, "AAifi",	m_System.fPlanAifi);
	addXmlElement(pElement, "AMid",		fT);
	addXmlElement(pElement, "AAsai",	100*m_System.fPlanAsai);
	addXmlElement(pElement, "AEns",		m_System.fPlanEns);
 
	addXmlElement(pElement, "EconomyInvest",		m_System.fEconomyInvest);
	addXmlElement(pElement, "EconomyAnnualWorth",	m_System.fEconomyAnnualWorth);
	addXmlElement(pElement, "EconomyLoss",			m_System.fEconomyLoss);
	addXmlElement(pElement, "EconomyFaultLoss",		m_System.fEconomyFaultLoss);
	addXmlElement(pElement, "EconomyTotal",			m_System.fEconomyTotal);
	addXmlElement(pElement, "EconomyFaultTotal",	m_System.fEconomyFaultTotal);

	//////////////////////////////////////////////////////////////////////////
	//	�ɿ����������ɼ����������ɽ���ϲ����豸�С�
// 	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
// 	{
// 		if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Load)
// 			continue;
// 
// 		pElement = new TiXmlElement("EnergyConsumerReliabilityResult");
// 		pRoot->LinkEndChild(pElement);
// 
// 		addXmlElement(pElement, "Substation",	m_LineArray[nDev].strSubI.c_str());
// 		addXmlElement(pElement, "ID",			GetCompID(PG_ACLINESEGMENT, nDev));
// 		addXmlElement(pElement, "RCTime",		m_LineArray[nDev].fRCTime);
// 		addXmlElement(pElement, "RCCase",		m_LineArray[nDev].nRCCase);
// 		addXmlElement(pElement, "P",			m_LineArray[nDev].fPower);
// 		addXmlElement(pElement, "R",			m_LineArray[nDev].sResult.fR);
// 		addXmlElement(pElement, "U",			m_LineArray[nDev].sResult.fU);
// 		addXmlElement(pElement, "T",			m_LineArray[nDev].sResult.fT);
// 		addXmlElement(pElement, "FR",			m_LineArray[nDev].sResult.fFaultR);
// 		addXmlElement(pElement, "FU",			m_LineArray[nDev].sResult.fFaultU);
// 		addXmlElement(pElement, "FT",			m_LineArray[nDev].sResult.fFaultT);
// 		addXmlElement(pElement, "AR",			m_LineArray[nDev].sResult.fPlanR);
// 		addXmlElement(pElement, "AU",			m_LineArray[nDev].sResult.fPlanU);
// 		addXmlElement(pElement, "AT",			m_LineArray[nDev].sResult.fPlanT);
// 		addXmlElement(pElement, "Ens",			m_LineArray[nDev].sResult.fEns);
// 		addXmlElement(pElement, "FEns",			m_LineArray[nDev].sResult.fFaultEns);
// 		addXmlElement(pElement, "AEns",			m_LineArray[nDev].sResult.fPlanEns);
// 	}
// 	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
// 	{
// 		if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Load)
// 			continue;
// 
// 		pElement = new TiXmlElement("EnergyConsumerReliabilityResult");
// 		pRoot->LinkEndChild(pElement);
// 
// 		addXmlElement(pElement, "Substation",	m_TranArray[nDev].strSub.c_str());
// 		addXmlElement(pElement, "ID",			GetCompID(PG_TRANSFORMERWINDING, nDev));
// 		addXmlElement(pElement, "RCTime",		m_TranArray[nDev].fRCTime);
// 		addXmlElement(pElement, "RCCase",		m_TranArray[nDev].nRCCase);
// 		addXmlElement(pElement, "P",			m_TranArray[nDev].fPower);
// 		addXmlElement(pElement, "R",			m_TranArray[nDev].sResult.fR);
// 		addXmlElement(pElement, "U",			m_TranArray[nDev].sResult.fU);
// 		addXmlElement(pElement, "T",			m_TranArray[nDev].sResult.fT);
// 		addXmlElement(pElement, "FR",			m_TranArray[nDev].sResult.fFaultR);
// 		addXmlElement(pElement, "FU",			m_TranArray[nDev].sResult.fFaultU);
// 		addXmlElement(pElement, "FT",			m_TranArray[nDev].sResult.fFaultT);
// 		addXmlElement(pElement, "AR",			m_TranArray[nDev].sResult.fPlanR);
// 		addXmlElement(pElement, "AU",			m_TranArray[nDev].sResult.fPlanU);
// 		addXmlElement(pElement, "AT",			m_TranArray[nDev].sResult.fPlanT);
// 		addXmlElement(pElement, "Ens",			m_TranArray[nDev].sResult.fEns);
// 		addXmlElement(pElement, "FEns",			m_TranArray[nDev].sResult.fFaultEns);
// 		addXmlElement(pElement, "AEns",			m_TranArray[nDev].sResult.fPlanEns);
// 	}

	//////////////////////////////////////////////////////////////////////////
	//	�豸�ɿ��Լ�������
	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		pElement = new TiXmlElement("ACLineSegmentReliabilityResult");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Substation",			m_LineArray[nDev].strSubI.c_str());
		pElement->SetAttribute("ID",					GetCompID(PG_ACLINESEGMENT, nDev));
		pElement->SetDoubleAttribute("P",				m_LineArray[nDev].fPower);
		pElement->SetDoubleAttribute("R",				m_LineArray[nDev].sResult.fR);
		pElement->SetDoubleAttribute("U",				m_LineArray[nDev].sResult.fU);
		pElement->SetDoubleAttribute("T",				m_LineArray[nDev].sResult.fT);
		pElement->SetDoubleAttribute("FR",				m_LineArray[nDev].sResult.fFaultR);
		pElement->SetDoubleAttribute("FU",				m_LineArray[nDev].sResult.fFaultU);
		pElement->SetDoubleAttribute("FT",				m_LineArray[nDev].sResult.fFaultT);
		pElement->SetDoubleAttribute("AR",				m_LineArray[nDev].sResult.fPlanR);
		pElement->SetDoubleAttribute("AU",				m_LineArray[nDev].sResult.fPlanU);
		pElement->SetDoubleAttribute("AT",				m_LineArray[nDev].sResult.fPlanT);
		pElement->SetDoubleAttribute("Ens",				m_LineArray[nDev].sResult.fEns);
		pElement->SetDoubleAttribute("FEns",			m_LineArray[nDev].sResult.fFaultEns);
		pElement->SetDoubleAttribute("AEns",			m_LineArray[nDev].sResult.fPlanEns);
		pElement->SetDoubleAttribute("RCTime",			m_LineArray[nDev].fRCTime);
		pElement->SetAttribute("RCCase",				PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, m_LineArray[nDev].nRCCase));
		pElement->SetDoubleAttribute("RContribution",	m_LineArray[nDev].ro_RContribution);
		pElement->SetDoubleAttribute("UContribution",	m_LineArray[nDev].ro_UContribution);
		pElement->SetDoubleAttribute("ENSContribution",	m_LineArray[nDev].ro_ENSContribution);

		for (nPath=0; nPath<(int)m_LineArray[nDev].sMinPathArray.size(); nPath++)
		{
			if (m_LineArray[nDev].sMinPathArray[nPath].sCompArray.empty())
				continue;

			pSecElement = new TiXmlElement("MinimalPath");
			pElement->LinkEndChild(pSecElement);

			for (i=0; i<(int)m_LineArray[nDev].sMinPathArray[nPath].sCompArray.size(); i++)
			{
				pAttrElement = new TiXmlElement("Path");
				pSecElement->LinkEndChild(pAttrElement);

				nType = m_LineArray[nDev].sMinPathArray[nPath].sCompArray[i].nCompTyp;
				nComp = m_LineArray[nDev].sMinPathArray[nPath].sCompArray[i].nCompIdx;

				pAttrElement->SetAttribute("CompID", GetCompID(nType, nComp));
				switch (nType)
				{
				case	PG_ACLINESEGMENT:
					pAttrElement->SetDoubleAttribute("Rerr",	m_LineArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_LineArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_LineArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_LineArray[nComp].fTchk);
					break;
				case	PG_TRANSFORMERWINDING:
					pAttrElement->SetDoubleAttribute("Rerr",	m_TranArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_TranArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_TranArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_TranArray[nComp].fTchk);
					break;
				case	PG_BREAKER:
					pAttrElement->SetDoubleAttribute("Rerr",	m_BreakerArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_BreakerArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_BreakerArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_BreakerArray[nComp].fTchk);
					break;
				case	PG_DISCONNECTOR:
					pAttrElement->SetDoubleAttribute("Rerr",	m_DisconnectorArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_DisconnectorArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_DisconnectorArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_DisconnectorArray[nComp].fTchk);
					break;
				case	PG_SERIESCOMPENSATOR:
					pAttrElement->SetDoubleAttribute("Rerr",	m_ScapArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_ScapArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_ScapArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_ScapArray[nComp].fTchk);
					break;
				case	PG_BUSBARSECTION:
					pAttrElement->SetDoubleAttribute("Rerr",	m_BusArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_BusArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_BusArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_BusArray[nComp].fTchk);
					break;
				}
			}
		}

		for (nFault=0; nFault<(int)m_LineArray[nDev].sFault1Array.size(); nFault++)
		{
			if (m_LineArray[nDev].sFault1Array[nFault].fR < FLT_MIN && m_LineArray[nDev].sFault1Array[nFault].fT < FLT_MIN)
				continue;

			SaveMCReliabilityFault1(pElement, &m_LineArray[nDev].sFault1Array[nFault], fRThreshold, fUThreshold, 1);
		}

		for (nFault=0; nFault<(int)m_LineArray[nDev].sFault2Array.size(); nFault++)
		{
			if (m_LineArray[nDev].sFault2Array[nFault].fR < FLT_MIN && m_LineArray[nDev].sFault2Array[nFault].fT < FLT_MIN)
				continue;

			SaveMCReliabilityFault2(pElement, &m_LineArray[nDev].sFault2Array[nFault], fRThreshold, fUThreshold, 1);
		}

		for (nFault=0; nFault<(int)m_LineArray[nDev].sFault3Array.size(); nFault++)
		{
			if (m_LineArray[nDev].sFault3Array[nFault].fR < FLT_MIN && m_LineArray[nDev].sFault3Array[nFault].fT < FLT_MIN)
				continue;

			SaveMCReliabilityFault3(pElement, &m_LineArray[nDev].sFault3Array[nFault], fRThreshold, fUThreshold, 1);
		}
	}

	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		pElement = new TiXmlElement("TransformerWindingReliabilityResult");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Substation",			m_TranArray[nDev].strSub.c_str());
		pElement->SetAttribute("ID",					GetCompID(PG_TRANSFORMERWINDING, nDev));
		pElement->SetDoubleAttribute("P",				m_TranArray[nDev].fPower);
		pElement->SetDoubleAttribute("R",				m_TranArray[nDev].sResult.fR);
		pElement->SetDoubleAttribute("T",				m_TranArray[nDev].sResult.fT);
		pElement->SetDoubleAttribute("U",				m_TranArray[nDev].sResult.fU);
		pElement->SetDoubleAttribute("FR",				m_TranArray[nDev].sResult.fFaultR);
		pElement->SetDoubleAttribute("FT",				m_TranArray[nDev].sResult.fFaultT);
		pElement->SetDoubleAttribute("FU",				m_TranArray[nDev].sResult.fFaultU);
		pElement->SetDoubleAttribute("AR",				m_TranArray[nDev].sResult.fPlanR);
		pElement->SetDoubleAttribute("AT",				m_TranArray[nDev].sResult.fPlanT);
		pElement->SetDoubleAttribute("AU",				m_TranArray[nDev].sResult.fPlanU);
		pElement->SetDoubleAttribute("Ens",				m_TranArray[nDev].sResult.fEns);
		pElement->SetDoubleAttribute("FEns",			m_TranArray[nDev].sResult.fFaultEns);
		pElement->SetDoubleAttribute("AEns",			m_TranArray[nDev].sResult.fPlanEns);
		pElement->SetDoubleAttribute("RCTime",			m_TranArray[nDev].fRCTime);
		pElement->SetAttribute("RCCase",				PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, m_TranArray[nDev].nRCCase));
		pElement->SetDoubleAttribute("RContribution",	m_TranArray[nDev].ro_RContribution);
		pElement->SetDoubleAttribute("UContribution",	m_TranArray[nDev].ro_UContribution);
		pElement->SetDoubleAttribute("ENSContribution",	m_TranArray[nDev].ro_ENSContribution);

		for (nPath=0; nPath<(int)m_TranArray[nDev].sMinPathArray.size(); nPath++)
		{
			if (m_TranArray[nDev].sMinPathArray[nPath].sCompArray.empty())
				continue;

			pSecElement = new TiXmlElement("MinimalPath");
			pElement->LinkEndChild(pSecElement);

			for (i=0; i<(int)m_TranArray[nDev].sMinPathArray[nPath].sCompArray.size(); i++)
			{
				pAttrElement = new TiXmlElement("Path");
				pSecElement->LinkEndChild(pAttrElement);

				nType = m_TranArray[nDev].sMinPathArray[nPath].sCompArray[i].nCompTyp;
				nComp = m_TranArray[nDev].sMinPathArray[nPath].sCompArray[i].nCompIdx;

				pAttrElement->SetAttribute("CompID", GetCompID(nType, nComp));
				switch (nType)
				{
				case	PG_ACLINESEGMENT:
					pAttrElement->SetDoubleAttribute("Rerr",	m_LineArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_LineArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_LineArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_LineArray[nComp].fTchk);
					break;
				case	PG_TRANSFORMERWINDING:
					pAttrElement->SetDoubleAttribute("Rerr",	m_TranArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_TranArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_TranArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_TranArray[nComp].fTchk);
					break;
				case	PG_BREAKER:
					pAttrElement->SetDoubleAttribute("Rerr",	m_BreakerArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_BreakerArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_BreakerArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_BreakerArray[nComp].fTchk);
					break;
				case	PG_DISCONNECTOR:
					pAttrElement->SetDoubleAttribute("Rerr",	m_DisconnectorArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_DisconnectorArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_DisconnectorArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_DisconnectorArray[nComp].fTchk);
					break;
				case	PG_SERIESCOMPENSATOR:
					pAttrElement->SetDoubleAttribute("Rerr",	m_ScapArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_ScapArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_ScapArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_ScapArray[nComp].fTchk);
					break;
				case	PG_BUSBARSECTION:
					pAttrElement->SetDoubleAttribute("Rerr",	m_BusArray[nComp].fRerr);
					pAttrElement->SetDoubleAttribute("Trep",	m_BusArray[nComp].fTrep);
					pAttrElement->SetDoubleAttribute("Rchk",	m_BusArray[nComp].fRchk);
					pAttrElement->SetDoubleAttribute("Tchk",	m_BusArray[nComp].fTchk);
					break;
				}
			}
		}

		for (nFault=0; nFault<(int)m_TranArray[nDev].sFault1Array.size(); nFault++)
		{
			if (m_TranArray[nDev].sFault1Array[nFault].fR < FLT_MIN && m_TranArray[nDev].sFault1Array[nFault].fT < FLT_MIN)
				continue;

			SaveMCReliabilityFault1(pElement, &m_TranArray[nDev].sFault1Array[nFault], fRThreshold, fUThreshold, 1);
		}

		for (nFault=0; nFault<(int)m_TranArray[nDev].sFault2Array.size(); nFault++)
		{
			if (m_TranArray[nDev].sFault2Array[nFault].fR < FLT_MIN && m_TranArray[nDev].sFault2Array[nFault].fT < FLT_MIN)
				continue;

			SaveMCReliabilityFault2(pElement, &m_TranArray[nDev].sFault2Array[nFault], fRThreshold, fUThreshold, 1);
		}

		for (nFault=0; nFault<(int)m_TranArray[nDev].sFault3Array.size(); nFault++)
		{
			if (m_TranArray[nDev].sFault3Array[nFault].fR < FLT_MIN && m_TranArray[nDev].sFault3Array[nFault].fT < FLT_MIN)
				continue;

			SaveMCReliabilityFault3(pElement, &m_TranArray[nDev].sFault3Array[nFault], fRThreshold, fUThreshold, 1);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	�ɿ���ָ�꼰�����ģʽ

	//////////////////////////////////////////////////////////////////////////
	//	����
	pElement = new TiXmlElement("LineOneReliabilityIndex");
	pRoot->LinkEndChild(pElement);
	SaveMCReliabilityIndex(pElement, &m_L1Index, fRThreshold, fUThreshold);

	//////////////////////////////////////////////////////////////////////////
	//	����
	pElement = new TiXmlElement("TranOneReliabilityResult");
	pRoot->LinkEndChild(pElement);
	SaveMCReliabilityIndex(pElement, &m_T1Index, fRThreshold, fUThreshold);

	//////////////////////////////////////////////////////////////////////////
	//	����
	pElement = new TiXmlElement("LineTwoReliabilityResult");
	pRoot->LinkEndChild(pElement);
	SaveMCReliabilityIndex(pElement, &m_L2Index, fRThreshold, fUThreshold);

	//////////////////////////////////////////////////////////////////////////
	//	����
	pElement = new TiXmlElement("TranTwoReliabilityResult");
	pRoot->LinkEndChild(pElement);
	SaveMCReliabilityIndex(pElement, &m_T2Index, fRThreshold, fUThreshold);

	//////////////////////////////////////////////////////////////////////////
	//	�߱�
	pElement = new TiXmlElement("LineTranReliabilityResult");
	pRoot->LinkEndChild(pElement);
	SaveMCReliabilityIndex(pElement, &m_LTIndex, fRThreshold, fUThreshold);

	//////////////////////////////////////////////////////////////////////////
	//	ȫվ
	pElement = new TiXmlElement("SubstationReliabilityResult");
	pRoot->LinkEndChild(pElement);
	SaveMCReliabilityIndex(pElement, &m_SubIndex, fRThreshold, fUThreshold);

	pDocument->SaveFile(lpszFileName);
	pDocument->Clear();
	delete pDocument;
}

void CMCRPhyData::SaveMCReliabilityFault1(TiXmlElement* pParent, tagMCRPhyFault1* pFault, const double fRThreshold, const double fUThreshold, const unsigned char bOutArrange)
{
	int				nType, nComp;
	TiXmlElement	*pElement;

	if (pFault->fRContribution < 1 && pFault->fUContribution < 1)
	{
		if (pFault->fR < fRThreshold && pFault->fU < fUThreshold)
			return;
	}

	pElement = new TiXmlElement("FirstShortCut");
	pParent->LinkEndChild(pElement);

	pElement->SetAttribute("FType",	g_lpszCutType[pFault->nFType]);

	nType=pFault->sComp.nCompTyp;
	nComp=pFault->sComp.nCompIdx;
	pElement->SetAttribute("FComp1", GetCompID(nType, nComp));

	nType=pFault->sSwitchComp.nCompTyp;
	nComp=pFault->sSwitchComp.nCompIdx;
	if (nType > 0 && nComp > 0)
		pElement->SetAttribute("SwComp1", GetCompID(nType, nComp));

	pElement->SetDoubleAttribute("R",	pFault->fR);
	pElement->SetDoubleAttribute("T",	pFault->fT);
	pElement->SetDoubleAttribute("U",	pFault->fU);
	pElement->SetDoubleAttribute("FR",	pFault->fFaultR);
	pElement->SetDoubleAttribute("FT",	pFault->fFaultT);
	pElement->SetDoubleAttribute("FU",	pFault->fFaultU);
	if (bOutArrange)
	{
		pElement->SetDoubleAttribute("AR",	pFault->fPlanR);
		pElement->SetDoubleAttribute("AT",	pFault->fPlanT);
		pElement->SetDoubleAttribute("AU",	pFault->fPlanU);
	}

	pElement->SetDoubleAttribute("RContribution", pFault->fRContribution);
	pElement->SetDoubleAttribute("UContribution", pFault->fUContribution);

	//////////////////////////////////////////////////////////////////////////
	//	���������ʾ��Ϣ
	int		nAuxType, nAuxComp;
	std::string	strBuffer;
	char	szBuf[260];
	strBuffer.clear();

	nAuxType = pFault->sSwitchComp.nCompTyp;
	nAuxComp = pFault->sSwitchComp.nCompIdx;
	if (nAuxType > 0 && nAuxComp >= 0)	//	�л�
	{
		memset(szBuf, 0, 260);
		sprintf(szBuf, "�л�[%s]", GetCompString(nAuxType, nAuxComp).c_str());
		AppendString(strBuffer, szBuf);
	}

	for (nComp=0; nComp<3; nComp++)	//	����
	{
		nAuxType = pFault->sDegreeComp[nComp].nCompTyp;
		nAuxComp = pFault->sDegreeComp[nComp].nCompIdx;
		if (nAuxType > 0 && nAuxComp >= 0)
		{
			memset(szBuf, 0, 260);
			sprintf(szBuf, "����%d[%s]", nComp+1, GetCompString(nAuxType, nAuxComp).c_str());
			AppendString(strBuffer, szBuf);
		}
	}

	for (nComp=0; nComp<2; nComp++)	//	��ģ
	{
		nAuxType = pFault->sCommonBreaker[nComp].nCompTyp;
		nAuxComp = pFault->sCommonBreaker[nComp].nCompIdx;
		if (nAuxType > 0 && nAuxComp >= 0)
		{
			memset(szBuf, 0, 260);
			sprintf(szBuf, "��ģ%d[%s]", nComp+1, GetCompString(nAuxType, nAuxComp).c_str());
			AppendString(strBuffer, szBuf);
		}
	}
	pElement->SetAttribute("Aux", strBuffer.c_str());
}

void CMCRPhyData::SaveMCReliabilityFault2(TiXmlElement* pParent, tagMCRPhyFault2* pFault, const double fRThreshold, const double fUThreshold, const unsigned char bOutArrange)
{
	register int	i;
	int				nType, nComp;
	TiXmlElement	*pElement;
	char			szAttr[260];

	if (pFault->fRContribution < 1 && pFault->fUContribution < 1)
	{
		if (pFault->fR < fRThreshold && pFault->fU < fUThreshold)
			return;
	}

	pElement = new TiXmlElement("SecondShortCut");
	pParent->LinkEndChild(pElement);

	pElement->SetAttribute("FType",	g_lpszCutType[pFault->nFType]);

	for (i=0; i<2; i++)
	{
		nType=pFault->sComp[i].nCompTyp;
		nComp=pFault->sComp[i].nCompIdx;
		sprintf(szAttr, "FComp%d", i+1);
		pElement->SetAttribute(szAttr, GetCompID(nType, nComp));

		nType=pFault->sSwitchComp[i].nCompTyp;
		nComp=pFault->sSwitchComp[i].nCompIdx;
		if (nType > 0 && nComp > 0)
		{
			sprintf(szAttr, "SwComp%d", i+1);
			pElement->SetAttribute(szAttr,	GetCompID(nType, nComp));
		}
	}

	pElement->SetDoubleAttribute("R",  1000*pFault->fR);
	pElement->SetDoubleAttribute("T",		pFault->fT);
	pElement->SetDoubleAttribute("U",		pFault->fU);
	pElement->SetDoubleAttribute("FR", 1000*pFault->fFaultR);
	pElement->SetDoubleAttribute("FT",		pFault->fFaultT);
	pElement->SetDoubleAttribute("FU",		pFault->fFaultU);
	if (bOutArrange)
	{
		pElement->SetDoubleAttribute("AR", 1000*pFault->fPlanR);
		pElement->SetDoubleAttribute("AT",		pFault->fPlanT);
		pElement->SetDoubleAttribute("AU",		pFault->fPlanU);
	}

	pElement->SetDoubleAttribute("RContribution", pFault->fRContribution);
	pElement->SetDoubleAttribute("UContribution", pFault->fUContribution);

	//////////////////////////////////////////////////////////////////////////
	//	���������ʾ��Ϣ
	int		nAuxType, nAuxComp;
	std::string	strBuffer;
	char	szBuf[260];
	strBuffer.clear();

	nAuxType = pFault->sSwitchComp[0].nCompTyp;
	nAuxComp = pFault->sSwitchComp[0].nCompIdx;
	if (nAuxType > 0 && nAuxComp >= 0)
	{
		memset(szBuf, 0, 260);
		sprintf(szBuf, "�л�1[%s]", GetCompString(nAuxType, nAuxComp).c_str());
		AppendString(strBuffer, szBuf);
	}

	nAuxType = pFault->sSwitchComp[1].nCompTyp;
	nAuxComp = pFault->sSwitchComp[1].nCompIdx;
	if (nAuxType > 0 && nAuxComp >= 0)
	{
		memset(szBuf, 0, 260);
		sprintf(szBuf, "�л�2[%s]", GetCompString(nAuxType, nAuxComp).c_str());
		AppendString(strBuffer, szBuf);
	}

	for (nComp=0; nComp<3; nComp++)	//	����
	{
		nAuxType = pFault->sDegreeComp[nComp].nCompTyp;
		nAuxComp = pFault->sDegreeComp[nComp].nCompIdx;
		if (nAuxType > 0 && nAuxComp >= 0)
		{
			memset(szBuf, 0, 260);
			sprintf(szBuf, "����%d[%s]", nComp+1, GetCompString(nAuxType, nAuxComp).c_str());
			AppendString(strBuffer, szBuf);
		}
	}

	for (nComp=0; nComp<2; nComp++)	//	��ģ
	{
		nAuxType = pFault->sCommonBreaker[nComp].nCompTyp;
		nAuxComp = pFault->sCommonBreaker[nComp].nCompIdx;
		if (nAuxType > 0 && nAuxComp >= 0)
		{
			memset(szBuf, 0, 260);
			sprintf(szBuf, "��ģ%d[%s]", nComp+1, GetCompString(nAuxType, nAuxComp));
			AppendString(strBuffer, szBuf);
		}
	}
	pElement->SetAttribute("Aux", strBuffer.c_str());
}

void CMCRPhyData::SaveMCReliabilityFault3(TiXmlElement* pParent, tagMCRPhyFault3* pFault, const double fRThreshold, const double fUThreshold, const unsigned char bOutArrange)
{
	register int	i;
	int				nType, nComp;
	TiXmlElement	*pElement;
	char			szAttr[260];

	if (pFault->fRContribution < 1 && pFault->fUContribution < 1)
	{
		if (pFault->fR < fRThreshold && pFault->fU < fUThreshold)
			return;
	}

	pElement = new TiXmlElement("ThirdShortCut");
	pParent->LinkEndChild(pElement);

	pElement->SetAttribute("FType",	g_lpszCutType[pFault->nFType]);

	for (i=0; i<3; i++)
	{
		nType=pFault->sComp[i].nCompTyp;
		nComp=pFault->sComp[i].nCompIdx;
		sprintf(szAttr, "FComp%d", i+1);
		pElement->SetAttribute(szAttr, GetCompID(nType, nComp));

		nType=pFault->sSwitchComp[i].nCompTyp;
		nComp=pFault->sSwitchComp[i].nCompIdx;
		if (nType > 0 && nComp > 0)
		{
			sprintf(szAttr, "SwComp%d", i+1);
			pElement->SetAttribute(szAttr,	GetCompID(nType, nComp));
		}
	}

	pElement->SetDoubleAttribute("R", 1000*1000*pFault->fR);
	pElement->SetDoubleAttribute("T",			pFault->fT);
	pElement->SetDoubleAttribute("U",			pFault->fU);
	pElement->SetDoubleAttribute("FR",1000*1000*pFault->fFaultR);
	pElement->SetDoubleAttribute("FT",			pFault->fFaultT);
	pElement->SetDoubleAttribute("FU",			pFault->fFaultU);
	if (bOutArrange)
	{
		pElement->SetDoubleAttribute("AR",1000*1000*pFault->fPlanR);
		pElement->SetDoubleAttribute("AT",			pFault->fPlanT);
		pElement->SetDoubleAttribute("AU",			pFault->fPlanU);
	}

	pElement->SetDoubleAttribute("RContribution", pFault->fRContribution);
	pElement->SetDoubleAttribute("UContribution", pFault->fUContribution);

	//////////////////////////////////////////////////////////////////////////
	//	���������ʾ��Ϣ
	int		nAuxType, nAuxComp;
	std::string	strBuffer;
	char	szBuf[260];
	strBuffer.clear();

	nAuxType = pFault->sSwitchComp[0].nCompTyp;
	nAuxComp = pFault->sSwitchComp[0].nCompIdx;
	if (nAuxType > 0 && nAuxComp >= 0)
	{
		memset(szBuf, 0, 260);
		sprintf(szBuf, "�л�1[%s]", GetCompString(nAuxType, nAuxComp).c_str());
		AppendString(strBuffer, szBuf);
	}

	nAuxType = pFault->sSwitchComp[1].nCompTyp;
	nAuxComp = pFault->sSwitchComp[1].nCompIdx;
	if (nAuxType > 0 && nAuxComp >= 0)
	{
		memset(szBuf, 0, 260);
		sprintf(szBuf, "�л�2[%s]", GetCompString(nAuxType, nAuxComp).c_str());
		AppendString(strBuffer, szBuf);
	}

	nAuxType = pFault->sSwitchComp[2].nCompTyp;
	nAuxComp = pFault->sSwitchComp[2].nCompIdx;
	if (nAuxType > 0 && nAuxComp >= 0)
	{
		memset(szBuf, 0, 260);
		sprintf(szBuf, "�л�3[%s]", GetCompString(nAuxType, nAuxComp).c_str());
		AppendString(strBuffer, szBuf);
	}
	pElement->SetAttribute("Aux", strBuffer.c_str());
}

void CMCRPhyData::SaveMCReliabilityIndex(TiXmlElement* pElement, tagMCRDevIndex* pIndex, double fRThreshold, double fUThreshold)
{
	int				nFault;

	pElement->SetDoubleAttribute("LOR",		pIndex->fLOR);
	pElement->SetDoubleAttribute("LOU",		pIndex->fLOU);
	pElement->SetDoubleAttribute("LOD",		pIndex->fLOD);
	pElement->SetDoubleAttribute("ASAI",	100*pIndex->fASAI);
	pElement->SetDoubleAttribute("FLOR",	pIndex->fFaultLOR);
	pElement->SetDoubleAttribute("FLOU",	pIndex->fFaultLOU);
	pElement->SetDoubleAttribute("FLOD",	pIndex->fFaultLOD);
	pElement->SetDoubleAttribute("FASAI",	100*pIndex->fFaultASAI);
	pElement->SetDoubleAttribute("ALOR",	pIndex->fPlanLOR);
	pElement->SetDoubleAttribute("ALOU",	pIndex->fPlanLOU);
	pElement->SetDoubleAttribute("ALOD",	pIndex->fPlanLOD);
	pElement->SetDoubleAttribute("AASAI",	100*pIndex->fPlanASAI);

	for (nFault=0; nFault<(int)pIndex->sFault1Array.size(); nFault++)
	{
		if (pIndex->sFault1Array[nFault].fR < FLT_MIN && pIndex->sFault1Array[nFault].fT < FLT_MIN)
			continue;
		if (pIndex->sFault1Array[nFault].fRContribution < 1 && pIndex->sFault1Array[nFault].fUContribution < 1)
		{
			if (pIndex->sFault1Array[nFault].fR < fRThreshold && pIndex->sFault1Array[nFault].fU < fUThreshold)
				continue;
		}

		SaveMCReliabilityFault1(pElement, &pIndex->sFault1Array[nFault], fRThreshold, fUThreshold, 0);
	}

	for (nFault=0; nFault<(int)pIndex->sFault2Array.size(); nFault++)
	{
		if (pIndex->sFault2Array[nFault].fR < FLT_MIN && pIndex->sFault2Array[nFault].fT < FLT_MIN)
			continue;
		if (pIndex->sFault2Array[nFault].fRContribution < 1 && pIndex->sFault2Array[nFault].fUContribution < 1)
		{
			if (pIndex->sFault2Array[nFault].fR < fRThreshold && pIndex->sFault2Array[nFault].fU < fUThreshold)
				continue;
		}

		SaveMCReliabilityFault2(pElement, &pIndex->sFault2Array[nFault], fRThreshold, fUThreshold, 0);
	}

	for (nFault=0; nFault<(int)pIndex->sFault3Array.size(); nFault++)
	{
		if (pIndex->sFault3Array[nFault].fR < FLT_MIN && pIndex->sFault3Array[nFault].fT < FLT_MIN)
			continue;
		if (pIndex->sFault3Array[nFault].fRContribution < 1 && pIndex->sFault3Array[nFault].fUContribution < 1)
		{
			if (pIndex->sFault3Array[nFault].fR < fRThreshold && pIndex->sFault3Array[nFault].fU < fUThreshold)
				continue;
		}

		SaveMCReliabilityFault3(pElement, &pIndex->sFault3Array[nFault], fRThreshold, fUThreshold, 0);
	}
}

void CMCRPhyData::SaveMCReliabilityPerturbResult(const char* lpszFileName)
{
	register int	i;
	double			fT;
	TiXmlElement	*pElement, *pSubElement;

	if (g_MCRPerturb.m_Param.nPerturbNum <= 0)
		return;
	int		nPerturbNum = (g_MCRPerturb.m_Param.nPerturbType == 0) ?
		((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb)+1 :
		2*((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb)+1;

	TiXmlDocument*		pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����
	TiXmlDeclaration*	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	TiXmlElement*	pRoot=new TiXmlElement("ReliabilityPerturbResult");
	pDocument->LinkEndChild(pRoot);

	//////////////////////////////////////////////////////////////////////////
	//	�ɿ�������ϵͳ������

	pElement = new TiXmlElement("RelibilityPerturbParam");
	pRoot->LinkEndChild(pElement);

	pSubElement = new TiXmlElement("Base");
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetAttribute("Type",	g_MCRPerturb.m_Param.nPerturbType);
	pSubElement->SetAttribute("Num",	g_MCRPerturb.m_Param.nPerturbNum);

	//////////////////////////////////////////////////////////////////////////
	//	Bus
	pSubElement = new TiXmlElement(PGGetTableName(PG_BUSBARSECTION));
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetDoubleAttribute("Rerr",	g_MCRPerturb.m_Param.fBusRerrPerturb);
	pSubElement->SetDoubleAttribute("Trep",	g_MCRPerturb.m_Param.fBusTrepPerturb);
	pSubElement->SetDoubleAttribute("Rchk",	g_MCRPerturb.m_Param.fBusRchkPerturb);
	pSubElement->SetDoubleAttribute("Tchk",	g_MCRPerturb.m_Param.fBusTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Line
	pSubElement = new TiXmlElement(PGGetTableName(PG_ACLINESEGMENT));
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetDoubleAttribute("Rerr",	g_MCRPerturb.m_Param.fLineRerrPerturb);
	pSubElement->SetDoubleAttribute("Trep",	g_MCRPerturb.m_Param.fLineTrepPerturb);
	pSubElement->SetDoubleAttribute("Rchk",	g_MCRPerturb.m_Param.fLineRchkPerturb);
	pSubElement->SetDoubleAttribute("Tchk",	g_MCRPerturb.m_Param.fLineTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Tran
	pSubElement = new TiXmlElement(PGGetTableName(PG_TRANSFORMERWINDING));
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetDoubleAttribute("Rerr",	g_MCRPerturb.m_Param.fTranRerrPerturb);
	pSubElement->SetDoubleAttribute("Trep",	g_MCRPerturb.m_Param.fTranTrepPerturb);
	pSubElement->SetDoubleAttribute("Rchk",	g_MCRPerturb.m_Param.fTranRchkPerturb);
	pSubElement->SetDoubleAttribute("Tchk",	g_MCRPerturb.m_Param.fTranTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Scap
	pSubElement = new TiXmlElement(PGGetTableName(PG_SERIESCOMPENSATOR));
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetDoubleAttribute("Rerr",	g_MCRPerturb.m_Param.fScapRerrPerturb);
	pSubElement->SetDoubleAttribute("Trep",	g_MCRPerturb.m_Param.fScapTrepPerturb);
	pSubElement->SetDoubleAttribute("Rchk",	g_MCRPerturb.m_Param.fScapRchkPerturb);
	pSubElement->SetDoubleAttribute("Tchk",	g_MCRPerturb.m_Param.fScapTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Breaker
	pSubElement = new TiXmlElement(PGGetTableName(PG_BREAKER));
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetDoubleAttribute("Rerr",	g_MCRPerturb.m_Param.fBreakerRerrPerturb);
	pSubElement->SetDoubleAttribute("Trep",	g_MCRPerturb.m_Param.fBreakerTrepPerturb);
	pSubElement->SetDoubleAttribute("Rchk",	g_MCRPerturb.m_Param.fBreakerRchkPerturb);
	pSubElement->SetDoubleAttribute("Tchk",	g_MCRPerturb.m_Param.fBreakerTchkPerturb);
	pSubElement->SetDoubleAttribute("Topr",	g_MCRPerturb.m_Param.fBreakerToprPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Disconnector
	pSubElement = new TiXmlElement(PGGetTableName(PG_DISCONNECTOR));
	pElement->LinkEndChild(pSubElement);

	pSubElement->SetDoubleAttribute("Rerr",	g_MCRPerturb.m_Param.fDisconnectorRerrPerturb);
	pSubElement->SetDoubleAttribute("Trep",	g_MCRPerturb.m_Param.fDisconnectorTrepPerturb);
	pSubElement->SetDoubleAttribute("Rchk",	g_MCRPerturb.m_Param.fDisconnectorRchkPerturb);
	pSubElement->SetDoubleAttribute("Tchk",	g_MCRPerturb.m_Param.fDisconnectorTchkPerturb);
	pSubElement->SetDoubleAttribute("Topr",	g_MCRPerturb.m_Param.fDisconnectorToprPerturb);
	pSubElement->SetDoubleAttribute("TSwitch",	g_MCRPerturb.m_Param.fDisconnectorTSwitchPerturb);

	for (i=0; i<nPerturbNum; i++)
	{
		pElement = new TiXmlElement("SystemPerturbResult");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Perturb",		i);

		fT = (m_SystemPerturb[i].fAifi < FLT_MIN) ? 0 : m_SystemPerturb[i].fAidi/m_SystemPerturb[i].fAifi;
		pElement->SetDoubleAttribute("Aidi",	m_SystemPerturb[i].fAidi);
		pElement->SetDoubleAttribute("Aifi",	m_SystemPerturb[i].fAifi);
		pElement->SetDoubleAttribute("Mid",		fT);
		pElement->SetDoubleAttribute("Asai",	100*m_SystemPerturb[i].fAsai);
		pElement->SetDoubleAttribute("Ens",		m_SystemPerturb[i].fEns);

		fT = (m_SystemPerturb[i].fFaultAifi < FLT_MIN) ? 0 : m_SystemPerturb[i].fFaultAidi/m_SystemPerturb[i].fFaultAifi;
		pElement->SetDoubleAttribute("FAidi",	m_SystemPerturb[i].fFaultAidi);
		pElement->SetDoubleAttribute("FAifi",	m_SystemPerturb[i].fFaultAifi);
		pElement->SetDoubleAttribute("FMid",	fT);
		pElement->SetDoubleAttribute("FAsai",	100*m_SystemPerturb[i].fFaultAsai);
		pElement->SetDoubleAttribute("FEns",	m_SystemPerturb[i].fFaultEns);

		fT = (m_SystemPerturb[i].fPlanAifi < FLT_MIN) ? 0 : m_SystemPerturb[i].fPlanAidi/m_SystemPerturb[i].fPlanAifi;
		pElement->SetDoubleAttribute("AAidi",	m_SystemPerturb[i].fPlanAidi);
		pElement->SetDoubleAttribute("AAifi",	m_SystemPerturb[i].fPlanAifi);
		pElement->SetDoubleAttribute("AMid",	fT);
		pElement->SetDoubleAttribute("AAsai",	100*m_SystemPerturb[i].fPlanAsai);
		pElement->SetDoubleAttribute("AEns",	m_SystemPerturb[i].fPlanEns);
	}

	pDocument->SaveFile(lpszFileName);
	pDocument->Clear();
	delete pDocument;
}
