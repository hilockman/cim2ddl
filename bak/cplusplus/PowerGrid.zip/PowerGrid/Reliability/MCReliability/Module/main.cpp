#include <io.h>
#include <vector>
using namespace std;
#include <crtdbg.h>
#include <process.h>
#include <float.h>

#include "../../../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../lib/PGMemDB.lib")
#else					 
#	pragma comment(lib, "../../../../lib_x64/PGMemDB.lib")
#endif

#include "../../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif

#include "../MCRAlgorithm.h"

#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="MCReliabilityModule.log";
extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	unsigned __stdcall  MCREstimateConThreaad(void* lParam);

CMCRPhyData		g_MCRPhyData;
CMCRAlgorithm	g_MCRAlgorithm;
CMCRPerturb		g_MCRPerturb;

int main(int argc, char** argv, char** envp)
{
	int				nAnaMode;
	unsigned char	bFault1Plan;	//	������һ�׸�Ԥ����
	unsigned char	bExCommon;		//	�����ǹ�ģ
	unsigned char	bExSwitch;		//	�������л�
	unsigned char	bBreakerFaultFailure;	//	���Ϲ���ʧЧ����
	double			fFmodeRThreshold, fFmodeUThreshold;
	char			szInputFileName[260];
	char			szModelFileName[260];
	char			szOutPutFileName[260];
	char			szPerturbFileName[260];
	clock_t	dBeg, dEnd;
	int		nDur;

	int				nLifeTime;
	double			fEValueRatio, fEPrice, fRecip, fPowerFactor;

	ClearLog(g_lpszLogFile);

	bFault1Plan = bExCommon = bExSwitch = 0;
	bBreakerFaultFailure = 1;
	fFmodeRThreshold = fFmodeUThreshold = 0;
	nLifeTime = 25;
	fEValueRatio = 4;
	fEPrice = 0.5;
	fRecip = 12;
	fPowerFactor = 0.93;

	memset(szPerturbFileName, 0, 260);

	int	nEle=1;
	if (argc > nEle)	nAnaMode = atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	bFault1Plan=atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	bExCommon=atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	bExSwitch=atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	bBreakerFaultFailure=atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	fFmodeRThreshold=atof(argv[nEle++]);	else	return 0;
	if (argc > nEle)	fFmodeUThreshold=atof(argv[nEle++]);	else	return 0;

	if (argc > nEle)	nLifeTime=atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	fEPrice=atof(argv[nEle++]);				else	return 0;
	if (argc > nEle)	fRecip=atof(argv[nEle++]);				else	return 0;
	if (argc > nEle)	fEValueRatio=atof(argv[nEle++]);		else	return 0;
	if (argc > nEle)	fPowerFactor=atof(argv[nEle++]);		else	return 0;

	if (argc > nEle)	strcpy(szInputFileName, argv[nEle++]);	else	return 0;
	if (argc > nEle)	strcpy(szModelFileName, argv[nEle++]);	else	return 0;
	if (argc > nEle)	strcpy(szOutPutFileName, argv[nEle++]);	else	return 0;
	if (argc > nEle)	strcpy(szPerturbFileName, argv[nEle++]);

	Log(g_lpszLogFile,  "CutPlan = %d\nInput = %s\nModel=%s\nResult=%s \n", bFault1Plan, szInputFileName, szModelFileName, szOutPutFileName);

	if (access(szInputFileName, 0) != 0)
		return 0;

	if (nAnaMode != 0)
	{
		if (access(szPerturbFileName, 0) != 0)
			return 0;
	}

	dBeg=clock();
	SYSTEM_INFO sysInfo;
	::GetSystemInfo(&sysInfo);
	int		nThreadNum = (int)sysInfo.dwNumberOfProcessors;

	if (!g_MCRPhyData.ReadPhyFile(szInputFileName))
	{
		Log(g_lpszLogFile,  "װ������ģ�ʹ���ģ��=%s\n", szInputFileName);
		return 0;
	}

	if (nAnaMode == 0)
	{
		g_MCRPhyData.PrevReliabilityEvaluate();
		g_MCRAlgorithm.ReadData(&g_MCRPhyData, szModelFileName);

		{
			unsigned int	nChildThreadID;
			tagMCRThreadInfo*	pInfo=(tagMCRThreadInfo*)malloc(sizeof(tagMCRThreadInfo));
			pInfo->nParentThreadID = GetCurrentThreadId();
			pInfo->nThreadNum = nThreadNum;

			pInfo->bFault1Plan =		bFault1Plan;	//	������һ�׸�Ԥ����
			pInfo->bExCommon =			bExCommon;		//	�����ǹ�ģ
			pInfo->bExSwitch =			bExSwitch;		//	�������л�
			pInfo->bBreakerFaultFailure =		bBreakerFaultFailure;	//	���Ϲ���ʧЧ����
			pInfo->fFmodeRThreshold =	fFmodeRThreshold;
			pInfo->fFmodeUThreshold =	fFmodeUThreshold;
			pInfo->nLifeTime =			nLifeTime;
			pInfo->fEValueRatio =		fEValueRatio;
			pInfo->fEPrice =			fEPrice;
			pInfo->fRecip =				fRecip;
			pInfo->fPowerFactor =		fPowerFactor;

			strcpy(pInfo->szResultXmlFile, szOutPutFileName);
			HANDLE hControl = (HANDLE)_beginthreadex(NULL, 0, MCREstimateConThreaad, (void*)pInfo, 0, &nChildThreadID);
			DWORD dwRet=WaitForSingleObject(hControl, INFINITE);

			if (dwRet == WAIT_OBJECT_0)
				Log(g_lpszLogFile, "        �����߿ɿ�����������������\n");
			else
				Log(g_lpszLogFile, "        �����߿ɿ�������������̴��� RetCode = %d\n", dwRet);
			if (hControl != INVALID_HANDLE_VALUE)
				CloseHandle(hControl);
		}
// 		g_MCRAlgorithm.CalculateAllLoadReliablity(bFault1Plan, bExCommon, bExSwitch, bBreakerFaultFailure);
// 		g_MCRAlgorithm.CalculateAllGenReliablity(bFault1Plan, bExCommon, bExSwitch, bBreakerFaultFailure);
// 		g_MCRAlgorithm.CalculateAugLoadReliablity(&g_MCRPhyData, bFault1Plan, bExCommon, bExSwitch, bBreakerFaultFailure);
// 		g_MCRAlgorithm.CalculateAugGenReliablity(&g_MCRPhyData, bFault1Plan, bExCommon, bExSwitch, bBreakerFaultFailure);

// 		dEnd=clock();
// 		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 		PrintMessage("�ɿ��Թ���ģʽ������ɣ���ʱ %d ����", nDur);
// 
// 		g_MCRPhyData.MCRSysIndex();
// 		g_MCRPhyData.MCRDevIndex();
// 		g_MCRPhyData.MCREconomy(nLifeTime, fEPrice, fRecip, fEValueRatio, fPowerFactor);
// 
// 		dEnd=clock();
// 		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 		PrintMessage("�ɿ���ָ�������ɣ���ʱ %d ����", nDur);
// 
// 		g_MCRPhyData.SaveMCReliabilityResult(szOutPutFileName, fFmodeRThreshold, fFmodeUThreshold);
// 		dEnd=clock();
// 		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 		PrintMessage("�ɿ��Լ����������ɣ���ʱ %d ����", nDur);
	}
	else
	{
		if (!g_MCRPerturb.ReadParamFile(szPerturbFileName))
		{
			PrintMessage("�ɿ����㶯��������");
			return 0;
		}

		g_MCRPhyData.PrevReliabilityEvaluate();
		g_MCRAlgorithm.ReadData(&g_MCRPhyData, szModelFileName);
		g_MCRAlgorithm.CalculateAllLoadReliablity(bFault1Plan, bExCommon, bExSwitch, bBreakerFaultFailure);
		g_MCRAlgorithm.CalculateAllGenReliablity(bFault1Plan, bExCommon, bExSwitch, bBreakerFaultFailure);

		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("�ɿ��Թ���ģʽ������ɣ���ʱ %d ����", nDur);

		g_MCRPhyData.MCRSysIndex();
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("�ɿ���ָ�������ɣ���ʱ %d ����", nDur);

		g_MCRPhyData.SaveMCReliabilityPerturbResult(szOutPutFileName);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("�ɿ���ָ�������ɣ���ʱ %d ����", nDur);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("������ɣ���ʱ %d ����", nDur);
}

void PrintMessage(const char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];

	vsprintf(szMesg, pformat, args);
	vfprintf(stdout, pformat, args);
	fprintf(stdout, "\n");

	Log(g_lpszLogFile, szMesg);

	va_end(args);
}
