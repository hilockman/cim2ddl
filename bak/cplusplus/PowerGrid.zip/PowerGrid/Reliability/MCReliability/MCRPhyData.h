#pragma once

#include "MCRPerturb.h"
#include "MCRPhyDataDefine.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"
#include "../../../Common/VoltageLevel.h"
using namespace _VoltageLevel;

#define	BypassRoute_No	0
#define	BypassRoute_Yes	1

#define	InrangeBusbar_No	0
#define	InrangeBusbar_Yes	1

#define	InrangeBreaker_No	0
#define	InrangeBreaker_Yes	1

class CMCRPhyData
{
public:
	CMCRPhyData(void);
	~CMCRPhyData(void);

public:
	std::string							m_strMCDataFileName;
	unsigned char						m_bFault1Plan;

	std::vector<tagMCRPhyBus>			m_BusArray;
	std::vector<tagMCRPhyLine>			m_LineArray;
	std::vector<tagMCRPhyTran>			m_TranArray;
	std::vector<tagMCRPhyScap>			m_ScapArray;
	std::vector<tagMCRPhyBreaker>		m_BreakerArray;
	std::vector<tagMCRPhyDisconnector>	m_DisconnectorArray;

	std::vector<tagMCRPhyNode>			m_NodeArray;

	tagMCRParam							m_MCRParam;

	//////////////////////////////////////////////////////////////////////////
	//	���
	tagMCRPhySystem						m_System;
	tagMCRPhyAugLoad					m_AugLoad;
	tagMCRPhyAugGen						m_AugGen;

	tagMCRPhySystem						m_SystemPerturb[2*g_nConstMaxReliabilityPerturb+1];

public:
	void	PGMemDB2PhyData(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void	PhyData2PGMemDB(tagPGBlock* pPGBlock);
	void	AppendSubstationVoltageLevel(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);

public:
	void	PrevReliabilityEvaluate();
	void	MCRSysIndex();
	void	MCRDevIndex();
	void	MCREconomy(const int nLifetime, const double fPrice, const double fRecip, const double fEValueRatio, const double fPowerFactor);

	void	SaveMCReliabilityResult(const char* lpszFileName, double fFModeRThreshold, double fFModeUThreshold);
	void	SaveMCReliabilityPerturbResult(const char* lpszFileName);

	void	PhyTopo();

	int		ReadPhyFile(const char* lpszFileName);
	void	SavePhyFile(const char* lpszFileName);

	int		ReadPhyRParamFile(const char* lpszFileName);
	void	SavePhyRParamFile(const char* lpszFileName);
	void	ImportMCRPhyParam();

	void	ExportMCRTableField(const char* lpszFileName);

private:
	void	PhyCheckError();
	void	PhyCheckSource(const char* lpszVolt);
	void	PhyTraverseNet(const int nStartNode, const unsigned char bInrangeBusbar, const unsigned char bInrangeBreaker, const unsigned char bRouteBypass, std::vector<int>& nNodeArray);
	void	PhyTraverseVolt(const int nStartNode, const unsigned char bInrangeBusbar, const unsigned char bInrangeBreaker, const unsigned char bRouteBypass, std::vector<int>& nNodeArray);
	int		PhyTraverseJointDevice(const int nStartNode, const unsigned char bInrangeBusbar, const unsigned char bInrangeBreaker, const short nTargetType);

	void	SortBus(int nDn0, int nUp0);
	void	SortLine(int nDn0, int nUp0);
	void	SortTran(int nDn0, int nUp0);
	void	SortScap(int nDn0, int nUp0);
	void	SortBreaker(int nDn0, int nUp0);
	void	SortDisconnector(int nDn0, int nUp0);

private:
	void	SaveMCReliabilityFault1(TiXmlElement* pParent, tagMCRPhyFault1* pFault, const double fRThreshold=0, const double fUThreshold=0, const unsigned char bOutArrange=1);
	void	SaveMCReliabilityFault2(TiXmlElement* pParent, tagMCRPhyFault2* pFault, const double fRThreshold=0, const double fUThreshold=0, const unsigned char bOutArrange=1);
	void	SaveMCReliabilityFault3(TiXmlElement* pParent, tagMCRPhyFault3* pFault, const double fRThreshold=0, const double fUThreshold=0, const unsigned char bOutArrange=1);
	void	SaveMCReliabilityIndex(TiXmlElement* pElement, tagMCRDevIndex* pIndex, double fFmodeRThreshold=0, double fFmodeUThreshold=0);

//////////////////////////////////////////////////////////////////////////
//	��������صĲ���
//////////////////////////////////////////////////////////////////////////
private:
	void	InitializePhyBus			(tagMCRPhyBus*			pData);
	void	InitializePhyLine			(tagMCRPhyLine*			pData);
	void	InitializePhyTran			(tagMCRPhyTran*			pData);
	void	InitializePhyScap			(tagMCRPhyScap*			pData);
	void	InitializePhyBreaker		(tagMCRPhyBreaker*		pData);
	void	InitializePhyDisconnector	(tagMCRPhyDisconnector*	pData);

	void	InitializeMCRParam			(tagMCRParam*			pData);

	void	InitializeMCRPhyParam();
	void	InitializeMCRPhyNode(tagMCRPhyNode* pData);

	void	InitializePhyAugLoad		(tagMCRPhyAugLoad*		pData);
	void	InitializePhyAugGen			(tagMCRPhyAugGen*		pData);

	void	SortNodeByName(int nDn0, int nUp0);
	int		FindNodeByName (int nLeft, int nRight, const std::string strName);

public:
	std::string	GetPhyDataValue(const int nTable, const int nField, const int nRecord);
	void		SetPhyDataValue(const int nTable, const int nField, const int nRecord, const char* lpszValue);
	int			GetPhyDataField(const int nTable, const char* lpszField);

public:
	int	GetCompID(const short nCompTyp, const int nCompIdx);
	std::string	GetCompString(const short nCompTyp, const int nCompIdx);

private:
	std::string	GetPhyBusData			(const int nField, const int nRecord);
	std::string	GetPhyLineData			(const int nField, const int nRecord);
	std::string	GetPhyTranData			(const int nField, const int nRecord);
	std::string	GetPhyScapData			(const int nField, const int nRecord);
	std::string	GetPhyBreakerData		(const int nField, const int nRecord);
	std::string	GetPhyDisconnectorData	(const int nField, const int nRecord);

private:
	void SetPhyBusData			(const int nField, const int nRecord, const char* lpszValue);
	void SetPhyLineData			(const int nField, const int nRecord, const char* lpszValue);
	void SetPhyTranData			(const int nField, const int nRecord, const char* lpszValue);
	void SetPhyScapData			(const int nField, const int nRecord, const char* lpszValue);
	void SetPhyBreakerData		(const int nField, const int nRecord, const char* lpszValue);
	void SetPhyDisconnectorData	(const int nField, const int nRecord, const char* lpszValue);

public:
	void SetPhyBusData			(tagMCRPhyBus*			pBus,			const int nField, const char* lpszValue);
	void SetPhyLineData			(tagMCRPhyLine*			pLine,			const int nField, const char* lpszValue);
	void SetPhyTranData			(tagMCRPhyTran*			pTran,			const int nField, const char* lpszValue);
	void SetPhyScapData			(tagMCRPhyScap*			pScap,			const int nField, const char* lpszValue);
	void SetPhyBreakerData		(tagMCRPhyBreaker*		pBreaker,		const int nField, const char* lpszValue);
	void SetPhyDisconnectorData	(tagMCRPhyDisconnector*	pDisconnector,	const int nField, const char* lpszValue);

private:
	void PGMemDB2PhyData_Bus			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void PGMemDB2PhyData_Line			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void PGMemDB2PhyData_Tran			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void PGMemDB2PhyData_Scap			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void PGMemDB2PhyData_Breaker		(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void PGMemDB2PhyData_Disconnector	(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);

//////////////////////////////////////////////////////////////////////////
//	�����ģʽ��صĲ���
//////////////////////////////////////////////////////////////////////////
public:
	tagMCRDevIndex	m_L1Index;
	tagMCRDevIndex	m_T1Index;
	tagMCRDevIndex	m_L2Index;
	tagMCRDevIndex	m_T2Index;
	tagMCRDevIndex	m_LTIndex;
	tagMCRDevIndex	m_SubIndex;

private:
	void	InitilizeMCRDevIndex(tagMCRDevIndex* pData);

	int		ComparePhyComp(tagMCRPhyComp* pCompI, tagMCRPhyComp* pCompJ);
	int		SeekFault1InFault1(std::vector<tagMCRPhyFault1>& sFaultArray, tagMCRPhyFault1& sFault);
	int		SeekFault1InFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault1& sFault);
	int		SeekFault1InFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault1& sFault);
	int		SeekFault2InFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault2& sFault);
	int		SeekFault3InFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault3& sFault);
	int		SeekFault2InFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault2& sFault);
	int		CompareFault1(tagMCRPhyFault1* pFaultA, tagMCRPhyFault1* pFaultB);
	int		CompareFault2(tagMCRPhyFault2* pFaultA, tagMCRPhyFault2* pFaultB);
	int		CompareFault3(tagMCRPhyFault3* pFaultA, tagMCRPhyFault3* pFaultB);
	int		CompareFault1Comp(tagMCRPhyFault1* pFaultA, tagMCRPhyFault1* pFaultB);
	int		CompareFault2Comp(tagMCRPhyFault2* pFaultA, tagMCRPhyFault2* pFaultB);
	int		CompareFault3Comp(tagMCRPhyFault3* pFaultA, tagMCRPhyFault3* pFaultB);
	void	RegularFault2(tagMCRPhyFault2* pFault);
	void	RegularFault3(tagMCRPhyFault3* pFault);
	void	AddFault1(std::vector<tagMCRPhyFault1>& sFaultArray, tagMCRPhyFault1& sFault);
	void	AddFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault2& sFault);
	void	AddFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault1& sFaultA, tagMCRPhyFault1& sFaultB);
	void	AddFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault3& sFault);
	void	AddFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault1& sFaultA, tagMCRPhyFault2& sFaultB);
	void	CombineFault3(std::vector<tagMCRPhyFault3>& sFault3Array, tagMCRPhyFault2* pFaultA, tagMCRPhyFault2* pFaultB);
	void	SortFault1(std::vector<tagMCRPhyFault1>& sFaultArray, int nDn0, int nUp0);
	void	SortFault2(std::vector<tagMCRPhyFault2>& sFaultArray, int nDn0, int nUp0);
	void	SortFault3(std::vector<tagMCRPhyFault3>& sFaultArray, int nDn0, int nUp0);
	void	MergeFault1(std::vector<tagMCRPhyFault1>& sFaultArray);
	void	MergeFault2(std::vector<tagMCRPhyFault2>& sFaultArray);
	void	MergeFault3(std::vector<tagMCRPhyFault3>& sFaultArray);

	void	SeriesFault(std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array, tagMCRDevIndex& sIndex);
	void	Contribution(const double fR, const double fU, std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array);

private:
	void AppendString(std::string& strString, const char* lpszAppendString)
	{
		if (strString.empty())
			strString.append(lpszAppendString);
		else
		{
			strString.append("; ");
			strString.append(lpszAppendString);
		}
	}
};

extern	const char*	g_lpszLogFile;
extern	CMCRPerturb		g_MCRPerturb;

extern	void	Log(const char* lpszLogFile, char* pformat, ...);
