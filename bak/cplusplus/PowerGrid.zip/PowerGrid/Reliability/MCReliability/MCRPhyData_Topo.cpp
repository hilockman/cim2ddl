#include "StdAfx.h"
#include "MCRPhyData.h"

void CMCRPhyData::SortBus(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strSub=m_BusArray[(nDn0+nUp0)/2].strSub;
	std::string	strVolt=m_BusArray[(nDn0+nUp0)/2].strVolt;
	std::string	strName=m_BusArray[(nDn0+nUp0)/2].strName;

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && (strcmp(m_BusArray[nDn].strSub.c_str(), strSub.c_str()) < 0 ||
			strcmp(m_BusArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BusArray[nDn].strVolt.c_str(), strVolt.c_str()) < 0 ||
			strcmp(m_BusArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BusArray[nDn].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_BusArray[nDn].strName.c_str(), strName.c_str()) < 0))
			++nDn;
		while (nUp > nDn0 && (strcmp(m_BusArray[nUp].strSub.c_str(), strSub.c_str()) > 0 ||
			strcmp(m_BusArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BusArray[nUp].strVolt.c_str(), strVolt.c_str()) > 0 ||
			strcmp(m_BusArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BusArray[nUp].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_BusArray[nUp].strName.c_str(), strName.c_str()) > 0))
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BusArray[nDn], m_BusArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortBus(nDn0, nUp);

	if (nDn < nUp0 )
		SortBus(nDn, nUp0);
}

void CMCRPhyData::SortLine(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strName=m_LineArray[(nDn0+nUp0)/2].strName;

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_LineArray[nDn].strName.c_str(), strName.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_LineArray[nUp].strName.c_str(), strName.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_LineArray[nDn], m_LineArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortLine(nDn0, nUp);

	if (nDn < nUp0 )
		SortLine(nDn, nUp0);
}

void CMCRPhyData::SortTran(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strSub=m_TranArray[(nDn0+nUp0)/2].strSub;
	std::string	strName=m_TranArray[(nDn0+nUp0)/2].strName;

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && (strcmp(m_TranArray[nDn].strSub.c_str(), strSub.c_str()) < 0 ||
			strcmp(m_TranArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_TranArray[nDn].strName.c_str(), strName.c_str()) < 0))
			++nDn;
		while (nUp > nDn0 && (strcmp(m_TranArray[nUp].strSub.c_str(), strSub.c_str()) > 0 ||
			strcmp(m_TranArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_TranArray[nUp].strName.c_str(), strName.c_str()) > 0))
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_TranArray[nDn], m_TranArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortTran(nDn0, nUp);

	if (nDn < nUp0 )
		SortTran(nDn, nUp0);
}

void CMCRPhyData::SortScap(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strSub=m_ScapArray[(nDn0+nUp0)/2].strSub;
	std::string	strVolt=m_ScapArray[(nDn0+nUp0)/2].strVolt;
	std::string	strName=m_ScapArray[(nDn0+nUp0)/2].strName;

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && (strcmp(m_ScapArray[nDn].strSub.c_str(), strSub.c_str()) < 0 ||
			strcmp(m_ScapArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_ScapArray[nDn].strVolt.c_str(), strVolt.c_str()) < 0 ||
			strcmp(m_ScapArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_ScapArray[nDn].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_ScapArray[nDn].strName.c_str(), strName.c_str()) < 0))
			++nDn;
		while (nUp > nDn0 && (strcmp(m_ScapArray[nUp].strSub.c_str(), strSub.c_str()) > 0 ||
			strcmp(m_ScapArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_ScapArray[nUp].strVolt.c_str(), strVolt.c_str()) > 0 ||
			strcmp(m_ScapArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_ScapArray[nUp].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_ScapArray[nUp].strName.c_str(), strName.c_str()) > 0))
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_ScapArray[nDn], m_ScapArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortScap(nDn0, nUp);

	if (nDn < nUp0 )
		SortScap(nDn, nUp0);
}

void CMCRPhyData::SortBreaker(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strSub=m_BreakerArray[(nDn0+nUp0)/2].strSub;
	std::string	strVolt=m_BreakerArray[(nDn0+nUp0)/2].strVolt;
	std::string	strName=m_BreakerArray[(nDn0+nUp0)/2].strName;

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && (strcmp(m_BreakerArray[nDn].strSub.c_str(), strSub.c_str()) < 0 ||
			strcmp(m_BreakerArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BreakerArray[nDn].strVolt.c_str(), strVolt.c_str()) < 0 ||
			strcmp(m_BreakerArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BreakerArray[nDn].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_BreakerArray[nDn].strName.c_str(), strName.c_str()) < 0))
			++nDn;
		while (nUp > nDn0 && (strcmp(m_BreakerArray[nUp].strSub.c_str(), strSub.c_str()) > 0 ||
			strcmp(m_BreakerArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BreakerArray[nUp].strVolt.c_str(), strVolt.c_str()) > 0 ||
			strcmp(m_BreakerArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_BreakerArray[nUp].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_BreakerArray[nUp].strName.c_str(), strName.c_str()) > 0))
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BreakerArray[nDn], m_BreakerArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortBreaker(nDn0, nUp);

	if (nDn < nUp0 )
		SortBreaker(nDn, nUp0);
}

void CMCRPhyData::SortDisconnector(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strSub=m_DisconnectorArray[(nDn0+nUp0)/2].strSub;
	std::string	strVolt=m_DisconnectorArray[(nDn0+nUp0)/2].strVolt;
	std::string	strName=m_DisconnectorArray[(nDn0+nUp0)/2].strName;

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && (strcmp(m_DisconnectorArray[nDn].strSub.c_str(), strSub.c_str()) < 0 ||
			strcmp(m_DisconnectorArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_DisconnectorArray[nDn].strVolt.c_str(), strVolt.c_str()) < 0 ||
			strcmp(m_DisconnectorArray[nDn].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_DisconnectorArray[nDn].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_DisconnectorArray[nDn].strName.c_str(), strName.c_str()) < 0))
			++nDn;
		while (nUp > nDn0 && (strcmp(m_DisconnectorArray[nUp].strSub.c_str(), strSub.c_str()) > 0 ||
			strcmp(m_DisconnectorArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_DisconnectorArray[nUp].strVolt.c_str(), strVolt.c_str()) > 0 ||
			strcmp(m_DisconnectorArray[nUp].strSub.c_str(), strSub.c_str()) == 0 && strcmp(m_DisconnectorArray[nUp].strVolt.c_str(), strVolt.c_str()) == 0 && strcmp(m_DisconnectorArray[nUp].strName.c_str(), strName.c_str()) > 0))
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_DisconnectorArray[nDn], m_DisconnectorArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortDisconnector(nDn0, nUp);

	if (nDn < nUp0 )
		SortDisconnector(nDn, nUp0);
}


void CMCRPhyData::PhyTopo()
{
	register int	i;
	unsigned char	bExist;
	int				nDev;
	tagMCRPhyNode	sNodeBuffer;
	std::vector<std::string>	strVoltArray;

	strVoltArray.clear();

	SortBus(0, (int)m_BusArray.size()-1);
	SortLine(0, (int)m_LineArray.size()-1);
	SortTran(0, (int)m_TranArray.size()-1);
	SortScap(0, (int)m_ScapArray.size()-1);
	SortBreaker(0, (int)m_BreakerArray.size()-1);
	SortDisconnector(0, (int)m_DisconnectorArray.size()-1);

	m_NodeArray.clear();
	for (nDev=0; nDev<(int)m_BusArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_BusArray[nDev].strNode.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_BUSBARSECTION;
			sNodeBuffer.strParentName = GetCompString(PG_BUSBARSECTION, nDev);
			sNodeBuffer.strName = m_BusArray[nDev].strNode;
			sNodeBuffer.strVolt = m_BusArray[nDev].strVolt;
			sNodeBuffer.nNodeType = PG_BUSBARSECTION;
			sNodeBuffer.bBypass = (m_BusArray[nDev].bByPass) ? 1 : 0;
			m_NodeArray.push_back(sNodeBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_LineArray[nDev].strNodeI.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_ACLINESEGMENT;
			sNodeBuffer.strParentName = m_LineArray[nDev].strName;
			sNodeBuffer.strName = m_LineArray[nDev].strNodeI;
			sNodeBuffer.strVolt = m_LineArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}

		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_LineArray[nDev].strNodeJ.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_ACLINESEGMENT;
			sNodeBuffer.strParentName = GetCompString(PG_ACLINESEGMENT, nDev);
			sNodeBuffer.strName = m_LineArray[nDev].strNodeJ;
			sNodeBuffer.strVolt = m_LineArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}

// 		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge)
// 		{
// 			bExist = 0;
// 			for (i=0; i<(int)m_NodeArray.size(); i++)
// 			{
// 				if (stricmp(m_NodeArray[i].strName.c_str(), m_LineArray[nDev].strNodeJ.c_str()) == 0)
// 				{
// 					bExist=1;
// 					break;
// 				}
// 			}
// 			if (!bExist)
// 			{
// 				InitializeMCRPhyNode(&sNodeBuffer);
// 
// 				sNodeBuffer.nParentType = PG_ACLINESEGMENT;
// 				sNodeBuffer.strParentName = GetCompString(PG_ACLINESEGMENT, nDev);
// 				sNodeBuffer.strName = m_LineArray[nDev].strNodeJ;
// 				sNodeBuffer.strVolt = m_LineArray[nDev].strVolt;
// 				m_NodeArray.push_back(sNodeBuffer);
// 			}
// 		}
	}
	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_TranArray[nDev].strNodeI.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_TRANSFORMERWINDING;
			sNodeBuffer.strParentName = GetCompString(PG_TRANSFORMERWINDING, nDev);
			sNodeBuffer.strName = m_TranArray[nDev].strNodeI;
			sNodeBuffer.strVolt = m_TranArray[nDev].strVoltI;
			m_NodeArray.push_back(sNodeBuffer);
		}

		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_TranArray[nDev].strNodeJ.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_TRANSFORMERWINDING;
			sNodeBuffer.strParentName = GetCompString(PG_TRANSFORMERWINDING, nDev);
			sNodeBuffer.strName = m_TranArray[nDev].strNodeJ;
			sNodeBuffer.strVolt = m_TranArray[nDev].strVoltJ;
			m_NodeArray.push_back(sNodeBuffer);
		}

// 		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge)
// 		{
// 			bExist = 0;
// 			for (i=0; i<(int)m_NodeArray.size(); i++)
// 			{
// 				if (stricmp(m_NodeArray[i].strName.c_str(), m_TranArray[nDev].strNodeJ.c_str()) == 0)
// 				{
// 					bExist=1;
// 					break;
// 				}
// 			}
// 			if (!bExist)
// 			{
// 				InitializeMCRPhyNode(&sNodeBuffer);
// 
// 				sNodeBuffer.nParentType = PG_TRANSFORMERWINDING;
// 				sNodeBuffer.strParentName = GetCompString(PG_TRANSFORMERWINDING, nDev);
// 				sNodeBuffer.strName = m_TranArray[nDev].strNodeJ;
// 				sNodeBuffer.strVolt = m_TranArray[nDev].strVoltJ;
// 				m_NodeArray.push_back(sNodeBuffer);
// 			}
// 		}
	}
	for (nDev=0; nDev<(int)m_ScapArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_ScapArray[nDev].strNodeI.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_SERIESCOMPENSATOR;
			sNodeBuffer.strParentName = GetCompString(PG_SERIESCOMPENSATOR, nDev);
			sNodeBuffer.strName = m_ScapArray[nDev].strNodeI;
			sNodeBuffer.strVolt = m_ScapArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}

		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_ScapArray[nDev].strNodeJ.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_SERIESCOMPENSATOR;
			sNodeBuffer.strParentName = GetCompString(PG_SERIESCOMPENSATOR, nDev);
			sNodeBuffer.strName = m_ScapArray[nDev].strNodeJ;
			sNodeBuffer.strVolt = m_ScapArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_BreakerArray[nDev].strNodeI.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_BREAKER;
			sNodeBuffer.strParentName = GetCompString(PG_BREAKER, nDev);
			sNodeBuffer.strName = m_BreakerArray[nDev].strNodeI;
			sNodeBuffer.strVolt = m_BreakerArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}

		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_BreakerArray[nDev].strNodeJ.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_BREAKER;
			sNodeBuffer.strParentName = GetCompString(PG_BREAKER, nDev);
			sNodeBuffer.strName = m_BreakerArray[nDev].strNodeJ;
			sNodeBuffer.strVolt = m_BreakerArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_DisconnectorArray[nDev].strNodeI.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_DISCONNECTOR;
			sNodeBuffer.strParentName = GetCompString(PG_DISCONNECTOR, nDev);
			sNodeBuffer.strName = m_DisconnectorArray[nDev].strNodeI;
			sNodeBuffer.strVolt = m_DisconnectorArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}

		bExist = 0;
		for (i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (stricmp(m_NodeArray[i].strName.c_str(), m_DisconnectorArray[nDev].strNodeJ.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			InitializeMCRPhyNode(&sNodeBuffer);

			sNodeBuffer.nParentType = PG_DISCONNECTOR;
			sNodeBuffer.strParentName= GetCompString(PG_DISCONNECTOR, nDev);
			sNodeBuffer.strName = m_DisconnectorArray[nDev].strNodeJ;
			sNodeBuffer.strVolt = m_DisconnectorArray[nDev].strVolt;
			m_NodeArray.push_back(sNodeBuffer);
		}
	}
	SortNodeByName(0, (int)m_NodeArray.size()-1);

	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		m_LineArray[nDev].nNodeI = FindNodeByName(0, (int)m_NodeArray.size()-1, m_LineArray[nDev].strNodeI);
		m_LineArray[nDev].nNodeJ = FindNodeByName(0, (int)m_NodeArray.size()-1, m_LineArray[nDev].strNodeJ);

		if (m_LineArray[nDev].nNodeI >= 0)
		{
			m_NodeArray[m_LineArray[nDev].nNodeI].nLineArray.push_back(nDev);

			if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Gen)
				m_NodeArray[m_LineArray[nDev].nNodeI].nNodeType = PG_SYNCHRONOUSMACHINE;
			else if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_NodeArray[m_LineArray[nDev].nNodeI].nNodeType = PG_ENERGYCONSUMER;
		}
		if (m_LineArray[nDev].nNodeJ >= 0)
		{
			m_NodeArray[m_LineArray[nDev].nNodeJ].nLineArray.push_back(nDev);

			if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Gen)
				m_NodeArray[m_LineArray[nDev].nNodeJ].nNodeType = PG_SYNCHRONOUSMACHINE;
			else if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_NodeArray[m_LineArray[nDev].nNodeJ].nNodeType = PG_ENERGYCONSUMER;
		}
		if (m_LineArray[nDev].nNodeJ >= 0 && m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge)	m_NodeArray[m_LineArray[nDev].nNodeJ].nLineArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		m_TranArray[nDev].nNodeI = FindNodeByName(0, (int)m_NodeArray.size()-1, m_TranArray[nDev].strNodeI);
		m_TranArray[nDev].nNodeJ = FindNodeByName(0, (int)m_NodeArray.size()-1, m_TranArray[nDev].strNodeJ);

		if (m_TranArray[nDev].nNodeI >= 0)
		{
			m_NodeArray[m_TranArray[nDev].nNodeI].nTranArray.push_back(nDev);
			if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Gen)
				m_NodeArray[m_TranArray[nDev].nNodeI].nNodeType = PG_SYNCHRONOUSMACHINE;
			else if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_NodeArray[m_TranArray[nDev].nNodeI].nNodeType = PG_ENERGYCONSUMER;
		}
		if (m_TranArray[nDev].nNodeJ >= 0)
		{
			m_NodeArray[m_TranArray[nDev].nNodeJ].nTranArray.push_back(nDev);
			if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Gen)
				m_NodeArray[m_TranArray[nDev].nNodeJ].nNodeType = PG_SYNCHRONOUSMACHINE;
			else if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_NodeArray[m_TranArray[nDev].nNodeJ].nNodeType = PG_ENERGYCONSUMER;
		}
		if (m_TranArray[nDev].nNodeJ >= 0 && m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge)	m_NodeArray[m_TranArray[nDev].nNodeJ].nTranArray.push_back(nDev);
	}

	for (nDev=0; nDev<(int)m_ScapArray.size(); nDev++)
	{
		m_ScapArray[nDev].nNodeI = FindNodeByName(0, (int)m_NodeArray.size()-1, m_ScapArray[nDev].strNodeI);
		m_ScapArray[nDev].nNodeJ = FindNodeByName(0, (int)m_NodeArray.size()-1, m_ScapArray[nDev].strNodeJ);

		if (m_ScapArray[nDev].nNodeI >= 0)	m_NodeArray[m_ScapArray[nDev].nNodeI].nScapArray.push_back(nDev);
		if (m_ScapArray[nDev].nNodeJ >= 0)	m_NodeArray[m_ScapArray[nDev].nNodeJ].nScapArray.push_back(nDev);
	}

	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		m_BreakerArray[nDev].nNodeI = FindNodeByName(0, (int)m_NodeArray.size()-1, m_BreakerArray[nDev].strNodeI);
		m_BreakerArray[nDev].nNodeJ = FindNodeByName(0, (int)m_NodeArray.size()-1, m_BreakerArray[nDev].strNodeJ);

		if (m_BreakerArray[nDev].nNodeI >= 0)	m_NodeArray[m_BreakerArray[nDev].nNodeI].nBreakerArray.push_back(nDev);
		if (m_BreakerArray[nDev].nNodeJ >= 0)	m_NodeArray[m_BreakerArray[nDev].nNodeJ].nBreakerArray.push_back(nDev);
	}

	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		m_DisconnectorArray[nDev].nNodeI = FindNodeByName(0, (int)m_NodeArray.size()-1, m_DisconnectorArray[nDev].strNodeI);
		m_DisconnectorArray[nDev].nNodeJ = FindNodeByName(0, (int)m_NodeArray.size()-1, m_DisconnectorArray[nDev].strNodeJ);

		if (m_DisconnectorArray[nDev].nNodeI >= 0)	m_NodeArray[m_DisconnectorArray[nDev].nNodeI].nDisconnectorArray.push_back(nDev);
		if (m_DisconnectorArray[nDev].nNodeJ >= 0)	m_NodeArray[m_DisconnectorArray[nDev].nNodeJ].nDisconnectorArray.push_back(nDev);
	}

	for (nDev=0; nDev<(int)m_BusArray.size(); nDev++)
	{
		m_BusArray[nDev].nNode = FindNodeByName(0, (int)m_NodeArray.size()-1, m_BusArray[nDev].strNode);
		if (m_BusArray[nDev].bByPass)
			continue;

		if (m_BusArray[nDev].nNode >= 0)	m_NodeArray[m_BusArray[nDev].nNode].nBusArray.push_back(nDev);
	}

	strVoltArray.clear();
	for (nDev=0; nDev<(int)m_NodeArray.size(); nDev++)
	{
		bExist = 0;
		for (i=0; i<(int)strVoltArray.size(); i++)
		{
			if (stricmp(strVoltArray[i].c_str(), m_NodeArray[nDev].strVolt.c_str()) == 0)
			{
				bExist = 1;
				break;
			}
		}
		if (!bExist)
			strVoltArray.push_back(m_NodeArray[nDev].strVolt);
	}

	std::string	strBuffer;
	int			nBuffer;
	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge)
			continue;
		if (m_LineArray[nDev].nNodeI == m_LineArray[nDev].nNodeJ)
			continue;

		if (m_NodeArray[m_LineArray[nDev].nNodeI].nLineArray.size() == 1 && 
			m_NodeArray[m_LineArray[nDev].nNodeI].nTranArray.empty() && 
			m_NodeArray[m_LineArray[nDev].nNodeI].nScapArray.empty() && 
			m_NodeArray[m_LineArray[nDev].nNodeI].nBreakerArray.empty() && 
			m_NodeArray[m_LineArray[nDev].nNodeI].nDisconnectorArray.empty())
		{
			strBuffer = m_LineArray[nDev].strNodeI;
			m_LineArray[nDev].strNodeI = m_LineArray[nDev].strNodeJ;
			m_LineArray[nDev].strNodeJ = strBuffer;

			nBuffer = m_LineArray[nDev].nNodeI;
			m_LineArray[nDev].nNodeI = m_LineArray[nDev].nNodeJ;
			m_LineArray[nDev].nNodeJ = nBuffer;
		}
	}
	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge)
			continue;
		if (m_TranArray[nDev].nNodeI == m_TranArray[nDev].nNodeJ)
			continue;

		if (m_NodeArray[m_TranArray[nDev].nNodeI].nTranArray.size() == 1 && 
			m_NodeArray[m_TranArray[nDev].nNodeI].nLineArray.empty() && 
			m_NodeArray[m_TranArray[nDev].nNodeI].nScapArray.empty() && 
			m_NodeArray[m_TranArray[nDev].nNodeI].nBreakerArray.empty() && 
			m_NodeArray[m_TranArray[nDev].nNodeI].nDisconnectorArray.empty())
		{
			strBuffer = m_TranArray[nDev].strNodeI;
			m_TranArray[nDev].strNodeI = m_TranArray[nDev].strNodeJ;
			m_TranArray[nDev].strNodeJ = strBuffer;

			nBuffer = m_TranArray[nDev].nNodeI;
			m_TranArray[nDev].nNodeI = m_TranArray[nDev].nNodeJ;
			m_TranArray[nDev].nNodeJ = nBuffer;
		}
	}


	for (nDev=0; nDev<(int)strVoltArray.size(); nDev++)
		PhyCheckSource(strVoltArray[nDev].c_str());
	PhyCheckError();
}

void CMCRPhyData::PhyCheckSource(const char* lpszVolt)
{
	register int	i;
	int				nDev, nNode;
	unsigned char	bBusConnMode;
	std::vector<unsigned char>	nBreakerStatusArray;
	std::vector<unsigned char>	nDisconnectorStatusArray;
	std::vector<int>	nNodeArray;

	nBreakerStatusArray.resize(m_BreakerArray.size());
	nDisconnectorStatusArray.resize(m_DisconnectorArray.size());
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		nBreakerStatusArray[i] = m_BreakerArray[i].nStatus;
		m_BreakerArray[i].nStatus = 0;
	}
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		nDisconnectorStatusArray[i] = m_DisconnectorArray[i].nStatus;
		m_DisconnectorArray[i].nStatus = 0;
	}

	//////////////////////////////////////////////////////////////////////////
	//	�����ڶ�·��������ĸ�߶�ֱ�����ӵģ���ý���Ϊĸ���ƽ���
	bBusConnMode = 1;
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (stricmp(m_BreakerArray[nDev].strVolt.c_str(), lpszVolt) != 0)
			continue;

		if (!PhyTraverseJointDevice(m_BreakerArray[nDev].nNodeI, InrangeBusbar_Yes, InrangeBreaker_Yes, PG_BUSBARSECTION) &&
			!PhyTraverseJointDevice(m_BreakerArray[nDev].nNodeJ, InrangeBusbar_Yes, InrangeBreaker_Yes, PG_BUSBARSECTION))
		{
			bBusConnMode = 0;
			break;
		}
	}

	for	(nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		if (stricmp(m_LineArray[nDev].strVolt.c_str(), lpszVolt) != 0)
			continue;

		if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Edge)
			continue;

		m_LineArray[nDev].nStatus = 1;

		m_LineArray[nDev].bSourceI = PhyTraverseJointDevice(m_LineArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE);
		m_LineArray[nDev].bSourceJ = PhyTraverseJointDevice(m_LineArray[nDev].nNodeJ, InrangeBusbar_No, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE);
		m_LineArray[nDev].nStatus = 0;
	}

	for	(nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		if (stricmp(m_TranArray[nDev].strVoltI.c_str(), lpszVolt) != 0 && stricmp(m_TranArray[nDev].strVoltJ.c_str(), lpszVolt) != 0)
			continue;

		if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Edge)
			continue;

		PhyTraverseVolt(m_TranArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, BypassRoute_No, nNodeArray);
		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_NodeArray[nNodeArray[nNode]].nTranArray.size(); i++)
			{
				m_TranArray[m_NodeArray[nNodeArray[nNode]].nTranArray[i]].nStatus = 1;
			}
		}

		m_TranArray[nDev].bSourceI = PhyTraverseJointDevice(m_TranArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE);
		m_TranArray[nDev].bSourceJ = PhyTraverseJointDevice(m_TranArray[nDev].nNodeJ, InrangeBusbar_No, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE);

		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_NodeArray[nNodeArray[nNode]].nTranArray.size(); i++)
			{
				m_TranArray[m_NodeArray[nNodeArray[nNode]].nTranArray[i]].nStatus = 0;
			}
		}
	}

	for	(nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (stricmp(m_BreakerArray[nDev].strVolt.c_str(), lpszVolt) != 0)
			continue;

		m_BreakerArray[nDev].nStatus = 1;

		if (bBusConnMode)
		{
			if (PhyTraverseJointDevice(m_BreakerArray[nDev].nNodeI, InrangeBusbar_Yes, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE))
				m_BreakerArray[nDev].bSourceI =1;
			if (PhyTraverseJointDevice(m_BreakerArray[nDev].nNodeJ, InrangeBusbar_Yes, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE))
				m_BreakerArray[nDev].bSourceJ =1;

			if (m_BreakerArray[nDev].bSourceI == 0 && m_BreakerArray[nDev].bSourceJ == 0)
			{
				if (PhyTraverseJointDevice(m_BreakerArray[nDev].nNodeI, InrangeBusbar_Yes, InrangeBreaker_No, PG_ENERGYCONSUMER))
					m_BreakerArray[nDev].bSourceJ =1;
				else if (PhyTraverseJointDevice(m_BreakerArray[nDev].nNodeJ, InrangeBusbar_Yes, InrangeBreaker_No, PG_ENERGYCONSUMER))
					m_BreakerArray[nDev].bSourceI =1;
			}
		}
		else
		{
			m_BreakerArray[nDev].bSourceI =1;
			m_BreakerArray[nDev].bSourceJ =1;
		}

		m_BreakerArray[nDev].nStatus = 0;
	}

	for	(nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (stricmp(m_DisconnectorArray[nDev].strVolt.c_str(), lpszVolt) != 0)
			continue;

		m_DisconnectorArray[nDev].nStatus = 1;

		if (bBusConnMode)
		{
			if (PhyTraverseJointDevice(m_DisconnectorArray[nDev].nNodeI, InrangeBusbar_Yes, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE))
				m_DisconnectorArray[nDev].bSourceI =1;
			if (PhyTraverseJointDevice(m_DisconnectorArray[nDev].nNodeJ, InrangeBusbar_Yes, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE))
				m_DisconnectorArray[nDev].bSourceJ =1;

			if (m_DisconnectorArray[nDev].bSourceI == 0 && m_DisconnectorArray[nDev].bSourceJ == 0)
			{
				if (PhyTraverseJointDevice(m_DisconnectorArray[nDev].nNodeI, InrangeBusbar_Yes, InrangeBreaker_No, PG_ENERGYCONSUMER))
					m_DisconnectorArray[nDev].bSourceJ =1;
				else if (PhyTraverseJointDevice(m_DisconnectorArray[nDev].nNodeJ, InrangeBusbar_Yes, InrangeBreaker_No, PG_ENERGYCONSUMER))
					m_DisconnectorArray[nDev].bSourceI =1;
			}
		}
		else
		{
			m_DisconnectorArray[nDev].bSourceI =1;
			m_DisconnectorArray[nDev].bSourceJ =1;
		}

		m_DisconnectorArray[nDev].nStatus = 0;
	}

	for (i=0; i<(int)m_BreakerArray.size(); i++)
		m_BreakerArray[i].nStatus = nBreakerStatusArray[i];
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
		m_DisconnectorArray[i].nStatus = nDisconnectorStatusArray[i];

	nBreakerStatusArray.clear();
	nDisconnectorStatusArray.clear();
}

void CMCRPhyData::PhyTraverseNet(const int nStartNode, const unsigned char bInrangeBusbar, const unsigned char bInrangeBreaker, const unsigned char bRouteBypass, std::vector<int>& nNodeArray)
{
	register int	i, j;
	int		nDev, nNode;
	int		nNodeNumOfLayer;
	std::vector<int> nMidNodeArray;

	nNodeArray.clear();
	for (i=0; i<(int)m_NodeArray.size(); i++)
		m_NodeArray[i].bUnproc=1;

	nNodeArray.push_back(nStartNode);
	m_NodeArray[nStartNode].bUnproc=0;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
		{
			if (bInrangeBusbar)
			{
				if (m_NodeArray[nNodeArray[i]].nNodeType == PG_BUSBARSECTION)
				//if (nNodeArray[i] != nStartNode && m_NodeArray[nNodeArray[i]].nNodeType == PG_BUSBARSECTION)
					continue;
			}
			if (!bRouteBypass)
			{
				if (nNodeArray[i] != nStartNode && m_NodeArray[nNodeArray[i]].bBypass)
					continue;
			}

			if (!bInrangeBreaker)
			{
				for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nBreakerArray.size(); j++)
				{
					nDev=m_NodeArray[nNodeArray[i]].nBreakerArray[j];
					if (m_BreakerArray[nDev].nStatus != 0)
						continue;

					nNode=(nNodeArray[i] == m_BreakerArray[nDev].nNodeI) ? m_BreakerArray[nDev].nNodeJ:m_BreakerArray[nDev].nNodeI;
					if (m_NodeArray[nNode].bUnproc)
					{
						nMidNodeArray.push_back(nNode);
						m_NodeArray[nNode].bUnproc=0;
					}
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nDisconnectorArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nDisconnectorArray[j];
				if (m_DisconnectorArray[nDev].nStatus != 0)
					continue;

				nNode=(nNodeArray[i] == m_DisconnectorArray[nDev].nNodeI) ? m_DisconnectorArray[nDev].nNodeJ : m_DisconnectorArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nLineArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nLineArray[j];
				if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Edge)
					continue;
				if (m_LineArray[nDev].nStatus  != 0)
					continue;

				nNode=(nNodeArray[i] == m_LineArray[nDev].nNodeI) ? m_LineArray[nDev].nNodeJ : m_LineArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nTranArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nTranArray[j];
				if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Edge)
					continue;
				if (m_TranArray[nDev].nStatus != 0)
					continue;

				nNode=(nNodeArray[i] == m_TranArray[nDev].nNodeI) ? m_TranArray[nDev].nNodeJ : m_TranArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nScapArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nScapArray[j];
				nNode=(nNodeArray[i] == m_ScapArray[nDev].nNodeI) ? m_ScapArray[nDev].nNodeJ : m_ScapArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
		}
		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nNodeArray.push_back(nMidNodeArray[i]);
	}
}

void CMCRPhyData::PhyTraverseVolt(const int nStartNode, const unsigned char bInrangeBusbar, const unsigned char bInrangeBreaker, const unsigned char bRouteBypass, std::vector<int>& nNodeArray)
{
	register int	i, j;
	int		nDev, nNode;
	int		nNodeNumOfLayer;
	std::vector<int> nMidNodeArray;

	nNodeArray.clear();
	for (i=0; i<(int)m_NodeArray.size(); i++)
		m_NodeArray[i].bUnproc=1;

	nNodeArray.push_back(nStartNode);
	m_NodeArray[nStartNode].bUnproc=0;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
		{
			if (bInrangeBusbar)
			{
				if (m_NodeArray[nNodeArray[i]].nNodeType == PG_BUSBARSECTION)
					//if (nNodeArray[i] != nStartNode && m_NodeArray[nNodeArray[i]].nNodeType == PG_BUSBARSECTION)
					continue;
			}
			if (!bRouteBypass)
			{
				if (nNodeArray[i] != nStartNode && m_NodeArray[nNodeArray[i]].bBypass)
					continue;
			}

			if (!bInrangeBreaker)
			{
				for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nBreakerArray.size(); j++)
				{
					nDev=m_NodeArray[nNodeArray[i]].nBreakerArray[j];
					if (m_BreakerArray[nDev].nStatus != 0)
						continue;

					nNode=(nNodeArray[i] == m_BreakerArray[nDev].nNodeI) ? m_BreakerArray[nDev].nNodeJ:m_BreakerArray[nDev].nNodeI;
					if (m_NodeArray[nNode].bUnproc)
					{
						nMidNodeArray.push_back(nNode);
						m_NodeArray[nNode].bUnproc=0;
					}
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nDisconnectorArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nDisconnectorArray[j];
				if (m_DisconnectorArray[nDev].nStatus != 0)
					continue;

				nNode=(nNodeArray[i] == m_DisconnectorArray[nDev].nNodeI) ? m_DisconnectorArray[nDev].nNodeJ : m_DisconnectorArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nLineArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nLineArray[j];
				if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Edge)
					continue;
				if (m_LineArray[nDev].nStatus  != 0)
					continue;

				nNode=(nNodeArray[i] == m_LineArray[nDev].nNodeI) ? m_LineArray[nDev].nNodeJ : m_LineArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nTranArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nTranArray[j];
				if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Edge)
					continue;
				if (m_TranArray[nDev].nStatus != 0)
					continue;

				nNode=(nNodeArray[i] == m_TranArray[nDev].nNodeI) ? m_TranArray[nDev].nNodeJ : m_TranArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc && stricmp(m_NodeArray[nNode].strVolt.c_str(), m_NodeArray[nStartNode].strVolt.c_str()) == 0)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
			for (j=0; j<(int)m_NodeArray[nNodeArray[i]].nScapArray.size(); j++)
			{
				nDev=m_NodeArray[nNodeArray[i]].nScapArray[j];
				nNode=(nNodeArray[i] == m_ScapArray[nDev].nNodeI) ? m_ScapArray[nDev].nNodeJ : m_ScapArray[nDev].nNodeI;
				if (m_NodeArray[nNode].bUnproc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bUnproc=0;
				}
			}
		}
		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nNodeArray.push_back(nMidNodeArray[i]);
	}
}

int CMCRPhyData::PhyTraverseJointDevice(const int nStartNode, const unsigned char bInrangeBusbar, const unsigned char bInrangeBreaker, const short nTargetType)
{
	int		nNode;
	std::vector<int>	nNodeArray;

	PhyTraverseVolt(nStartNode, bInrangeBusbar, bInrangeBreaker, BypassRoute_No, nNodeArray);
	for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
	{
		if (nTargetType == PG_BUSBARSECTION)
		{
			if (m_NodeArray[nNodeArray[nNode]].bBypass)
				continue;
		}

		if (m_NodeArray[nNodeArray[nNode]].nNodeType == nTargetType)
			return 1;
	}

	if (nTargetType == PG_SYNCHRONOUSMACHINE)
	{
		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			if (m_NodeArray[nNodeArray[nNode]].nNodeType == PG_TRANSFORMERWINDING)
				return 1;
		}
	}
	else if (nTargetType == PG_ENERGYCONSUMER)
	{
		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			if (m_NodeArray[nNodeArray[nNode]].nNodeType == PG_TRANSFORMERWINDING)
				return 1;
		}
	}

	return 0;
}

void CMCRPhyData::PhyCheckError()
{
	int		nDev;

	for	(nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		m_LineArray[nDev].bAlone = 0;
		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge)
			continue;

		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
		{
			if (PhyTraverseJointDevice(m_LineArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE))
				m_LineArray[nDev].bAlone = 1;
		}
		else if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Gen)
		{
			if (PhyTraverseJointDevice(m_LineArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, PG_ENERGYCONSUMER))
				m_LineArray[nDev].bAlone = 1;
		}
	}

	for	(nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		m_TranArray[nDev].bAlone = 0;
		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge)
			continue;

		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
		{
			if (PhyTraverseJointDevice(m_TranArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, PG_SYNCHRONOUSMACHINE))
				m_TranArray[nDev].bAlone = 1;
		}
		else if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Gen)
		{
			if (PhyTraverseJointDevice(m_TranArray[nDev].nNodeI, InrangeBusbar_No, InrangeBreaker_No, PG_ENERGYCONSUMER))
				m_TranArray[nDev].bAlone = 1;
		}
	}
}
