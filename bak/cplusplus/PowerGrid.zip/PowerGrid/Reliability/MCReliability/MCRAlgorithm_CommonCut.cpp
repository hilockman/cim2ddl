#include "StdAfx.h"
#include "MCRAlgorithm.h"

void CMCRAlgorithm::FormCommonShortcut(const unsigned char bBreakerFaultFailure)
{
	register int	i;
	int		nComp, nFCm, nSCm, nMCut, nFComp, nSComp;
	int		nCmComp, nFCmComp, nSCmComp;
	double	fR1, fR2, fT1, fT2;
	tagMCRCmMinCut1	sCut1Buf;
	tagMCRCmMinCut2	sCut2Buf;

	m_CmMCut1Array.clear();
	m_CmMCut2Array.clear();
	memset(&sCut1Buf, 0, sizeof(tagMCRCmMinCut1));
	memset(&sCut2Buf, 0, sizeof(tagMCRCmMinCut2));
	sCut1Buf.nCutType = MCREnumCutType_Cut1_Cut1OneBreakerComm;
	sCut2Buf.nCutType = MCREnumCutType_Cut2_Cut2OneBreakerComm;

	for (i=0; i<2; i++)
	{
		sCut1Buf.nCommonBreaker[i]=-1;
		sCut2Buf.nCommonBreaker[i]=-1;
	}

	//һ�׸
	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		if (m_MinCut1Array[i].nCutType != MCREnumCutType_Normal)
			continue;

		nFComp = m_MinCut1Array[i].nComp;
		if (m_CompArray[nFComp].nPhyTyp != PG_BREAKER)	//	�����Ƕ�·��
			continue;

		for (nFCm=0; nFCm<(int)m_CompArray[nFComp].sCmCompArray.size(); nFCm++)
		{
			nCmComp=m_CompArray[nFComp].sCmCompArray[nFCm].nCommComp;
			if (!bBreakerFaultFailure && m_CompArray[nCmComp].nPhyTyp == PG_BREAKER)	//	���򵽶�·��
				continue;

			if (m_CompArray[nCmComp].fRerr <= FLT_MIN && m_CompArray[nCmComp].fTrep <= FLT_MIN)
				continue;

			if (SeekMCut01(m_MinCut1Array, nCmComp) >= 0)
				continue;

			sCut1Buf.nCutType = MCREnumCutType_Cut1_Cut1OneBreakerComm;
			sCut1Buf.nCommonBreaker[0] = nFComp;
			sCut1Buf.nCommonBreaker[1] = -1;
			sCut1Buf.nComp = nCmComp;
			sCut1Buf.fR =m_CompArray[nCmComp].fRerr;
			sCut1Buf.fT = (m_CompArray[nFComp].sCmCompArray[nFCm].nCommType == 0) ? m_CompArray[nCmComp].fTrep : m_CompArray[nCmComp].fTopr;

			if (sCut1Buf.fR > FLT_MIN && sCut1Buf.fT > FLT_MIN)
			{
#ifdef _DEBUG
				Log(g_lpszLogFile,  " ����·�����ӹ�ģһ�׸� : [%s %s] R1=%f T1=%f \n", PGGetTableDesp(m_CompArray[nCmComp].nPhyTyp), m_CompArray[nCmComp].strName.c_str(), sCut1Buf.fR, sCut1Buf.fT);
#endif
				nMCut = SeekCommMCut01(m_CmMCut1Array, nCmComp);
				if (nMCut < 0)
				{
					m_CmMCut1Array.push_back(sCut1Buf);
				}
				else
				{
					if (sCut1Buf.fR*sCut1Buf.fT > m_CmMCut1Array[nMCut].fR*m_CmMCut1Array[nMCut].fT)
						memcpy(&m_CmMCut1Array[nMCut], &sCut1Buf, sizeof(tagMCRCmMinCut1));
				}
			}
		}
	}

	//���׸
	//	���׸������֣�
	//	1��������·������ͬһ���豸�����γ�һ�׹�ģ��
	//	2��������·���ֱ�ģ��ͬ�豸�����γ��µĶ��׹�ģ�������µĶ��׹�ģ�����豸��ԭ���ͬ��
	//	3���滻����һ����·����
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		if (m_MinCut2Array[i].nCutType != MCREnumCutType_Normal)
			continue;

		nFComp = m_MinCut2Array[i].nComp[0];
		nSComp = m_MinCut2Array[i].nComp[1];

		if (m_CompArray[nFComp].nPhyTyp != PG_BREAKER && m_CompArray[nSComp].nPhyTyp != PG_BREAKER)
			continue;

		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER && m_CompArray[nSComp].nPhyTyp == PG_BREAKER)	//	���ɶ��׸�ľ�Ϊ��·��
		{
			for (nFCm=0; nFCm<(int)m_CompArray[nFComp].sCmCompArray.size(); nFCm++)					//	�豸1�Ĺ�ģ�豸
			{
				nFCmComp=m_CompArray[nFComp].sCmCompArray[nFCm].nCommComp;
				if (nFCmComp == nSComp)																//	�豸1�Ĺ�ģ�豸���豸2��Ϊ����
					continue;

				if (SeekMCut01(m_MinCut1Array, nFCmComp) >= 0)
					continue;
				if (!bBreakerFaultFailure && m_CompArray[nFCmComp].nPhyTyp == PG_BREAKER)					//	���򵽶�·��
					continue;

				for (nSCm=0; nSCm<(int)m_CompArray[nSComp].sCmCompArray.size(); nSCm++)				//	�豸2�Ĺ�ģ�豸
				{
					nSCmComp=m_CompArray[nSComp].sCmCompArray[nSCm].nCommComp;
					if (nSCmComp == nFComp)															//	�豸2�Ĺ�ģ�豸���豸1��Ϊ����
						continue;

					if (SeekMCut01(m_MinCut1Array, nSCmComp) >= 0)
						continue;
					if (!bBreakerFaultFailure && m_CompArray[nSCmComp].nPhyTyp == PG_BREAKER)				//	���򵽶�·��
						continue;

					if (nFCmComp == nSCmComp)														//	��������ͬ��ģ�豸������һ���滻
					{
						sCut1Buf.nCutType = MCREnumCutType_Cut1_Cut2TwoBreakerComm;
						sCut1Buf.nCommonBreaker[0] = nFComp;
						sCut1Buf.nCommonBreaker[1] = nSComp;
						sCut1Buf.nComp = nFCmComp;
						sCut1Buf.fR =m_CompArray[nFCmComp].fRerr;
						sCut1Buf.fT = (m_CompArray[nFComp].sCmCompArray[nFCm].nCommType == 0 && m_CompArray[nSComp].sCmCompArray[nSCm].nCommType == 0) ? m_CompArray[nFCmComp].fTrep : m_CompArray[nFCmComp].fTopr;

						if (sCut1Buf.fR > FLT_MIN && sCut1Buf.fT > FLT_MIN)
						{
#ifdef _DEBUG
							Log(g_lpszLogFile,  "                ˫��·��[%s %s]���ӹ�ģһ�׸�: [%s] R1=%f T1=%f \n", m_CompArray[nFComp].strName.c_str(), m_CompArray[nSComp].strName.c_str(), m_CompArray[nFCmComp].strName.c_str(), sCut1Buf.fR, sCut1Buf.fT);
#endif
							nMCut = SeekCommMCut01(m_CmMCut1Array, nFCmComp);
							if (nMCut < 0)
							{
								m_CmMCut1Array.push_back(sCut1Buf);
							}
							else
							{
								if (sCut1Buf.fR*sCut1Buf.fT > m_CmMCut1Array[nMCut].fR*m_CmMCut1Array[nMCut].fT)
									memcpy(&m_CmMCut1Array[nMCut], &sCut1Buf, sizeof(tagMCRCmMinCut1));
							}
						}
					}
					else
					{
						if (SeekMCut02(m_MinCut2Array, nFCmComp, nSCmComp) >= 0 || SeekCommMCut02(m_CmMCut2Array, nFCmComp, nSCmComp) >= 0)
							continue;

						sCut1Buf.nCutType = MCREnumCutType_Cut2_Cut2OneBreakerComm;
						sCut2Buf.nCommonBreaker[0] = nFComp;
						sCut2Buf.nCommonBreaker[1] = nSComp;
						sCut2Buf.nComp[0]=nFCmComp;
						sCut2Buf.nComp[1]=nSCmComp;

						fR1=m_CompArray[nFCmComp].fRerr;
						fR2=m_CompArray[nSCmComp].fRerr;
						fT1=(m_CompArray[nFComp].sCmCompArray[nFCm].nCommType == 0) ? m_CompArray[nFCmComp].fTrep : m_CompArray[nFCmComp].fTopr;
						fT2=(m_CompArray[nSComp].sCmCompArray[nSCm].nCommType == 0) ? m_CompArray[nSCmComp].fTrep : m_CompArray[nSCmComp].fTopr;

						sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
						if (8760*sCut2Buf.fR > FLT_MIN)
							sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

						if (sCut2Buf.fR > FLT_MIN && sCut2Buf.fT > FLT_MIN)
						{
#ifdef _DEBUG
							Log(g_lpszLogFile,  "˫��·��[%s %s]���ӹ�ģ���׸�: [%s] [%s] R=%f T=%f\n", m_CompArray[nFComp].strName.c_str(), m_CompArray[nSComp].strName.c_str(), m_CompArray[nFCmComp].strName.c_str(), m_CompArray[nSCmComp].strName.c_str(), 1000000*sCut2Buf.fR, sCut2Buf.fT);
#endif
							m_CmMCut2Array.push_back(sCut2Buf);
						}
					}
				}
			}
		}

		if (m_CompArray[nFComp].nPhyTyp == PG_BREAKER)
		{
			for (nComp=0; nComp<(int)m_CompArray[nFComp].sCmCompArray.size(); nComp++)
			{
				nCmComp=m_CompArray[nFComp].sCmCompArray[nComp].nCommComp;
				if (!bBreakerFaultFailure && m_CompArray[nCmComp].nPhyTyp == PG_BREAKER)	//	���򵽶�·��
					continue;

				if (SeekMCut01(m_MinCut1Array, nCmComp) >= 0 ||
					SeekMCut02(m_MinCut2Array, nSComp, nCmComp) >= 0 ||
					SeekCommMCut01(m_CmMCut1Array, nCmComp) >= 0 ||
					SeekCommMCut02(m_CmMCut2Array, nSComp, nCmComp) >= 0)
					continue;

				sCut1Buf.nCutType = MCREnumCutType_Cut2_Cut2OneBreakerComm;
				sCut2Buf.nCommonBreaker[0]=nFComp;
				sCut2Buf.nCommonBreaker[1]=-1;
				sCut2Buf.nComp[0]=nCmComp;
				sCut2Buf.nComp[1]=nSComp;

				fR1=m_CompArray[nCmComp].fRerr;
				fT1=(m_CompArray[nFComp].sCmCompArray[nComp].nCommType == 0) ? m_CompArray[nCmComp].fTrep : m_CompArray[nCmComp].fTopr;
				fR2=m_CompArray[nSComp].fRerr;
				fT2=m_CompArray[nSComp].fTrep;

				sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
				if (8760*sCut2Buf.fR > FLT_MIN)
					sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

				if (sCut2Buf.fR > FLT_MIN && sCut2Buf.fT > FLT_MIN)
				{
#ifdef _DEBUG
					Log(g_lpszLogFile,  "1����·��[%s]���ӹ�ģ���׸� : R=%f T=%f\n", m_CompArray[nFComp].strName.c_str(), 1000000*sCut2Buf.fR, sCut2Buf.fT);
#endif
					m_CmMCut2Array.push_back(sCut2Buf);
				}
			}
		}

		if (m_CompArray[nSComp].nPhyTyp == PG_BREAKER)
		{
			for (nComp=0; nComp<(int)m_CompArray[nSComp].sCmCompArray.size(); nComp++)
			{
				nCmComp=m_CompArray[nSComp].sCmCompArray[nComp].nCommComp;
				if (!bBreakerFaultFailure && m_CompArray[nCmComp].nPhyTyp == PG_BREAKER)	//	���򵽶�·��
					continue;
				if (SeekMCut01(m_MinCut1Array, nCmComp) >= 0 || SeekCommMCut01(m_CmMCut1Array, nCmComp) >= 0 || SeekMCut02(m_MinCut2Array, nFComp, nCmComp) >= 0 || SeekCommMCut02(m_CmMCut2Array, nFComp, nCmComp) >= 0)
					continue;

				sCut1Buf.nCutType = MCREnumCutType_Cut2_Cut2OneBreakerComm;
				sCut2Buf.nCommonBreaker[0]=-1;
				sCut2Buf.nCommonBreaker[1]=nSComp;
				sCut2Buf.nComp[0]=nFComp;
				sCut2Buf.nComp[1]=nCmComp;

				fR1=m_CompArray[nFComp].fRerr;
				fT1=m_CompArray[nFComp].fTrep;
				fR2=m_CompArray[nCmComp].fRerr;
				fT2=(m_CompArray[nSComp].sCmCompArray[nComp].nCommType == 0) ? m_CompArray[nCmComp].fTrep : m_CompArray[nCmComp].fTopr;

				sCut2Buf.fR=fR1*fR2*(fT1+fT2)/8760;
				if (8760*sCut2Buf.fR > FLT_MIN)
					sCut2Buf.fT=(fR1*fR2*fT1*fT2)/(8760*sCut2Buf.fR);

				if (sCut2Buf.fR > FLT_MIN && sCut2Buf.fT > FLT_MIN)
				{
#ifdef _DEBUG
					Log(g_lpszLogFile,  "2����·��[%s]���ӹ�ģ���׸� : R=%f T=%f\n", m_CompArray[nSComp].strName.c_str(), 1000000*sCut2Buf.fR, sCut2Buf.fT);
#endif
					m_CmMCut2Array.push_back(sCut2Buf);
				}
			}
		}
	}

	//���ײ����ǹ�ģ�滻
#ifdef _DEBUG
	Log(g_lpszLogFile,  "--------------------------------------------------------------------------------\n");
	for (i=0; i<(int)m_CmMCut1Array.size(); i++)
	{
		Log(g_lpszLogFile,  "    ��ģ�滻һ����С��[%d/%d]�� %s, %s R=%f T=%f\n", i, m_CmMCut1Array.size(),
			PGGetTableName(m_CompArray[m_CmMCut1Array[i].nComp].nPhyTyp), m_CompArray[m_CmMCut1Array[i].nComp].strName.c_str(),
			m_CmMCut1Array[i].fR, m_CmMCut1Array[i].fT);
	}
	for (i=0; i<(int)m_CmMCut2Array.size(); i++)
	{
		Log(g_lpszLogFile,  "    ��ģ�滻������С��[%d/%d]�� %s, %s    %s, %s R=%f T=%f\n", i, m_CmMCut2Array.size(),
			PGGetTableName(m_CompArray[m_CmMCut2Array[i].nComp[0]].nPhyTyp), m_CompArray[m_CmMCut2Array[i].nComp[0]].strName.c_str(),
			PGGetTableName(m_CompArray[m_CmMCut2Array[i].nComp[1]].nPhyTyp), m_CompArray[m_CmMCut2Array[i].nComp[1]].strName.c_str(),
			1000000*m_CmMCut2Array[i].fR, m_CmMCut2Array[i].fT);
	}
	Log(g_lpszLogFile,  "--------------------------------------------------------------------------------\n");
#endif
}
