#include "StdAfx.h"
#include "MCRPhyData.h"

void CMCRPhyData::PGMemDB2PhyData(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	PGMemDB2PhyData_Bus			(pPGBlock, lpszSub, lpszVolt);
	PGMemDB2PhyData_Line		(pPGBlock, lpszSub, lpszVolt);
	PGMemDB2PhyData_Tran		(pPGBlock, lpszSub, lpszVolt);
	PGMemDB2PhyData_Scap		(pPGBlock, lpszSub, lpszVolt);
	PGMemDB2PhyData_Breaker		(pPGBlock, lpszSub, lpszVolt);
	PGMemDB2PhyData_Disconnector(pPGBlock, lpszSub, lpszVolt);
	PhyTopo();
}

void CMCRPhyData::PGMemDB2PhyData_Bus(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub,nVolt,nDev;
	tagMCRPhyBus	sBusBuffer;

	m_BusArray.clear();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
		{
			if (pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
				continue;

			InitializePhyBus(&sBusBuffer);
			sBusBuffer.strSub = pPGBlock->m_BusbarSectionArray[nDev].szSub;
			sBusBuffer.strVolt = pPGBlock->m_BusbarSectionArray[nDev].szVolt;
			sBusBuffer.strName = pPGBlock->m_BusbarSectionArray[nDev].szName;
			sBusBuffer.strNode = pPGBlock->m_BusbarSectionArray[nDev].szNode;
			sBusBuffer.bByPass = pPGBlock->m_BusbarSectionArray[nDev].bBypass;

			sBusBuffer.fRerr=		pPGBlock->m_BusbarSectionArray[nDev].ri_Rerr;		
			sBusBuffer.fTrep=		pPGBlock->m_BusbarSectionArray[nDev].ri_Trep;		
			sBusBuffer.fRchk=		pPGBlock->m_BusbarSectionArray[nDev].ri_Rchk;		
			sBusBuffer.fTchk=		pPGBlock->m_BusbarSectionArray[nDev].ri_Tchk;		
			sBusBuffer.fTopr=		pPGBlock->m_BusbarSectionArray[nDev].ri_Tfloc;		
			sBusBuffer.fInvest=		pPGBlock->m_BusbarSectionArray[nDev].ei_Invest;		

			m_BusArray.push_back(sBusBuffer);
		}
	}
}

void CMCRPhyData::PGMemDB2PhyData_Line(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub,nVolt,nDev;
	tagMCRPhyLine	sLineBuffer;

	m_LineArray.clear();
	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (stricmp(lpszSub, pPGBlock->m_ACLineSegmentArray[nDev].szSubI) != 0 &&
			stricmp(lpszSub, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ) != 0)
			continue;

		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI) != 0 &&
				stricmp(lpszVolt, pPGBlock->m_ACLineSegmentArray[nDev].szVoltJ) != 0)
				continue;
		}

		InitializePhyLine(&sLineBuffer);
		sLineBuffer.strSubI	=	pPGBlock->m_ACLineSegmentArray[nDev].szSubI;
		sLineBuffer.strSubJ	=	pPGBlock->m_ACLineSegmentArray[nDev].szSubJ;
		sLineBuffer.strNodeI=	pPGBlock->m_ACLineSegmentArray[nDev].szNodeI;
		sLineBuffer.strNodeJ=	pPGBlock->m_ACLineSegmentArray[nDev].szNodeJ;
		sLineBuffer.strVolt	=	pPGBlock->m_ACLineSegmentArray[nDev].szVoltI;
		sLineBuffer.strName	=	pPGBlock->m_ACLineSegmentArray[nDev].szName;

		sLineBuffer.fLength=	pPGBlock->m_ACLineSegmentArray[nDev].fLength;

		sLineBuffer.fRerr=		pPGBlock->m_ACLineSegmentArray[nDev].ri_Rerr;		
		sLineBuffer.fTrep=		pPGBlock->m_ACLineSegmentArray[nDev].ri_Trep;		
		sLineBuffer.fRchk=		pPGBlock->m_ACLineSegmentArray[nDev].ri_Rchk;		
		sLineBuffer.fTchk=		pPGBlock->m_ACLineSegmentArray[nDev].ri_Tchk;		
		sLineBuffer.fTopr=		pPGBlock->m_ACLineSegmentArray[nDev].ri_Tfloc;		
		sLineBuffer.fInvest=	pPGBlock->m_ACLineSegmentArray[nDev].ei_Invest;		

		sLineBuffer.nType =		pPGBlock->m_ACLineSegmentArray[nDev].nMCRType;
		sLineBuffer.fPower =	pPGBlock->m_ACLineSegmentArray[nDev].fMCRPower;

		m_LineArray.push_back(sLineBuffer);
	}

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}

		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
		{
			InitializePhyLine(&sLineBuffer);
			sLineBuffer.strSubI =	pPGBlock->m_EnergyConsumerArray[nDev].szSub;
			sLineBuffer.strVolt =	pPGBlock->m_EnergyConsumerArray[nDev].szVolt;
			sLineBuffer.strName =	pPGBlock->m_EnergyConsumerArray[nDev].szName;
			sLineBuffer.strNodeI =	pPGBlock->m_EnergyConsumerArray[nDev].szNode;
			sLineBuffer.nType =		PGEnumLineTran_MCType_Load;
			sLineBuffer.fPower =	pPGBlock->m_EnergyConsumerArray[nDev].fMCRPower;
			m_LineArray.push_back(sLineBuffer);
		}
	}
}

void CMCRPhyData::PGMemDB2PhyData_Tran(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nDev;
	tagMCRPhyTran	sTranBuffer;

	m_TranArray.clear();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nDev=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(pPGBlock->m_TransformerWindingArray[nDev].szVoltI, lpszVolt) != 0 && stricmp(pPGBlock->m_TransformerWindingArray[nDev].szVoltJ, lpszVolt) != 0)
				continue;
		}

		InitializePhyTran(&sTranBuffer);
		sTranBuffer.strSub	=	pPGBlock->m_TransformerWindingArray[nDev].szSub;
		sTranBuffer.strVoltI=	pPGBlock->m_TransformerWindingArray[nDev].szVoltI;
		sTranBuffer.strVoltJ=	pPGBlock->m_TransformerWindingArray[nDev].szVoltJ;
		sTranBuffer.strName	=	pPGBlock->m_TransformerWindingArray[nDev].szName;
		sTranBuffer.strNodeI=	pPGBlock->m_TransformerWindingArray[nDev].szNodeI;
		sTranBuffer.strNodeJ=	pPGBlock->m_TransformerWindingArray[nDev].szNodeJ;

		sTranBuffer.fRerr=		pPGBlock->m_TransformerWindingArray[nDev].ri_Rerr;		
		sTranBuffer.fTrep=		pPGBlock->m_TransformerWindingArray[nDev].ri_Trep;		
		sTranBuffer.fRchk=		pPGBlock->m_TransformerWindingArray[nDev].ri_Rchk;		
		sTranBuffer.fTchk=		pPGBlock->m_TransformerWindingArray[nDev].ri_Tchk;		
		sTranBuffer.fTopr=		pPGBlock->m_TransformerWindingArray[nDev].ri_Tfloc;		
		sTranBuffer.fInvest=	pPGBlock->m_TransformerWindingArray[nDev].ei_Invest;

		sTranBuffer.nType =		pPGBlock->m_TransformerWindingArray[nDev].nMCRType;
		sTranBuffer.fPower =	pPGBlock->m_TransformerWindingArray[nDev].fMCRPower;

		m_TranArray.push_back(sTranBuffer);
	}
}

void CMCRPhyData::PGMemDB2PhyData_Scap(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub,nVolt,nDev;
	tagMCRPhyScap	sScapBuffer;

	m_ScapArray.clear();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSeriesCompensatorRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSeriesCompensatorRange; nDev++)
		{
			InitializePhyScap(&sScapBuffer);
			sScapBuffer.strSub=pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
			sScapBuffer.strVolt=pPGBlock->m_SeriesCompensatorArray[nDev].szVolt;
			sScapBuffer.strName=pPGBlock->m_SeriesCompensatorArray[nDev].szName;
			sScapBuffer.strNodeI=pPGBlock->m_SeriesCompensatorArray[nDev].szNodeI;
			sScapBuffer.strNodeJ=pPGBlock->m_SeriesCompensatorArray[nDev].szNodeJ;

			sScapBuffer.fRerr=		pPGBlock->m_SeriesCompensatorArray[nDev].ri_Rerr;		
			sScapBuffer.fTrep=		pPGBlock->m_SeriesCompensatorArray[nDev].ri_Trep;		
			sScapBuffer.fRchk=		pPGBlock->m_SeriesCompensatorArray[nDev].ri_Rchk;		
			sScapBuffer.fTchk=		pPGBlock->m_SeriesCompensatorArray[nDev].ri_Tchk;		
			sScapBuffer.fTopr=		pPGBlock->m_SeriesCompensatorArray[nDev].ri_Tfloc;		
			sScapBuffer.fInvest=	pPGBlock->m_SeriesCompensatorArray[nDev].ei_Invest;		

			m_ScapArray.push_back(sScapBuffer);
		}
	}
}

void CMCRPhyData::PGMemDB2PhyData_Breaker(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub,nVolt,nDev;
	tagMCRPhyBreaker	sBreakerBuffer;

	m_BreakerArray.clear();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
		{
			InitializePhyBreaker(&sBreakerBuffer);
			sBreakerBuffer.strSub = pPGBlock->m_BreakerArray[nDev].szSub;
			sBreakerBuffer.strVolt = pPGBlock->m_BreakerArray[nDev].szVolt;
			sBreakerBuffer.strName = pPGBlock->m_BreakerArray[nDev].szName;
			sBreakerBuffer.strNodeI = pPGBlock->m_BreakerArray[nDev].szNodeI;
			sBreakerBuffer.strNodeJ = pPGBlock->m_BreakerArray[nDev].szNodeJ;

			sBreakerBuffer.nType = pPGBlock->m_BreakerArray[nDev].nInnerType;
			sBreakerBuffer.nStatus= pPGBlock->m_BreakerArray[nDev].nStatus;

			sBreakerBuffer.fRerr=		pPGBlock->m_BreakerArray[nDev].ri_Rerr;		
			sBreakerBuffer.fTrep=		pPGBlock->m_BreakerArray[nDev].ri_Trep;		
			sBreakerBuffer.fRchk=		pPGBlock->m_BreakerArray[nDev].ri_Rchk;		
			sBreakerBuffer.fTchk=		pPGBlock->m_BreakerArray[nDev].ri_Tchk;		
			sBreakerBuffer.fTopr=		pPGBlock->m_BreakerArray[nDev].ri_Tfloc;		
			sBreakerBuffer.fTSwitch=	pPGBlock->m_BreakerArray[nDev].ri_TSwitch;		
			sBreakerBuffer.fInvest=		pPGBlock->m_BreakerArray[nDev].ei_Invest;		

			m_BreakerArray.push_back(sBreakerBuffer);
		}
	}
}

void CMCRPhyData::PGMemDB2PhyData_Disconnector(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub,nVolt,nDev;
	tagMCRPhyDisconnector	sDisconnectorBuffer;

	m_DisconnectorArray.clear();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;
	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
		{
			InitializePhyDisconnector(&sDisconnectorBuffer);
			sDisconnectorBuffer.strSub = pPGBlock->m_DisconnectorArray[nDev].szSub;
			sDisconnectorBuffer.strVolt = pPGBlock->m_DisconnectorArray[nDev].szVolt;
			sDisconnectorBuffer.strName = pPGBlock->m_DisconnectorArray[nDev].szName;
			sDisconnectorBuffer.strNodeI = pPGBlock->m_DisconnectorArray[nDev].szNodeI;
			sDisconnectorBuffer.strNodeJ = pPGBlock->m_DisconnectorArray[nDev].szNodeJ;

			sDisconnectorBuffer.nType = pPGBlock->m_DisconnectorArray[nDev].nInnerType;
			sDisconnectorBuffer.nStatus= pPGBlock->m_DisconnectorArray[nDev].nStatus;

			sDisconnectorBuffer.fRerr=		pPGBlock->m_DisconnectorArray[nDev].ri_Rerr;		
			sDisconnectorBuffer.fTrep=		pPGBlock->m_DisconnectorArray[nDev].ri_Trep;		
			sDisconnectorBuffer.fRchk=		pPGBlock->m_DisconnectorArray[nDev].ri_Rchk;		
			sDisconnectorBuffer.fTchk=		pPGBlock->m_DisconnectorArray[nDev].ri_Tchk;		
			sDisconnectorBuffer.fTopr=		pPGBlock->m_DisconnectorArray[nDev].ri_Tfloc;		
			sDisconnectorBuffer.fTSwitch=	pPGBlock->m_DisconnectorArray[nDev].ri_TSwitch;		
			sDisconnectorBuffer.fInvest=	pPGBlock->m_DisconnectorArray[nDev].ei_Invest;		

			m_DisconnectorArray.push_back(sDisconnectorBuffer);
		}
	}
}

void	CMCRPhyData::AppendSubstationVoltageLevel(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	register int	i;
	unsigned char	bExist;

	bExist=0;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		if (strcmp(pPGBlock->m_SubstationArray[i].szName, lpszSub) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
	{
		memset(&pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]], 0, sizeof(tagPGSubstation));
		strcpy(pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]].szName,			lpszSub);
		pPGBlock->m_nRecordNum[PG_SUBSTATION]++;
	}

	for (i=0; i<pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]; i++)
	{
		if (strcmp(pPGBlock->m_VoltageLevelArray[i].szSub, lpszSub) == 0 && strcmp(pPGBlock->m_VoltageLevelArray[i].szName, lpszVolt) == 0)
			return;
	}

	memset(&pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]], 0, sizeof(tagPGVoltageLevel));
	strcpy(pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szSub,	lpszSub);
	strcpy(pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szName,	lpszVolt);
	pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]++;

	return;
}

void CMCRPhyData::PhyData2PGMemDB(tagPGBlock* pPGBlock)
{
	register int	i;
	int		nTable;

	for (nTable=0; nTable<MAXMDBTABLENUM; nTable++)
		pPGBlock->m_nRecordNum[nTable] = 0;
	pPGBlock->m_nRecordNum[PG_SYSTEM] = 1;

	for (i=0; i<(int)m_BusArray.size(); i++)
	{
		AppendSubstationVoltageLevel(pPGBlock, m_BusArray[i].strSub.c_str(), m_BusArray[i].strVolt.c_str());

		memset(&pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]], 0, sizeof(tagPGBusbarSection));

		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szSub,		m_BusArray[i].strSub .c_str());
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szVolt,		m_BusArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szName,		m_BusArray[i].strName.c_str());
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szNode,		m_BusArray[i].strNode.c_str());
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].ri_Rerr =			(float)m_BusArray[i].fRerr;
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].ri_Trep =			(float)m_BusArray[i].fTrep;
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].ri_Rchk =			(float)m_BusArray[i].fRchk;
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].ri_Tchk =			(float)m_BusArray[i].fTchk;
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].ri_Tfloc =			(float)m_BusArray[i].fTopr;
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].ei_Invest =		(float)m_BusArray[i].fInvest;
		pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].bBypass =			m_BusArray[i].bByPass;
		pPGBlock->m_nRecordNum[PG_BUSBARSECTION]++;
	}

	for (i=0; i<(int)m_LineArray.size(); i++)
	{
		AppendSubstationVoltageLevel(pPGBlock, m_LineArray[i].strSubI.c_str(), m_LineArray[i].strVolt.c_str());
		AppendSubstationVoltageLevel(pPGBlock, m_LineArray[i].strSubJ.c_str(), m_LineArray[i].strVolt.c_str());

		memset(&pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]], 0, sizeof(tagPGACLineSegment));

		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubI,		m_LineArray[i].strSubI.c_str());
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubJ,		m_LineArray[i].strSubJ.c_str());
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltI,	m_LineArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltJ,	m_LineArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szName,		m_LineArray[i].strName.c_str());
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeI,	m_LineArray[i].strNodeI.c_str());
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeJ,	m_LineArray[i].strNodeJ.c_str());

		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].nMCRType =			m_LineArray[i].nType;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fMCRPower =		(float)m_LineArray[i].fPower;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fLength =			(float)m_LineArray[i].fLength;

		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Rerr =			(float)m_LineArray[i].fRerr;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Trep =			(float)m_LineArray[i].fTrep;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Rchk =			(float)m_LineArray[i].fRchk;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Tchk =			(float)m_LineArray[i].fTchk;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Tfloc =			(float)m_LineArray[i].fTopr;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].ei_Invest =		(float)m_LineArray[i].fInvest;
		pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]++;
	}

	for (i=0; i<(int)m_TranArray.size(); i++)
	{
		AppendSubstationVoltageLevel(pPGBlock, m_TranArray[i].strSub.c_str(), m_TranArray[i].strVoltI.c_str());
		AppendSubstationVoltageLevel(pPGBlock, m_TranArray[i].strSub.c_str(), m_TranArray[i].strVoltJ.c_str());

		memset(&pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));

		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub,	m_TranArray[i].strSub.c_str());
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI,	m_TranArray[i].strVoltI.c_str());
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ,	m_TranArray[i].strVoltJ.c_str());
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName,	m_TranArray[i].strName.c_str());
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI,	m_TranArray[i].strNodeI.c_str());
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ,	m_TranArray[i].strNodeJ.c_str());

		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].nMCRType =		m_TranArray[i].nType;
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fMCRPower =		(float)m_TranArray[i].fPower;

		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Rerr =		(float)m_TranArray[i].fRerr;
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Trep =		(float)m_TranArray[i].fTrep;
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Rchk =		(float)m_TranArray[i].fRchk;
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Tchk =		(float)m_TranArray[i].fTchk;
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Tfloc =		(float)m_TranArray[i].fTopr;
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ei_Invest =		(float)m_TranArray[i].fInvest;
		pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;
	}

	for (i=0; i<(int)m_ScapArray.size(); i++)
	{
		AppendSubstationVoltageLevel(pPGBlock, m_ScapArray[i].strSub.c_str(), m_ScapArray[i].strVolt.c_str());

		memset(&pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]], 0, sizeof(tagPGTransformerWinding));

		strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szSub,		m_ScapArray[i].strSub.c_str());
		strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szVolt,		m_ScapArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szName,		m_ScapArray[i].strName.c_str());
		strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szNodeI,	m_ScapArray[i].strNodeI.c_str());
		strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szNodeJ,	m_ScapArray[i].strNodeJ.c_str());
		pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].ri_Rerr =			(float)m_ScapArray[i].fRerr;
		pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].ri_Trep =			(float)m_ScapArray[i].fTrep;
		pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].ri_Rchk =			(float)m_ScapArray[i].fRchk;
		pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].ri_Tchk =			(float)m_ScapArray[i].fTchk;
		pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].ri_Tfloc =			(float)m_ScapArray[i].fTopr;
		pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].ei_Invest =		(float)m_ScapArray[i].fInvest;
		pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]++;
	}

	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		AppendSubstationVoltageLevel(pPGBlock, m_BreakerArray[i].strSub.c_str(), m_BreakerArray[i].strVolt.c_str());

		memset(&pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]], 0, sizeof(tagPGTransformerWinding));

		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szSub,		m_BreakerArray[i].strSub.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szVolt,		m_BreakerArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szName,		m_BreakerArray[i].strName.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szNodeI,	m_BreakerArray[i].strNodeI.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szNodeJ,	m_BreakerArray[i].strNodeJ.c_str());
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ri_Rerr =			(float)m_BreakerArray[i].fRerr;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ri_Trep =			(float)m_BreakerArray[i].fTrep;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ri_Rchk =			(float)m_BreakerArray[i].fRchk;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ri_Tchk =			(float)m_BreakerArray[i].fTchk;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ri_Tfloc =			(float)m_BreakerArray[i].fTopr;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ri_TSwitch =		(float)m_BreakerArray[i].fTSwitch;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].ei_Invest =		(float)m_BreakerArray[i].fInvest;

		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].nCTLocation =		m_BreakerArray[i].nCTLoc;
		pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].nStatus =			m_BreakerArray[i].nStatus;

		pPGBlock->m_nRecordNum[PG_BREAKER]++;
	}

	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		AppendSubstationVoltageLevel(pPGBlock, m_DisconnectorArray[i].strSub.c_str(), m_DisconnectorArray[i].strVolt.c_str());

		memset(&pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]], 0, sizeof(tagPGTransformerWinding));

		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szSub,	m_DisconnectorArray[i].strSub.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szVolt,	m_DisconnectorArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szName,	m_DisconnectorArray[i].strName.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szNodeI,	m_DisconnectorArray[i].strNodeI.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szNodeJ,	m_DisconnectorArray[i].strNodeJ.c_str());
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ri_Rerr =		(float)m_DisconnectorArray[i].fRerr;
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ri_Trep =		(float)m_DisconnectorArray[i].fTrep;
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ri_Rchk =		(float)m_DisconnectorArray[i].fRchk;
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ri_Tchk =		(float)m_DisconnectorArray[i].fTchk;
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ri_Tfloc =		(float)m_DisconnectorArray[i].fTopr;
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ri_TSwitch =		(float)m_DisconnectorArray[i].fTSwitch;
		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].ei_Invest =		(float)m_DisconnectorArray[i].fInvest;

		pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].nStatus =		m_DisconnectorArray[i].nStatus;

		pPGBlock->m_nRecordNum[PG_DISCONNECTOR]++;
	}

	PGMaint(pPGBlock);
}
