#include "StdAfx.h"
#include <process.h>
#include "MCRCommon.h"
#include "MCRAlgorithm.h"

const char* g_lpszMCREstimateSemaphore = "MCREstimateSemaphore";

extern	CMCRAlgorithm	g_MCRAlgorithm;
extern	CMCRPhyData		g_MCRPhyData;

extern	HANDLE	InitSem(const char* lpszSemKey);
extern	HANDLE	SemOn(const char* lpszSemKey, const int nMillionSecond);
extern	void	SemOff(HANDLE hSem);

unsigned int __stdcall  MCREstimateCalThreaad(void* lParam)
{
	register int	i;
	int		nEstimatePace, nEstimateType, nEstimateDev;
	clock_t	dBeg, dEnd;
	int		nDur;

	dBeg=clock();

	tagMCRThreadInfo*	pThreadInfo = (tagMCRThreadInfo*)lParam;
	CMCRAlgorithm* pMCRAlg = new CMCRAlgorithm();
	if (!pMCRAlg)
		return 0;
	pMCRAlg->CloneAlgData(&g_MCRAlgorithm);

	nEstimatePace = 0;
	while (TRUE)
	{
		nEstimateType = nEstimateDev = -1;

		HANDLE hSem = SemOn(g_lpszMCREstimateSemaphore, 1000);
		if (hSem != INVALID_HANDLE_VALUE)
		{
			if (nEstimateType < 0)
			{
				if (!g_MCRAlgorithm.m_AugGen.bEstimated)
				{
					nEstimateType = 3;
					nEstimateDev = 0;
					g_MCRAlgorithm.m_AugGen.bEstimated = 1;
				}
			}
			if (nEstimateType < 0)
			{
				if (!g_MCRAlgorithm.m_AugLoad.bEstimated)
				{
					nEstimateType = 2;
					nEstimateDev = 0;
					g_MCRAlgorithm.m_AugLoad.bEstimated = 1;
				}
			}
			if (nEstimateType < 0)
			{
				for (i=0; i<(int)g_MCRAlgorithm.m_GenArray.size(); i++)	//ѭ��ÿ�����ɵ�
				{
					if (!g_MCRAlgorithm.m_GenArray[i].bEstimated)
					{
						nEstimateType = 1;
						nEstimateDev = i;
						g_MCRAlgorithm.m_GenArray[i].bEstimated = 1;
						break;
					}
				}
			}
			if (nEstimateType < 0)
			{
				for (i=0; i<(int)g_MCRAlgorithm.m_LoadArray.size(); i++)	//ѭ��ÿ�����ɵ�
				{
					if (!g_MCRAlgorithm.m_LoadArray[i].bEstimated)
					{
						nEstimateType = 0;
						nEstimateDev = i;
						g_MCRAlgorithm.m_LoadArray[i].bEstimated = 1;
						break;
					}
				}
			}

			SemOff(hSem);
		}
		else
		{
			Log(g_lpszLogFile, "��ȡ״̬����������\n");
		}

		if (nEstimateType < 0 || nEstimateDev < 0)
			break;

		switch (nEstimateType)
		{
		case	0:
			dBeg=clock();
				pMCRAlg->CalculateLoadReliability(&g_MCRPhyData, nEstimateDev, pThreadInfo->bFault1Plan, pThreadInfo->bExCommon, pThreadInfo->bExSwitch, pThreadInfo->bBreakerFaultFailure);
			dEnd=clock();
			nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
			break;
		case	1:
			dBeg=clock();
				pMCRAlg->CalculateGenReliability(&g_MCRPhyData, nEstimateDev, pThreadInfo->bFault1Plan, pThreadInfo->bExCommon, pThreadInfo->bExSwitch, pThreadInfo->bBreakerFaultFailure);
			dEnd=clock();
			nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
			break;
		case	2:
			pMCRAlg->CalculateAugLoadReliablity(&g_MCRPhyData, pThreadInfo->bFault1Plan, pThreadInfo->bExCommon, pThreadInfo->bExSwitch, pThreadInfo->bBreakerFaultFailure);
			break;
		case	3:
			pMCRAlg->CalculateAugGenReliablity(&g_MCRPhyData, pThreadInfo->bFault1Plan, pThreadInfo->bExCommon, pThreadInfo->bExSwitch, pThreadInfo->bBreakerFaultFailure);
			break;
		}

		nEstimatePace++;
		if (nEstimatePace > 0)
			PostThreadMessage(pThreadInfo->nParentThreadID, TM_ESTIMATING, 1, 0);
	}

	delete pMCRAlg;
	free(pThreadInfo);

	_endthreadex(0);

	return 0;
}

unsigned int __stdcall  MCREstimateConThreaad(void* lParam)
{
	register int		i;
	clock_t				dBeg, dEnd;
	int					nDur;
	unsigned int		nChildThreadID;
	std::vector<HANDLE>	hThreadArray;

	dBeg = clock();

	tagMCRThreadInfo*	pParentThreadInfo = (tagMCRThreadInfo*)lParam;
	for (i=0; i<(int)g_MCRAlgorithm.m_LoadArray.size(); i++)
		g_MCRAlgorithm.m_LoadArray[i].bEstimated = 0;
	for (i=0; i<(int)g_MCRAlgorithm.m_GenArray.size(); i++)
		g_MCRAlgorithm.m_GenArray[i].bEstimated = 0;

	SYSTEM_INFO sysInfo;
	::GetSystemInfo(&sysInfo);
	int		nThreadNum = pParentThreadInfo->nThreadNum;
	if (nThreadNum <= 1)
		nThreadNum = 1;
	else if (nThreadNum > (int)sysInfo.dwNumberOfProcessors)
		nThreadNum=(int)sysInfo.dwNumberOfProcessors;

	hThreadArray.resize(nThreadNum);
	for (i=0; i<nThreadNum; i++)
		hThreadArray[i] = INVALID_HANDLE_VALUE;
	HANDLE hEstStateSem = InitSem(g_lpszMCREstimateSemaphore);

	int		nEstimateTotal=(int)(g_MCRAlgorithm.m_LoadArray.size()+g_MCRAlgorithm.m_GenArray.size()+2);
	PostThreadMessage(pParentThreadInfo->nParentThreadID, TM_ESTIMATEBEG, nEstimateTotal, 0);

	for (i=0; i<nThreadNum; i++)
	{
		tagMCRThreadInfo*	pInfo=(tagMCRThreadInfo*)malloc(sizeof(tagMCRThreadInfo));
		memcpy(pInfo, pParentThreadInfo, sizeof(tagMCRThreadInfo));
		pInfo->nThreadID = i+1;
		hThreadArray[i] = (HANDLE)_beginthreadex(NULL, 0, &MCREstimateCalThreaad, (void*)pInfo, 0, &nChildThreadID);
	}

	for (i=0; i<(int)hThreadArray.size(); i++)
	{
		DWORD dwRet=WaitForSingleObject(hThreadArray[i], INFINITE);

		if (dwRet == WAIT_OBJECT_0)
			Log(g_lpszLogFile, "        �����߿ɿ��������������[%d]���\n", i+1);
		else
			Log(g_lpszLogFile, "        �����߿ɿ��������������[%d]���� RetCode = %d\n", i+1, dwRet);

		if (hThreadArray[i] != INVALID_HANDLE_VALUE)
			CloseHandle(hThreadArray[i]);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�ɿ��Թ���ģʽ������ɣ���ʱ %d ����", nDur);

	g_MCRPhyData.MCRSysIndex();
	g_MCRPhyData.MCRDevIndex();
	g_MCRPhyData.MCREconomy(pParentThreadInfo->nLifeTime, pParentThreadInfo->fEPrice, pParentThreadInfo->fRecip, pParentThreadInfo->fEValueRatio, pParentThreadInfo->fPowerFactor);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�ɿ���ָ�������ɣ���ʱ %d ����", nDur);

	PostThreadMessage(pParentThreadInfo->nParentThreadID, TM_ESTIMATEEND, nEstimateTotal, 0);

	g_MCRPhyData.SaveMCReliabilityResult(pParentThreadInfo->szResultXmlFile, pParentThreadInfo->fFmodeRThreshold, pParentThreadInfo->fFmodeUThreshold);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�ɿ��Լ����������ɣ���ʱ %d ����", nDur);

	CloseHandle(hEstStateSem);

	free(pParentThreadInfo);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "�����߿ɿ������� ��ɣ���ʱ %d ����\n", nDur);

	_endthreadex( 0 );

	return 0;
}
