#include "StdAfx.h"
#include "MCRAlgorithm.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

void	CMCRAlgorithm::Alg2PlyMCut(const double fR, const double fU, std::vector<tagMCRPhyPath>& sMinPathArray, std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array)
{
	int	nComp, nPath, nMCut;
	tagMCRPhyPath sPathBuf;
	tagMCRPhyFault1 sCut1Buf;
	tagMCRPhyFault2 sCut2Buf;
	tagMCRPhyFault3 sCut3Buf;

	//////////////////////////////////////////////////////////////////////////
	//	·����ֵ
	for (nPath=0; nPath<(int)m_MinPathArray.size(); nPath++)
	{
		if (m_MinPathArray[nPath].nCompArray.empty())
			continue;
		if (m_MinPathArray[nPath].nStatus != 0)
			continue;

		sPathBuf.sCompArray.resize(m_MinPathArray[nPath].nCompArray.size());
		for (nComp=0; nComp<(int)m_MinPathArray[nPath].nCompArray.size(); nComp++)
		{
			memset(&sPathBuf.sCompArray[nComp], 0, sizeof(tagMCRPhyComp));
			sPathBuf.sCompArray[nComp].nCompTyp = m_CompArray[m_MinPathArray[nPath].nCompArray[nComp]].nPhyTyp;
			sPathBuf.sCompArray[nComp].nCompIdx = m_CompArray[m_MinPathArray[nPath].nCompArray[nComp]].nPhyIdx;
			sPathBuf.sCompArray[nComp].fRerr = m_CompArray[m_MinPathArray[nPath].nCompArray[nComp]].fRerr;
			sPathBuf.sCompArray[nComp].fTrep = m_CompArray[m_MinPathArray[nPath].nCompArray[nComp]].fTrep;
		}
		sMinPathArray.push_back(sPathBuf);
	}

	//////////////////////////////////////////////////////////////////////////
	//	���ֵ
	for (nMCut=0; nMCut<(int)m_MinCut1Array.size(); nMCut++)
	{
		if (m_MinCut1Array[nMCut].fR < g_fMininalValue)
			continue;

		memset(&sCut1Buf, 0, sizeof(tagMCRPhyFault1));

		sCut1Buf.sComp.nCompTyp = m_CompArray[m_MinCut1Array[nMCut].nComp].nPhyTyp;
		sCut1Buf.sComp.nCompIdx = m_CompArray[m_MinCut1Array[nMCut].nComp].nPhyIdx;
		sCut1Buf.sComp.fRerr = m_CompArray[m_MinCut1Array[nMCut].nComp].fRerr;
		sCut1Buf.sComp.fTrep = m_CompArray[m_MinCut1Array[nMCut].nComp].fTrep;

		if (m_MinCut1Array[nMCut].nSwitchComp >= 0)
		{
			sCut1Buf.sSwitchComp.nCompTyp = m_CompArray[m_MinCut1Array[nMCut].nSwitchComp].nPhyTyp;
			sCut1Buf.sSwitchComp.nCompIdx = m_CompArray[m_MinCut1Array[nMCut].nSwitchComp].nPhyIdx;
		}

		sCut1Buf.nFType		= m_MinCut1Array[nMCut].nCutType	;
		sCut1Buf.fR			= m_MinCut1Array[nMCut].fR		;
		sCut1Buf.fT			= m_MinCut1Array[nMCut].fT		;
		sCut1Buf.fFaultR	= m_MinCut1Array[nMCut].fFaultR	;
		sCut1Buf.fFaultT	= m_MinCut1Array[nMCut].fFaultT	;
		sCut1Buf.fPlanR		= m_MinCut1Array[nMCut].fPlanR	;
		sCut1Buf.fPlanT		= m_MinCut1Array[nMCut].fPlanT	;

		if (m_MinCut1Array[nMCut].nCutType == MCREnumCutType_2Degree1)
		{
			for (nComp=0; nComp<2; nComp++)
			{
				sCut1Buf.sDegreeComp[nComp].nCompTyp = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].nPhyTyp;
				sCut1Buf.sDegreeComp[nComp].nCompIdx = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].nPhyIdx;
				sCut1Buf.sDegreeComp[nComp].fRerr = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].fRerr;
				sCut1Buf.sDegreeComp[nComp].fTrep = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].fTrep;
			}
		}
		else if (m_MinCut1Array[nMCut].nCutType == MCREnumCutType_3Degree1)
		{
			for (nComp=0; nComp<3; nComp++)
			{
				sCut1Buf.sDegreeComp[nComp].nCompTyp = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].nPhyTyp;
				sCut1Buf.sDegreeComp[nComp].nCompIdx = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].nPhyIdx;
				sCut1Buf.sDegreeComp[nComp].fRerr = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].fRerr;
				sCut1Buf.sDegreeComp[nComp].fTrep = m_CompArray[m_MinCut1Array[nMCut].nDegreeComp[nComp]].fTrep;
			}
		}

		if (sCut1Buf.fR*sCut1Buf.fT > g_fZeroThreashold || sCut1Buf.fFaultR*sCut1Buf.fFaultT > g_fZeroThreashold || sCut1Buf.fPlanR*sCut1Buf.fPlanT > g_fZeroThreashold)
			sFault1Array.push_back(sCut1Buf);
	}

	for (nMCut=0; nMCut<(int)m_MinCut2Array.size(); nMCut++)
	{
		if (m_MinCut2Array[nMCut].fR < g_fMininalValue)
			continue;

		memset(&sCut2Buf, 0, sizeof(tagMCRPhyFault2));

		sCut2Buf.sComp[0].nCompTyp = m_CompArray[m_MinCut2Array[nMCut].nComp[0]].nPhyTyp;
		sCut2Buf.sComp[0].nCompIdx = m_CompArray[m_MinCut2Array[nMCut].nComp[0]].nPhyIdx;
		sCut2Buf.sComp[0].fRerr = m_CompArray[m_MinCut2Array[nMCut].nComp[0]].fRerr;
		sCut2Buf.sComp[0].fTrep = m_CompArray[m_MinCut2Array[nMCut].nComp[0]].fTrep;

		sCut2Buf.sComp[1].nCompTyp = m_CompArray[m_MinCut2Array[nMCut].nComp[1]].nPhyTyp;
		sCut2Buf.sComp[1].nCompIdx = m_CompArray[m_MinCut2Array[nMCut].nComp[1]].nPhyIdx;
		sCut2Buf.sComp[1].fRerr = m_CompArray[m_MinCut2Array[nMCut].nComp[1]].fRerr;
		sCut2Buf.sComp[1].fTrep = m_CompArray[m_MinCut2Array[nMCut].nComp[1]].fTrep;

		if (m_MinCut2Array[nMCut].nSwitchComp[0] >= 0)
		{
			sCut2Buf.sSwitchComp[0].nCompTyp = m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[0]].nPhyTyp;
			sCut2Buf.sSwitchComp[0].nCompIdx = m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[0]].nPhyIdx;
		}
		if (m_MinCut2Array[nMCut].nSwitchComp[1] >= 0)
		{
			sCut2Buf.sSwitchComp[1].nCompTyp = m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[1]].nPhyTyp;
			sCut2Buf.sSwitchComp[1].nCompIdx = m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[1]].nPhyIdx;
		}

		sCut2Buf.nFType		= m_MinCut2Array[nMCut].nCutType	;
		sCut2Buf.fR			= m_MinCut2Array[nMCut].fR		;
		sCut2Buf.fT			= m_MinCut2Array[nMCut].fT		;
		sCut2Buf.fFaultR	= m_MinCut2Array[nMCut].fFaultR	;
		sCut2Buf.fFaultT	= m_MinCut2Array[nMCut].fFaultT	;
		sCut2Buf.fPlanR		= m_MinCut2Array[nMCut].fPlanR	;
		sCut2Buf.fPlanT		= m_MinCut2Array[nMCut].fPlanT	;

		if (m_MinCut2Array[nMCut].nCutType == MCREnumCutType_3Degree2)
		{
			for (nComp=0; nComp<3; nComp++)
			{
				sCut2Buf.sDegreeComp[nComp].nCompTyp = m_CompArray[m_MinCut2Array[nMCut].nDegreeComp[nComp]].nPhyTyp;
				sCut2Buf.sDegreeComp[nComp].nCompIdx = m_CompArray[m_MinCut2Array[nMCut].nDegreeComp[nComp]].nPhyIdx;
				sCut2Buf.sDegreeComp[nComp].fRerr = m_CompArray[m_MinCut2Array[nMCut].nDegreeComp[nComp]].fRerr;
				sCut2Buf.sDegreeComp[nComp].fTrep = m_CompArray[m_MinCut2Array[nMCut].nDegreeComp[nComp]].fTrep;
			}
		}

		if (sCut2Buf.fR*sCut2Buf.fT > g_fZeroThreashold || sCut2Buf.fFaultR*sCut2Buf.fFaultT > g_fZeroThreashold || sCut2Buf.fPlanR*sCut2Buf.fPlanT > g_fZeroThreashold)
			sFault2Array.push_back(sCut2Buf);
	}

	for (nMCut=0; nMCut<(int)m_MinCut3Array.size(); nMCut++)
	{
		if (m_MinCut3Array[nMCut].fR < g_fMininalValue)
			continue;

		memset(&sCut3Buf, 0, sizeof(tagMCRPhyFault3));

		sCut3Buf.sComp[0].nCompTyp = m_CompArray[m_MinCut3Array[nMCut].nComp[0]].nPhyTyp;
		sCut3Buf.sComp[0].nCompIdx = m_CompArray[m_MinCut3Array[nMCut].nComp[0]].nPhyIdx;
		sCut3Buf.sComp[0].fRerr = m_CompArray[m_MinCut3Array[nMCut].nComp[0]].fRerr;
		sCut3Buf.sComp[0].fTrep = m_CompArray[m_MinCut3Array[nMCut].nComp[0]].fTrep;

		sCut3Buf.sComp[1].nCompTyp = m_CompArray[m_MinCut3Array[nMCut].nComp[1]].nPhyTyp;
		sCut3Buf.sComp[1].nCompIdx = m_CompArray[m_MinCut3Array[nMCut].nComp[1]].nPhyIdx;
		sCut3Buf.sComp[1].fRerr = m_CompArray[m_MinCut3Array[nMCut].nComp[1]].fRerr;
		sCut3Buf.sComp[1].fTrep = m_CompArray[m_MinCut3Array[nMCut].nComp[1]].fTrep;

		sCut3Buf.sComp[2].nCompTyp = m_CompArray[m_MinCut3Array[nMCut].nComp[2]].nPhyTyp;
		sCut3Buf.sComp[2].nCompIdx = m_CompArray[m_MinCut3Array[nMCut].nComp[2]].nPhyIdx;
		sCut3Buf.sComp[2].fRerr = m_CompArray[m_MinCut3Array[nMCut].nComp[2]].fRerr;
		sCut3Buf.sComp[2].fTrep = m_CompArray[m_MinCut3Array[nMCut].nComp[2]].fTrep;

		if (m_MinCut3Array[nMCut].nSwitchComp[0] >= 0)
		{
			sCut3Buf.sSwitchComp[0].nCompTyp = m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[0]].nPhyTyp;
			sCut3Buf.sSwitchComp[0].nCompIdx = m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[0]].nPhyIdx;
		}
		if (m_MinCut3Array[nMCut].nSwitchComp[1] >= 0)
		{
			sCut3Buf.sSwitchComp[1].nCompTyp = m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[1]].nPhyTyp;
			sCut3Buf.sSwitchComp[1].nCompIdx = m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[1]].nPhyIdx;
		}
		if (m_MinCut3Array[nMCut].nSwitchComp[2] >= 0)
		{
			sCut3Buf.sSwitchComp[2].nCompTyp = m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[2]].nPhyTyp;
			sCut3Buf.sSwitchComp[2].nCompIdx = m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[2]].nPhyIdx;
		}

		sCut3Buf.nFType		= m_MinCut3Array[nMCut].nCutType	;
		sCut3Buf.fR			= m_MinCut3Array[nMCut].fR		;
		sCut3Buf.fT			= m_MinCut3Array[nMCut].fT		;
		sCut3Buf.fFaultR	= m_MinCut3Array[nMCut].fFaultR	;
		sCut3Buf.fFaultT	= m_MinCut3Array[nMCut].fFaultT	;
		sCut3Buf.fPlanR		= m_MinCut3Array[nMCut].fPlanR	;
		sCut3Buf.fPlanT		= m_MinCut3Array[nMCut].fPlanT	;

		if (sCut3Buf.fR*sCut3Buf.fT > g_fZeroThreashold || sCut3Buf.fFaultR*sCut3Buf.fFaultT > g_fZeroThreashold || sCut3Buf.fPlanR*sCut3Buf.fPlanT > g_fZeroThreashold)
			sFault3Array.push_back(sCut3Buf);
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ģ���ֵ
	for (nMCut=0; nMCut<(int)m_CmMCut1Array.size(); nMCut++)
	{
		if (m_CmMCut1Array[nMCut].fR < g_fMininalValue)
			continue;

		memset(&sCut1Buf, 0, sizeof(tagMCRPhyFault1));

		sCut1Buf.sComp.nCompTyp = m_CompArray[m_CmMCut1Array[nMCut].nComp].nPhyTyp;
		sCut1Buf.sComp.nCompIdx = m_CompArray[m_CmMCut1Array[nMCut].nComp].nPhyIdx;
		sCut1Buf.sComp.fRerr = m_CompArray[m_CmMCut1Array[nMCut].nComp].fRerr;
		sCut1Buf.sComp.fTrep = m_CompArray[m_CmMCut1Array[nMCut].nComp].fTrep;

		sCut1Buf.nFType		= m_CmMCut1Array[nMCut].nCutType	;
		sCut1Buf.fR			= m_CmMCut1Array[nMCut].fR	;
		sCut1Buf.fT			= m_CmMCut1Array[nMCut].fT	;
		sCut1Buf.fFaultR	= m_CmMCut1Array[nMCut].fR	;
		sCut1Buf.fFaultT	= m_CmMCut1Array[nMCut].fT	;

		if (sCut1Buf.fR*sCut1Buf.fT > g_fZeroThreashold || sCut1Buf.fFaultR*sCut1Buf.fFaultT > g_fZeroThreashold || sCut1Buf.fPlanR*sCut1Buf.fPlanT > g_fZeroThreashold)
		{
			if (m_CmMCut1Array[nMCut].nCommonBreaker[0] >= 0)
			{
				sCut1Buf.sCommonBreaker[0].nCompTyp = m_CompArray[m_CmMCut1Array[nMCut].nCommonBreaker[0]].nPhyTyp;
				sCut1Buf.sCommonBreaker[0].nCompIdx = m_CompArray[m_CmMCut1Array[nMCut].nCommonBreaker[0]].nPhyIdx;
			}
			if (m_CmMCut1Array[nMCut].nCommonBreaker[1] >= 0)
			{
				sCut1Buf.sCommonBreaker[1].nCompTyp = m_CompArray[m_CmMCut1Array[nMCut].nCommonBreaker[1]].nPhyTyp;
				sCut1Buf.sCommonBreaker[1].nCompIdx = m_CompArray[m_CmMCut1Array[nMCut].nCommonBreaker[1]].nPhyIdx;
			}
			sFault1Array.push_back(sCut1Buf);
		}
	}

	for (nMCut=0; nMCut<(int)m_CmMCut2Array.size(); nMCut++)
	{
		if (m_CmMCut2Array[nMCut].fR < g_fMininalValue)
			continue;

		memset(&sCut2Buf, 0, sizeof(tagMCRPhyFault2));

		sCut2Buf.sComp[0].nCompTyp = m_CompArray[m_CmMCut2Array[nMCut].nComp[0]].nPhyTyp;
		sCut2Buf.sComp[0].nCompIdx = m_CompArray[m_CmMCut2Array[nMCut].nComp[0]].nPhyIdx;
		sCut2Buf.sComp[0].fRerr = m_CompArray[m_CmMCut2Array[nMCut].nComp[0]].fRerr;
		sCut2Buf.sComp[0].fTrep = m_CompArray[m_CmMCut2Array[nMCut].nComp[0]].fTrep;

		sCut2Buf.sComp[1].nCompTyp = m_CompArray[m_CmMCut2Array[nMCut].nComp[1]].nPhyTyp;
		sCut2Buf.sComp[1].nCompIdx = m_CompArray[m_CmMCut2Array[nMCut].nComp[1]].nPhyIdx;
		sCut2Buf.sComp[1].fRerr = m_CompArray[m_CmMCut2Array[nMCut].nComp[1]].fRerr;
		sCut2Buf.sComp[1].fTrep = m_CompArray[m_CmMCut2Array[nMCut].nComp[1]].fTrep;

		sCut2Buf.nFType		= m_CmMCut2Array[nMCut].nCutType	;
		sCut2Buf.fR			= m_CmMCut2Array[nMCut].fR	;
		sCut2Buf.fT			= m_CmMCut2Array[nMCut].fT	;
		sCut2Buf.fFaultR	= m_CmMCut2Array[nMCut].fR	;
		sCut2Buf.fFaultT	= m_CmMCut2Array[nMCut].fT	;

		if (sCut2Buf.fR*sCut2Buf.fT > g_fZeroThreashold || sCut2Buf.fFaultR*sCut2Buf.fFaultT > g_fZeroThreashold || sCut2Buf.fPlanR*sCut2Buf.fPlanT > g_fZeroThreashold)
		{
			if (m_CmMCut2Array[nMCut].nCommonBreaker[0] >= 0)
			{
				sCut2Buf.sCommonBreaker[0].nCompTyp = m_CompArray[m_CmMCut2Array[nMCut].nCommonBreaker[0]].nPhyTyp;
				sCut2Buf.sCommonBreaker[0].nCompIdx = m_CompArray[m_CmMCut2Array[nMCut].nCommonBreaker[0]].nPhyIdx;
			}
			if (m_CmMCut2Array[nMCut].nCommonBreaker[1] >= 0)
			{
				sCut2Buf.sCommonBreaker[1].nCompTyp = m_CompArray[m_CmMCut2Array[nMCut].nCommonBreaker[1]].nPhyTyp;
				sCut2Buf.sCommonBreaker[1].nCompIdx = m_CompArray[m_CmMCut2Array[nMCut].nCommonBreaker[1]].nPhyIdx;
			}
			sFault2Array.push_back(sCut2Buf);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	�����������豸�ɿ���ָ��Ĺ��׶�
	for (nMCut=0; nMCut<(int)sFault1Array.size(); nMCut++)
	{
		sFault1Array[nMCut].fRContribution=sFault1Array[nMCut].fUContribution=0;

		sFault1Array[nMCut].fU		= sFault1Array[nMCut].fR*sFault1Array[nMCut].fT;
		sFault1Array[nMCut].fFaultU	= sFault1Array[nMCut].fFaultR*sFault1Array[nMCut].fFaultT;
		sFault1Array[nMCut].fPlanU	= sFault1Array[nMCut].fPlanR*sFault1Array[nMCut].fPlanT;

		if (fR > FLT_MIN)	sFault1Array[nMCut].fRContribution	= 100*sFault1Array[nMCut].fR/fR;
		if (fU > FLT_MIN)	sFault1Array[nMCut].fUContribution	= 100*sFault1Array[nMCut].fU/fU;
	}

	for (nMCut=0; nMCut<(int)sFault2Array.size();nMCut++)
	{
		sFault2Array[nMCut].fRContribution=sFault2Array[nMCut].fUContribution=0;

		sFault2Array[nMCut].fU		= sFault2Array[nMCut].fR*sFault2Array[nMCut].fT;
		sFault2Array[nMCut].fFaultU	= sFault2Array[nMCut].fFaultR*sFault2Array[nMCut].fFaultT;
		sFault2Array[nMCut].fPlanU	= sFault2Array[nMCut].fPlanR*sFault2Array[nMCut].fPlanT;

		if (fR > FLT_MIN)	sFault2Array[nMCut].fRContribution	= 100*sFault2Array[nMCut].fR/fR;
		if (fU > FLT_MIN)	sFault2Array[nMCut].fUContribution	= 100*sFault2Array[nMCut].fU/fU;
	}
	for (nMCut=0; nMCut<(int)sFault3Array.size();nMCut++)
	{
		sFault3Array[nMCut].fRContribution=sFault3Array[nMCut].fUContribution=0;

		sFault3Array[nMCut].fU		= sFault3Array[nMCut].fR*sFault3Array[nMCut].fT;
		sFault3Array[nMCut].fFaultU	= sFault3Array[nMCut].fFaultR*sFault3Array[nMCut].fFaultT;
		sFault3Array[nMCut].fPlanU	= sFault3Array[nMCut].fPlanR*sFault3Array[nMCut].fPlanT;

		if (fR > FLT_MIN)	sFault3Array[nMCut].fRContribution	= 100*sFault3Array[nMCut].fR/fR;
		if (fU > FLT_MIN)	sFault3Array[nMCut].fUContribution	= 100*sFault3Array[nMCut].fU/fU;
	}
}

void	CMCRAlgorithm::Alg2PhyResult(tagMCRAlgResult* pAlg, tagMCRPhyResult* pPhy)
{
	memset(pPhy, 0, sizeof(tagMCRPhyResult));
	pPhy->fR=		pAlg->fR;		//��Чͣ���ʣ���/�꣩
	pPhy->fT=		pAlg->fT;		//��Чͣ��ʱ�䣨Сʱ��
	pPhy->fU=		pAlg->fU;		//���ɵĲ�������=r*t��Сʱ/�꣩
	pPhy->fFaultR=	pAlg->fFaultR;	//��Ч����ͣ���ʣ���/�꣩
	pPhy->fFaultT=	pAlg->fFaultT;	//��Ч����ͣ��ʱ�䣨Сʱ��
	pPhy->fFaultU=	pAlg->fFaultU;	//���ɵ�Ч���ϲ�������=r*t��Сʱ/�꣩
	pPhy->fPlanR=	pAlg->fPlanR;	//��ЧԤ����ͣ���ʣ���/�꣩
	pPhy->fPlanT=	pAlg->fPlanT;	//��ЧԤ����ͣ��ʱ�䣨Сʱ��
	pPhy->fPlanU=	pAlg->fPlanU;	//���ɵ�ЧԤ����Ԥ���Ų�������=r*t��Сʱ/�꣩
}

void	CMCRAlgorithm::Alg2PhyLoad(CMCRPhyData* pPhyData, const unsigned char bAugLoad, const int nAlgLoad, const double fRCTime)
{
	if (!bAugLoad)
	{
		register int	i;
		int		nPhyComp;
		int		nPhyLoad=m_LoadArray[nAlgLoad].nPhyIdx;
		switch (m_LoadArray[nAlgLoad].nPhyTyp)
		{
		case	PG_ACLINESEGMENT:
			Alg2PhyResult(&m_LoadArray[nAlgLoad].sResult, &pPhyData->m_LineArray[nPhyLoad].sResult);
			for (i=0; i<2*g_nConstMaxReliabilityPerturb+1; i++)
				Alg2PhyResult(&m_LoadArray[nAlgLoad].sPerturbResult[i], &pPhyData->m_LineArray[nPhyLoad].sPerturbResult[i]);

			pPhyData->m_LineArray[nPhyLoad].sResult.fEns			=pPhyData->m_LineArray[nPhyLoad].fPower*pPhyData->m_LineArray[nPhyLoad].sResult.fU;
			pPhyData->m_LineArray[nPhyLoad].sResult.fFaultEns	=pPhyData->m_LineArray[nPhyLoad].fPower*pPhyData->m_LineArray[nPhyLoad].sResult.fFaultU;
			pPhyData->m_LineArray[nPhyLoad].sResult.fPlanEns		=pPhyData->m_LineArray[nPhyLoad].fPower*pPhyData->m_LineArray[nPhyLoad].sResult.fPlanU;

			pPhyData->m_LineArray[nPhyLoad].fRCTime = fRCTime;
			pPhyData->m_LineArray[nPhyLoad].nRCCase = (m_MinPathArray.size() >= m_nConstMaxEdge-1) ? PGEnumEnergyConsumer_RCCase_MinPathExceed : PGEnumEnergyConsumer_RCCase_Norm;

			Alg2PlyMCut(pPhyData->m_LineArray[nPhyLoad].sResult.fR, pPhyData->m_LineArray[nPhyLoad].sResult.fU, pPhyData->m_LineArray[nPhyLoad].sMinPathArray,
				pPhyData->m_LineArray[nPhyLoad].sFault1Array, pPhyData->m_LineArray[nPhyLoad].sFault2Array, pPhyData->m_LineArray[nPhyLoad].sFault3Array);

			break;
		case	PG_TRANSFORMERWINDING:
			Alg2PhyResult(&m_LoadArray[nAlgLoad].sResult, &pPhyData->m_TranArray[nPhyLoad].sResult);
			for (i=0; i<2*g_nConstMaxReliabilityPerturb+1; i++)
				Alg2PhyResult(&m_LoadArray[nAlgLoad].sPerturbResult[i], &pPhyData->m_TranArray[nPhyLoad].sPerturbResult[i]);

			pPhyData->m_TranArray[nPhyLoad].sResult.fEns		=pPhyData->m_TranArray[nPhyLoad].fPower*pPhyData->m_TranArray[nPhyLoad].sResult.fU;
			pPhyData->m_TranArray[nPhyLoad].sResult.fFaultEns	=pPhyData->m_TranArray[nPhyLoad].fPower*pPhyData->m_TranArray[nPhyLoad].sResult.fFaultU;
			pPhyData->m_TranArray[nPhyLoad].sResult.fPlanEns	=pPhyData->m_TranArray[nPhyLoad].fPower*pPhyData->m_TranArray[nPhyLoad].sResult.fPlanU;

			pPhyData->m_TranArray[nPhyLoad].fRCTime = fRCTime;
			pPhyData->m_TranArray[nPhyLoad].nRCCase = (m_MinPathArray.size() >= m_nConstMaxEdge-1) ? PGEnumEnergyConsumer_RCCase_MinPathExceed : PGEnumEnergyConsumer_RCCase_Norm;

			Alg2PlyMCut(pPhyData->m_TranArray[nPhyLoad].sResult.fR, pPhyData->m_TranArray[nPhyLoad].sResult.fU, pPhyData->m_TranArray[nPhyLoad].sMinPathArray,
				pPhyData->m_TranArray[nPhyLoad].sFault1Array, pPhyData->m_TranArray[nPhyLoad].sFault2Array, pPhyData->m_TranArray[nPhyLoad].sFault3Array);

			break;
		}
		for (i=0; i<(int)m_CompArray.size(); i++)
		{
			nPhyComp = m_CompArray[i].nPhyIdx;
			switch (m_CompArray[i].nPhyTyp)
			{
			case	PG_BUSBARSECTION:
				pPhyData->m_BusArray[nPhyComp].ro_RContribution += m_CompArray[i].fAccumR		;
				pPhyData->m_BusArray[nPhyComp].ro_UContribution += m_CompArray[i].fAccumU		;
				pPhyData->m_BusArray[nPhyComp].ro_ENSContribution += m_CompArray[i].fAccumEns	;
				break;
			case	PG_ACLINESEGMENT:
				pPhyData->m_LineArray[nPhyComp].ro_RContribution += m_CompArray[i].fAccumR		;
				pPhyData->m_LineArray[nPhyComp].ro_UContribution += m_CompArray[i].fAccumU		;
				pPhyData->m_LineArray[nPhyComp].ro_ENSContribution += m_CompArray[i].fAccumEns	;
				break;
			case	PG_TRANSFORMERWINDING:
				pPhyData->m_TranArray[nPhyComp].ro_RContribution += m_CompArray[i].fAccumR		;
				pPhyData->m_TranArray[nPhyComp].ro_UContribution += m_CompArray[i].fAccumU		;
				pPhyData->m_TranArray[nPhyComp].ro_ENSContribution += m_CompArray[i].fAccumEns	;
				break;
			case	PG_SERIESCOMPENSATOR:
				pPhyData->m_ScapArray[nPhyComp].ro_RContribution += m_CompArray[i].fAccumR		;
				pPhyData->m_ScapArray[nPhyComp].ro_UContribution += m_CompArray[i].fAccumU		;
				pPhyData->m_ScapArray[nPhyComp].ro_ENSContribution += m_CompArray[i].fAccumEns	;
				break;
			case	PG_BREAKER:
				pPhyData->m_BreakerArray[nPhyComp].ro_RContribution += m_CompArray[i].fAccumR		;
				pPhyData->m_BreakerArray[nPhyComp].ro_UContribution += m_CompArray[i].fAccumU		;
				pPhyData->m_BreakerArray[nPhyComp].ro_ENSContribution += m_CompArray[i].fAccumEns	;
				break;
			case	PG_DISCONNECTOR:
				pPhyData->m_DisconnectorArray[nPhyComp].ro_RContribution += m_CompArray[i].fAccumR		;
				pPhyData->m_DisconnectorArray[nPhyComp].ro_UContribution += m_CompArray[i].fAccumU		;
				pPhyData->m_DisconnectorArray[nPhyComp].ro_ENSContribution += m_CompArray[i].fAccumEns	;
				break;
			}
		}
	}
	else
	{
		Alg2PhyResult(&m_LoadArray[nAlgLoad].sResult, &pPhyData->m_AugLoad.sResult);
		pPhyData->m_AugLoad.sResult.fEns		=m_LoadArray[nAlgLoad].fLoadP*pPhyData->m_AugLoad.sResult.fU;
		pPhyData->m_AugLoad.sResult.fFaultEns	=m_LoadArray[nAlgLoad].fLoadP*pPhyData->m_AugLoad.sResult.fFaultU;
		pPhyData->m_AugLoad.sResult.fPlanEns	=m_LoadArray[nAlgLoad].fLoadP*pPhyData->m_AugLoad.sResult.fFaultU;

		pPhyData->m_AugLoad.fRCTime	= fRCTime;
		pPhyData->m_AugLoad.nRCCase = (m_MinPathArray.size() >= m_nConstMaxEdge-1) ? PGEnumEnergyConsumer_RCCase_MinPathExceed : PGEnumEnergyConsumer_RCCase_Norm;

		Alg2PlyMCut(pPhyData->m_AugLoad.sResult.fR, pPhyData->m_AugLoad.sResult.fU, pPhyData->m_AugLoad.sMinPathArray, pPhyData->m_AugLoad.sFault1Array, pPhyData->m_AugLoad.sFault2Array, pPhyData->m_AugLoad.sFault3Array);
	}
}

void	CMCRAlgorithm::Alg2PhyGen(CMCRPhyData* pPhyData, const unsigned char bAugGen, const int nAlgGen, const double fRCTime)
{
	if (!bAugGen)
	{
		register int	i;
		int		nPhyGen=m_GenArray[nAlgGen].nPhyIdx;
		switch (m_GenArray[nAlgGen].nPhyTyp)
		{
		case	PG_ACLINESEGMENT:
			Alg2PhyResult(&m_GenArray[nAlgGen].sResult, &pPhyData->m_LineArray[nPhyGen].sResult);
			for (i=0; i<2*g_nConstMaxReliabilityPerturb+1; i++)
				Alg2PhyResult(&m_GenArray[nAlgGen].sPerturbResult[i], &pPhyData->m_LineArray[nPhyGen].sPerturbResult[i]);

			pPhyData->m_LineArray[nPhyGen].fRCTime = fRCTime;
			pPhyData->m_LineArray[nPhyGen].nRCCase = (m_MinPathArray.size() >= m_nConstMaxEdge-1) ? PGEnumEnergyConsumer_RCCase_MinPathExceed : PGEnumEnergyConsumer_RCCase_Norm;

			Alg2PlyMCut(pPhyData->m_LineArray[nPhyGen].sResult.fR, pPhyData->m_LineArray[nPhyGen].sResult.fU, pPhyData->m_LineArray[nPhyGen].sMinPathArray,
				pPhyData->m_LineArray[nPhyGen].sFault1Array, pPhyData->m_LineArray[nPhyGen].sFault2Array, pPhyData->m_LineArray[nPhyGen].sFault3Array);

			break;
		case	PG_TRANSFORMERWINDING:
			Alg2PhyResult(&m_GenArray[nAlgGen].sResult, &pPhyData->m_TranArray[nPhyGen].sResult);
			for (i=0; i<2*g_nConstMaxReliabilityPerturb+1; i++)
				Alg2PhyResult(&m_GenArray[nAlgGen].sPerturbResult[i], &pPhyData->m_TranArray[nPhyGen].sPerturbResult[i]);

			pPhyData->m_TranArray[nPhyGen].fRCTime = fRCTime;
			pPhyData->m_TranArray[nPhyGen].nRCCase = (m_MinPathArray.size() >= m_nConstMaxEdge-1) ? PGEnumEnergyConsumer_RCCase_MinPathExceed : PGEnumEnergyConsumer_RCCase_Norm;

			Alg2PlyMCut(pPhyData->m_TranArray[nPhyGen].sResult.fR, pPhyData->m_TranArray[nPhyGen].sResult.fU, pPhyData->m_TranArray[nPhyGen].sMinPathArray,
				pPhyData->m_TranArray[nPhyGen].sFault1Array, pPhyData->m_TranArray[nPhyGen].sFault2Array, pPhyData->m_TranArray[nPhyGen].sFault3Array);

			break;
		}
	}
	else
	{
		Alg2PhyResult(&m_GenArray[nAlgGen].sResult, &pPhyData->m_AugGen.sResult);

		pPhyData->m_AugGen.fRCTime = fRCTime;
		pPhyData->m_AugGen.nRCCase = (m_MinPathArray.size() >= m_nConstMaxEdge-1) ? PGEnumEnergyConsumer_RCCase_MinPathExceed : PGEnumEnergyConsumer_RCCase_Norm;

		Alg2PlyMCut(pPhyData->m_AugGen.sResult.fR, pPhyData->m_AugGen.sResult.fU, pPhyData->m_AugGen.sMinPathArray, pPhyData->m_AugGen.sFault1Array, pPhyData->m_AugGen.sFault2Array, pPhyData->m_AugGen.sFault3Array);
	}
}
