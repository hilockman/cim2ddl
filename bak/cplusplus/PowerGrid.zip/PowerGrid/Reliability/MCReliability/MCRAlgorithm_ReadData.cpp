#include "StdAfx.h"
#include "MCRAlgorithm.h"

void CMCRAlgorithm::AddUniqueComm(std::vector<tagMCRAlgComm>& nCompArray, tagMCRAlgComm& sCommBuffer)
{
	register int	i;
	for (i=0; i<(int)nCompArray.size(); i++)
	{
		if (sCommBuffer.nCommComp == nCompArray[i].nCommComp)
			return;
	}

	nCompArray.push_back(sCommBuffer);
}

int CMCRAlgorithm::SeekBreakerComm(const int nBreaker, const int nCheckComp)
{
	register int	i;
	for (i=0; i<(int)m_CompArray[nBreaker].sCmCompArray.size(); i++)
	{
		if (m_CompArray[nBreaker].sCmCompArray[i].nCommComp == nCheckComp)
			return i;
	}
	return -1;
}

int	CMCRAlgorithm::ReadData(CMCRPhyData* pPhy, const char* lpszModelFileName)
{
	int		nDev;

	m_GenArray.clear();
	m_LoadArray.clear();
	m_CompArray.clear();
	m_NodeArray.clear();

	//	1���γɽڵ�ģ��
	m_nMaxPhyNode = ReadData_Node(pPhy);

	if (m_nMaxPhyNode <= 0)
		return m_nMaxPhyNode;

	//	2���γɷ����ģ��
	ReadData_Gen(pPhy);

	//	3���γɸ���ģ��
	ReadData_Load(pPhy);

	//	4���γ��豸ģ��
	ReadData_Comp(pPhy);

	//	5���ڵ��ţ��ɲ������Ľڵ����γ������Ľڵ��ţ�Ϊ�˷�ֹ�����������еľ�������
	AlgTopo();

	ReadData_Comm();

	//ReadData_Switch(pPhy);

	ReadData_CheckFCut();

	tagMCRAlgComp	sCompBuf;

	InitializeAlgLoad(&m_AugLoad);
	strcpy(m_AugLoad.szName, "���⸺��");
	m_AugLoad.nPhyTyp = PG_ENERGYCONSUMER;
	m_AugLoad.nPhyIdx = 0;
	m_AugLoad.nPhyNode = m_nMaxPhyNode + 1;
	for (nDev=0; nDev<(int)m_LoadArray.size(); nDev++)
		m_AugLoad.fLoadP += m_LoadArray[nDev].fLoadP;

	InitializeAlgComp(&sCompBuf);
	m_AugLoadCompArray.clear();
	for (nDev=0; nDev<(int)m_LoadArray.size(); nDev++)
	{
		sCompBuf.strName = "������·";
		sCompBuf.nPhyTyp = PG_ACLINESEGMENT;
		sCompBuf.nPhyIdx = 0;
		sCompBuf.nIniPhyNode = m_LoadArray[nDev].nPhyNode;
		sCompBuf.nEndPhyNode = m_nMaxPhyNode + 1;
		sCompBuf.bAugComp = 1;

		m_AugLoadCompArray.push_back(sCompBuf);
	}

	InitializeAlgGen(&m_AugGen);
	strcpy(m_AugGen.szName, "�����Դ");
	m_AugGen.nPhyTyp = PG_SYNCHRONOUSMACHINE;
	m_AugGen.nPhyIdx = 0;
	m_AugGen.nPhyNode = m_nMaxPhyNode + 1;
	for (nDev=0; nDev<(int)m_GenArray.size(); nDev++)
		m_AugGen.fOutP += m_GenArray[nDev].fOutP;

	InitializeAlgComp(&sCompBuf);
	m_AugGenCompArray.clear();
	for (nDev=0; nDev<(int)m_GenArray.size(); nDev++)
	{
		sCompBuf.strName = "������·";
		sCompBuf.nPhyTyp = PG_ACLINESEGMENT;
		sCompBuf.nPhyIdx = 0;
		sCompBuf.nIniPhyNode = m_GenArray[nDev].nPhyNode;
		sCompBuf.nEndPhyNode = m_nMaxPhyNode + 1;
		sCompBuf.bAugComp = 1;

		m_AugGenCompArray.push_back(sCompBuf);
	}

	if (lpszModelFileName)
		SaveMCReilabilityModel(lpszModelFileName);

	return	1;
}

void	CMCRAlgorithm::ReadData_Gen(CMCRPhyData* pPhy)
{
	int				nDev;
	tagMCRAlgGen	sGenBuffer;

	for	(nDev=0; nDev<(int)pPhy->m_LineArray.size(); nDev++)
	{
		if (pPhy->m_LineArray[nDev].nType != PGEnumLineTran_MCType_Gen)
			continue;
		if (pPhy->m_LineArray[nDev].nNodeI < 0)
			continue;

		InitializeAlgGen(&sGenBuffer);

		strcpy(sGenBuffer.szName, pPhy->GetCompString(PG_ACLINESEGMENT, nDev).c_str());
		sGenBuffer.nPhyNode	= pPhy->m_LineArray[nDev].nNodeI;
		sGenBuffer.nPhyTyp	= PG_ACLINESEGMENT;
		sGenBuffer.nPhyIdx	= nDev;
		sGenBuffer.fOutP	= pPhy->m_LineArray[nDev].fPower;
		m_GenArray.push_back(sGenBuffer);
	}

	for	(nDev=0; nDev<(int)pPhy->m_TranArray.size(); nDev++)
	{
		if (pPhy->m_TranArray[nDev].nType != PGEnumLineTran_MCType_Gen)
			continue;
		if (pPhy->m_TranArray[nDev].nNodeI < 0)
			continue;

		InitializeAlgGen(&sGenBuffer);

		strcpy(sGenBuffer.szName, pPhy->GetCompString(PG_TRANSFORMERWINDING, nDev).c_str());
		sGenBuffer.nPhyNode	= pPhy->m_TranArray[nDev].nNodeI;
		sGenBuffer.nPhyTyp	= PG_TRANSFORMERWINDING;
		sGenBuffer.nPhyIdx	= nDev;
		sGenBuffer.fOutP	= pPhy->m_TranArray[nDev].fPower;
		m_GenArray.push_back(sGenBuffer);
	}
}

void	CMCRAlgorithm::ReadData_Load(CMCRPhyData* pPhy)
{
	int				nDev;
	tagMCRAlgLoad	sLoadBuffer;

	InitializeAlgLoad(&sLoadBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_LineArray.size(); nDev++)
	{
		if (pPhy->m_LineArray[nDev].nType != PGEnumLineTran_MCType_Load)
			continue;
		if (pPhy->m_LineArray[nDev].nNodeI < 0)
			continue;

		strcpy(sLoadBuffer.szName, pPhy->GetCompString(PG_ACLINESEGMENT, nDev).c_str());
		sLoadBuffer.nPhyNode	= pPhy->m_LineArray[nDev].nNodeI;
		sLoadBuffer.nPhyTyp		= PG_ACLINESEGMENT;
		sLoadBuffer.nPhyIdx		= nDev;
		sLoadBuffer.fLoadP		= pPhy->m_LineArray[nDev].fPower;
		m_LoadArray.push_back(sLoadBuffer);
	}

	for	(nDev=0; nDev<(int)pPhy->m_TranArray.size(); nDev++)
	{
		if (pPhy->m_TranArray[nDev].nType != PGEnumLineTran_MCType_Load)
			continue;
		if (pPhy->m_TranArray[nDev].nNodeI < 0)
			continue;

		strcpy(sLoadBuffer.szName, pPhy->GetCompString(PG_TRANSFORMERWINDING, nDev).c_str());
		sLoadBuffer.nPhyNode	= pPhy->m_TranArray[nDev].nNodeI;
		sLoadBuffer.nPhyTyp		= PG_TRANSFORMERWINDING;
		sLoadBuffer.nPhyIdx		= nDev;
		sLoadBuffer.fLoadP		= pPhy->m_TranArray[nDev].fPower;
		m_LoadArray.push_back(sLoadBuffer);
	}
}

int	CMCRAlgorithm::ReadData_Node(CMCRPhyData* pPhy)
{
	register int	i;
	int				nDev, nExist;
	tagMCRAlgNode	sNodeBuffer;
	int				nMaxPhyNode;

	nMaxPhyNode=-1;

	InitializeAlgNode(&sNodeBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_LineArray.size(); nDev++)
	{
		if (pPhy->m_LineArray[nDev].nNodeI < 0)
			continue;
		if (pPhy->m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge && pPhy->m_LineArray[nDev].nNodeJ < 0)
			continue;

		sNodeBuffer.strName = pPhy->m_LineArray[nDev].strName;

		nExist=0;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_LineArray[nDev].nNodeI == m_NodeArray[i].nPhyNode)
			{
				nExist=1;
				break;
			}
		}
		if (!nExist)
		{
			sNodeBuffer.nPhyNode = pPhy->m_LineArray[nDev].nNodeI;
			if (pPhy->m_LineArray[nDev].nType == PGEnumLineTran_MCType_Gen)
				sNodeBuffer.nPhyType = PG_SYNCHRONOUSMACHINE;
			else if (pPhy->m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
				sNodeBuffer.nPhyType = PG_ENERGYCONSUMER;
			else if (pPhy->m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge)
				sNodeBuffer.nPhyType = PG_ACLINESEGMENT;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}

		if (pPhy->m_LineArray[nDev].nType == PGEnumLineTran_MCType_Edge)
		{
			nExist=0;
			for	(i=0; i<(int)m_NodeArray.size(); i++)
			{
				if (pPhy->m_LineArray[nDev].nNodeJ == m_NodeArray[i].nPhyNode)
				{
					nExist=1;
					break;
				}
			}
			if (!nExist)
			{
				sNodeBuffer.nPhyNode = pPhy->m_LineArray[nDev].nNodeJ;
				sNodeBuffer.nPhyType = PG_ACLINESEGMENT;

				nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
				m_NodeArray.push_back(sNodeBuffer);
			}
		}
	}

	InitializeAlgNode(&sNodeBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_TranArray.size(); nDev++)
	{
		if (pPhy->m_TranArray[nDev].nNodeI < 0)
			continue;
		if (pPhy->m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge && pPhy->m_TranArray[nDev].nNodeJ < 0)
			continue;

		sNodeBuffer.strName = pPhy->GetCompString(PG_TRANSFORMERWINDING, nDev);

		nExist=0;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_TranArray[nDev].nNodeI == m_NodeArray[i].nPhyNode)
			{
				nExist=1;
				break;
			}
		}
		if (!nExist)
		{
			sNodeBuffer.nPhyNode = pPhy->m_TranArray[nDev].nNodeI;
			if (pPhy->m_TranArray[nDev].nType == PGEnumLineTran_MCType_Gen)
				sNodeBuffer.nPhyType = PG_SYNCHRONOUSMACHINE;
			else if (pPhy->m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
				sNodeBuffer.nPhyType = PG_ENERGYCONSUMER;
			else if (pPhy->m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge)
				sNodeBuffer.nPhyType = PG_TRANSFORMERWINDING;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}

		if (pPhy->m_TranArray[nDev].nType == PGEnumLineTran_MCType_Edge)
		{
			nExist=0;
			for	(i=0; i<(int)m_NodeArray.size(); i++)
			{
				if (pPhy->m_TranArray[nDev].nNodeJ == m_NodeArray[i].nPhyNode)
				{
					nExist=1;
					break;
				}
			}
			if (!nExist)
			{
				sNodeBuffer.nPhyNode = pPhy->m_TranArray[nDev].nNodeJ;
				sNodeBuffer.nPhyType = PG_TRANSFORMERWINDING;

				nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
				m_NodeArray.push_back(sNodeBuffer);
			}
		}
	}

	InitializeAlgNode(&sNodeBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_BusArray.size(); nDev++)
	{
		if (pPhy->m_BusArray[nDev].nNode < 0)
			continue;

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_BusArray[nDev].nNode == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.strName = pPhy->GetCompString(PG_BUSBARSECTION, nDev);

			sNodeBuffer.nPhyNode = pPhy->m_BusArray[nDev].nNode;
			sNodeBuffer.nPhyType = PG_BUSBARSECTION;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}
	}

	InitializeAlgNode(&sNodeBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_ScapArray.size(); nDev++)
	{
		if (pPhy->m_ScapArray[nDev].nNodeI < 0 || pPhy->m_ScapArray[nDev].nNodeJ < 0)
			continue;

		sNodeBuffer.strName = pPhy->GetCompString(PG_SERIESCOMPENSATOR, nDev);

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_ScapArray[nDev].nNodeI == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.nPhyNode = pPhy->m_ScapArray[nDev].nNodeI;
			sNodeBuffer.nPhyType = PG_SERIESCOMPENSATOR;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_ScapArray[nDev].nNodeJ == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.nPhyNode = pPhy->m_ScapArray[nDev].nNodeJ;
			sNodeBuffer.nPhyType = PG_SERIESCOMPENSATOR;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}
	}

	InitializeAlgNode(&sNodeBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_BreakerArray.size(); nDev++)
	{
		if (pPhy->m_BreakerArray[nDev].nNodeI < 0 || pPhy->m_BreakerArray[nDev].nNodeJ < 0)
			continue;

		sNodeBuffer.strName = pPhy->GetCompString(PG_BREAKER, nDev);

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_BreakerArray[nDev].nNodeI == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.nPhyNode = pPhy->m_BreakerArray[nDev].nNodeI;
			sNodeBuffer.nPhyType = PG_BREAKER;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_BreakerArray[nDev].nNodeJ == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.nPhyNode = pPhy->m_BreakerArray[nDev].nNodeJ;
			sNodeBuffer.nPhyType = PG_BREAKER;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}
	}

	InitializeAlgNode(&sNodeBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_DisconnectorArray.size(); nDev++)
	{
		if (pPhy->m_DisconnectorArray[nDev].nNodeI < 0 || pPhy->m_DisconnectorArray[nDev].nNodeJ < 0)
			continue;

		sNodeBuffer.strName = pPhy->GetCompString(PG_DISCONNECTOR, nDev);

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_DisconnectorArray[nDev].nNodeI == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.nPhyNode = pPhy->m_DisconnectorArray[nDev].nNodeI;
			sNodeBuffer.nPhyType = PG_DISCONNECTOR;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}

		nExist=-1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (pPhy->m_DisconnectorArray[nDev].nNodeJ == m_NodeArray[i].nPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuffer.nPhyNode = pPhy->m_DisconnectorArray[nDev].nNodeJ;
			sNodeBuffer.nPhyType = PG_DISCONNECTOR;

			nMaxPhyNode = max(nMaxPhyNode, sNodeBuffer.nPhyNode);
			m_NodeArray.push_back(sNodeBuffer);
		}
	}

	return nMaxPhyNode;
}

void	CMCRAlgorithm::ReadData_Comp(CMCRPhyData* pPhy)
{
	register int	i;
	int				nDev, nExist;
	tagMCRAlgComp	sCompBuffer;

	InitializeAlgComp(&sCompBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_LineArray.size(); nDev++)
	{
		if (pPhy->m_LineArray[nDev].nType != PGEnumLineTran_MCType_Edge)
			continue;

		sCompBuffer.strName		= pPhy->GetCompString(PG_ACLINESEGMENT, nDev);
		sCompBuffer.nPhyTyp		= PG_ACLINESEGMENT;
		sCompBuffer.nPhyIdx		= nDev;
		sCompBuffer.nIniPhyNode	= pPhy->m_LineArray[nDev].nNodeI;
		sCompBuffer.nEndPhyNode	= pPhy->m_LineArray[nDev].nNodeJ;
		sCompBuffer.fRerr		= pPhy->m_LineArray[nDev].fRerr;
		sCompBuffer.fTrep		= pPhy->m_LineArray[nDev].fTrep;
		sCompBuffer.fRchk		= pPhy->m_LineArray[nDev].fRchk;
		sCompBuffer.fTchk		= pPhy->m_LineArray[nDev].fTchk;
		sCompBuffer.fTopr		= pPhy->m_LineArray[nDev].fTopr;
		sCompBuffer.bSourceI	= pPhy->m_LineArray[nDev].bSourceI;
		sCompBuffer.bSourceJ	= pPhy->m_LineArray[nDev].bSourceJ;
		sCompBuffer.nDirection	= NoDirection;

		if (pPhy->m_LineArray[nDev].bSourceI != pPhy->m_LineArray[nDev].bSourceJ && pPhy->m_LineArray[nDev].bSourceI != 0)
			sCompBuffer.nDirection=I2JDirection;
		else if (pPhy->m_LineArray[nDev].bSourceI != pPhy->m_LineArray[nDev].bSourceJ && pPhy->m_LineArray[nDev].bSourceJ != 0)
			sCompBuffer.nDirection=J2IDirection;

		m_CompArray.push_back(sCompBuffer);
	}

	InitializeAlgComp(&sCompBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_TranArray.size(); nDev++)
	{
		if (pPhy->m_TranArray[nDev].nType != PGEnumLineTran_MCType_Edge)
			continue;

		sCompBuffer.strName		= pPhy->GetCompString(PG_TRANSFORMERWINDING, nDev);
		sCompBuffer.nPhyTyp		= PG_TRANSFORMERWINDING;
		sCompBuffer.nPhyIdx		= nDev;
		sCompBuffer.nIniPhyNode	= pPhy->m_TranArray[nDev].nNodeI;
		sCompBuffer.nEndPhyNode	= pPhy->m_TranArray[nDev].nNodeJ;
		sCompBuffer.fRerr		= pPhy->m_TranArray[nDev].fRerr;
		sCompBuffer.fTrep		= pPhy->m_TranArray[nDev].fTrep;
		sCompBuffer.fRchk		= pPhy->m_TranArray[nDev].fRchk;
		sCompBuffer.fTchk		= pPhy->m_TranArray[nDev].fTchk;
		sCompBuffer.fTopr		= pPhy->m_TranArray[nDev].fTopr;
		sCompBuffer.bSourceI	= pPhy->m_TranArray[nDev].bSourceI;
		sCompBuffer.bSourceJ	= pPhy->m_TranArray[nDev].bSourceJ;
		sCompBuffer.nDirection	= NoDirection;

		if (pPhy->m_TranArray[nDev].bSourceI != pPhy->m_TranArray[nDev].bSourceJ && pPhy->m_TranArray[nDev].bSourceI != 0)
			sCompBuffer.nDirection=I2JDirection;
		else if (pPhy->m_TranArray[nDev].bSourceI != pPhy->m_TranArray[nDev].bSourceJ && pPhy->m_TranArray[nDev].bSourceJ != 0)
			sCompBuffer.nDirection=J2IDirection;

		m_CompArray.push_back(sCompBuffer);
	}

	InitializeAlgComp(&sCompBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_BreakerArray.size(); nDev++)
	{
		sCompBuffer.strName		= pPhy->GetCompString(PG_BREAKER, nDev);
		sCompBuffer.nPhyTyp		= PG_BREAKER;
		sCompBuffer.nPhyIdx		= nDev;
		sCompBuffer.nIniPhyNode	= pPhy->m_BreakerArray[nDev].nNodeI;
		sCompBuffer.nEndPhyNode	= pPhy->m_BreakerArray[nDev].nNodeJ;
		sCompBuffer.fRerr		= pPhy->m_BreakerArray[nDev].fRerr;
		sCompBuffer.fTrep		= pPhy->m_BreakerArray[nDev].fTrep;
		sCompBuffer.fRchk		= pPhy->m_BreakerArray[nDev].fRchk;
		sCompBuffer.fTchk		= pPhy->m_BreakerArray[nDev].fTchk;
		sCompBuffer.fTopr		= pPhy->m_BreakerArray[nDev].fTopr;
		sCompBuffer.fTSwitch	= pPhy->m_BreakerArray[nDev].fTSwitch;
		sCompBuffer.nStatus		= pPhy->m_BreakerArray[nDev].nStatus;
		sCompBuffer.bSourceI	= pPhy->m_BreakerArray[nDev].bSourceI;
		sCompBuffer.bSourceJ	= pPhy->m_BreakerArray[nDev].bSourceJ;
		sCompBuffer.nDirection	= NoDirection;

		if (pPhy->m_BreakerArray[nDev].bSourceI != pPhy->m_BreakerArray[nDev].bSourceJ && pPhy->m_BreakerArray[nDev].bSourceI != 0)
			sCompBuffer.nDirection=I2JDirection;
		else if (pPhy->m_BreakerArray[nDev].bSourceI != pPhy->m_BreakerArray[nDev].bSourceJ && pPhy->m_BreakerArray[nDev].bSourceJ != 0)
			sCompBuffer.nDirection=J2IDirection;

// 		if (pPhy->m_NodeArray[pPhy->m_BreakerArray[nDev].nNodeI].nBusArray.empty() && pPhy->m_NodeArray[pPhy->m_BreakerArray[nDev].nNodeJ].nBusArray.empty())
// 			sCompBuffer.fTSwitch = 0;

		m_CompArray.push_back(sCompBuffer);
	}

	InitializeAlgComp(&sCompBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_DisconnectorArray.size(); nDev++)
	{
		sCompBuffer.strName		= pPhy->GetCompString(PG_DISCONNECTOR, nDev);
		sCompBuffer.nPhyTyp		= PG_DISCONNECTOR;
		sCompBuffer.nPhyIdx		= nDev;
		sCompBuffer.nIniPhyNode	= pPhy->m_DisconnectorArray[nDev].nNodeI;
		sCompBuffer.nEndPhyNode	= pPhy->m_DisconnectorArray[nDev].nNodeJ;
		sCompBuffer.fRerr		= pPhy->m_DisconnectorArray[nDev].fRerr;
		sCompBuffer.fTrep		= pPhy->m_DisconnectorArray[nDev].fTrep;
		sCompBuffer.fRchk		= pPhy->m_DisconnectorArray[nDev].fRchk;
		sCompBuffer.fTchk		= pPhy->m_DisconnectorArray[nDev].fTchk;
		sCompBuffer.fTopr		= pPhy->m_DisconnectorArray[nDev].fTopr;
		sCompBuffer.fTSwitch	= pPhy->m_DisconnectorArray[nDev].fTSwitch;
		sCompBuffer.nStatus		= pPhy->m_DisconnectorArray[nDev].nStatus;
		sCompBuffer.bSourceI	= pPhy->m_DisconnectorArray[nDev].bSourceI;
		sCompBuffer.bSourceJ	= pPhy->m_DisconnectorArray[nDev].bSourceJ;
		sCompBuffer.nDirection	= NoDirection;

		if (pPhy->m_DisconnectorArray[nDev].bSourceI != pPhy->m_DisconnectorArray[nDev].bSourceJ && pPhy->m_DisconnectorArray[nDev].bSourceI != 0)
			sCompBuffer.nDirection=I2JDirection;
		else if (pPhy->m_DisconnectorArray[nDev].bSourceI != pPhy->m_DisconnectorArray[nDev].bSourceJ && pPhy->m_DisconnectorArray[nDev].bSourceJ != 0)
			sCompBuffer.nDirection=J2IDirection;

// 		if (pPhy->m_NodeArray[pPhy->m_DisconnectorArray[nDev].nNodeI].nBusArray.empty() && pPhy->m_NodeArray[pPhy->m_DisconnectorArray[nDev].nNodeJ].nBusArray.empty())
// 			sCompBuffer.fTSwitch = 0;

		m_CompArray.push_back(sCompBuffer);
	}


	InitializeAlgComp(&sCompBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_ScapArray.size(); nDev++)
	{
		sCompBuffer.strName		= pPhy->GetCompString(PG_SERIESCOMPENSATOR, nDev);
		sCompBuffer.nPhyTyp		= PG_SERIESCOMPENSATOR;
		sCompBuffer.nPhyIdx		= nDev;
		sCompBuffer.nIniPhyNode	= pPhy->m_ScapArray[nDev].nNodeI;
		sCompBuffer.nEndPhyNode	= pPhy->m_ScapArray[nDev].nNodeJ;
		sCompBuffer.fRerr		= pPhy->m_ScapArray[nDev].fRerr;
		sCompBuffer.fTrep		= pPhy->m_ScapArray[nDev].fTrep;
		sCompBuffer.fRchk		= pPhy->m_ScapArray[nDev].fRchk;
		sCompBuffer.fTchk		= pPhy->m_ScapArray[nDev].fTchk;
		sCompBuffer.fTopr		= pPhy->m_ScapArray[nDev].fTopr;
		sCompBuffer.nDirection	= NoDirection;

		m_CompArray.push_back(sCompBuffer);
	}

	InitializeAlgComp(&sCompBuffer);
	for	(nDev=0; nDev<(int)pPhy->m_BusArray.size(); nDev++)
	{
		if (pPhy->m_BusArray[nDev].nNode < 0)
			continue;

		if ((pPhy->m_BusArray[nDev].fRerr < FLT_MIN || pPhy->m_BusArray[nDev].fTrep < FLT_MIN) &&
			(pPhy->m_BusArray[nDev].fRchk < FLT_MIN || pPhy->m_BusArray[nDev].fTchk < FLT_MIN))
			continue;

		nExist=-1;
		for	(i=0; i<(int)m_CompArray.size(); i++)
		{
			if (m_CompArray[i].nPhyTyp != PG_BUSBARSECTION)
				continue;
			if (pPhy->m_BusArray[nDev].nNode == m_CompArray[i].nIniPhyNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sCompBuffer.strName		= pPhy->GetCompString(PG_BUSBARSECTION, nDev);
			sCompBuffer.nPhyTyp		= PG_BUSBARSECTION;
			sCompBuffer.nPhyIdx		= nDev;
			sCompBuffer.nIniPhyNode	= pPhy->m_BusArray[nDev].nNode;
			sCompBuffer.nEndPhyNode	= pPhy->m_BusArray[nDev].nNode;
			sCompBuffer.fRerr		= pPhy->m_BusArray[nDev].fRerr;
			sCompBuffer.fTrep		= pPhy->m_BusArray[nDev].fTrep;
			sCompBuffer.fRchk		= pPhy->m_BusArray[nDev].fRchk;
			sCompBuffer.fTchk		= pPhy->m_BusArray[nDev].fTchk;
			sCompBuffer.fTopr		= pPhy->m_BusArray[nDev].fTopr;
			sCompBuffer.nDirection	= NoDirection;

			m_CompArray.push_back(sCompBuffer);
		}
		else
		{
			m_CompArray[nExist].fRerr=(m_CompArray[nExist].fRerr*pPhy->m_BusArray[nDev].fRerr*(m_CompArray[nExist].fTrep+pPhy->m_BusArray[nDev].fTrep)/8760);
			if (m_CompArray[nExist].fRerr > FLT_MIN)
				m_CompArray[nExist].fTrep=((m_CompArray[nExist].fRerr*pPhy->m_BusArray[nDev].fRerr*m_CompArray[nExist].fTrep*pPhy->m_BusArray[nDev].fTrep)/(m_CompArray[nExist].fRerr*8760));

			m_CompArray[nExist].fRchk=(m_CompArray[nExist].fRchk*pPhy->m_BusArray[nDev].fRchk*(m_CompArray[nExist].fTchk+pPhy->m_BusArray[nDev].fTchk)/8760);
			if (m_CompArray[nExist].fRchk > FLT_MIN)
				m_CompArray[nExist].fTchk=((m_CompArray[nExist].fRchk*pPhy->m_BusArray[nDev].fRchk*m_CompArray[nExist].fTchk*pPhy->m_BusArray[nDev].fTchk)/(m_CompArray[nExist].fRchk*8760));
		}
	}

	for (i=0; i<(int)m_CompArray.size(); i++)
	{
		if (m_CompArray[i].fRerr < FLT_MIN || m_CompArray[i].fTrep < FLT_MIN)	{	m_CompArray[i].fRerr=m_CompArray[i].fTrep=0;	}
		if (m_CompArray[i].fRchk < FLT_MIN || m_CompArray[i].fTchk < FLT_MIN)	{	m_CompArray[i].fRchk=m_CompArray[i].fTchk=0;	}
	}
}

void CMCRAlgorithm::ReadData_Comm()
{
	register int	i;
	int							nComp, nNode, nDev;
	tagMCRAlgComm				sCommBuffer;
	std::vector<int>			nNodeArray;
	std::vector<unsigned char>	nCompStatusArray;

	for	(nComp=0; nComp<(int)m_CompArray.size(); nComp++)
		m_CompArray[nComp].sCmCompArray.clear();

	nCompStatusArray.resize(m_CompArray.size());
	for	(nComp=0; nComp<(int)m_CompArray.size(); nComp++)
	{
		nCompStatusArray[nComp] = m_CompArray[nComp].nStatus;
		if (m_CompArray[nComp].nPhyTyp == PG_BREAKER)
			m_CompArray[nComp].nStatus = 1;
	}

	for	(nComp=0; nComp<(int)m_CompArray.size(); nComp++)
	{
		if (m_CompArray[nComp].nPhyTyp != PG_BREAKER)	continue;

		sCommBuffer.nCommType = 0;
		nNode = m_CompArray[nComp].nIniAlgNode;
		for (i=0; i<(int)m_NodeArray[nNode].nCompArray.size(); i++)
		{
			nDev=m_NodeArray[nNode].nCompArray[i];
			if (nComp == nDev)
				continue;
			if (nCompStatusArray[nDev] != 0)	//	��Ϊ��·��״̬���˹����õģ�������Ҫ�ñ��������ж�
				continue;

			//if (m_CompArray[nDev].nPhyTyp == PG_BUSBARSECTION)
			//	ASSERT(FALSE);
			sCommBuffer.nCommComp = nDev;
			AddUniqueComm(m_CompArray[nComp].sCmCompArray, sCommBuffer);
		}
		nNode = m_CompArray[nComp].nEndAlgNode;
		for (i=0; i<(int)m_NodeArray[nNode].nCompArray.size(); i++)
		{
			nDev=m_NodeArray[nNode].nCompArray[i];
			if (nComp == nDev)
				continue;
			if (nCompStatusArray[nDev] != 0)	//	��Ϊ��·��״̬���˹����õģ�������Ҫ�ñ��������ж�
				continue;

			//if (m_CompArray[nDev].nPhyTyp == PG_BUSBARSECTION)
			//	ASSERT(FALSE);
			sCommBuffer.nCommComp = nDev;
			AddUniqueComm(m_CompArray[nComp].sCmCompArray, sCommBuffer);
		}

		sCommBuffer.nCommType = 1;
		AlgTraverse(m_CompArray[nComp].nIniAlgNode, -1, 1, nNodeArray);
		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_NodeArray[nNodeArray[nNode]].nCompArray.size(); i++)
			{
				nDev=m_NodeArray[nNodeArray[nNode]].nCompArray[i];
				if (nComp == nDev)
					continue;
				if (nCompStatusArray[nDev] != 0)
					continue;

				if (m_CompArray[nDev].fRerr > FLT_MIN && m_CompArray[nDev].fTrep > FLT_MIN)
				{
					//if (m_CompArray[nDev].nPhyTyp == PG_BUSBARSECTION)
					//	ASSERT(FALSE);

					sCommBuffer.nCommComp = nDev;
					AddUniqueComm(m_CompArray[nComp].sCmCompArray, sCommBuffer);
				}
			}
		}

		AlgTraverse(m_CompArray[nComp].nEndAlgNode, -1, 1, nNodeArray);
		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_NodeArray[nNodeArray[nNode]].nCompArray.size(); i++)
			{
				nDev=m_NodeArray[nNodeArray[nNode]].nCompArray[i];
				if (nComp == nDev)
					continue;
				if (nCompStatusArray[nDev] != 0)
					continue;

				if (m_CompArray[nDev].fRerr > FLT_MIN && m_CompArray[nDev].fTrep > FLT_MIN)
				{
					sCommBuffer.nCommComp = nDev;
					AddUniqueComm(m_CompArray[nComp].sCmCompArray, sCommBuffer);
				}
			}
		}
	}

	for	(nComp=0; nComp<(int)nCompStatusArray.size(); nComp++)
		m_CompArray[nComp].nStatus = nCompStatusArray[nComp];
}

// void CMCRAlgorithm::ReadData_Switch(CMCRPhyData* pPhy)
// {
// 	register int	i;
// 	int		nComp, nNode, nDev, nOppNode;
// 	std::vector<int>	nNodeArray;
// 	unsigned char	bAllOppBus;
// 
// 	for	(nComp=0; nComp<(int)m_CompArray.size(); nComp++)
// 		m_CompArray[nComp].nSwCompArray.clear();
// 
// 	for	(nComp=0; nComp<(int)m_CompArray.size(); nComp++)
// 	{
// 		if (m_CompArray[nComp].nPhyTyp != PG_DISCONNECTOR)	continue;
// 		if (m_CompArray[nComp].fTSwitch < FLT_MIN)			continue;
// 
// 		nNode = m_CompArray[nComp].nIniPhyNode;
// 		if (pPhy->m_NodeArray[nNode].nBusArray.empty())
// 		{
// 			bAllOppBus = 1;
// 			for (i=0; i<(int)pPhy->m_NodeArray[nNode].nDisconnectorArray.size(); i++)
// 			{
// 				nDev = pPhy->m_NodeArray[nNode].nDisconnectorArray[i];
// 				nOppNode = (nNode == pPhy->m_DisconnectorArray[nDev].nNodeI) ? pPhy->m_DisconnectorArray[nDev].nNodeJ : pPhy->m_DisconnectorArray[nDev].nNodeI;
// 				if (pPhy->m_NodeArray[nOppNode].nBusArray.empty())
// 				{
// 					bAllOppBus = 0;
// 					break;
// 				}
// 			}
// 			if (bAllOppBus)
// 			{
// 				nNode = m_CompArray[nComp].nIniAlgNode;
// 				for (i=0; i<(int)m_NodeArray[nNode].nCompArray.size(); i++)
// 				{
// 					nDev = m_NodeArray[nNode].nCompArray[i];
// 					if (m_CompArray[nDev].nPhyTyp != PG_DISCONNECTOR)
// 						continue;
// 					if (nDev == nComp)
// 						continue;
// 
// 					AddUniqueInteger(m_CompArray[nComp].nSwCompArray, nDev);
// 				}
// 			}
// 		}
// 
// 		nNode = m_CompArray[nComp].nEndPhyNode;
// 		if (pPhy->m_NodeArray[nNode].nBusArray.empty())
// 		{
// 			bAllOppBus = 1;
// 			for (i=0; i<(int)pPhy->m_NodeArray[nNode].nDisconnectorArray.size(); i++)
// 			{
// 				nDev = pPhy->m_NodeArray[nNode].nDisconnectorArray[i];
// 				nOppNode = (nNode == pPhy->m_DisconnectorArray[nDev].nNodeI) ? pPhy->m_DisconnectorArray[nDev].nNodeJ : pPhy->m_DisconnectorArray[nDev].nNodeI;
// 				if (pPhy->m_NodeArray[nOppNode].nBusArray.empty())
// 				{
// 					bAllOppBus = 0;
// 					break;
// 				}
// 			}
// 			if (bAllOppBus)
// 			{
// 				nNode = m_CompArray[nComp].nEndAlgNode;
// 				for (i=0; i<(int)m_NodeArray[nNode].nCompArray.size(); i++)
// 				{
// 					nDev = m_NodeArray[nNode].nCompArray[i];
// 					if (m_CompArray[nDev].nPhyTyp != PG_DISCONNECTOR)
// 						continue;
// 					if (nDev == nComp)
// 						continue;
// 
// 					AddUniqueInteger(m_CompArray[nComp].nSwCompArray, nDev);
// 				}
// 			}
// 		}
// 	}
// }

void CMCRAlgorithm::ReadData_CheckFCut()
{
	int		nComp, nNode;
	std::vector<int>	nNodeArray;
	std::vector<unsigned char>	nStatusArray;

	nStatusArray.resize(m_CompArray.size());
	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
	{
		nStatusArray[nComp] = m_CompArray[nComp].nStatus;
		m_CompArray[nComp].nStatus = 0;
	}

	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
	{
		if (m_CompArray[nComp].nPhyTyp == PG_BUSBARSECTION)
			continue;

		m_CompArray[nComp].bFCutPlan = 1;

		m_CompArray[nComp].nStatus = 1;
		if (m_CompArray[nComp].bFCutPlan)
		{
			AlgTraverseDirection(m_CompArray[nComp].nIniAlgNode, YCheckStatus, PosDirection, nNodeArray);
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				if (nNodeArray[nNode] == m_CompArray[nComp].nEndAlgNode)
				{
					m_CompArray[nComp].bFCutPlan = 0;
					break;
				}
			}
		}
		if (m_CompArray[nComp].bFCutPlan)
		{
			AlgTraverseDirection(m_CompArray[nComp].nEndAlgNode, YCheckStatus, PosDirection, nNodeArray);
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				if (nNodeArray[nNode] == m_CompArray[nComp].nIniAlgNode)
				{
					m_CompArray[nComp].bFCutPlan = 0;
					break;
				}
			}
		}
		m_CompArray[nComp].nStatus = 0;
	}

	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
		m_CompArray[nComp].nStatus = nStatusArray[nComp];
}

void CMCRAlgorithm::SaveMCReilabilityModel(const char* lpszFileName)
{
	register int	i;
	int				nDev, nComp;
	TiXmlElement	*pElement, *pSecElement;

	TiXmlDocument*		pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����
	TiXmlDeclaration*	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	TiXmlElement*	pRoot=new TiXmlElement("ReliabilityModel");
	pDocument->LinkEndChild(pRoot);

	for (nDev=0; nDev<(int)m_GenArray.size(); nDev++)
	{
		pElement = new TiXmlElement("Gen");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Type",			PGGetTableDesp(m_GenArray[nDev].nPhyTyp));
		pElement->SetAttribute("Index",			m_GenArray[nDev].nPhyIdx);
		pElement->SetAttribute("Name",			m_GenArray[nDev].szName);
		pElement->SetDoubleAttribute("OutP",	m_GenArray[nDev].fOutP);
		pElement->SetAttribute("PhyNode",		m_GenArray[nDev].nPhyNode);
		pElement->SetAttribute("AlgNode",		m_GenArray[nDev].nAlgNode);
	}

	for (nDev=0; nDev<(int)m_LoadArray.size(); nDev++)
	{
		pElement = new TiXmlElement("Load");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Type",			PGGetTableDesp(m_LoadArray[nDev].nPhyTyp));
		pElement->SetAttribute("Index",			m_LoadArray[nDev].nPhyIdx);
		pElement->SetAttribute("Name",			m_LoadArray[nDev].szName);
		pElement->SetDoubleAttribute("LoadP",	m_LoadArray[nDev].fLoadP);
		pElement->SetAttribute("PhyNode",		m_LoadArray[nDev].nPhyNode);
		pElement->SetAttribute("AlgNode",		m_LoadArray[nDev].nAlgNode);
	}

	for (nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		pElement = new TiXmlElement("Comp");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Type",			PGGetTableDesp(m_CompArray[nDev].nPhyTyp));
		pElement->SetAttribute("Index",			m_CompArray[nDev].nPhyIdx);
		pElement->SetAttribute("Name",			m_CompArray[nDev].strName.c_str());
		pElement->SetAttribute("IniPhyNode",	m_CompArray[nDev].nIniPhyNode);
		pElement->SetAttribute("EndPhyNode",	m_CompArray[nDev].nEndPhyNode);
		pElement->SetAttribute("IniAlgNode",	m_CompArray[nDev].nIniAlgNode);
		pElement->SetAttribute("EndAlgNode",	m_CompArray[nDev].nEndAlgNode);

		pElement->SetAttribute("EndPhyNode",	m_CompArray[nDev].nStatus);
		pElement->SetAttribute("FCutPlan",		m_CompArray[nDev].bFCutPlan);
		pElement->SetAttribute("SourceI",		m_CompArray[nDev].bSourceI);
		pElement->SetAttribute("SourceJ",		m_CompArray[nDev].bSourceJ);

		pElement->SetDoubleAttribute("Rerr",	m_CompArray[nDev].fRerr);
		pElement->SetDoubleAttribute("Trep",	m_CompArray[nDev].fTrep);
		pElement->SetDoubleAttribute("Rchk",	m_CompArray[nDev].fRchk);
		pElement->SetDoubleAttribute("Tchk",	m_CompArray[nDev].fTchk);
		pElement->SetDoubleAttribute("Topr",	m_CompArray[nDev].fTopr);
		pElement->SetDoubleAttribute("TSwitch",	m_CompArray[nDev].fTSwitch);
	}

	for (nDev=0; nDev<(int)m_NodeArray.size(); nDev++)
	{
		pElement = new TiXmlElement("Node");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Type",			PGGetTableDesp(m_NodeArray[nDev].nPhyType));
		pElement->SetAttribute("Name",			m_NodeArray[nDev].strName.c_str());
		pElement->SetAttribute("PhyNode",		m_NodeArray[nDev].nPhyNode);
	}

	for (nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		if (m_CompArray[nDev].nPhyTyp != PG_BREAKER)
			continue;

		pElement = new TiXmlElement("Comm");
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("Type",			PGGetTableDesp(m_CompArray[nDev].nPhyTyp));
		pElement->SetAttribute("Name",			m_CompArray[nDev].strName.c_str());
		pElement->SetAttribute("Status",		m_CompArray[nDev].nStatus);

		for (i=0; i<(int)m_CompArray[nDev].sCmCompArray.size(); i++)
		{
			pSecElement = new TiXmlElement("CommComp");
			pElement->LinkEndChild(pSecElement);

			nComp = m_CompArray[nDev].sCmCompArray[i].nCommComp;
			if (m_CompArray[nDev].sCmCompArray[i].nCommType == 0)
				pSecElement->SetAttribute("CommType",	"��ͨ");
			else
				pSecElement->SetAttribute("CommType",	"��ģ");

			pSecElement->SetAttribute("CompType",	PGGetTableDesp(m_CompArray[nComp].nPhyTyp));
			pSecElement->SetAttribute("CompIndex",	m_CompArray[nComp].nPhyIdx);
			pSecElement->SetAttribute("CompName",	m_CompArray[nComp].strName.c_str());
			pSecElement->SetAttribute("CompStauts",	m_CompArray[nComp].nStatus);
		}
	}

// 	for (nDev=0; nDev<(int)m_CompArray.size(); nDev++)
// 	{
// 		if (m_CompArray[nDev].nPhyTyp != PG_DISCONNECTOR)
// 			continue;
// 		if (m_CompArray[nDev].nStatus != 0)
// 			continue;
// 		if (m_CompArray[nDev].nSwCompArray.empty())
// 			continue;
// 
// 		pElement = new TiXmlElement("Switch");
// 		pRoot->LinkEndChild(pElement);
// 
// 		pElement->SetAttribute("Type",			PGGetTableDesp(m_CompArray[nDev].nPhyTyp));
// 		pElement->SetAttribute("Index",			m_CompArray[nDev].nPhyIdx);
// 		pElement->SetAttribute("Name",			m_CompArray[nDev].strName.c_str());
// 		pElement->SetAttribute("Stauts",		m_CompArray[nDev].nStatus);
// 		pElement->SetDoubleAttribute("TSwitch",	m_CompArray[nDev].fTSwitch);
// 
// 		for (i=0; i<(int)m_CompArray[nDev].nSwCompArray.size(); i++)
// 		{
// 			pSecElement = new TiXmlElement("SwitchComp");
// 			pElement->LinkEndChild(pSecElement);
// 
// 			nComp = m_CompArray[nDev].nSwCompArray[i];
// 			pSecElement->SetAttribute("SwitchType",		PGGetTableDesp(m_CompArray[nComp].nPhyTyp));
// 			pSecElement->SetAttribute("SwitchIndex",	m_CompArray[nComp].nPhyIdx);
// 			pSecElement->SetAttribute("SwitchName",		m_CompArray[nComp].strName.c_str());
// 			pSecElement->SetAttribute("SwitchStauts",	m_CompArray[nComp].nStatus);
// 		}
// 	}


	pDocument->SaveFile(lpszFileName);
	pDocument->Clear();
	delete pDocument;
}
