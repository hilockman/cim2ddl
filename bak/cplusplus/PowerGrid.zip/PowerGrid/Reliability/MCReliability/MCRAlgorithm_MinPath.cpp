#include "StdAfx.h"
#include "MCRAlgorithm.h"

void CMCRAlgorithm::FormNormalMinPath(const int nAlgNode, const unsigned char nPathOrient, std::vector<tagMCRAlgPath>& sMinPathArray)
{
	register int	i;
	int		nComp, nPath;
	std::vector<int>	nRangeNodeArray, nEndNodeArray;
	clock_t	dBeg, dEnd;
	int		nDur;

	short			nBoundType = (nPathOrient == Load2GenPath) ? PG_SYNCHRONOUSMACHINE : PG_ENERGYCONSUMER;
	unsigned char	nDirection = (nPathOrient == Load2GenPath) ? PosDirection : NegDirection;

	sMinPathArray.clear();
	if (m_NodeArray[nAlgNode].nPhyType == nBoundType)		//	�����뷢��ֱ��
		return;

	//////////////////////////////////////////////////////////////////////////
	//	�γɼ���ڵ㼯��
	AlgTraverse(nAlgNode, nBoundType, 1, nRangeNodeArray);
	if (nRangeNodeArray.size() <= 1)
	{
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ����ڵ�Ϊ�� Node = %s\n", m_NodeArray[nAlgNode].strName.c_str());
#endif
		return;
	}

	nEndNodeArray.clear();
	for (i=0; i<(int)nRangeNodeArray.size(); i++)
	{
		if (m_NodeArray[nRangeNodeArray[i]].nPhyType == nBoundType)
			nEndNodeArray.push_back(nRangeNodeArray[i]);
	}
	//	�γɼ���ڵ㼯��
	//////////////////////////////////////////////////////////////////////////

	dBeg=clock();

	if (!m_DisJoint.DisJoint_Init(nAlgNode, nDirection, YCheckStatus, m_NodeArray, m_CompArray, nRangeNodeArray))
		return;

	for (i=0; i<(int)nEndNodeArray.size(); i++)
	{
		m_DisJoint.DisJoint_Calc(nEndNodeArray[i], nRangeNodeArray);
		m_DisJoint.DisJoint2MinPath(m_NodeArray, m_CompArray, nRangeNodeArray, sMinPathArray);
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ĸ����Ϊ֧·���ӵ�����·����
	std::vector<int>	nCompNodeArray;
	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		nCompNodeArray.clear();
		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp=sMinPathArray[nPath].nCompArray[i];
			if (m_CompArray[nComp].nIniAlgNode != m_CompArray[nComp].nEndAlgNode)
			{
				AddUniqueInteger(nCompNodeArray, m_CompArray[nComp].nIniAlgNode);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
				AddUniqueInteger(nCompNodeArray, m_CompArray[nComp].nEndAlgNode);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
			}
		}
		for (i=0; i<(int)nCompNodeArray.size(); i++)
		{
			for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
			{
				if (m_CompArray[nComp].nPhyTyp != PG_BUSBARSECTION)
					continue;
				if (m_CompArray[nComp].fRerr < FLT_MIN || m_CompArray[nComp].fTrep < FLT_MIN)
					continue;
				if (m_CompArray[nComp].nIniAlgNode != nCompNodeArray[i])
					continue;

				AddUniqueInteger(sMinPathArray[nPath].nCompArray, nComp);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
			}
		}
	}
	//	��ĸ����Ϊ֧·���ӵ�����·����
	//////////////////////////////////////////////////////////////////////////
	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
		sMinPathArray[nPath].nCompVector.resize(m_CompArray.size(), 0);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ��С·(MinPath = %d) [EndNode = %d]��ɣ���ʱ%d����\n", sMinPathArray.size(), nEndNodeArray.size(), nDur);

	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		if (sMinPathArray[nPath].nCompArray.empty())
			continue;

		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp = sMinPathArray[nPath].nCompArray[i];
			Log(g_lpszLogFile, "          (������С·-%d/%d PathStatus=%d) %s, %s, (%f, %f, %f, %f) CompStatus = %d\n", i+1, sMinPathArray[nPath].nCompArray.size(), sMinPathArray[nPath].nStatus,
				PGGetTableName(m_CompArray[nComp].nPhyTyp), m_CompArray[nComp].strName.c_str(), m_CompArray[nComp].fRerr, m_CompArray[nComp].fTrep, m_CompArray[nComp].fRchk, m_CompArray[nComp].fTchk, m_CompArray[nComp].nStatus);
		}
		Log(g_lpszLogFile, "\n");
	}
#endif
}

// void CMCRAlgorithm::FormSwitchMinPathOld(const int nAlgNode, const unsigned char nPathOrient, std::vector<tagMCRAlgPath>& sMinPathArray)
// {
// 	register int	i, j;
// 	int					nComp, nPath;
// 	std::vector<int>	nRangeNodeArray, nEndNodeArray;
// 	std::vector<int>	nSwitchCompArray;
// 	clock_t	dBeg, dEnd;
// 	int		nDur;
// 
// 	dBeg=clock();
// 
// 	short			nBoundType = (nPathOrient == Load2GenPath) ? PG_SYNCHRONOUSMACHINE : PG_ENERGYCONSUMER;
// 	unsigned char	nDirection = (nPathOrient == Load2GenPath) ? PosDirection : NegDirection;
// 
// 	sMinPathArray.clear();
// 	if (m_NodeArray[nAlgNode].nPhyType == nBoundType)		//	�����뷢��ֱ��
// 		return;
// 
// 	nSwitchCompArray.clear();
// 	for (nPath=0; nPath<(int)m_MinPathArray.size(); nPath++)
// 	{
// 		for (i=0; i<(int)m_MinPathArray[nPath].nCompArray.size(); i++)
// 		{
// 			nComp = m_MinPathArray[nPath].nCompArray[i];
// 			if (m_CompArray[nComp].nSwCompArray.empty())
// 				continue;
// 
// 			m_CompArray[nComp].nStatus = 1;
// 			for (j=0; j<(int)m_CompArray[nComp].nSwCompArray.size(); j++)
// 			{
// 				if (m_CompArray[m_CompArray[nComp].nSwCompArray[j]].nStatus != 0)
// 					AddUniqueInteger(nSwitchCompArray, m_CompArray[nComp].nSwCompArray[j]);
// 			}
// 		}
// 	}
// 	if (nSwitchCompArray.empty())
// 		goto _ClearOut;
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	//	��¼�л��豸״̬
// 	for (i=0; i<(int)nSwitchCompArray.size(); i++)
// 		m_CompArray[nSwitchCompArray[i]].nStatus = 0;
// 	//	��¼�л��豸״̬
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	//	�γɼ���ڵ㼯��
// 	AlgTraverse(nAlgNode, nBoundType, 1, nRangeNodeArray);
// 	if (nRangeNodeArray.size() <= 1)
// 		goto _ClearOut;
// 
// 	nEndNodeArray.clear();
// 	for (i=0; i<(int)nRangeNodeArray.size(); i++)
// 	{
// 		if (m_NodeArray[nRangeNodeArray[i]].nPhyType == nBoundType)
// 			nEndNodeArray.push_back(nRangeNodeArray[i]);
// 	}
// 	//	�γɼ���ڵ㼯��
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	if (!m_DisJoint.DisJoint_Init(nAlgNode, nDirection, YCheckStatus, m_NodeArray, m_CompArray, nRangeNodeArray))
// 		goto _ClearOut;
// 
// 	for (i=0; i<(int)nEndNodeArray.size(); i++)
// 	{
// 		m_DisJoint.DisJoint_Calc(nEndNodeArray[i], nRangeNodeArray);
// 		m_DisJoint.DisJoint2MinPath(m_NodeArray, m_CompArray, nRangeNodeArray, sMinPathArray);
// 	}
// 
// 	//////////////////////////////////////////////////////////////////////////
// 	//	�ָ��л��豸״̬
// 	for (i=0; i<(int)nSwitchCompArray.size(); i++)
// 		m_CompArray[nSwitchCompArray[i]].nStatus = 1;
// 	//	�ָ��л��豸״̬
// 	//////////////////////////////////////////////////////////////////////////
// 
// 	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
// 	{
// 		sMinPathArray[nPath].nStatus = 0;
// 		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
// 		{
// 			if (m_CompArray[sMinPathArray[nPath].nCompArray[i]].nStatus != 0)
// 				sMinPathArray[nPath].nStatus++;
// 		}
// 	}
// 
// 	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
// 		sMinPathArray[nPath].nCompVector.resize(m_CompArray.size(), 0);
// 
// 	dEnd=clock();
// 	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 
// #ifdef _DEBUG
// 	Log(g_lpszLogFile,  "    �л���С·(MinPath = %d) [EndNode = %d]��ɣ���ʱ%d����\n", sMinPathArray.size(), nEndNodeArray.size(), nDur);
// 
// 	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
// 	{
// 		if (sMinPathArray[nPath].nCompArray.empty())
// 			continue;
// 
// 		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
// 		{
// 			nComp = sMinPathArray[nPath].nCompArray[i];
// 			Log(g_lpszLogFile, "          (�л���С·-%d/%d PathStatus=%d) %s, %s, (%f, %f, %f, %f) CompStatus = %d\n", i+1, sMinPathArray[nPath].nCompArray.size(), sMinPathArray[nPath].nStatus,
// 				PGGetTableName(m_CompArray[nComp].nPhyTyp), m_CompArray[nComp].strName.c_str(), m_CompArray[nComp].fRerr, m_CompArray[nComp].fTrep, m_CompArray[nComp].fRchk, m_CompArray[nComp].fTchk, m_CompArray[nComp].nStatus);
// 		}
// 		Log(g_lpszLogFile, "\n");
// 	}
// #endif
// 
// _ClearOut:	;
// 	for (nPath=0; nPath<(int)m_MinPathArray.size(); nPath++)
// 	{
// 		for (i=0; i<(int)m_MinPathArray[nPath].nCompArray.size(); i++)
// 			m_CompArray[m_MinPathArray[nPath].nCompArray[i]].nStatus = 0;
// 	}
// 	nSwitchCompArray.clear();
// }

void CMCRAlgorithm::FormSwitchMinPath(const int nAlgNode, const unsigned char nPathOrient, std::vector<tagMCRAlgPath>& sMinPathArray)
{
	register int	i;
	int				nComp, nPath;
	std::vector<int>	nRangeNodeArray, nEndNodeArray;
	std::vector<unsigned char>	nCompStatusArray;
	std::vector<int>			nCompNodeArray;
	std::vector<tagMCRAlgPath>	sPathBufferArray;
	clock_t	dBeg, dEnd;
	int		nDur;

	dBeg=clock();

	short			nBoundType = (nPathOrient == Load2GenPath) ? PG_SYNCHRONOUSMACHINE : PG_ENERGYCONSUMER;
	unsigned char	nDirection = (nPathOrient == Load2GenPath) ? PosDirection : NegDirection;

	sMinPathArray.clear();
	if (m_NodeArray[nAlgNode].nPhyType == nBoundType)		//	�����뷢��ֱ��
		return;

	//////////////////////////////////////////////////////////////////////////
	//	��¼�豸״̬�������豸״̬�ú�
	nCompStatusArray.resize(m_CompArray.size());
	for (i=0; i<(int)m_CompArray.size(); i++)
	{
		nCompStatusArray[i] = m_CompArray[i].nStatus;
		m_CompArray[i].nStatus = 0;
	}
	//	��¼�豸״̬
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	//	�γɼ���ڵ㼯��
	AlgTraverse(nAlgNode, nBoundType, 1, nRangeNodeArray);
	if (nRangeNodeArray.size() <= 1)
		goto _ClearOut;

	nEndNodeArray.clear();
	for (i=0; i<(int)nRangeNodeArray.size(); i++)
	{
		if (m_NodeArray[nRangeNodeArray[i]].nPhyType == nBoundType)
			nEndNodeArray.push_back(nRangeNodeArray[i]);
	}
	//	�γɼ���ڵ㼯��
	//////////////////////////////////////////////////////////////////////////

	if (!m_DisJoint.DisJoint_Init(nAlgNode, nDirection, YCheckStatus, m_NodeArray, m_CompArray, nRangeNodeArray))
		goto _ClearOut;

	for (i=0; i<(int)nEndNodeArray.size(); i++)
	{
		m_DisJoint.DisJoint_Calc(nEndNodeArray[i], nRangeNodeArray);
		m_DisJoint.DisJoint2MinPath(m_NodeArray, m_CompArray, nRangeNodeArray, sMinPathArray);
	}

	//////////////////////////////////////////////////////////////////////////
	//	�ָ��豸״̬
	for (i=0; i<(int)m_CompArray.size(); i++)
		m_CompArray[i].nStatus = nCompStatusArray[i];
	//	�ָ��豸״̬
	//////////////////////////////////////////////////////////////////////////

	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		sMinPathArray[nPath].nStatus = 0;
		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			if (m_CompArray[sMinPathArray[nPath].nCompArray[i]].nStatus != 0)
				sMinPathArray[nPath].nStatus++;
		}
	}

	sPathBufferArray.clear();
	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		if (sMinPathArray[nPath].nStatus > 1)
			continue;

		sPathBufferArray.push_back(sMinPathArray[nPath]);
	}
	sMinPathArray.assign(sPathBufferArray.begin(), sPathBufferArray.end());
	sPathBufferArray.clear();

	//////////////////////////////////////////////////////////////////////////
	//	��ĸ����Ϊ֧·���ӵ�·����
	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		nCompNodeArray.clear();
		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp=sMinPathArray[nPath].nCompArray[i];
			if (m_CompArray[nComp].nIniAlgNode != m_CompArray[nComp].nEndAlgNode)
			{
				AddUniqueInteger(nCompNodeArray, m_CompArray[nComp].nIniAlgNode);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
				AddUniqueInteger(nCompNodeArray, m_CompArray[nComp].nEndAlgNode);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
			}
		}
		for (i=0; i<(int)nCompNodeArray.size(); i++)
		{
			for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
			{
				if (m_CompArray[nComp].nPhyTyp != PG_BUSBARSECTION)
					continue;
				if (m_CompArray[nComp].fRerr < FLT_MIN || m_CompArray[nComp].fTrep < FLT_MIN)
					continue;
				if (m_CompArray[nComp].nIniAlgNode != nCompNodeArray[i])
					continue;

				AddUniqueInteger(sMinPathArray[nPath].nCompArray, nComp);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
			}
		}
	}
	//	��ĸ����Ϊ֧·���ӵ�·����
	//////////////////////////////////////////////////////////////////////////

	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
		sMinPathArray[nPath].nCompVector.resize(m_CompArray.size(), 0);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    �л���С·(MinPath = %d) [EndNode = %d]��ɣ���ʱ%d����\n", sMinPathArray.size(), nEndNodeArray.size(), nDur);
	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		if (sMinPathArray[nPath].nCompArray.empty())
			continue;

		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp = sMinPathArray[nPath].nCompArray[i];
			Log(g_lpszLogFile, "          (�л���С·-%d/%d PathStatus=%d) %s, %s, (%f, %f, %f, %f) CompStatus = %d\n", i+1, sMinPathArray[nPath].nCompArray.size(), sMinPathArray[nPath].nStatus,
				PGGetTableName(m_CompArray[nComp].nPhyTyp), m_CompArray[nComp].strName.c_str(), m_CompArray[nComp].fRerr, m_CompArray[nComp].fTrep, m_CompArray[nComp].fRchk, m_CompArray[nComp].fTchk, m_CompArray[nComp].nStatus);
		}
		Log(g_lpszLogFile, "\n");
	}
#endif

_ClearOut:	;
	for (nPath=0; nPath<(int)m_MinPathArray.size(); nPath++)
	{
		for (i=0; i<(int)m_MinPathArray[nPath].nCompArray.size(); i++)
			m_CompArray[m_MinPathArray[nPath].nCompArray[i]].nStatus = 0;
	}
}
