#include "StdAfx.h"
#include "MCRAlgorithm.h"

void CMCRAlgorithm::CalculateAllLoadReliablity(const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure)
{
	int		nDev;
	clock_t	dBeg, dEnd;
	int		nDur;

	if (m_nMaxPhyNode <= 0)
		return;

	//nDev=0;
	for (nDev=0; nDev<(int)m_LoadArray.size(); nDev++)	//ѭ��ÿ�����ɵ�
	{
		PrintMessage("���㸺�ɿɿ���: %s", m_LoadArray[nDev].szName);
		Log(g_lpszLogFile, "���㸺�ɿɿ���: %s\n", m_LoadArray[nDev].szName);

		dBeg=clock();
		CalculateLoadReliability(&g_MCRPhyData, nDev, bFCutPlan, bExcludeCommon, bExcludeSwitch, bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

		PrintMessage("    ����(%s)�ɿ��Լ�����ɣ���ʱ%d����", m_LoadArray[nDev].szName, nDur);
		Log(g_lpszLogFile, "    ����(%s)�ɿ��Լ�����ɣ���ʱ%d����\n", m_LoadArray[nDev].szName, nDur);
	}
}

void CMCRAlgorithm::CalculateAugLoadReliablity(CMCRPhyData* pPhyData, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure)
{
	register int	i;
	clock_t	dBeg, dEnd;
	int		nDur;
	double	fRCTime;

	if (m_nMaxPhyNode <= 0)
		return;

	std::vector<tagMCRAlgGen>	sGenArray;
	std::vector<tagMCRAlgLoad>	sLoadArray;
	std::vector<tagMCRAlgComp>	sCompArray;
	std::vector<tagMCRAlgNode>	sNodeArray;
	sGenArray.assign(m_GenArray.begin(), m_GenArray.end());
	sLoadArray.assign(m_LoadArray.begin(), m_LoadArray.end());
	sCompArray.assign(m_CompArray.begin(), m_CompArray.end());
	sNodeArray.assign(m_NodeArray.begin(), m_NodeArray.end());

	m_LoadArray.clear();
	m_LoadArray.push_back(m_AugLoad);
	for (i=0; i<(int)m_NodeArray.size(); i++)
	{
		if (m_NodeArray[i].nPhyType == PG_ENERGYCONSUMER)
			m_NodeArray[i].nPhyType = PG_ACLINESEGMENT;
	}

	tagMCRAlgNode	sNodeBuf;
	InitializeAlgNode(&sNodeBuf);
	sNodeBuf.bAugNode = 1;
	sNodeBuf.nPhyNode = m_nMaxPhyNode+1;
	sNodeBuf.nPhyType = PG_ENERGYCONSUMER;
	m_NodeArray.push_back(sNodeBuf);

	for (i=0; i<(int)m_AugLoadCompArray.size(); i++)
		m_CompArray.push_back(m_AugLoadCompArray[i]);

	AlgTopo();

	PrintMessage("����ȫվͣ�縺�ɿɿ���: %s", m_AugLoad.szName);
	Log(g_lpszLogFile, "����ȫվͣ�縺�ɿɿ���: %s\n", m_AugLoad.szName);

	//	��ʼ������
	m_MinPathArray.clear();		//	��С·
	m_MinCut1Array.clear();		//	һ����С��
	m_MinCut2Array.clear();		//	������С��
	m_MinCut3Array.clear();		//	������С��
	m_CmMCut1Array.clear();		//	һ�׹��Ϲ�ģ�滻��С��
	m_CmMCut2Array.clear();		//	���׹��Ϲ�ģ�滻��С��

	dBeg=clock();
	FormNormalMinPath(m_LoadArray[0].nAlgNode, Load2GenPath, m_MinPathArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С·��ɣ���ʱ%d����", nDur);
	Log(g_lpszLogFile, "          ��С·��ɣ���ʱ%d����\n", nDur);

	FormNormalShortCut();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С�������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��С�������ɣ���ʱ%d����\n",  nDur);

	if (!bExcludeCommon)
	{
		FormDegreeShortCut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ���۹��ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ���۹��ϼ�����ɣ���ʱ%d����\n",  nDur);

		FormCommonShortcut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ��ģ���ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ��ģ���ϼ�����ɣ���ʱ%d����\n",  nDur);

		EraseDegreeShortCut();
	}

	if (!bExcludeSwitch)
	{
		std::vector<tagMCRAlgPath>	sMinPathArray;			//	�л���С·
		FormSwitchMinPath(m_LoadArray[0].nAlgNode, Load2GenPath, sMinPathArray);

		FormSwitchShortCut(sMinPathArray);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          �л�������ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          �л�������ɣ���ʱ%d����\n",  nDur);

		sMinPathArray.clear();
	}

	memset(&m_AugLoad.sResult, 0, sizeof(tagMCRAlgResult));

	ParallelShortcut(bFCutPlan);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��ڲ���������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��ڲ���������ɣ���ʱ%d����\n",  nDur);

	SeriesShortcut(&m_AugLoad.sResult);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��䴮��������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��䴮��������ɣ���ʱ%d����\n",  nDur);

	CompContribution(m_AugLoad.fLoadP);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����\n",  nDur);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	fRCTime=(nDur/1000.0);

	PrintMessage("    ����(%s)�ɿ��Լ�����ɣ���ʱ%d����", m_AugLoad.szName, nDur);
	Log(g_lpszLogFile, "    ����(%s)�ɿ��Լ�����ɣ���ʱ%d����\n", m_AugLoad.szName, nDur);

	Alg2PhyLoad(pPhyData, 1, 0, fRCTime);

	m_GenArray.assign(sGenArray.begin(), sGenArray.end());
	m_LoadArray.assign(sLoadArray.begin(), sLoadArray.end());
	m_CompArray.assign(sCompArray.begin(), sCompArray.end());
	m_NodeArray.assign(sNodeArray.begin(), sNodeArray.end());

	sGenArray.clear();
	sLoadArray.clear();
	sCompArray.clear();
	sNodeArray.clear();
}

void CMCRAlgorithm::CalculateLoadReliability(CMCRPhyData* pPhyData, const int nAlgLoad, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure)
{
	clock_t	dBeg, dEnd;
	int		nDur;
	double	fRCTime;

	//	��ʼ������
	m_MinPathArray.clear();		//	��С·
	m_MinCut1Array.clear();		//	һ����С��
	m_MinCut2Array.clear();		//	������С��
	m_MinCut3Array.clear();		//	������С��
	m_CmMCut1Array.clear();		//	һ�׹��Ϲ�ģ�滻��С��
	m_CmMCut2Array.clear();		//	���׹��Ϲ�ģ�滻��С��

	dBeg=clock();
	FormNormalMinPath(m_LoadArray[nAlgLoad].nAlgNode, Load2GenPath, m_MinPathArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С·��ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��С·��ɣ���ʱ%d����\n",  nDur);

	FormNormalShortCut();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С�������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��С�������ɣ���ʱ%d����\n",  nDur);

	if (!bExcludeCommon)
	{
		FormDegreeShortCut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ���۹��ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ���۹��ϼ�����ɣ���ʱ%d����\n",  nDur);

		FormCommonShortcut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ��ģ���ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ��ģ���ϼ�����ɣ���ʱ%d����\n",  nDur);

		EraseDegreeShortCut();
	}

	if (!bExcludeSwitch)
	{
		std::vector<tagMCRAlgPath>	sMinPathArray;			//	�л���С·
		FormSwitchMinPath(m_LoadArray[nAlgLoad].nAlgNode, Load2GenPath, sMinPathArray);

		FormSwitchShortCut(sMinPathArray);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          �л�������ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          �л�������ɣ���ʱ%d����\n",  nDur);

		sMinPathArray.clear();
	}

	memset(&m_LoadArray[nAlgLoad].sResult, 0, sizeof(tagMCRAlgResult));

	ParallelShortcut(bFCutPlan);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��ڲ���������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��ڲ���������ɣ���ʱ%d����\n",  nDur);

	SeriesShortcut(&m_LoadArray[nAlgLoad].sResult);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��䴮��������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��䴮��������ɣ���ʱ%d����\n",  nDur);

	CompContribution(m_LoadArray[nAlgLoad].fLoadP);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����\n",  nDur);

	int		nPerturbIndex, nPerturb, nIniPerturb, nEndPerturb;
	if (g_MCRPerturb.m_Param.nPerturbType == 0)
	{
		nIniPerturb = 0;
		nEndPerturb = (g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb;
	}
	else
	{
		nIniPerturb = -((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb);
		nEndPerturb = +((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb);
	}

	m_CompBackArray.resize(m_CompArray.size());
	for (int nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		m_CompBackArray[nDev].fRerr	= m_CompArray[nDev].fRerr		;
		m_CompBackArray[nDev].fTrep	= m_CompArray[nDev].fTrep		;
		m_CompBackArray[nDev].fRchk	= m_CompArray[nDev].fRchk		;
		m_CompBackArray[nDev].fTchk	= m_CompArray[nDev].fTchk		;
		m_CompBackArray[nDev].fTopr = m_CompArray[nDev].fTopr		;
		m_CompBackArray[nDev].fTSwitch = m_CompArray[nDev].fTSwitch	;
	}

	nPerturbIndex = 0;
	for (nPerturb=nIniPerturb; nPerturb<=nEndPerturb; nPerturb++)
	{
		if (nPerturb == 0)
		{
			memcpy(&m_LoadArray[nAlgLoad].sPerturbResult[nPerturbIndex], &m_LoadArray[nAlgLoad].sResult, sizeof(tagMCRAlgResult));
		}
		else
		{
			memset(&m_LoadArray[nAlgLoad].sPerturbResult[nPerturbIndex], 0, sizeof(tagMCRAlgResult));

			PerturbAmend(nPerturb);

			ParallelShortcut(bFCutPlan);
			SeriesShortcut(&m_LoadArray[nAlgLoad].sPerturbResult[nPerturbIndex]);

			PerturbRestore();
		}
		nPerturbIndex++;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	fRCTime=(nDur/1000.0);

	Alg2PhyLoad(pPhyData, 0, nAlgLoad, fRCTime);

#ifdef _DEBUG
	Log(g_lpszLogFile,  "Load[%d] FaultR=%f FaultT=%f PlanR=%f PlanT=%f\n", nAlgLoad, m_LoadArray[nAlgLoad].sResult.fFaultR, m_LoadArray[nAlgLoad].sResult.fFaultU, m_LoadArray[nAlgLoad].sResult.fPlanR, m_LoadArray[nAlgLoad].sResult.fPlanU);
#endif
}

void CMCRAlgorithm::CalculateAllGenReliablity(const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure)
{
	int		nDev;
	clock_t	dBeg, dEnd;
	int		nDur;

	if (m_nMaxPhyNode <= 0)
		return;

	//nDev = 0;
	for (nDev=0; nDev<(int)m_GenArray.size(); nDev++)	//ѭ��ÿ����Դ��
	{
		PrintMessage("�����Դ[%d]�ɿ���: %s", m_GenArray[nDev].nPhyTyp, m_GenArray[nDev].szName);
		Log(g_lpszLogFile, "�����Դ[%d]�ɿ���: %s\n", m_GenArray[nDev].nPhyTyp, m_GenArray[nDev].szName);

		dBeg=clock();
		CalculateGenReliability(&g_MCRPhyData, nDev, bFCutPlan, bExcludeCommon, bExcludeSwitch, bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

		PrintMessage("    ��Դ(%s)�ɿ��Լ�����ɣ���ʱ%d����", m_GenArray[nDev].szName, nDur);
		Log(g_lpszLogFile, "    ��Դ(%s)�ɿ��Լ�����ɣ���ʱ%d����\n", m_GenArray[nDev].szName, nDur);
	}
}

void CMCRAlgorithm::CalculateAugGenReliablity(CMCRPhyData* pPhyData, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure)
{
	register int	i;
	clock_t	dBeg, dEnd;
	int		nDur;
	double	fRCTime;

	std::vector<tagMCRAlgGen>	sGenArray;
	std::vector<tagMCRAlgLoad>	sLoadArray;
	std::vector<tagMCRAlgComp>	sCompArray;
	std::vector<tagMCRAlgNode>	sNodeArray;
	sGenArray.assign(m_GenArray.begin(), m_GenArray.end());
	sLoadArray.assign(m_LoadArray.begin(), m_LoadArray.end());
	sCompArray.assign(m_CompArray.begin(), m_CompArray.end());
	sNodeArray.assign(m_NodeArray.begin(), m_NodeArray.end());

	m_GenArray.clear();
	m_GenArray.push_back(m_AugGen);
	for (i=0; i<(int)m_NodeArray.size(); i++)
	{
		if (m_NodeArray[i].nPhyType == PG_SYNCHRONOUSMACHINE)
			m_NodeArray[i].nPhyType = PG_ACLINESEGMENT;
	}

	tagMCRAlgNode	sNodeBuf;
	InitializeAlgNode(&sNodeBuf);
	sNodeBuf.bAugNode = 1;
	sNodeBuf.nPhyNode = m_nMaxPhyNode+1;
	sNodeBuf.nPhyType = PG_SYNCHRONOUSMACHINE;
	m_NodeArray.push_back(sNodeBuf);

	for (i=0; i<(int)m_AugGenCompArray.size(); i++)
		m_CompArray.push_back(m_AugGenCompArray[i]);

	AlgTopo();

	PrintMessage("����ȫվͣ���Դ�ɿ���: %s", m_AugGen.szName);
	Log(g_lpszLogFile, "����ȫվͣ���Դ�ɿ���: %s\n", m_AugGen.szName);

	//	��ʼ������
	m_MinPathArray.clear();		//	��С·
	m_MinCut1Array.clear();		//	һ����С��
	m_MinCut2Array.clear();		//	������С��
	m_MinCut3Array.clear();		//	������С��
	m_CmMCut1Array.clear();		//	һ�׹��Ϲ�ģ�滻��С��
	m_CmMCut2Array.clear();		//	���׹��Ϲ�ģ�滻��С��

	dBeg=clock();
	FormNormalMinPath(m_GenArray[0].nAlgNode, Gen2LoadPath, m_MinPathArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С·��ɣ���ʱ%d����", nDur);
	Log(g_lpszLogFile, "          ��С·��ɣ���ʱ%d����\n", nDur);

	FormNormalShortCut();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С�������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��С�������ɣ���ʱ%d����\n",  nDur);

	if (!bExcludeCommon)
	{
		FormDegreeShortCut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ���۹��ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ���۹��ϼ�����ɣ���ʱ%d����\n",  nDur);

		FormCommonShortcut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ��ģ���ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ��ģ���ϼ�����ɣ���ʱ%d����\n",  nDur);

		EraseDegreeShortCut();
	}

	if (!bExcludeSwitch)
	{
		std::vector<tagMCRAlgPath>	sMinPathArray;			//	�л���С·
		FormSwitchMinPath(m_GenArray[0].nAlgNode, Gen2LoadPath, sMinPathArray);

		FormSwitchShortCut(sMinPathArray);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          �л�������ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          �л�������ɣ���ʱ%d����\n",  nDur);

		sMinPathArray.clear();
	}

	memset(&m_AugGen.sResult, 0, sizeof(tagMCRAlgResult));

	ParallelShortcut(bFCutPlan);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��ڲ���������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��ڲ���������ɣ���ʱ%d����\n",  nDur);

	SeriesShortcut(&m_AugGen.sResult);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��䴮��������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��䴮��������ɣ���ʱ%d����\n",  nDur);

	CompContribution(m_AugGen.fOutP);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����\n",  nDur);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	PrintMessage("    ��Դ(%s)�ɿ��Լ�����ɣ���ʱ%d����", m_AugGen.szName, nDur);
	Log(g_lpszLogFile, "    ��Դ(%s)�ɿ��Լ�����ɣ���ʱ%d����\n", m_AugGen.szName, nDur);

	fRCTime=(nDur/1000.0);

	Alg2PhyGen(pPhyData, 1, 0, fRCTime);

	m_GenArray.assign(sGenArray.begin(), sGenArray.end());
	m_LoadArray.assign(sLoadArray.begin(), sLoadArray.end());
	m_CompArray.assign(sCompArray.begin(), sCompArray.end());
	m_NodeArray.assign(sNodeArray.begin(), sNodeArray.end());

	sGenArray.clear();
	sLoadArray.clear();
	sCompArray.clear();
	sNodeArray.clear();
}

void CMCRAlgorithm::CalculateGenReliability(CMCRPhyData* pPhyData, const int nAlgGen, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure)
{
	clock_t	dBeg, dEnd;
	int		nDur;
	double	fRCTime;

	//	��ʼ������
	m_MinPathArray.clear();		//	��С·
	m_MinCut1Array.clear();		//	һ����С��
	m_MinCut2Array.clear();		//	������С��
	m_MinCut3Array.clear();		//	������С��
	m_CmMCut1Array.clear();		//	һ�׹��Ϲ�ģ�滻��С��
	m_CmMCut2Array.clear();		//	���׹��Ϲ�ģ�滻��С��

	dBeg=clock();
	FormNormalMinPath(m_GenArray[nAlgGen].nAlgNode, Gen2LoadPath, m_MinPathArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С·��ɣ���ʱ%d����", nDur);
	Log(g_lpszLogFile, "          ��С·��ɣ���ʱ%d����\n", nDur);

	FormNormalShortCut();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��С�������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��С�������ɣ���ʱ%d����\n",  nDur);

	if (!bExcludeCommon)
	{
		FormDegreeShortCut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ���۹��ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ���۹��ϼ�����ɣ���ʱ%d����\n",  nDur);

		FormCommonShortcut(bBreakerFaultFailure);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          ��ģ���ϼ�����ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          ��ģ���ϼ�����ɣ���ʱ%d����\n",  nDur);

		EraseDegreeShortCut();
	}

	if (!bExcludeSwitch)
	{
		std::vector<tagMCRAlgPath>	sMinPathArray;			//	�л���С·
		FormSwitchMinPath(m_GenArray[nAlgGen].nAlgNode, Gen2LoadPath, sMinPathArray);

		FormSwitchShortCut(sMinPathArray);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("          �л�������ɣ���ʱ%d����",  nDur);
		Log(g_lpszLogFile, "          �л�������ɣ���ʱ%d����\n",  nDur);

		sMinPathArray.clear();
	}

	memset(&m_GenArray[nAlgGen].sResult, 0, sizeof(tagMCRAlgResult));

	ParallelShortcut(bFCutPlan);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��ڲ���������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��ڲ���������ɣ���ʱ%d����\n",  nDur);

	SeriesShortcut(&m_GenArray[nAlgGen].sResult);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          ��䴮��������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          ��䴮��������ɣ���ʱ%d����\n",  nDur);

	CompContribution(0);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "          �ɿ��Թ��׶ȼ�����ɣ���ʱ%d����\n",  nDur);

	int		nPerturbIndex, nPerturb, nIniPerturb, nEndPerturb;
	if (g_MCRPerturb.m_Param.nPerturbType == 0)
	{
		nIniPerturb = 0;
		nEndPerturb = (g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb;
	}
	else
	{
		nIniPerturb = -((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb);
		nEndPerturb = +((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb);
	}

	m_CompBackArray.resize(m_CompArray.size());
	for (int nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		m_CompBackArray[nDev].fRerr	= m_CompArray[nDev].fRerr		;
		m_CompBackArray[nDev].fTrep	= m_CompArray[nDev].fTrep		;
		m_CompBackArray[nDev].fRchk	= m_CompArray[nDev].fRchk		;
		m_CompBackArray[nDev].fTchk	= m_CompArray[nDev].fTchk		;
		m_CompBackArray[nDev].fTopr = m_CompArray[nDev].fTopr		;
		m_CompBackArray[nDev].fTSwitch = m_CompArray[nDev].fTSwitch	;
	}

	nPerturbIndex = 0;
	for (nPerturb=nIniPerturb; nPerturb<=nEndPerturb; nPerturb++)
	{
		if (nPerturb == 0)
		{
			memcpy(&m_GenArray[nAlgGen].sPerturbResult[nPerturbIndex], &m_GenArray[nAlgGen].sResult, sizeof(tagMCRAlgResult));
		}
		else
		{
			memset(&m_GenArray[nAlgGen].sPerturbResult[nPerturbIndex], 0, sizeof(tagMCRAlgResult));

			PerturbAmend(nPerturb);

			ParallelShortcut(bFCutPlan);
			SeriesShortcut(&m_GenArray[nAlgGen].sPerturbResult[nPerturbIndex]);

			PerturbRestore();
		}
		nPerturbIndex++;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	fRCTime=(nDur/1000.0);

	Alg2PhyGen(pPhyData, 0, nAlgGen, fRCTime);

#ifdef _DEBUG
	Log(g_lpszLogFile,  "Gen[%d] FaultR=%f FaultT=%f PlanR=%f PlanT=%f\n", nAlgGen, m_GenArray[nAlgGen].sResult.fFaultR, m_GenArray[nAlgGen].sResult.fFaultU, m_GenArray[nAlgGen].sResult.fPlanR, m_GenArray[nAlgGen].sResult.fPlanU);
#endif
}

void CMCRAlgorithm::ParallelShortcut(const unsigned char bFCutPlan)
{
	int	nMCut;
	int nFComp=0;
	int nSComp=0;
	int nTComp=0;
	double	fFR1, fFR2, fFR3, fFT1, fFT2, fFT3;
	double	fAR1, fAR2, fAR3, fAT1, fAT2, fAT3;

	//һ�׸��ͬʱ���ǹ��Ϻͼ��ޣ������ǹ�ģ
	for (nMCut=0; nMCut<(int)m_MinCut1Array.size(); nMCut++)
	{
		nFComp = m_MinCut1Array[nMCut].nComp;	//��С���е�Ԫ��

		m_MinCut1Array[nMCut].fR=m_CompArray[nFComp].fRerr;
		m_MinCut1Array[nMCut].fT=m_CompArray[nFComp].fTrep;

		m_MinCut1Array[nMCut].fFaultR=m_CompArray[nFComp].fRerr;
		m_MinCut1Array[nMCut].fFaultT=m_CompArray[nFComp].fTrep;

		if (bFCutPlan && m_CompArray[nFComp].bFCutPlan)	//һ�׸�е�Ԫ�ؿ��Ǽ���
		{
			m_MinCut1Array[nMCut].fR=m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk;
			if (m_MinCut1Array[nMCut].fR > FLT_MIN)	m_MinCut1Array[nMCut].fT=(m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk)/m_MinCut1Array[nMCut].fR;

			m_MinCut1Array[nMCut].fPlanR=m_CompArray[nFComp].fRchk;
			m_MinCut1Array[nMCut].fPlanT=m_CompArray[nFComp].fTchk;
		}

		if (m_MinCut1Array[nMCut].nSwitchComp >= 0 && m_CompArray[nFComp].fTopr > FLT_MIN && m_CompArray[m_MinCut1Array[nMCut].nSwitchComp].fTSwitch > FLT_MIN)
		{
			m_MinCut1Array[nMCut].fT		=min(m_CompArray[nFComp].fTopr+m_CompArray[m_MinCut1Array[nMCut].nSwitchComp].fTSwitch, m_CompArray[nFComp].fTrep);
			m_MinCut1Array[nMCut].fFaultT	=min(m_CompArray[nFComp].fTopr+m_CompArray[m_MinCut1Array[nMCut].nSwitchComp].fTSwitch, m_CompArray[nFComp].fTrep);
		}
	}

	//���ף�ͬʱ���ǹ��Ϻͼ��ޣ������ǹ�ģ
	for (nMCut=0; nMCut<(int)m_MinCut2Array.size(); nMCut++)
	{
		nFComp = m_MinCut2Array[nMCut].nComp[0];
		nSComp = m_MinCut2Array[nMCut].nComp[1];

		fFR1=m_CompArray[nFComp].fRerr;
		fFR2=m_CompArray[nSComp].fRerr;
		fFR3=0;
		fFT1=m_CompArray[nFComp].fTrep;
		fFT2=m_CompArray[nSComp].fTrep;
		fFT3=0;

		fAR1=m_CompArray[nFComp].fRchk;
		fAR2=m_CompArray[nSComp].fRchk;
		fAR3=0;
		fAT1=m_CompArray[nFComp].fTchk;
		fAT2=m_CompArray[nSComp].fTchk;
		fAT3=0;

		//	�Ǹ��豸���л������Ǹ��豸���л�ʱ��
		if (m_MinCut2Array[nMCut].nSwitchComp[0] >= 0 && m_CompArray[nFComp].fTopr > FLT_MIN && m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[0]].fTSwitch > FLT_MIN)
		{
			fFT1=min(m_CompArray[nFComp].fTopr+m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[0]].fTSwitch, m_CompArray[nFComp].fTrep);
		}
		if (m_MinCut2Array[nMCut].nSwitchComp[1] >= 0 && m_CompArray[nSComp].fTopr > FLT_MIN && m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[1]].fTSwitch > FLT_MIN)
		{
			fFT2=min(m_CompArray[nSComp].fTopr+m_CompArray[m_MinCut2Array[nMCut].nSwitchComp[1]].fTSwitch, m_CompArray[nSComp].fTrep);
		}

		m_MinCut2Array[nMCut].fR=fFR1*fFR2*(fFT1+fFT2)/8760+fFR2*fAR1*fAT1/8760+fFR1*fAR2*fAT2/8760;
		if (8760*m_MinCut2Array[nMCut].fR > FLT_MIN)
		{
			m_MinCut2Array[nMCut].fT=fFR1*fFR2*fFT1*fFT2;
			if (fAT1+fFT2 > FLT_MIN)	m_MinCut2Array[nMCut].fT += fFR2*fAR1*fAT1*(fAT1*fFT2)/(fAT1+fFT2);
			if (fFT1+fAT2 > FLT_MIN)	m_MinCut2Array[nMCut].fT += fFR1*fAR2*fAT2*(fFT1*fAT2)/(fFT1+fAT2);
			m_MinCut2Array[nMCut].fT /= (8760*m_MinCut2Array[nMCut].fR);
		}

		m_MinCut2Array[nMCut].fFaultR=fFR1*fFR2*(fFT1+fFT2)/8760;
		if (8760*m_MinCut2Array[nMCut].fFaultR > FLT_MIN)
			m_MinCut2Array[nMCut].fFaultT=(fFR1*fFT1*fFR2*fFT2)/(m_MinCut2Array[nMCut].fFaultR*8760);

		//Ԥ����ͣ��
		m_MinCut2Array[nMCut].fPlanR=m_MinCut2Array[nMCut].fR-m_MinCut2Array[nMCut].fFaultR;
		if (8760*m_MinCut2Array[nMCut].fPlanR > FLT_MIN)
			m_MinCut2Array[nMCut].fPlanT=(m_MinCut2Array[nMCut].fR*m_MinCut2Array[nMCut].fT-m_MinCut2Array[nMCut].fFaultR*m_MinCut2Array[nMCut].fFaultT)/m_MinCut2Array[nMCut].fPlanR;
	}

	//���ף�ͬʱ���ǹ��Ϻͼ��ޣ������ǹ�ģ
	for (nMCut=0; nMCut<(int)m_MinCut3Array.size(); nMCut++)
	{
		nFComp = m_MinCut3Array[nMCut].nComp[0];
		nSComp = m_MinCut3Array[nMCut].nComp[1];
		nTComp = m_MinCut3Array[nMCut].nComp[2];

		fFR1=m_CompArray[nFComp].fRerr;
		fFR2=m_CompArray[nSComp].fRerr;
		fFR3=m_CompArray[nTComp].fRerr;
		fFT1=m_CompArray[nFComp].fTrep;
		fFT2=m_CompArray[nSComp].fTrep;
		fFT3=m_CompArray[nTComp].fTrep;

		fAR1=m_CompArray[nFComp].fRchk;
		fAR2=m_CompArray[nSComp].fRchk;
		fAR3=m_CompArray[nTComp].fRchk;
		fAT1=m_CompArray[nFComp].fTchk;
		fAT2=m_CompArray[nSComp].fTchk;
		fAT3=m_CompArray[nTComp].fTchk;

		//	�Ǹ��豸���л������Ǹ��豸���л�ʱ��
		if (m_MinCut3Array[nMCut].nSwitchComp[0] >= 0 && m_CompArray[nFComp].fTopr > FLT_MIN && m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[0]].fTSwitch > FLT_MIN)
		{
			fFT1=min(m_CompArray[nFComp].fTopr+m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[0]].fTSwitch, m_CompArray[nFComp].fTrep);
		}
		if (m_MinCut3Array[nMCut].nSwitchComp[1] >= 0 && m_CompArray[nSComp].fTopr > FLT_MIN && m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[1]].fTSwitch > FLT_MIN)
		{
			fFT2=min(m_CompArray[nSComp].fTopr+m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[1]].fTSwitch, m_CompArray[nSComp].fTrep);
		}
		if (m_MinCut3Array[nMCut].nSwitchComp[2] >= 0 && m_CompArray[nTComp].fTopr > FLT_MIN && m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[2]].fTSwitch > FLT_MIN)
		{
			fFT3=min(m_CompArray[nTComp].fTopr+m_CompArray[m_MinCut3Array[nMCut].nSwitchComp[2]].fTSwitch, m_CompArray[nTComp].fTrep);
		}

		m_MinCut3Array[nMCut].fR=fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)/(8760*8760)+
			fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1/(8760*8760)+
			fFR1*fFR3*(fFT1+fFT3)*fAR2*fAT2/(8760*8760)+
			fFR1*fFR2*(fFT1+fFT2)*fAR3*fAT3/(8760*8760);
		if (8760*8760*m_MinCut3Array[nMCut].fR > FLT_MIN)
		{
			m_MinCut3Array[nMCut].fT = 0;
			if ((fFT1*fFT2+fFT1*fFT3+fFT2*fFT3) > FLT_MIN)	m_MinCut3Array[nMCut].fT += fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)*(fFT1*fFT2*fFT3)/(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3);
			if ((fAT1*fFT2+fAT1*fFT3+fFT2*fFT3) > FLT_MIN)	m_MinCut3Array[nMCut].fT += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1*(fAT1*fFT2*fFT3)/(fAT1*fFT2+fAT1*fFT3+fFT2*fFT3);
			if ((fFT1*fAT2+fFT1*fFT3+fAT2*fFT3) > FLT_MIN)	m_MinCut3Array[nMCut].fT += fFR1*fFR3*(fFT1+fFT3)*fAR2*fAT2*(fFT1*fAT2*fFT3)/(fFT1*fAT2+fFT1*fFT3+fAT2*fFT3);
			if ((fFT1*fFT2+fFT1*fAT3+fFT2*fAT3) > FLT_MIN)	m_MinCut3Array[nMCut].fT += fFR1*fFR2*(fFT1+fFT2)*fAR3*fAT3*(fFT1*fFT2*fAT3)/(fFT1*fFT2+fFT1*fAT3+fFT2*fAT3);
			m_MinCut3Array[nMCut].fT /= (8760*8760*m_MinCut3Array[nMCut].fR);
		}

		m_MinCut3Array[nMCut].fFaultR=fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)/(8760*8760);
		if (8760*8760*m_MinCut3Array[nMCut].fFaultR > FLT_MIN)
			m_MinCut3Array[nMCut].fFaultT=(fFR1*fFR2*fFR3*fFT1*fFT2*fFT3)/(m_MinCut3Array[nMCut].fFaultR*8760*8760);

		//Ԥ����ͣ��
		m_MinCut3Array[nMCut].fPlanR=m_MinCut3Array[nMCut].fR-m_MinCut3Array[nMCut].fFaultR;
		if (8760*8760*m_MinCut3Array[nMCut].fPlanR > FLT_MIN)
			m_MinCut3Array[nMCut].fPlanT=(m_MinCut3Array[nMCut].fR*m_MinCut3Array[nMCut].fT-m_MinCut3Array[nMCut].fFaultR*m_MinCut3Array[nMCut].fFaultT)/m_MinCut3Array[nMCut].fPlanR;
	}

	//��ģһ�׸��ͬʱ���ǹ��Ϻͼ��ޣ������ǹ�ģ
#ifdef _DEBUG0
	Log(g_lpszLogFile, "********************************************************************************\n");
#endif
	int		nComm, nBreaker;
	for (nMCut=0; nMCut<(int)m_CmMCut1Array.size(); nMCut++)
	{
#ifdef _DEBUG0
		Log(g_lpszLogFile, "��ģһ�׸�����ʺ�ʱ��������%f %f\n", m_CmMCut1Array[nMCut].fR, m_CmMCut1Array[nMCut].fT);
#endif
		nFComp = m_CmMCut1Array[nMCut].nComp;
		m_CmMCut1Array[nMCut].fR=m_CompArray[nFComp].fRerr;
		if (m_CmMCut1Array[nMCut].nCutType == MCREnumCutType_Cut1_Cut1OneBreakerComm)
		{
			m_CmMCut1Array[nMCut].fR=m_CompArray[nFComp].fRerr;
			m_CmMCut1Array[nMCut].fT=m_CompArray[nFComp].fTopr;

			nBreaker = m_CmMCut1Array[nMCut].nCommonBreaker[0];
			if (nBreaker >= 0)
			{
				nComm = SeekBreakerComm(nBreaker, nFComp);
				if (nComm >= 0)
					m_CmMCut1Array[nMCut].fT=(m_CompArray[nBreaker].sCmCompArray[nComm].nCommType == 0) ? m_CompArray[nFComp].fTrep : m_CompArray[nFComp].fTopr;
			}

			nBreaker = m_CmMCut1Array[nMCut].nCommonBreaker[1];
			if (nBreaker >= 0)
			{
				nComm = SeekBreakerComm(nBreaker, nFComp);
				if (nComm >= 0)
					m_CmMCut1Array[nMCut].fT=(m_CompArray[nBreaker].sCmCompArray[nComm].nCommType == 0) ? m_CompArray[nFComp].fTrep : m_CompArray[nFComp].fTopr;
			}
		}
#ifdef _DEBUG0
		Log(g_lpszLogFile, "        ��ģһ�׸�����ʺ�ʱ��������%f %f\n", m_CmMCut1Array[nMCut].fR, m_CmMCut1Array[nMCut].fT);
#endif
	}

	//��ģ����
	for (nMCut=0; nMCut<(int)m_CmMCut2Array.size(); nMCut++)
	{
#ifdef _DEBUG0
		Log(g_lpszLogFile, "��ģ���׸�����ʺ�ʱ��������%f %f\n", m_CmMCut2Array[nMCut].fR, m_CmMCut2Array[nMCut].fT);
#endif
		nFComp = m_CmMCut2Array[nMCut].nComp[0];
		nSComp = m_CmMCut2Array[nMCut].nComp[1];

		fFR1=m_CompArray[nFComp].fRerr;
		fFR2=m_CompArray[nSComp].fRerr;
		fFT1=m_CompArray[nFComp].fTrep;
		fFT2=m_CompArray[nSComp].fTrep;

		nBreaker = m_CmMCut2Array[nMCut].nCommonBreaker[0];
		if (nBreaker >= 0)
		{
			nComm = SeekBreakerComm(nBreaker, nFComp);
			if (nComm >= 0)
				fFT1=(m_CompArray[nBreaker].sCmCompArray[nComm].nCommType == 0) ? m_CompArray[nFComp].fTrep : m_CompArray[nFComp].fTopr;
		}
		nBreaker = m_CmMCut2Array[nMCut].nCommonBreaker[1];
		if (nBreaker >= 0)
		{
			nComm = SeekBreakerComm(nBreaker, nSComp);
			if (nComm >= 0)
				fFT2=(m_CompArray[nBreaker].sCmCompArray[nComm].nCommType == 0) ? m_CompArray[nSComp].fTrep : m_CompArray[nSComp].fTopr;
		}

		m_CmMCut2Array[nMCut].fR=fFR1*fFR2*(fFT1+fFT2)/8760;
		if (8760*m_CmMCut2Array[nMCut].fR > FLT_MIN)
			m_CmMCut2Array[nMCut].fT=fFR1*fFR2*fFT1*fFT2/(8760*m_CmMCut2Array[nMCut].fR);

#ifdef _DEBUG0
		Log(g_lpszLogFile, "        ��ģ���׸�����ʺ�ʱ��������%f %f\n", m_CmMCut2Array[nMCut].fR, m_CmMCut2Array[nMCut].fT);
#endif
	}
#ifdef _DEBUG0
	Log(g_lpszLogFile, "********************************************************************************\n");
#endif
}

void CMCRAlgorithm::SeriesShortcut(tagMCRAlgResult* pResult)
{
	register int	i;
	double	fFCutR, fSCutR, fTCutR;
	double	fFCutT, fSCutT, fTCutT;
	double	fCommR, fCommT, fCommU;

	//////////////////////////////////////////////////////////////////////////
	//	��ģָ�����
	fFCutR=0;
	fFCutT=0;
	fSCutR=0;
	fSCutT=0;
	fTCutR=0;
	fTCutT=0;
	//һ�׼乲ģ���ϴ���
	for (i=0; i<(int)m_CmMCut1Array.size(); i++)
	{
		if (m_CmMCut1Array[i].fR < FLT_MIN || m_CmMCut1Array[i].fT < FLT_MIN)
			continue;

		fFCutT += m_CmMCut1Array[i].fR*m_CmMCut1Array[i].fT;
		fFCutR += m_CmMCut1Array[i].fR;
	}
	if (fFCutR > FLT_MIN)
		fFCutT /= fFCutR;

	//���׼乲ģ���ϴ���
	for (i=0; i<(int)m_CmMCut2Array.size(); i++)
	{
		if (m_CmMCut2Array[i].fR < FLT_MIN || m_CmMCut2Array[i].fT < FLT_MIN)
			continue;

		fSCutT += m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT;
		fSCutR += m_CmMCut2Array[i].fR;
	}
	if (fSCutR > FLT_MIN)
		fSCutT /= fSCutR;

	//��ģ���崮��
	fCommR = fFCutR+fSCutR+fTCutR;
	fCommU = fFCutR*fFCutT+fSCutR*fSCutT+fTCutR*fTCutT;
	if (fCommR > FLT_MIN)
		fCommT = fCommU/fCommR;

	//////////////////////////////////////////////////////////////////////////
	//	ǿ��ͣ��ָ�����
	fFCutR=0;
	fFCutT=0;
	fSCutR=0;
	fSCutT=0;
	fTCutR=0;
	fTCutT=0;
	//ǿ��ͣ��һ�׼䴮��
	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		if (m_MinCut1Array[i].fFaultR < FLT_MIN || m_MinCut1Array[i].fFaultT < FLT_MIN)
			continue;

		fFCutT += m_MinCut1Array[i].fFaultR*m_MinCut1Array[i].fFaultT;
		fFCutR += m_MinCut1Array[i].fFaultR;
	}
	if (fFCutR > FLT_MIN)
		fFCutT /= fFCutR;

	//ǿ��ͣ�˶��׼䴮��, �����뱾����Ǵ�����ϵ���������׸������豸ͬʱ���ϸ���ͣ�磬�����豸���ϣ�����ͣ��
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		if (m_MinCut2Array[i].fFaultR < FLT_MIN || m_MinCut2Array[i].fFaultT < FLT_MIN)
			continue;

		fSCutT += m_MinCut2Array[i].fFaultR*m_MinCut2Array[i].fFaultT;
		fSCutR += m_MinCut2Array[i].fFaultR;
	}
	if (fSCutR > FLT_MIN)
		fSCutT /= fSCutR;

	//ǿ��ͣ�����׼䴮��
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		if (m_MinCut3Array[i].fFaultR < FLT_MIN || m_MinCut3Array[i].fFaultT < FLT_MIN)
			continue;

		fTCutT += m_MinCut3Array[i].fFaultR*m_MinCut3Array[i].fFaultT;
		fTCutR += m_MinCut3Array[i].fFaultR;
	}
	if (fTCutR > FLT_MIN)
		fTCutT /= fTCutR;

	//����ǿ��ͣ�����崮��(����ģ)
	pResult->fFaultR = fCommR + fFCutR+fSCutR+fTCutR;
	pResult->fFaultU = fCommU + fFCutR*fFCutT+fSCutR*fSCutT+fTCutR*fTCutT;
	if (pResult->fFaultR > FLT_MIN)
		pResult->fFaultT = pResult->fFaultU/pResult->fFaultR;

	//////////////////////////////////////////////////////////////////////////
	//	Ԥ����ָ�����
	fFCutR=0;
	fFCutT=0;
	fSCutR=0;
	fSCutT=0;
	fTCutR=0;
	fTCutT=0;
	//�ƻ�ͣ��һ�׼䴮��
	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		if (m_MinCut1Array[i].fPlanR < FLT_MIN || m_MinCut1Array[i].fPlanT < FLT_MIN)
			continue;

		fFCutT += m_MinCut1Array[i].fPlanR*m_MinCut1Array[i].fPlanT;
		fFCutR += m_MinCut1Array[i].fPlanR;
	}
	if (fFCutR > FLT_MIN)
		fFCutT /= fFCutR;

	//�ƻ�ͣ�˶��׼䴮��
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		if ((fSCutR+m_MinCut2Array[i].fPlanR) < FLT_MIN)
			continue;

		fSCutT = (fSCutT*fSCutR+m_MinCut2Array[i].fPlanR*m_MinCut2Array[i].fPlanT)/(fSCutR+m_MinCut2Array[i].fPlanR);
		fSCutR += m_MinCut2Array[i].fPlanR;
	}
	//�ƻ�ͣ�����׼䴮��
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		if ((fTCutR+m_MinCut3Array[i].fPlanR) < FLT_MIN)
			continue;

		fTCutT = (fTCutT*fTCutR+m_MinCut3Array[i].fPlanR*m_MinCut3Array[i].fPlanT)/(fTCutR+m_MinCut3Array[i].fPlanR);
		fTCutR += m_MinCut3Array[i].fPlanR;
	}

	//�ƻ�ͣ�����崮��
	pResult->fPlanR=fFCutR+fSCutR+fTCutR;
	pResult->fPlanU=fFCutR*fFCutT+fSCutR*fSCutT+fTCutR*fTCutT;
	if (pResult->fPlanR > FLT_MIN)
		pResult->fPlanT=pResult->fPlanU/pResult->fPlanR;
	//	���ɲ���������Ԥ����ͣ��

	//////////////////////////////////////////////////////////////////////////
	//	�ۺ�ָ�����
	fFCutR=0;
	fFCutT=0;
	fSCutR=0;
	fSCutT=0;
	fTCutR=0;
	fTCutT=0;
	//�ۺ�һ�׼䴮��
	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		if ((fFCutR+m_MinCut1Array[i].fR) < FLT_MIN)
			continue;

		fFCutT = (fFCutT*fFCutR+m_MinCut1Array[i].fR*m_MinCut1Array[i].fT)/(fFCutR+m_MinCut1Array[i].fR);
		fFCutR += m_MinCut1Array[i].fR;
	}
	//�ۺ϶��׼䴮��
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		if ((fSCutR+m_MinCut2Array[i].fR) < FLT_MIN)
			continue;

		fSCutT = (fSCutT*fSCutR+m_MinCut2Array[i].fR*m_MinCut2Array[i].fT)/(fSCutR+m_MinCut2Array[i].fR);
		fSCutR += m_MinCut2Array[i].fR;
	}
	//�ۺ����׼䴮��
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		if ((fTCutR+m_MinCut3Array[i].fR) < FLT_MIN)
			continue;

		fTCutT = (fTCutT*fTCutR+m_MinCut3Array[i].fR*m_MinCut3Array[i].fT)/(fTCutR+m_MinCut3Array[i].fR);
		fTCutR += m_MinCut3Array[i].fR;
	}

	//���崮��
	pResult->fR=fCommR + fFCutR+fSCutR+fTCutR;
	pResult->fU=fCommU + fFCutR*fFCutT+fSCutR*fSCutT+fTCutR*fTCutT;
	if (pResult->fR > FLT_MIN)
		pResult->fT=pResult->fU/pResult->fR;
}

void CMCRAlgorithm::CompContribution(const double fPower)	//	����������豸�Կɿ���ָ��Ĺ���ֵ
{
	register int	i;
	int		nFComp, nSComp, nTComp;
	double	fRatio, fTotalR, fTotalU;

	for (i=0; i<(int)m_CompArray.size(); i++)
	{
		m_CompArray[i].fAccumR=0;
		m_CompArray[i].fAccumU=0;
		m_CompArray[i].fAccumEns=0;
	}

	for (i=0; i<(int)m_CmMCut1Array.size(); i++)
	{
		nFComp=m_CmMCut1Array[i].nComp;

		m_CompArray[nFComp].fAccumR += m_CmMCut1Array[i].fR;
		m_CompArray[nFComp].fAccumU += m_CmMCut1Array[i].fR*m_CmMCut1Array[i].fT;
		m_CompArray[nFComp].fAccumEns += fPower*m_CmMCut1Array[i].fR*m_CmMCut1Array[i].fT;
	}

	for (i=0; i<(int)m_CmMCut2Array.size(); i++)
	{
		nFComp= m_CmMCut2Array[i].nComp[0];
		nSComp= m_CmMCut2Array[i].nComp[1];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nSComp].fRerr;
		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;

		if (fTotalR > FLT_MIN)
		{
			fRatio=m_CompArray[nFComp].fRerr/fTotalR;
			m_CompArray[nFComp].fAccumR += m_CmMCut2Array[i].fR*fRatio;

			fRatio=m_CompArray[nSComp].fRerr/fTotalR;
			m_CompArray[nSComp].fAccumR += m_CmMCut2Array[i].fR*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fAccumR += m_CmMCut2Array[i].fR/2;
			m_CompArray[nSComp].fAccumR += m_CmMCut2Array[i].fR/2;
		}
		if (fTotalU > FLT_MIN)
		{
			fRatio=m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep/fTotalU;

			m_CompArray[nFComp].fAccumU += m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT*fRatio;
			m_CompArray[nFComp].fAccumEns += fPower*m_CmMCut2Array[i].fR* m_CmMCut2Array[i].fT*fRatio;

			fRatio=m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep/fTotalU;
			m_CompArray[nSComp].fAccumU += m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT*fRatio;
			m_CompArray[nSComp].fAccumEns += fPower*m_CmMCut2Array[i].fR* m_CmMCut2Array[i].fT*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fAccumU += m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT/2;
			m_CompArray[nFComp].fAccumEns += fPower*m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT/2;

			m_CompArray[nSComp].fAccumU += m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT/2;
			m_CompArray[nSComp].fAccumEns += fPower*m_CmMCut2Array[i].fR*m_CmMCut2Array[i].fT/2;
		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ��㹲ģ
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		nFComp=m_MinCut1Array[i].nComp;

		m_CompArray[nFComp].fAccumR += m_MinCut1Array[i].fR;
		m_CompArray[nFComp].fAccumU += m_MinCut1Array[i].fR*m_MinCut1Array[i].fT;
		m_CompArray[nFComp].fAccumEns += fPower*m_MinCut1Array[i].fR*m_MinCut1Array[i].fT;
	}

	for (i=0;i<(int)m_MinCut2Array.size();i++)
	{
		nFComp=m_MinCut2Array[i].nComp[0];
		nSComp=m_MinCut2Array[i].nComp[1];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk;
		fTotalR += m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk;

		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
		fTotalU += m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk;
		fTotalU += m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk;;

		if (fTotalR > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk)/fTotalR;
			m_CompArray[nFComp].fAccumR += m_MinCut2Array[i].fR*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk)/fTotalR;
			m_CompArray[nSComp].fAccumR += m_MinCut2Array[i].fR*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fAccumR += m_MinCut2Array[i].fR/2;
			m_CompArray[nSComp].fAccumR += m_MinCut2Array[i].fR/2;
		}

		if (fTotalU > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk)/fTotalU;

			m_CompArray[nFComp].fAccumU += m_MinCut2Array[i].fR*m_MinCut2Array[i].fT*fRatio;
			m_CompArray[nFComp].fAccumEns += fPower*m_MinCut2Array[i].fR*m_MinCut2Array[i].fT*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep+m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk)/fTotalU;
			m_CompArray[nSComp].fAccumU += m_MinCut2Array[i].fR*m_MinCut2Array[i].fT*fRatio;
			m_CompArray[nSComp].fAccumEns += fPower*m_MinCut2Array[i].fR*m_MinCut2Array[i].fT*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fAccumU += m_MinCut2Array[i].fR*m_MinCut2Array[i].fT/2;
			m_CompArray[nFComp].fAccumEns += fPower*m_MinCut2Array[i].fR*m_MinCut2Array[i].fT/2;

			m_CompArray[nSComp].fAccumU += m_MinCut2Array[i].fR*m_MinCut2Array[i].fT/2;
			m_CompArray[nSComp].fAccumEns += fPower*m_MinCut2Array[i].fR*m_MinCut2Array[i].fT/2;
		}
	}

	for (i=0;i<(int)m_MinCut3Array.size();i++)
	{
		nFComp=m_MinCut3Array[i].nComp[0];
		nSComp=m_MinCut3Array[i].nComp[1];
		nTComp=m_MinCut3Array[i].nComp[2];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk;
		fTotalR += m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk;
		fTotalR += m_CompArray[nTComp].fRerr+m_CompArray[nTComp].fRchk;

		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk;
		fTotalU += m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep;
		fTotalU += m_CompArray[nTComp].fRchk*m_CompArray[nTComp].fTchk;
		if (fTotalR > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk)/fTotalR;
			m_CompArray[nFComp].fAccumR += m_MinCut3Array[i].fR*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk)/fTotalR;
			m_CompArray[nSComp].fAccumR += m_MinCut3Array[i].fR*fRatio;

			fRatio=(m_CompArray[nTComp].fRerr+m_CompArray[nTComp].fRchk)/fTotalR;
			m_CompArray[nTComp].fAccumR += m_MinCut3Array[i].fR*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fAccumR += m_MinCut3Array[i].fR/3;
			m_CompArray[nSComp].fAccumR += m_MinCut3Array[i].fR/3;
			m_CompArray[nTComp].fAccumR += m_MinCut3Array[i].fR/3;
		}
		if (fTotalU > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk)/fTotalU;
			m_CompArray[nFComp].fAccumU += m_MinCut3Array[i].fR*m_MinCut3Array[i].fT*fRatio;
			m_CompArray[nFComp].fAccumEns += fPower*m_MinCut3Array[i].fR*m_MinCut3Array[i].fT*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep+m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk)/fTotalU;
			m_CompArray[nSComp].fAccumU += m_MinCut3Array[i].fR*m_MinCut3Array[i].fT*fRatio;
			m_CompArray[nSComp].fAccumEns += fPower*m_MinCut3Array[i].fR*m_MinCut3Array[i].fT*fRatio;

			fRatio=(m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep+m_CompArray[nTComp].fRchk*m_CompArray[nTComp].fTchk)/fTotalU;
			m_CompArray[nTComp].fAccumU += m_MinCut3Array[i].fR*m_MinCut3Array[i].fT*fRatio;
			m_CompArray[nTComp].fAccumEns += fPower*m_MinCut3Array[i].fR*m_MinCut3Array[i].fT*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fAccumU += m_MinCut3Array[i].fR*m_MinCut3Array[i].fT/3;
			m_CompArray[nFComp].fAccumEns += fPower*m_MinCut3Array[i].fR*m_MinCut3Array[i].fT/3;

			m_CompArray[nSComp].fAccumU += m_MinCut3Array[i].fR*m_MinCut3Array[i].fT/3;
			m_CompArray[nSComp].fAccumEns += fPower*m_MinCut3Array[i].fR*m_MinCut3Array[i].fT/3;

			m_CompArray[nTComp].fAccumU += m_MinCut3Array[i].fR*m_MinCut3Array[i].fT/3;
			m_CompArray[nTComp].fAccumEns += fPower*m_MinCut3Array[i].fR*m_MinCut3Array[i].fT/3;
		}
	}
}
