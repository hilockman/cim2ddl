#include "StdAfx.h"
#include "MCRPhyData.h"

void CMCRPhyData::InitilizeMCRDevIndex(tagMCRDevIndex* pData)
{
	pData->fLOR = 0;
	pData->fLOU = 0;
	pData->fLOD = 0;
	pData->fASAI = 0;

	pData->fFaultLOR = 0;
	pData->fFaultLOU = 0;
	pData->fFaultLOD = 0;
	pData->fFaultASAI = 0;

	pData->fPlanLOR = 0;
	pData->fPlanLOU = 0;
	pData->fPlanLOD = 0;
	pData->fPlanASAI = 0;

	pData->sFault1Array.clear();
	pData->sFault2Array.clear();
	pData->sFault3Array.clear();
}

int CMCRPhyData::ComparePhyComp(tagMCRPhyComp* pCompI, tagMCRPhyComp* pCompJ)
{
	if (pCompI->nCompTyp < pCompJ->nCompTyp)
		return -1;
	else if (pCompI->nCompTyp > pCompJ->nCompTyp)
		return 1;
	else if (pCompI->nCompTyp == pCompJ->nCompTyp)
	{
		if (pCompI->nCompIdx < pCompJ->nCompIdx)
			return -1;
		else if (pCompI->nCompIdx > pCompJ->nCompIdx)
			return 1;
	}

	return 0;
}

int CMCRPhyData::CompareFault1(tagMCRPhyFault1* pFaultA, tagMCRPhyFault1* pFaultB)
{
	if (ComparePhyComp(&pFaultA->sComp, &pFaultB->sComp) < 0)
		return -1;
	else if (ComparePhyComp(&pFaultA->sComp, &pFaultB->sComp) > 0)
		return 1;
	else
	{
		if (pFaultA->fU < pFaultB->fU)
			return -1;
		else if (pFaultA->fU > pFaultB->fU)
			return 1;
		else
			return 0;
	}
}

int CMCRPhyData::CompareFault2(tagMCRPhyFault2* pFaultA, tagMCRPhyFault2* pFaultB)
{
	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) < 0)
		return -1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) > 0)
		return 1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) == 0)
	{
		if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) < 0)
			return -1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) > 0)
			return 1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) == 0)
		{
			if (pFaultA->fU < pFaultB->fU)
				return -1;
			else if (pFaultA->fU > pFaultB->fU)
				return 1;
			else
				return 0;
		}
	}

	return 0;
}

int CMCRPhyData::CompareFault3(tagMCRPhyFault3* pFaultA, tagMCRPhyFault3* pFaultB)
{
	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) < 0)
		return -1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) > 0)
		return 1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) == 0)
	{
		if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) < 0)
			return -1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) > 0)
			return 1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) == 0)
		{
			if (ComparePhyComp(&pFaultA->sComp[2], &pFaultB->sComp[2]) < 0)
				return -1;
			else if (ComparePhyComp(&pFaultA->sComp[2], &pFaultB->sComp[2]) > 0)
				return 1;
			else if (ComparePhyComp(&pFaultA->sComp[2], &pFaultB->sComp[2]) == 0)
			{
				if (pFaultA->fU < pFaultB->fU)
					return -1;
				else if (pFaultA->fU > pFaultB->fU)
					return 1;
				else
					return 0;
			}
		}
	}

	return 0;
}

int CMCRPhyData::CompareFault1Comp(tagMCRPhyFault1* pFaultA, tagMCRPhyFault1* pFaultB)
{
	return ComparePhyComp(&pFaultA->sComp, &pFaultB->sComp);
}

int CMCRPhyData::CompareFault2Comp(tagMCRPhyFault2* pFaultA, tagMCRPhyFault2* pFaultB)
{
	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) < 0)
		return -1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) > 0)
		return 1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) == 0)
	{
		if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) < 0)
			return -1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) > 0)
			return 1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) == 0)
		{
			return 0;
		}
	}

	return 0;
}

int CMCRPhyData::CompareFault3Comp(tagMCRPhyFault3* pFaultA, tagMCRPhyFault3* pFaultB)
{
	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) < 0)
		return -1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) > 0)
		return 1;
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) == 0)
	{
		if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) < 0)
			return -1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) > 0)
			return 1;
		else if (ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) == 0)
		{
			if (ComparePhyComp(&pFaultA->sComp[2], &pFaultB->sComp[2]) < 0)
				return -1;
			else if (ComparePhyComp(&pFaultA->sComp[2], &pFaultB->sComp[2]) > 0)
				return 1;
			else if (ComparePhyComp(&pFaultA->sComp[2], &pFaultB->sComp[2]) == 0)
			{
				return 0;
			}
		}
	}

	return 0;
}

void CMCRPhyData::SortFault1(std::vector<tagMCRPhyFault1>& sFaultArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	tagMCRPhyFault1	sFault;
	memcpy(&sFault, &sFaultArray[(nDn0+nUp0)/2], sizeof(tagMCRPhyFault1));

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && CompareFault1Comp(&sFaultArray[nDn], &sFault) < 0)
			++nDn;
		while (nUp > nDn0 && CompareFault1Comp(&sFaultArray[nUp], &sFault) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(sFaultArray[nDn], sFaultArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortFault1(sFaultArray, nDn0, nUp);

	if (nDn < nUp0 )
		SortFault1(sFaultArray, nDn, nUp0);
}

void CMCRPhyData::SortFault2(std::vector<tagMCRPhyFault2>& sFaultArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	tagMCRPhyFault2	sFault;
	memcpy(&sFault, &sFaultArray[(nDn0+nUp0)/2], sizeof(tagMCRPhyFault2));

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && CompareFault2Comp(&sFaultArray[nDn], &sFault) < 0)
			++nDn;
		while (nUp > nDn0 && CompareFault2Comp(&sFaultArray[nUp], &sFault) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(sFaultArray[nDn], sFaultArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortFault2(sFaultArray, nDn0, nUp);

	if (nDn < nUp0 )
		SortFault2(sFaultArray, nDn, nUp0);
}

void CMCRPhyData::SortFault3(std::vector<tagMCRPhyFault3>& sFaultArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	tagMCRPhyFault3	sFault;
	memcpy(&sFault, &sFaultArray[(nDn0+nUp0)/2], sizeof(tagMCRPhyFault3));

	while (nDn <= nUp)
	{
		while (nDn < nUp0 && CompareFault3Comp(&sFaultArray[nDn], &sFault) < 0)
			++nDn;
		while (nUp > nDn0 && CompareFault3Comp(&sFaultArray[nUp], &sFault) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(sFaultArray[nDn], sFaultArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortFault3(sFaultArray, nDn0, nUp);

	if (nDn < nUp0 )
		SortFault3(sFaultArray, nDn, nUp0);
}

void CMCRPhyData::MergeFault1(std::vector<tagMCRPhyFault1>& sFaultArray)
{
	register int	i;
	int		nFault;

	SortFault1(sFaultArray, 0, (int)sFaultArray.size()-1);

	tagMCRPhyFault1					sFaultBuf;
	std::vector<tagMCRPhyFault1>	sBufferArray;
	sBufferArray.clear();

	nFault=0;
	while (nFault < (int)sFaultArray.size())
	{
		memcpy(&sFaultBuf, &sFaultArray[nFault], sizeof(tagMCRPhyFault1));

		i=nFault+1;
		while (i < (int)sFaultArray.size())
		{
			if (CompareFault1Comp(&sFaultBuf, &sFaultArray[i]) == 0)
			{
				if (sFaultBuf.fU < sFaultArray[i].fU)
					memcpy(&sFaultBuf, &sFaultArray[i], sizeof(tagMCRPhyFault1));

				nFault++;
				i++;
			}
			else
			{
				break;
			}
		}
		nFault++;

		sBufferArray.push_back(sFaultBuf);
	}

	sFaultArray.clear();
	sFaultArray.assign(sBufferArray.begin(), sBufferArray.end());
	sBufferArray.clear();
}

void CMCRPhyData::MergeFault2(std::vector<tagMCRPhyFault2>& sFaultArray)
{
	register int	i;
	int		nFault;

	SortFault2(sFaultArray, 0, (int)sFaultArray.size()-1);

	tagMCRPhyFault2	sFaultBuf;
	std::vector<tagMCRPhyFault2>	sBufferArray;
	sBufferArray.clear();

	nFault=0;
	while (nFault < (int)sFaultArray.size())
	{
		memcpy(&sFaultBuf, &sFaultArray[nFault], sizeof(tagMCRPhyFault2));

		i=nFault+1;
		while (i < (int)sFaultArray.size())
		{
			if (CompareFault2Comp(&sFaultBuf, &sFaultArray[i]) == 0)
			{
				if (sFaultBuf.fU < sFaultArray[i].fU)
					memcpy(&sFaultBuf, &sFaultArray[nFault], sizeof(tagMCRPhyFault2));

				nFault++;
				i++;
			}
			else
			{
				break;
			}
		}
		nFault++;

		sBufferArray.push_back(sFaultBuf);
	}

	sFaultArray.clear();
	sFaultArray.assign(sBufferArray.begin(), sBufferArray.end());
	sBufferArray.clear();
}

void CMCRPhyData::MergeFault3(std::vector<tagMCRPhyFault3>& sFaultArray)
{
	register int	i;
	int		nFault;

	SortFault3(sFaultArray, 0, (int)sFaultArray.size()-1);

	tagMCRPhyFault3	sFaultBuf;
	std::vector<tagMCRPhyFault3>	sBufferArray;
	sBufferArray.clear();

	nFault=0;
	while (nFault < (int)sFaultArray.size())
	{
		memcpy(&sFaultBuf, &sFaultArray[nFault], sizeof(tagMCRPhyFault3));

		i=nFault+1;
		while (i < (int)sFaultArray.size())
		{
			if (CompareFault3Comp(&sFaultBuf, &sFaultArray[i]) == 0)
			{
				if (sFaultBuf.fU < sFaultArray[i].fU)
					memcpy(&sFaultBuf, &sFaultArray[nFault], sizeof(tagMCRPhyFault3));

				nFault++;
				i++;
			}
			else
			{
				break;
			}
		}
		nFault++;

		sBufferArray.push_back(sFaultBuf);
	}

	sFaultArray.clear();
	sFaultArray.assign(sBufferArray.begin(), sBufferArray.end());
	sBufferArray.clear();
}

void CMCRPhyData::RegularFault2(tagMCRPhyFault2* pFault)
{
	tagMCRPhyComp	sCompBuf;
	if (ComparePhyComp(&pFault->sComp[0], &pFault->sComp[1]) > 0)
	{
		memcpy(&sCompBuf, &pFault->sComp[0], sizeof(tagMCRPhyComp));
		memcpy(&pFault->sComp[0], &pFault->sComp[1], sizeof(tagMCRPhyComp));
		memcpy(&pFault->sComp[1], &sCompBuf, sizeof(tagMCRPhyComp));

		memcpy(&sCompBuf, &pFault->sSwitchComp[0], sizeof(tagMCRPhyComp));
		memcpy(&pFault->sSwitchComp[0], &pFault->sSwitchComp[1], sizeof(tagMCRPhyComp));
		memcpy(&pFault->sSwitchComp[1], &sCompBuf, sizeof(tagMCRPhyComp));
	}
}

void CMCRPhyData::RegularFault3(tagMCRPhyFault3* pFault)
{
	register int	i, j;
	tagMCRPhyComp	sCompBuf;

	for (i=0; i<3; i++)
	{
		for (j=i+1; j<3; j++)
		{
			if (ComparePhyComp(&pFault->sComp[i], &pFault->sComp[j]) > 0)
			{
				memcpy(&sCompBuf, &pFault->sComp[i], sizeof(tagMCRPhyComp));
				memcpy(&pFault->sComp[i], &pFault->sComp[j], sizeof(tagMCRPhyComp));
				memcpy(&pFault->sComp[j], &sCompBuf, sizeof(tagMCRPhyComp));

				memcpy(&sCompBuf, &pFault->sSwitchComp[i], sizeof(tagMCRPhyComp));
				memcpy(&pFault->sSwitchComp[i], &pFault->sSwitchComp[j], sizeof(tagMCRPhyComp));
				memcpy(&pFault->sSwitchComp[j], &sCompBuf, sizeof(tagMCRPhyComp));
			}
		}
	}
}

int CMCRPhyData::SeekFault1InFault1(std::vector<tagMCRPhyFault1>& sFaultArray, tagMCRPhyFault1& sFault)
{
	register int	i;
	for (i=0; i<(int)sFaultArray.size(); i++)
	{
		if (ComparePhyComp(&sFaultArray[i].sComp, &sFault.sComp) == 0)
			return i;
	}
	return -1;
}

int CMCRPhyData::SeekFault2InFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault2& sFault)
{
	register int	i;
	for (i=0; i<(int)sFaultArray.size(); i++)
	{
		if (ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[1]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[0]) == 0)
			return i;
	}
	return -1;
}

int CMCRPhyData::SeekFault3InFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault3& sFault)
{
	register int	i;
	for (i=0; i<(int)sFaultArray.size(); i++)
	{
		if (ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[2]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[2]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[2]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[2]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[2]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[2]) == 0)
			return i;
	}
	return -1;
}

int CMCRPhyData::SeekFault1InFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault1& sFault)
{
	register int	i;
	for (i=0; i<(int)sFaultArray.size(); i++)
	{
		if (ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp) == 0 || ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp) == 0)
			return i;
	}
	return -1;
}

int CMCRPhyData::SeekFault1InFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault1& sFault)
{
	register int	i;
	for (i=0; i<(int)sFaultArray.size(); i++)
	{
		if (ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp) == 0 || ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp) == 0 || ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp) == 0)
			return i;
	}
	return -1;
}

int CMCRPhyData::SeekFault2InFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault2& sFault)
{
	register int	i;
	for (i=0; i<(int)sFaultArray.size(); i++)
	{
		if (ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[1]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[0]) == 0 ||

			ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[1]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[0], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[0]) == 0 ||

			ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[0]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[1]) == 0 ||
			ComparePhyComp(&sFaultArray[i].sComp[1], &sFault.sComp[1]) == 0 && ComparePhyComp(&sFaultArray[i].sComp[2], &sFault.sComp[0]) == 0)
			return i;
	}
	return -1;
}

void CMCRPhyData::AddFault1(std::vector<tagMCRPhyFault1>& sFaultArray, tagMCRPhyFault1& sFault)
{
	sFaultArray.push_back(sFault);
}

void CMCRPhyData::AddFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault2& sFault)
{
	RegularFault2(&sFault);
	sFaultArray.push_back(sFault);
}

void CMCRPhyData::AddFault2(std::vector<tagMCRPhyFault2>& sFaultArray, tagMCRPhyFault1& sFaultA, tagMCRPhyFault1& sFaultB)
{
	tagMCRPhyFault2	sFBuf;
	memset(&sFBuf, 0, sizeof(tagMCRPhyFault2));
	sFBuf.nFType = MCREnumCutType_Combine;

	double	fFR1=sFaultA.fR;
	double	fFR2=sFaultB.fR;
	double	fFT1=sFaultA.fT;
	double	fFT2=sFaultB.fT;

	memcpy(&sFBuf.sComp[0], &sFaultA.sComp, sizeof(tagMCRPhyComp));
	memcpy(&sFBuf.sComp[1], &sFaultB.sComp, sizeof(tagMCRPhyComp));

	memcpy(&sFBuf.sSwitchComp[0], &sFaultA.sSwitchComp, sizeof(tagMCRPhyComp));
	memcpy(&sFBuf.sSwitchComp[1], &sFaultB.sSwitchComp, sizeof(tagMCRPhyComp));

	sFBuf.fR=fFR1*fFR2*(fFT1+fFT2)/8760;
	if (8760*sFBuf.fR > FLT_MIN)
		sFBuf.fT=(fFR1*fFT1*fFR2*fFT2)/(sFBuf.fR*8760);
	sFBuf.fU=sFBuf.fR*sFBuf.fT;

	AddFault2(sFaultArray, sFBuf);
}

void CMCRPhyData::AddFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault3& sFault)
{
	RegularFault3(&sFault);
	sFaultArray.push_back(sFault);
}

void CMCRPhyData::AddFault3(std::vector<tagMCRPhyFault3>& sFaultArray, tagMCRPhyFault1& sFaultA, tagMCRPhyFault2& sFaultB)
{
	tagMCRPhyFault3	sFBuf;
	memset(&sFBuf, 0, sizeof(tagMCRPhyFault3));
	sFBuf.nFType = MCREnumCutType_Combine;

	memcpy(&sFBuf.sComp[0], &sFaultA.sComp, sizeof(tagMCRPhyComp));
	memcpy(&sFBuf.sSwitchComp[0], &sFaultA.sSwitchComp, sizeof(tagMCRPhyComp));

	memcpy(&sFBuf.sComp[1], &sFaultB.sComp[0], sizeof(tagMCRPhyComp));
	memcpy(&sFBuf.sSwitchComp[1], &sFaultB.sSwitchComp[0], sizeof(tagMCRPhyComp));

	memcpy(&sFBuf.sComp[2], &sFaultB.sComp[1], sizeof(tagMCRPhyComp));
	memcpy(&sFBuf.sSwitchComp[2], &sFaultB.sSwitchComp[1], sizeof(tagMCRPhyComp));

	double	fFR1, fFR2, fFR3, fFT1, fFT2, fFT3;
	fFR1 = fFR2 = fFR3 = fFT1 = fFT2 = fFT3 = 0;
	fFR1=sFaultA.sComp.fRerr;
	fFT1=sFaultA.sComp.fTrep;
	fFR2=sFaultB.sComp[0].fRerr;
	fFT2=sFaultB.sComp[0].fTrep;
	fFR3=sFaultB.sComp[1].fRerr;
	fFT3=sFaultB.sComp[1].fTrep;

	sFBuf.fR=fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)/(8760*8760);
	if (8760*8760*sFBuf.fR > FLT_MIN)
	{
		if ((fFT1*fFT2+fFT1*fFT3+fFT2*fFT3) > FLT_MIN)	sFBuf.fT = fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)*(fFT1*fFT2*fFT3)/(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3);
		sFBuf.fT /= (8760*8760*sFBuf.fR);
	}
	sFBuf.fU = sFBuf.fR*sFBuf.fT;

	sFBuf.fFaultR=sFBuf.fR;
	sFBuf.fFaultT=sFBuf.fT;
	sFBuf.fFaultU=sFBuf.fU;

	AddFault3(sFaultArray, sFBuf);
}

void CMCRPhyData::CombineFault3(std::vector<tagMCRPhyFault3>& sFault3Array, tagMCRPhyFault2* pFaultA, tagMCRPhyFault2* pFaultB)
{
	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) == 0 && ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) == 0 ||
		ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[1]) == 0 && ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[0]) == 0)
		return;

	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) != 0 && ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) != 0 &&
		ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[1]) != 0 && ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[0]) != 0)
		return;

	tagMCRPhyFault3	sF3Buf;
	memset(&sF3Buf, 0, sizeof(tagMCRPhyFault3));
	sF3Buf.nFType = MCREnumCutType_Combine;

	double	fFR1, fFR2, fFR3, fFT1, fFT2, fFT3;
	fFR1 = fFR2 = fFR3 = fFT1 = fFT2 = fFT3 = 0;
	fFR1=pFaultA->sComp[0].fRerr;
	fFT1=pFaultA->sComp[0].fTrep;
	fFR2=pFaultA->sComp[1].fRerr;
	fFT2=pFaultA->sComp[1].fTrep;

	memcpy(&sF3Buf.sComp[0], &pFaultA->sComp, sizeof(tagMCRPhyComp));
	memcpy(&sF3Buf.sSwitchComp[0], &pFaultA->sSwitchComp, sizeof(tagMCRPhyComp));

	memcpy(&sF3Buf.sComp[1], &pFaultB->sComp[0], sizeof(tagMCRPhyComp));
	memcpy(&sF3Buf.sSwitchComp[1], &pFaultB->sSwitchComp[0], sizeof(tagMCRPhyComp));

	if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[0]) == 0 || ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[0]) == 0)
	{
		fFR3=pFaultB->sComp[1].fRerr;
		fFT3=pFaultB->sComp[1].fTrep;

		memcpy(&sF3Buf.sComp[2], &pFaultB->sComp[1], sizeof(tagMCRPhyComp));
		memcpy(&sF3Buf.sSwitchComp[2], &pFaultB->sSwitchComp[1], sizeof(tagMCRPhyComp));
	}
	else if (ComparePhyComp(&pFaultA->sComp[0], &pFaultB->sComp[1]) == 0 || ComparePhyComp(&pFaultA->sComp[1], &pFaultB->sComp[1]) == 0)
	{
		fFR3=pFaultB->sComp[0].fRerr;
		fFT3=pFaultB->sComp[0].fTrep;

		memcpy(&sF3Buf.sComp[2], &pFaultB->sComp[0], sizeof(tagMCRPhyComp));
		memcpy(&sF3Buf.sSwitchComp[2], &pFaultB->sSwitchComp[0], sizeof(tagMCRPhyComp));
	}
	else
		return;

	sF3Buf.fR=fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)/(8760*8760);
	if (8760*8760*sF3Buf.fR > FLT_MIN)
	{
		if ((fFT1*fFT2+fFT1*fFT3+fFT2*fFT3) > FLT_MIN)	sF3Buf.fT = fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)*(fFT1*fFT2*fFT3)/(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3);
		sF3Buf.fT /= (8760*8760*sF3Buf.fR);
	}
	sF3Buf.fU = sF3Buf.fR*sF3Buf.fT;

	sF3Buf.fFaultR=sF3Buf.fR;
	sF3Buf.fFaultT=sF3Buf.fT;
	sF3Buf.fFaultU=sF3Buf.fU;

	AddFault3(sFault3Array, sF3Buf);
}

void CMCRPhyData::SeriesFault(std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array, tagMCRDevIndex& sIndex)
{
	register int	i;
	double	fFault1R, fFault2R, fFault3R;
	double	fFault1T, fFault2T, fFault3T;

	fFault1R=0;
	fFault1T=0;
	fFault2R=0;
	fFault2T=0;
	fFault3R=0;
	fFault3T=0;

	//һ�׼䴮��
	for (i=0; i<(int)sFault1Array.size(); i++)
	{
		if ((fFault1R+sFault1Array[i].fFaultR) < FLT_MIN)
			continue;

		fFault1T = (fFault1T*fFault1R+sFault1Array[i].fFaultR*sFault1Array[i].fFaultT)/(fFault1R+sFault1Array[i].fFaultR);
		fFault1R += sFault1Array[i].fFaultR;
	}
	//���׼䴮��
	for (i=0; i<(int)sFault2Array.size(); i++)
	{
		if ((fFault2R+sFault2Array[i].fFaultR) < FLT_MIN)
			continue;

		fFault2T = (fFault2T*fFault2R+sFault2Array[i].fFaultR*sFault2Array[i].fFaultT)/(fFault2R+sFault2Array[i].fFaultR);
		fFault2R += sFault2Array[i].fFaultR;
	}
	//���׼䴮��
	for (i=0; i<(int)sFault3Array.size(); i++)
	{
		if ((fFault3R+sFault3Array[i].fFaultR) < FLT_MIN)
			continue;

		fFault3T = (fFault3T*fFault3R+sFault3Array[i].fFaultR*sFault3Array[i].fFaultT)/(fFault3R+sFault3Array[i].fFaultR);
		fFault3R += sFault3Array[i].fFaultR;
	}

	//���崮��
	sIndex.fFaultLOR=fFault1R+fFault2R+fFault3R;
	sIndex.fFaultLOU=fFault1R*fFault1T+fFault2R*fFault2T+fFault3R*fFault3T;
	if (sIndex.fFaultLOR > FLT_MIN)
		sIndex.fFaultLOD=sIndex.fFaultLOU/sIndex.fFaultLOR;

	fFault1R=0;
	fFault1T=0;
	fFault2R=0;
	fFault2T=0;
	fFault3R=0;
	fFault3T=0;

	//һ�׼䴮��
	for (i=0; i<(int)sFault1Array.size(); i++)
	{
		if ((fFault1R+sFault1Array[i].fPlanR) < FLT_MIN)
			continue;

		fFault1T = (fFault1T*fFault1R+sFault1Array[i].fPlanR*sFault1Array[i].fPlanT)/(fFault1R+sFault1Array[i].fPlanR);
		fFault1R += sFault1Array[i].fPlanR;
	}
	//���׼䴮��
	for (i=0; i<(int)sFault2Array.size(); i++)
	{
		if ((fFault2R+sFault2Array[i].fPlanR) < FLT_MIN)
			continue;

		fFault2T = (fFault2T*fFault2R+sFault2Array[i].fPlanR*sFault2Array[i].fPlanT)/(fFault2R+sFault2Array[i].fPlanR);
		fFault2R += sFault2Array[i].fPlanR;
	}
	//���׼䴮��
	for (i=0; i<(int)sFault3Array.size(); i++)
	{
		if ((fFault3R+sFault3Array[i].fPlanR) < FLT_MIN)
			continue;

		fFault3T = (fFault3T*fFault3R+sFault3Array[i].fPlanR*sFault3Array[i].fPlanT)/(fFault3R+sFault3Array[i].fPlanR);
		fFault3R += sFault3Array[i].fPlanR;
	}

	//���崮��
	sIndex.fPlanLOR=fFault1R+fFault2R+fFault3R;
	sIndex.fPlanLOU=fFault1R*fFault1T+fFault2R*fFault2T+fFault3R*fFault3T;
	if (sIndex.fPlanLOR > FLT_MIN)
		sIndex.fPlanLOD=sIndex.fPlanLOU/sIndex.fPlanLOR;

	fFault1R=0;
	fFault1T=0;
	fFault2R=0;
	fFault2T=0;
	fFault3R=0;
	fFault3T=0;

	//һ�׼䴮��
	for (i=0; i<(int)sFault1Array.size(); i++)
	{
		if ((fFault1R+sFault1Array[i].fR) < FLT_MIN)
			continue;

		fFault1T = (fFault1T*fFault1R+sFault1Array[i].fR*sFault1Array[i].fT)/(fFault1R+sFault1Array[i].fR);
		fFault1R += sFault1Array[i].fR;
	}
	//���׼䴮��
	for (i=0; i<(int)sFault2Array.size(); i++)
	{
		if ((fFault2R+sFault2Array[i].fR) < FLT_MIN)
			continue;

		fFault2T = (fFault2T*fFault2R+sFault2Array[i].fR*sFault2Array[i].fT)/(fFault2R+sFault2Array[i].fR);
		fFault2R += sFault2Array[i].fR;
	}
	//���׼䴮��
	for (i=0; i<(int)sFault3Array.size(); i++)
	{
		if ((fFault3R+sFault3Array[i].fR) < FLT_MIN)
			continue;

		fFault3T = (fFault3T*fFault3R+sFault3Array[i].fR*sFault3Array[i].fT)/(fFault3R+sFault3Array[i].fR);
		fFault3R += sFault3Array[i].fR;
	}

	//���崮��
	sIndex.fLOR=fFault1R+fFault2R+fFault3R;
	sIndex.fLOU=fFault1R*fFault1T+fFault2R*fFault2T+fFault3R*fFault3T;
	if (sIndex.fLOR > FLT_MIN)
		sIndex.fLOD=sIndex.fLOU/sIndex.fLOR;

	sIndex.fASAI = 1 - sIndex.fLOU/8760;
	sIndex.fFaultASAI = 1 - sIndex.fFaultLOU/8760;
	sIndex.fPlanASAI = 1 - sIndex.fPlanLOU/8760;
}

void CMCRPhyData::Contribution(const double fR, const double fU, std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array)
{
	int	nFault;
	//////////////////////////////////////////////////////////////////////////
	//	�����������ģʽ���豸�ɿ���ָ��Ĺ��׶�
	for (nFault=0; nFault<(int)sFault1Array.size(); nFault++)
	{
		sFault1Array[nFault].fRContribution=sFault1Array[nFault].fUContribution=0;

		if (fR > FLT_MIN)	sFault1Array[nFault].fRContribution	= 100*sFault1Array[nFault].fR/fR;
		if (fU > FLT_MIN)	sFault1Array[nFault].fUContribution	= 100*sFault1Array[nFault].fU/fU;
	}

	for (nFault=0;nFault<(int)sFault2Array.size();nFault++)
	{
		sFault2Array[nFault].fRContribution=sFault2Array[nFault].fUContribution=0;

		if (fR > FLT_MIN)	sFault2Array[nFault].fRContribution	= 100*sFault2Array[nFault].fR/fR;
		if (fU > FLT_MIN)	sFault2Array[nFault].fUContribution	= 100*sFault2Array[nFault].fU/fU;
	}
	for (nFault=0;nFault<(int)sFault3Array.size();nFault++)
	{
		sFault3Array[nFault].fRContribution=sFault3Array[nFault].fUContribution=0;

		if (fR > FLT_MIN)	sFault3Array[nFault].fRContribution	= 100*sFault3Array[nFault].fR/fR;
		if (fU > FLT_MIN)	sFault3Array[nFault].fUContribution	= 100*sFault3Array[nFault].fU/fU;
	}
}

void CMCRPhyData::MCRSysIndex()
{
	int		nDev, nPerturb;

	memset(&m_System, 0, sizeof(tagMCRPhySystem));
	//////////////////////////////////////////////////////////////////////////
	//	ϵͳ��
	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Load)
			continue;

		m_System.fAifi += m_LineArray[nDev].sResult.fR;
		m_System.fAidi += m_LineArray[nDev].sResult.fU;
		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
			m_System.fEns += m_LineArray[nDev].fPower*m_LineArray[nDev].sResult.fU;

		m_System.fFaultAifi += m_LineArray[nDev].sResult.fFaultR;
		m_System.fFaultAidi += m_LineArray[nDev].sResult.fFaultU;
		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
			m_System.fFaultEns += m_LineArray[nDev].fPower*m_LineArray[nDev].sResult.fFaultU;

		m_System.fPlanAifi += m_LineArray[nDev].sResult.fPlanR;
		m_System.fPlanAidi += m_LineArray[nDev].sResult.fPlanU;
		if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
			m_System.fPlanEns += m_LineArray[nDev].fPower*m_LineArray[nDev].sResult.fPlanU;
	}
	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Load)
			continue;

		m_System.fAifi += m_TranArray[nDev].sResult.fR;
		m_System.fAidi += m_TranArray[nDev].sResult.fU;
		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
			m_System.fEns += m_TranArray[nDev].fPower*m_TranArray[nDev].sResult.fU;

		m_System.fFaultAifi += m_TranArray[nDev].sResult.fFaultR;
		m_System.fFaultAidi += m_TranArray[nDev].sResult.fFaultU;
		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
			m_System.fFaultEns += m_TranArray[nDev].fPower*m_TranArray[nDev].sResult.fFaultU;

		m_System.fPlanAifi += m_TranArray[nDev].sResult.fPlanR;
		m_System.fPlanAidi += m_TranArray[nDev].sResult.fPlanU;
		if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
			m_System.fPlanEns += m_TranArray[nDev].fPower*m_TranArray[nDev].sResult.fPlanU;
	}

	m_System.fAsai = (1.0-m_System.fAidi/8760);
	m_System.fFaultAsai = (1.0-m_System.fFaultAidi/8760.0);
	m_System.fPlanAsai = (1.0-m_System.fPlanAidi/8760.0);

	for (nPerturb=0; nPerturb<2*g_nConstMaxReliabilityPerturb+1; nPerturb++)
	{
		memset(&m_SystemPerturb[nPerturb], 0, sizeof(tagMCRPhySystem));
		m_SystemPerturb[nPerturb].nPerturb = nPerturb;
		for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
		{
			if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Load)
				continue;

			m_SystemPerturb[nPerturb].fAifi += m_LineArray[nDev].sPerturbResult[nPerturb].fR;
			m_SystemPerturb[nPerturb].fAidi += m_LineArray[nDev].sPerturbResult[nPerturb].fU;
			if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_SystemPerturb[nPerturb].fEns += m_LineArray[nDev].fPower*m_LineArray[nDev].sPerturbResult[nPerturb].fU;

			m_SystemPerturb[nPerturb].fFaultAifi += m_LineArray[nDev].sPerturbResult[nPerturb].fFaultR;
			m_SystemPerturb[nPerturb].fFaultAidi += m_LineArray[nDev].sPerturbResult[nPerturb].fFaultU;
			if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_SystemPerturb[nPerturb].fFaultEns += m_LineArray[nDev].fPower*m_LineArray[nDev].sPerturbResult[nPerturb].fFaultU;

			m_SystemPerturb[nPerturb].fPlanAifi += m_LineArray[nDev].sPerturbResult[nPerturb].fPlanR;
			m_SystemPerturb[nPerturb].fPlanAidi += m_LineArray[nDev].sPerturbResult[nPerturb].fPlanU;
			if (m_LineArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_SystemPerturb[nPerturb].fPlanEns += m_LineArray[nDev].fPower*m_LineArray[nDev].sPerturbResult[nPerturb].fPlanU;
		}
		for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
		{
			if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Load)
				continue;

			m_SystemPerturb[nPerturb].fAifi += m_TranArray[nDev].sPerturbResult[nPerturb].fR;
			m_SystemPerturb[nPerturb].fAidi += m_TranArray[nDev].sPerturbResult[nPerturb].fU;
			if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_SystemPerturb[nPerturb].fEns += m_TranArray[nDev].fPower*m_TranArray[nDev].sPerturbResult[nPerturb].fU;

			m_SystemPerturb[nPerturb].fFaultAifi += m_TranArray[nDev].sPerturbResult[nPerturb].fFaultR;
			m_SystemPerturb[nPerturb].fFaultAidi += m_TranArray[nDev].sPerturbResult[nPerturb].fFaultU;
			if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_SystemPerturb[nPerturb].fFaultEns += m_TranArray[nDev].fPower*m_TranArray[nDev].sPerturbResult[nPerturb].fFaultU;

			m_SystemPerturb[nPerturb].fPlanAifi += m_TranArray[nDev].sPerturbResult[nPerturb].fPlanR;
			m_SystemPerturb[nPerturb].fPlanAidi += m_TranArray[nDev].sPerturbResult[nPerturb].fPlanU;
			if (m_TranArray[nDev].nType == PGEnumLineTran_MCType_Load)
				m_SystemPerturb[nPerturb].fPlanEns += m_TranArray[nDev].fPower*m_TranArray[nDev].sPerturbResult[nPerturb].fPlanU;
		}

		m_SystemPerturb[nPerturb].fAsai = (1.0-m_SystemPerturb[nPerturb].fAidi/8760);
		m_SystemPerturb[nPerturb].fFaultAsai = (1.0-m_SystemPerturb[nPerturb].fFaultAidi/8760.0);
		m_SystemPerturb[nPerturb].fPlanAsai = (1.0-m_SystemPerturb[nPerturb].fPlanAidi/8760.0);
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ϵͳ��ָ�깱�׶�
	for	(nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Load)
			continue;
		if (m_System.fAifi > FLT_MIN)	m_LineArray[nDev].ro_RContribution	=(100.0*m_LineArray[nDev].sResult.fR							/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_LineArray[nDev].ro_UContribution	=(100.0*m_LineArray[nDev].sResult.fU							/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_LineArray[nDev].ro_ENSContribution=(100.0*m_LineArray[nDev].sResult.fU*m_LineArray[nDev].fPower	/m_System.fEns);
	}
	for	(nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Load)
			continue;
		if (m_System.fAifi > FLT_MIN)	m_TranArray[nDev].ro_RContribution	=(100.0*m_TranArray[nDev].sResult.fR							/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_TranArray[nDev].ro_UContribution	=(100.0*m_TranArray[nDev].sResult.fU							/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_TranArray[nDev].ro_ENSContribution=(100.0*m_TranArray[nDev].sResult.fU*m_TranArray[nDev].fPower	/m_System.fEns);
	}

	for (nDev=0; nDev<(int)m_BusArray.size(); nDev++)
	{
		if (m_System.fAifi > FLT_MIN)	m_BusArray[nDev].ro_RContribution	= 	(100.0*m_BusArray[nDev].ro_RContribution	/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_BusArray[nDev].ro_UContribution	= 	(100.0*m_BusArray[nDev].ro_UContribution	/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_BusArray[nDev].ro_ENSContribution	=	(100.0*m_BusArray[nDev].ro_ENSContribution	/m_System.fEns);
	}
	for (nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Edge)
			continue;
		if (m_System.fAifi > FLT_MIN)	m_LineArray[nDev].ro_RContribution		= (100.0*m_LineArray[nDev].ro_RContribution		/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_LineArray[nDev].ro_UContribution		= (100.0*m_LineArray[nDev].ro_UContribution		/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_LineArray[nDev].ro_ENSContribution	= (100.0*m_LineArray[nDev].ro_ENSContribution	/m_System.fEns);
	}
	for (nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Edge)
			continue;
		if (m_System.fAifi > FLT_MIN)	m_TranArray[nDev].ro_RContribution	= 	(100.0*m_TranArray[nDev].ro_RContribution	/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_TranArray[nDev].ro_UContribution	= 	(100.0*m_TranArray[nDev].ro_UContribution	/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_TranArray[nDev].ro_ENSContribution=	(100.0*m_TranArray[nDev].ro_ENSContribution	/m_System.fEns);
	}
	for (nDev=0; nDev<(int)m_ScapArray.size(); nDev++)
	{
		if (m_System.fAifi > FLT_MIN)	m_ScapArray[nDev].ro_RContribution	= 	(100.0*m_ScapArray[nDev].ro_RContribution	/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_ScapArray[nDev].ro_UContribution	= 	(100.0*m_ScapArray[nDev].ro_UContribution	/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_ScapArray[nDev].ro_ENSContribution=	(100.0*m_ScapArray[nDev].ro_ENSContribution	/m_System.fEns);
	}
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (m_System.fAifi > FLT_MIN)	m_BreakerArray[nDev].ro_RContribution	= 	(100.0*m_BreakerArray[nDev].ro_RContribution	/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_BreakerArray[nDev].ro_UContribution	= 	(100.0*m_BreakerArray[nDev].ro_UContribution	/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_BreakerArray[nDev].ro_ENSContribution	=	(100.0*m_BreakerArray[nDev].ro_ENSContribution	/m_System.fEns);
	}
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (m_System.fAifi > FLT_MIN)	m_DisconnectorArray[nDev].ro_RContribution	= 	(100.0*m_DisconnectorArray[nDev].ro_RContribution	/m_System.fAifi);
		if (m_System.fAidi > FLT_MIN)	m_DisconnectorArray[nDev].ro_UContribution	= 	(100.0*m_DisconnectorArray[nDev].ro_UContribution	/m_System.fAidi);
		if (m_System.fEns > FLT_MIN)	m_DisconnectorArray[nDev].ro_ENSContribution=	(100.0*m_DisconnectorArray[nDev].ro_ENSContribution	/m_System.fEns);
	}
}

void CMCRPhyData::MCRDevIndex()
{
	int		nDev, nDev1, nDev2, nFault, nDev1F, nDev2F;

	//////////////////////////////////////////////////////////////////////////
	//	����
	m_L1Index.sFault1Array.clear();
	m_L1Index.sFault2Array.clear();
	m_L1Index.sFault3Array.clear();
	for	(nDev=0; nDev<(int)m_LineArray.size(); nDev++)
	{
		if (m_LineArray[nDev].nType != PGEnumLineTran_MCType_Load && m_LineArray[nDev].nType != PGEnumLineTran_MCType_Gen)
			continue;

		for (nFault=0; nFault<(int)m_LineArray[nDev].sFault1Array.size(); nFault++)
			AddFault1(m_L1Index.sFault1Array, m_LineArray[nDev].sFault1Array[nFault]);
		for (nFault=0; nFault<(int)m_LineArray[nDev].sFault2Array.size(); nFault++)
			AddFault2(m_L1Index.sFault2Array, m_LineArray[nDev].sFault2Array[nFault]);
		for (nFault=0; nFault<(int)m_LineArray[nDev].sFault3Array.size(); nFault++)
			AddFault3(m_L1Index.sFault3Array, m_LineArray[nDev].sFault3Array[nFault]);
	}
	MergeFault1(m_L1Index.sFault1Array);
	MergeFault2(m_L1Index.sFault2Array);
	MergeFault3(m_L1Index.sFault3Array);
	SeriesFault(m_L1Index.sFault1Array, m_L1Index.sFault2Array, m_L1Index.sFault3Array, m_L1Index);
	Contribution(m_L1Index.fLOR, m_L1Index.fLOU, m_L1Index.sFault1Array, m_L1Index.sFault2Array, m_L1Index.sFault3Array);

	//////////////////////////////////////////////////////////////////////////
	//	����
	m_T1Index.sFault1Array.clear();
	m_T1Index.sFault2Array.clear();
	m_T1Index.sFault3Array.clear();
	for	(nDev=0; nDev<(int)m_TranArray.size(); nDev++)
	{
		if (m_TranArray[nDev].nType != PGEnumLineTran_MCType_Load && m_TranArray[nDev].nType != PGEnumLineTran_MCType_Gen)
			continue;

		for (nFault=0; nFault<(int)m_TranArray[nDev].sFault1Array.size(); nFault++)
			AddFault1(m_T1Index.sFault1Array, m_TranArray[nDev].sFault1Array[nFault]);
		for (nFault=0; nFault<(int)m_TranArray[nDev].sFault2Array.size(); nFault++)
			AddFault2(m_T1Index.sFault2Array, m_TranArray[nDev].sFault2Array[nFault]);
		for (nFault=0; nFault<(int)m_TranArray[nDev].sFault3Array.size(); nFault++)
			AddFault3(m_T1Index.sFault3Array, m_TranArray[nDev].sFault3Array[nFault]);
	}
	MergeFault1(m_T1Index.sFault1Array);
	MergeFault2(m_T1Index.sFault2Array);
	MergeFault3(m_T1Index.sFault3Array);
	SeriesFault(m_T1Index.sFault1Array, m_T1Index.sFault2Array, m_T1Index.sFault3Array, m_T1Index);
	Contribution(m_T1Index.fLOR, m_T1Index.fLOU, m_T1Index.sFault1Array, m_T1Index.sFault2Array, m_T1Index.sFault3Array);

	//////////////////////////////////////////////////////////////////////////
	//	����
	m_L2Index.sFault1Array.clear();
	m_L2Index.sFault2Array.clear();
	m_L2Index.sFault3Array.clear();
	for	(nDev1=0; nDev1<(int)m_LineArray.size(); nDev1++)
	{
		if (m_LineArray[nDev1].nType != PGEnumLineTran_MCType_Load && m_LineArray[nDev1].nType != PGEnumLineTran_MCType_Gen)
			continue;

		for	(nDev2=nDev1+1; nDev2<(int)m_LineArray.size(); nDev2++)
		{
			if (m_LineArray[nDev2].nType != PGEnumLineTran_MCType_Load && m_LineArray[nDev2].nType != PGEnumLineTran_MCType_Gen)
				continue;


			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2��һ�׹��� ����أ�������׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-1
			{
				nFault = SeekFault1InFault1(m_LineArray[nDev2].sFault1Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault1(m_L2Index.sFault1Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
					AddFault1(m_L2Index.sFault1Array, m_LineArray[nDev2].sFault1Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_LineArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-1
						AddFault2(m_L2Index.sFault2Array, m_LineArray[nDev1].sFault1Array[nDev1F], m_LineArray[nDev2].sFault1Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�Ķ��׹��� �� �豸2�Ķ��׹��� ����أ��������Ľ׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault2Array.size(); nDev1F++)			//	2-2
			{
				nFault = SeekFault2InFault2(m_LineArray[nDev2].sFault2Array, m_LineArray[nDev1].sFault2Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault2(m_L2Index.sFault2Array, m_LineArray[nDev1].sFault2Array[nDev1F]);
					AddFault2(m_L2Index.sFault2Array, m_LineArray[nDev2].sFault2Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_LineArray[nDev2].sFault2Array.size(); nDev2F++)			//	2-2
						CombineFault3(m_L2Index.sFault3Array,  &m_LineArray[nDev1].sFault2Array[nDev1F], &m_LineArray[nDev2].sFault2Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�����׹��� �� �豸2�����׹��� ����أ��������ġ��塢���׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault3Array.size(); nDev1F++)			//	3-3
			{
				nFault = SeekFault3InFault3(m_LineArray[nDev2].sFault3Array, m_LineArray[nDev1].sFault3Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev1].sFault3Array[nDev1F]);
					AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev2].sFault3Array[nFault]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2�Ķ��׹��� ����أ��������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-2
			{
				nFault = SeekFault1InFault2(m_LineArray[nDev2].sFault2Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault2(m_L2Index.sFault2Array, m_LineArray[nDev2].sFault2Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_LineArray[nDev2].sFault2Array.size(); nDev2F++)
						AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev1].sFault1Array[nDev1F], m_LineArray[nDev2].sFault2Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2�����׹��� ����أ��������Ľ׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-2
			{
				nFault = SeekFault1InFault3(m_LineArray[nDev2].sFault3Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
					AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev2].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�Ķ��׹��� �� �豸2�����׹��� ����أ���������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault2Array.size(); nDev1F++)			//	2-3
			{
				nFault = SeekFault2InFault3(m_LineArray[nDev2].sFault3Array, m_LineArray[nDev1].sFault2Array[nDev1F]);
				if (nFault >= 0)
					AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev2].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2��һ�׹��� �� �豸1�Ķ��׹��� ����أ��������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_LineArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-2
			{
				nFault = SeekFault1InFault2(m_LineArray[nDev1].sFault2Array, m_LineArray[nDev2].sFault1Array[nDev2F]);
				if (nFault >= 0)
				{
					AddFault2(m_L2Index.sFault2Array, m_LineArray[nDev1].sFault2Array[nFault]);
				}
				else
				{
					for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault2Array.size(); nDev1F++)
						AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev2].sFault1Array[nDev2F], m_LineArray[nDev1].sFault2Array[nDev1F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2��һ�׹��� �� �豸1�����׹��� ����أ��������Ľ׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_LineArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-2
			{
				nFault = SeekFault1InFault3(m_LineArray[nDev1].sFault3Array, m_LineArray[nDev2].sFault1Array[nDev2F]);
				if (nFault >= 0)
					AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev1].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2�Ķ��׹��� �� �豸1�����׹��� ����أ���������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_LineArray[nDev2].sFault2Array.size(); nDev2F++)			//	2-3
			{
				nFault = SeekFault2InFault3(m_LineArray[nDev1].sFault3Array, m_LineArray[nDev2].sFault2Array[nDev2F]);
				if (nFault >= 0)
					AddFault3(m_L2Index.sFault3Array, m_LineArray[nDev1].sFault3Array[nFault]);
			}
		}
	}
	MergeFault1(m_L2Index.sFault1Array);
	MergeFault2(m_L2Index.sFault2Array);
	MergeFault3(m_L2Index.sFault3Array);
	SeriesFault(m_L2Index.sFault1Array, m_L2Index.sFault2Array, m_L2Index.sFault3Array, m_L2Index);
	Contribution(m_L2Index.fLOR, m_L2Index.fLOU, m_L2Index.sFault1Array, m_L2Index.sFault2Array, m_L2Index.sFault3Array);

	//////////////////////////////////////////////////////////////////////////
	//	����
	m_T2Index.sFault1Array.clear();
	m_T2Index.sFault2Array.clear();
	m_T2Index.sFault3Array.clear();
	for	(nDev1=0; nDev1<(int)m_TranArray.size(); nDev1++)
	{
		if (m_TranArray[nDev1].nType != PGEnumLineTran_MCType_Load && m_TranArray[nDev1].nType != PGEnumLineTran_MCType_Gen)
			continue;

		for	(nDev2=nDev1+1; nDev2<(int)m_TranArray.size(); nDev2++)
		{
			if (m_TranArray[nDev2].nType != PGEnumLineTran_MCType_Load && m_TranArray[nDev2].nType != PGEnumLineTran_MCType_Gen)
				continue;

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2��һ�׹��� ����أ�������׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-1
			{
				nFault = SeekFault1InFault1(m_TranArray[nDev2].sFault1Array, m_TranArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault1(m_T2Index.sFault1Array, m_TranArray[nDev1].sFault1Array[nDev1F]);
					AddFault1(m_T2Index.sFault1Array, m_TranArray[nDev2].sFault1Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-1
						AddFault2(m_T2Index.sFault2Array, m_TranArray[nDev1].sFault1Array[nDev1F], m_TranArray[nDev2].sFault1Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�Ķ��׹��� �� �豸2�Ķ��׹��� ����أ��������Ľ׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault2Array.size(); nDev1F++)			//	2-2
			{
				nFault = SeekFault2InFault2(m_TranArray[nDev2].sFault2Array, m_TranArray[nDev1].sFault2Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault2(m_T2Index.sFault2Array, m_TranArray[nDev1].sFault2Array[nDev1F]);
					AddFault2(m_T2Index.sFault2Array, m_TranArray[nDev2].sFault2Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault2Array.size(); nDev2F++)			//	2-2
						CombineFault3(m_T2Index.sFault3Array,  &m_TranArray[nDev1].sFault2Array[nDev1F], &m_TranArray[nDev2].sFault2Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�����׹��� �� �豸2�����׹��� ����أ��������ġ��塢���׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault3Array.size(); nDev1F++)			//	3-3
			{
				nFault = SeekFault3InFault3(m_TranArray[nDev2].sFault3Array, m_TranArray[nDev1].sFault3Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev1].sFault3Array[nDev1F]);
					AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev2].sFault3Array[nFault]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2�Ķ��׹��� ����أ��������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-2
			{
				nFault = SeekFault1InFault2(m_TranArray[nDev2].sFault2Array, m_TranArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault2(m_T2Index.sFault2Array, m_TranArray[nDev2].sFault2Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault2Array.size(); nDev2F++)
						AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev1].sFault1Array[nDev1F], m_TranArray[nDev2].sFault2Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2�����׹��� ����أ��������Ľ׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-2
			{
				nFault = SeekFault1InFault3(m_TranArray[nDev2].sFault3Array, m_TranArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
					AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev2].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�Ķ��׹��� �� �豸2�����׹��� ����أ���������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault2Array.size(); nDev1F++)			//	2-3
			{
				nFault = SeekFault2InFault3(m_TranArray[nDev2].sFault3Array, m_TranArray[nDev1].sFault2Array[nDev1F]);
				if (nFault >= 0)
					AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev2].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2��һ�׹��� �� �豸1�Ķ��׹��� ����أ��������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-2
			{
				nFault = SeekFault1InFault2(m_TranArray[nDev1].sFault2Array, m_TranArray[nDev2].sFault1Array[nDev2F]);
				if (nFault >= 0)
				{
					AddFault2(m_T2Index.sFault2Array, m_TranArray[nDev1].sFault2Array[nFault]);
				}
				else
				{
					for (nDev1F=0; nDev1F<(int)m_TranArray[nDev1].sFault2Array.size(); nDev1F++)
						AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev2].sFault1Array[nDev2F], m_TranArray[nDev1].sFault2Array[nDev1F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2��һ�׹��� �� �豸1�����׹��� ����أ��������Ľ׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-2
			{
				nFault = SeekFault1InFault3(m_TranArray[nDev1].sFault3Array, m_TranArray[nDev2].sFault1Array[nDev2F]);
				if (nFault >= 0)
					AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev1].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2�Ķ��׹��� �� �豸1�����׹��� ����أ���������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault2Array.size(); nDev2F++)			//	2-3
			{
				nFault = SeekFault2InFault3(m_TranArray[nDev1].sFault3Array, m_TranArray[nDev2].sFault2Array[nDev2F]);
				if (nFault >= 0)
					AddFault3(m_T2Index.sFault3Array, m_TranArray[nDev1].sFault3Array[nFault]);
			}
		}
	}
	MergeFault1(m_T2Index.sFault1Array);
	MergeFault2(m_T2Index.sFault2Array);
	MergeFault3(m_T2Index.sFault3Array);
	SeriesFault(m_T2Index.sFault1Array, m_T2Index.sFault2Array, m_T2Index.sFault3Array, m_T2Index);
	Contribution(m_T2Index.fLOR, m_T2Index.fLOU, m_T2Index.sFault1Array, m_T2Index.sFault2Array, m_T2Index.sFault3Array);

	//////////////////////////////////////////////////////////////////////////
	//	�߱�
	m_LTIndex.sFault1Array.clear();
	m_LTIndex.sFault2Array.clear();
	m_LTIndex.sFault3Array.clear();
	for	(nDev1=0; nDev1<(int)m_LineArray.size(); nDev1++)
	{
		if (m_LineArray[nDev1].nType != PGEnumLineTran_MCType_Load && m_LineArray[nDev1].nType != PGEnumLineTran_MCType_Gen)
			continue;

		for	(nDev2=0; nDev2<(int)m_TranArray.size(); nDev2++)
		{
			if (m_TranArray[nDev2].nType != PGEnumLineTran_MCType_Load && m_TranArray[nDev2].nType != PGEnumLineTran_MCType_Gen)
				continue;

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2��һ�׹��� ����أ�������׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-1
			{
				nFault = SeekFault1InFault1(m_TranArray[nDev2].sFault1Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault1(m_LTIndex.sFault1Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
					AddFault1(m_LTIndex.sFault1Array, m_TranArray[nDev2].sFault1Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-1
						AddFault2(m_LTIndex.sFault2Array, m_LineArray[nDev1].sFault1Array[nDev1F], m_TranArray[nDev2].sFault1Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�Ķ��׹��� �� �豸2�Ķ��׹��� ����أ��������Ľ׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault2Array.size(); nDev1F++)			//	2-2
			{
				nFault = SeekFault2InFault2(m_TranArray[nDev2].sFault2Array, m_LineArray[nDev1].sFault2Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault2(m_LTIndex.sFault2Array, m_LineArray[nDev1].sFault2Array[nDev1F]);
					AddFault2(m_LTIndex.sFault2Array, m_TranArray[nDev2].sFault2Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault2Array.size(); nDev2F++)			//	2-2
						CombineFault3(m_LTIndex.sFault3Array,  &m_LineArray[nDev1].sFault2Array[nDev1F], &m_TranArray[nDev2].sFault2Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�����׹��� �� �豸2�����׹��� ����أ��������ġ��塢���׹��ϣ������һ������ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault3Array.size(); nDev1F++)			//	3-3
			{
				nFault = SeekFault3InFault3(m_TranArray[nDev2].sFault3Array, m_LineArray[nDev1].sFault3Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault3(m_LTIndex.sFault3Array, m_LineArray[nDev1].sFault3Array[nDev1F]);
					AddFault3(m_LTIndex.sFault3Array, m_TranArray[nDev2].sFault3Array[nFault]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2�Ķ��׹��� ����أ��������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-2
			{
				nFault = SeekFault1InFault2(m_TranArray[nDev2].sFault2Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
				{
					AddFault2(m_LTIndex.sFault2Array, m_TranArray[nDev2].sFault2Array[nFault]);
				}
				else
				{
					for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault2Array.size(); nDev2F++)
						AddFault3(m_LTIndex.sFault3Array, m_LineArray[nDev1].sFault1Array[nDev1F], m_TranArray[nDev2].sFault2Array[nDev2F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1��һ�׹��� �� �豸2�����׹��� ����أ��������Ľ׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault1Array.size(); nDev1F++)			//	1-2
			{
				nFault = SeekFault1InFault3(m_TranArray[nDev2].sFault3Array, m_LineArray[nDev1].sFault1Array[nDev1F]);
				if (nFault >= 0)
					AddFault3(m_LTIndex.sFault3Array, m_TranArray[nDev2].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸1�Ķ��׹��� �� �豸2�����׹��� ����أ���������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault2Array.size(); nDev1F++)			//	2-3
			{
				nFault = SeekFault2InFault3(m_TranArray[nDev2].sFault3Array, m_LineArray[nDev1].sFault2Array[nDev1F]);
				if (nFault >= 0)
					AddFault3(m_LTIndex.sFault3Array, m_TranArray[nDev2].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2��һ�׹��� �� �豸1�Ķ��׹��� ����أ��������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-2
			{
				nFault = SeekFault1InFault2(m_LineArray[nDev1].sFault2Array, m_TranArray[nDev2].sFault1Array[nDev2F]);
				if (nFault >= 0)
				{
					AddFault2(m_LTIndex.sFault2Array, m_LineArray[nDev1].sFault2Array[nFault]);
				}
				else
				{
					for (nDev1F=0; nDev1F<(int)m_LineArray[nDev1].sFault2Array.size(); nDev1F++)
						AddFault3(m_LTIndex.sFault3Array, m_TranArray[nDev2].sFault1Array[nDev2F], m_LineArray[nDev1].sFault2Array[nDev1F]);
				}
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2��һ�׹��� �� �豸1�����׹��� ����أ��������Ľ׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault1Array.size(); nDev2F++)			//	1-2
			{
				nFault = SeekFault1InFault3(m_LineArray[nDev1].sFault3Array, m_TranArray[nDev2].sFault1Array[nDev2F]);
				if (nFault >= 0)
					AddFault3(m_LTIndex.sFault3Array, m_LineArray[nDev1].sFault3Array[nFault]);
			}

			//////////////////////////////////////////////////////////////////////////
			//	�豸2�Ķ��׹��� �� �豸1�����׹��� ����أ���������׹��ϣ������һ�����׹ʹ���ģʽ�����豸ͬʱͣ��
			for (nDev2F=0; nDev2F<(int)m_TranArray[nDev2].sFault2Array.size(); nDev2F++)			//	2-3
			{
				nFault = SeekFault2InFault3(m_LineArray[nDev1].sFault3Array, m_TranArray[nDev2].sFault2Array[nDev2F]);
				if (nFault >= 0)
					AddFault3(m_LTIndex.sFault3Array, m_LineArray[nDev1].sFault3Array[nFault]);
			}
		}
	}
	MergeFault1(m_LTIndex.sFault1Array);
	MergeFault2(m_LTIndex.sFault2Array);
	MergeFault3(m_LTIndex.sFault3Array);
	SeriesFault(m_LTIndex.sFault1Array, m_LTIndex.sFault2Array, m_LTIndex.sFault3Array, m_LTIndex);
	Contribution(m_LTIndex.fLOR, m_LTIndex.fLOU, m_LTIndex.sFault1Array, m_LTIndex.sFault2Array, m_LTIndex.sFault3Array);

	//////////////////////////////////////////////////////////////////////////
	//	ȫվ
	m_SubIndex.sFault1Array.clear();
	m_SubIndex.sFault2Array.clear();
	m_SubIndex.sFault3Array.clear();
	for (nFault=0; nFault<(int)m_AugLoad.sFault1Array.size(); nFault++)
		AddFault1(m_SubIndex.sFault1Array, m_AugLoad.sFault1Array[nFault]);
	for (nFault=0; nFault<(int)m_AugLoad.sFault2Array.size(); nFault++)
		AddFault2(m_SubIndex.sFault2Array, m_AugLoad.sFault2Array[nFault]);
	for (nFault=0; nFault<(int)m_AugLoad.sFault3Array.size(); nFault++)
		AddFault3(m_SubIndex.sFault3Array, m_AugLoad.sFault3Array[nFault]);

	for (nFault=0; nFault<(int)m_AugGen.sFault1Array.size(); nFault++)
		AddFault1(m_SubIndex.sFault1Array, m_AugGen.sFault1Array[nFault]);
	for (nFault=0; nFault<(int)m_AugGen.sFault2Array.size(); nFault++)
		AddFault2(m_SubIndex.sFault2Array, m_AugGen.sFault2Array[nFault]);
	for (nFault=0; nFault<(int)m_AugGen.sFault3Array.size(); nFault++)
		AddFault3(m_SubIndex.sFault3Array, m_AugGen.sFault3Array[nFault]);

	MergeFault1(m_SubIndex.sFault1Array);
	MergeFault2(m_SubIndex.sFault2Array);
	MergeFault3(m_SubIndex.sFault3Array);
	SeriesFault(m_SubIndex.sFault1Array, m_SubIndex.sFault2Array, m_SubIndex.sFault3Array, m_SubIndex);
	Contribution(m_SubIndex.fLOR, m_SubIndex.fLOU, m_SubIndex.sFault1Array, m_SubIndex.sFault2Array, m_SubIndex.sFault3Array);
}

void CMCRPhyData::MCREconomy(const int nLifetime, const double fPrice, const double fRecip, const double fEValueRatio, const double fPowerFactor)
{
	register int	i;
	double			fBuffer;

	m_System.fEconomyInvest = 0;
	for (i=0; i<(int)m_BusArray.size(); i++)
		m_System.fEconomyInvest += m_BusArray[i].fInvest;
	for (i=0; i<(int)m_LineArray.size(); i++)
	{
		if (m_LineArray[i].nType == PGEnumLineTran_MCType_Edge)
			m_System.fEconomyInvest += m_LineArray[i].fInvest;
	}
	for (i=0; i<(int)m_TranArray.size(); i++)
	{
		//if (m_TranArray[i].nType == PGEnumLineTran_MCType_Edge)
			m_System.fEconomyInvest += m_TranArray[i].fInvest;
	}
	for (i=0; i<(int)m_ScapArray.size(); i++)
		m_System.fEconomyInvest += m_ScapArray[i].fInvest;
	for (i=0; i<(int)m_BreakerArray.size(); i++)
		m_System.fEconomyInvest += m_BreakerArray[i].fInvest;
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
		m_System.fEconomyInvest += m_DisconnectorArray[i].fInvest;

	fBuffer=1+fRecip/100;
	for (i=1; i<nLifetime; i++)
		fBuffer *= (1+fRecip/100);

	m_System.fEconomyAnnualWorth = m_System.fEconomyInvest*(fRecip/100)*fBuffer/(fBuffer-1);
	m_System.fEconomyLoss = m_System.fEns*fEValueRatio*fPowerFactor*fPrice/10;
	m_System.fEconomyTotal = m_System.fEconomyAnnualWorth+m_System.fEconomyLoss;

	m_System.fEconomyFaultLoss = m_System.fFaultEns*fEValueRatio*fPowerFactor*fPrice/10;
	m_System.fEconomyFaultTotal = m_System.fEconomyAnnualWorth+m_System.fEconomyFaultLoss;
}