#include "StdAfx.h"
#include "MCRAlgorithm.h"


void CMCRAlgorithm::FormMCut01Switch(const int nRouterComp, const int nSwitchComp)
{
	if (m_CompArray[nRouterComp].fTopr > FLT_MIN && m_CompArray[nSwitchComp].nStatus != 0 && m_CompArray[nSwitchComp].fTSwitch > FLT_MIN)
	{
		int nMCut = SeekMCut01(m_MinCut1Array, nRouterComp);
		if (nMCut >= 0)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "              һ�׸� %s - %s �л�\n",  m_CompArray[nRouterComp].strName.c_str(), m_CompArray[nSwitchComp].strName.c_str());
#endif
			m_MinCut1Array[nMCut].nSwitchComp = nSwitchComp;
		}
	}
}

void CMCRAlgorithm::FormMCut02Switch(const int nRouterComp1, const int nRouterComp2, const int nSwitchComp)
{
	int	nComp, nMCut = SeekMCut02(m_MinCut2Array, nRouterComp1, nRouterComp2);
	if (nMCut >= 0)
	{
		if (m_CompArray[nRouterComp1].fTopr > FLT_MIN)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "              ���׸� %s - %s �л�\n",  m_CompArray[nRouterComp1].strName.c_str(), m_CompArray[nSwitchComp].strName.c_str());
#endif
			for (nComp=0; nComp<2; nComp++)
			{
				if (m_MinCut2Array[nMCut].nComp[nComp] == nRouterComp1)
				{
					m_MinCut2Array[nMCut].nSwitchComp[nComp] = nSwitchComp;
					break;
				}
			}
		}
		if (m_CompArray[nRouterComp2].fTopr > FLT_MIN)
		{
			Log(g_lpszLogFile, "              ���׸� %s - %s �л�\n",  m_CompArray[nRouterComp2].strName.c_str(), m_CompArray[nSwitchComp].strName.c_str());
			for (nComp=0; nComp<2; nComp++)
			{
				if (m_MinCut2Array[nMCut].nComp[nComp] == nRouterComp2)
				{
					m_MinCut2Array[nMCut].nSwitchComp[nComp] = nSwitchComp;
					break;
				}
			}
		}
	}
}

void CMCRAlgorithm::FormMCut03Switch(const int nRouterComp1, const int nRouterComp2, const int nRouterComp3, const int nSwitchComp)
{
	int nComp, nMCut = SeekMCut03(m_MinCut3Array, nRouterComp1, nRouterComp2, nRouterComp3);	//	 nSwitchComp��nRouterComp1
	if (nMCut >= 0)
	{
		if (m_CompArray[nRouterComp1].fTopr > FLT_MIN)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "              ���׸� %s - %s �л�\n",  m_CompArray[nRouterComp1].strName.c_str(), m_CompArray[nSwitchComp].strName.c_str());
#endif
			for (nComp=0; nComp<3; nComp++)
			{
				if (m_MinCut3Array[nMCut].nComp[nComp] == nRouterComp1)
				{
					m_MinCut3Array[nMCut].nSwitchComp[nComp] = nSwitchComp;
					break;
				}
			}
		}
		if (m_CompArray[nRouterComp2].fTopr > FLT_MIN)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "              ���׸� %s - %s �л�\n",  m_CompArray[nRouterComp2].strName.c_str(), m_CompArray[nSwitchComp].strName.c_str());
#endif
			for (nComp=0; nComp<3; nComp++)
			{
				if (m_MinCut3Array[nMCut].nComp[nComp] == nRouterComp2)
				{
					m_MinCut3Array[nMCut].nSwitchComp[nComp] = nSwitchComp;
					break;
				}
			}
		}
		if (m_CompArray[nRouterComp3].fTopr > FLT_MIN)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "              ���׸� %s - %s �л�\n",  m_CompArray[nRouterComp3].strName.c_str(), m_CompArray[nSwitchComp].strName.c_str());
#endif
			for (nComp=0; nComp<3; nComp++)
			{
				if (m_MinCut3Array[nMCut].nComp[nComp] == nRouterComp3)
				{
					m_MinCut3Array[nMCut].nSwitchComp[nComp] = nSwitchComp;
					break;
				}
			}
		}
	}
}

void CMCRAlgorithm::FormSwitchShortCut(std::vector<tagMCRAlgPath>& sMinPathArray)
{
	register int	i;
	int		j1, j2, j3, j4;
	int		nMCut, nPath, nComp;

	clock_t	dBeg, dEnd;
	int		nDur;

	tagMCRAlgMinCut1	sCut1Buf;
	tagMCRAlgMinCut2	sCut2Buf;
	tagMCRAlgMinCut3	sCut3Buf;
	tagMCRAlgMinCut4	sCut4Buf;
	std::vector<tagMCRAlgMinCut1>		sAllCut1Array;
	std::vector<tagMCRAlgMinCut2>		sAllCut2Array;
	std::vector<tagMCRAlgMinCut3>		sAllCut3Array;
	std::vector<tagMCRAlgMinCut4>		sAllCut4Array;

	for (nMCut=0; nMCut<(int)m_MinCut1Array.size(); nMCut++)
	{
		m_MinCut1Array[nMCut].nSwitchComp = -1;
	}
	for (nMCut=0; nMCut<(int)m_MinCut2Array.size(); nMCut++)
	{
		m_MinCut2Array[nMCut].nSwitchComp[0] = -1;
		m_MinCut2Array[nMCut].nSwitchComp[1] = -1;
	}
	for (nMCut=0; nMCut<(int)m_MinCut3Array.size(); nMCut++)
	{
		m_MinCut3Array[nMCut].nSwitchComp[0] = -1;
		m_MinCut3Array[nMCut].nSwitchComp[1] = -1;
		m_MinCut3Array[nMCut].nSwitchComp[2] = -1;
	}

	if (sMinPathArray.empty())
		return;

	dBeg=clock();

	sAllCut1Array.clear();
	sAllCut2Array.clear();
	sAllCut3Array.clear();
	sAllCut4Array.clear();
	memset(&sCut1Buf, 0, sizeof(tagMCRAlgMinCut1));
	memset(&sCut2Buf, 0, sizeof(tagMCRAlgMinCut2));
	memset(&sCut3Buf, 0, sizeof(tagMCRAlgMinCut3));
	memset(&sCut4Buf, 0, sizeof(tagMCRAlgMinCut4));

	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
		m_CompArray[nComp].bInPath=0;
	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		//	Ϊ������С�����٣�������С·���豸��Ϣ��
		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp=sMinPathArray[nPath].nCompArray[i];
			m_CompArray[nComp].bInPath=1;
			sMinPathArray[nPath].nCompVector[nComp]=1;
		}
	}

	for (j1=0; j1<(int)m_CompArray.size(); j1++) //��һ��
	{
		if (!m_CompArray[j1].bInPath)
			continue;
		//if (m_CompArray[j1].fRerr < FLT_MIN && m_CompArray[j1].fTrep < FLT_MIN)
		//	continue;

		if (isShortCut01(sMinPathArray, NCheckStatus, j1))
		{
			if (SeekMCut01(sAllCut1Array, j1) < 0)
			{
				sCut1Buf.nComp=j1;
				sAllCut1Array.push_back(sCut1Buf);
			}
			continue;
		}

		if (sMinPathArray.size() > 1)
		{
			for (j2=0; j2<j1; j2++) //�����
			{
				if (!m_CompArray[j2].bInPath)
					continue;
				//if (m_CompArray[j2].fRerr < FLT_MIN && m_CompArray[j2].fTrep < FLT_MIN)
				//	continue;
				if (SeekMCut01(sAllCut1Array, j2) >= 0) //�����ж�j2�Ƿ񹹳�һ�׸
					continue;

				if (isShortCut02(sMinPathArray, NCheckStatus, j2, j1))
				{
					if (SeekMCut02(sAllCut2Array, j1, j2) < 0)
					{
						sCut2Buf.nComp[0]=j2;
						sCut2Buf.nComp[1]=j1;
						sAllCut2Array.push_back(sCut2Buf);
					}
					continue;
				}

				if (sMinPathArray.size() > 2)
				{
					for (j3=0; j3<j2; j3++) //������
					{
						if (!m_CompArray[j3].bInPath)
							continue;
						//if (m_CompArray[j3].fRerr < FLT_MIN && m_CompArray[j3].fTrep < FLT_MIN)
						//	continue;
						if (SeekMCut01(sAllCut1Array, j3) >= 0) //�����ж�j3�Ƿ񹹳�һ�׸
							continue;

						if (SeekMCut02(sAllCut2Array, j3, j1) >= 0) //ɸ������
							continue;
						if (SeekMCut02(sAllCut2Array, j3, j2) >= 0) //ɸ������
							continue;

						if (isShortCut03(sMinPathArray, NCheckStatus, j3, j2, j1))
						{
							if (SeekMCut03(sAllCut3Array, j1, j2, j3) < 0)
							{
								sCut3Buf.nComp[0]=j3;
								sCut3Buf.nComp[1]=j2;
								sCut3Buf.nComp[2]=j1;
								sAllCut3Array.push_back(sCut3Buf);
							}
							continue;
						}

						if (sMinPathArray.size() > 3)
						{
							for (j4=0; j4<j3; j4++) //���Ľ�
							{
								if (!m_CompArray[j4].bInPath)
									continue;
								//if (m_CompArray[j4].fRerr < FLT_MIN && m_CompArray[j4].fTrep < FLT_MIN)
								//	continue;

								//////////////////////////////////////////////////////////////////////////
								//	���µ����ж�˳����Ϊ������
								if (isShortCut04(sMinPathArray, NCheckStatus, j4, j3, j2, j1))
								{
									if (SeekMCut01(sAllCut1Array, j4) >= 0) //�����ж�j4�Ƿ񹹳�һ�׸
										continue;

									if (SeekMCut02(sAllCut2Array, j4, j1) >= 0) //ɸ������
										continue;
									if (SeekMCut02(sAllCut2Array, j4, j2) >= 0) //ɸ������
										continue;
									if (SeekMCut02(sAllCut2Array, j4, j3) >= 0) //ɸ������
										continue;

									if (SeekMCut03(sAllCut3Array, j1, j2, j4) >= 0) //ɸ������
										continue;
									if (SeekMCut03(sAllCut3Array, j1, j3, j4) >= 0) //ɸ������
										continue;
									if (SeekMCut03(sAllCut3Array, j2, j3, j4) >= 0) //ɸ������
										continue;

									if (SeekMCut04(sAllCut4Array, j1, j2, j3, j4) < 0)
									{
										sCut4Buf.nComp[0]=j4;
										sCut4Buf.nComp[1]=j3;
										sCut4Buf.nComp[2]=j2;
										sCut4Buf.nComp[3]=j1;
										sAllCut4Array.push_back(sCut4Buf);
									}

									continue;
								}
							}
						}
					}
				}
			}
		}
	}

#ifdef _DEBUG
	for (i=0; i<(int)sAllCut2Array.size(); i++)
	{
		j1=sAllCut2Array[i].nComp[0];
		j2=sAllCut2Array[i].nComp[1];
		if (m_CompArray[j1].nStatus == 0 && m_CompArray[j2].nStatus == 0)
			continue;

		Log(g_lpszLogFile,  "          �л�������С��[%d/%d]�� %s, %s    %s, %s\n", i, sAllCut2Array.size(),
			PGGetTableName(m_CompArray[j1].nPhyTyp), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nPhyTyp), m_CompArray[j2].strName.c_str());
	}
	for (i=0; i<(int)sAllCut3Array.size(); i++)
	{
		j1=sAllCut3Array[i].nComp[0];
		j2=sAllCut3Array[i].nComp[1];
		j3=sAllCut3Array[i].nComp[2];
		if (m_CompArray[j1].nStatus == 0 && m_CompArray[j2].nStatus == 0 && m_CompArray[j3].nStatus == 0)
			continue;

		Log(g_lpszLogFile,  "          �л�������С��[%d/%d]�� %s, %s    %s, %s    %s, %s\n", i, sAllCut3Array.size(),
			PGGetTableName(m_CompArray[j1].nPhyTyp), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nPhyTyp), m_CompArray[j2].strName.c_str(),
			PGGetTableName(m_CompArray[j3].nPhyTyp), m_CompArray[j3].strName.c_str());
	}
	for (i=0; i<(int)sAllCut4Array.size(); i++)
	{
		j1=sAllCut4Array[i].nComp[0];
		j2=sAllCut4Array[i].nComp[1];
		j3=sAllCut4Array[i].nComp[2];
		j4=sAllCut4Array[i].nComp[3];
		if (m_CompArray[j1].nStatus == 0 && m_CompArray[j2].nStatus == 0 && m_CompArray[j3].nStatus == 0 && m_CompArray[j4].nStatus == 0)
			continue;

		Log(g_lpszLogFile,  "          �л��Ľ���С��[%d/%d]�� %s, %s    %s, %s    %s, %s    %s, %s\n", i, sAllCut4Array.size(),
			PGGetTableName(m_CompArray[j1].nPhyTyp), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nPhyTyp), m_CompArray[j2].strName.c_str(),
			PGGetTableName(m_CompArray[j3].nPhyTyp), m_CompArray[j3].strName.c_str(),
			PGGetTableName(m_CompArray[j4].nPhyTyp), m_CompArray[j4].strName.c_str());
	}

#endif

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("              �л����� �������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile,  "              �л����� �������ɣ���ʱ%d����\n",  nDur);

	//////////////////////////////////////////////////////////////////////////
	//	���׸������л��豸������л�
	for (i=0; i<(int)sAllCut2Array.size(); i++)
	{
		j1=sAllCut2Array[i].nComp[0];
		j2=sAllCut2Array[i].nComp[1];
		if (m_CompArray[j1].nStatus == 0 && m_CompArray[j2].nStatus == 0)
			continue;
		if (m_CompArray[j1].nStatus == 1 && m_CompArray[j2].nStatus == 1)
			continue;

		if (SeekMCut02(m_MinCut2Array, j1, j2) >= 0)
			continue;

		if (m_CompArray[j2].fTopr > FLT_MIN && m_CompArray[j1].nStatus != 0 && m_CompArray[j1].fTSwitch > FLT_MIN)
			FormMCut01Switch(j2, j1);
		if (m_CompArray[j1].fTopr > FLT_MIN && m_CompArray[j2].nStatus != 0 && m_CompArray[j2].fTSwitch > FLT_MIN)
			FormMCut01Switch(j1, j2);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("              �л����� һ�׸��л���ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "              �л����� һ�׸��л���ɣ���ʱ%d����\n",  nDur);

	//////////////////////////////////////////////////////////////////////////
	//	���׸������л��豸������л�
	for (i=0; i<(int)sAllCut3Array.size(); i++)
	{
		j1=sAllCut3Array[i].nComp[0];
		j2=sAllCut3Array[i].nComp[1];
		j3=sAllCut3Array[i].nComp[2];
		if (m_CompArray[j1].nStatus == 0 && m_CompArray[j2].nStatus == 0 && m_CompArray[j3].nStatus == 0)
			continue;
		if (m_CompArray[j1].nStatus == 1 && m_CompArray[j2].nStatus == 1 && m_CompArray[j3].nStatus == 1)
			continue;

		if (SeekMCut03(m_MinCut3Array, j1, j2, j3) >= 0)
			continue;

		//////////////////////////////////////////////////////////////////////////
		//	�л���j1
		if (m_CompArray[j1].nStatus != 0 && m_CompArray[j1].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j2, j1);
			FormMCut01Switch(j3, j1);

			FormMCut02Switch(j2, j3, j1);
		}

		//////////////////////////////////////////////////////////////////////////
		//	�л���j2
		if (m_CompArray[j2].nStatus != 0 && m_CompArray[j2].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j1, j2);
			FormMCut01Switch(j3, j2);

			FormMCut02Switch(j1, j3, j2);
		}

		//////////////////////////////////////////////////////////////////////////
		//	�л���j3
		if (m_CompArray[j3].nStatus != 0 && m_CompArray[j3].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j1, j3);
			FormMCut01Switch(j2, j3);

			FormMCut02Switch(j1, j2, j3);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("              �л����� ���׸��л���ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "              �л����� ���׸��л���ɣ���ʱ%d����\n",  nDur);

	//////////////////////////////////////////////////////////////////////////
	//	�Ľ׸������л��豸������л�
	for (i=0; i<(int)sAllCut4Array.size(); i++)
	{
		j1=sAllCut4Array[i].nComp[0];
		j2=sAllCut4Array[i].nComp[1];
		j3=sAllCut4Array[i].nComp[2];
		j4=sAllCut4Array[i].nComp[3];
		if (m_CompArray[j1].nStatus == 0 && m_CompArray[j2].nStatus == 0 && m_CompArray[j3].nStatus == 0 && m_CompArray[j4].nStatus == 0)
			continue;
		if (m_CompArray[j1].nStatus == 1 && m_CompArray[j2].nStatus == 1 && m_CompArray[j3].nStatus == 1 && m_CompArray[j4].nStatus == 1)
			continue;

		if (m_CompArray[j1].nStatus != 0 && m_CompArray[j1].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j2, j1);
			FormMCut01Switch(j3, j1);
			FormMCut01Switch(j4, j1);

			FormMCut02Switch(j2, j3, j1);
			FormMCut02Switch(j2, j4, j1);
			FormMCut02Switch(j3, j4, j1);

			FormMCut03Switch(j2, j3, j4, j1);
		}

		if (m_CompArray[j2].nStatus != 0 && m_CompArray[j2].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j1, j2);
			FormMCut01Switch(j3, j2);
			FormMCut01Switch(j4, j2);

			FormMCut02Switch(j1, j3, j2);
			FormMCut02Switch(j1, j4, j2);
			FormMCut02Switch(j3, j4, j2);

			FormMCut03Switch(j1, j3, j4, j2);
		}

		if (m_CompArray[j3].nStatus != 0 && m_CompArray[j3].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j1, j3);
			FormMCut01Switch(j2, j3);
			FormMCut01Switch(j4, j3);

			FormMCut02Switch(j1, j2, j3);
			FormMCut02Switch(j1, j4, j3);
			FormMCut02Switch(j2, j4, j3);

			FormMCut03Switch(j1, j2, j4, j3);
		}

		if (m_CompArray[j4].nStatus != 0 && m_CompArray[j4].fTSwitch > FLT_MIN)
		{
			FormMCut01Switch(j1, j4);
			FormMCut01Switch(j2, j4);
			FormMCut01Switch(j3, j4);

			FormMCut02Switch(j1, j2, j4);
			FormMCut02Switch(j1, j3, j4);
			FormMCut02Switch(j2, j3, j4);

			FormMCut03Switch(j1, j2, j3, j4);
		}
	}
	//	�������п��л��Ķ��׸�����׸�
	//////////////////////////////////////////////////////////////////////////

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("              �л����� ���׸��л���ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile, "              �л����� ���׸��л���ɣ���ʱ%d����\n",  nDur);

	sAllCut1Array.clear();
	sAllCut2Array.clear();
	sAllCut3Array.clear();
	sAllCut4Array.clear();
}
