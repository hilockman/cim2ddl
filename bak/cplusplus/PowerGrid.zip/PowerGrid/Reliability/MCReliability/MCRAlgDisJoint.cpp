#include "StdAfx.h"
#include "MCRAlgDisJoint.h"

CMCRAlgDisJoint::CMCRAlgDisJoint(void)
{
	m_nMaxRoad = 0;
}

CMCRAlgDisJoint::~CMCRAlgDisJoint(void)
{
}

int CMCRAlgDisJoint::GetVw(int nEdge)
{
	int nFanOut=1;
	while(1)
	{
		if (m_DisjointNodeMatrix[nFanOut-1][nEdge-1] != -50)
			nFanOut++;
		else
			break;
	}
	return(nFanOut);
}

int CMCRAlgDisJoint::DisJoint_Init(const int nIniAlgNode, const unsigned char bPosDirection, const unsigned char bCheckStatus, IN std::vector<tagMCRAlgNode>& sNodeArray, IN std::vector<tagMCRAlgComp>& sCompArray, std::vector<int>& nRangeNodeArray)
{
	register int	i, j;
	int		nNode, nComp, nOppNode;
	std::vector<int>	nNobnArray;

	m_nBusNum=(int)nRangeNodeArray.size();

	m_RouteMatrix.clear();
	for (nNode=0; nNode<(int)nRangeNodeArray.size(); nNode++)
	{
		nNobnArray.clear();
		for (i=0; i<(int)sNodeArray[nRangeNodeArray[nNode]].nCompArray.size(); i++)
		{
			nComp=sNodeArray[nRangeNodeArray[nNode]].nCompArray[i];
			if (bCheckStatus && sCompArray[nComp].nStatus != 0)
				continue;
			if (sCompArray[nComp].nPhyTyp == PG_BUSBARSECTION)
				continue;

			if (bPosDirection == PosDirection)
			{
				if (sCompArray[nComp].nDirection == I2JDirection)
				{
					if (sCompArray[nComp].nIniAlgNode == nRangeNodeArray[nNode])
						continue;
				}
				if (sCompArray[nComp].nDirection == J2IDirection)
				{
					if (sCompArray[nComp].nEndAlgNode == nRangeNodeArray[nNode])
						continue;
				}
			}
			else if (bPosDirection == NegDirection)
			{
				if (sCompArray[nComp].nDirection == J2IDirection)
				{
					if (sCompArray[nComp].nIniAlgNode == nRangeNodeArray[nNode])
						continue;
				}
				if (sCompArray[nComp].nDirection == I2JDirection)
				{
					if (sCompArray[nComp].nEndAlgNode == nRangeNodeArray[nNode])
						continue;
				}
			}

			nOppNode=(sCompArray[nComp].nIniAlgNode == nRangeNodeArray[nNode]) ? sCompArray[nComp].nEndAlgNode : sCompArray[nComp].nIniAlgNode;
			for (j=0; j<(int)nRangeNodeArray.size(); j++)
			{
				if (nRangeNodeArray[j] == nOppNode)
				{
					nNobnArray.push_back(j+1);
					break;
				}
			}
		}
		//��Դ���֧·��Ϣ�������仯
		//if (nNobnArray.size() != m_NobnArray[nRangeNodeArray[nNode]].nOppNodeArray.size())
		//	return 0;
		nNobnArray.push_back(0);
		m_RouteMatrix.push_back(nNobnArray);
	}

	m_nIniBus=-1;
	for (i=0; i<(int)nRangeNodeArray.size(); i++)
	{
		if (nIniAlgNode == nRangeNodeArray[i])
		{
			m_nIniBus=i+1;
			break;
		}
	}
	if (m_nIniBus <= 0)
		return 0;
	m_RouteMatrix[m_nIniBus-1][m_RouteMatrix[m_nIniBus-1].size()-1]=-1;

	std::vector<int>	nVBuf;
	nVBuf.resize(m_nConstMaxEdge, -50);
	m_DisjointNodeMatrix.clear();
	for (i=0; i<m_nBusNum+1; i++)
		m_DisjointNodeMatrix.push_back(nVBuf);
	nVBuf.clear();

	m_DisjointNodeMatrix[0][0]=m_nIniBus;

	m_nPosVector.resize(m_nBusNum, 1);
	m_nChkVector.resize(m_nBusNum, 0);

	return 1;
}

void CMCRAlgDisJoint::DisJoint_Calc(const int nEndAlgNode, std::vector<int>& nRangeNodeArray)
{
	register int	i, j;
	int	nNode=2, nRoad=1, nBus=m_nIniBus;

	m_nEndBus=-1;
	for (i=0; i<(int)nRangeNodeArray.size(); i++)
	{
		if (nEndAlgNode == nRangeNodeArray[i])
		{
			m_nEndBus=i+1;
			break;
		}
	}
	if (m_nEndBus <= 0)
		return;

	for (i=0; i<m_nBusNum; i++)
	{
		m_nPosVector[i]=1;
		m_nChkVector[i]=0;
	}
	m_nChkVector[m_nIniBus-1]=1;
	m_nChkVector[m_nEndBus-1]=-1;

	for (i=0; i<m_nBusNum+1; i++)
	{
		for (j=0; j<m_nConstMaxEdge; j++)
			m_DisjointNodeMatrix[i][j]=-50;
	}
	m_DisjointNodeMatrix[0][0]=m_nIniBus;

	while(1)
	{
		m_DisjointNodeMatrix[nNode-1][nRoad-1]=m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1];
		if (m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1] > 0)							//	nBus��λ��m_nPosVector[nBus-1]�����ȳ�֧·
		{
			if (m_nChkVector[m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1]-1] > 0)		//	nBus��λ��m_nPosVector[nBus-1]�������Ѿ���������
			{
				m_nPosVector[nBus-1]=m_nPosVector[nBus-1]+1;							//	������һ��λ��
				continue;
			}
			else
			{
				if (m_nChkVector[m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1]-1] == 0)
				{
					nBus=m_DisjointNodeMatrix[nNode-1][nRoad-1];
					m_nChkVector[nBus-1]=1;
					nNode++;
					continue;
				}
				else
				{
					m_nPosVector[nBus-1]=m_nPosVector[nBus-1]+1;

					int Vw=GetVw(nRoad)-2;
					for (i=0; i<Vw; i++)
					{
						m_DisjointNodeMatrix[i][nRoad]=m_DisjointNodeMatrix[i][nRoad-1];
					}
					if (nRoad < m_nConstMaxEdge-1)	nRoad++;

					if (nRoad > m_nMaxRoad)
						m_nMaxRoad=nRoad;

					continue;
				}
			}
		}
		else
		{
			if (m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1] == 0)	//	nBus��λ��m_nPosVector[nBus-1]��û���ȳ�֧·
			{
				m_nChkVector[nBus-1]=0;
				m_nPosVector[nBus-1]=1;
				nBus=m_DisjointNodeMatrix[nNode-3][nRoad-1];
				m_nPosVector[nBus-1]=m_nPosVector[nBus-1]+1;
				nNode--;
				continue;
			}
			else	//	nBus��λ��m_nPosVector[nBus-1]������Ŀ���
			{
				break;
			}
		}
	}
	// 	for (i=0; i<m_nConstMaxEdge; i++)
	// 	{
	// 		nEdgeNum=0;
	// 		for(j=0; j<(int)nRangeNodeArray.size()+1; j++)
	// 		{
	// 			if (m_DisjointNodeMatrix[j][i] != -50 && m_DisjointNodeMatrix[j][i] > 0)
	// 			{
	// 				Log(g_lpszLogFile,  "%d\t", nRangeNodeArray[m_DisjointNodeMatrix[j][i]-1]);
	// 				nEdgeNum++;
	// 			}
	// 		}
	// 		if (nEdgeNum > 0)	Log(g_lpszLogFile,  "\n");
	// 	}
}

void CMCRAlgDisJoint::DisJoint2MinPath(IN std::vector<tagMCRAlgNode>& sNodeArray, IN std::vector<tagMCRAlgComp>& sCompArray, std::vector<int>& nRangeNodeArray, std::vector<tagMCRAlgPath>& sMinPathArray)
{
	register int	i;
	int		nEdge, nNode, nComp, nFrNode, nToNode, nOppNode;
	int		nEdgeNum;
	tagMCRAlgPath	pathBuf;

	pathBuf.nCompArray.clear();
	pathBuf.nCompVector.clear();
	pathBuf.nStatus = 0;

	for (nEdge=0; nEdge<m_nConstMaxEdge; nEdge++)
	{
		nEdgeNum=0;
		nFrNode=nToNode=-1;
		pathBuf.nCompArray.clear();
		for (nNode=0; nNode<(int)nRangeNodeArray.size()+1; nNode++)
		{
			if (m_DisjointNodeMatrix[nNode][nEdge] != -50 && m_DisjointNodeMatrix[nNode][nEdge] > 0)
			{
				//Log(g_lpszLogFile,  "%d\t", nRangeNodeArray[m_DisjointNodeMatrix[nNode][nEdge]-1]);
				if (nToNode < 0)
				{
					nToNode=nRangeNodeArray[m_DisjointNodeMatrix[nNode][nEdge]-1];
				}
				else if (nToNode >= 0)
				{
					nFrNode=nToNode;
					nToNode=nRangeNodeArray[m_DisjointNodeMatrix[nNode][nEdge]-1];
				}

				if (nFrNode >= 0 && nToNode >= 0)
				{
					nEdgeNum++;
					for (i=0; i<(int)sNodeArray[nFrNode].nCompArray.size(); i++)
					{
						nComp=sNodeArray[nFrNode].nCompArray[i];
						if (sCompArray[nComp].nPhyTyp == PG_BUSBARSECTION)
							continue;
						if (sCompArray[nComp].nIniAlgNode == sCompArray[nComp].nEndAlgNode)
							continue;
						nOppNode=(sCompArray[nComp].nIniAlgNode == nFrNode) ? sCompArray[nComp].nEndAlgNode : sCompArray[nComp].nIniAlgNode;
						if (nOppNode == nToNode)
						{
							pathBuf.nCompArray.push_back(nComp);
							break;
						}
					}
				}
			}
		}
		if (nEdgeNum > 0)
			sMinPathArray.push_back(pathBuf);
		//if (nEdgeNum > 0)	Log(g_lpszLogFile,  "\n");
	}
}
