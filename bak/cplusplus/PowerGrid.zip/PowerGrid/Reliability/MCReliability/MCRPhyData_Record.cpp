#include "StdAfx.h"
#include "MCRPhyData.h"

int	CMCRPhyData::GetCompID(const short nCompTyp, const int nCompIdx)
{
	switch (nCompTyp)
	{
	case	PG_ACLINESEGMENT:
	case	PG_ENERGYCONSUMER:
		return 1000*nCompTyp+nCompIdx+1;
		break;
	case	PG_TRANSFORMERWINDING:
		return 1000*nCompTyp+nCompIdx+1;
		break;
	case	PG_BREAKER:
		return 1000*nCompTyp+nCompIdx+1;
		break;
	case	PG_DISCONNECTOR:
		return 1000*nCompTyp+nCompIdx+1;
		break;
	case	PG_SERIESCOMPENSATOR:
		return 1000*nCompTyp+nCompIdx+1;
		break;
	case	PG_BUSBARSECTION:
		return 1000*nCompTyp+nCompIdx+1;
		break;
	}

	return 0;
}

std::string	CMCRPhyData::GetCompString(const short nCompTyp, const int nCompIdx)
{
	char	szBuf[260];

	memset(szBuf, 0, 260);
	switch (nCompTyp)
	{
	case	PG_ACLINESEGMENT:
	case	PG_ENERGYCONSUMER:
		sprintf(szBuf, "%s[%s %s]", PGGetTableDesp(nCompTyp), m_LineArray[nCompIdx].strVolt.c_str(), m_LineArray[nCompIdx].strName.c_str());
		break;
	case	PG_TRANSFORMERWINDING:
		sprintf(szBuf, "%s[%s@%s]", PGGetTableDesp(nCompTyp), m_TranArray[nCompIdx].strName.c_str(), m_TranArray[nCompIdx].strSub.c_str());
		break;
	case	PG_BREAKER:
		sprintf(szBuf, "%s[%s %s %s]", PGGetTableDesp(nCompTyp), m_BreakerArray[nCompIdx].strSub.c_str(), m_BreakerArray[nCompIdx].strVolt.c_str(), m_BreakerArray[nCompIdx].strName.c_str());
		break;
	case	PG_DISCONNECTOR:
		sprintf(szBuf, "%s[%s %s %s]", PGGetTableDesp(nCompTyp), m_DisconnectorArray[nCompIdx].strSub.c_str(), m_DisconnectorArray[nCompIdx].strVolt.c_str(), m_DisconnectorArray[nCompIdx].strName.c_str());
		break;
	case	PG_SERIESCOMPENSATOR:
		sprintf(szBuf, "%s[%s %s %s]", PGGetTableDesp(nCompTyp), m_ScapArray[nCompIdx].strSub.c_str(), m_ScapArray[nCompIdx].strVolt.c_str(), m_ScapArray[nCompIdx].strName.c_str());
		break;
	case	PG_BUSBARSECTION:
		sprintf(szBuf, "%s[%s %s %s]", PGGetTableDesp(nCompTyp), m_BusArray[nCompIdx].strSub.c_str(), m_BusArray[nCompIdx].strVolt.c_str(), m_BusArray[nCompIdx].strName.c_str());
		break;
	}

	return szBuf;
}

int	CMCRPhyData::GetPhyDataField(const int nTable, const char* lpszField)
{
	register int	i;
	switch (nTable)
	{
	case	PG_BUSBARSECTION:
		for (i=0; i<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyBusField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyBusField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	case	PG_ACLINESEGMENT:
		for (i=0; i<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyLineField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyLineField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	case	PG_TRANSFORMERWINDING:
		for (i=0; i<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyTranField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyTranField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	case	PG_SERIESCOMPENSATOR:
		for (i=0; i<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyScapField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyScapField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	case	PG_BREAKER:
		for (i=0; i<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyBreakerField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyBreakerField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	case	PG_DISCONNECTOR:
		for (i=0; i<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyDisconnectorField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyDisconnectorField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	case	PG_ENERGYCONSUMER:
		for (i=0; i<sizeof(g_MCPhyLoadField)/sizeof(tagMCRPhyField); i++)
		{
			if (stricmp(PGGetFieldName(nTable, g_MCPhyLoadField[i].nMDBField), lpszField) == 0 || stricmp(PGGetFieldDesp(nTable, g_MCPhyLoadField[i].nMDBField), lpszField) == 0)
				return i;
		}
		break;
	}
	return -1;
}

std::string	CMCRPhyData::GetPhyDataValue(const int nTable, const int nField, const int nRecord)
{
	switch (nTable)
	{
	case	PG_BUSBARSECTION:
		if (nRecord >= 0 && nRecord < (int)m_BusArray.size())
			return	GetPhyBusData(nField, nRecord);
		break;
	case	PG_ACLINESEGMENT:
		if (nRecord >= 0 && nRecord < (int)m_LineArray.size())
			return	GetPhyLineData(nField, nRecord);
		break;
	case	PG_TRANSFORMERWINDING:
		if (nRecord >= 0 && nRecord < (int)m_TranArray.size())
			return	GetPhyTranData(nField, nRecord);
		break;
	case	PG_SERIESCOMPENSATOR:
		if (nRecord >= 0 && nRecord < (int)m_ScapArray.size())
			return	GetPhyScapData(nField, nRecord);
		break;
	case	PG_BREAKER:
		if (nRecord >= 0 && nRecord < (int)m_BreakerArray.size())
			return	GetPhyBreakerData(nField, nRecord);
		break;
	case	PG_DISCONNECTOR:
		if (nRecord >= 0 && nRecord < (int)m_DisconnectorArray.size())
			return	GetPhyDisconnectorData(nField, nRecord);
		break;
	}
	return "";
}

std::string	CMCRPhyData::GetPhyBusData(const int nField, const int nRecord)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);

	if (nRecord >= 0 && nRecord < (int)m_BusArray.size())
	{
		if (nField == MCPhyBus_Node)		strcpy(szValue, m_BusArray[nRecord].strNode.c_str());
		else if (nField == MCPhyBus_Sub)	strcpy(szValue, m_BusArray[nRecord].strSub.c_str());
		else if (nField == MCPhyBus_Volt)	strcpy(szValue, m_BusArray[nRecord].strVolt.c_str());
		else if (nField == MCPhyBus_Name)	strcpy(szValue, m_BusArray[nRecord].strName.c_str());
		else if (nField == MCPhyBus_ByPass)	sprintf(szValue, "%d", m_BusArray[nRecord].bByPass);
		else if (nField == MCPhyBus_Rerr)	sprintf(szValue, "%f", m_BusArray[nRecord].fRerr);
		else if (nField == MCPhyBus_Trep)	sprintf(szValue, "%f", m_BusArray[nRecord].fTrep);
		else if (nField == MCPhyBus_Rchk)	sprintf(szValue, "%f", m_BusArray[nRecord].fRchk);
		else if (nField == MCPhyBus_Tchk)	sprintf(szValue, "%f", m_BusArray[nRecord].fTchk);
		else if (nField == MCPhyBus_Topr)	sprintf(szValue, "%f", m_BusArray[nRecord].fTopr);
		else if (nField == MCPhyBus_Invest)	sprintf(szValue, "%f", m_BusArray[nRecord].fInvest);
	}

	return szValue;
}

std::string	CMCRPhyData::GetPhyLineData(const int nField, const int nRecord)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);

	if (nRecord >= 0 && nRecord < (int)m_LineArray.size())
	{
		if (nField == MCPhyLine_NodeI)			strcpy(szValue, m_LineArray[nRecord].strNodeI.c_str());
		else if (nField == MCPhyLine_NodeJ)		strcpy(szValue, m_LineArray[nRecord].strNodeJ.c_str());
		else if (nField == MCPhyLine_SubI)		strcpy(szValue, m_LineArray[nRecord].strSubI.c_str());
		else if (nField == MCPhyLine_SubJ)		strcpy(szValue, m_LineArray[nRecord].strSubJ.c_str());
		else if (nField == MCPhyLine_Volt)		strcpy(szValue, m_LineArray[nRecord].strVolt.c_str());
		else if (nField == MCPhyLine_Name)		strcpy(szValue, m_LineArray[nRecord].strName.c_str());
		else if (nField == MCPhyLine_Type)		sprintf(szValue, "%d", m_LineArray[nRecord].nType);
		else if (nField == MCPhyLine_Length)	sprintf(szValue, "%f", m_LineArray[nRecord].fLength);
		else if (nField == MCPhyLine_Power)		sprintf(szValue, "%f", m_LineArray[nRecord].fPower);
		else if (nField == MCPhyLine_Rerr)		sprintf(szValue, "%f", m_LineArray[nRecord].fRerr);
		else if (nField == MCPhyLine_Trep)		sprintf(szValue, "%f", m_LineArray[nRecord].fTrep);
		else if (nField == MCPhyLine_Rchk)		sprintf(szValue, "%f", m_LineArray[nRecord].fRchk);
		else if (nField == MCPhyLine_Tchk)		sprintf(szValue, "%f", m_LineArray[nRecord].fTchk);
		else if (nField == MCPhyLine_Topr)		sprintf(szValue, "%f", m_LineArray[nRecord].fTopr);
		else if (nField == MCPhyLine_Invest)	sprintf(szValue, "%f", m_LineArray[nRecord].fInvest);
	}

	return szValue;
}

std::string	CMCRPhyData::GetPhyTranData(const int nField, const int nRecord)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);

	if (nRecord >= 0 && nRecord < (int)m_TranArray.size())
	{
		if (nField == MCPhyTran_NodeI)			strcpy(szValue, m_TranArray[nRecord].strNodeI.c_str());
		else if (nField == MCPhyTran_NodeJ)		strcpy(szValue, m_TranArray[nRecord].strNodeJ.c_str());
		else if (nField == MCPhyTran_Sub)		strcpy(szValue, m_TranArray[nRecord].strSub.c_str());
		else if (nField == MCPhyTran_VoltI)		strcpy(szValue, m_TranArray[nRecord].strVoltI.c_str());
		else if (nField == MCPhyTran_VoltJ)		strcpy(szValue, m_TranArray[nRecord].strVoltJ.c_str());
		else if (nField == MCPhyTran_Name)		strcpy(szValue, m_TranArray[nRecord].strName.c_str());
		else if (nField == MCPhyTran_Type)		sprintf(szValue, "%d", m_TranArray[nRecord].nType);
		else if (nField == MCPhyTran_Power)		sprintf(szValue, "%f", m_TranArray[nRecord].fPower);
		else if (nField == MCPhyTran_Rerr)		sprintf(szValue, "%f", m_TranArray[nRecord].fRerr);
		else if (nField == MCPhyTran_Trep)		sprintf(szValue, "%f", m_TranArray[nRecord].fTrep);
		else if (nField == MCPhyTran_Rchk)		sprintf(szValue, "%f", m_TranArray[nRecord].fRchk);
		else if (nField == MCPhyTran_Tchk)		sprintf(szValue, "%f", m_TranArray[nRecord].fTchk);
		else if (nField == MCPhyTran_Topr)		sprintf(szValue, "%f", m_TranArray[nRecord].fTopr);
		else if (nField == MCPhyTran_Invest)	sprintf(szValue, "%f", m_TranArray[nRecord].fInvest);
	}

	return szValue;
}

std::string	CMCRPhyData::GetPhyScapData(const int nField, const int nRecord)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);

	if (nRecord >= 0 && nRecord < (int)m_ScapArray.size())
	{
		if (nField == MCPhyScap_NodeI)			strcpy(szValue, m_ScapArray[nRecord].strNodeI.c_str());
		else if (nField == MCPhyScap_NodeJ)		strcpy(szValue, m_ScapArray[nRecord].strNodeJ.c_str());
		else if (nField == MCPhyScap_Sub)		strcpy(szValue, m_ScapArray[nRecord].strSub.c_str());
		else if (nField == MCPhyScap_Volt)		strcpy(szValue, m_ScapArray[nRecord].strVolt.c_str());
		else if (nField == MCPhyScap_Name)		strcpy(szValue, m_ScapArray[nRecord].strName.c_str());
		else if (nField == MCPhyScap_Rerr)		sprintf(szValue, "%f", m_ScapArray[nRecord].fRerr);
		else if (nField == MCPhyScap_Trep)		sprintf(szValue, "%f", m_ScapArray[nRecord].fTrep);
		else if (nField == MCPhyScap_Rchk)		sprintf(szValue, "%f", m_ScapArray[nRecord].fRchk);
		else if (nField == MCPhyScap_Tchk)		sprintf(szValue, "%f", m_ScapArray[nRecord].fTchk);
		else if (nField == MCPhyScap_Topr)		sprintf(szValue, "%f", m_ScapArray[nRecord].fTopr);
		else if (nField == MCPhyScap_Invest)	sprintf(szValue, "%f", m_ScapArray[nRecord].fInvest);
	}

	return szValue;
}

std::string	CMCRPhyData::GetPhyBreakerData(const int nField, const int nRecord)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);

	if (nRecord >= 0 && nRecord < (int)m_BreakerArray.size())
	{
		if (nField == MCPhyBreaker_NodeI)			strcpy(szValue, m_BreakerArray[nRecord].strNodeI.c_str());
		else if (nField == MCPhyBreaker_NodeJ)		strcpy(szValue, m_BreakerArray[nRecord].strNodeJ.c_str());
		else if (nField == MCPhyBreaker_Sub)		strcpy(szValue, m_BreakerArray[nRecord].strSub.c_str());
		else if (nField == MCPhyBreaker_Volt)		strcpy(szValue, m_BreakerArray[nRecord].strVolt.c_str());
		else if (nField == MCPhyBreaker_Name)		strcpy(szValue, m_BreakerArray[nRecord].strName.c_str());
		else if (nField == MCPhyBreaker_CTLoc)		sprintf(szValue, "%d", m_BreakerArray[nRecord].nCTLoc);
		else if (nField == MCPhyBreaker_Type)		sprintf(szValue, "%d", m_BreakerArray[nRecord].nType);
		else if (nField == MCPhyBreaker_Status)		sprintf(szValue, "%d", m_BreakerArray[nRecord].nStatus);
		else if (nField == MCPhyBreaker_Rerr)		sprintf(szValue, "%f", m_BreakerArray[nRecord].fRerr);
		else if (nField == MCPhyBreaker_Trep)		sprintf(szValue, "%f", m_BreakerArray[nRecord].fTrep);
		else if (nField == MCPhyBreaker_Rchk)		sprintf(szValue, "%f", m_BreakerArray[nRecord].fRchk);
		else if (nField == MCPhyBreaker_Tchk)		sprintf(szValue, "%f", m_BreakerArray[nRecord].fTchk);
		else if (nField == MCPhyBreaker_Topr)		sprintf(szValue, "%f", m_BreakerArray[nRecord].fTopr);
		else if (nField == MCPhyBreaker_TSwitch)	sprintf(szValue, "%f", m_BreakerArray[nRecord].fTSwitch);
		else if (nField == MCPhyBreaker_Invest)		sprintf(szValue, "%f", m_BreakerArray[nRecord].fInvest);
	}

	return szValue;
}

std::string	CMCRPhyData::GetPhyDisconnectorData(const int nField, const int nRecord)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);

	if (nRecord >= 0 && nRecord < (int)m_DisconnectorArray.size())
	{
		if (nField == MCPhyDisconnector_NodeI)			strcpy(szValue, m_DisconnectorArray[nRecord].strNodeI.c_str());
		else if (nField == MCPhyDisconnector_NodeJ)		strcpy(szValue, m_DisconnectorArray[nRecord].strNodeJ.c_str());
		else if (nField == MCPhyDisconnector_Sub)		strcpy(szValue, m_DisconnectorArray[nRecord].strSub.c_str());
		else if (nField == MCPhyDisconnector_Volt)		strcpy(szValue, m_DisconnectorArray[nRecord].strVolt.c_str());
		else if (nField == MCPhyDisconnector_Name)		strcpy(szValue, m_DisconnectorArray[nRecord].strName.c_str());
		else if (nField == MCPhyDisconnector_Type)		sprintf(szValue, "%d", m_DisconnectorArray[nRecord].nType);
		else if (nField == MCPhyDisconnector_Status)	sprintf(szValue, "%d", m_DisconnectorArray[nRecord].nStatus);
		else if (nField == MCPhyDisconnector_Rerr)		sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fRerr);
		else if (nField == MCPhyDisconnector_Trep)		sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fTrep);
		else if (nField == MCPhyDisconnector_Rchk)		sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fRchk);
		else if (nField == MCPhyDisconnector_Tchk)		sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fTchk);
		else if (nField == MCPhyDisconnector_Topr)		sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fTopr);
		else if (nField == MCPhyDisconnector_TSwitch)	sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fTSwitch);
		else if (nField == MCPhyDisconnector_Invest)	sprintf(szValue, "%f", m_DisconnectorArray[nRecord].fInvest);
	}

	return szValue;
}

void CMCRPhyData::SetPhyDataValue(const int nTable, const int nField, const int nRecord, const char* lpszValue)
{
	switch (nTable)
	{
	case	PG_BUSBARSECTION:
		if (nRecord >= 0 && nRecord < (int)m_BusArray.size())
			SetPhyBusData(nField, nRecord, lpszValue);
		break;
	case	PG_ACLINESEGMENT:
		if (nRecord >= 0 && nRecord < (int)m_LineArray.size())
			SetPhyLineData(nField, nRecord, lpszValue);
		break;
	case	PG_TRANSFORMERWINDING:
		if (nRecord >= 0 && nRecord < (int)m_TranArray.size())
			SetPhyTranData(nField, nRecord, lpszValue);
		break;
	case	PG_SERIESCOMPENSATOR:
		if (nRecord >= 0 && nRecord < (int)m_ScapArray.size())
			SetPhyScapData(nField, nRecord, lpszValue);
		break;
	case	PG_BREAKER:
		if (nRecord >= 0 && nRecord < (int)m_BreakerArray.size())
			SetPhyBreakerData(nField, nRecord, lpszValue);
		break;
	case	PG_DISCONNECTOR:
		if (nRecord >= 0 && nRecord < (int)m_DisconnectorArray.size())
			SetPhyDisconnectorData(nField, nRecord, lpszValue);
		break;
	}
}
void CMCRPhyData::SetPhyBusData(const int nField, const int nRecord, const char* lpszValue)
{
	if (nRecord >= 0 && nRecord < (int)m_BusArray.size())
		SetPhyBusData(&m_BusArray[nRecord], nField, lpszValue);
}

void CMCRPhyData::SetPhyLineData(const int nField, const int nRecord, const char* lpszValue)
{
	if (nRecord >= 0 && nRecord < (int)m_LineArray.size())
		SetPhyLineData(&m_LineArray[nRecord], nField, lpszValue);
}

void CMCRPhyData::SetPhyTranData(const int nField, const int nRecord, const char* lpszValue)
{
	if (nRecord >= 0 && nRecord < (int)m_TranArray.size())
		SetPhyTranData(&m_TranArray[nRecord], nField, lpszValue);
}

void CMCRPhyData::SetPhyScapData(const int nField, const int nRecord, const char* lpszValue)
{
	if (nRecord >= 0 && nRecord < (int)m_ScapArray.size())
		SetPhyScapData(&m_ScapArray[nRecord], nField, lpszValue);
}

void CMCRPhyData::SetPhyBreakerData(const int nField, const int nRecord, const char* lpszValue)
{
	if (nRecord >= 0 && nRecord < (int)m_BreakerArray.size())
		SetPhyBreakerData(&m_BreakerArray[nRecord], nField, lpszValue);
}

void CMCRPhyData::SetPhyDisconnectorData(const int nField, const int nRecord, const char* lpszValue)
{
	if (nRecord >= 0 && nRecord < (int)m_DisconnectorArray.size())
		SetPhyDisconnectorData(&m_DisconnectorArray[nRecord], nField, lpszValue);
}

void CMCRPhyData::SetPhyBusData(tagMCRPhyBus* pMCBus, const int nField, const char* lpszValue)
{
	if (nField == MCPhyBus_Node)		pMCBus->strNode = lpszValue;
	else if (nField == MCPhyBus_Sub)	pMCBus->strSub = lpszValue;
	else if (nField == MCPhyBus_Volt)	pMCBus->strVolt = lpszValue;
	else if (nField == MCPhyBus_Name)	pMCBus->strName = lpszValue;
	else if (nField == MCPhyBus_ByPass)	pMCBus->bByPass = atoi(lpszValue);
	else if (nField == MCPhyBus_Rerr)	pMCBus->fRerr = atof(lpszValue);
	else if (nField == MCPhyBus_Trep)	pMCBus->fTrep = atof(lpszValue);
	else if (nField == MCPhyBus_Rchk)	pMCBus->fRchk = atof(lpszValue);
	else if (nField == MCPhyBus_Tchk)	pMCBus->fTchk = atof(lpszValue);
	else if (nField == MCPhyBus_Topr)	pMCBus->fTopr = atof(lpszValue);
	else if (nField == MCPhyBus_Invest)	pMCBus->fInvest = atof(lpszValue);
}

void CMCRPhyData::SetPhyLineData(tagMCRPhyLine* pMCLine, const int nField, const char* lpszValue)
{
	if (nField == MCPhyLine_NodeI)			pMCLine->strNodeI = lpszValue;
	else if (nField == MCPhyLine_NodeJ)		pMCLine->strNodeJ = lpszValue;
	else if (nField == MCPhyLine_SubI)		pMCLine->strSubI = lpszValue;
	else if (nField == MCPhyLine_SubJ)		pMCLine->strSubJ = lpszValue;
	else if (nField == MCPhyLine_Volt)		pMCLine->strVolt = lpszValue;
	else if (nField == MCPhyLine_Name)		pMCLine->strName = lpszValue;
	else if (nField == MCPhyLine_Type)		pMCLine->nType = atoi(lpszValue);
	else if (nField == MCPhyLine_Length)	pMCLine->fLength = atof(lpszValue);
	else if (nField == MCPhyLine_Power)		pMCLine->fPower = atof(lpszValue);
	else if (nField == MCPhyLine_Rerr)		pMCLine->fRerr = atof(lpszValue);
	else if (nField == MCPhyLine_Trep)		pMCLine->fTrep = atof(lpszValue);
	else if (nField == MCPhyLine_Rchk)		pMCLine->fRchk = atof(lpszValue);
	else if (nField == MCPhyLine_Tchk)		pMCLine->fTchk = atof(lpszValue);
	else if (nField == MCPhyLine_Topr)		pMCLine->fTopr = atof(lpszValue);
	else if (nField == MCPhyLine_Invest)	pMCLine->fInvest = atof(lpszValue);
}

void CMCRPhyData::SetPhyTranData(tagMCRPhyTran* pMCTran, const int nField, const char* lpszValue)
{
	if (nField == MCPhyTran_NodeI)			pMCTran->strNodeI = lpszValue;
	else if (nField == MCPhyTran_NodeJ)		pMCTran->strNodeJ = lpszValue;
	else if (nField == MCPhyTran_Sub)		pMCTran->strSub = lpszValue;
	else if (nField == MCPhyTran_VoltI)		pMCTran->strVoltI = lpszValue;
	else if (nField == MCPhyTran_VoltJ)		pMCTran->strVoltJ = lpszValue;
	else if (nField == MCPhyTran_Name)		pMCTran->strName = lpszValue;
	else if (nField == MCPhyTran_Type)		pMCTran->nType = atoi(lpszValue);
	else if (nField == MCPhyTran_Power)		pMCTran->fPower = atof(lpszValue);
	else if (nField == MCPhyTran_Rerr)		pMCTran->fRerr = atof(lpszValue);
	else if (nField == MCPhyTran_Trep)		pMCTran->fTrep = atof(lpszValue);
	else if (nField == MCPhyTran_Rchk)		pMCTran->fRchk = atof(lpszValue);
	else if (nField == MCPhyTran_Tchk)		pMCTran->fTchk = atof(lpszValue);
	else if (nField == MCPhyTran_Topr)		pMCTran->fTopr = atof(lpszValue);
	else if (nField == MCPhyTran_Invest)	pMCTran->fInvest = atof(lpszValue);
}

void CMCRPhyData::SetPhyScapData(tagMCRPhyScap* pMCScap, const int nField, const char* lpszValue)
{
	if (nField == MCPhyScap_NodeI)			pMCScap->strNodeI = lpszValue;
	else if (nField == MCPhyScap_NodeJ)		pMCScap->strNodeJ = lpszValue;
	else if (nField == MCPhyScap_Sub)		pMCScap->strSub = lpszValue;
	else if (nField == MCPhyScap_Volt)		pMCScap->strVolt = lpszValue;
	else if (nField == MCPhyScap_Name)		pMCScap->strName = lpszValue;
	else if (nField == MCPhyScap_Rerr)		pMCScap->fRerr = atof(lpszValue);
	else if (nField == MCPhyScap_Trep)		pMCScap->fTrep = atof(lpszValue);
	else if (nField == MCPhyScap_Rchk)		pMCScap->fRchk = atof(lpszValue);
	else if (nField == MCPhyScap_Tchk)		pMCScap->fTchk = atof(lpszValue);
	else if (nField == MCPhyScap_Topr)		pMCScap->fTopr = atof(lpszValue);
	else if (nField == MCPhyScap_Invest)	pMCScap->fInvest = atof(lpszValue);
}

void CMCRPhyData::SetPhyBreakerData(tagMCRPhyBreaker* pMCBreaker, const int nField, const char* lpszValue)
{
	if (nField == MCPhyBreaker_NodeI)			pMCBreaker->strNodeI = lpszValue;
	else if (nField == MCPhyBreaker_NodeJ)		pMCBreaker->strNodeJ = lpszValue;
	else if (nField == MCPhyBreaker_Sub)		pMCBreaker->strSub = lpszValue;
	else if (nField == MCPhyBreaker_Volt)		pMCBreaker->strVolt = lpszValue;
	else if (nField == MCPhyBreaker_Name)		pMCBreaker->strName = lpszValue;
	else if (nField == MCPhyBreaker_CTLoc)		pMCBreaker->nCTLoc = atoi(lpszValue);
	else if (nField == MCPhyBreaker_Type)		pMCBreaker->nType = atoi(lpszValue);
	else if (nField == MCPhyBreaker_Status)		pMCBreaker->nStatus = atoi(lpszValue);
	else if (nField == MCPhyBreaker_Rerr)		pMCBreaker->fRerr = atof(lpszValue);
	else if (nField == MCPhyBreaker_Trep)		pMCBreaker->fTrep = atof(lpszValue);
	else if (nField == MCPhyBreaker_Rchk)		pMCBreaker->fRchk = atof(lpszValue);
	else if (nField == MCPhyBreaker_Tchk)		pMCBreaker->fTchk = atof(lpszValue);
	else if (nField == MCPhyBreaker_Topr)		pMCBreaker->fTopr = atof(lpszValue);
	else if (nField == MCPhyBreaker_TSwitch)	pMCBreaker->fTSwitch = atof(lpszValue);
	else if (nField == MCPhyBreaker_Invest)		pMCBreaker->fInvest = atof(lpszValue);
}

void CMCRPhyData::SetPhyDisconnectorData(tagMCRPhyDisconnector* pMCDisconnector, const int nField, const char* lpszValue)
{
	if (nField == MCPhyDisconnector_NodeI)			pMCDisconnector->strNodeI = lpszValue;
	else if (nField == MCPhyDisconnector_NodeJ)		pMCDisconnector->strNodeJ = lpszValue;
	else if (nField == MCPhyDisconnector_Sub)		pMCDisconnector->strSub = lpszValue;
	else if (nField == MCPhyDisconnector_Volt)		pMCDisconnector->strVolt = lpszValue;
	else if (nField == MCPhyDisconnector_Name)		pMCDisconnector->strName = lpszValue;
	else if (nField == MCPhyDisconnector_Type)		pMCDisconnector->nType = atoi(lpszValue);
	else if (nField == MCPhyDisconnector_Status)	pMCDisconnector->nStatus = atoi(lpszValue);
	else if (nField == MCPhyDisconnector_Rerr)		pMCDisconnector->fRerr = atof(lpszValue);
	else if (nField == MCPhyDisconnector_Trep)		pMCDisconnector->fTrep = atof(lpszValue);
	else if (nField == MCPhyDisconnector_Rchk)		pMCDisconnector->fRchk = atof(lpszValue);
	else if (nField == MCPhyDisconnector_Tchk)		pMCDisconnector->fTchk = atof(lpszValue);
	else if (nField == MCPhyDisconnector_Topr)		pMCDisconnector->fTopr = atof(lpszValue);
	else if (nField == MCPhyDisconnector_TSwitch)	pMCDisconnector->fTSwitch = atof(lpszValue);
	else if (nField == MCPhyDisconnector_Invest)	pMCDisconnector->fInvest = atof(lpszValue);
}
