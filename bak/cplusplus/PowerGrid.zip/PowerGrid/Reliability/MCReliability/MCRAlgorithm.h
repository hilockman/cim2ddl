#pragma once

#include "MCRCommon.h"

#include "MCRPhyData.h"
#include "MCRPerturb.h"
#include "MCRAlgDisJoint.h"
#include "MCRAlgDataDefine.h"

#include "../../../Common/TinyXML/tinyxml.h"

const	double	g_fMininalValue=1e-10;

class CMCRAlgorithm
{
public:
	CMCRAlgorithm(void);
	~CMCRAlgorithm(void);

//////////////////////////////////////////////////////////////////////////
//	�ɿ��Լ���ģ�ͣ����ݶ���ͷ���
public:
	int		m_nMaxPhyNode;
	std::vector<tagMCRAlgGen>			m_GenArray;
	std::vector<tagMCRAlgLoad>			m_LoadArray;
	std::vector<tagMCRAlgComp>			m_CompArray;
	std::vector<tagMCRAlgNode>			m_NodeArray;

	tagMCRAlgLoad	m_AugLoad;
	tagMCRAlgGen	m_AugGen;
	std::vector<tagMCRAlgComp>	m_AugLoadCompArray;
	std::vector<tagMCRAlgComp>	m_AugGenCompArray;

	void	CloneAlgData(CMCRAlgorithm* pClone)
	{
		m_nMaxPhyNode = pClone->m_nMaxPhyNode;
		m_GenArray .assign(pClone->m_GenArray.begin(),  pClone->m_GenArray.end());
		m_LoadArray.assign(pClone->m_LoadArray.begin(), pClone->m_LoadArray.end());
		m_CompArray.assign(pClone->m_CompArray.begin(), pClone->m_CompArray.end());
		m_NodeArray.assign(pClone->m_NodeArray.begin(), pClone->m_NodeArray.end());

		memcpy(&m_AugLoad, &pClone->m_AugLoad, sizeof(tagMCRAlgLoad));
		memcpy(&m_AugGen, &pClone->m_AugGen, sizeof(tagMCRAlgGen));
		m_AugLoadCompArray.assign(pClone->m_AugLoadCompArray.begin(), pClone->m_AugLoadCompArray.end());
		m_AugGenCompArray.assign(pClone->m_AugGenCompArray.begin(), pClone->m_AugGenCompArray.end());
	}

public:
	int		ReadData(CMCRPhyData* pPhy, const char* lpszModelFileName);
	void	SaveMCReilabilityModel(const char* lpszFileName);

private:
	void	ReadData_Gen(CMCRPhyData* pPhy);
	void	ReadData_Load(CMCRPhyData* pPhy);
	int		ReadData_Node(CMCRPhyData* pPhy);
	void	ReadData_Comp(CMCRPhyData* pPhy);
	//void	ReadData_Switch(CMCRPhyData* pPhy);
	void	ReadData_Comm();
	void	ReadData_CheckFCut();

private:
	void	InitializeAlgNode(tagMCRAlgNode* pData);
	void	InitializeAlgComp(tagMCRAlgComp* pData);
	void	InitializeAlgLoad(tagMCRAlgLoad* pData);
	void	InitializeAlgGen(tagMCRAlgGen* pData);

private:
	void	AddUniqueComm(std::vector<tagMCRAlgComm>& nCompArray, tagMCRAlgComm& sCommBuffer);
	void	AddUniqueInteger(std::vector<int>& nIntegerArray, const int nInteger);
	int		SeekBreakerComm(const int nBreaker, const int nCheckComp);

private:
	void	AlgTopo();
	void	AlgTraverse(const int nIniAlgNode, const int nBoundNodeType, const unsigned char bCheckStatus, std::vector<int>& nRgnNodeArray);
	void	AlgTraverseDirection(const int nIniAlgNode, const unsigned char bCheckStatus, const unsigned char bPosDirection, std::vector<int>& nRgnNodeArray);

//////////////////////////////////////////////////////////////////////////
//	�ɿ��Լ���ʹ�ã����ݶ���ͷ���
private:
	std::vector<tagMCRAlgCompBackup>	m_CompBackArray;		//	�������ⲿ���صı�������
	//	���㹤���ռ�
	std::vector<tagMCRAlgPath>		m_MinPathArray;		//	��С·
	std::vector<tagMCRAlgMinCut1>	m_MinCut1Array;		//	һ����С��
	std::vector<tagMCRAlgMinCut2>	m_MinCut2Array;		//	������С��
	std::vector<tagMCRAlgMinCut3>	m_MinCut3Array;		//	������С��
	std::vector<tagMCRCmMinCut1>	m_CmMCut1Array;		//	һ�׹��Ϲ�ģ�滻��С��
	std::vector<tagMCRCmMinCut2>	m_CmMCut2Array;		//	���׹��Ϲ�ģ�滻��С��


public:
	void	CalculateAllLoadReliablity(const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure);
	void	CalculateAllGenReliablity(const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure);
	void	CalculateLoadReliability(CMCRPhyData* pPhyData, const int nAlgLoad, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure);
	void	CalculateGenReliability (CMCRPhyData* pPhyData, const int nAlgGen, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure);
	void	CalculateAugLoadReliablity(CMCRPhyData* pPhyData, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure);
	void	CalculateAugGenReliablity (CMCRPhyData* pPhyData, const unsigned char bFCutPlan, const unsigned char bExcludeCommon, const unsigned char bExcludeSwitch, const unsigned char bBreakerFaultFailure);

private:
	void	FormNormalMinPath(const int nAlgNode, const unsigned char nPathOrient, std::vector<tagMCRAlgPath>& minPathArray);
	//void	FormSwitchMinPathOld(const int nAlgNode, const unsigned char nPathOrient, std::vector<tagMCRAlgPath>& minPathArray);
	void	FormSwitchMinPath(const int nAlgNode, const unsigned char nPathOrient, std::vector<tagMCRAlgPath>& minPathArray);
	void	FormNormalShortCut();
	void	ParallelShortcut(const unsigned char bFCutPlan);
	void	SeriesShortcut(tagMCRAlgResult* pResult);
	void	CompContribution(const double fPower);

private:
	void	FormMCut01Switch(const int nRouterComp, const int nSwitchComp);
	void	FormMCut02Switch(const int nRouterComp1, const int nRouterComp2, const int nSwitchComp);
	void	FormMCut03Switch(const int nRouterComp1, const int nRouterComp2, const int nRouterComp3, const int nSwitchComp);
	void	FormSwitchShortCut(std::vector<tagMCRAlgPath>& sMinPathArray);
	void	FormCommonShortcut(const unsigned char bBreakerFaultFailure);
	void	FormDegreeShortCut(const unsigned char bBreakerFaultFailure);
	void	EraseDegreeShortCut();
	void	FormDegreeShortcutBreakerCm(const int nMCut, const int nFCmBreaker1, const int nFCmBreaker2, const int nFCmBreaker3);
	void	FormDegreeShortcutBreakerCm3To2(const int nMCut, const int nFCmBreaker1, const int nFCmBreaker2, const int nComp);
	void	FormDegreeShortcut3BreakerTo1(const int nMCut, const int nBreaker1, const int nBreaker2, const int nBreaker3);
	void	FormDegreeShortcut3BreakerTo2(const int nMCut, const int nBreaker1, const int nBreaker2, const int nBreaker3);
	void	FormDegreeShortcut3To1(const int nMCut, const int nFCmBreaker1, const int nFCmBreaker2, const int nComp);
	void	FormDegreeShortcut3To2(const int nMCut, const int nFCmBreaker, const int nComp1, const int nComp2);

private:
	int		SeekMCut01(std::vector<tagMCRAlgMinCut1>& sCutArray, const int nComp);
	int		SeekMCut02(std::vector<tagMCRAlgMinCut2>& sCutArray, const int nComp1, const int nComp2);
	int		SeekMCut03(std::vector<tagMCRAlgMinCut3>& sCutArray, const int nComp1, const int nComp2, const int nComp3);
	int		SeekMCut04(std::vector<tagMCRAlgMinCut4>& sCutArray, const int nComp1, const int nComp2, const int nComp3, const int nComp4);

	int		SeekCommMCut01(std::vector<tagMCRCmMinCut1>& sCmMCutO1Array, const int nComp);
	int		SeekCommMCut02(std::vector<tagMCRCmMinCut2>& sCmMCutO2Array, const int nComp1, const int nComp2);

	int		isShortCut01(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp);
	int		isShortCut02(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp1, const int nComp2);
	int		isShortCut03(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp1, const int nComp2, const int nComp3);
	int		isShortCut04(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp1, const int nComp2, const int nComp3, const int nComp4);
	//int		isSwitchPair(const int nComp1, const int nComp2);


public:
	void	Alg2PhyLoad(CMCRPhyData* pPhyData, const unsigned char bAugLoad, const int nAlgLoad, const double fRCTime);
	void	Alg2PhyGen (CMCRPhyData* pPhyData, const unsigned char bAugGen, const int nAlgGen, const double fRCTime);

private:
	void	Alg2PhyResult(tagMCRAlgResult* pAlg, tagMCRPhyResult* pPhy);
	void	Alg2PlyMCut(const double fR, const double fU, std::vector<tagMCRPhyPath>& sMinPathArray, std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array);

public:
	void	InitPerturb();
	void	PerturbAmend(const int nPerturb);
	void	PerturbRestore();

private:
	CMCRAlgDisJoint	m_DisJoint;
};

extern	CMCRPhyData		g_MCRPhyData;
extern	CMCRPerturb		g_MCRPerturb;
extern	const	char*	g_lpszLogFile;
extern	void	Log(const char* lpszLogFile, char* pformat, ...);

extern	void	PrintMessage(const char* pformat, ...);
