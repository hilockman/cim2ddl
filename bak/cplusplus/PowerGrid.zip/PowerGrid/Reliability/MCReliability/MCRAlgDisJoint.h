#pragma once

#include "MCRAlgDataDefine.h"

class CMCRAlgDisJoint
{
public:
	CMCRAlgDisJoint(void);
	~CMCRAlgDisJoint(void);

public:
	int		DisJoint_Init(const int nIniAlgNode, const unsigned char bPosDirection, const unsigned char bCheckStatus, IN std::vector<tagMCRAlgNode>& sNodeArray, IN std::vector<tagMCRAlgComp>& sCompArray, std::vector<int>& nRangeNodeArray);
	void	DisJoint_Calc(const int nEndAlgNode, std::vector<int>& nRangeNodeArray);
	void	DisJoint2MinPath(IN std::vector<tagMCRAlgNode>& sNodeArray, IN std::vector<tagMCRAlgComp>& sCompArray, std::vector<int>& nRangeNodeArray, std::vector<tagMCRAlgPath>& sMinPathArray);

private:
	int		GetVw(int);

	int m_nMaxRoad;

	int m_nBusNum;
	int m_nIniBus;
	int m_nEndBus;
	std::vector<int>	m_nChkVector;
	std::vector<int>	m_nPosVector;
	std::vector< std::vector<int> > m_RouteMatrix;
	std::vector< std::vector<int> >	m_DisjointNodeMatrix;
};
