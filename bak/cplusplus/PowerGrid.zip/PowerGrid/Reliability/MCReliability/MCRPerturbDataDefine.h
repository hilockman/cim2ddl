#pragma once

const	int	g_nConstMaxReliabilityPerturb	= 10;
typedef	struct _MCRPerturbParam
{
	unsigned char	nPerturbType;	//	=0������=1��˫��
	short			nPerturbNum;

	double		fBusRerrPerturb;
	double		fBusTrepPerturb;
	double		fBusRchkPerturb;
	double		fBusTchkPerturb;

	double		fLineRerrPerturb;
	double		fLineTrepPerturb;
	double		fLineRchkPerturb;
	double		fLineTchkPerturb;

	double		fTranRerrPerturb;
	double		fTranTrepPerturb;
	double		fTranRchkPerturb;
	double		fTranTchkPerturb;

	double		fScapRerrPerturb;
	double		fScapTrepPerturb;
	double		fScapRchkPerturb;
	double		fScapTchkPerturb;

	double		fBreakerRerrPerturb;
	double		fBreakerTrepPerturb;
	double		fBreakerRchkPerturb;
	double		fBreakerTchkPerturb;
	double		fBreakerToprPerturb;

	double		fDisconnectorRerrPerturb;
	double		fDisconnectorTrepPerturb;
	double		fDisconnectorRchkPerturb;
	double		fDisconnectorTchkPerturb;
	double		fDisconnectorToprPerturb;
	double		fDisconnectorTSwitchPerturb;
}	tagMCRPerturbParam;
