#include "StdAfx.h"
#include "MCRPerturb.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

CMCRPerturb::CMCRPerturb(void)
{
	memset(&m_Param, 0, sizeof(tagMCRPerturbParam));
	m_Param.nPerturbNum = 5;
}

CMCRPerturb::~CMCRPerturb(void)
{
}


int CMCRPerturb::ReadParamFile(const char* lpszFileName)
{
	memset(&m_Param, 0, sizeof(tagMCRPerturbParam));

	TiXmlElement*	pLine;
	TiXmlDocument	doc(lpszFileName);
	if (!doc.LoadFile())
	{
		return 0;
	}

	TiXmlAttribute*	pAttr;
	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "MCRPerturbParam") != 0)
	{
		doc.Clear();
		return 0;
	}

	// Traverse children of pRoot, populating the list of lines
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), "Base") == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Type") == 0)		m_Param.nPerturbType = atoi(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Num") == 0)	m_Param.nPerturbNum = atoi(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_BUSBARSECTION)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_BUSBARSECTION)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_Param.fBusRerrPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_Param.fBusTrepPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_Param.fBusRchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_Param.fBusTchkPerturb = atof(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_ACLINESEGMENT)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_ACLINESEGMENT)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_Param.fLineRerrPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_Param.fLineTrepPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_Param.fLineRchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_Param.fLineTchkPerturb = atof(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_TRANSFORMERWINDING)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_TRANSFORMERWINDING)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_Param.fTranRerrPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_Param.fTranTrepPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_Param.fTranRchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_Param.fTranTchkPerturb = atof(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_SERIESCOMPENSATOR)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_SERIESCOMPENSATOR)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_Param.fScapRerrPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_Param.fScapTrepPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_Param.fScapRchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_Param.fScapTchkPerturb = atof(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_BREAKER)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_BREAKER)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)		m_Param.fBreakerRerrPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)	m_Param.fBreakerTrepPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)	m_Param.fBreakerRchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)	m_Param.fBreakerTchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)	m_Param.fBreakerToprPerturb = atof(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), PGGetTableName(PG_DISCONNECTOR)) == 0 || stricmp(pLine->Value(), PGGetTableDesp(PG_DISCONNECTOR)) == 0)
		{
			pAttr=pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp(pAttr->Name(), "Rerr") == 0)			m_Param.fDisconnectorRerrPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Trep") == 0)		m_Param.fDisconnectorTrepPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Rchk") == 0)		m_Param.fDisconnectorRchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Tchk") == 0)		m_Param.fDisconnectorTchkPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "Topr") == 0)		m_Param.fDisconnectorToprPerturb = atof(pAttr->Value());
				else if (stricmp(pAttr->Name(), "TSwitch") == 0)	m_Param.fDisconnectorTSwitchPerturb = atof(pAttr->Value());

				pAttr=pAttr->Next();
			}
		}

		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();

	return 1;
}

void CMCRPerturb::SaveParamFile(const char* lpszFileName)
{
	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement		*pRootElement, *pTableElement;

	pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("MCRPerturbParam");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);


	pTableElement = new TiXmlElement("Base");
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetAttribute("Type",	m_Param.nPerturbType);
	pTableElement->SetAttribute("Num",	m_Param.nPerturbNum);

	//////////////////////////////////////////////////////////////////////////
	//	Bus
	pTableElement = new TiXmlElement(PGGetTableName(PG_BUSBARSECTION));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_Param.fBusRerrPerturb);
	pTableElement->SetDoubleAttribute("Trep",	m_Param.fBusTrepPerturb);
	pTableElement->SetDoubleAttribute("Rchk",	m_Param.fBusRchkPerturb);
	pTableElement->SetDoubleAttribute("Tchk",	m_Param.fBusTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Line
	pTableElement = new TiXmlElement(PGGetTableName(PG_ACLINESEGMENT));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_Param.fLineRerrPerturb);
	pTableElement->SetDoubleAttribute("Trep",	m_Param.fLineTrepPerturb);
	pTableElement->SetDoubleAttribute("Rchk",	m_Param.fLineRchkPerturb);
	pTableElement->SetDoubleAttribute("Tchk",	m_Param.fLineTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Tran
	pTableElement = new TiXmlElement(PGGetTableName(PG_TRANSFORMERWINDING));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_Param.fTranRerrPerturb);
	pTableElement->SetDoubleAttribute("Trep",	m_Param.fTranTrepPerturb);
	pTableElement->SetDoubleAttribute("Rchk",	m_Param.fTranRchkPerturb);
	pTableElement->SetDoubleAttribute("Tchk",	m_Param.fTranTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Scap
	pTableElement = new TiXmlElement(PGGetTableName(PG_SERIESCOMPENSATOR));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_Param.fScapRerrPerturb);
	pTableElement->SetDoubleAttribute("Trep",	m_Param.fScapTrepPerturb);
	pTableElement->SetDoubleAttribute("Rchk",	m_Param.fScapRchkPerturb);
	pTableElement->SetDoubleAttribute("Tchk",	m_Param.fScapTchkPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Breaker
	pTableElement = new TiXmlElement(PGGetTableName(PG_BREAKER));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_Param.fBreakerRerrPerturb);
	pTableElement->SetDoubleAttribute("Trep",	m_Param.fBreakerTrepPerturb);
	pTableElement->SetDoubleAttribute("Rchk",	m_Param.fBreakerRchkPerturb);
	pTableElement->SetDoubleAttribute("Tchk",	m_Param.fBreakerTchkPerturb);
	pTableElement->SetDoubleAttribute("Topr",	m_Param.fBreakerToprPerturb);

	//////////////////////////////////////////////////////////////////////////
	//	Disconnector
	pTableElement = new TiXmlElement(PGGetTableName(PG_DISCONNECTOR));
	pRootElement->LinkEndChild(pTableElement);

	pTableElement->SetDoubleAttribute("Rerr",	m_Param.fDisconnectorRerrPerturb);
	pTableElement->SetDoubleAttribute("Trep",	m_Param.fDisconnectorTrepPerturb);
	pTableElement->SetDoubleAttribute("Rchk",	m_Param.fDisconnectorRchkPerturb);
	pTableElement->SetDoubleAttribute("Tchk",	m_Param.fDisconnectorTchkPerturb);
	pTableElement->SetDoubleAttribute("Topr",	m_Param.fDisconnectorToprPerturb);
	pTableElement->SetDoubleAttribute("TSwitch",m_Param.fDisconnectorTSwitchPerturb);

	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}
