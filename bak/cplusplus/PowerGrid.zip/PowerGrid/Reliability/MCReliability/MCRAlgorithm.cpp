#include "StdAfx.h"
#include "MCRAlgorithm.h"

CMCRAlgorithm::CMCRAlgorithm(void)
{
	m_nMaxPhyNode = 0;
}

CMCRAlgorithm::~CMCRAlgorithm(void)
{
}

void CMCRAlgorithm::AddUniqueInteger(std::vector<int>& nIntegerArray, const int nInteger)
{
	register int	i;
	for (i=0; i<(int)nIntegerArray.size(); i++)
	{
		if (nInteger == nIntegerArray[i])
			return;
	}

	nIntegerArray.push_back(nInteger);
}

void CMCRAlgorithm::InitializeAlgComp(tagMCRAlgComp* pData)
{
	pData->strName.clear();

	pData->nPhyTyp = 0;
	pData->nPhyIdx = 0;
	pData->nIniPhyNode=	0;
	pData->nEndPhyNode=	0;
	pData->nIniAlgNode=	0;
	pData->nEndAlgNode=	0;

	pData->fRerr=0;
	pData->fTrep=0;
	pData->fRchk=0;
	pData->fTchk=0;
	pData->fTopr=0;
	pData->fTSwitch=0;

	pData->fLength=0;
	pData->nStatus=0;
	pData->nDirection=NoDirection;
	pData->bSourceI=0;		//I����Դ
	pData->bSourceJ=0;		//Z����Դ

	//pData->nSwCompArray.clear();
	pData->sCmCompArray.clear();

	pData->bInPath = 0;

	pData->fAccumR=0;
	pData->fAccumU=0;
	pData->fAccumEns=0;

	pData->bFCutPlan = 0;
	pData->bAugComp = 0;
}

void CMCRAlgorithm::InitializeAlgNode(tagMCRAlgNode* pData)
{
	pData->strName.clear();
	pData->nPhyNode		= 0;
	pData->nPhyType	= 0;
	pData->bProc	= 0;
	pData->nCompArray.clear();
	pData->bAugNode = 0;
}

void CMCRAlgorithm::InitializeAlgLoad(tagMCRAlgLoad* pData)
{
	memset(pData->szName, 0, MDB_CHARLEN_LONG);
	pData->nPhyTyp = 0;
	pData->nPhyIdx = 0;
	pData->nPhyNode = 0;
	pData->nAlgNode = 0;
	pData->fLoadP = 0;	

	pData->bAlone = 0;
	pData->bEstimated = 0;

	//	�������ռ�
	memset(&pData->sResult, 0, sizeof(tagMCRAlgResult));
}

void CMCRAlgorithm::InitializeAlgGen(tagMCRAlgGen* pData)
{
	memset(pData->szName, 0, MDB_CHARLEN_LONG);
	pData->nPhyTyp = 0;
	pData->nPhyIdx = 0;
	pData->nPhyNode = 0;
	pData->nAlgNode = 0;
	pData->fOutP = 0;	

	pData->bAlone = 0;
	pData->bEstimated = 0;

	//	�������ռ�
	memset(&pData->sResult, 0, sizeof(tagMCRAlgResult));
}

void CMCRAlgorithm::AlgTopo()
{
	register int	i;
	int		nDev, nFlag;

	for	(nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		m_CompArray[nDev].nIniAlgNode = m_CompArray[nDev].nEndAlgNode = -1;
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (m_CompArray[nDev].nIniPhyNode == m_NodeArray[i].nPhyNode)
				m_CompArray[nDev].nIniAlgNode=i;
			if (m_CompArray[nDev].nEndPhyNode == m_NodeArray[i].nPhyNode)
				m_CompArray[nDev].nEndAlgNode=i;

			if (m_CompArray[nDev].nIniAlgNode >= 0 && m_CompArray[nDev].nEndAlgNode >= 0)
				break;
		}
	}

	for (nDev=0; nDev<(int)m_LoadArray.size(); nDev++)
	{
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (m_LoadArray[nDev].nPhyNode == m_NodeArray[i].nPhyNode)
			{
				m_LoadArray[nDev].nAlgNode=i;
				break;
			}
		}
	}

	for (nDev=0; nDev<(int)m_GenArray.size(); nDev++)
	{
		for	(i=0; i<(int)m_NodeArray.size(); i++)
		{
			if (m_GenArray[nDev].nPhyNode == m_NodeArray[i].nPhyNode)
			{
				m_GenArray[nDev].nAlgNode=i;
				break;
			}
		}
	}

	//	2���γɽڵ���Ϣ��
	for (i=0; i<(int)m_NodeArray.size(); i++)
		m_NodeArray[i].nCompArray.clear();
	for	(nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		if (m_CompArray[nDev].nPhyTyp == PG_SYNCHRONOUSMACHINE || m_CompArray[nDev].nPhyTyp == PG_ENERGYCONSUMER)
			continue;

		m_NodeArray[m_CompArray[nDev].nIniAlgNode].nCompArray.push_back(nDev);
		m_NodeArray[m_CompArray[nDev].nEndAlgNode].nCompArray.push_back(nDev);
	}

	std::vector<int>	nNodeArray;
	for (nDev=0; nDev<(int)m_LoadArray.size(); nDev++)
	{
		m_LoadArray[nDev].bAlone = 0;

		AlgTraverseDirection(m_LoadArray[nDev].nAlgNode, 1, NegDirection, nNodeArray);

		nFlag = 0;
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			if (m_NodeArray[nNodeArray[i]].nPhyType == PG_SYNCHRONOUSMACHINE)
			{
				nFlag = 1;
				break;
			}
		}
		if (!nFlag)
			m_LoadArray[nDev].bAlone = 1;
	}

	for (nDev=0; nDev<(int)m_GenArray.size(); nDev++)
	{
		m_GenArray[nDev].bAlone = 0;

		AlgTraverseDirection(m_GenArray[nDev].nAlgNode, 1, PosDirection, nNodeArray);

		nFlag = 0;
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			if (m_NodeArray[nNodeArray[i]].nPhyType == PG_ENERGYCONSUMER)
			{
				nFlag = 1;
				break;
			}
		}
		if (!nFlag)
			m_GenArray[nDev].bAlone = 1;
	}
}

void CMCRAlgorithm::AlgTraverse(const int nIniAlgNode, const int nBoundNodeType, const unsigned char bCheckStatus, std::vector<int>& nRgnNodeArray)
{
	register int	i, j;
	std::vector<int>	nMidNodeArray;
	std::vector<int>	nSrcNodeArray;
	int	nNode, nDev;
	int	nNodeNumOfLayer;

	nSrcNodeArray.clear();
	nRgnNodeArray.clear();
	for (i=0; i<(int)m_NodeArray.size(); i++)
		m_NodeArray[i].bProc=0;

	nRgnNodeArray.push_back(nIniAlgNode);
	if (m_NodeArray[nIniAlgNode].nPhyType == nBoundNodeType)	return;

	m_NodeArray[nIniAlgNode].bProc=1;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nRgnNodeArray.size(); i++)
		{
			for (j=0; j<(int)m_NodeArray[nRgnNodeArray[i]].nCompArray.size(); j++)
			{
				nDev=m_NodeArray[nRgnNodeArray[i]].nCompArray[j];
				if (m_CompArray[nDev].nPhyTyp == PG_BUSBARSECTION)
					continue;
				if (bCheckStatus && m_CompArray[nDev].nStatus != 0)
					continue;
				if (m_CompArray[nDev].nEndAlgNode == m_CompArray[nDev].nIniAlgNode)
					continue;

				nNode=(nRgnNodeArray[i] == m_CompArray[nDev].nIniAlgNode) ? m_CompArray[nDev].nEndAlgNode : m_CompArray[nDev].nIniAlgNode;
				if (!m_NodeArray[nNode].bProc)
				{
					if (m_NodeArray[nNode].nPhyType == nBoundNodeType)
					{
						nSrcNodeArray.push_back(nNode);
						m_NodeArray[nNode].bProc=1;
					}
					else
					{
						nMidNodeArray.push_back(nNode);
						m_NodeArray[nNode].bProc=1;
					}
				}
			}
		}
		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nRgnNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nRgnNodeArray.push_back(nMidNodeArray[i]);
	}
	for (i=0; i<(int)nSrcNodeArray.size(); i++)
		nRgnNodeArray.push_back(nSrcNodeArray[i]);
}

void CMCRAlgorithm::AlgTraverseDirection(const int nIniAlgNode, const unsigned char bCheckStatus, const unsigned char bPosDirection, std::vector<int>& nRgnNodeArray)
{
	register int	i, j;
	std::vector<int>	nMidNodeArray;
	int	nNode, nDev;
	int	nNodeNumOfLayer;

	nRgnNodeArray.clear();
	for (i=0; i<(int)m_NodeArray.size(); i++)
		m_NodeArray[i].bProc=0;

	nRgnNodeArray.push_back(nIniAlgNode);

	m_NodeArray[nIniAlgNode].bProc=1;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nRgnNodeArray.size(); i++)
		{
			for (j=0; j<(int)m_NodeArray[nRgnNodeArray[i]].nCompArray.size(); j++)
			{
				nDev=m_NodeArray[nRgnNodeArray[i]].nCompArray[j];
				if (m_CompArray[nDev].nPhyTyp == PG_BUSBARSECTION)
					continue;
				if (bCheckStatus && m_CompArray[nDev].nStatus != 0)
					continue;
				if (m_CompArray[nDev].nEndAlgNode == m_CompArray[nDev].nIniAlgNode)
					continue;

				nNode=-1;
				nNode=(nRgnNodeArray[i] == m_CompArray[nDev].nIniAlgNode) ? m_CompArray[nDev].nEndAlgNode : m_CompArray[nDev].nIniAlgNode;

				if (nRgnNodeArray[i] == m_CompArray[nDev].nIniAlgNode)
				{
					if (bPosDirection == PosDirection && m_CompArray[nDev].nDirection == J2IDirection ||	//	��������I-J��������I-J������
						bPosDirection == NegDirection && m_CompArray[nDev].nDirection == I2JDirection)		//	��������J-I��������J-I������
						continue;
				}
				else if (nRgnNodeArray[i] == m_CompArray[nDev].nEndAlgNode)	//	I2J
				{
					if (bPosDirection == PosDirection && m_CompArray[nDev].nDirection == I2JDirection ||
						bPosDirection == NegDirection && m_CompArray[nDev].nDirection == J2IDirection)
						continue;
				}
				if (nNode < 0)
					continue;

				if (!m_NodeArray[nNode].bProc)
				{
					nMidNodeArray.push_back(nNode);
					m_NodeArray[nNode].bProc=1;
				}
			}
		}
		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nRgnNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nRgnNodeArray.push_back(nMidNodeArray[i]);
	}
}
