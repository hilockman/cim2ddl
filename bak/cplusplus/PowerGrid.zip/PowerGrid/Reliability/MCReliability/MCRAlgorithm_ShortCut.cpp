#include "StdAfx.h"
#include "MCRAlgorithm.h"

int CMCRAlgorithm::SeekMCut01(std::vector<tagMCRAlgMinCut1>& sCutArray, const int nComp)
{
	register int	i;
	for (i=0; i<(int)sCutArray.size(); i++)
	{
		if (sCutArray[i].nComp == nComp)
			return i;
	}
	return -1;
}

int CMCRAlgorithm::SeekMCut02(std::vector<tagMCRAlgMinCut2>& sCutArray, const int nComp1, const int nComp2)
{
	register int	i;
	for (i=0; i<(int)sCutArray.size(); i++)
	{
		if (sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[1] == nComp2 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[0] == nComp2)
			return i;
	}
	return -1;
}

int CMCRAlgorithm::SeekMCut03(std::vector<tagMCRAlgMinCut3>& sCutArray, const int nComp1, const int nComp2, const int nComp3)
{
	register int	i;
	for (i=0; i<(int)sCutArray.size(); i++)
	{
		if (sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[2] == nComp3 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[2] == nComp3 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[0] == nComp3 ||
			sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[1] == nComp3 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[0] == nComp3 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[1] == nComp3)
			return i;
	}
	return -1;
}

int CMCRAlgorithm::SeekMCut04(std::vector<tagMCRAlgMinCut4>& sCutArray, const int nComp1, const int nComp2, const int nComp3, const int nComp4)
{
	register int	i;

	for (i=0; i<(int)sCutArray.size(); i++)
	{
		if (sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[2] == nComp3 && sCutArray[i].nComp[3] == nComp4 ||
			sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[3] == nComp3 && sCutArray[i].nComp[2] == nComp4 ||
			sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[1] == nComp3 && sCutArray[i].nComp[3] == nComp4 ||
			sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[3] == nComp3 && sCutArray[i].nComp[1] == nComp4 ||
			sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[3] == nComp2 && sCutArray[i].nComp[1] == nComp3 && sCutArray[i].nComp[2] == nComp4 ||
			sCutArray[i].nComp[0] == nComp1 && sCutArray[i].nComp[3] == nComp2 && sCutArray[i].nComp[2] == nComp3 && sCutArray[i].nComp[1] == nComp4 ||

			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[2] == nComp3 && sCutArray[i].nComp[3] == nComp4 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[3] == nComp3 && sCutArray[i].nComp[2] == nComp4 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[0] == nComp3 && sCutArray[i].nComp[3] == nComp4 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[3] == nComp3 && sCutArray[i].nComp[0] == nComp4 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[3] == nComp2 && sCutArray[i].nComp[0] == nComp3 && sCutArray[i].nComp[2] == nComp4 ||
			sCutArray[i].nComp[1] == nComp1 && sCutArray[i].nComp[3] == nComp2 && sCutArray[i].nComp[2] == nComp3 && sCutArray[i].nComp[0] == nComp4 ||

			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[1] == nComp3 && sCutArray[i].nComp[3] == nComp4 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[3] == nComp3 && sCutArray[i].nComp[1] == nComp4 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[0] == nComp3 && sCutArray[i].nComp[3] == nComp4 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[3] == nComp3 && sCutArray[i].nComp[0] == nComp4 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[3] == nComp2 && sCutArray[i].nComp[0] == nComp3 && sCutArray[i].nComp[1] == nComp4 ||
			sCutArray[i].nComp[2] == nComp1 && sCutArray[i].nComp[3] == nComp2 && sCutArray[i].nComp[1] == nComp3 && sCutArray[i].nComp[0] == nComp4 ||

			sCutArray[i].nComp[3] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[1] == nComp3 && sCutArray[i].nComp[2] == nComp4 ||
			sCutArray[i].nComp[3] == nComp1 && sCutArray[i].nComp[0] == nComp2 && sCutArray[i].nComp[2] == nComp3 && sCutArray[i].nComp[1] == nComp4 ||
			sCutArray[i].nComp[3] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[0] == nComp3 && sCutArray[i].nComp[2] == nComp4 ||
			sCutArray[i].nComp[3] == nComp1 && sCutArray[i].nComp[1] == nComp2 && sCutArray[i].nComp[2] == nComp3 && sCutArray[i].nComp[0] == nComp4 ||
			sCutArray[i].nComp[3] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[0] == nComp3 && sCutArray[i].nComp[1] == nComp4 ||
			sCutArray[i].nComp[3] == nComp1 && sCutArray[i].nComp[2] == nComp2 && sCutArray[i].nComp[1] == nComp3 && sCutArray[i].nComp[0] == nComp4)
			return i;
	}
	return -1;
}

int CMCRAlgorithm::SeekCommMCut01(std::vector<tagMCRCmMinCut1>& sCmMCutO1Array, const int nComp)
{
	register int	i;
	for (i=0; i<(int)sCmMCutO1Array.size(); i++)
	{
		if (sCmMCutO1Array[i].nComp == nComp)
			return i;
	}
	return -1;
}

int CMCRAlgorithm::SeekCommMCut02(std::vector<tagMCRCmMinCut2>& sCmMCutO2Array, const int nComp1, const int nComp2)
{
	register int	i;
	for (i=0; i<(int)sCmMCutO2Array.size(); i++)
	{
		if (sCmMCutO2Array[i].nComp[0] == nComp1 && sCmMCutO2Array[i].nComp[1] == nComp2 ||
			sCmMCutO2Array[i].nComp[1] == nComp1 && sCmMCutO2Array[i].nComp[0] == nComp2)
			return i;
	}
	return -1;
}

// int CMCRAlgorithm::isSwitchPair(const int nComp1, const int nComp2)
// {
// 	if (m_CompArray[nComp1].nPhyTyp != PG_DISCONNECTOR || m_CompArray[nComp2].nPhyTyp != PG_DISCONNECTOR)
// 		return 0;
// 
// 	register int	i;
// 	for (i=0; i<(int)m_CompArray[nComp1].nSwCompArray.size(); i++)
// 	{
// 		if (m_CompArray[nComp1].nSwCompArray[i] == nComp2)
// 			return 1;
// 	}
// 	for (i=0; i<(int)m_CompArray[nComp2].nSwCompArray.size(); i++)
// 	{
// 		if (m_CompArray[nComp2].nSwCompArray[i] == nComp1)
// 			return 1;
// 	}
// 	return 0;
// }

int CMCRAlgorithm::isShortCut01(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp)
{
	register int	i;

	//��ά�����ĳһ��ȫΪ1, ��Ϊһ����С�����ĳ�豸����������·��
	for (i=0; i <(int)sMinPathArray.size(); i++)
	{
		if (bCheckPathStatus && sMinPathArray[i].nStatus != 0)
			continue;

		if (sMinPathArray[i].nCompVector[nComp] == 0)	//	����һ�׸�ķ���
			return 0;
	}
	return 1;
}

int CMCRAlgorithm::isShortCut02(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp1, const int nComp2)
{
	register int	i;
	//�����ĳһ��ȫΪ1, ��Ϊ������С���·���в�����nComp1��nComp2����nComp1��nComp2һ�����Ƕ��׸�
	for (i=0; i<(int)sMinPathArray.size(); i++)
	{
		if (bCheckPathStatus && sMinPathArray[i].nStatus != 0)
			continue;

		if ( (sMinPathArray[i].nCompVector[nComp1] == 0 && sMinPathArray[i].nCompVector[nComp2] == 0))	//	���Ƕ��׸�ķ���
			return 0;
	}
	return 1;
}

int CMCRAlgorithm::isShortCut03(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp1, const int nComp2, const int nComp3)
{
	register int	i;

	for (i=0; i<(int)sMinPathArray.size(); i++)
	{
		if (bCheckPathStatus && sMinPathArray[i].nStatus != 0)
			continue;

		if ((sMinPathArray[i].nCompVector[nComp1] == 0 && sMinPathArray[i].nCompVector[nComp2] == 0 && sMinPathArray[i].nCompVector[nComp3] == 0))	//	�������׸�ķ���
			return 0;
	}
	return 1;
}

int CMCRAlgorithm::isShortCut04(std::vector<tagMCRAlgPath>& sMinPathArray, const unsigned char bCheckPathStatus, const int nComp1, const int nComp2, const int nComp3, const int nComp4)
{
	register int	i;

	for (i=0; i<(int)sMinPathArray.size(); i++)
	{
		if (bCheckPathStatus && sMinPathArray[i].nStatus != 0)
			continue;

		if ((sMinPathArray[i].nCompVector[nComp1] == 0 && sMinPathArray[i].nCompVector[nComp2] == 0 && sMinPathArray[i].nCompVector[nComp3] == 0 && sMinPathArray[i].nCompVector[nComp4] == 0))	//	�����Ľ׸�ķ���
			return 0;
	}
	return 1;
}

void CMCRAlgorithm::FormNormalShortCut()
{
	int		j1, j2, j3;
	tagMCRAlgMinCut1	sCut1Buf;
	tagMCRAlgMinCut2	sCut2Buf;
	tagMCRAlgMinCut3	sCut3Buf;

	m_MinCut1Array.clear();
	m_MinCut2Array.clear();
	m_MinCut3Array.clear();

	memset(&sCut1Buf, 0, sizeof(tagMCRAlgMinCut1));
	memset(&sCut2Buf, 0, sizeof(tagMCRAlgMinCut2));
	memset(&sCut3Buf, 0, sizeof(tagMCRAlgMinCut3));

	clock_t	dBeg, dEnd;
	int		nDur;

	if (m_MinPathArray.empty())
		return;

	dBeg=clock();

	register int	i;
	int		nPath, nComp;
	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
		m_CompArray[nComp].bInPath=0;
	for (nPath=0; nPath<(int)m_MinPathArray.size(); nPath++)
	{
		//	Ϊ������С�����٣�������С·���豸��Ϣ��
		if (m_MinPathArray[nPath].nStatus != 0)
			continue;

		for (i=0; i<(int)m_MinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp=m_MinPathArray[nPath].nCompArray[i];
			m_CompArray[nComp].bInPath=1;
			m_MinPathArray[nPath].nCompVector[nComp]=1;
		}
	}

	for (j1=0; j1<(int)m_CompArray.size(); j1++) //��һ��
	{
		if (!m_CompArray[j1].bInPath)
			continue;

		//	����Ҫ���ǹ�ģ�滻�����Բ��ܽ�ͨ��fRerr��fTrep��fRchk��fTchk���о��γɸ
		if (m_CompArray[j1].nPhyTyp != PG_BREAKER && (m_CompArray[j1].fRerr < FLT_MIN && m_CompArray[j1].fTrep < FLT_MIN) && (m_CompArray[j1].fRchk < FLT_MIN && m_CompArray[j1].fTchk < FLT_MIN))
			continue;

		if (isShortCut01(m_MinPathArray, YCheckStatus, j1))
		{
			if (SeekMCut01(m_MinCut1Array, j1) < 0)
			{
				//if ((m_CompArray[j1].fRerr > FLT_MIN && m_CompArray[j1].fTrep > FLT_MIN) || (m_CompArray[j1].fRchk > FLT_MIN && m_CompArray[j1].fTchk > FLT_MIN))
				{
					sCut1Buf.nComp=j1;
					m_MinCut1Array.push_back(sCut1Buf);
				}
			}
			continue;
		}
		if (m_MinPathArray.size() > 1)
		{
			for (j2=0; j2<j1; j2++) //�����
			{
				if (!m_CompArray[j2].bInPath)
					continue;
				if (m_CompArray[j2].nPhyTyp != PG_BREAKER && (m_CompArray[j2].fRerr < FLT_MIN && m_CompArray[j2].fTrep < FLT_MIN) && (m_CompArray[j2].fRchk < FLT_MIN && m_CompArray[j2].fTchk < FLT_MIN))
					continue;
				if (SeekMCut01(m_MinCut1Array, j2) >= 0) //�����ж�j2�Ƿ񹹳�һ�׸
					continue;

				if (isShortCut02(m_MinPathArray, YCheckStatus, j2, j1))
				{
					if (SeekMCut02(m_MinCut2Array, j1, j2) < 0)
					{
						//	����Ҫ�����л�ʱ�乲ģ�����أ����Բ���ͨ��fRerr��fTrep��fRchk��fTchk���о��γɸ
						//  					if (((m_CompArray[j1].fRerr > FLT_MIN && m_CompArray[j1].fTrep > FLT_MIN) || (m_CompArray[j1].fRchk > FLT_MIN && m_CompArray[j1].fTchk > FLT_MIN)) ||
						//  						((m_CompArray[j2].fRerr > FLT_MIN && m_CompArray[j2].fTrep > FLT_MIN) || (m_CompArray[j2].fRchk > FLT_MIN && m_CompArray[j2].fTchk > FLT_MIN)))
						{
							sCut2Buf.nComp[0]=j2;
							sCut2Buf.nComp[1]=j1;
							m_MinCut2Array.push_back(sCut2Buf);
						}
					}
					continue;
				}
				if (m_MinPathArray.size() > 2)
				{
					for (j3=0; j3<j2; j3++) //������
					{
						if (!m_CompArray[j3].bInPath)
							continue;
						if (m_CompArray[j3].nPhyTyp != PG_BREAKER && (m_CompArray[j3].fRerr < FLT_MIN && m_CompArray[j3].fTrep < FLT_MIN) && (m_CompArray[j3].fRchk < FLT_MIN && m_CompArray[j3].fTchk < FLT_MIN))
							continue;
						if (SeekMCut01(m_MinCut1Array, j3) >= 0) //�����ж�j3�Ƿ񹹳�һ�׸
							continue;

						if (SeekMCut02(m_MinCut2Array, j3, j1) >= 0 || SeekMCut02(m_MinCut2Array, j3, j2) >= 0) //ɸ������
							continue;

						if (isShortCut03(m_MinPathArray, YCheckStatus, j3, j2, j1))
						{
							if (SeekMCut03(m_MinCut3Array, j1, j2, j3) < 0)
							{
								//	����Ҫ�����л�ʱ�乲ģ�����أ����Բ���ͨ��fRerr��fTrep��fRchk��fTchk���о��γɸ
								// 								if (((m_CompArray[j1].fRerr > FLT_MIN && m_CompArray[j1].fTrep > FLT_MIN) || (m_CompArray[j1].fRchk > FLT_MIN && m_CompArray[j1].fTchk > FLT_MIN)) ||
								// 									((m_CompArray[j2].fRerr > FLT_MIN && m_CompArray[j2].fTrep > FLT_MIN) || (m_CompArray[j2].fRchk > FLT_MIN && m_CompArray[j2].fTchk > FLT_MIN)) ||
								// 									((m_CompArray[j3].fRerr > FLT_MIN && m_CompArray[j3].fTrep > FLT_MIN) || (m_CompArray[j3].fRchk > FLT_MIN && m_CompArray[j3].fTchk > FLT_MIN)))
								{
									sCut3Buf.nComp[0]=j3;
									sCut3Buf.nComp[1]=j2;
									sCut3Buf.nComp[2]=j1;
									m_MinCut3Array.push_back(sCut3Buf);
								}
							}
							continue;
						}
					}
				}
			}
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("              �������ɣ���ʱ%d����",  nDur);
	Log(g_lpszLogFile,  "              �������ɣ���ʱ%d����\n",  nDur);

	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		m_MinCut1Array[i].fR=0;			//��Чͣ����
		m_MinCut1Array[i].fT=0;			//��Чͣ��ʱ��
		m_MinCut1Array[i].fFaultR=0;		//��Ч����ͣ����
		m_MinCut1Array[i].fFaultT=0;		//��Ч����ͣ��ʱ��
		m_MinCut1Array[i].fPlanR=0;		//��ЧԤ����ͣ����
		m_MinCut1Array[i].fPlanT=0;		//��ЧԤ����ͣ��ʱ��

		m_MinCut1Array[i].nSwitchComp = -1;
	}
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		m_MinCut2Array[i].fR=0;			//��Чͣ����
		m_MinCut2Array[i].fT=0;			//��Чͣ��ʱ��
		m_MinCut2Array[i].fFaultR=0;		//��Ч����ͣ����
		m_MinCut2Array[i].fFaultT=0;		//��Ч����ͣ��ʱ��
		m_MinCut2Array[i].fPlanR=0;		//��ЧԤ����ͣ����
		m_MinCut2Array[i].fPlanT=0;		//��ЧԤ����ͣ��ʱ��

		m_MinCut2Array[i].nSwitchComp[0]=-1;
		m_MinCut2Array[i].nSwitchComp[1]=-1;
	}
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		m_MinCut3Array[i].fR=0;			//��Чͣ����
		m_MinCut3Array[i].fT=0;			//��Чͣ��ʱ��
		m_MinCut3Array[i].fFaultR=0;		//��Ч����ͣ����
		m_MinCut3Array[i].fFaultT=0;		//��Ч����ͣ��ʱ��
		m_MinCut3Array[i].fPlanR=0;		//��ЧԤ����ͣ����
		m_MinCut3Array[i].fPlanT=0;		//��ЧԤ����ͣ��ʱ��

		m_MinCut3Array[i].nSwitchComp[0]=-1;
		m_MinCut3Array[i].nSwitchComp[1]=-1;
		m_MinCut3Array[i].nSwitchComp[2]=-1;
	}

#ifdef _DEBUG
	for (i=0; i<(int)m_MinCut1Array.size(); i++)
	{
		j1=m_MinCut1Array[i].nComp;
		Log(g_lpszLogFile,  "          һ����С��[%d/%d]�� %s, %s [%f %f]\n", i+1, m_MinCut1Array.size(), PGGetTableName(m_CompArray[j1].nPhyTyp), m_CompArray[j1].strName.c_str(),
			m_CompArray[j1].fRerr, m_CompArray[j1].fTrep);
	}
	for (i=0; i<(int)m_MinCut2Array.size(); i++)
	{
		j1=m_MinCut2Array[i].nComp[0];
		j2=m_MinCut2Array[i].nComp[1];

		Log(g_lpszLogFile,  "          ������С��[%d/%d]�� %s, %s    %s, %s\n", i, m_MinCut2Array.size(),
			PGGetTableName(m_CompArray[j1].nPhyTyp), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nPhyTyp), m_CompArray[j2].strName.c_str());
	}
	for (i=0; i<(int)m_MinCut3Array.size(); i++)
	{
		j1=m_MinCut3Array[i].nComp[0];
		j2=m_MinCut3Array[i].nComp[1];
		j3=m_MinCut3Array[i].nComp[2];

		Log(g_lpszLogFile,  "          ������С��[%d/%d]�� %s, %s    %s, %s    %s, %s\n", i, m_MinCut3Array.size(),
			PGGetTableName(m_CompArray[j1].nPhyTyp), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nPhyTyp), m_CompArray[j2].strName.c_str(),
			PGGetTableName(m_CompArray[j3].nPhyTyp), m_CompArray[j3].strName.c_str());
	}

#endif
}
