#include "StdAfx.h"
#include "MCRAlgorithm.h"

void CMCRAlgorithm::InitPerturb()
{
}

void	CMCRAlgorithm::PerturbAmend(const int nPerturb)
{
	int	nComp;
	for (nComp=0; nComp<(int)m_CompBackArray.size(); nComp++)
	{

		switch (m_CompArray[nComp].nPhyTyp)
		{
		case PG_BUSBARSECTION:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*g_MCRPerturb.m_Param.fBusRerrPerturb);	if (m_CompArray[nComp].fRerr < 0)	m_CompArray[nComp].fRerr = 0;
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*g_MCRPerturb.m_Param.fBusTrepPerturb);	if (m_CompArray[nComp].fTrep < 0)	m_CompArray[nComp].fTrep = 0;
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*g_MCRPerturb.m_Param.fBusRchkPerturb);	if (m_CompArray[nComp].fRchk < 0)	m_CompArray[nComp].fRchk = 0;
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*g_MCRPerturb.m_Param.fBusTchkPerturb);	if (m_CompArray[nComp].fTchk < 0)	m_CompArray[nComp].fTchk = 0;
			break;
		case PG_ACLINESEGMENT:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*g_MCRPerturb.m_Param.fLineRerrPerturb);	if (m_CompArray[nComp].fRerr < 0)	m_CompArray[nComp].fRerr = 0;
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*g_MCRPerturb.m_Param.fLineTrepPerturb);	if (m_CompArray[nComp].fTrep < 0)	m_CompArray[nComp].fTrep = 0;
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*g_MCRPerturb.m_Param.fLineRchkPerturb);	if (m_CompArray[nComp].fRchk < 0)	m_CompArray[nComp].fRchk = 0;
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*g_MCRPerturb.m_Param.fLineTchkPerturb);	if (m_CompArray[nComp].fTchk < 0)	m_CompArray[nComp].fTchk = 0;
			break;
		case PG_TRANSFORMERWINDING:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*g_MCRPerturb.m_Param.fTranRerrPerturb);	if (m_CompArray[nComp].fRerr < 0)	m_CompArray[nComp].fRerr = 0;
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*g_MCRPerturb.m_Param.fTranTrepPerturb);	if (m_CompArray[nComp].fTrep < 0)	m_CompArray[nComp].fTrep = 0;
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*g_MCRPerturb.m_Param.fTranRchkPerturb);	if (m_CompArray[nComp].fRchk < 0)	m_CompArray[nComp].fRchk = 0;
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*g_MCRPerturb.m_Param.fTranTchkPerturb);	if (m_CompArray[nComp].fTchk < 0)	m_CompArray[nComp].fTchk = 0;
			break;
		case PG_SERIESCOMPENSATOR:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*g_MCRPerturb.m_Param.fScapRerrPerturb);	if (m_CompArray[nComp].fRerr < 0)	m_CompArray[nComp].fRerr = 0;
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*g_MCRPerturb.m_Param.fScapTrepPerturb);	if (m_CompArray[nComp].fTrep < 0)	m_CompArray[nComp].fTrep = 0;
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*g_MCRPerturb.m_Param.fScapRchkPerturb);	if (m_CompArray[nComp].fRchk < 0)	m_CompArray[nComp].fRchk = 0;
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*g_MCRPerturb.m_Param.fScapTchkPerturb);	if (m_CompArray[nComp].fTchk < 0)	m_CompArray[nComp].fTchk = 0;
			break;
		case PG_BREAKER:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*g_MCRPerturb.m_Param.fBreakerRerrPerturb);	if (m_CompArray[nComp].fRerr < 0)	m_CompArray[nComp].fRerr = 0;
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*g_MCRPerturb.m_Param.fBreakerTrepPerturb);	if (m_CompArray[nComp].fTrep < 0)	m_CompArray[nComp].fTrep = 0;
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*g_MCRPerturb.m_Param.fBreakerRchkPerturb);	if (m_CompArray[nComp].fRchk < 0)	m_CompArray[nComp].fRchk = 0;
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*g_MCRPerturb.m_Param.fBreakerTchkPerturb);	if (m_CompArray[nComp].fTchk < 0)	m_CompArray[nComp].fTchk = 0;
			m_CompArray[nComp].fTopr=m_CompBackArray[nComp].fTopr*(1+nPerturb*g_MCRPerturb.m_Param.fBreakerToprPerturb);	if (m_CompArray[nComp].fTopr < 0)	m_CompArray[nComp].fTopr = 0;
			break;
		case PG_DISCONNECTOR:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*g_MCRPerturb.m_Param.fDisconnectorRerrPerturb);		if (m_CompArray[nComp].fRerr < 0)		m_CompArray[nComp].fRerr = 0;
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*g_MCRPerturb.m_Param.fDisconnectorTrepPerturb);		if (m_CompArray[nComp].fTrep < 0)		m_CompArray[nComp].fTrep = 0;
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*g_MCRPerturb.m_Param.fDisconnectorRchkPerturb);		if (m_CompArray[nComp].fRchk < 0)		m_CompArray[nComp].fRchk = 0;
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*g_MCRPerturb.m_Param.fDisconnectorTchkPerturb);		if (m_CompArray[nComp].fTchk < 0)		m_CompArray[nComp].fTchk = 0;
			m_CompArray[nComp].fTopr=m_CompBackArray[nComp].fTopr*(1+nPerturb*g_MCRPerturb.m_Param.fDisconnectorToprPerturb);		if (m_CompArray[nComp].fTopr < 0)		m_CompArray[nComp].fTopr = 0;
			m_CompArray[nComp].fTSwitch=m_CompArray[nComp].fTSwitch*(1+nPerturb*g_MCRPerturb.m_Param.fDisconnectorTSwitchPerturb);	if (m_CompArray[nComp].fTSwitch < 0)	m_CompArray[nComp].fTSwitch = 0;
			break;
		}
	}
}

void	CMCRAlgorithm::PerturbRestore()
{
	int		nComp;
	for (nComp=0; nComp<(int)m_CompBackArray.size(); nComp++)
	{
		m_CompArray[nComp].fRerr	=m_CompBackArray[nComp].fRerr	;
		m_CompArray[nComp].fTrep	=m_CompBackArray[nComp].fTrep	;
		m_CompArray[nComp].fRchk	=m_CompBackArray[nComp].fRchk	;
		m_CompArray[nComp].fTchk	=m_CompBackArray[nComp].fTchk	;
		m_CompArray[nComp].fTopr	=m_CompBackArray[nComp].fTopr	;
		m_CompArray[nComp].fTSwitch	=m_CompBackArray[nComp].fTSwitch;
	}
}
