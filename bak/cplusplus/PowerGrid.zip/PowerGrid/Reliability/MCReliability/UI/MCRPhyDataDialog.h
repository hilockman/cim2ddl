#pragma once

// CMCRPhyDataDialog �Ի���

class CMCRPhyDataDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRPhyDataDialog)

public:
	CMCRPhyDataDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRPhyDataDialog();

// �Ի�������
	enum { IDD = IDD_MCRPHYDATA_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedFormModel();
	afx_msg void OnBnClickedFormMemDB();
	afx_msg void OnCbnSelchangeDatatypeCombo();
	afx_msg void OnNMClickDataList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedMod();
	afx_msg void RefreshDataList();
	afx_msg void OnLvnItemchangedDataList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedTopo();
	DECLARE_MESSAGE_MAP()

private:
	int m_nShowDevType;
	CMFCPropertyGridCtrl	m_wndPropertyList;

private:
	void RefreshPhyBusList			(const unsigned char bRefreshColumn);
	void RefreshPhyLineList			(const unsigned char bRefreshColumn, const unsigned char nShowDevType = 0);
	void RefreshPhyTranList			(const unsigned char bRefreshColumn, const unsigned char nShowDevType = 0);
	void RefreshPhyScapList			(const unsigned char bRefreshColumn);
	void RefreshPhyBreakerList		(const unsigned char bRefreshColumn);
	void RefreshPhyDisconnectorList	(const unsigned char bRefreshColumn);
	void RefreshPhyNodeList			();

	void RefreshDevType();
	void RefreshPropertyList(const int nRecord);
	int ResolvePropertyValue(const int nTable, char szRecArray[][MDB_CHARLEN_LONG]);
public:
	void Refresh();
};
