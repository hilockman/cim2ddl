// FaultModeDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRResultFModeDialog.h"

// CFaultModeDialog �Ի���

static	char*	lpszReliabilityIndexName[]=
{
	"(�ۺ�)������(��/��)",
	"(�ۺ�)ͣ�����ʱ��(Сʱ/��)",
	"(�ۺ�)��ͣ��ʱ��(Сʱ/��)",
	"(�ۺ�)������(%)",
	"(�ۺ�)������ʧ(����ʱ/��)",
	"",
	"(����)������(��/��)",
	"(����)ͣ�����ʱ��(Сʱ/��)",
	"(����)��ͣ��ʱ��(Сʱ/��)",
	"(����)������(%)",
	"(����)������ʧ(����ʱ/��)",
};

static	char*	lpszReliabilityIndexColumn[]=
{
	"ָ��",
	"ϵͳָ��",
	"���߹���",
	"�������",
	"���߹���",
	"�������",
	"һ��һ�����",
	"ȫվͣ��",
};

static	char*	lpszEconomyIndexName[]=
{
	"ָ��",
	"ֵ",
};

static	char*	lpszEconomyIndexColumn[]=
{
	"����ֵ(��Ԫ)",
	"(�ۺ�)ͣ����ʧ(��Ԫ)",
	"(����)ͣ����ʧ(��Ԫ)",
	"(�ۺ�)�ϼ�(��Ԫ)",
	"(����)�ϼ�(��Ԫ)",
};

static	char*	lpszFaultColumn[]=
{
	"���",
	"��������",
	"�����豸1",
	"�����豸2",
	"�����豸3",
	"������",
	"ͣ��ʱ��",
	"R����(%)",
	"U����(%)",
};


IMPLEMENT_DYNAMIC(CMCRResultFModeDialog, CDialog)

CMCRResultFModeDialog::CMCRResultFModeDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRResultFModeDialog::IDD, pParent)
{
	m_nFMode = 0;
}

CMCRResultFModeDialog::~CMCRResultFModeDialog()
{
}

void CMCRResultFModeDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_FMODE_L1, m_nFMode);
}


BEGIN_MESSAGE_MAP(CMCRResultFModeDialog, CDialog)
	ON_BN_CLICKED(IDC_FMODE_L1, &CMCRResultFModeDialog::OnBnClickedFmode)
	ON_BN_CLICKED(IDC_FMODE_T1, &CMCRResultFModeDialog::OnBnClickedFmode)
	ON_BN_CLICKED(IDC_FMODE_L2, &CMCRResultFModeDialog::OnBnClickedFmode)
	ON_BN_CLICKED(IDC_FMODE_T2, &CMCRResultFModeDialog::OnBnClickedFmode)
	ON_BN_CLICKED(IDC_FMODE_LT, &CMCRResultFModeDialog::OnBnClickedFmode)
	ON_BN_CLICKED(IDC_FMODE_ALL, &CMCRResultFModeDialog::OnBnClickedFmode)
	ON_BN_CLICKED(IDC_EXCEL_OUT, &CMCRResultFModeDialog::OnBnClickedExcelOut)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CFaultModeDialog ��Ϣ��������

BOOL CMCRResultFModeDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectDummy;

	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RELIABILITY_INDEX_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszReliabilityIndexColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszReliabilityIndexColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ECONOMY_INDEX_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszEconomyIndexName)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszEconomyIndexName[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FMODE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszFaultColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszFaultColumn[i],	LVCFMT_LEFT,	100);

	Refresh();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRResultFModeDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

void CMCRResultFModeDialog::RefreshFaultList(std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array)
{
	register int	i;
	int			nType, nComp, nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FMODE_LIST);
	if (!pListCtrl->DeleteAllItems())
		return;

	nRow=0;
	for (i=0; i<(int)sFault1Array.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, "һ�׹���");

		nType = sFault1Array[i].sComp.nCompTyp;
		nComp = sFault1Array[i].sComp.nCompIdx;
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nCol++;
		nCol++;

		sprintf(szBuf, "%f", sFault1Array[i].fR);				pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", sFault1Array[i].fU);				pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", sFault1Array[i].fRContribution);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", sFault1Array[i].fUContribution);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}
	for (i=0; i<(int)sFault2Array.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);		pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, "���׹���");

		nType = sFault2Array[i].sComp[0].nCompTyp;
		nComp = sFault2Array[i].sComp[0].nCompIdx;
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nType = sFault2Array[i].sComp[1].nCompTyp;
		nComp = sFault2Array[i].sComp[1].nCompIdx;
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nCol++;

		sprintf(szBuf, "%f", sFault2Array[i].fR);				pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", sFault2Array[i].fU);				pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", sFault2Array[i].fRContribution);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", sFault2Array[i].fUContribution);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}
	for (i=0; i<(int)sFault3Array.size(); i++)
	{

		sprintf(szBuf, "%d", nRow+1);		pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, "���׹���");

		nType = sFault3Array[i].sComp[0].nCompTyp;
		nComp = sFault3Array[i].sComp[0].nCompIdx;
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nType = sFault3Array[i].sComp[1].nCompTyp;
		nComp = sFault3Array[i].sComp[1].nCompIdx;
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nType = sFault3Array[i].sComp[2].nCompTyp;
		nComp = sFault3Array[i].sComp[2].nCompIdx;
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

		sprintf(szBuf, "%f", sFault3Array[i].fR);				pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", sFault3Array[i].fU);				pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", sFault3Array[i].fRContribution);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", sFault3Array[i].fUContribution);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	for (i=0; i<sizeof(lpszFaultColumn)/sizeof(char*); i++)
	{
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultFModeDialog::RefreshReliabilityIndexList()
{
	register int	i;
	int			nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;
	double		fT;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RELIABILITY_INDEX_LIST);
	pListCtrl->DeleteAllItems();

	nCol=0;

	for (nRow=0; nRow<sizeof(lpszReliabilityIndexName)/sizeof(char*); nRow++)
		pListCtrl->InsertItem(nRow, lpszReliabilityIndexName[nRow]);
	nCol++;

	//////////////////////////////////////////////////////////////////////////
	nRow=0;
	fT = 0;
	if (g_MCRPhyData.m_System.fAifi > FLT_MIN)	fT = g_MCRPhyData.m_System.fAidi/g_MCRPhyData.m_System.fAifi;

	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fAifi);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", fT);									pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fAidi);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_System.fAsai);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEns);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;

	fT = 0;
	if (g_MCRPhyData.m_System.fFaultAifi > FLT_MIN)	fT = g_MCRPhyData.m_System.fFaultAidi/g_MCRPhyData.m_System.fFaultAifi;

	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fFaultAifi);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", fT);									pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fFaultAidi);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_System.fFaultAsai);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fFaultEns);		pListCtrl->SetItemText(nRow++, nCol, szBuf);

	nCol++;

	nRow=0;
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L1Index.fASAI);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;
	nRow++;

	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fFaultLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fFaultLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fFaultLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L1Index.fFaultASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nCol++;

	//////////////////////////////////////////////////////////////////////////
	nRow=0;
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fLOR);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fLOD);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fLOU);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T1Index.fASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;
	nRow++;

	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fFaultLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fFaultLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fFaultLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T1Index.fFaultASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nCol++;

	//////////////////////////////////////////////////////////////////////////
	nRow=0;
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fLOR);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fLOD);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fLOU);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L2Index.fASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;
	nRow++;

	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fFaultLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fFaultLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fFaultLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L2Index.fFaultASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nCol++;

	//////////////////////////////////////////////////////////////////////////
	nRow=0;
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fLOR);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fLOD);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fLOU);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T2Index.fASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;
	nRow++;

	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fFaultLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fFaultLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fFaultLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T2Index.fFaultASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nCol++;

	//////////////////////////////////////////////////////////////////////////
	nRow=0;
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_LTIndex.fASAI);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;
	nRow++;

	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fFaultLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fFaultLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fFaultLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_LTIndex.fFaultASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nCol++;

	//////////////////////////////////////////////////////////////////////////
	nRow=0;
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fLOR);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fLOD);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fLOU);			pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_SubIndex.fASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nRow++;
	nRow++;

	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fFaultLOR);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fFaultLOD);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fFaultLOU);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_SubIndex.fFaultASAI);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	nCol++;

	for (i=0; i<sizeof(lpszReliabilityIndexColumn)/sizeof(char*); i++)
	{
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultFModeDialog::RefreshEconomyIndexList()
{
	register int	i;
	int			nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ECONOMY_INDEX_LIST);
	pListCtrl->DeleteAllItems();

	nCol=0;

	for (nRow=0; nRow<sizeof(lpszEconomyIndexColumn)/sizeof(char*); nRow++)
		pListCtrl->InsertItem(nRow, lpszEconomyIndexColumn[nRow]);
	nCol++;

	nRow=0;
	nCol=1;
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyAnnualWorth);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyLoss);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyFaultLoss);	pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyTotal);		pListCtrl->SetItemText(nRow++, nCol, szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyFaultTotal);	pListCtrl->SetItemText(nRow++, nCol, szBuf);

	for (i=0; i<sizeof(lpszEconomyIndexName)/sizeof(char*); i++)
	{
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultFModeDialog::OnBnClickedFmode()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	switch (m_nFMode)
	{
	case	0:
		RefreshFaultList(g_MCRPhyData.m_L1Index.sFault1Array, g_MCRPhyData.m_L1Index.sFault2Array, g_MCRPhyData.m_L1Index.sFault3Array);
		break;
	case	1:
		RefreshFaultList(g_MCRPhyData.m_T1Index.sFault1Array, g_MCRPhyData.m_T1Index.sFault2Array, g_MCRPhyData.m_T1Index.sFault3Array);
		break;
	case	2:
		RefreshFaultList(g_MCRPhyData.m_L2Index.sFault1Array, g_MCRPhyData.m_L2Index.sFault2Array, g_MCRPhyData.m_L2Index.sFault3Array);
		break;
	case	3:
		RefreshFaultList(g_MCRPhyData.m_T2Index.sFault1Array, g_MCRPhyData.m_T2Index.sFault2Array, g_MCRPhyData.m_T2Index.sFault3Array);
		break;
	case	4:
		RefreshFaultList(g_MCRPhyData.m_LTIndex.sFault1Array, g_MCRPhyData.m_LTIndex.sFault2Array, g_MCRPhyData.m_LTIndex.sFault3Array);
		break;
	case	5:
		RefreshFaultList(g_MCRPhyData.m_SubIndex.sFault1Array, g_MCRPhyData.m_SubIndex.sFault2Array, g_MCRPhyData.m_SubIndex.sFault3Array);
		break;
	}
}

void CMCRResultFModeDialog::SaveFaultAsExcel(ExcelAccessor* pXls, std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array)
{
	register int	i;
	int		nType, nComp;
	char	szBuf[260];

	for (i=0; i<(int)sFault1Array.size(); i++)
	{
		pXls->NewLine();
		sprintf(szBuf, "%d", i+1);	pXls->AddCell(szBuf);

		pXls->AddCell("һ�׹���");

		nType = sFault1Array[i].sComp.nCompTyp;
		nComp = sFault1Array[i].sComp.nCompIdx;
		pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

		pXls->AddCell("");
		pXls->AddCell("");

		sprintf(szBuf, "%f", sFault1Array[i].fR);				pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", sFault1Array[i].fU);				pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", sFault1Array[i].fRContribution);	pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", sFault1Array[i].fUContribution);	pXls->AddCell(szBuf);
	}

	for (i=0; i<(int)sFault2Array.size(); i++)
	{
		pXls->NewLine();
		sprintf(szBuf, "%d", i+1);		pXls->AddCell(szBuf);

		pXls->AddCell("���׹���");

		nType = sFault2Array[i].sComp[0].nCompTyp;
		nComp = sFault2Array[i].sComp[0].nCompIdx;
		pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nType = sFault2Array[i].sComp[1].nCompTyp;
		nComp = sFault2Array[i].sComp[1].nCompIdx;
		pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

		pXls->AddCell("");

		sprintf(szBuf, "%f", sFault2Array[i].fR);				pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", sFault2Array[i].fU);				pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", sFault2Array[i].fRContribution);	pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", sFault2Array[i].fUContribution);	pXls->AddCell(szBuf);
	}

	for (i=0; i<(int)sFault3Array.size(); i++)
	{
		pXls->NewLine();
		sprintf(szBuf, "%d", i+1);		pXls->AddCell(szBuf);

		pXls->AddCell("���׹���");

		nType = sFault3Array[i].sComp[0].nCompTyp;
		nComp = sFault3Array[i].sComp[0].nCompIdx;
		pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nType = sFault3Array[i].sComp[1].nCompTyp;
		nComp = sFault3Array[i].sComp[1].nCompIdx;
		pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

		nType = sFault3Array[i].sComp[2].nCompTyp;
		nComp = sFault3Array[i].sComp[2].nCompIdx;
		pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

		sprintf(szBuf, "%f", sFault3Array[i].fR);				pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", sFault3Array[i].fU);				pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", sFault3Array[i].fRContribution);	pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", sFault3Array[i].fUContribution);	pXls->AddCell(szBuf);
	}
}

void CMCRResultFModeDialog::SaveAsExcel(ExcelAccessor* pXls)
{
	int		nCol;
	double	fT;
	char	szBuf[260];

	//////////////////////////////////////////////////////////////////////////
	pXls->AddSheet("�����߿ɿ��Լ�����");
	pXls->SetCurSheet("�����߿ɿ��Լ�����");

	for (nCol=0; nCol<sizeof(lpszReliabilityIndexColumn)/sizeof(char*); nCol++)
		pXls->AddCell(lpszReliabilityIndexColumn[nCol]);

	nCol=0;
	//////////////////////////////////////////////////////////////////////////
	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fAifi);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fLOR);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fLOR);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fLOR);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fLOR);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fLOR);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fLOR);			pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	fT = 0;	if (g_MCRPhyData.m_System.fAifi > FLT_MIN)			fT = g_MCRPhyData.m_System.fAidi/g_MCRPhyData.m_System.fAifi;			sprintf(szBuf, "%f", fT);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fLOD);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fLOD);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fLOD);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fLOD);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fLOD);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fLOD);			pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fAidi);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fLOU);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fLOU);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fLOU);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fLOU);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fLOU);			pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fLOU);			pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_System.fAsai);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L1Index.fASAI);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T1Index.fASAI);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L2Index.fASAI);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T2Index.fASAI);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_LTIndex.fASAI);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_SubIndex.fASAI);pXls->AddCell(szBuf);
	nCol++;		//	����

	nCol++;
	pXls->NewLine();

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fFaultAifi);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fFaultLOR);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fFaultLOR);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fFaultLOR);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fFaultLOR);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fFaultLOR);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fFaultLOR);	pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	fT = 0;	if (g_MCRPhyData.m_System.fFaultAifi > FLT_MIN)		fT = g_MCRPhyData.m_System.fFaultAidi/g_MCRPhyData.m_System.fFaultAifi;	sprintf(szBuf, "%f", fT);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fFaultLOD);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fFaultLOD);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fFaultLOD);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fFaultLOD);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fFaultLOD);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fFaultLOD);	pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fFaultAidi);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L1Index.fFaultLOU);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T1Index.fFaultLOU);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_L2Index.fFaultLOU);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_T2Index.fFaultLOU);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_LTIndex.fFaultLOU);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", g_MCRPhyData.m_SubIndex.fFaultLOU);	pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszReliabilityIndexName[nCol++]);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_System.fFaultAsai);		pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L1Index.fFaultASAI);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T1Index.fFaultASAI);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_L2Index.fFaultASAI);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_T2Index.fFaultASAI);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_LTIndex.fFaultASAI);	pXls->AddCell(szBuf);
	sprintf(szBuf, "%f", 100*g_MCRPhyData.m_SubIndex.fFaultASAI);	pXls->AddCell(szBuf);

	//////////////////////////////////////////////////////////////////////////

	pXls->AddSheet("�����߾����Լ�����");
	pXls->SetCurSheet("�����߾����Լ�����");
	for (nCol=0; nCol<sizeof(lpszEconomyIndexName)/sizeof(char*); nCol++)
		pXls->AddCell(lpszEconomyIndexName[nCol]);

	nCol=0;
	//////////////////////////////////////////////////////////////////////////
	pXls->NewLine();
	pXls->AddCell(lpszEconomyIndexColumn[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyAnnualWorth);			pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszEconomyIndexColumn[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyLoss);			pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszEconomyIndexColumn[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyTotal);			pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszEconomyIndexColumn[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyFaultLoss);		pXls->AddCell(szBuf);

	pXls->NewLine();
	pXls->AddCell(lpszEconomyIndexColumn[nCol++]);
	sprintf(szBuf, "%f", g_MCRPhyData.m_System.fEconomyFaultTotal);		pXls->AddCell(szBuf);

	//////////////////////////////////////////////////////////////////////////
	pXls->AddSheet("�����߿ɿ��Թ���ģʽ");
	pXls->SetCurSheet("�����߿ɿ��Թ���ģʽ");

	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
		pXls->AddCell(lpszFaultColumn[nCol]);

	//////////////////////////////////////////////////////////////////////////
	pXls->NewLine();
	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
	{
		pXls->FillCell(RGB(0, 255, 0));
		pXls->AddCell("");
	}
	pXls->NewLine();
	pXls->AddCell("���߹���");
	SaveFaultAsExcel(pXls, g_MCRPhyData.m_L1Index.sFault1Array, g_MCRPhyData.m_L1Index.sFault2Array, g_MCRPhyData.m_L1Index.sFault3Array);

	pXls->NewLine();
	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
	{
		pXls->FillCell(RGB(0, 255, 0));
		pXls->AddCell("");
	}
	pXls->NewLine();
	pXls->AddCell("�������");
	SaveFaultAsExcel(pXls, g_MCRPhyData.m_T1Index.sFault1Array, g_MCRPhyData.m_T1Index.sFault2Array, g_MCRPhyData.m_T1Index.sFault3Array);

	pXls->NewLine();
	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
	{
		pXls->FillCell(RGB(0, 255, 0));
		pXls->AddCell("");
	}
	pXls->NewLine();
	pXls->AddCell("���߹���");
	SaveFaultAsExcel(pXls, g_MCRPhyData.m_L2Index.sFault1Array, g_MCRPhyData.m_L2Index.sFault2Array, g_MCRPhyData.m_L2Index.sFault3Array);

	pXls->NewLine();
	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
	{
		pXls->FillCell(RGB(0, 255, 0));
		pXls->AddCell("");
	}
	pXls->NewLine();
	pXls->AddCell("�������");
	SaveFaultAsExcel(pXls, g_MCRPhyData.m_T2Index.sFault1Array, g_MCRPhyData.m_T2Index.sFault2Array, g_MCRPhyData.m_T2Index.sFault3Array);

	pXls->NewLine();
	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
	{
		pXls->FillCell(RGB(0, 255, 0));
		pXls->AddCell("");
	}
	pXls->NewLine();
	pXls->AddCell("�߱����");
	SaveFaultAsExcel(pXls, g_MCRPhyData.m_LTIndex.sFault1Array, g_MCRPhyData.m_LTIndex.sFault2Array, g_MCRPhyData.m_LTIndex.sFault3Array);

	pXls->NewLine();
	for (nCol=0; nCol<sizeof(lpszFaultColumn)/sizeof(char*); nCol++)
	{
		pXls->FillCell(RGB(0, 255, 0));
		pXls->AddCell("");
	}
	pXls->NewLine();
	pXls->AddCell("ȫվ����");
	SaveFaultAsExcel(pXls, g_MCRPhyData.m_SubIndex.sFault1Array, g_MCRPhyData.m_SubIndex.sFault2Array, g_MCRPhyData.m_SubIndex.sFault3Array);
}

void CMCRResultFModeDialog::OnBnClickedExcelOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	SaveAsExcel(&xls);

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(dlg.GetPathName());
}
