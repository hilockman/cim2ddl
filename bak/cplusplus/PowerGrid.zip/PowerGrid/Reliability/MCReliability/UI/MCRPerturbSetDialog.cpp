// MCRPerturbDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRPerturbSetDialog.h"

// CMCRPerturbSetDialog �Ի���

IMPLEMENT_DYNAMIC(CMCRPerturbSetDialog, CDialog)

CMCRPerturbSetDialog::CMCRPerturbSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRPerturbSetDialog::IDD, pParent)
{

}

CMCRPerturbSetDialog::~CMCRPerturbSetDialog()
{
}

void CMCRPerturbSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMCRPerturbSetDialog, CDialog)
	ON_BN_CLICKED(IDC_ZERO_PERTURB, &CMCRPerturbSetDialog::OnBnClickedZeroPerturb)
	ON_BN_CLICKED(IDOK, &CMCRPerturbSetDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDC_LOAD_PARAM, &CMCRPerturbSetDialog::OnBnClickedLoadParam)
	ON_BN_CLICKED(IDC_SAVE_PARAM, &CMCRPerturbSetDialog::OnBnClickedSaveParam)
END_MESSAGE_MAP()


// CMCRPerturbSetDialog ��Ϣ��������

BOOL CMCRPerturbSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	RefreshUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRPerturbSetDialog::RefreshUI()
{
	char	szValue[MDB_CHARLEN];

	sprintf(szValue, "%d", g_MCRPerturb.m_Param.nPerturbNum);					GetDlgItem(IDC_PERTURB_NUM)->SetWindowText(CString(szValue));
	((CButton*)GetDlgItem(IDC_BIPERTURB))->SetCheck(g_MCRPerturb.m_Param.nPerturbType);

	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBusRerrPerturb);				GetDlgItem(IDC_BUS_RERR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBusTrepPerturb);				GetDlgItem(IDC_BUS_TREP)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBusRchkPerturb);				GetDlgItem(IDC_BUS_RCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBusTchkPerturb);				GetDlgItem(IDC_BUS_TCHK)->SetWindowText(CString(szValue));

	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fLineRerrPerturb);				GetDlgItem(IDC_LINE_RERR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fLineTrepPerturb);				GetDlgItem(IDC_LINE_TREP)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fLineRchkPerturb);				GetDlgItem(IDC_LINE_RCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fLineTchkPerturb);				GetDlgItem(IDC_LINE_TCHK)->SetWindowText(CString(szValue));

	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fTranRerrPerturb);				GetDlgItem(IDC_TRAN_RERR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fTranTrepPerturb);				GetDlgItem(IDC_TRAN_TREP)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fTranRchkPerturb);				GetDlgItem(IDC_TRAN_RCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fTranTchkPerturb);				GetDlgItem(IDC_TRAN_TCHK)->SetWindowText(CString(szValue));

	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fScapRerrPerturb);				GetDlgItem(IDC_SCAP_RERR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fScapTrepPerturb);				GetDlgItem(IDC_SCAP_TREP)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fScapRchkPerturb);				GetDlgItem(IDC_SCAP_RCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fScapTchkPerturb);				GetDlgItem(IDC_SCAP_TCHK)->SetWindowText(CString(szValue));

	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBreakerRerrPerturb);			GetDlgItem(IDC_BREAKER_RERR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBreakerTrepPerturb);			GetDlgItem(IDC_BREAKER_TREP)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBreakerRchkPerturb);			GetDlgItem(IDC_BREAKER_RCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBreakerTchkPerturb);			GetDlgItem(IDC_BREAKER_TCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fBreakerToprPerturb);			GetDlgItem(IDC_BREAKER_TOPR)->SetWindowText(CString(szValue));

	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fDisconnectorRerrPerturb);		GetDlgItem(IDC_DISCONNECTOR_RERR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fDisconnectorTrepPerturb);		GetDlgItem(IDC_DISCONNECTOR_TREP)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fDisconnectorRchkPerturb);		GetDlgItem(IDC_DISCONNECTOR_RCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fDisconnectorTchkPerturb);		GetDlgItem(IDC_DISCONNECTOR_TCHK)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fDisconnectorToprPerturb);		GetDlgItem(IDC_DISCONNECTOR_TOPR)->SetWindowText(CString(szValue));
	sprintf(szValue, "%f", g_MCRPerturb.m_Param.fDisconnectorTSwitchPerturb);	GetDlgItem(IDC_DISCONNECTOR_TSWITCH)->SetWindowText(CString(szValue));

}
void CMCRPerturbSetDialog::OnBnClickedZeroPerturb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_MCRPerturb.m_Param.fBusRerrPerturb=0;
	g_MCRPerturb.m_Param.fBusTrepPerturb=0;
	g_MCRPerturb.m_Param.fBusRchkPerturb=0;
	g_MCRPerturb.m_Param.fBusTchkPerturb=0;

	g_MCRPerturb.m_Param.fLineRerrPerturb=0;
	g_MCRPerturb.m_Param.fLineTrepPerturb=0;
	g_MCRPerturb.m_Param.fLineRchkPerturb=0;
	g_MCRPerturb.m_Param.fLineTchkPerturb=0;

	g_MCRPerturb.m_Param.fTranRerrPerturb=0;
	g_MCRPerturb.m_Param.fTranTrepPerturb=0;
	g_MCRPerturb.m_Param.fTranRchkPerturb=0;
	g_MCRPerturb.m_Param.fTranTchkPerturb=0;

	g_MCRPerturb.m_Param.fScapRerrPerturb=0;
	g_MCRPerturb.m_Param.fScapTrepPerturb=0;
	g_MCRPerturb.m_Param.fScapRchkPerturb=0;
	g_MCRPerturb.m_Param.fScapTchkPerturb=0;

	g_MCRPerturb.m_Param.fBreakerRerrPerturb=0;
	g_MCRPerturb.m_Param.fBreakerTrepPerturb=0;
	g_MCRPerturb.m_Param.fBreakerRchkPerturb=0;
	g_MCRPerturb.m_Param.fBreakerTchkPerturb=0;
	g_MCRPerturb.m_Param.fBreakerToprPerturb=0;

	g_MCRPerturb.m_Param.fDisconnectorRerrPerturb=0;
	g_MCRPerturb.m_Param.fDisconnectorTrepPerturb=0;
	g_MCRPerturb.m_Param.fDisconnectorRchkPerturb=0;
	g_MCRPerturb.m_Param.fDisconnectorTchkPerturb=0;
	g_MCRPerturb.m_Param.fDisconnectorToprPerturb=0;
	g_MCRPerturb.m_Param.fDisconnectorTSwitchPerturb=0;

	RefreshUI();
}

void CMCRPerturbSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char	szValue[260];

	GetDlgItem(IDC_PERTURB_NUM)->GetWindowText(szValue, 260);			g_MCRPerturb.m_Param.nPerturbNum=atoi(szValue);
	g_MCRPerturb.m_Param.nPerturbType = ((CButton*)GetDlgItem(IDC_BIPERTURB))->GetCheck();

	GetDlgItem(IDC_BUS_RERR)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fBusRerrPerturb=atof(szValue);
	GetDlgItem(IDC_BUS_TREP)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fBusTrepPerturb=atof(szValue);
	GetDlgItem(IDC_BUS_RCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fBusRchkPerturb=atof(szValue);
	GetDlgItem(IDC_BUS_TCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fBusTchkPerturb=atof(szValue);

	GetDlgItem(IDC_LINE_RERR)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fLineRerrPerturb=atof(szValue);
	GetDlgItem(IDC_LINE_TREP)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fLineTrepPerturb=atof(szValue);
	GetDlgItem(IDC_LINE_RCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fLineRchkPerturb=atof(szValue);
	GetDlgItem(IDC_LINE_TCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fLineTchkPerturb=atof(szValue);

	GetDlgItem(IDC_TRAN_RERR)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fTranRerrPerturb=atof(szValue);
	GetDlgItem(IDC_TRAN_TREP)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fTranTrepPerturb=atof(szValue);
	GetDlgItem(IDC_TRAN_RCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fTranRchkPerturb=atof(szValue);
	GetDlgItem(IDC_TRAN_TCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fTranTchkPerturb=atof(szValue);

	GetDlgItem(IDC_SCAP_RERR)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fScapRerrPerturb=atof(szValue);
	GetDlgItem(IDC_SCAP_TREP)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fScapTrepPerturb=atof(szValue);
	GetDlgItem(IDC_SCAP_RCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fScapRchkPerturb=atof(szValue);
	GetDlgItem(IDC_SCAP_TCHK)->GetWindowText(szValue, 260);				g_MCRPerturb.m_Param.fScapTchkPerturb=atof(szValue);

	GetDlgItem(IDC_BREAKER_RERR)->GetWindowText(szValue, 260);			g_MCRPerturb.m_Param.fBreakerRerrPerturb=atof(szValue);
	GetDlgItem(IDC_BREAKER_TREP)->GetWindowText(szValue, 260);			g_MCRPerturb.m_Param.fBreakerTrepPerturb=atof(szValue);
	GetDlgItem(IDC_BREAKER_RCHK)->GetWindowText(szValue, 260);			g_MCRPerturb.m_Param.fBreakerRchkPerturb=atof(szValue);
	GetDlgItem(IDC_BREAKER_TCHK)->GetWindowText(szValue, 260);			g_MCRPerturb.m_Param.fBreakerTchkPerturb=atof(szValue);
	GetDlgItem(IDC_BREAKER_TOPR)->GetWindowText(szValue, 260);			g_MCRPerturb.m_Param.fBreakerToprPerturb=atof(szValue);

	GetDlgItem(IDC_DISCONNECTOR_RERR)->GetWindowText(szValue, 260);		g_MCRPerturb.m_Param.fDisconnectorRerrPerturb=atof(szValue);
	GetDlgItem(IDC_DISCONNECTOR_TREP)->GetWindowText(szValue, 260);		g_MCRPerturb.m_Param.fDisconnectorTrepPerturb=atof(szValue);
	GetDlgItem(IDC_DISCONNECTOR_RCHK)->GetWindowText(szValue, 260);		g_MCRPerturb.m_Param.fDisconnectorRchkPerturb=atof(szValue);
	GetDlgItem(IDC_DISCONNECTOR_TCHK)->GetWindowText(szValue, 260);		g_MCRPerturb.m_Param.fDisconnectorTchkPerturb=atof(szValue);
	GetDlgItem(IDC_DISCONNECTOR_TOPR)->GetWindowText(szValue, 260);		g_MCRPerturb.m_Param.fDisconnectorToprPerturb=atof(szValue);
	GetDlgItem(IDC_DISCONNECTOR_TSWITCH)->GetWindowText(szValue, 260);	g_MCRPerturb.m_Param.fDisconnectorTSwitchPerturb=atof(szValue);

	if (g_MCRPerturb.m_Param.nPerturbNum < 0)
		g_MCRPerturb.m_Param.nPerturbNum=0;
	else if (g_MCRPerturb.m_Param.nPerturbNum > 20)
		g_MCRPerturb.m_Param.nPerturbNum=20;

	OnOK();
}

void CMCRPerturbSetDialog::OnBnClickedLoadParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�������߿ɿ����㶯�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_MCRPerturb.ReadParamFile(dlg.GetPathName());
	RefreshUI();
}

void CMCRPerturbSetDialog::OnBnClickedSaveParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("���������߿ɿ����㶯�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_MCRPerturb.SaveParamFile(dlg.GetPathName());
}
