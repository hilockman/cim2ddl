
// MCReliabilityDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCReliabilityUIDlg.h"
#include "MCRPerturbSetDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

extern	unsigned int __stdcall  MCREstimateConThreaad(void* lParam);

// CMCReliabilityDlg �Ի���

CMCReliabilityDlg::CMCReliabilityDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMCReliabilityDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_fFModeRThreshold = 0.000001;
	m_fFModeUThreshold = 0.001;

	m_bFCutPlan = FALSE;
	m_bExcludeCommon = FALSE;
	m_bExcludeSwitch = FALSE;
	m_bBreakerFaultFailure = TRUE;

	m_nLifeTime = 25;
	m_fEValueRatio = 4;
	m_fEPrice = 0.5;
	m_fRecip = 12;
	m_fPowerFactor = 0.93;

	m_nMCRAlgNum = 0;
	m_hMCRAlgHandle = INVALID_HANDLE_VALUE;
}

void CMCReliabilityDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_FCUT_ARRANGE, m_bFCutPlan);
	DDX_Text(pDX, IDC_FMODE_RTHRESHOLD, m_fFModeRThreshold);
	DDX_Text(pDX, IDC_FMODE_UTHRESHOLD, m_fFModeUThreshold);
	DDX_Check(pDX, IDC_EXCLUDE_COMMON, m_bExcludeCommon);
	DDX_Check(pDX, IDC_EXCLUDE_SWITCH, m_bExcludeSwitch);
	DDX_Check(pDX, IDC_FAULT_FAILURE, m_bBreakerFaultFailure);
	DDX_Text(pDX, IDC_ECON_LIFETIME, m_nLifeTime);
	DDX_Text(pDX, IDC_ECON_EVALUERATIO, m_fEValueRatio);
	DDV_MinMaxDouble(pDX, m_fEValueRatio, 1, 1000000000);
	DDX_Text(pDX, IDC_ECON_PRICE, m_fEPrice);
	DDX_Text(pDX, IDC_ECON_RECIP, m_fRecip);
	DDX_Text(pDX, IDC_ECON_POWERFACTOR, m_fPowerFactor);
}

BEGIN_MESSAGE_MAP(CMCReliabilityDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_EXPORT_DATACFG, &CMCReliabilityDlg::OnBnClickedExportDatacfg)
	ON_BN_CLICKED(IDC_RELIABILITY, &CMCReliabilityDlg::OnBnClickedReliability)
	ON_BN_CLICKED(IDC_CLEAR, &CMCReliabilityDlg::OnBnClickedClear)
	ON_BN_CLICKED(IDC_LOAD_FILE, &CMCReliabilityDlg::OnBnClickedLoadFile)
	ON_BN_CLICKED(IDC_SAVE_FILE, &CMCReliabilityDlg::OnBnClickedSaveFile)
	ON_BN_CLICKED(IDC_MCRPERTURB, &CMCReliabilityDlg::OnBnClickedMcrperturb)
	ON_BN_CLICKED(IDC_EXCEL, &CMCReliabilityDlg::OnBnClickedExcel)

	ON_MESSAGE(WM_ESTIMATEBEG, OnMCRCalculationBegin)
	ON_MESSAGE(WM_ESTIMATING, OnMCRCalculating)
	ON_MESSAGE(WM_ESTIMATEEND, OnMCRCalculationEnded)
END_MESSAGE_MAP()


// CMCReliabilityDlg ��Ϣ��������

BOOL CMCReliabilityDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	CRect	rectDummy;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndMCRParam.SetMCRParam(&g_MCRPhyData.m_MCRParam);
	m_wndMCRParam. Create(IDD_MCRPARAM_DIALOG, &m_wndTab);
	m_wndMCRPhyData.Create(IDD_MCRPHYDATA_DIALOG, &m_wndTab);
	m_wndMCRAlgData.Create(IDD_MCRALGDATA_DIALOG, &m_wndTab);
	m_wndMCRMinCut.Create(IDD_MCRMINCUT_RESULT_DIALOG, &m_wndTab);
	m_wndMCRFMode.Create(IDD_MCRFMODE_RESULT_DIALOG, &m_wndTab);
	m_wndMCRPerturb.Create(IDD_MCRPERTURB_RESULT_DIALOG, &m_wndTab);

	m_wndTab.AddTab (&m_wndMCRParam, _T("�ɿ��Բ���"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCRPhyData, _T("ģ������"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCRAlgData, _T("��������"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCRMinCut, _T("·���"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCRFMode, _T("������"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCRPerturb, _T("�ɿ����㶯"), -1, FALSE);

	m_wndTab.SetActiveTab(1);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CMCReliabilityDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CMCReliabilityDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMCReliabilityDlg::OnBnClickedExportDatacfg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�������������ݿ������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_MCRPhyData.ExportMCRTableField(dlg.GetPathName());
}

void CMCReliabilityDlg::PrintMessage(const char* lpszMesg)
{
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);

	int	iExt = GetTextLen(lpszMesg);
	if (iExt > pListBox->GetHorizontalExtent())
		pListBox->SetHorizontalExtent(iExt);
	pListBox->AddString(lpszMesg);
	pListBox->SetCurSel(pListBox->GetCount()-1);
}

int CMCReliabilityDlg::GetTextLen(LPCTSTR lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC* pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(lpszText, (int) _tcslen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(lpszText, (int) _tcslen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CMCReliabilityDlg::OnBnClickedLoadFile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�������߿ɿ����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	if (g_MCRPhyData.ReadPhyFile(dlg.GetPathName()))
		GetDlgItem(IDC_MCDATA_FILE)->SetWindowText(g_MCRPhyData.m_strMCDataFileName.c_str());

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	::PrintMessage("װ�ؿɿ��Լ���ģ�� [%s] ��ɣ���ʱ %d ����", g_MCRPhyData.m_strMCDataFileName.c_str(), nDur);

	m_wndMCRPhyData.Refresh();

	m_wndTab.SetActiveTab(1);
}

void CMCReliabilityDlg::OnBnClickedSaveFile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;
	if (g_MCRPhyData.m_strMCDataFileName.empty())
	{
		CString	fileExt=_T("xml");
		CString	defaultFileName=_T("");
		CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
		DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

		CFileDialog	dlg(FALSE, fileExt,
			defaultFileName,
			dwFlags,
			fileFilter,
			NULL);

		dlg.m_ofn.lpstrTitle=_T("���������߿ɿ��Լ����ļ�");
		dlg.m_ofn.lpstrInitialDir=_T("");
		dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

		if (dlg.DoModal() == IDCANCEL)
			return;


		dBeg=clock();
		g_MCRPhyData.SavePhyFile(dlg.GetPathName());
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		::PrintMessage("����ɿ��Լ���ģ�� [%s] ��ɣ���ʱ %d ����", g_MCRPhyData.m_strMCDataFileName.c_str(), nDur);

		g_MCRPhyData.m_strMCDataFileName = dlg.GetPathName();
		GetDlgItem(IDC_MCDATA_FILE)->SetWindowText(g_MCRPhyData.m_strMCDataFileName.c_str());
	}
	else
	{
		dBeg=clock();
		g_MCRPhyData.SavePhyFile(g_MCRPhyData.m_strMCDataFileName.c_str());
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		::PrintMessage("����ɿ��Լ���ģ�� [%s] ��ɣ���ʱ %d ����", g_MCRPhyData.m_strMCDataFileName.c_str(), nDur);
	}
}

void CMCReliabilityDlg::OnBnClickedClear()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	pListBox->ResetContent();
}

#define _MultiThread
void CMCReliabilityDlg::OnBnClickedReliability()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	char	szTempPath[260], szModelFileName[260], szOutputFileName[260];
	GetTempPath(260, szTempPath);
	sprintf(szModelFileName, "%s/%s", szTempPath, g_lpszReliableModelFileName);
	sprintf(szOutputFileName, "%s/%s", szTempPath, g_lpszReliableResultFileName);

	g_MCRPhyData.PrevReliabilityEvaluate();
	g_MCRAlgorithm.ReadData(&g_MCRPhyData, szModelFileName);

#ifdef _MultiThread
	{
		unsigned int	nChildThreadID;
		tagMCRThreadInfo*	pInfo=(tagMCRThreadInfo*)malloc(sizeof(tagMCRThreadInfo));
		pInfo->nParentThreadID = GetCurrentThreadId();
		pInfo->nThreadNum = 10;

		pInfo->bFault1Plan =		m_bFCutPlan;	//	������һ�׸�Ԥ����
		pInfo->bExCommon =			m_bExcludeCommon;		//	�����ǹ�ģ
		pInfo->bExSwitch =			m_bExcludeSwitch;		//	�������л�
		pInfo->bBreakerFaultFailure =		m_bBreakerFaultFailure;	//	��·�����Ϲ���ʧЧ����

		pInfo->fFmodeRThreshold =	m_fFModeRThreshold;
		pInfo->fFmodeUThreshold =	m_fFModeUThreshold;
		pInfo->nLifeTime =			m_nLifeTime;
		pInfo->fEValueRatio =		m_fEValueRatio;
		pInfo->fEPrice =			m_fEPrice;
		pInfo->fRecip =				m_fRecip;
		pInfo->fPowerFactor =		m_fPowerFactor;

		strcpy(pInfo->szResultXmlFile, szOutputFileName);
		m_hMCRAlgHandle = (HANDLE)_beginthreadex(NULL, 0, MCREstimateConThreaad, (void*)pInfo, 0, &nChildThreadID);
	}
#else
	{
		g_MCRAlgorithm.CalculateAllLoadReliablity(m_bFCutPlan, m_bExcludeCommon, m_bExcludeSwitch, m_bBreakerFaultFailure);
		//goto _OUT_ ;
		g_MCRAlgorithm.CalculateAllGenReliablity(m_bFCutPlan, m_bExcludeCommon, m_bExcludeSwitch, m_bBreakerFaultFailure);
		g_MCRAlgorithm.CalculateAugLoadReliablity(&g_MCRPhyData, m_bFCutPlan, m_bExcludeCommon, m_bExcludeSwitch, m_bBreakerFaultFailure);
		g_MCRAlgorithm.CalculateAugGenReliablity (&g_MCRPhyData, m_bFCutPlan, m_bExcludeCommon, m_bExcludeSwitch, m_bBreakerFaultFailure);

		g_MCRPhyData.MCRSysIndex();
		g_MCRPhyData.MCRDevIndex();
		g_MCRPhyData.MCREconomy(m_nLifeTime, m_fEPrice, m_fRecip, m_fEValueRatio, m_fPowerFactor);

		::PrintMessage("�ɿ���ָ��������");

		g_MCRPhyData.SaveMCReliabilityResult(szOutputFileName, m_fFModeRThreshold, m_fFModeUThreshold);

_OUT_:	;

		m_wndMCRPhyData.Refresh();
		m_wndMCRAlgData.Refresh();
		m_wndMCRMinCut.Refresh();
		m_wndMCRFMode.Refresh();

		m_wndTab.SetActiveTab(4);

		::PrintMessage("�ɿ��Լ������");
	}
#endif // _MultiThread
}

void CMCReliabilityDlg::OnBnClickedMcrperturb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CMCRPerturbSetDialog	dlg;
	if (dlg.DoModal() != IDOK)
		return;

	UpdateData();

	clock_t	dBeg,dEnd;
	int		nDur;

	char	szTempPath[260], szModelFileName[260], szOutputFileName[260];
	GetTempPath(260, szTempPath);
	sprintf(szModelFileName, "%s/%s", szTempPath, g_lpszReliableModelFileName);
	sprintf(szOutputFileName, "%s/%s", szTempPath, g_lpszReliablePerturbFileName);

	dBeg=clock();

	g_MCRPhyData.PrevReliabilityEvaluate();
	g_MCRAlgorithm.ReadData(&g_MCRPhyData, szModelFileName);
	g_MCRAlgorithm.CalculateAllLoadReliablity(m_bFCutPlan, m_bExcludeCommon, m_bExcludeSwitch, m_bBreakerFaultFailure);
	g_MCRAlgorithm.CalculateAllGenReliablity(m_bFCutPlan, m_bExcludeCommon, m_bExcludeSwitch, m_bBreakerFaultFailure);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	::PrintMessage("�ɿ��Թ���ģʽ������ɣ���ʱ %d ����", nDur);

	g_MCRPhyData.MCRSysIndex();
	g_MCRPhyData.SaveMCReliabilityPerturbResult(szOutputFileName);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	::PrintMessage("�ɿ���ָ�������ɣ���ʱ %d ����", nDur);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	::PrintMessage("�ɿ����㶯������ɣ���ʱ %d ����", nDur);

	m_wndMCRPerturb.Refresh();

	m_wndTab.SetActiveTab(5);
}

void CMCReliabilityDlg::OnBnClickedExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS;*.xlsx;*.XLSX|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	m_wndMCRMinCut.SaveAsExcel(&xls);
	m_wndMCRFMode.SaveAsExcel(&xls);
	m_wndMCRPerturb.SaveAsExcel(&xls);

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(dlg.GetPathName());
}

LRESULT CMCReliabilityDlg::OnMCRCalculationBegin(WPARAM wParam, LPARAM lParam)
{
	m_nMCRAlgNum = 0;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetRange32(0, (int)wParam);

	PrintMessage("���㿪ʼ\n");
	return 0;
}

LRESULT CMCReliabilityDlg::OnMCRCalculating(WPARAM wParam, LPARAM lParam)
{
	m_nMCRAlgNum += (int)wParam;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos(m_nMCRAlgNum);
	return 0;
}

LRESULT CMCReliabilityDlg::OnMCRCalculationEnded(WPARAM wParam, LPARAM lParam)
{
	m_nMCRAlgNum = 0;
	if (m_hMCRAlgHandle != INVALID_HANDLE_VALUE)
		CloseHandle(m_hMCRAlgHandle);
	m_hMCRAlgHandle = INVALID_HANDLE_VALUE;

	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos((int)wParam);

	m_wndMCRPhyData.Refresh();
	m_wndMCRAlgData.Refresh();
	m_wndMCRMinCut.Refresh();
	m_wndMCRFMode.Refresh();
	m_wndTab.SetActiveTab(4);

	PrintMessage("�������\n");

	return 0;
}
