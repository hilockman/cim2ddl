#pragma once


// CMCAlgDataDialog �Ի���

class CMCRAlgDataDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRAlgDataDialog)

public:
	CMCRAlgDataDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRAlgDataDialog();

// �Ի�������
	enum { IDD = IDD_MCRALGDATA_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeDatatypeCombo();
	afx_msg void OnBnClickedFormModel();
	DECLARE_MESSAGE_MAP()

private:
	void RefreshGenList();
	void RefreshLoadList();
	void RefreshCompList();
	void RefreshNodeList();
	void RefreshCommList();
	//void RefreshSwitchList();
public:
	void Refresh();
};
