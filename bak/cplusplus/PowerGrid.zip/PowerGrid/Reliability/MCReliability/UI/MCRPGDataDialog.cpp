// PGDataDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRPGDataDialog.h"


// CPGDataDialog �Ի���

IMPLEMENT_DYNAMIC(CMCRPGDataDialog, CDialog)

CMCRPGDataDialog::CMCRPGDataDialog(CMCRPhyData* pPhy, CWnd* pParent /*=NULL*/)
	: CDialog(CMCRPGDataDialog::IDD, pParent)
{
	m_pMCData = pPhy;
}

CMCRPGDataDialog::~CMCRPGDataDialog()
{
}

void CMCRPGDataDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMCRPGDataDialog, CDialog)
	ON_WM_PAINT()
	ON_CBN_SELCHANGE(IDC_SUB_COMBO, &CMCRPGDataDialog::OnCbnSelchangeSubCombo)
	ON_CBN_SELCHANGE(IDC_VOLT_COMBO, &CMCRPGDataDialog::OnCbnSelchangeVoltCombo)
	ON_BN_CLICKED(IDC_FORM_MODEL, &CMCRPGDataDialog::OnBnClickedFormModel)
END_MESSAGE_MAP()


// CPGDataDialog ��Ϣ��������

BOOL CMCRPGDataDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectDummy;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndDataTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndDataTab.EnableAutoColor (TRUE);
	m_wndDataTab.EnableTabSwap (FALSE);

	if (!m_wndListBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndDataTab, 11))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBus.SetExtendedStyle(m_wndListBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListBus.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); i++)
		m_wndListBus.InsertColumn(i+1, PGGetFieldDesp(PG_BUSBARSECTION, g_MCPhyBusField[i].nMDBField),	LVCFMT_LEFT,	100);

	if (!m_wndListLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndDataTab, 12))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLine.SetExtendedStyle(m_wndListLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListLine.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); i++)
		m_wndListLine.InsertColumn(i+1, PGGetFieldDesp(PG_ACLINESEGMENT, g_MCPhyLineField[i].nMDBField),	LVCFMT_LEFT,	100);

	if (!m_wndListTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndDataTab, 13))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListTran.SetExtendedStyle(m_wndListTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListTran.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); i++)
		m_wndListTran.InsertColumn(i+1, PGGetFieldDesp(PG_TRANSFORMERWINDING, g_MCPhyTranField[i].nMDBField),	LVCFMT_LEFT,	100);

	if (!m_wndListScap.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndDataTab, 14))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListScap.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListScap.SetExtendedStyle(m_wndListScap.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListScap.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListScap.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); i++)
		m_wndListScap.InsertColumn(i+1, PGGetFieldDesp(PG_SERIESCOMPENSATOR, g_MCPhyScapField[i].nMDBField),	LVCFMT_LEFT,	100);

	if (!m_wndListBreaker.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndDataTab, 15))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBreaker.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBreaker.SetExtendedStyle(m_wndListBreaker.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBreaker.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListBreaker.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); i++)
		m_wndListBreaker.InsertColumn(i+1, PGGetFieldDesp(PG_BREAKER, g_MCPhyBreakerField[i].nMDBField),	LVCFMT_LEFT,	100);

	if (!m_wndListDisconnector.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndDataTab, 16))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListDisconnector.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListDisconnector.SetExtendedStyle(m_wndListDisconnector.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListDisconnector.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListDisconnector.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); i++)
		m_wndListDisconnector.InsertColumn(i+1, PGGetFieldDesp(PG_DISCONNECTOR, g_MCPhyDisconnectorField[i].nMDBField),	LVCFMT_LEFT,	100);

	m_wndDataTab.AddTab (&m_wndListBus, _T("ĸ��"), -1, FALSE);
	m_wndDataTab.AddTab (&m_wndListLine, _T("��·"), -1, FALSE);
	m_wndDataTab.AddTab (&m_wndListTran, _T("��ѹ��"), -1, FALSE);
	m_wndDataTab.AddTab (&m_wndListScap, _T("�����翹"), -1, FALSE);
	m_wndDataTab.AddTab (&m_wndListBreaker, _T("��·��"), -1, FALSE);
	m_wndDataTab.AddTab (&m_wndListDisconnector, _T("���뿪��"), -1, FALSE);

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pComboBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRPGDataDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndDataTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

void CMCRPGDataDialog::OnFetchData()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char		szSub[MDB_CHARLEN], szVolt[MDB_CHARLEN_SHORTER];
	CComboBox*	pComboBox;
	int			nSel;

	memset(szSub, 0, MDB_CHARLEN);
	memset(szVolt, 0, MDB_CHARLEN_SHORTER);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel != CB_ERR)
		pComboBox->GetLBText(nSel, szSub);

	pComboBox=(CComboBox*)GetDlgItem(IDC_VOLT_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel != CB_ERR && nSel != 0)
		pComboBox->GetLBText(nSel, szVolt);

	RefreshPGBusList			(g_pPGBlock, szSub, szVolt);
	RefreshPGLineList			(g_pPGBlock, szSub, szVolt);
	RefreshPGTranList			(g_pPGBlock, szSub, szVolt);
	RefreshPGScapList			(g_pPGBlock, szSub, szVolt);
	RefreshPGBreakerList		(g_pPGBlock, szSub, szVolt);
	RefreshPGDisconnectorList	(g_pPGBlock, szSub, szVolt);
}

void CMCRPGDataDialog::RefreshPGBusList(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nVolt, nDev, nField;
	int		nRow, nCol;
	char	szBuf[260];

	const int	nFieldNum = sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = m_wndListBus.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = m_wndListBus.GetNextSelectedItem(pos);
	m_wndListBus.DeleteAllItems();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	nRow=0;
	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}

		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
		{
			if (pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
				continue;

			sprintf(szBuf, "%d", nRow+1);	m_wndListBus.InsertItem(nRow, szBuf);		m_wndListBus.SetItemData(nRow, nRow);
			nCol=1;
			for (nField=0; nField<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); nField++)
			{
				if (g_MCPhyBusField[nField].nMDBField >= 0)
				{
					PGGetRecordValue(pPGBlock, PG_BUSBARSECTION, g_MCPhyBusField[nField].nMDBField, nDev, szBuf);
					m_wndListBus.SetItemText(nRow, nCol, szBuf);
				}
				nCol++;
			}
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBus.GetColumnWidth(nCol);
		m_wndListBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBus.GetColumnWidth(nCol);

		m_wndListBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < m_wndListBus.GetItemCount())
	{
		m_wndListBus.SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		m_wndListBus.EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPGDataDialog::RefreshPGLineList(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nVolt, nDev, nField;
	int		nRow, nCol;
	char	szBuf[260];

	const int	nFieldNum = sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = m_wndListLine.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = m_wndListLine.GetNextSelectedItem(pos);
	m_wndListLine.DeleteAllItems();


	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	nRow=0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (stricmp(lpszSub, pPGBlock->m_ACLineSegmentArray[nDev].szSubI) != 0 &&
			stricmp(lpszSub, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ) != 0)
			continue;

		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI) != 0 &&
				stricmp(lpszVolt, pPGBlock->m_ACLineSegmentArray[nDev].szVoltJ) != 0)
				continue;
		}

		sprintf(szBuf, "%d", nRow+1);	m_wndListLine.InsertItem(nRow, szBuf);		m_wndListLine.SetItemData(nRow, nRow);
		nCol=1;
		for (nField=0; nField<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); nField++)
		{
			if (g_MCPhyLineField[nField].nMDBField >= 0)
			{
				PGGetRecordValue(pPGBlock, PG_ACLINESEGMENT, g_MCPhyLineField[nField].nMDBField, nDev, szBuf);
				m_wndListLine.SetItemText(nRow, nCol++, szBuf);
			}
		}
		nRow++;
	}

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}

		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
		{
			sprintf(szBuf, "%d", nRow+1);	m_wndListLine.InsertItem(nRow, szBuf);		m_wndListLine.SetItemData(nRow, nRow);
			nCol=1;
			for (nField=0; nField<sizeof(g_MCPhyLoadField)/sizeof(tagMCRPhyField); nField++)
			{
				if (g_MCPhyLoadField[nField].nMDBField >= 0)
				{
					PGGetRecordValue(pPGBlock, PG_ENERGYCONSUMER, g_MCPhyLoadField[nField].nMDBField, nDev, szBuf);
					m_wndListLine.SetItemText(nRow, nCol++, szBuf);
				}
			}
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLine.GetColumnWidth(nCol);
		m_wndListLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLine.GetColumnWidth(nCol);

		m_wndListLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < m_wndListLine.GetItemCount())
	{
		m_wndListLine.SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		m_wndListLine.EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPGDataDialog::RefreshPGTranList(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nDev, nField;
	int		nRow, nCol;
	char	szBuf[260];

	const int	nFieldNum = sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = m_wndListTran.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = m_wndListTran.GetNextSelectedItem(pos);
	m_wndListTran.DeleteAllItems();

	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	nRow=0;
	for (nDev=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(pPGBlock->m_TransformerWindingArray[nDev].szVoltI, lpszVolt) != 0 && stricmp(pPGBlock->m_TransformerWindingArray[nDev].szVoltJ, lpszVolt) != 0)
				continue;
		}

		sprintf(szBuf, "%d", nRow+1);	m_wndListTran.InsertItem(nRow, szBuf);		m_wndListTran.SetItemData(nRow, nRow);
		nCol=1;
		for (nField=0; nField<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); nField++)
		{
			if (g_MCPhyLoadField[nField].nMDBField >= 0)
			{
				PGGetRecordValue(pPGBlock, PG_TRANSFORMERWINDING, g_MCPhyTranField[nField].nMDBField, nDev, szBuf);
				m_wndListTran.SetItemText(nRow, nCol++, szBuf);
			}
		}
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListTran.GetColumnWidth(nCol);
		m_wndListTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListTran.GetColumnWidth(nCol);

		m_wndListTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < m_wndListTran.GetItemCount())
	{
		m_wndListTran.SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		m_wndListTran.EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPGDataDialog::RefreshPGScapList(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nVolt, nDev, nField;
	int		nRow, nCol;
	char	szBuf[260];

	const int	nFieldNum = sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField);
	int		nSelItem=-1;
	POSITION	pos = m_wndListScap.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = m_wndListScap.GetNextSelectedItem(pos);
	m_wndListScap.DeleteAllItems();

	nRow=0;
	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSeriesCompensatorRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSeriesCompensatorRange; nDev++)
		{
			sprintf(szBuf, "%d", nRow+1);	m_wndListScap.InsertItem(nRow, szBuf);		m_wndListScap.SetItemData(nRow, nRow);
			nCol=1;
			for (nField=0; nField<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); nField++)
			{
				if (g_MCPhyScapField[nField].nMDBField >= 0)
				{
					PGGetRecordValue(pPGBlock, PG_SERIESCOMPENSATOR, g_MCPhyScapField[nField].nMDBField, nDev, szBuf);
					m_wndListScap.SetItemText(nRow, nCol++, szBuf);
				}
			}
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListScap.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListScap.GetColumnWidth(nCol);
		m_wndListScap.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListScap.GetColumnWidth(nCol);

		m_wndListScap.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < m_wndListScap.GetItemCount())
	{
		m_wndListScap.SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		m_wndListScap.EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPGDataDialog::RefreshPGBreakerList(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nVolt, nDev, nRow, nCol, nField;
	char	szBuf[260];

	const int	nFieldNum = sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = m_wndListBreaker.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = m_wndListBreaker.GetNextSelectedItem(pos);
	m_wndListBreaker.DeleteAllItems();

	nRow=0;
	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;

	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
		{
			sprintf(szBuf, "%d", nRow+1);	m_wndListBreaker.InsertItem(nRow, szBuf);		m_wndListBreaker.SetItemData(nRow, nRow);
			nCol=1;
			for (nField=0; nField<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); nField++)
			{
				if (g_MCPhyBreakerField[nField].nMDBField >= 0)
				{
					PGGetRecordValue(pPGBlock, PG_BREAKER, g_MCPhyBreakerField[nField].nMDBField, nDev, szBuf);
					m_wndListBreaker.SetItemText(nRow, nCol++, szBuf);
				}
			}
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBreaker.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBreaker.GetColumnWidth(nCol);
		m_wndListBreaker.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBreaker.GetColumnWidth(nCol);

		m_wndListBreaker.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < m_wndListBreaker.GetItemCount())
	{
		m_wndListBreaker.SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		m_wndListBreaker.EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPGDataDialog::RefreshPGDisconnectorList(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt)
{
	int		nSub, nVolt, nDev, nRow, nCol, nField;
	char	szBuf[260];

	const int	nFieldNum = sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = m_wndListDisconnector.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = m_wndListDisconnector.GetNextSelectedItem(pos);
	m_wndListDisconnector.DeleteAllItems();

	nRow=0;
	nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, lpszSub);
	if (nSub < 0)
		return;
	for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
	{
		if (strlen(lpszVolt) > 0)
		{
			if (stricmp(lpszVolt, pPGBlock->m_VoltageLevelArray[nVolt].szName) != 0)
				continue;
		}
		for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
		{
			sprintf(szBuf, "%d", nRow+1);	m_wndListDisconnector.InsertItem(nRow, szBuf);		m_wndListDisconnector.SetItemData(nRow, nRow);
			nCol=1;
			for (nField=0; nField<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); nField++)
			{
				if (g_MCPhyDisconnectorField[nField].nMDBField >= 0)
				{
					PGGetRecordValue(pPGBlock, PG_DISCONNECTOR, g_MCPhyDisconnectorField[nField].nMDBField, nDev, szBuf);
					m_wndListDisconnector.SetItemText(nRow, nCol++, szBuf);
				}
			}
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListDisconnector.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListDisconnector.GetColumnWidth(nCol);
		m_wndListDisconnector.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListDisconnector.GetColumnWidth(nCol);

		m_wndListDisconnector.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < m_wndListDisconnector.GetItemCount())
	{
		m_wndListDisconnector.SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		m_wndListDisconnector.EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPGDataDialog::OnCbnSelchangeSubCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nSel;
	char		szSub[MDB_CHARLEN], szVolt[MDB_CHARLEN_SHORTER];
	CComboBox*	pComboBox;

	memset(szSub, 0, MDB_CHARLEN);
	memset(szVolt, 0, MDB_CHARLEN_SHORTER);

	pComboBox=(CComboBox*)GetDlgItem(IDC_VOLT_COMBO);
	pComboBox->ResetContent();

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
		return;
	pComboBox->GetLBText(nSel, szSub);

	pComboBox=(CComboBox*)GetDlgItem(IDC_VOLT_COMBO);
	pComboBox->AddString("ȫ��");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]; i++)
	{
		if (strcmp(g_pPGBlock->m_VoltageLevelArray[i].szSub, szSub) != 0)
			continue;

		pComboBox->AddString(g_pPGBlock->m_VoltageLevelArray[i].szName);
	}
	OnFetchData();
}

void CMCRPGDataDialog::OnCbnSelchangeVoltCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnFetchData();
}

void CMCRPGDataDialog::OnBnClickedFormModel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char		szSub[MDB_CHARLEN], szVolt[MDB_CHARLEN_SHORTER];
	CComboBox*	pComboBox;
	int			nSel;

	memset(szSub, 0, MDB_CHARLEN);
	memset(szVolt, 0, MDB_CHARLEN_SHORTER);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel != CB_ERR)
		pComboBox->GetLBText(nSel, szSub);
	else
	{
		AfxMessageBox("��ȷ�����վ����");
		return;
	}

	pComboBox=(CComboBox*)GetDlgItem(IDC_VOLT_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel != CB_ERR && nSel != 0)
		pComboBox->GetLBText(nSel, szVolt);

	m_pMCData->PGMemDB2PhyData(g_pPGBlock, szSub, szVolt);

	EndDialog(IDOK);
}
