#pragma once
#include "../../../../Common/Excel/ExcelAccessor.h"

// CMCRLoadResultDialog �Ի���

class CMCRResultMinCutDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRResultMinCutDialog)

public:
	CMCRResultMinCutDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRResultMinCutDialog();

// �Ի�������
	enum { IDD = IDD_MCRMINCUT_RESULT_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedMcrDetail();
	afx_msg void OnNMClickLoadresultList(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndMinPathList, m_wndMCut1List, m_wndMCut2List, m_wndMCut3List;

public:
	void Refresh()
	{
		RefreshDeviceList();
	};

private:
	void RefreshDeviceList();
	void RefreshMinPathList(const short nDevType, const int nDevice);
	void RefreshMCu1O1List(const short nDevType, const int nDevice);
	void RefreshMCu1O2List(const short nDevType, const int nDevice);
	void RefreshMCu1O3List(const short nDevType, const int nDevice);

	void AppendString(std::string& strString, const char* lpszAppendString);

public:
	void SaveAsExcel(ExcelAccessor* pXls);
};
