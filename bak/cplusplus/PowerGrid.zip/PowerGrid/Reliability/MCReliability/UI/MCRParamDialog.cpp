// MCRParamDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRParamDialog.h"


// CMCRParamDialog �Ի���
static	unsigned char	m_bUIFrozen = 0;

IMPLEMENT_DYNAMIC(CMCRParamDialog, CDialog)

CMCRParamDialog::CMCRParamDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRParamDialog::IDD, pParent)
{
	m_pMCRParam = NULL;
}

CMCRParamDialog::~CMCRParamDialog()
{
}

void CMCRParamDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMCRParamDialog, CDialog)
	ON_BN_CLICKED(IDC_LOAD, &CMCRParamDialog::OnBnClickedLoad)
	ON_BN_CLICKED(IDC_SAVE, &CMCRParamDialog::OnBnClickedSave)
	ON_BN_CLICKED(IDC_IMPORT, &CMCRParamDialog::OnBnClickedImport)
	ON_EN_CHANGE(IDC_BUS_RERR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BUS_TREP, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BUS_RCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BUS_TCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BUS_TOPR, &CMCRParamDialog::OnEnChangeParam)

	ON_EN_CHANGE(IDC_LINE_RERR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_LINE_TREP, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_LINE_RCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_LINE_TCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_LINE_TOPR, &CMCRParamDialog::OnEnChangeParam)

	ON_EN_CHANGE(IDC_TRAN_RERR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_TRAN_TREP, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_TRAN_RCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_TRAN_TCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_TRAN_TOPR, &CMCRParamDialog::OnEnChangeParam)

	ON_EN_CHANGE(IDC_SCAP_RERR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_SCAP_TREP, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_SCAP_RCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_SCAP_TCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_SCAP_TOPR, &CMCRParamDialog::OnEnChangeParam)

	ON_EN_CHANGE(IDC_BREAKER_RERR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BREAKER_TREP, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BREAKER_RCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BREAKER_TCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BREAKER_TOPR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BREAKER_TSWITCH, &CMCRParamDialog::OnEnChangeParam)

	ON_EN_CHANGE(IDC_DISCONNECTOR_RERR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_DISCONNECTOR_TREP, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_DISCONNECTOR_RCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_DISCONNECTOR_TCHK, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_DISCONNECTOR_TOPR, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_DISCONNECTOR_TSWITCH, &CMCRParamDialog::OnEnChangeParam)

	ON_EN_CHANGE(IDC_BUS_INVEST, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_LINE_INVEST, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_TRAN_INVEST, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_SCAP_INVEST, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_BREAKER_INVEST, &CMCRParamDialog::OnEnChangeParam)
	ON_EN_CHANGE(IDC_DISCONNECTOR_INVEST, &CMCRParamDialog::OnEnChangeParam)
	ON_LBN_SELCHANGE(IDC_VOLT_LIST, &CMCRParamDialog::OnLbnSelchangeVoltList)
END_MESSAGE_MAP()

// CMCRParamDialog ��Ϣ��������

BOOL CMCRParamDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_VOLT_LIST);
	pListBox->ResetContent();
	for (i=0; i<g_nVoltageLevelNum; i++)
		pListBox->AddString(GetVoltageLevelName(i));
	pListBox->SetCurSel(0);

	RefreshMCRParam();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRParamDialog::RefreshMCRParam()
{
	char	szBuf[260];

	m_bUIFrozen = 1;

	sprintf(szBuf, "%f", m_pMCRParam->fBusRerr);				GetDlgItem(IDC_BUS_RERR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBusTrep);				GetDlgItem(IDC_BUS_TREP)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBusRchk);				GetDlgItem(IDC_BUS_RCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBusTchk);				GetDlgItem(IDC_BUS_TCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBusTopr);				GetDlgItem(IDC_BUS_TOPR)->SetWindowText(szBuf);

	sprintf(szBuf, "%f", m_pMCRParam->fLineRerr);				GetDlgItem(IDC_LINE_RERR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fLineTrep);				GetDlgItem(IDC_LINE_TREP)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fLineRchk);				GetDlgItem(IDC_LINE_RCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fLineTchk);				GetDlgItem(IDC_LINE_TCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fLineTopr);				GetDlgItem(IDC_LINE_TOPR)->SetWindowText(szBuf);

	sprintf(szBuf, "%f", m_pMCRParam->fTranRerr);				GetDlgItem(IDC_TRAN_RERR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fTranTrep);				GetDlgItem(IDC_TRAN_TREP)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fTranRchk);				GetDlgItem(IDC_TRAN_RCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fTranTchk);				GetDlgItem(IDC_TRAN_TCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fTranTopr);				GetDlgItem(IDC_TRAN_TOPR)->SetWindowText(szBuf);

	sprintf(szBuf, "%f", m_pMCRParam->fScapRerr);				GetDlgItem(IDC_SCAP_RERR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fScapTrep);				GetDlgItem(IDC_SCAP_TREP)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fScapRchk);				GetDlgItem(IDC_SCAP_RCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fScapTchk);				GetDlgItem(IDC_SCAP_TCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fScapTopr);				GetDlgItem(IDC_SCAP_TOPR)->SetWindowText(szBuf);

	sprintf(szBuf, "%f", m_pMCRParam->fBreakerRerr);			GetDlgItem(IDC_BREAKER_RERR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBreakerTrep);			GetDlgItem(IDC_BREAKER_TREP)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBreakerRchk);			GetDlgItem(IDC_BREAKER_RCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBreakerTchk);			GetDlgItem(IDC_BREAKER_TCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBreakerTopr);			GetDlgItem(IDC_BREAKER_TOPR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fBreakerTSwitch);			GetDlgItem(IDC_BREAKER_TSWITCH)->SetWindowText(szBuf);

	sprintf(szBuf, "%f", m_pMCRParam->fDisconnectorRerr);		GetDlgItem(IDC_DISCONNECTOR_RERR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fDisconnectorTrep);		GetDlgItem(IDC_DISCONNECTOR_TREP)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fDisconnectorRchk);		GetDlgItem(IDC_DISCONNECTOR_RCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fDisconnectorTchk);		GetDlgItem(IDC_DISCONNECTOR_TCHK)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fDisconnectorTopr);		GetDlgItem(IDC_DISCONNECTOR_TOPR)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_pMCRParam->fDisconnectorTSwitch);	GetDlgItem(IDC_DISCONNECTOR_TSWITCH)->SetWindowText(szBuf);

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_VOLT_LIST);
	int			nVolt=pListBox->GetCurSel();
	if (nVolt >= 0 && nVolt < g_nVoltageLevelNum)
	{
		sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fBusInvest);				GetDlgItem(IDC_BUS_INVEST)->SetWindowText(szBuf);
		sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fLineInvest);			GetDlgItem(IDC_LINE_INVEST)->SetWindowText(szBuf);
		sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fTranInvest);			GetDlgItem(IDC_TRAN_INVEST)->SetWindowText(szBuf);
		sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fScapInvest);			GetDlgItem(IDC_SCAP_INVEST)->SetWindowText(szBuf);
		sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fBreakerInvest);			GetDlgItem(IDC_BREAKER_INVEST)->SetWindowText(szBuf);
		sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fDisconnectorInvest);	GetDlgItem(IDC_DISCONNECTOR_INVEST)->SetWindowText(szBuf);
	}

	m_bUIFrozen = 0;
}

void CMCRParamDialog::OnEnChangeParam()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (m_bUIFrozen)
		return;

	char	szBuf[260];

	GetDlgItem(IDC_BUS_RERR)->GetWindowText(szBuf, 260);				m_pMCRParam->fBusRerr=atof(szBuf);
	GetDlgItem(IDC_BUS_TREP)->GetWindowText(szBuf, 260);				m_pMCRParam->fBusTrep=atof(szBuf);
	GetDlgItem(IDC_BUS_RCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fBusRchk=atof(szBuf);
	GetDlgItem(IDC_BUS_TCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fBusTchk=atof(szBuf);
	GetDlgItem(IDC_BUS_TOPR)->GetWindowText(szBuf, 260);				m_pMCRParam->fBusTopr=atof(szBuf);

	GetDlgItem(IDC_LINE_RERR)->GetWindowText(szBuf, 260);				m_pMCRParam->fLineRerr=atof(szBuf);
	GetDlgItem(IDC_LINE_TREP)->GetWindowText(szBuf, 260);				m_pMCRParam->fLineTrep=atof(szBuf);
	GetDlgItem(IDC_LINE_RCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fLineRchk=atof(szBuf);
	GetDlgItem(IDC_LINE_TCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fLineTchk=atof(szBuf);
	GetDlgItem(IDC_LINE_TOPR)->GetWindowText(szBuf, 260);				m_pMCRParam->fLineTopr=atof(szBuf);

	GetDlgItem(IDC_TRAN_RERR)->GetWindowText(szBuf, 260);				m_pMCRParam->fTranRerr=atof(szBuf);
	GetDlgItem(IDC_TRAN_TREP)->GetWindowText(szBuf, 260);				m_pMCRParam->fTranTrep=atof(szBuf);
	GetDlgItem(IDC_TRAN_RCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fTranRchk=atof(szBuf);
	GetDlgItem(IDC_TRAN_TCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fTranTchk=atof(szBuf);
	GetDlgItem(IDC_TRAN_TOPR)->GetWindowText(szBuf, 260);				m_pMCRParam->fTranTopr=atof(szBuf);

	GetDlgItem(IDC_SCAP_RERR)->GetWindowText(szBuf, 260);				m_pMCRParam->fScapRerr=atof(szBuf);
	GetDlgItem(IDC_SCAP_TREP)->GetWindowText(szBuf, 260);				m_pMCRParam->fScapTrep=atof(szBuf);
	GetDlgItem(IDC_SCAP_RCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fScapRchk=atof(szBuf);
	GetDlgItem(IDC_SCAP_TCHK)->GetWindowText(szBuf, 260);				m_pMCRParam->fScapTchk=atof(szBuf);
	GetDlgItem(IDC_SCAP_TOPR)->GetWindowText(szBuf, 260);				m_pMCRParam->fScapTopr=atof(szBuf);

	GetDlgItem(IDC_BREAKER_RERR)->GetWindowText(szBuf, 260);			m_pMCRParam->fBreakerRerr=atof(szBuf);
	GetDlgItem(IDC_BREAKER_TREP)->GetWindowText(szBuf, 260);			m_pMCRParam->fBreakerTrep=atof(szBuf);
	GetDlgItem(IDC_BREAKER_RCHK)->GetWindowText(szBuf, 260);			m_pMCRParam->fBreakerRchk=atof(szBuf);
	GetDlgItem(IDC_BREAKER_TCHK)->GetWindowText(szBuf, 260);			m_pMCRParam->fBreakerTchk=atof(szBuf);
	GetDlgItem(IDC_BREAKER_TOPR)->GetWindowText(szBuf, 260);			m_pMCRParam->fBreakerTopr=atof(szBuf);
	GetDlgItem(IDC_BREAKER_TSWITCH)->GetWindowText(szBuf, 260);			m_pMCRParam->fBreakerTSwitch=atof(szBuf);

	GetDlgItem(IDC_DISCONNECTOR_RERR)->GetWindowText(szBuf, 260);		m_pMCRParam->fDisconnectorRerr=atof(szBuf);
	GetDlgItem(IDC_DISCONNECTOR_TREP)->GetWindowText(szBuf, 260);		m_pMCRParam->fDisconnectorTrep=atof(szBuf);
	GetDlgItem(IDC_DISCONNECTOR_RCHK)->GetWindowText(szBuf, 260);		m_pMCRParam->fDisconnectorRchk=atof(szBuf);
	GetDlgItem(IDC_DISCONNECTOR_TCHK)->GetWindowText(szBuf, 260);		m_pMCRParam->fDisconnectorTchk=atof(szBuf);
	GetDlgItem(IDC_DISCONNECTOR_TOPR)->GetWindowText(szBuf, 260);		m_pMCRParam->fDisconnectorTopr=atof(szBuf);
	GetDlgItem(IDC_DISCONNECTOR_TSWITCH)->GetWindowText(szBuf, 260);	m_pMCRParam->fDisconnectorTSwitch=atof(szBuf);

	OnEnChangeEconomy();
}

void CMCRParamDialog::RefreshMCREconomy()
{
	char		szBuf[260];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_VOLT_LIST);
	int			nVolt=pListBox->GetCurSel();
	if (nVolt < 0 || nVolt >= g_nVoltageLevelNum)
		return;

	m_bUIFrozen = 1;

	sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fBusInvest);				GetDlgItem(IDC_BUS_INVEST)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fLineInvest);			GetDlgItem(IDC_LINE_INVEST)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fTranInvest);			GetDlgItem(IDC_TRAN_INVEST)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fScapInvest);			GetDlgItem(IDC_SCAP_INVEST)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fBreakerInvest);			GetDlgItem(IDC_BREAKER_INVEST)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pMCRParam->sMCREconomy[nVolt].fDisconnectorInvest);	GetDlgItem(IDC_DISCONNECTOR_INVEST)->SetWindowText(szBuf);

	m_bUIFrozen = 0;
}

void CMCRParamDialog::OnEnChangeEconomy()
{
	if (m_bUIFrozen)
		return;

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_VOLT_LIST);
	int			nVolt=pListBox->GetCurSel();
	if (nVolt < 0 || nVolt >= g_nVoltageLevelNum)
		return;

	char	szBuf[260];
	GetDlgItem(IDC_BUS_INVEST)->GetWindowText(szBuf, 260);				m_pMCRParam->sMCREconomy[nVolt].fBusInvest=atof(szBuf);
	GetDlgItem(IDC_LINE_INVEST)->GetWindowText(szBuf, 260);				m_pMCRParam->sMCREconomy[nVolt].fLineInvest=atof(szBuf);
	GetDlgItem(IDC_TRAN_INVEST)->GetWindowText(szBuf, 260);				m_pMCRParam->sMCREconomy[nVolt].fTranInvest=atof(szBuf);
	GetDlgItem(IDC_SCAP_INVEST)->GetWindowText(szBuf, 260);				m_pMCRParam->sMCREconomy[nVolt].fScapInvest=atof(szBuf);
	GetDlgItem(IDC_BREAKER_INVEST)->GetWindowText(szBuf, 260);			m_pMCRParam->sMCREconomy[nVolt].fBreakerInvest=atof(szBuf);
	GetDlgItem(IDC_DISCONNECTOR_INVEST)->GetWindowText(szBuf, 260);		m_pMCRParam->sMCREconomy[nVolt].fDisconnectorInvest=atof(szBuf);
}

void CMCRParamDialog::OnBnClickedLoad()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�������߿ɿ��Բ����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_MCRPhyData.ReadPhyRParamFile(dlg.GetPathName());
	RefreshMCRParam();
}

void CMCRParamDialog::OnBnClickedSave()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("���������߿ɿ��Բ����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_MCRPhyData.SavePhyRParamFile(dlg.GetPathName());
}

void CMCRParamDialog::OnBnClickedImport()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_MCRPhyData.ImportMCRPhyParam();

	PrintMessage("����������");
}

void CMCRParamDialog::OnLbnSelchangeVoltList()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshMCREconomy();
}
