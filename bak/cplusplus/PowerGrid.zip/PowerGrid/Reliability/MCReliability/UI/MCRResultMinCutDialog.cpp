// MCRLoadResultDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRResultMinCutDialog.h"


// CMCRLoadResultDialog �Ի���
static	char*	lpszLoadColumn[]=
{
	"�豸����",
	"�豸����",
	"����(MW)",
	"����ͣ����(��/��)",
	"����ͣ��ʱ��(Сʱ/��)",
	"Ԥ����ͣ����(��/��)",
	"Ԥ����ͣ��ʱ��(Сʱ/��)",
	"��ͣ����(��/��)",
	"��ͣ��ʱ��(Сʱ/��)",
	"�������������(MW/��)",
	"�����������������(MW/��)",
	"Ԥ�����������������(MW/��)",

	"ͣ������ռ����(%)",
	"ͣ��ʱ����ռ����(%)",
	"����������ռ����(%)",

	"�����ʱ(��)",
	"�������",
};

static	char*	m_lpszMinPathColumn[]=
{
	"·�����",
	"·���豸",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
	"������(��/��)",
	"����ʱ��(Сʱ)",
};

static	char*	lpszFault1Column[]=
{
	"���",
	"��������",
	"�����豸",
	"ͣ����",
	"ͣ��ʱ��",
	"ͣ���ʹ��׶�",
	"ͣ��ʱ�乱�׶�",
	"������Ϣ",
};
static	char*	lpszFault2Column[]=
{
	"���",
	"��������",
	"�����豸1",
	"�����豸2",
	"ͣ����(10E-3)",
	"ͣ��ʱ��",
	"ͣ���ʹ��׶�",
	"ͣ��ʱ�乱�׶�",
	"������Ϣ",
};
static	char*	lpszFault3Column[]=
{
	"���",
	"��������",
	"�����豸1",
	"�����豸2",
	"�����豸3",
	"ͣ����(10E-6)",
	"ͣ��ʱ��",
	"ͣ���ʹ��׶�",
	"ͣ��ʱ�乱�׶�",
	"������Ϣ",
};

IMPLEMENT_DYNAMIC(CMCRResultMinCutDialog, CDialog)

CMCRResultMinCutDialog::CMCRResultMinCutDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRResultMinCutDialog::IDD, pParent)
{

}

CMCRResultMinCutDialog::~CMCRResultMinCutDialog()
{
}

void CMCRResultMinCutDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMCRResultMinCutDialog, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_LOADRESULT_LIST, &CMCRResultMinCutDialog::OnNMClickLoadresultList)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CMCRLoadResultDialog ��Ϣ��������

BOOL CMCRResultMinCutDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectDummy;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOADRESULT_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLoadColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, CString(lpszLoadColumn[i]),	LVCFMT_LEFT,	100);

	if (!m_wndMinPathList.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndTab, 101))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndMinPathList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndMinPathList.SetExtendedStyle(m_wndMinPathList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndMinPathList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(m_lpszMinPathColumn)/sizeof(char*); i++)
		m_wndMinPathList.InsertColumn(i, m_lpszMinPathColumn[i], LVCFMT_LEFT, 100);

	if (!m_wndMCut1List.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndTab, 102))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndMCut1List.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndMCut1List.SetExtendedStyle(m_wndMCut1List.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndMCut1List.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszFault1Column)/sizeof(char*); i++)
		m_wndMCut1List.InsertColumn(i, lpszFault1Column[i], LVCFMT_LEFT, 100);

	if (!m_wndMCut2List.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndTab, 103))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndMCut2List.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndMCut2List.SetExtendedStyle(m_wndMCut2List.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndMCut2List.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszFault2Column)/sizeof(char*); i++)
		m_wndMCut2List.InsertColumn(i, lpszFault2Column[i], LVCFMT_LEFT, 100);

	if (!m_wndMCut3List.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndTab, 104))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndMCut3List.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndMCut3List.SetExtendedStyle(m_wndMCut3List.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndMCut3List.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszFault3Column)/sizeof(char*); i++)
		m_wndMCut3List.InsertColumn(i, lpszFault3Column[i], LVCFMT_LEFT, 100);

	m_wndTab.AddTab (&m_wndMinPathList, _T("·��"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCut1List, _T("һ��Ԥ���¹�"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCut2List, _T("����Ԥ���¹�"), -1, FALSE);
	m_wndTab.AddTab (&m_wndMCut3List, _T("����Ԥ���¹�"), -1, FALSE);

	m_wndTab.SetActiveTab(0);

	Refresh();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRResultMinCutDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

void CMCRResultMinCutDialog::RefreshDeviceList()
{
	register int	i;
	int			nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOADRESULT_LIST);
	if (!pListCtrl->DeleteAllItems())
		return;

	for (i=0; i<(int)g_MCRPhyData.m_LineArray.size(); i++)
	{
		if (g_MCRPhyData.m_LineArray[i].nType != PGEnumLineTran_MCType_Load &&
			g_MCRPhyData.m_LineArray[i].nType != PGEnumLineTran_MCType_Gen)
			continue;

		pListCtrl->InsertItem(i, PGGetTableDesp(PG_ACLINESEGMENT));		pListCtrl->SetItemData(i, i);

		nCol=1;

		pListCtrl->SetItemText(i, nCol++, g_MCRPhyData.GetCompString(PG_ACLINESEGMENT, i).c_str());
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].fPower				);		pListCtrl->SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fFaultR	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fFaultU	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fPlanR		);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fPlanU		);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fR			);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fU			);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fEns		);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fFaultEns	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].sResult.fPlanEns	);		pListCtrl->SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].ro_RContribution	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].ro_UContribution	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].ro_ENSContribution	);		pListCtrl->SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[i].fRCTime);				pListCtrl->SetItemText(i, nCol++, szBuf);
		pListCtrl->SetItemText(i, nCol++, PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, g_MCRPhyData.m_LineArray[i].nRCCase));
	}

	for (i=0; i<(int)g_MCRPhyData.m_TranArray.size(); i++)
	{
		if (g_MCRPhyData.m_TranArray[i].nType != PGEnumLineTran_MCType_Load &&
			g_MCRPhyData.m_TranArray[i].nType != PGEnumLineTran_MCType_Gen)
			continue;

		pListCtrl->InsertItem(i, PGGetTableDesp(PG_TRANSFORMERWINDING));		pListCtrl->SetItemData(i, i);

		nCol=1;

		pListCtrl->SetItemText(i, nCol++, g_MCRPhyData.GetCompString(PG_TRANSFORMERWINDING, i).c_str());

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].fPower				);		pListCtrl->SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fFaultR	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fFaultU	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fPlanR		);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fPlanU		);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fR			);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fU			);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fEns		);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fFaultEns	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].sResult.fPlanEns	);		pListCtrl->SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].ro_RContribution	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].ro_UContribution	);		pListCtrl->SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].ro_ENSContribution	);		pListCtrl->SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[i].fRCTime);				pListCtrl->SetItemText(i, nCol++, szBuf);
		pListCtrl->SetItemText(i, nCol++, PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, g_MCRPhyData.m_TranArray[i].nRCCase));
	}

	for (i=0; i<sizeof(lpszLoadColumn)/sizeof(char*); i++)
	{
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultMinCutDialog::RefreshMinPathList(const short nDevType, const int nDevice)
{
	register int	i;
	int			nPath, nType, nComp, nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;

	if (!m_wndMinPathList.DeleteAllItems())
		return;

	nRow=0;

	if (nDevType == PG_ACLINESEGMENT)
	{
		for (nPath=0; nPath<(int)g_MCRPhyData.m_LineArray[nDevice].sMinPathArray.size(); nPath++)
		{
			sprintf(szBuf, "·��(%d/%d)", nPath+1, g_MCRPhyData.m_LineArray[nDevice].sMinPathArray.size());
			m_wndMinPathList.InsertItem(nRow, szBuf);

			nRow++;

			for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sMinPathArray[nPath].sCompArray.size(); i++)
			{
				nType = g_MCRPhyData.m_LineArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompTyp;
				nComp = g_MCRPhyData.m_LineArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompIdx;

				m_wndMinPathList.InsertItem(nRow, "");

				nCol=1;
				m_wndMinPathList.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

				switch (nType)
				{
				case	PG_ACLINESEGMENT:
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_TRANSFORMERWINDING:
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_BREAKER:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_DISCONNECTOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRerr);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTrep);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRchk);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTchk);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_SERIESCOMPENSATOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_BUSBARSECTION:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRerr);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTrep);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRchk);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTchk);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				}

				nRow++;
			}
		}
	}
	else if (nDevType == PG_TRANSFORMERWINDING)
	{
		for (nPath=0; nPath<(int)g_MCRPhyData.m_TranArray[nDevice].sMinPathArray.size(); nPath++)
		{
			sprintf(szBuf, "·��(%d/%d)", nPath+1, g_MCRPhyData.m_TranArray[nDevice].sMinPathArray.size());
			m_wndMinPathList.InsertItem(nRow, szBuf);
			nRow++;

			for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sMinPathArray[nPath].sCompArray.size(); i++)
			{
				nType = g_MCRPhyData.m_TranArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompTyp;
				nComp = g_MCRPhyData.m_TranArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompIdx;

				m_wndMinPathList.InsertItem(nRow, "");

				nCol=1;
				m_wndMinPathList.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

				switch (nType)
				{
				case	PG_ACLINESEGMENT:
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_TRANSFORMERWINDING:
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_BREAKER:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_DISCONNECTOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRerr);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTrep);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRchk);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTchk);m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_SERIESCOMPENSATOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRerr);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTrep);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTchk);		m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				case	PG_BUSBARSECTION:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRerr);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTrep);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRchk);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTchk);			m_wndMinPathList.SetItemText(nRow, nCol++, szBuf);
					break;
				}

				nRow++;
			}
		}
	}
	for (i=0; i<sizeof(m_lpszMinPathColumn)/sizeof(char*); i++)
	{
		m_wndMinPathList.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMinPathList.GetColumnWidth(i);
		m_wndMinPathList.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMinPathList.GetColumnWidth(i);

		m_wndMinPathList.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultMinCutDialog::RefreshMCu1O1List(const short nDevType, const int nDevice)
{
	register int	i;
	int			nType, nComp, nAuxType, nAuxComp, nRow, nCol;
	char		szBuf[260];
	std::string	strBuffer;
	int			nColWidth, nHeaderWidth;
	if (!m_wndMCut1List.DeleteAllItems())
		return;

	nRow=0;

	if (nDevType == PG_ACLINESEGMENT)
	{
		for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sFault1Array.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);		m_wndMCut1List.InsertItem(nRow, szBuf);

			nCol=1;
			m_wndMCut1List.SetItemText(nRow, nCol++, g_lpszCutType[g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].nFType]);

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sComp.nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sComp.nCompIdx;
			m_wndMCut1List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fR);				m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fU);				m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fRContribution);	m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fUContribution);	m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);

			strBuffer.clear();

			nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sSwitchComp.nCompTyp;
			nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sSwitchComp.nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)	//	�л�
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			for (nComp=0; nComp<3; nComp++)	//	����
			{
				nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sDegreeComp[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sDegreeComp[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "����%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			for (nComp=0; nComp<2; nComp++)	//	��ģ
			{
				nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sCommonBreaker[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sCommonBreaker[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "��ģ%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			m_wndMCut1List.SetItemText(nRow, nCol++, strBuffer.c_str());

			nRow++;
		}
	}
	else if (nDevType == PG_TRANSFORMERWINDING)
	{
		for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sFault1Array.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);
			m_wndMCut1List.InsertItem(nRow, szBuf);

			nCol=1;
			m_wndMCut1List.SetItemText(nRow, nCol++, g_lpszCutType[g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].nFType]);

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sComp.nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sComp.nCompIdx;
			m_wndMCut1List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fR);				m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fU);				m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fRContribution);	m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fUContribution);	m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);

			strBuffer.clear();

			nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sSwitchComp.nCompTyp;
			nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sSwitchComp.nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)	//	�л�
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			for (nComp=0; nComp<3; nComp++)	//	����
			{
				nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sDegreeComp[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sDegreeComp[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "����%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			for (nComp=0; nComp<2; nComp++)	//	��ģ
			{
				nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sCommonBreaker[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sCommonBreaker[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "��ģ%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			m_wndMCut1List.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

	for (i=0; i<sizeof(lpszFault1Column)/sizeof(char*); i++)
	{
		m_wndMCut1List.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMCut1List.GetColumnWidth(i);
		m_wndMCut1List.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMCut1List.GetColumnWidth(i);

		m_wndMCut1List.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultMinCutDialog::RefreshMCu1O2List(const short nDevType, const int nDevice)
{
	register int	i;
	int			nRow, nCol, nType, nComp, nAuxType, nAuxComp;
	char		szBuf[260];
	std::string	strBuffer;
	int			nColWidth, nHeaderWidth;

	if (!m_wndMCut2List.DeleteAllItems())
		return;

	nRow=0;

	if (nDevType == PG_ACLINESEGMENT)
	{
		for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sFault2Array.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);		m_wndMCut2List.InsertItem(nRow, szBuf);

			nCol=1;

			m_wndMCut2List.SetItemText(nRow, nCol++, g_lpszCutType[g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].nFType]);

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[0].nCompIdx;
			m_wndMCut2List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[1].nCompIdx;
			m_wndMCut2List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fR);		m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fU);				m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fRContribution);	m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fUContribution);	m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);

			strBuffer.clear();

			nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompTyp;
			nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�1[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompTyp;
			nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�2[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			for (nComp=0; nComp<3; nComp++)	//	����
			{
				nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sDegreeComp[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sDegreeComp[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "����%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			for (nComp=0; nComp<2; nComp++)	//	��ģ
			{
				nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sCommonBreaker[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sCommonBreaker[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "��ģ%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			m_wndMCut2List.SetItemText(nRow, nCol++, strBuffer.c_str());

			nRow++;
		}
	}
	else if (nDevType == PG_TRANSFORMERWINDING)
	{
		for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sFault2Array.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);		m_wndMCut2List.InsertItem(nRow, szBuf);

			nCol=1;

			m_wndMCut2List.SetItemText(nRow, nCol++, g_lpszCutType[g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].nFType]);
			nType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[0].nCompIdx;
			m_wndMCut2List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[1].nCompIdx;
			m_wndMCut2List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fR);		m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fU);				m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fRContribution);	m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fUContribution);	m_wndMCut2List.SetItemText(nRow, nCol++, szBuf);

			strBuffer.clear();

			nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompTyp;
			nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�1[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompTyp;
			nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�2[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			for (nComp=0; nComp<3; nComp++)	//	����
			{
				nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sDegreeComp[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sDegreeComp[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "����%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			for (nComp=0; nComp<2; nComp++)	//	��ģ
			{
				nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sCommonBreaker[nComp].nCompTyp;
				nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sCommonBreaker[nComp].nCompIdx;
				if (nAuxType > 0 && nAuxComp >= 0)
				{
					memset(szBuf, 0, 260);
					sprintf(szBuf, "��ģ%d[%s]", nComp+1, g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
					AppendString(strBuffer, szBuf);
				}
			}

			m_wndMCut2List.SetItemText(nRow, nCol++, strBuffer.c_str());

			nRow++;
		}
	}

	for (i=0; i<sizeof(lpszFault2Column)/sizeof(char*); i++)
	{
		m_wndMCut2List.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMCut2List.GetColumnWidth(i);
		m_wndMCut2List.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMCut2List.GetColumnWidth(i);

		m_wndMCut2List.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultMinCutDialog::RefreshMCu1O3List(const short nDevType, const int nDevice)
{
	register int	i;
	int			nRow, nCol, nType, nComp, nAuxType, nAuxComp;
	char		szBuf[260];
	std::string	strBuffer;
	int			nColWidth, nHeaderWidth;

	if (!m_wndMCut3List.DeleteAllItems())
		return;

	nRow=0;

	if (nDevType == PG_ACLINESEGMENT)
	{
		for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sFault3Array.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);		m_wndMCut3List.InsertItem(nRow, szBuf);

			nCol=1;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_lpszCutType[g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].nFType]);

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[0].nCompIdx;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[1].nCompIdx;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[2].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[2].nCompIdx;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*1000*g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fR);	m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fU);				m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fRContribution);	m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fUContribution);	m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);

			strBuffer.clear();

			nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompTyp;
			nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�1[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompTyp;
			nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�2[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			nAuxType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompTyp;
			nAuxComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�3[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			m_wndMCut3List.SetItemText(nRow, nCol++, strBuffer.c_str());

			nRow++;
		}
	}
	else if (nDevType == PG_TRANSFORMERWINDING)
	{
		for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sFault3Array.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);		m_wndMCut3List.InsertItem(nRow, szBuf);

			nCol=1;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_lpszCutType[g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].nFType]);

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[0].nCompIdx;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[1].nCompIdx;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[2].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[2].nCompIdx;
			m_wndMCut3List.SetItemText(nRow, nCol++, g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*1000*g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fR);	m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fU);				m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fRContribution);	m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fUContribution);	m_wndMCut3List.SetItemText(nRow, nCol++, szBuf);

			strBuffer.clear();

			nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompTyp;
			nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�1[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompTyp;
			nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�2[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			nAuxType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompTyp;
			nAuxComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompIdx;
			if (nAuxType > 0 && nAuxComp >= 0)
			{
				memset(szBuf, 0, 260);
				sprintf(szBuf, "�л�3[%s]", g_MCRPhyData.GetCompString(nAuxType, nAuxComp).c_str());
				AppendString(strBuffer, szBuf);
			}

			m_wndMCut3List.SetItemText(nRow, nCol++, strBuffer.c_str());

			nRow++;
		}
	}

	for (i=0; i<sizeof(lpszFault3Column)/sizeof(char*); i++)
	{
		m_wndMCut3List.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMCut3List.GetColumnWidth(i);
		m_wndMCut3List.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMCut3List.GetColumnWidth(i);

		m_wndMCut3List.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CMCRResultMinCutDialog::OnBnClickedMcrDetail()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOADRESULT_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	char	szDevType[MDB_CHARLEN];
	char	szDevName[MDB_CHARLEN_LONG];
	int		nItem=pListCtrl->GetNextSelectedItem(pos);

	strcpy(szDevType, pListCtrl->GetItemText(nItem, 0));
	strcpy(szDevName, pListCtrl->GetItemText(nItem, 1));

	register int	i;
	int	nDevice=-1;
	if (stricmp(szDevType, PGGetTableDesp(PG_ACLINESEGMENT)) == 0)
	{
		for (i=0; i<(int)g_MCRPhyData.m_LineArray.size(); i++)
		{
			if (stricmp(szDevName, g_MCRPhyData.GetCompString(PG_ACLINESEGMENT, i).c_str()) == 0)
			{
				nDevice = i;
				break;
			}
		}
		if (nDevice >= 0 && nDevice < (int)g_MCRPhyData.m_LineArray.size())
		{
			RefreshMinPathList(PG_ACLINESEGMENT, nDevice);
			RefreshMCu1O1List (PG_ACLINESEGMENT, nDevice);
			RefreshMCu1O2List (PG_ACLINESEGMENT, nDevice);
			RefreshMCu1O3List (PG_ACLINESEGMENT, nDevice);
		}
	}
	else if (stricmp(szDevType, PGGetTableDesp(PG_TRANSFORMERWINDING)) == 0)
	{
		for (i=0; i<(int)g_MCRPhyData.m_TranArray.size(); i++)
		{
			if (stricmp(szDevName, g_MCRPhyData.GetCompString(PG_TRANSFORMERWINDING, i).c_str()) == 0)
			{
				nDevice = i;
				break;
			}
		}
		if (nDevice >= 0 && nDevice < (int)g_MCRPhyData.m_TranArray.size())
		{
			RefreshMinPathList(PG_TRANSFORMERWINDING, nDevice);
			RefreshMCu1O1List (PG_TRANSFORMERWINDING, nDevice);
			RefreshMCu1O2List (PG_TRANSFORMERWINDING, nDevice);
			RefreshMCu1O3List (PG_TRANSFORMERWINDING, nDevice);
		}
	}
}

void CMCRResultMinCutDialog::OnNMClickLoadresultList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnBnClickedMcrDetail();
	*pResult = 0;
}

void CMCRResultMinCutDialog::SaveAsExcel(ExcelAccessor* pXls)
{
	register int	i;
	int		nCol, nDevice, nPath, nType, nComp;
	int		nSwType, nSwComp;
	char	szBuf[260];

	pXls->AddSheet("�����߿ɿ���·���");
	pXls->SetCurSheet("�����߿ɿ���·���");

	for (nDevice=0; nDevice<(int)g_MCRPhyData.m_LineArray.size(); nDevice++)
	{
		if (g_MCRPhyData.m_LineArray[nDevice].nType != PGEnumLineTran_MCType_Load &&
			g_MCRPhyData.m_LineArray[nDevice].nType != PGEnumLineTran_MCType_Gen)
			continue;

		pXls->NewLine();
		for (nCol=0; nCol<sizeof(lpszLoadColumn)/sizeof(char*); nCol++)
		{
			pXls->FillCell(RGB(255, 0, 0));
			pXls->AddCell("");
		}

		pXls->NewLine();

		pXls->AddCell(PGGetTableDesp(PG_ACLINESEGMENT));

		pXls->AddCell(g_MCRPhyData.GetCompString(PG_ACLINESEGMENT, nDevice).c_str());
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].fPower				);		pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fFaultR		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fFaultU		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fPlanR		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fPlanU		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fR			);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fU			);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fEns			);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fFaultEns	);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sResult.fPlanEns		);		pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].ro_RContribution		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].ro_UContribution		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].ro_ENSContribution	);		pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].fRCTime);					pXls->AddCell(szBuf);
		pXls->AddCell(PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, g_MCRPhyData.m_LineArray[nDevice].nRCCase));

		pXls->NewLine();
		pXls->NewLine();
		for (nPath=0; nPath<(int)g_MCRPhyData.m_LineArray[nDevice].sMinPathArray.size(); nPath++)
		{
			pXls->NewLine();

			sprintf(szBuf, "·��(%d/%d)", nPath+1, g_MCRPhyData.m_LineArray[nDevice].sMinPathArray.size());
			pXls->AddCell(szBuf);

			for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sMinPathArray[nPath].sCompArray.size(); i++)
			{
				pXls->NewLine();

				nType = g_MCRPhyData.m_LineArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompTyp;
				nComp = g_MCRPhyData.m_LineArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompIdx;

				pXls->AddCell("");

				pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

				switch (nType)
				{
				case	PG_ACLINESEGMENT:
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_TRANSFORMERWINDING:
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_BREAKER:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_DISCONNECTOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRerr);pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTrep);pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRchk);pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTchk);pXls->AddCell(szBuf);
					break;
				case	PG_SERIESCOMPENSATOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_BUSBARSECTION:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRerr);			pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTrep);			pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRchk);			pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTchk);			pXls->AddCell(szBuf);
					break;
				}
			}
		}

		pXls->NewLine();
		pXls->NewLine();
		for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sFault1Array.size(); i++)
		{
			pXls->NewLine();

			sprintf(szBuf, "һ�׹���(%d/%d)", i+1, g_MCRPhyData.m_LineArray[nDevice].sFault1Array.size());	pXls->AddCell(szBuf);

			nCol=1;
			pXls->AddCell(g_lpszCutType[g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].nFType]);

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sComp.nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sComp.nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fR);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fU);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fRContribution);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].fUContribution);	pXls->AddCell(szBuf);

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sSwitchComp.nCompTyp;
			nSwComp = g_MCRPhyData.m_LineArray[nDevice].sFault1Array[i].sSwitchComp.nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			pXls->AddCell(szBuf);
		}

		pXls->NewLine();
		for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sFault2Array.size(); i++)
		{
			pXls->NewLine();

			sprintf(szBuf, "���׹���(%d/%d)", i+1, g_MCRPhyData.m_LineArray[nDevice].sFault2Array.size());	pXls->AddCell(szBuf);

			pXls->AddCell(g_lpszCutType[g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].nFType]);

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[0].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sComp[1].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fR);		pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fU);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fRContribution);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].fUContribution);	pXls->AddCell(szBuf);

			memset(szBuf, 0, 260);

			nSwType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompTyp;
			nSwComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());

			nSwType = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompTyp;
			nSwComp = g_MCRPhyData.m_LineArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, ", ");
				strcat(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			}

			pXls->AddCell(szBuf);
		}

		pXls->NewLine();
		for (i=0; i<(int)g_MCRPhyData.m_LineArray[nDevice].sFault3Array.size(); i++)
		{
			pXls->NewLine();

			sprintf(szBuf, "���׹���(%d/%d)", i+1, g_MCRPhyData.m_LineArray[nDevice].sFault3Array.size());	pXls->AddCell(szBuf);

			pXls->AddCell(g_lpszCutType[g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].nFType]);

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[0].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[1].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[2].nCompTyp;
			nComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sComp[2].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*1000*g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fR);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fU);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fRContribution);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].fUContribution);	pXls->AddCell(szBuf);

			memset(szBuf, 0, 260);

			nSwType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompTyp;
			nSwComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompTyp;
			nSwComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, ", ");
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			}

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompTyp;
			nSwComp = g_MCRPhyData.m_LineArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, ", ");
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			}

			pXls->AddCell(szBuf);
		}
	}

	pXls->NewLine();
	pXls->NewLine();
	pXls->NewLine();
	for (nDevice=0; nDevice<(int)g_MCRPhyData.m_TranArray.size(); nDevice++)
	{
		if (g_MCRPhyData.m_TranArray[nDevice].nType != PGEnumLineTran_MCType_Load &&
			g_MCRPhyData.m_TranArray[nDevice].nType != PGEnumLineTran_MCType_Gen)
			continue;

		pXls->NewLine();
		for (nCol=0; nCol<sizeof(lpszLoadColumn)/sizeof(char*); nCol++)
		{
			pXls->FillCell(RGB(255, 0, 0));
			pXls->AddCell("");
		}

		pXls->NewLine();
		pXls->AddCell(PGGetTableDesp(PG_TRANSFORMERWINDING));

		pXls->AddCell(g_MCRPhyData.GetCompString(PG_TRANSFORMERWINDING, nDevice).c_str());

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].fPower				);		pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fFaultR		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fFaultU		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fPlanR		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fPlanU		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fR			);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fU			);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fEns			);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fFaultEns	);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sResult.fPlanEns		);		pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].ro_RContribution		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].ro_UContribution		);		pXls->AddCell(szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].ro_ENSContribution	);		pXls->AddCell(szBuf);

		sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].fRCTime);				pXls->AddCell(szBuf);
		pXls->AddCell(PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, g_MCRPhyData.m_TranArray[nDevice].nRCCase));

		pXls->NewLine();
		pXls->NewLine();
		for (nPath=0; nPath<(int)g_MCRPhyData.m_TranArray[nDevice].sMinPathArray.size(); nPath++)
		{
			pXls->NewLine();

			sprintf(szBuf, "·��(%d/%d)", nPath+1, g_MCRPhyData.m_TranArray[nDevice].sMinPathArray.size());
			pXls->AddCell(szBuf);

			for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sMinPathArray[nPath].sCompArray.size(); i++)
			{
				pXls->NewLine();

				nType = g_MCRPhyData.m_TranArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompTyp;
				nComp = g_MCRPhyData.m_TranArray[nDevice].sMinPathArray[nPath].sCompArray[i].nCompIdx;

				pXls->AddCell("");

				pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

				switch (nType)
				{
				case	PG_ACLINESEGMENT:
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_LineArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_TRANSFORMERWINDING:
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_BREAKER:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BreakerArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_DISCONNECTOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRerr);pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTrep);pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fRchk);pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_DisconnectorArray[nComp].fTchk);pXls->AddCell(szBuf);
					break;
				case	PG_SERIESCOMPENSATOR:
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRerr);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTrep);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fRchk);		pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_ScapArray[nComp].fTchk);		pXls->AddCell(szBuf);
					break;
				case	PG_BUSBARSECTION:
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRerr);			pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTrep);			pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fRchk);			pXls->AddCell(szBuf);
					sprintf(szBuf, "%f", g_MCRPhyData.m_BusArray[nComp].fTchk);			pXls->AddCell(szBuf);
					break;
				}
			}
		}

		pXls->NewLine();
		pXls->NewLine();
		for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sFault1Array.size(); i++)
		{
			pXls->NewLine();

			sprintf(szBuf, "һ�׹���(%d/%d)", i+1, g_MCRPhyData.m_TranArray[nDevice].sFault1Array.size());	pXls->AddCell(szBuf);

			pXls->AddCell(g_lpszCutType[g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].nFType]);

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sComp.nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sComp.nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fR);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fU);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fRContribution);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].fUContribution);	pXls->AddCell(szBuf);

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sSwitchComp.nCompTyp;
			nSwComp = g_MCRPhyData.m_TranArray[nDevice].sFault1Array[i].sSwitchComp.nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			pXls->AddCell(szBuf);
		}

		pXls->NewLine();
		for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sFault2Array.size(); i++)
		{
			pXls->NewLine();

			sprintf(szBuf, "���׹���(%d/%d)", i+1, g_MCRPhyData.m_TranArray[nDevice].sFault2Array.size());	pXls->AddCell(szBuf);

			pXls->AddCell(g_lpszCutType[g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].nFType]);
			nType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[0].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sComp[1].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fR);		pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fU);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fRContribution);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].fUContribution);	pXls->AddCell(szBuf);

			memset(szBuf, 0, 260);

			nSwType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompTyp;
			nSwComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[0].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompTyp;
			nSwComp = g_MCRPhyData.m_TranArray[nDevice].sFault2Array[i].sSwitchComp[1].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, ", ");
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			}

			pXls->AddCell(szBuf);
		}

		pXls->NewLine();
		for (i=0; i<(int)g_MCRPhyData.m_TranArray[nDevice].sFault3Array.size(); i++)
		{
			pXls->NewLine();

			sprintf(szBuf, "���׹���(%d/%d)", i+1, g_MCRPhyData.m_TranArray[nDevice].sFault3Array.size());	pXls->AddCell(szBuf);

			pXls->AddCell(g_lpszCutType[g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].nFType]);

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[0].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[0].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[1].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[1].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			nType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[2].nCompTyp;
			nComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sComp[2].nCompIdx;
			pXls->AddCell(g_MCRPhyData.GetCompString(nType, nComp).c_str());

			sprintf(szBuf, "%f", 1000*1000*g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fR);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fU);				pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fRContribution);	pXls->AddCell(szBuf);
			sprintf(szBuf, "%f", g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].fUContribution);	pXls->AddCell(szBuf);

			memset(szBuf, 0, 260);

			nSwType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompTyp;
			nSwComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[0].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompTyp;
			nSwComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[1].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, ", ");
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			}

			memset(szBuf, 0, 260);
			nSwType = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompTyp;
			nSwComp = g_MCRPhyData.m_TranArray[nDevice].sFault3Array[i].sSwitchComp[2].nCompIdx;
			if (nSwType > 0 && nSwComp >= 0)
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, ", ");
				strcpy(szBuf, g_MCRPhyData.GetCompString(nSwType, nSwComp).c_str());
			}
			pXls->AddCell(szBuf);
		}
	}
}

void CMCRResultMinCutDialog::AppendString(std::string& strString, const char* lpszAppendString)
{
	if (strString.empty())
		strString.append(lpszAppendString);
	else
	{
		strString.append("; ");
		strString.append(lpszAppendString);
	}
}
