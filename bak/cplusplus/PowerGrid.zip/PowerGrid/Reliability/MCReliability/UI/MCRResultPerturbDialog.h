#pragma once
#include "../../../../Common/Excel/ExcelAccessor.h"

// CMCRResultPerturbDialog �Ի���

class CMCRResultPerturbDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRResultPerturbDialog)

public:
	CMCRResultPerturbDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRResultPerturbDialog();

// �Ի�������
	enum { IDD = IDD_MCRPERTURB_RESULT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedExcelOut();
	DECLARE_MESSAGE_MAP()

private:
	void RefreshPerturbList();
public:
	void Refresh();
	void SaveAsExcel(ExcelAccessor* pXls);
};
