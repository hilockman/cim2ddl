#pragma once


// CMCRPerturbSetDialog �Ի���

class CMCRPerturbSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRPerturbSetDialog)

public:
	CMCRPerturbSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRPerturbSetDialog();

// �Ի�������
	enum { IDD = IDD_MCRPERTURB_SET_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedZeroPerturb();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedLoadParam();
	afx_msg void OnBnClickedSaveParam();
	DECLARE_MESSAGE_MAP()

private:
	void	RefreshUI();
public:
};
