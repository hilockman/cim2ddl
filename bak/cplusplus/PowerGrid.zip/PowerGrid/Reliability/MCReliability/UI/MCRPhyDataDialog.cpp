// MCSourceDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRPhyDataDialog.h"
#include "MCRPGDataDialog.h"

// CMCSourceDialog �Ի���
static	char*	lpszColumn[]=
{
	("����"),
	("��ֵ"),
	("����"),
	("����"),
};

const	int	m_nMCPhyTables[]=
{
	PG_BUSBARSECTION,
	PG_ACLINESEGMENT,
	PG_TRANSFORMERWINDING,
	PG_BREAKER,
	PG_DISCONNECTOR,
	PG_SERIESCOMPENSATOR,
	PG_CONNECTIVITYNODE,
};
static	char*	m_lpszMCPhyDevice[]=
{
	"ĸ��",
	"��·",
	"��ѹ��",
	"��·��",
	"���뿪��",
	"�����翹",
	"�ڵ�",
};

static	char*	m_lpszMCPhyGenColumn[]=
{
	"��վ",
	"��ѹ�ȼ�",
	"����",
	"����",

	"R",
	"T",
	"U",
	"FR",
	"FT",
	"FU",
	"AR",
	"AT",
	"AU",
	"MR",
	"MT",
	"MU",

	"RCTime",
	"RCCase",
};

static	char*	m_lpszMCPhyLoadColumn[]=
{
	"��վ",
	"��ѹ�ȼ�",
	"����",
	"����",

	"R",
	"T",
	"U",
	"FR",
	"FT",
	"FU",
	"AR",
	"AT",
	"AU",
	"MR",
	"MT",
	"MU",

	"NEns",
	"FEns",
	"AEns",
	"NLoss",
	"FLoss",
	"ALoss",

	"rContribution",
	"uContribution",
	"ensContribution",

	"RCTime",
	"RCCase",
};

static	char*	m_lpszMCPhyNodeColumn[]=
{
	"������",
	"������",
	"����",
	"��·��",
	"������",
	"������",
	"������",
	"��բ��",
	"�ڵ�����",
};

IMPLEMENT_DYNAMIC(CMCRPhyDataDialog, CDialog)

CMCRPhyDataDialog::CMCRPhyDataDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRPhyDataDialog::IDD, pParent)
{
	m_nShowDevType = 0;
}

CMCRPhyDataDialog::~CMCRPhyDataDialog()
{
}

void CMCRPhyDataDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_ALL, m_nShowDevType);
}


BEGIN_MESSAGE_MAP(CMCRPhyDataDialog, CDialog)
	ON_BN_CLICKED(IDC_FORM_MODEL, &CMCRPhyDataDialog::OnBnClickedFormModel)
	ON_BN_CLICKED(IDC_FORM_MEMDB, &CMCRPhyDataDialog::OnBnClickedFormMemDB)
	
	ON_CBN_SELCHANGE(IDC_DATATYPE_COMBO, &CMCRPhyDataDialog::OnCbnSelchangeDatatypeCombo)
	ON_NOTIFY(NM_CLICK, IDC_DATA_LIST, &CMCRPhyDataDialog::OnNMClickDataList)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_DATA_LIST, &CMCRPhyDataDialog::OnLvnItemchangedDataList)
	ON_BN_CLICKED(IDC_ADD, &CMCRPhyDataDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CMCRPhyDataDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_MOD, &CMCRPhyDataDialog::OnBnClickedMod)
	ON_BN_CLICKED(IDC_ALL, &CMCRPhyDataDialog::RefreshDataList)
	ON_BN_CLICKED(IDC_GEN, &CMCRPhyDataDialog::RefreshDataList)
	ON_BN_CLICKED(IDC_LOAD, &CMCRPhyDataDialog::RefreshDataList)
	ON_BN_CLICKED(IDC_TOPO, &CMCRPhyDataDialog::OnBnClickedTopo)
END_MESSAGE_MAP()


// CMCSourceDialog ��Ϣ��������

BOOL CMCRPhyDataDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	CRect	rectDummy;
	GetDlgItem(IDC_PROPERTY)->GetWindowRect (&rectDummy);
	ScreenToClient (&rectDummy);

	if (!m_wndPropertyList.Create(WS_VISIBLE | WS_CHILD | WS_BORDER, rectDummy, this, 1))
	{
		TRACE(_T("δ�ܴ�����������\n"));
		return FALSE;      // δ�ܴ���
	}

	HDITEM	hdi;
	char	szBuffer[260];

	hdi.mask = HDI_TEXT;
	hdi.pszText = szBuffer;
	hdi.cchTextMax = 260;

	m_wndPropertyList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndPropertyList.EnableHeaderCtrl(TRUE);
	m_wndPropertyList.EnableDescriptionArea(FALSE);
	m_wndPropertyList.SetVSDotNetLook(TRUE);
	m_wndPropertyList.MarkModifiedProperties(TRUE);
	m_wndPropertyList.SetShowDragContext(FALSE);
	for (i=0; i<m_wndPropertyList.GetHeaderCtrl().GetItemCount(); i++)
	{
		m_wndPropertyList.GetHeaderCtrl().GetItem(i, &hdi);
		strcpy(hdi.pszText, lpszColumn[i]);
		m_wndPropertyList.GetHeaderCtrl().SetItem(i, &hdi);
	}
	m_wndPropertyList.RemoveAll();

	RefreshPropertyList(0);

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL | LVS_REPORT | LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(m_lpszMCPhyDevice)/sizeof(char*); i++)
		pComboBox->AddString(m_lpszMCPhyDevice[i]);
	pComboBox->SetCurSel(0);

	OnCbnSelchangeDatatypeCombo();
	RefreshDevType();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRPhyDataDialog::Refresh()
{
	OnCbnSelchangeDatatypeCombo();
}

void CMCRPhyDataDialog::OnBnClickedFormModel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CMCRPGDataDialog	dlg(&g_MCRPhyData);
	if (dlg.DoModal() == IDOK)
	{
		OnCbnSelchangeDatatypeCombo();

		PrintMessage("�ɵ������ݿ����������߿ɿ��Լ���ģ�� [%s] ���", g_MCRPhyData.m_strMCDataFileName.c_str());
	}
}

void CMCRPhyDataDialog::OnBnClickedFormMemDB()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_MCRPhyData.PhyData2PGMemDB(g_pPGBlock);

	PrintMessage("�����߿ɿ��Լ���ģ�� [%s] ����������ݿ����", g_MCRPhyData.m_strMCDataFileName.c_str());
}

void CMCRPhyDataDialog::OnBnClickedTopo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nNodeTable;
	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
	g_MCRPhyData.PhyTopo();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("���˷�����ɣ���ʱ %d ����", nDur);

	nNodeTable = -1;
	for (i=0; i<sizeof(m_nMCPhyTables)/sizeof(int); i++)
	{
		if (m_nMCPhyTables[i] == PG_CONNECTIVITYNODE)
		{
			nNodeTable = i;
			break;
		}
	}

	if (nNodeTable >= 0)
	{
		CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
		pComboBox->SetCurSel(nNodeTable);
	}
}

void CMCRPhyDataDialog::RefreshDevType()
{
	GetDlgItem(IDC_ADD)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_DEL)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_MOD)->ShowWindow(SW_SHOW);

	GetDlgItem(IDC_ALL)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_GEN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_LOAD)->ShowWindow(SW_HIDE);

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;

	if (m_nMCPhyTables[nTable] == PG_CONNECTIVITYNODE || m_nMCPhyTables[nTable] == PG_SYNCHRONOUSMACHINE || m_nMCPhyTables[nTable] == PG_ENERGYCONSUMER)
	{
		GetDlgItem(IDC_ADD)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_DEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_MOD)->ShowWindow(SW_HIDE);
	}

	if (m_nMCPhyTables[nTable] == PG_ACLINESEGMENT || m_nMCPhyTables[nTable] == PG_TRANSFORMERWINDING)
	{
		GetDlgItem(IDC_ALL)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_GEN)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_LOAD)->ShowWindow(SW_SHOW);
	}
}

void CMCRPhyDataDialog::RefreshDataList()
{
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;

	UpdateData();

	switch (m_nMCPhyTables[nTable])
	{
	case	PG_BUSBARSECTION:
		RefreshPhyBusList(1);
		break;
	case	PG_ACLINESEGMENT:
		RefreshPhyLineList(1, m_nShowDevType);
		break;
	case	PG_TRANSFORMERWINDING:
		RefreshPhyTranList(1, m_nShowDevType);
		break;
	case	PG_SERIESCOMPENSATOR:
		RefreshPhyScapList(1);
		break;
	case	PG_BREAKER:
		RefreshPhyBreakerList(1);
		break;
	case	PG_DISCONNECTOR:
		RefreshPhyDisconnectorList(1);
		break;
	case	PG_CONNECTIVITYNODE:
		RefreshPhyNodeList();
		break;
	}
}

void CMCRPhyDataDialog::RefreshPhyBusList(const unsigned char bRefreshColumn)
{
	register int	i;
	int		nField;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	const int	nFieldNum = sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	if (bRefreshColumn)
	{
		while (pListCtrl->DeleteColumn(0));
		pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
		for (i=0; i<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); i++)
			pListCtrl->InsertColumn(i+1, PGGetFieldDesp(PG_BUSBARSECTION, g_MCPhyBusField[i].nMDBField),	LVCFMT_LEFT,	100);
	}
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_BusArray.size(); i++)
	{
		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		for (nField=0; nField<nFieldNum; nField++)
			pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetPhyDataValue(PG_BUSBARSECTION, nField, i).c_str());

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::RefreshPhyLineList(const unsigned char bRefreshColumn, const unsigned char nShowDevType)
{
	register int	i;
	int		nField;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	const int	nFieldNum = sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField);
	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	if (bRefreshColumn)
	{
		while (pListCtrl->DeleteColumn(0));
		pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
		for (i=0; i<nFieldNum; i++)
			pListCtrl->InsertColumn(i+1, PGGetFieldDesp(PG_ACLINESEGMENT, g_MCPhyLineField[i].nMDBField),	LVCFMT_LEFT,	100);
	}
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_LineArray.size(); i++)
	{
		if (nShowDevType == 1)
		{
			if (g_MCRPhyData.m_LineArray[i].nType != PGEnumLineTran_MCType_Gen)
				continue;
		}
		else if (nShowDevType == 2)
		{
			if (g_MCRPhyData.m_LineArray[i].nType != PGEnumLineTran_MCType_Load)
				continue;
		}

		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		for (nField=0; nField<nFieldNum; nField++)
		{
			pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetPhyDataValue(PG_ACLINESEGMENT, nField, i).c_str());
		}

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::RefreshPhyTranList(const unsigned char bRefreshColumn, const unsigned char nShowDevType)
{
	register int	i;
	int		nField;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	const int	nFieldNum = sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField);
	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	if (bRefreshColumn)
	{
		while (pListCtrl->DeleteColumn(0));
		pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
		for (i=0; i<nFieldNum; i++)
			pListCtrl->InsertColumn(i+1, PGGetFieldDesp(PG_TRANSFORMERWINDING, g_MCPhyTranField[i].nMDBField),	LVCFMT_LEFT,	100);
	}
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_TranArray.size(); i++)
	{
		if (nShowDevType == 1)
		{
			if (g_MCRPhyData.m_TranArray[i].nType != PGEnumLineTran_MCType_Gen)
				continue;
		}
		else if (nShowDevType == 2)
		{
			if (g_MCRPhyData.m_TranArray[i].nType != PGEnumLineTran_MCType_Load)
				continue;
		}

		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		for (nField=0; nField<nFieldNum; nField++)
			pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetPhyDataValue(PG_TRANSFORMERWINDING, nField, i).c_str());
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::RefreshPhyScapList(const unsigned char bRefreshColumn)
{
	register int	i;
	int		nField;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	const int	nFieldNum = sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField);
	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	if (bRefreshColumn)
	{
		while (pListCtrl->DeleteColumn(0));
		pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
		for (i=0; i<nFieldNum; i++)
			pListCtrl->InsertColumn(i+1, PGGetFieldDesp(PG_SERIESCOMPENSATOR, g_MCPhyScapField[i].nMDBField),	LVCFMT_LEFT,	100);
	}
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_ScapArray.size(); i++)
	{
		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		for (nField=0; nField<nFieldNum; nField++)
			pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetPhyDataValue(PG_SERIESCOMPENSATOR, nField, i).c_str());

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::RefreshPhyBreakerList(const unsigned char bRefreshColumn)
{
	register int	i;
	int		nRow, nCol, nField;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	const int	nFieldNum = sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField);
	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	if (bRefreshColumn)
	{
		while (pListCtrl->DeleteColumn(0));
		pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
		for (i=0; i<nFieldNum; i++)
			pListCtrl->InsertColumn(i+1, PGGetFieldDesp(PG_BREAKER, g_MCPhyBreakerField[i].nMDBField),	LVCFMT_LEFT,	100);
	}
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_BreakerArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		for (nField=0; nField<nFieldNum; nField++)
			pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetPhyDataValue(PG_BREAKER, nField, i).c_str());

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::RefreshPhyDisconnectorList(const unsigned char bRefreshColumn)
{
	register int	i;
	int		nRow, nCol, nField;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	const int	nFieldNum = sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField);
	int			nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	if (bRefreshColumn)
	{
		while (pListCtrl->DeleteColumn(0));
		pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
		for (i=0; i<nFieldNum; i++)
			pListCtrl->InsertColumn(i+1, PGGetFieldDesp(PG_DISCONNECTOR, g_MCPhyDisconnectorField[i].nMDBField),	LVCFMT_LEFT,	100);
	}
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_DisconnectorArray.size(); i++)
	{
		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		for (nField=0; nField<nFieldNum; nField++)
			pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.GetPhyDataValue(PG_DISCONNECTOR, nField, i).c_str());

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<nFieldNum+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::RefreshPhyNodeList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);

	const int	nFieldNum = sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField);
	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	while (pListCtrl->DeleteColumn(0));
	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(m_lpszMCPhyNodeColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, m_lpszMCPhyNodeColumn[i],	LVCFMT_LEFT,	100);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRPhyData.m_NodeArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, PGGetTableDesp(g_MCRPhyData.m_NodeArray[i].nParentType));
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.m_NodeArray[i].strParentName.c_str());
		pListCtrl->SetItemText(nRow, nCol++, g_MCRPhyData.m_NodeArray[i].strName.c_str());
		sprintf(szBuf, "%d", g_MCRPhyData.m_NodeArray[i].nLineArray.size());			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRPhyData.m_NodeArray[i].nTranArray.size());			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRPhyData.m_NodeArray[i].nScapArray.size());			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRPhyData.m_NodeArray[i].nBreakerArray.size());		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRPhyData.m_NodeArray[i].nDisconnectorArray.size());	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, PGGetTableDesp(g_MCRPhyData.m_NodeArray[i].nNodeType));

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(m_lpszMCPhyNodeColumn)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRPhyDataDialog::OnCbnSelchangeDatatypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDataList();
	RefreshPropertyList(0);
	RefreshDevType();
}

void CMCRPhyDataDialog::OnNMClickDataList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (pNMItemActivate->iItem >= 0)
		RefreshPropertyList(pNMItemActivate->iItem);

	*pResult = 0;
}

void CMCRPhyDataDialog::OnLvnItemchangedDataList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	static	int	nOldItem = -1;

	int	nNewItem=pNMLV->iItem;
	if (nNewItem != -1 && nOldItem != nNewItem)
	{
		nOldItem = nNewItem;
		RefreshPropertyList(pNMLV->iItem);
	}

	*pResult = 0;
}

void CMCRPhyDataDialog::RefreshPropertyList(const int nRecord)
{
	register int	i;
	int		nField, nEnumNum;
	char	szValue[MDB_CHARLEN_LONG];
	CMFCPropertyGridProperty* pProp;

	m_wndPropertyList.RemoveAll();

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;

	CMFCPropertyGridProperty* pGrpData = new CMFCPropertyGridProperty(_T("����"));
	switch (m_nMCPhyTables[nTable])
	{
	case	PG_BUSBARSECTION:
		for (nField=0; nField<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); nField++)
		{
			strcpy(szValue, g_MCRPhyData.GetPhyDataValue(m_nMCPhyTables[nTable], nField, nRecord).c_str());

			pProp=new CMFCPropertyGridProperty(PGGetFieldDesp(m_nMCPhyTables[nTable], g_MCPhyBusField[nField].nMDBField), (_variant_t) _T(szValue), _T(""), nField);
			if (g_MCPhyBusField[nField].bEditable)
				pProp->AllowEdit(TRUE);
			else
				pProp->AllowEdit(FALSE);

			nEnumNum = PGGetFieldEnumNum(m_nMCPhyTables[nTable], g_MCPhyBusField[nField].nMDBField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				for (i=0; i<nEnumNum; i++)
					pProp->AddOption(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyBusField[nField].nMDBField, i));

				pProp->SetValue(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyBusField[nField].nMDBField, atoi(szValue)));
				pProp->AllowEdit(FALSE);
			}

			pGrpData->AddSubItem(pProp);
		}
		break;
	case	PG_ACLINESEGMENT:
		for (nField=0; nField<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); nField++)
		{
			strcpy(szValue, g_MCRPhyData.GetPhyDataValue(m_nMCPhyTables[nTable], nField, nRecord).c_str());

			pProp=new CMFCPropertyGridProperty(PGGetFieldDesp(m_nMCPhyTables[nTable], g_MCPhyLineField[nField].nMDBField),(_variant_t) _T(szValue), _T(""), nField);
			if (g_MCPhyLineField[nField].bEditable)
				pProp->AllowEdit(TRUE);
			else
				pProp->AllowEdit(FALSE);

			nEnumNum = PGGetFieldEnumNum(m_nMCPhyTables[nTable], g_MCPhyLineField[nField].nMDBField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				for (i=0; i<nEnumNum; i++)
					pProp->AddOption(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyLineField[nField].nMDBField, i));

				pProp->SetValue(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyLineField[nField].nMDBField, atoi(szValue)));
				pProp->AllowEdit(FALSE);
			}

			pGrpData->AddSubItem(pProp);
		}
		break;
	case	PG_TRANSFORMERWINDING:
		for (nField=0; nField<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); nField++)
		{
			strcpy(szValue, g_MCRPhyData.GetPhyDataValue(m_nMCPhyTables[nTable], nField, nRecord).c_str());

			pProp=new CMFCPropertyGridProperty(PGGetFieldDesp(m_nMCPhyTables[nTable], g_MCPhyTranField[nField].nMDBField),(_variant_t) _T(szValue), _T(""), nField);
			if (g_MCPhyTranField[nField].bEditable)
				pProp->AllowEdit(TRUE);
			else
				pProp->AllowEdit(FALSE);

			nEnumNum = PGGetFieldEnumNum(m_nMCPhyTables[nTable], g_MCPhyTranField[nField].nMDBField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				for (i=0; i<nEnumNum; i++)
					pProp->AddOption(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyTranField[nField].nMDBField, i));

				pProp->SetValue(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyTranField[nField].nMDBField, atoi(szValue)));
				pProp->AllowEdit(FALSE);
			}

			pGrpData->AddSubItem(pProp);
		}
		break;
	case	PG_SERIESCOMPENSATOR:
		for (nField=0; nField<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); nField++)
		{
			strcpy(szValue, g_MCRPhyData.GetPhyDataValue(m_nMCPhyTables[nTable], nField, nRecord).c_str());

			pProp=new CMFCPropertyGridProperty(PGGetFieldDesp(m_nMCPhyTables[nTable], g_MCPhyScapField[nField].nMDBField),(_variant_t) _T(szValue), _T(""), nField);
			if (g_MCPhyScapField[nField].bEditable)
				pProp->AllowEdit(TRUE);
			else
				pProp->AllowEdit(FALSE);

			nEnumNum = PGGetFieldEnumNum(m_nMCPhyTables[nTable], g_MCPhyScapField[nField].nMDBField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				for (i=0; i<nEnumNum; i++)
					pProp->AddOption(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyScapField[nField].nMDBField, i));

				pProp->SetValue(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyScapField[nField].nMDBField, atoi(szValue)));
				pProp->AllowEdit(FALSE);
			}

			pGrpData->AddSubItem(pProp);
		}
		break;
	case	PG_BREAKER:
		for (nField=0; nField<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); nField++)
		{
			strcpy(szValue, g_MCRPhyData.GetPhyDataValue(m_nMCPhyTables[nTable], nField, nRecord).c_str());

			pProp=new CMFCPropertyGridProperty(PGGetFieldDesp(m_nMCPhyTables[nTable], g_MCPhyBreakerField[nField].nMDBField),(_variant_t) _T(szValue), _T(""), nField);
			if (g_MCPhyBreakerField[nField].bEditable)
				pProp->AllowEdit(TRUE);
			else
				pProp->AllowEdit(FALSE);

			nEnumNum = PGGetFieldEnumNum(m_nMCPhyTables[nTable], g_MCPhyBreakerField[nField].nMDBField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				for (i=0; i<nEnumNum; i++)
					pProp->AddOption(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyBreakerField[nField].nMDBField, i));

				pProp->SetValue(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyBreakerField[nField].nMDBField, atoi(szValue)));
				pProp->AllowEdit(FALSE);
			}

			pGrpData->AddSubItem(pProp);
		}
		break;
	case	PG_DISCONNECTOR:
		for (nField=0; nField<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); nField++)
		{
			strcpy(szValue, g_MCRPhyData.GetPhyDataValue(m_nMCPhyTables[nTable], nField, nRecord).c_str());

			pProp=new CMFCPropertyGridProperty(PGGetFieldDesp(m_nMCPhyTables[nTable], g_MCPhyDisconnectorField[nField].nMDBField),(_variant_t) _T(szValue), _T(""), nField);
			if (g_MCPhyDisconnectorField[nField].bEditable)
				pProp->AllowEdit(TRUE);
			else
				pProp->AllowEdit(FALSE);

			nEnumNum = PGGetFieldEnumNum(m_nMCPhyTables[nTable], g_MCPhyDisconnectorField[nField].nMDBField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				for (i=0; i<nEnumNum; i++)
					pProp->AddOption(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyDisconnectorField[nField].nMDBField, i));

				pProp->SetValue(PGGetFieldEnumString(m_nMCPhyTables[nTable], g_MCPhyDisconnectorField[nField].nMDBField, atoi(szValue)));
				pProp->AllowEdit(FALSE);
			}

			pGrpData->AddSubItem(pProp);
		}
		break;
	default:
		break;
	}

	pGrpData->Expand(TRUE);
	m_wndPropertyList.AddProperty(pGrpData);
}

int CMCRPhyDataDialog::ResolvePropertyValue(const int nTable, char szRecArray[][MDB_CHARLEN_LONG])
{
	int			nGroup, nSubitem, nField, nMDBField;
	char		szValue[MDB_CHARLEN_LONG];
	CMFCPropertyGridProperty*		pNorm;

	if (nTable == PG_CONNECTIVITYNODE || nTable == PG_SYNCHRONOUSMACHINE || nTable == PG_ENERGYCONSUMER)
		return 0;

	//Log(g_lpszLogFile, "CPropertyEntityDialog OnBnClickedOk\n");
	for (nGroup=0; nGroup<m_wndPropertyList.GetPropertyCount(); nGroup++)
	{
		//Log(g_lpszLogFile, "    Group[%d/%d]\n", nGroup, m_wndDataPropList.GetPropertyCount());
		CMFCPropertyGridProperty*	pGrp=m_wndPropertyList.GetProperty(nGroup);
		for (nSubitem=0; nSubitem<pGrp->GetSubItemsCount(); nSubitem++)
		{
			memset(szValue, 0, MDB_CHARLEN_LONG);
			pNorm=(CMFCPropertyGridProperty*)pGrp->GetSubItem(nSubitem);
			if (pNorm->GetValue().vt != VT_BSTR)
				continue;

			nField=(int)pNorm->GetData();
			strcpy(szRecArray[nField], CString(pNorm->GetValue().bstrVal));

			switch (nTable)
			{
			case	PG_BUSBARSECTION:
				nMDBField = g_MCPhyBusField[nField].nMDBField;
				break;
			case	PG_ACLINESEGMENT:
				nMDBField = g_MCPhyLineField[nField].nMDBField;
				break;
			case	PG_TRANSFORMERWINDING:
				nMDBField = g_MCPhyTranField[nField].nMDBField;
				break;
			case	PG_SERIESCOMPENSATOR:
				nMDBField = g_MCPhyScapField[nField].nMDBField;
				break;
			case	PG_BREAKER:
				nMDBField = g_MCPhyBreakerField[nField].nMDBField;
				break;
			case	PG_DISCONNECTOR:
				nMDBField = g_MCPhyDisconnectorField[nField].nMDBField;
				break;
			}

			if (PGGetFieldEnumNum(nTable, nMDBField) > 0)
			{
				int nEnum=PGGetFieldEnumValue(nTable, nMDBField, szRecArray[nField]);
				sprintf(szRecArray[nField], "%d", nEnum);
			}

			//Log(g_lpszLogFile, "DataTable[Grp=%d Item=%d/%d]=%s Value(%s)=%s\n",
			//	nGroup,
			//	nSubitem,
			//	pGrp->GetSubItemsCount(),
			//	PGGetTableDesp(nTable), PGGetFieldDesp(nTable, nField), szValue);
		}
	}

	return 0;
}

void CMCRPhyDataDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nField;
	char	szRecArray[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;
	if (m_nMCPhyTables[nTable] == PG_CONNECTIVITYNODE || m_nMCPhyTables[nTable] == PG_SYNCHRONOUSMACHINE || m_nMCPhyTables[nTable] == PG_ENERGYCONSUMER)
		return;

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szRecArray[i], 0, MDB_CHARLEN_LONG);
	ResolvePropertyValue(m_nMCPhyTables[nTable], szRecArray);

	tagMCRPhyBus			sBusBuffer;
	tagMCRPhyLine			sLineBuffer;
	tagMCRPhyTran			sTranBuffer;
	tagMCRPhyScap			sScapBuffer;
	tagMCRPhyBreaker		sBreakerBuffer;
	tagMCRPhyDisconnector	sDisconnectorBuffer;
	switch (m_nMCPhyTables[nTable])
	{
	case	PG_BUSBARSECTION:
		for (nField=0; nField<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); nField++)
			g_MCRPhyData.SetPhyBusData(&sBusBuffer, nField, szRecArray[nField]);
		g_MCRPhyData.m_BusArray.push_back(sBusBuffer);
		break;
	case	PG_ACLINESEGMENT:
		for (nField=0; nField<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); nField++)
			g_MCRPhyData.SetPhyLineData(&sLineBuffer, nField, szRecArray[nField]);
		g_MCRPhyData.m_LineArray.push_back(sLineBuffer);
		break;
	case	PG_TRANSFORMERWINDING:
		for (nField=0; nField<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); nField++)
			g_MCRPhyData.SetPhyTranData(&sTranBuffer, nField, szRecArray[nField]);
		g_MCRPhyData.m_TranArray.push_back(sTranBuffer);
		break;
	case	PG_SERIESCOMPENSATOR:
		for (nField=0; nField<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); nField++)
			g_MCRPhyData.SetPhyScapData(&sScapBuffer, nField, szRecArray[nField]);
		g_MCRPhyData.m_ScapArray.push_back(sScapBuffer);
		break;
	case	PG_BREAKER:
		for (nField=0; nField<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); nField++)
			g_MCRPhyData.SetPhyBreakerData(&sBreakerBuffer, nField, szRecArray[nField]);
		g_MCRPhyData.m_BreakerArray.push_back(sBreakerBuffer);
		break;
	case	PG_DISCONNECTOR:
		for (nField=0; nField<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); nField++)
			g_MCRPhyData.SetPhyDisconnectorData(&sDisconnectorBuffer, nField, szRecArray[nField]);
		g_MCRPhyData.m_DisconnectorArray.push_back(sDisconnectorBuffer);
		break;
	}

	PrintMessage("���� %s ������ɣ����ֹ�����", PGGetTableDesp(m_nMCPhyTables[nTable]));

	RefreshDataList();
}

void CMCRPhyDataDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;
	if (m_nMCPhyTables[nTable] == PG_CONNECTIVITYNODE || m_nMCPhyTables[nTable] == PG_SYNCHRONOUSMACHINE || m_nMCPhyTables[nTable] == PG_ENERGYCONSUMER)
		return;

	register int	i;
	int			nSelItem = -1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	for (i=0; i<pListCtrl->GetItemCount(); i++)
	{
		if (pListCtrl->GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)
		{
			nSelItem = i;
			break;
		}
	}
	if (nSelItem >= 0 && pListCtrl->GetItemCount())
	{
		switch (m_nMCPhyTables[nTable])
		{
		case	PG_BUSBARSECTION:
			if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_BusArray.size())
				g_MCRPhyData.m_BusArray.erase(g_MCRPhyData.m_BusArray.begin()+nSelItem);
			break;
		case	PG_ACLINESEGMENT:
			if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_LineArray.size())
				g_MCRPhyData.m_LineArray.erase(g_MCRPhyData.m_LineArray.begin()+nSelItem);
			break;
		case	PG_TRANSFORMERWINDING:
			if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_TranArray.size())
				g_MCRPhyData.m_TranArray.erase(g_MCRPhyData.m_TranArray.begin()+nSelItem);
			break;
		case	PG_SERIESCOMPENSATOR:
			if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_ScapArray.size())
				g_MCRPhyData.m_ScapArray.erase(g_MCRPhyData.m_ScapArray.begin()+nSelItem);
			break;
		case	PG_BREAKER:
			if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_BreakerArray.size())
				g_MCRPhyData.m_BreakerArray.erase(g_MCRPhyData.m_BreakerArray.begin()+nSelItem);
			break;
		case	PG_DISCONNECTOR:
			if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_DisconnectorArray.size())
				g_MCRPhyData.m_DisconnectorArray.erase(g_MCRPhyData.m_DisconnectorArray.begin()+nSelItem);
			break;
		}

		PrintMessage("ɾ�� %s ������ɣ����ֹ�����", PGGetTableDesp(m_nMCPhyTables[nTable]));

		RefreshDataList();
	}
}

void CMCRPhyDataDialog::OnBnClickedMod()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nField;
	char		szRecArray[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;
	if (m_nMCPhyTables[nTable] == PG_CONNECTIVITYNODE || m_nMCPhyTables[nTable] == PG_SYNCHRONOUSMACHINE || m_nMCPhyTables[nTable] == PG_ENERGYCONSUMER)
		return;

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szRecArray[i], 0, MDB_CHARLEN_LONG);
	ResolvePropertyValue(m_nMCPhyTables[nTable], szRecArray);

	int			nSelItem = -1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	for (i=0; i<pListCtrl->GetItemCount(); i++)
	{
		if (pListCtrl->GetItemState(i, LVIS_SELECTED) == LVIS_SELECTED)
		{
			nSelItem = i;
			break;
		}
	}

	switch (m_nMCPhyTables[nTable])
	{
	case	PG_BUSBARSECTION:
		if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_BusArray.size())
		{
			for (nField=0; nField<sizeof(g_MCPhyBusField)/sizeof(tagMCRPhyField); nField++)
				g_MCRPhyData.SetPhyBusData(&g_MCRPhyData.m_BusArray[nSelItem], nField, szRecArray[nField]);
		}
		break;
	case	PG_ACLINESEGMENT:
		if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_LineArray.size())
		{
			for (nField=0; nField<sizeof(g_MCPhyLineField)/sizeof(tagMCRPhyField); nField++)
				g_MCRPhyData.SetPhyLineData(&g_MCRPhyData.m_LineArray[nSelItem], nField, szRecArray[nField]);
		}
		break;
	case	PG_TRANSFORMERWINDING:
		if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_TranArray.size())
		{
			for (nField=0; nField<sizeof(g_MCPhyTranField)/sizeof(tagMCRPhyField); nField++)
				g_MCRPhyData.SetPhyTranData(&g_MCRPhyData.m_TranArray[nSelItem], nField, szRecArray[nField]);
		}
		break;
	case	PG_SERIESCOMPENSATOR:
		if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_ScapArray.size())
		{
			for (nField=0; nField<sizeof(g_MCPhyScapField)/sizeof(tagMCRPhyField); nField++)
				g_MCRPhyData.SetPhyScapData(&g_MCRPhyData.m_ScapArray[nSelItem], nField, szRecArray[nField]);
		}
		break;
	case	PG_BREAKER:
		if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_BreakerArray.size())
		{
			for (nField=0; nField<sizeof(g_MCPhyBreakerField)/sizeof(tagMCRPhyField); nField++)
				g_MCRPhyData.SetPhyBreakerData(&g_MCRPhyData.m_BreakerArray[nSelItem], nField, szRecArray[nField]);
		}
		break;
	case	PG_DISCONNECTOR:
		if (nSelItem >= 0 && nSelItem < (int)g_MCRPhyData.m_DisconnectorArray.size())
		{
			for (nField=0; nField<sizeof(g_MCPhyDisconnectorField)/sizeof(tagMCRPhyField); nField++)
				g_MCRPhyData.SetPhyDisconnectorData(&g_MCRPhyData.m_DisconnectorArray[nSelItem], nField, szRecArray[nField]);
		}
		break;
	}

	PrintMessage("�޸� %s ������ɣ����ֹ�����", PGGetTableDesp(m_nMCPhyTables[nTable]));

	RefreshDataList();
}
