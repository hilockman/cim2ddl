#pragma once

#include "../MCRPhyData.h"

// CPGDataDialog �Ի���

class CMCRPGDataDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRPGDataDialog)

public:
	CMCRPGDataDialog(CMCRPhyData* pPhy, CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRPGDataDialog();

// �Ի�������
	enum { IDD = IDD_MCRPGDATA_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeSubCombo();
	afx_msg void OnCbnSelchangeVoltCombo();
	afx_msg void OnBnClickedFormModel();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndDataTab;
	CMFCListCtrl	m_wndListBus,m_wndListLine,m_wndListTran,m_wndListScap,m_wndListBreaker,m_wndListDisconnector;

private:
	void OnFetchData();
	void RefreshPGBusList			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void RefreshPGLineList			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void RefreshPGTranList			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void RefreshPGScapList			(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void RefreshPGBreakerList		(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
	void RefreshPGDisconnectorList	(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt);
private:
	CMCRPhyData*	m_pMCData;
public:
};
