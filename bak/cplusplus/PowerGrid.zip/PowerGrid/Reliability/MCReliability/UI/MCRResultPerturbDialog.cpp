// MCRResultPerturbDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRResultPerturbDialog.h"
#include "../../../../Common/Excel/ExcelAccessor.h"

// CMCRResultPerturbDialog �Ի���
static	char*	lpszPerturbColumn[]=
{
	"�㶯ֵ",
	"(�ۺ�)������(��/��)",
	"(�ۺ�)ƽ��ͣ�����ʱ��(Сʱ/��)",
	"(�ۺ�)��ͣ��ʱ��(Сʱ/��)",
	"(�ۺ�)������(%)",
	"(�ۺ�)������ʧ(����ʱ/��)",

	"(����)������(��/��)",
	"(����)ƽ��ͣ�����ʱ��(Сʱ/��)",
	"(����)��ͣ��ʱ��(Сʱ/��)",
	"(����)������(%)",
	"(����)������ʧ(����ʱ/��)",
};

IMPLEMENT_DYNAMIC(CMCRResultPerturbDialog, CDialog)

CMCRResultPerturbDialog::CMCRResultPerturbDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRResultPerturbDialog::IDD, pParent)
{

}

CMCRResultPerturbDialog::~CMCRResultPerturbDialog()
{
}

void CMCRResultPerturbDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMCRResultPerturbDialog, CDialog)
	ON_BN_CLICKED(IDC_EXCEL_OUT, &CMCRResultPerturbDialog::OnBnClickedExcelOut)
END_MESSAGE_MAP()


// CMCRResultPerturbDialog ��Ϣ��������

BOOL CMCRResultPerturbDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PERTURB_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszPerturbColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszPerturbColumn[i],	LVCFMT_LEFT,	100);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRResultPerturbDialog::Refresh()
{
	RefreshPerturbList();
}

void CMCRResultPerturbDialog::RefreshPerturbList()
{
	register int	i;
	int		nRow, nCol;
	double	fT;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PERTURB_LIST);

	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();

	int		nPerturbNum = (g_MCRPerturb.m_Param.nPerturbType == 0) ?
		((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb)+1 :
		2*((g_MCRPerturb.m_Param.nPerturbNum <= g_nConstMaxReliabilityPerturb) ? g_MCRPerturb.m_Param.nPerturbNum : g_nConstMaxReliabilityPerturb)+1;

	nRow=0;
	for (i=0; i<nPerturbNum; i++)
	{
		sprintf(szBuf, "%d", g_MCRPhyData.m_SystemPerturb[i].nPerturb);		pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol = 1;

		fT = (g_MCRPhyData.m_SystemPerturb[i].fAifi < FLT_MIN) ? 0 : g_MCRPhyData.m_SystemPerturb[i].fAidi/g_MCRPhyData.m_SystemPerturb[i].fAifi;
		sprintf(szBuf, "%f", g_MCRPhyData.m_SystemPerturb[i].fAifi);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", fT);												pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_SystemPerturb[i].fAidi);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", 100*g_MCRPhyData.m_SystemPerturb[i].fAsai);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_SystemPerturb[i].fEns);				pListCtrl->SetItemText(nRow, nCol++, szBuf); 

		fT = (g_MCRPhyData.m_SystemPerturb[i].fFaultAifi < FLT_MIN) ? 0 : g_MCRPhyData.m_SystemPerturb[i].fFaultAidi/g_MCRPhyData.m_SystemPerturb[i].fFaultAifi;
		sprintf(szBuf, "%f", g_MCRPhyData.m_SystemPerturb[i].fFaultAifi);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", fT);												pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_SystemPerturb[i].fFaultAidi);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", 100*g_MCRPhyData.m_SystemPerturb[i].fFaultAsai);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRPhyData.m_SystemPerturb[i].fFaultEns);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPerturbColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRResultPerturbDialog::OnBnClickedExcelOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	int		nRow, nCol;
	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());


	xls.AddSheet("�����߿ɿ����㶯������");
	xls.SetCurSheet("�����߿ɿ����㶯������");

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PERTURB_LIST);

	for (nCol=0; nCol<sizeof(lpszPerturbColumn)/sizeof(char*); nCol++)
		xls.AddCell(lpszPerturbColumn[nCol]);
	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		xls.NewLine();
		for (nCol=0; nCol<sizeof(lpszPerturbColumn)/sizeof(char*); nCol++)
		{
			xls.AddCell(pListCtrl->GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(dlg.GetPathName());
}

void CMCRResultPerturbDialog::SaveAsExcel(ExcelAccessor* pXls)
{
}
