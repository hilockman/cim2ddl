#pragma once
#include "../../../../Common/Excel/ExcelAccessor.h"

// CFaultModeDialog �Ի���

class CMCRResultFModeDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRResultFModeDialog)

public:
	CMCRResultFModeDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRResultFModeDialog();

// �Ի�������
	enum { IDD = IDD_MCRFMODE_RESULT_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedFmode();
	afx_msg void OnBnClickedExcelOut();
	DECLARE_MESSAGE_MAP()

private:
	int				m_nFMode;
	CMFCTabCtrl		m_wndTab;

public:
	void Refresh()
	{
		OnBnClickedFmode();
		RefreshReliabilityIndexList();
		RefreshEconomyIndexList();
	};
private:
	void	SaveFaultAsExcel(ExcelAccessor* pXls, std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array);
	void	RefreshFaultList(std::vector<tagMCRPhyFault1>& sFault1Array, std::vector<tagMCRPhyFault2>& sFault2Array, std::vector<tagMCRPhyFault3>& sFault3Array);
	void	RefreshReliabilityIndexList();
	void	RefreshEconomyIndexList();
public:
	void	SaveAsExcel(ExcelAccessor* pXls);
};
