
// MCReliability.h : PROJECT_NAME Ӧ�ó������ͷ�ļ�
//

#pragma once

#ifndef __AFXWIN_H__
	#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"		// ������
#include "../MCRPhyData.h"
#include "../MCRAlgorithm.h"
#include "../MCRPerturb.h"

#define	WM_ESTIMATEBEG	WM_APP+1001
#define	WM_ESTIMATING	WM_APP+1002
#define	WM_ESTIMATEEND	WM_APP+1003

static	char*	g_lpszReliableModelFileName="MCReliableModel.xml";
static	char*	g_lpszReliableResultFileName="MCReliableResult.xml";
static	char*	g_lpszReliablePerturbFileName="MCReliablePerturb.xml";

// CMCReliabilityApp:
// �йش����ʵ�֣������ MCReliability.cpp
//

class CMCReliabilityApp : public CWinAppEx
{
public:
	CMCReliabilityApp();

// ��д
	public:
	virtual BOOL InitInstance();
	afx_msg void OnMCRCalculationBeg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnMCRCalculating(WPARAM wParam, LPARAM lParam);
	afx_msg void OnMCRCalculationEnd(WPARAM wParam, LPARAM lParam);

// ʵ��

	DECLARE_MESSAGE_MAP()
};

extern CMCReliabilityApp theApp;
extern	tagPGBlock*		g_pPGBlock;

extern	const char*	g_lpszLogFile;
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	void	ClearLog(const char* lpszLogFile);
extern	void	PrintMessage(const char* pformat, ...);

extern	CMCRPhyData		g_MCRPhyData;
extern	CMCRAlgorithm	g_MCRAlgorithm;
extern	CMCRPerturb		g_MCRPerturb;
