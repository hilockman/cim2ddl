
// MCReliabilityDlg.h : ͷ�ļ�
//

#pragma once

#include "MCRParamDialog.h"
#include "MCRPhyDataDialog.h"
#include "MCRAlgDataDialog.h"
#include "MCRResultMinCutDialog.h"
#include "MCRResultFModeDialog.h"
#include "MCRResultPerturbDialog.h"

// CMCReliabilityDlg �Ի���
class CMCReliabilityDlg : public CDialog
{
// ����
public:
	CMCReliabilityDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_MCRELIABILITY_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedExportDatacfg();
	afx_msg void OnBnClickedReliability();
	afx_msg void OnBnClickedClear();
	afx_msg void OnBnClickedLoadFile();
	afx_msg void OnBnClickedSaveFile();
	afx_msg void OnBnClickedMcrperturb();
	afx_msg void OnBnClickedExcel();

	afx_msg LRESULT OnMCRCalculationBegin(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnMCRCalculating(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnMCRCalculationEnded(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl					m_wndTab;
	CMCRParamDialog				m_wndMCRParam;
	CMCRPhyDataDialog			m_wndMCRPhyData;
	CMCRAlgDataDialog			m_wndMCRAlgData;
	CMCRResultMinCutDialog		m_wndMCRMinCut;
	CMCRResultFModeDialog		m_wndMCRFMode;
	CMCRResultPerturbDialog		m_wndMCRPerturb;

public:
	void PrintMessage(const char* lpszMesg);

private:
	int GetTextLen(LPCTSTR lpszText);
private:
	double	m_fFModeRThreshold;
	double	m_fFModeUThreshold;

	BOOL	m_bFCutPlan;
	BOOL	m_bExcludeCommon;
	BOOL	m_bExcludeSwitch;
	BOOL	m_bBreakerFaultFailure;

	int		m_nLifeTime;
	double	m_fEValueRatio;
	double	m_fEPrice;
	double	m_fRecip;
	double	m_fPowerFactor;

private:
	int		m_nMCRAlgNum;
	HANDLE	m_hMCRAlgHandle;
};
