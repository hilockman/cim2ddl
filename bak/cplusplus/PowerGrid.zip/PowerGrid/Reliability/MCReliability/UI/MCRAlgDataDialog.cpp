// MCAlgDataDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MCReliabilityUIApp.h"
#include "MCRAlgDataDialog.h"

// CMCAlgDataDialog �Ի���
static	char*	g_lpszMCAlgDevice[]=
{
	"��Դ",
	"����",
	"�豸",
	"�ڵ�",
	"��ģ",
//	"�л�",
};

static	char*	lpszMCAlgGen[]=
{
	"�豸����",
	"����",
	"����",
	"�ڵ�",
	"����ڵ�",
	"����",
};

static	char*	lpszMCAlgLoad[]=
{
	"�豸����",
	"����",
	"����",
	"�ڵ��",
	"����ڵ�",
	"����",
};

static	char*	lpszMCAlgComp[]=
{
	"�豸����",
	"����",
	"�����ڵ�",
	"����ڵ�",
	"״̬",
	"��Դ",
	"Rerr",
	"Trep",
	"Rchk",
	"Tchk",
	"Topr",
	"TSwitch",
	"����ڵ�I",
	"����ڵ�J",
};

static	char*	lpszMCAlgNode[]=
{
	"�豸����",
	"����",
	"�����ڵ�",
	"�ڵ������豸",
};

static	char*	lpszMCAlgComm[]=
{
	"��·��",
	"��ģ��",
	"�豸",
};

static	char*	lpszMCAlgSwitch[]=
{
	"���뿪��",
	"�л�ʱ��",
	"�л��豸",
	"�л��豸",
};

IMPLEMENT_DYNAMIC(CMCRAlgDataDialog, CDialog)

CMCRAlgDataDialog::CMCRAlgDataDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CMCRAlgDataDialog::IDD, pParent)
{

}

CMCRAlgDataDialog::~CMCRAlgDataDialog()
{
}

void CMCRAlgDataDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMCRAlgDataDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_DATATYPE_COMBO, &CMCRAlgDataDialog::OnCbnSelchangeDatatypeCombo)
	ON_BN_CLICKED(IDC_FORM_MODEL, &CMCRAlgDataDialog::OnBnClickedFormModel)
END_MESSAGE_MAP()


// CMCAlgDataDialog ��Ϣ��������

BOOL CMCRAlgDataDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(g_lpszMCAlgDevice)/sizeof(char*); i++)
		pComboBox->AddString(g_lpszMCAlgDevice[i]);
	pComboBox->SetCurSel(0);

	OnCbnSelchangeDatatypeCombo();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CMCRAlgDataDialog::Refresh()
{
	OnCbnSelchangeDatatypeCombo();
}

void CMCRAlgDataDialog::RefreshGenList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);

	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	while (pListCtrl->DeleteColumn(0));
	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(lpszMCAlgGen)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszMCAlgGen[i],	LVCFMT_LEFT,	100);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRAlgorithm.m_GenArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;

		sprintf(szBuf, "%s[%d]", PGGetTableDesp(g_MCRAlgorithm.m_GenArray[i].nPhyTyp), g_MCRAlgorithm.m_GenArray[i].nPhyIdx);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_MCRAlgorithm.m_GenArray[i].szName);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_GenArray[i].fOutP);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRAlgorithm.m_GenArray[i].nPhyNode);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRAlgorithm.m_GenArray[i].nAlgNode);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		if (g_MCRAlgorithm.m_GenArray[i].bAlone)
			pListCtrl->SetItemText(nRow, nCol++, "��");
		else
			pListCtrl->SetItemText(nRow, nCol++, "��");

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszMCAlgGen)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRAlgDataDialog::RefreshLoadList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);

	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	while (pListCtrl->DeleteColumn(0));
	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(lpszMCAlgLoad)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszMCAlgLoad[i],	LVCFMT_LEFT,	100);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRAlgorithm.m_LoadArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;

		sprintf(szBuf, "%s[%d]", PGGetTableDesp(g_MCRAlgorithm.m_LoadArray[i].nPhyTyp), g_MCRAlgorithm.m_LoadArray[i].nPhyIdx);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_MCRAlgorithm.m_LoadArray[i].szName);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_LoadArray[i].fLoadP);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRAlgorithm.m_LoadArray[i].nPhyNode);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRAlgorithm.m_LoadArray[i].nAlgNode);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		if (g_MCRAlgorithm.m_LoadArray[i].bAlone)
			pListCtrl->SetItemText(nRow, nCol++, "��");
		else
			pListCtrl->SetItemText(nRow, nCol++, "��");

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszMCAlgLoad)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRAlgDataDialog::RefreshCompList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);

	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	while (pListCtrl->DeleteColumn(0));
	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(lpszMCAlgComp)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszMCAlgComp[i],	LVCFMT_LEFT,	100);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRAlgorithm.m_CompArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;

		sprintf(szBuf, "%s[%d]", PGGetTableDesp(g_MCRAlgorithm.m_CompArray[i].nPhyTyp), g_MCRAlgorithm.m_CompArray[i].nPhyIdx);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_MCRAlgorithm.m_CompArray[i].strName.c_str());

		sprintf(szBuf, "%d %d", g_MCRAlgorithm.m_CompArray[i].nIniPhyNode, g_MCRAlgorithm.m_CompArray[i].nEndPhyNode);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d %d", g_MCRAlgorithm.m_CompArray[i].nIniAlgNode, g_MCRAlgorithm.m_CompArray[i].nEndAlgNode);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%d [%d]", g_MCRAlgorithm.m_CompArray[i].nStatus, g_MCRAlgorithm.m_CompArray[i].bFCutPlan);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d %d", g_MCRAlgorithm.m_CompArray[i].bSourceI, g_MCRAlgorithm.m_CompArray[i].bSourceJ);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[i].fRerr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[i].fTrep);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[i].fRchk);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[i].fTchk);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[i].fTopr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[i].fTSwitch);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%d", g_MCRAlgorithm.m_CompArray[i].nIniAlgNode);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_MCRAlgorithm.m_CompArray[i].nEndAlgNode);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszMCAlgComp)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRAlgDataDialog::RefreshNodeList()
{
	register int	i, j;
	int		nRow, nCol, nDev;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);

	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	while (pListCtrl->DeleteColumn(0));
	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(lpszMCAlgNode)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszMCAlgNode[i],	LVCFMT_LEFT,	100);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_MCRAlgorithm.m_NodeArray.size(); i++)
	{
		sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, PGGetTableDesp(g_MCRAlgorithm.m_NodeArray[i].nPhyType));
		pListCtrl->SetItemText(nRow, nCol++, g_MCRAlgorithm.m_NodeArray[i].strName.c_str());
		sprintf(szBuf, "%d", g_MCRAlgorithm.m_NodeArray[i].nPhyNode);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		nRow++;

		for (j=0; j<(int)g_MCRAlgorithm.m_NodeArray[i].nCompArray.size(); j++)
		{
			pListCtrl->InsertItem(nRow, "");

			nCol = 4;
			nDev = g_MCRAlgorithm.m_NodeArray[i].nCompArray[j];
			sprintf(szBuf, "[%d/%d] %s", j+1, g_MCRAlgorithm.m_NodeArray[i].nCompArray.size(), g_MCRAlgorithm.m_CompArray[nDev].strName.c_str());
			pListCtrl->SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszMCAlgNode)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CMCRAlgDataDialog::RefreshCommList()
{
	register int	i;
	int		nComp, nRow, nCol, nDev, nBreaker;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);

	int		nSelItem=-1;
	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem = pListCtrl->GetNextSelectedItem(pos);

	while (pListCtrl->DeleteColumn(0));
	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (i=0; i<sizeof(lpszMCAlgComm)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i+1, lpszMCAlgComm[i],	LVCFMT_LEFT,	100);
	pListCtrl->DeleteAllItems();

	nBreaker = 0;
	nRow=0;
	for (nComp=0; nComp<(int)g_MCRAlgorithm.m_CompArray.size(); nComp++)
	{
		if (g_MCRAlgorithm.m_CompArray[nComp].nPhyTyp != PG_BREAKER)
			continue;

		sprintf(szBuf, "%d", nBreaker++);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);

		nCol=1;

		sprintf(szBuf, "%s[%d %s Status=%d]", PGGetTableDesp(g_MCRAlgorithm.m_CompArray[nComp].nPhyTyp), g_MCRAlgorithm.m_CompArray[nComp].nPhyIdx, g_MCRAlgorithm.m_CompArray[nComp].strName.c_str(), g_MCRAlgorithm.m_CompArray[nComp].nStatus);
		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%d", g_MCRAlgorithm.m_CompArray[nComp].sCmCompArray.size());		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		nRow++;

		for (i=0; i<(int)g_MCRAlgorithm.m_CompArray[nComp].sCmCompArray.size(); i++)
		{
			nCol = 3;
			nDev = g_MCRAlgorithm.m_CompArray[nComp].sCmCompArray[i].nCommComp;
			pListCtrl->InsertItem(nRow, "");		pListCtrl->SetItemData(nRow, nRow);
			if (g_MCRAlgorithm.m_CompArray[nComp].sCmCompArray[i].nCommType == 0)
				sprintf(szBuf, "��ͨ %s[%d %s Status=%d CommType=%d]", PGGetTableDesp(g_MCRAlgorithm.m_CompArray[nDev].nPhyTyp), g_MCRAlgorithm.m_CompArray[nDev].nPhyIdx, g_MCRAlgorithm.m_CompArray[nDev].strName.c_str(), g_MCRAlgorithm.m_CompArray[nDev].nStatus, g_MCRAlgorithm.m_CompArray[nComp].sCmCompArray[i].nCommType);
			else
				sprintf(szBuf, "��ģ %s[%d %s Status=%d CommType=%d]", PGGetTableDesp(g_MCRAlgorithm.m_CompArray[nDev].nPhyTyp), g_MCRAlgorithm.m_CompArray[nDev].nPhyIdx, g_MCRAlgorithm.m_CompArray[nDev].strName.c_str(), g_MCRAlgorithm.m_CompArray[nDev].nStatus, g_MCRAlgorithm.m_CompArray[nComp].sCmCompArray[i].nCommType);

			pListCtrl->SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszMCAlgComm)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
	{
		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

// void CMCRAlgDataDialog::RefreshSwitchList()
// {
// 	register int	i;
// 	int		nComp, nRow, nCol, nDev, nDisconnector;
// 	char	szBuf[260];
// 	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DATA_LIST);
// 
// 	int		nSelItem=-1;
// 	POSITION	pos = pListCtrl->GetFirstSelectedItemPosition();
// 	if (pos)
// 		nSelItem = pListCtrl->GetNextSelectedItem(pos);
// 
// 	while (pListCtrl->DeleteColumn(0));
// 	pListCtrl->InsertColumn(0, "���",	LVCFMT_LEFT,	100);
// 	for (i=0; i<sizeof(lpszMCAlgSwitch)/sizeof(char*); i++)
// 		pListCtrl->InsertColumn(i+1, lpszMCAlgSwitch[i],	LVCFMT_LEFT,	100);
// 	pListCtrl->DeleteAllItems();
// 
// 	nDisconnector = 0;
// 	nRow=0;
// 	for (nComp=0; nComp<(int)g_MCRAlgorithm.m_CompArray.size(); nComp++)
// 	{
// 		if (g_MCRAlgorithm.m_CompArray[nComp].nPhyTyp != PG_DISCONNECTOR)
// 			continue;
// 		if (g_MCRAlgorithm.m_CompArray[nComp].nStatus != 0)
// 			continue;
// 		if (g_MCRAlgorithm.m_CompArray[nComp].nSwCompArray.empty())
// 			continue;
// 
// 		sprintf(szBuf, "%d", nDisconnector++);	pListCtrl->InsertItem(nRow, szBuf);		pListCtrl->SetItemData(nRow, nRow);
// 
// 		nCol=1;
// 
// 		sprintf(szBuf, "%s[%d %s %d]", PGGetTableDesp(g_MCRAlgorithm.m_CompArray[nComp].nPhyTyp), g_MCRAlgorithm.m_CompArray[nComp].nPhyIdx, g_MCRAlgorithm.m_CompArray[nComp].strName.c_str(), g_MCRAlgorithm.m_CompArray[nComp].nStatus);
// 		pListCtrl->SetItemText(nRow, nCol++, szBuf);
// 
// 		sprintf(szBuf, "%f", g_MCRAlgorithm.m_CompArray[nComp].fTSwitch);
// 		pListCtrl->SetItemText(nRow, nCol++, szBuf);
// 
// 		for (i=0; i<(int)g_MCRAlgorithm.m_CompArray[nComp].nSwCompArray.size(); i++)
// 		{
// 			nDev = g_MCRAlgorithm.m_CompArray[nComp].nSwCompArray[i];
// 			sprintf(szBuf, "%s[%d %s %d]", PGGetTableDesp(g_MCRAlgorithm.m_CompArray[nDev].nPhyTyp), g_MCRAlgorithm.m_CompArray[nDev].nPhyIdx, g_MCRAlgorithm.m_CompArray[nDev].strName.c_str(), g_MCRAlgorithm.m_CompArray[nDev].nStatus);
// 			pListCtrl->SetItemText(nRow, nCol++, szBuf);
// 
// 		}
// 
// 		nRow++;
// 	}
// 
// 	int	nColWidth,nHeaderWidth;
// 	for (nCol=0; nCol<sizeof(lpszMCAlgSwitch)/sizeof(char*)+1; nCol++)
// 	{
// 		nColWidth=nHeaderWidth=0;
// 		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
// 		nColWidth = pListCtrl->GetColumnWidth(nCol);
// 		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
// 		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);
// 
// 		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
// 	}
// 
// 	if (nSelItem >= 0 && nSelItem < pListCtrl->GetItemCount())
// 	{
// 		pListCtrl->SetItemState(nSelItem, LVIS_SELECTED, 0xffff);
// 		pListCtrl->EnsureVisible(nSelItem, FALSE);
// 	}
// }

void CMCRAlgDataDialog::OnCbnSelchangeDatatypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DATATYPE_COMBO);
	int			nTable=pCombo->GetCurSel();
	if (nTable == CB_ERR)
		return;

	switch (nTable)
	{
	case	0:
		RefreshGenList();
		break;
	case	1:
		RefreshLoadList();
		break;
	case	2:
		RefreshCompList();
		break;
	case	3:
		RefreshNodeList();
		break;
	case	4:
		RefreshCommList();
		break;
//	case	5:
//		RefreshSwitchList();
//		break;
	default:
		break;
	}
}

void CMCRAlgDataDialog::OnBnClickedFormModel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
	g_MCRAlgorithm.ReadData(&g_MCRPhyData, NULL);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�����ɿ��Լ���ģ����ɣ���ʱ %d ����", nDur);
	PrintMessage("�����ɿ��Լ���ģ����ɣ���ʱ %d ����", nDur);

	char	szTempPath[260], szModelFileName[260];
	GetTempPath(260, szTempPath);
	sprintf(szModelFileName, "%s/%s", szTempPath, g_lpszReliableModelFileName);
	g_MCRAlgorithm.SaveMCReilabilityModel(szModelFileName);

	OnCbnSelchangeDatatypeCombo();
}