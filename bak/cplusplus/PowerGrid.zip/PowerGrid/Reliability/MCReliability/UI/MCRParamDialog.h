#pragma once


// CMCRParamDialog �Ի���

class CMCRParamDialog : public CDialog
{
	DECLARE_DYNAMIC(CMCRParamDialog)

public:
	CMCRParamDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CMCRParamDialog();

	void SetMCRParam(tagMCRParam* pMCRParam)	{	m_pMCRParam = pMCRParam;	};

// �Ի�������
	enum { IDD = IDD_MCRPARAM_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedLoad();
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedImport();
	afx_msg void OnEnChangeParam();
	DECLARE_MESSAGE_MAP()

private:
	void RefreshMCRParam();
	void RefreshMCREconomy();
	void OnEnChangeEconomy();

private:
	tagMCRParam*	m_pMCRParam;
public:
	afx_msg void OnLbnSelchangeVoltList();
};
