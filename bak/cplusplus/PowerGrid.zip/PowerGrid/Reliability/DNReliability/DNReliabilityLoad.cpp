#include "stdafx.h"
#include "DNReliability.h"

//3.1��С·
void CDNREstimate::FormMinPath(const int nLoad, std::vector<tagRMinPath>& sMinPathArray)
{
	register int	i;
	std::vector<int>	nNodeArray, nUnitNodeArray;
	unsigned char	bJointUnit;
	clock_t	dBeg, dEnd;
	int		nDur;

	sMinPathArray.clear();

	for (i=0; i<(int)m_CompArray.size(); i++)
		m_CompArray[i].bExcision=0;
	TraverseRangeNode(m_LoadArray[nLoad].nNewNode, PG_SYNCHRONOUSMACHINE, nNodeArray);
	if (nNodeArray.size() <= 1)
		return;

	nUnitNodeArray.clear();
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (m_NodeArray[nNodeArray[i]].nNodeTyp == PG_SYNCHRONOUSMACHINE)
			nUnitNodeArray.push_back(nNodeArray[i]);
	}

	bJointUnit=0;
	for (i=0; i<(int)nUnitNodeArray.size(); i++)
	{
		if (m_LoadArray[nLoad].nNewNode == nUnitNodeArray[i])
		{
			bJointUnit=1;
			break;
		}
	}
	if (bJointUnit)
		return;

	dBeg=clock();
	if (!m_AlgDisJoint.DisJoint_Init(m_NodeArray, m_CompArray, m_LoadArray[nLoad].nNewNode, nNodeArray))
		return;

	for (i=0; i<(int)nUnitNodeArray.size(); i++)
	{
		m_AlgDisJoint.DisJoint_Calc(nUnitNodeArray[i], nNodeArray);
		m_AlgDisJoint.DisJoint2MinPath(m_NodeArray, m_CompArray, nNodeArray, sMinPathArray);
	}
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ��С·(MinPath=%d) [%d]��ɣ���ʱ%d����\n", sMinPathArray.size(), nUnitNodeArray.size(), nDur);

	register int	j;
	for (i=0; i<(int)sMinPathArray.size(); i++)
	{
		if (sMinPathArray[i].nCompArray.empty())
			continue;

		for (j=0; j<(int)sMinPathArray[i].nCompArray.size(); j++)
		{
			int nComp=sMinPathArray[i].nCompArray[j];
			Log(g_lpszLogFile, "          (��С·-%d)%s, %s, %s, %f, %f, %f, %f\n", i+1, PGGetTableName(m_CompArray[nComp].nDevTyp),
				m_CompArray[nComp].strResID.c_str(), m_CompArray[nComp].strName.c_str(), m_CompArray[nComp].fRerr, m_CompArray[nComp].fTrep, m_CompArray[nComp].fRchk, m_CompArray[nComp].fTchk);
		}
		Log(g_lpszLogFile, "\n");
	}
#endif

	ExtendMinPath(1, m_MinPathArray);	//	�γ�������С·����������С·:
}

void CDNREstimate::ExtendMinPath(const unsigned char bAllExtend, std::vector<tagRMinPath>& sMinPathArray)
{
	register int	i, j;
	int		nNode, nComp, nPath, nCompNum;
	std::vector<int>	nCompNodeArray;

	for (i=0; i<(int)m_CompArray.size(); i++)
		m_CompArray[i].bInPath=0;

	for (nPath=0; nPath<(int)sMinPathArray.size(); nPath++)
	{
		nCompNodeArray.clear();
		//////////////////////////////////////////////////////////////////////////
		//	��ĸ����Ϊ֧·���ӵ�����·����
		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp=sMinPathArray[nPath].nCompArray[i];
			if (m_CompArray[nComp].nNewIniNode != m_CompArray[nComp].nNewEndNode)
			{
				AddUniqueInteger(nCompNodeArray, m_CompArray[nComp].nNewIniNode);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
				AddUniqueInteger(nCompNodeArray, m_CompArray[nComp].nNewEndNode);	//	��·���ڵ㹹�ɵĽڵ㼯�����ڽ���ĸ��֧·�ж�
			}
		}
		for (nNode=0; nNode<(int)nCompNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_NodeArray[nNode].nBusArray.size(); i++)
			{
				nComp = m_NodeArray[nNode].nBusArray[i];
				if (m_CompArray[nComp].fRerr > FLT_MIN && m_CompArray[nComp].fTrep > FLT_MIN)
					AddUniqueInteger(sMinPathArray[nPath].nCompArray, nComp);
			}
			for (i=0; i<(int)m_NodeArray[nNode].nGenArray.size(); i++)
			{
				nComp = m_NodeArray[nNode].nGenArray[i];
				if (m_CompArray[nComp].fRerr > FLT_MIN && m_CompArray[nComp].fTrep > FLT_MIN)
					AddUniqueInteger(sMinPathArray[nPath].nCompArray, nComp);
			}
		}
		//	��ĸ����Ϊ֧·���ӵ�����·����
		//////////////////////////////////////////////////////////////////////////

		//////////////////////////////////////////////////////////////////////////
		//	����С·��������ͨ�豸
		nCompNum=(int)sMinPathArray[nPath].nCompArray.size();
		for (i=0; i<nCompNum; i++)
		{
			nComp=sMinPathArray[nPath].nCompArray[i];
			for (j=0; j<(int)m_CompArray[nComp].sLnkDevArray.size(); j++)
			{
				//	����·�����迼���޿ɿ��Բ����豸����Ϊ��ͨ�豸������������ͨ�ģ������ڹ��Ϲ�ģ����ʱҲ���迼��
				if ((m_CompArray[m_CompArray[nComp].sLnkDevArray[j].nDevice].fRerr < FLT_MIN || m_CompArray[m_CompArray[nComp].sLnkDevArray[j].nDevice].fTrep < FLT_MIN))
					continue;

				AddUniqueInteger(sMinPathArray[nPath].nCompArray, m_CompArray[nComp].sLnkDevArray[j].nDevice);
			}
		}
		//	����С·��������ͨ��ģ�豸
		//////////////////////////////////////////////////////////////////////////

		//	Ϊ������С�����٣�������С·���豸��Ϣ��
		sMinPathArray[nPath].nCompVector.resize(m_CompArray.size(), 0);
		for (i=0; i<(int)sMinPathArray[nPath].nCompArray.size(); i++)
		{
			nComp=sMinPathArray[nPath].nCompArray[i];
			m_CompArray[nComp].bInPath=1;
			sMinPathArray[nPath].nCompVector[nComp]=g_bCompInPathNormal;
		}
	}
}

//3.3.1��ڲ����������Ǽ��ޣ���ͳ�Ĵ�������
void CDNREstimate::ParallelShortcut(const unsigned char bFCutArrange)
{
	register int	i;
	int		nComp, nFComp, nSComp, nTComp;
	double	fFR1, fFR2, fFR3, fFT1, fFT2, fFT3;
	double	fAR1, fAR2, fAR3, fAT1, fAT2, fAT3;

	//һ�׸
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		m_MCutO1Array[i].fR=0;
		m_MCutO1Array[i].fT=0;
		m_MCutO1Array[i].fFaultR=0;
		m_MCutO1Array[i].fFaultT=0;
		m_MCutO1Array[i].fArrangeR=0;
		m_MCutO1Array[i].fArrangeT=0;

		nFComp = m_MCutO1Array[i].nComp;						//��С���е�Ԫ��

		//����
		m_MCutO1Array[i].fFaultR=m_CompArray[nFComp].fRerr;	//��Чͣ���ʣ���/�꣩
		m_MCutO1Array[i].fFaultT=m_CompArray[nFComp].fTrep;	//��Чͣ��ʱ�䣨Сʱ��

		if (bFCutArrange)
		{
			//Ԥ����
			m_MCutO1Array[i].fArrangeR=m_CompArray[nFComp].fRchk;	//��Чͣ���ʣ���/�꣩
			m_MCutO1Array[i].fArrangeT=m_CompArray[nFComp].fTchk;	//��Чͣ��ʱ�䣨Сʱ��

			//�ۺ�
			m_MCutO1Array[i].fR=m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk;
			if (m_MCutO1Array[i].fR > FLT_MIN)	m_MCutO1Array[i].fT=(m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk)/m_MCutO1Array[i].fR;
		}
		else
		{
			//�ۺ�
			m_MCutO1Array[i].fR=m_CompArray[nFComp].fRerr;			//һ�׸�е�Ԫ�ز����Ǽ���
			m_MCutO1Array[i].fT=(m_CompArray[nFComp].fTrep);
		}
	}

	//���׸
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		m_MCutO2Array[i].fR=0;
		m_MCutO2Array[i].fT=0;
		m_MCutO2Array[i].fFaultR=0;
		m_MCutO2Array[i].fFaultT=0;
		m_MCutO2Array[i].fArrangeR=0;
		m_MCutO2Array[i].fArrangeT=0;
// 		m_MCutO2Array[i].fDegreeR=0;
// 		m_MCutO2Array[i].fDegreeT=0;

		nFComp = m_MCutO2Array[i].nComp[0];
		nSComp = m_MCutO2Array[i].nComp[1];

		fFR1=m_CompArray[nFComp].fRerr;
		fFR2=m_CompArray[nSComp].fRerr;
		fFT1=(m_CompArray[nFComp].fTrep);
		fFT2=(m_CompArray[nSComp].fTrep);

		fAR1=m_CompArray[nFComp].fRchk;
		fAR2=m_CompArray[nSComp].fRchk;
		fAT1=m_CompArray[nFComp].fTchk;
		fAT2=m_CompArray[nSComp].fTchk;

		if (m_MCutO2Array[i].bDegreed)
		{
			nComp = m_MCutO2Array[i].nDegreeFComp;

			//����
			m_MCutO2Array[i].fFaultR=m_CompArray[nComp].fRerr;
			m_MCutO2Array[i].fFaultT=m_CompArray[nComp].fTrep;

			//�ۺ�
			m_MCutO2Array[i].fR=m_CompArray[nComp].fRerr+fFR2*fAR1*fAT1/8760+fFR1*fAR2*fAT2/8760;
			if (8760*m_MCutO2Array[i].fR > FLT_MIN)
			{
				m_MCutO2Array[i].fT=m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep;
				if (fAT1+fFT2 > FLT_MIN)	m_MCutO2Array[i].fT += fFR2*fAR1*fAT1*(fAT1*fFT2)/(fAT1+fFT2);											//	1Ԥ����
				m_MCutO2Array[i].fT /= (8760*m_MCutO2Array[i].fR);
			}
		}
		else
		{
			//����
			m_MCutO2Array[i].fFaultR=fFR1*fFR2*(fFT1+fFT2)/8760;
			if (8760*m_MCutO2Array[i].fFaultR > FLT_MIN)
				m_MCutO2Array[i].fFaultT=(fFR1*fFT1*fFR2*fFT2)/(m_MCutO2Array[i].fFaultR*8760);

			//�ۺ�
			m_MCutO2Array[i].fR=fFR1*fFR2*(fFT1+fFT2)/8760+fFR2*fAR1*fAT1/8760+fFR1*fAR2*fAT2/8760;
			if (8760*m_MCutO2Array[i].fR > FLT_MIN)
			{
				m_MCutO2Array[i].fT=fFR1*fFR2*fFT1*fFT2;
				if (fAT1+fFT2 > FLT_MIN)	m_MCutO2Array[i].fT += fFR2*fAR1*fAT1*(fAT1*fFT2)/(fAT1+fFT2);											//	1Ԥ����
				if (fFT1+fAT2 > FLT_MIN)	m_MCutO2Array[i].fT += fFR1*fAR2*fAT2*(fFT1*fAT2)/(fFT1+fAT2);										 	//	2Ԥ����
				m_MCutO2Array[i].fT /= (8760*m_MCutO2Array[i].fR);
			}
		}

		//Ԥ����
		m_MCutO2Array[i].fArrangeR=m_MCutO2Array[i].fR-m_MCutO2Array[i].fFaultR;
		if (8760*m_MCutO2Array[i].fArrangeR > FLT_MIN)
			m_MCutO2Array[i].fArrangeT=(m_MCutO2Array[i].fR*m_MCutO2Array[i].fT-m_MCutO2Array[i].fFaultR*m_MCutO2Array[i].fFaultT)/m_MCutO2Array[i].fArrangeR;
	}

	//����
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		m_MCutO3Array[i].fR=0;
		m_MCutO3Array[i].fT=0;
		m_MCutO3Array[i].fFaultR=0;
		m_MCutO3Array[i].fFaultT=0;
		m_MCutO3Array[i].fArrangeR=0;
		m_MCutO3Array[i].fArrangeT=0;

		nFComp = m_MCutO3Array[i].nComp[0];
		nSComp = m_MCutO3Array[i].nComp[1];
		nTComp = m_MCutO3Array[i].nComp[2];

		fFR1=m_CompArray[nFComp].fRerr;
		fFR2=m_CompArray[nSComp].fRerr;
		fFR3=m_CompArray[nTComp].fRerr;
		fFT1=m_CompArray[nFComp].fTrep;
		fFT2=m_CompArray[nSComp].fTrep;
		fFT3=m_CompArray[nTComp].fTrep;

		fAR1=m_CompArray[nFComp].fRchk;
		fAR2=m_CompArray[nSComp].fRchk;
		fAR3=m_CompArray[nTComp].fRchk;
		fAT1=m_CompArray[nFComp].fTchk;
		fAT2=m_CompArray[nSComp].fTchk;
		fAT3=m_CompArray[nTComp].fTchk;
		if (m_MCutO3Array[i].bDegreed)
		{
			if (m_MCutO3Array[i].nCutType == DNREnumCutType_3Degree1)
			{
				//	�豸1Ϊ���׺�����豸
				if (m_MCutO3Array[i].nDegreeFComp[0] == nFComp)
				{
				}
				else if (m_MCutO3Array[i].nDegreeFComp[0] == nSComp)
				{
					fFR1=m_CompArray[nSComp].fRerr;
					fFR2=m_CompArray[nFComp].fRerr;
					fFR3=m_CompArray[nTComp].fRerr;
					fFT1=m_CompArray[nSComp].fTrep;
					fFT2=m_CompArray[nFComp].fTrep;
					fFT3=m_CompArray[nTComp].fTrep;

					fAR1=m_CompArray[nSComp].fRchk;
					fAR2=m_CompArray[nFComp].fRchk;
					fAR3=m_CompArray[nTComp].fRchk;
					fAT1=m_CompArray[nSComp].fTchk;
					fAT2=m_CompArray[nFComp].fTchk;
					fAT3=m_CompArray[nTComp].fTchk;
				}
				else
				{
					fFR1=m_CompArray[nTComp].fRerr;
					fFR2=m_CompArray[nFComp].fRerr;
					fFR3=m_CompArray[nSComp].fRerr;
					fFT1=m_CompArray[nTComp].fTrep;
					fFT2=m_CompArray[nFComp].fTrep;
					fFT3=m_CompArray[nSComp].fTrep;

					fAR1=m_CompArray[nTComp].fRchk;
					fAR2=m_CompArray[nFComp].fRchk;
					fAR3=m_CompArray[nSComp].fRchk;
					fAT1=m_CompArray[nTComp].fTchk;
					fAT2=m_CompArray[nFComp].fTchk;
					fAT3=m_CompArray[nSComp].fTchk;
				}

				//����
				m_MCutO3Array[i].fFaultR=fFR1;
				m_MCutO3Array[i].fFaultT=fFT1;

				//�ۺ�
				m_MCutO3Array[i].fR = m_MCutO3Array[i].fFaultR;
				m_MCutO3Array[i].fR += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1/(8760*8760);																								//	1Ԥ����
				if (8760*8760*m_MCutO3Array[i].fR > FLT_MIN)
				{
					m_MCutO3Array[i].fT = m_MCutO3Array[i].fFaultR*m_MCutO3Array[i].fFaultT;
					if ((fAT1*fFT2+fAT1*fFT3+fFT2*fFT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1*(fAT1*fFT2*fFT3)/(fAT1*fFT2+fAT1*fFT3+fFT2*fFT3);	//	1Ԥ����
					m_MCutO3Array[i].fT /= (8760*8760*m_MCutO3Array[i].fR);
				}
			}
			else
			{
				//	�豸3Ϊ���׺󽵽��豸
				if (m_MCutO3Array[i].nDegreeFComp[0] != nFComp && m_MCutO3Array[i].nDegreeFComp[1] != nFComp)
				{
					fFR1=m_CompArray[nSComp].fRerr;
					fFR2=m_CompArray[nTComp].fRerr;
					fFR3=m_CompArray[nFComp].fRerr;
					fFT1=m_CompArray[nSComp].fTrep;
					fFT2=m_CompArray[nTComp].fTrep;
					fFT3=m_CompArray[nFComp].fTrep;

					fAR1=m_CompArray[nSComp].fRchk;
					fAR2=m_CompArray[nTComp].fRchk;
					fAR3=m_CompArray[nFComp].fRchk;
					fAT1=m_CompArray[nSComp].fTchk;
					fAT2=m_CompArray[nTComp].fTchk;
					fAT3=m_CompArray[nFComp].fTchk;
				}
				else if (m_MCutO3Array[i].nDegreeFComp[0] != nSComp && m_MCutO3Array[i].nDegreeFComp[1] != nSComp)
				{
					fFR1=m_CompArray[nFComp].fRerr;
					fFR2=m_CompArray[nTComp].fRerr;
					fFR3=m_CompArray[nSComp].fRerr;
					fFT1=m_CompArray[nFComp].fTrep;
					fFT2=m_CompArray[nTComp].fTrep;
					fFT3=m_CompArray[nSComp].fTrep;

					fAR1=m_CompArray[nFComp].fRchk;
					fAR2=m_CompArray[nTComp].fRchk;
					fAR3=m_CompArray[nSComp].fRchk;
					fAT1=m_CompArray[nFComp].fTchk;
					fAT2=m_CompArray[nTComp].fTchk;
					fAT3=m_CompArray[nSComp].fTchk;
				}
				else
				{
				}

				//����
				m_MCutO3Array[i].fFaultR=fFR1*fFR2*(fFT1+fFT2)/8760;
				if (8760*m_MCutO3Array[i].fFaultR > FLT_MIN)
					m_MCutO3Array[i].fFaultT = fFR1*fFR2*fFT1*fFT2 / (8760*m_MCutO3Array[i].fFaultR);

				//�ۺ�
				m_MCutO3Array[i].fR = m_MCutO3Array[i].fFaultR;
				m_MCutO3Array[i].fR += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1/(8760*8760);																								//	1Ԥ����
				m_MCutO3Array[i].fR += fFR1*fFR3*(fFT1+fFT3)*fAR2*fAT2/(8760*8760);																								//	2Ԥ����
				if (8760*8760*m_MCutO3Array[i].fR > FLT_MIN)
				{
					m_MCutO3Array[i].fT = m_MCutO3Array[i].fFaultR*m_MCutO3Array[i].fFaultT;
					if ((fAT1*fFT2+fAT1*fFT3+fFT2*fFT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1*(fAT1*fFT2*fFT3)/(fAT1*fFT2+fAT1*fFT3+fFT2*fFT3);	//	1Ԥ����
					if ((fFT1*fAT2+fFT1*fFT3+fAT2*fFT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR1*fFR3*(fFT1+fFT3)*fAR2*fAT2*(fFT1*fAT2*fFT3)/(fFT1*fAT2+fFT1*fFT3+fAT2*fFT3);	//	2Ԥ����
					m_MCutO3Array[i].fT /= (8760*8760*m_MCutO3Array[i].fR);
				}
			}
		}
		else
		{
			//����
			m_MCutO3Array[i].fFaultR=fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)/(8760*8760);
			if (8760*8760*m_MCutO3Array[i].fFaultR > FLT_MIN)
				m_MCutO3Array[i].fFaultT=(fFR1*fFR2*fFR3*fFT1*fFT2*fFT3)/(m_MCutO3Array[i].fFaultR*8760*8760);

			//�ۺ�
			m_MCutO3Array[i].fR = fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)/(8760*8760);
			m_MCutO3Array[i].fR += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1/(8760*8760);																									//	1Ԥ����
			m_MCutO3Array[i].fR += fFR1*fFR3*(fFT1+fFT3)*fAR2*fAT2/(8760*8760);																									//	2Ԥ����
			m_MCutO3Array[i].fR += fFR1*fFR2*(fFT1+fFT2)*fAR3*fAT3/(8760*8760);																									//	3Ԥ����
			if (8760*8760*m_MCutO3Array[i].fR > FLT_MIN)
			{
				m_MCutO3Array[i].fT = 0;
				if ((fFT1*fFT2+fFT1*fFT3+fFT2*fFT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR1*fFR2*fFR3*(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3)*(fFT1*fFT2*fFT3)/(fFT1*fFT2+fFT1*fFT3+fFT2*fFT3);
				if ((fAT1*fFT2+fAT1*fFT3+fFT2*fFT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR2*fFR3*(fFT2+fFT3)*fAR1*fAT1*(fAT1*fFT2*fFT3)/(fAT1*fFT2+fAT1*fFT3+fFT2*fFT3);		//	1Ԥ����
				if ((fFT1*fAT2+fFT1*fFT3+fAT2*fFT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR1*fFR3*(fFT1+fFT3)*fAR2*fAT2*(fFT1*fAT2*fFT3)/(fFT1*fAT2+fFT1*fFT3+fAT2*fFT3);		//	2Ԥ����
				if ((fFT1*fFT2+fFT1*fAT3+fFT2*fAT3) > FLT_MIN)	m_MCutO3Array[i].fT += fFR1*fFR2*(fFT1+fFT2)*fAR3*fAT3*(fFT1*fFT2*fAT3)/(fFT1*fFT2+fFT1*fAT3+fFT2*fAT3);		//	3Ԥ����
				m_MCutO3Array[i].fT /= (8760*8760*m_MCutO3Array[i].fR);
			}
		}

		//Ԥ����
		m_MCutO3Array[i].fArrangeR=m_MCutO3Array[i].fR-m_MCutO3Array[i].fFaultR;
		if (8760*8760*m_MCutO3Array[i].fArrangeR > FLT_MIN)
			m_MCutO3Array[i].fArrangeT=(m_MCutO3Array[i].fR*m_MCutO3Array[i].fT-m_MCutO3Array[i].fFaultR*m_MCutO3Array[i].fFaultT)/m_MCutO3Array[i].fArrangeR;
	}

	for (i=0; i<(int)m_CmMCutO1Array.size(); i++)
	{
		m_CmMCutO1Array[i].fR = 0;
		m_CmMCutO1Array[i].fT = 0;

		nFComp = m_CmMCutO1Array[i].nComp;

		m_CmMCutO1Array[i].fR=m_CompArray[nFComp].fRerr;
		m_CmMCutO1Array[i].fT=(m_CompArray[nFComp].fTFLoc <= m_CompArray[nFComp].fTrep || m_CompArray[nFComp].fTrep <= FLT_MIN) ? m_CompArray[nFComp].fTFLoc : m_CompArray[nFComp].fTrep;	//��Чͣ��ʱ�䣨Сʱ��
	}

	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
	{
		m_CmMCutO2Array[i].fR = 0;
		m_CmMCutO2Array[i].fT = 0;

		nFComp = m_CmMCutO2Array[i].nComp[0];
		nSComp = m_CmMCutO2Array[i].nComp[1];

		fFR1=m_CompArray[nFComp].fRerr;
		fFR2=m_CompArray[nSComp].fRerr;
		fFT1=(m_CompArray[nFComp].fTFLoc <= m_CompArray[nFComp].fTrep || m_CompArray[nFComp].fTrep <= FLT_MIN) ? m_CompArray[nFComp].fTFLoc : m_CompArray[nFComp].fTrep;
		fFT2=(m_CompArray[nSComp].fTFLoc <= m_CompArray[nSComp].fTrep || m_CompArray[nSComp].fTrep <= FLT_MIN) ? m_CompArray[nSComp].fTFLoc : m_CompArray[nSComp].fTrep;

		m_CmMCutO2Array[i].fR=fFR1*fFR2*(fFT1+fFT2)/8760;
		if (8760*m_CmMCutO2Array[i].fR > FLT_MIN)
			m_CmMCutO2Array[i].fT = fFR1*fFR2*fFT1*fFT2 / (8760*m_CmMCutO2Array[i].fR);
	}
}

//3.5��䴮������ÿ������ݵõ����ɵ�����
void CDNREstimate::SeriesShortcut()
{
	register int	i;
	double	fMCut1R, fMCut2R, fMCut3R;
	double	fMCut1T, fMCut2T, fMCut3T;

	m_fLoadR=0;
	m_fLoadT=0;
	m_fLoadU=0;
	m_fLoadFaultR=0;
	m_fLoadFaultT=0;
	m_fLoadFaultU=0;
	m_fLoadArrangeR=0;
	m_fLoadArrangeT=0;
	m_fLoadArrangeU=0;
	m_fLoadSwitchR=0;
	m_fLoadSwitchT=0;
	m_fLoadSwitchU=0;
	m_fLoadCommonR=0;
	m_fLoadCommonT=0;
	m_fLoadCommonU=0;

	//	����ͣ�������
	//		1���豸����ͣ��
	//			1.1���豸�������ͣ�磻������Ͻ������豸�ĸ
	//			1.2���豸���׹���ͣ�磻���׺��ý��׸��ͣ��Ƶ�ʺ�ʱ���滻��
	//		1���豸�л�ͣ��
	//////////////////////////////////////////////////////////////////////////
	//	�л��㷨��������л�ʱ��Ϊ�����л�ʱ�䣬��Ϊ�л��Ƚ��鷳���漰�����ɵĹ����豸��ת���豸֮����л���
	//		1�����ȹ����豸��ת���豸֮��һ��Ϊ���׻����׸
	//		2����������豸״̬���򹩵��豸Ϊһ�׸�������ʺ��л�ʱ�乹�ɸ��ɵ�ͣ��Ƶ�ʺ�ʱ�䣬���������������豸״̬�������޴˰취��
	//		3�����㷨�������п��ܵ��л�״̬���������л�Ƶ�ʺ�ʱ���ЧΪ���ɵ��л���
	fMCut1R=fMCut2R=fMCut3R=0;
	fMCut1T=fMCut2T=fMCut3T=0;

	//���׼��л�
	double	fMaxSwitchU=-100000000;
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if (m_MCutO2Array[i].fSwitchR*m_MCutO2Array[i].fSwitchT < FLT_MIN)
			continue;

		if (fMaxSwitchU < m_MCutO2Array[i].fSwitchR*m_MCutO2Array[i].fSwitchT)
		{
			fMaxSwitchU=m_MCutO2Array[i].fSwitchR*m_MCutO2Array[i].fSwitchT;
			fMCut1R=m_MCutO2Array[i].fSwitchR;
			fMCut1T=m_MCutO2Array[i].fSwitchT;
		}
	}
	//���׼��л�
	fMaxSwitchU=-100000000;
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if (m_MCutO3Array[i].fSwitchR*m_MCutO3Array[i].fSwitchT < FLT_MIN)
			continue;

		if (fMaxSwitchU < m_MCutO3Array[i].fSwitchR*m_MCutO3Array[i].fSwitchT)
		{
			fMaxSwitchU=m_MCutO3Array[i].fSwitchR*m_MCutO3Array[i].fSwitchT;
			fMCut2R=m_MCutO3Array[i].fSwitchR;
			fMCut2T=m_MCutO3Array[i].fSwitchT;
		}
	}
	//�Ľ׼��л�
	fMaxSwitchU=-100000000;
	for (i=0; i<(int)m_MCutO4Array.size(); i++)
	{
		if (m_MCutO4Array[i].fSwitchR*m_MCutO4Array[i].fSwitchT < FLT_MIN)
			continue;

		if (fMaxSwitchU < m_MCutO4Array[i].fSwitchR*m_MCutO4Array[i].fSwitchT)
		{
			fMaxSwitchU=m_MCutO4Array[i].fSwitchR*m_MCutO4Array[i].fSwitchT;
			fMCut3R=m_MCutO4Array[i].fSwitchR;
			fMCut3T=m_MCutO4Array[i].fSwitchT;
		}
	}

	if (fMCut1R*fMCut1T > fMCut2R*fMCut2T && fMCut1R*fMCut1T > fMCut3R*fMCut3T)
	{
		m_fLoadSwitchR=fMCut1R;
		m_fLoadSwitchU=fMCut1R*fMCut1T;
	}
	else if (fMCut2R*fMCut2T > fMCut1R*fMCut1T && fMCut2R*fMCut2T > fMCut3R*fMCut3T)
	{
		m_fLoadSwitchR=fMCut2R;
		m_fLoadSwitchU=fMCut2R*fMCut2T;
	}
	else
	{
		m_fLoadSwitchR=fMCut3R;
		m_fLoadSwitchU=fMCut3R*fMCut3T;
	}

	if (m_fLoadSwitchR > FLT_MIN)
		m_fLoadSwitchT=m_fLoadSwitchU/m_fLoadSwitchR;
	//Log(g_lpszLogFile,  "        �����л��л� R=%f T=%f U=%f\n", m_fLoadSwitchR, m_fLoadSwitchT, m_fLoadSwitchU);
	//	�л��㷨
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	//	��ģ����
	fMCut1R=fMCut2R=fMCut3R=0;
	fMCut1T=fMCut2T=fMCut3T=0;

	//һ�׼乲ģ���ϴ���
	for (i=0; i<(int)m_CmMCutO1Array.size(); i++)
	{
		if (m_CmMCutO1Array[i].fR < FLT_MIN || m_CmMCutO1Array[i].fT < FLT_MIN)
			continue;

		fMCut1T += m_CmMCutO1Array[i].fR*m_CmMCutO1Array[i].fT;
		fMCut1R += m_CmMCutO1Array[i].fR;
	}
	if (fMCut1R > FLT_MIN)
		fMCut1T /= fMCut1R;

	//���׼乲ģ���ϴ���
	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
	{
		if (m_CmMCutO2Array[i].fR < FLT_MIN || m_CmMCutO2Array[i].fT < FLT_MIN)
			continue;

		fMCut2T += m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT;
		fMCut2R += m_CmMCutO2Array[i].fR;
	}
	if (fMCut2R > FLT_MIN)
		fMCut2T /= fMCut2R;

	//��ģ���崮��
	m_fLoadCommonR=fMCut1R+fMCut2R+fMCut3R;
	m_fLoadCommonU=fMCut1R*fMCut1T+fMCut2R*fMCut2T+fMCut3R*fMCut3T;
	if (m_fLoadCommonR > FLT_MIN)
		m_fLoadCommonT=m_fLoadCommonU/m_fLoadCommonR;
	//	��ģ����
	//////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ��㹲ģ������
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	fMCut1R=fMCut2R=fMCut3R=0;
	fMCut1T=fMCut2T=fMCut3T=0;

	//////////////////////////////////////////////////////////////////////////
	//ǿ��ͣ��һ�׼䴮��
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		if (m_MCutO1Array[i].fFaultR < FLT_MIN || m_MCutO1Array[i].fFaultT < FLT_MIN)
			continue;

		fMCut1T += m_MCutO1Array[i].fFaultR*m_MCutO1Array[i].fFaultT;
		fMCut1R += m_MCutO1Array[i].fFaultR;
	}
	if (fMCut1R > FLT_MIN)
		fMCut1T /= fMCut1R;

	//////////////////////////////////////////////////////////////////////////
	//ǿ��ͣ�˶��׼䴮��, �����뱾����Ǵ�����ϵ���������׸������豸ͬʱ���ϸ���ͣ�磬�����豸���ϣ�����ͣ��
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if (m_MCutO2Array[i].fFaultR < FLT_MIN || m_MCutO2Array[i].fFaultT < FLT_MIN)
			continue;
		fMCut2T += m_MCutO2Array[i].fFaultR*m_MCutO2Array[i].fFaultT;
		fMCut2R += m_MCutO2Array[i].fFaultR;
	}
	if (fMCut2R > FLT_MIN)
		fMCut2T /= fMCut2R;

	//////////////////////////////////////////////////////////////////////////
	//ǿ��ͣ�����׼䴮��
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if (m_MCutO3Array[i].fFaultR < FLT_MIN || m_MCutO3Array[i].fFaultT < FLT_MIN)
			continue;

		fMCut3T += m_MCutO3Array[i].fFaultR*m_MCutO3Array[i].fFaultT;
		fMCut3R += m_MCutO3Array[i].fFaultR;
	}
	if (fMCut3R > FLT_MIN)
		fMCut3T /= fMCut3R;

	//////////////////////////////////////////////////////////////////////////
	//����ǿ��ͣ�����崮��
	m_fLoadFaultR=fMCut1R+fMCut2R+fMCut3R;
	if (m_fLoadFaultR > FLT_MIN)
		m_fLoadFaultT=(fMCut1R*fMCut1T+fMCut2R*fMCut2T+fMCut3R*fMCut3T)/m_fLoadFaultR;
	m_fLoadFaultU=m_fLoadFaultR*m_fLoadFaultT;

	m_fLoadFaultR += (m_fLoadSwitchR+m_fLoadCommonR);
	m_fLoadFaultU += (m_fLoadSwitchR*m_fLoadSwitchT+m_fLoadCommonR*m_fLoadCommonT);
	if (m_fLoadFaultR > FLT_MIN)
		m_fLoadFaultT=m_fLoadFaultU/m_fLoadFaultR;

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ����豸���ϣ���������
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	fMCut1R=fMCut2R=fMCut3R=0;
	fMCut1T=fMCut2T=fMCut3T=0;

	//�ƻ�ͣ��һ�׼䴮��
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		if (m_MCutO1Array[i].fArrangeR < FLT_MIN || m_MCutO1Array[i].fArrangeT < FLT_MIN)
			continue;

		fMCut1T += m_MCutO1Array[i].fArrangeR*m_MCutO1Array[i].fArrangeT;
		fMCut1R += m_MCutO1Array[i].fArrangeR;
	}
	if (fMCut1R > FLT_MIN)
		fMCut1T /= fMCut1R;

	//�ƻ�ͣ�˶��׼䴮��
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if ((fMCut2R+m_MCutO2Array[i].fArrangeR) < FLT_MIN)
			continue;

		fMCut2T = (fMCut2T*fMCut2R+m_MCutO2Array[i].fArrangeR*m_MCutO2Array[i].fArrangeT)/(fMCut2R+m_MCutO2Array[i].fArrangeR);
		fMCut2R += m_MCutO2Array[i].fArrangeR;
	}
	//�ƻ�ͣ�����׼䴮��
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if ((fMCut3R+m_MCutO3Array[i].fArrangeR) < FLT_MIN)
			continue;

		fMCut3T = (fMCut3T*fMCut3R+m_MCutO3Array[i].fArrangeR*m_MCutO3Array[i].fArrangeT)/(fMCut3R+m_MCutO3Array[i].fArrangeR);
		fMCut3R += m_MCutO3Array[i].fArrangeR;
	}

	//�ƻ�ͣ�����崮��
	m_fLoadArrangeR=fMCut1R+fMCut2R+fMCut3R;
	m_fLoadArrangeU=fMCut1R*fMCut1T+fMCut2R*fMCut2T+fMCut3R*fMCut3T;
	if (m_fLoadArrangeR > FLT_MIN)
		m_fLoadArrangeT=m_fLoadArrangeU/m_fLoadArrangeR;
	//	���ɲ���������Ԥ����ͣ��

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ���ƻ�ͣ��
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	fMCut1R=fMCut2R=fMCut3R=0;
	fMCut1T=fMCut2T=fMCut3T=0;
	//�ۺ�һ�׼䴮��
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		if ((fMCut1R+m_MCutO1Array[i].fR) < FLT_MIN)
			continue;

		fMCut1T = (fMCut1T*fMCut1R+m_MCutO1Array[i].fR*m_MCutO1Array[i].fT)/(fMCut1R+m_MCutO1Array[i].fR);
		fMCut1R += m_MCutO1Array[i].fR;
	}
	//�ۺ϶��׼䴮��
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if ((fMCut2R+m_MCutO2Array[i].fR) < FLT_MIN)
			continue;

		fMCut2T = (fMCut2T*fMCut2R+m_MCutO2Array[i].fR*m_MCutO2Array[i].fT)/(fMCut2R+m_MCutO2Array[i].fR);
		fMCut2R += m_MCutO2Array[i].fR;
	}
	//�ۺ����׼䴮��
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if ((fMCut3R+m_MCutO3Array[i].fR) < FLT_MIN)
			continue;

		fMCut3T = (fMCut3T*fMCut3R+m_MCutO3Array[i].fR*m_MCutO3Array[i].fT)/(fMCut3R+m_MCutO3Array[i].fR);
		fMCut3R += m_MCutO3Array[i].fR;
	}

	//���崮��
	m_fLoadR=fMCut1R+fMCut2R+fMCut3R;
	m_fLoadU=fMCut1R*fMCut1T+fMCut2R*fMCut2T+fMCut3R*fMCut3T;
	if (m_fLoadR > FLT_MIN)
		m_fLoadT=m_fLoadU/m_fLoadR;

#ifdef _DEBUG
	Log(g_lpszLogFile,  "�����ǹ�ģ���л� R=%f T=%f U=%f\n", m_fLoadR, m_fLoadT, m_fLoadU);
#endif
	m_fLoadR += (m_fLoadSwitchR+m_fLoadCommonR);
	m_fLoadU += (m_fLoadSwitchR*m_fLoadSwitchT+m_fLoadCommonR*m_fLoadCommonT);
	if (m_fLoadR > FLT_MIN)
		m_fLoadT=m_fLoadU/m_fLoadR;

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ���ǹ�ģ���л� R=%f T=%f U=%f    SwU=%f CmU=%f\n",
		m_fLoadR, m_fLoadT, m_fLoadU, m_fLoadSwitchR*m_fLoadSwitchT, m_fLoadCommonR*m_fLoadCommonT);
#endif
}

