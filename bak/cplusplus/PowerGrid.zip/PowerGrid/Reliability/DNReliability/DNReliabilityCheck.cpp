#include "stdafx.h"
#include "DNReliability.h"

int		CDNREstimate::isSwitchBreaker(const int nDevice)
{
	if (m_CompArray[nDevice].nDevTyp != PG_BREAKER)
		return 0;

	if (m_CompArray[nDevice].fRSwitch > FLT_MIN && m_CompArray[nDevice].fTSwitch > FLT_MIN)
		return 1;

	return 0;
}

int CDNREstimate::isInFcmComp(const int nComp, const int nCmComp)
{
	register int	i;

	for (i=0; i<(int)m_CompArray[nComp].sFCmDevArray.size(); i++)
	{
		if (m_CompArray[nComp].sFCmDevArray[i].nDevice == nCmComp)
			return 1;
	}
	return 0;
}


int CDNREstimate::isInMCut01(const int nComp)
{
	register int	i;
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		if (m_MCutO1Array[i].nComp == nComp)
			return 1;
	}
	return 0;
}

int CDNREstimate::isInMCut02(const int nComp1, const int nComp2)
{
	register int	i;
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if (m_MCutO2Array[i].nComp[0] == nComp1 && m_MCutO2Array[i].nComp[1] == nComp2 ||
			m_MCutO2Array[i].nComp[1] == nComp1 && m_MCutO2Array[i].nComp[0] == nComp2)
			return 1;
	}
	return 0;
}

int CDNREstimate::isInMCut03(const int nComp1, const int nComp2, const int nComp3)
{
	register int	i;
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if (m_MCutO3Array[i].nComp[0] == nComp1 && m_MCutO3Array[i].nComp[1] == nComp2 && m_MCutO3Array[i].nComp[2] == nComp3 ||
			m_MCutO3Array[i].nComp[1] == nComp1 && m_MCutO3Array[i].nComp[0] == nComp2 && m_MCutO3Array[i].nComp[2] == nComp3 ||
			m_MCutO3Array[i].nComp[2] == nComp1 && m_MCutO3Array[i].nComp[1] == nComp2 && m_MCutO3Array[i].nComp[0] == nComp3 ||
			m_MCutO3Array[i].nComp[0] == nComp1 && m_MCutO3Array[i].nComp[2] == nComp2 && m_MCutO3Array[i].nComp[1] == nComp3 ||
			m_MCutO3Array[i].nComp[1] == nComp1 && m_MCutO3Array[i].nComp[2] == nComp2 && m_MCutO3Array[i].nComp[0] == nComp3 ||
			m_MCutO3Array[i].nComp[2] == nComp1 && m_MCutO3Array[i].nComp[0] == nComp2 && m_MCutO3Array[i].nComp[1] == nComp3)
			return 1;
	}
	return 0;
}

int CDNREstimate::isInMCut04(const int nComp1, const int nComp2, const int nComp3, const int nComp4)
{
	register int	i;
	for (i=0; i<(int)m_MCutO4Array.size(); i++)
	{
		if (m_MCutO4Array[i].nComp[0] == nComp1 && m_MCutO4Array[i].nComp[1] == nComp2 && m_MCutO4Array[i].nComp[2] == nComp3 && m_MCutO4Array[i].nComp[3] == nComp4 ||
			m_MCutO4Array[i].nComp[0] == nComp1 && m_MCutO4Array[i].nComp[1] == nComp2 && m_MCutO4Array[i].nComp[3] == nComp3 && m_MCutO4Array[i].nComp[2] == nComp4 ||
			m_MCutO4Array[i].nComp[0] == nComp1 && m_MCutO4Array[i].nComp[2] == nComp2 && m_MCutO4Array[i].nComp[1] == nComp3 && m_MCutO4Array[i].nComp[3] == nComp4 ||
			m_MCutO4Array[i].nComp[0] == nComp1 && m_MCutO4Array[i].nComp[2] == nComp2 && m_MCutO4Array[i].nComp[3] == nComp3 && m_MCutO4Array[i].nComp[1] == nComp4 ||
			m_MCutO4Array[i].nComp[0] == nComp1 && m_MCutO4Array[i].nComp[3] == nComp2 && m_MCutO4Array[i].nComp[1] == nComp3 && m_MCutO4Array[i].nComp[2] == nComp4 ||
			m_MCutO4Array[i].nComp[0] == nComp1 && m_MCutO4Array[i].nComp[3] == nComp2 && m_MCutO4Array[i].nComp[2] == nComp3 && m_MCutO4Array[i].nComp[1] == nComp4 ||

			m_MCutO4Array[i].nComp[1] == nComp1 && m_MCutO4Array[i].nComp[0] == nComp2 && m_MCutO4Array[i].nComp[2] == nComp3 && m_MCutO4Array[i].nComp[3] == nComp4 ||
			m_MCutO4Array[i].nComp[1] == nComp1 && m_MCutO4Array[i].nComp[0] == nComp2 && m_MCutO4Array[i].nComp[3] == nComp3 && m_MCutO4Array[i].nComp[2] == nComp4 ||
			m_MCutO4Array[i].nComp[1] == nComp1 && m_MCutO4Array[i].nComp[2] == nComp2 && m_MCutO4Array[i].nComp[0] == nComp3 && m_MCutO4Array[i].nComp[3] == nComp4 ||
			m_MCutO4Array[i].nComp[1] == nComp1 && m_MCutO4Array[i].nComp[2] == nComp2 && m_MCutO4Array[i].nComp[3] == nComp3 && m_MCutO4Array[i].nComp[0] == nComp4 ||
			m_MCutO4Array[i].nComp[1] == nComp1 && m_MCutO4Array[i].nComp[3] == nComp2 && m_MCutO4Array[i].nComp[0] == nComp3 && m_MCutO4Array[i].nComp[2] == nComp4 ||
			m_MCutO4Array[i].nComp[1] == nComp1 && m_MCutO4Array[i].nComp[3] == nComp2 && m_MCutO4Array[i].nComp[2] == nComp3 && m_MCutO4Array[i].nComp[0] == nComp4 ||

			m_MCutO4Array[i].nComp[2] == nComp1 && m_MCutO4Array[i].nComp[0] == nComp2 && m_MCutO4Array[i].nComp[1] == nComp3 && m_MCutO4Array[i].nComp[3] == nComp4 ||
			m_MCutO4Array[i].nComp[2] == nComp1 && m_MCutO4Array[i].nComp[0] == nComp2 && m_MCutO4Array[i].nComp[3] == nComp3 && m_MCutO4Array[i].nComp[1] == nComp4 ||
			m_MCutO4Array[i].nComp[2] == nComp1 && m_MCutO4Array[i].nComp[1] == nComp2 && m_MCutO4Array[i].nComp[0] == nComp3 && m_MCutO4Array[i].nComp[3] == nComp4 ||
			m_MCutO4Array[i].nComp[2] == nComp1 && m_MCutO4Array[i].nComp[1] == nComp2 && m_MCutO4Array[i].nComp[3] == nComp3 && m_MCutO4Array[i].nComp[0] == nComp4 ||
			m_MCutO4Array[i].nComp[2] == nComp1 && m_MCutO4Array[i].nComp[3] == nComp2 && m_MCutO4Array[i].nComp[0] == nComp3 && m_MCutO4Array[i].nComp[1] == nComp4 ||
			m_MCutO4Array[i].nComp[2] == nComp1 && m_MCutO4Array[i].nComp[3] == nComp2 && m_MCutO4Array[i].nComp[1] == nComp3 && m_MCutO4Array[i].nComp[0] == nComp4 ||

			m_MCutO4Array[i].nComp[3] == nComp1 && m_MCutO4Array[i].nComp[0] == nComp2 && m_MCutO4Array[i].nComp[1] == nComp3 && m_MCutO4Array[i].nComp[2] == nComp4 ||
			m_MCutO4Array[i].nComp[3] == nComp1 && m_MCutO4Array[i].nComp[0] == nComp2 && m_MCutO4Array[i].nComp[2] == nComp3 && m_MCutO4Array[i].nComp[1] == nComp4 ||
			m_MCutO4Array[i].nComp[3] == nComp1 && m_MCutO4Array[i].nComp[1] == nComp2 && m_MCutO4Array[i].nComp[0] == nComp3 && m_MCutO4Array[i].nComp[2] == nComp4 ||
			m_MCutO4Array[i].nComp[3] == nComp1 && m_MCutO4Array[i].nComp[1] == nComp2 && m_MCutO4Array[i].nComp[2] == nComp3 && m_MCutO4Array[i].nComp[0] == nComp4 ||
			m_MCutO4Array[i].nComp[3] == nComp1 && m_MCutO4Array[i].nComp[2] == nComp2 && m_MCutO4Array[i].nComp[0] == nComp3 && m_MCutO4Array[i].nComp[1] == nComp4 ||
			m_MCutO4Array[i].nComp[3] == nComp1 && m_MCutO4Array[i].nComp[2] == nComp2 && m_MCutO4Array[i].nComp[1] == nComp3 && m_MCutO4Array[i].nComp[0] == nComp4)
			return 1;
	}
	return 0;
}

int CDNREstimate::isInDegreeMCut01(const int nComp)
{
	register int	i;
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if (!m_MCutO2Array[i].bDegreed)
			continue;

		if (m_MCutO2Array[i].nDegreeFComp == nComp)
			return 1;
	}
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if (m_MCutO3Array[i].bDegreed != 2)
			continue;

		if (m_MCutO3Array[i].nDegreeFComp[0] == nComp)
			return 1;
	}
	return 0;
}

int CDNREstimate::isInDegreeMCut02(const int nComp1, const int nComp2)
{
	register int	i;
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if (!m_MCutO3Array[i].bDegreed != 1)
			continue;

		if (m_MCutO3Array[i].nDegreeFComp[0] == nComp1 && m_MCutO3Array[i].nDegreeFComp[1] == nComp2 ||
			m_MCutO3Array[i].nDegreeFComp[0] == nComp2 && m_MCutO3Array[i].nDegreeFComp[1] == nComp1)
			return 1;
	}

	return 0;
}

int CDNREstimate::isInCommonMCut01(const int nComp)
{
	register int	i;
	for (i=0; i<(int)m_CmMCutO1Array.size(); i++)
	{
		if (m_CmMCutO1Array[i].nComp == nComp)
			return 1;
	}
	return 0;
}

int CDNREstimate::isInCommonMCut02(const int nComp1, const int nComp2)
{
	register int	i;
	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
	{
		if (m_CmMCutO2Array[i].nComp[0] == nComp1 && m_CmMCutO2Array[i].nComp[1] == nComp2 ||
			m_CmMCutO2Array[i].nComp[1] == nComp1 && m_CmMCutO2Array[i].nComp[0] == nComp2)
			return 1;
	}
	return 0;
}
