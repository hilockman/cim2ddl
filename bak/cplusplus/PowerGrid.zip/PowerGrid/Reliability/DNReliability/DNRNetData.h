#pragma once

#include "DNRDataDefine.h"

class CDNRNetData
{
public:
	CDNRNetData(void);
	~CDNRNetData(void);

public:
	tagRData	m_RData;

public:
	int		ReadData(tagPGBlock* pPGBlock, const unsigned char bReadWTPV = 1);
	void	InitRXml(const char* lpszFileName, const char* lpszRootTag);
	void	EndRXml(const char* lpszFileName, const char* lpszRootTag);
	int		InitData(tagPGBlock* pPGBlock);

	void	OutData_SysCalc(tagPGBlock* pPGBlock, const char* lpszRResultFile);
	void	OutData_SysPerturbCalc(tagPGBlock* pPGBlock);

	void	ParsePerturb(const int nStartArg=0, int argc=0, char** argv=NULL);

private:
	void	ReadData_Gen(tagPGBlock* pPGBlock, const unsigned char bReadWTPV);
	void	ReadData_Node(tagPGBlock* pPGBlock, const unsigned char bReadWTPV);
	void	ReadData_Load(tagPGBlock* pPGBlock);
	void	ReadData_Comp_Line(tagPGBlock* pPGBlock);
	void	ReadData_Comp_Wind(tagPGBlock* pPGBlock);
	void	ReadData_Comp_Breaker(tagPGBlock* pPGBlock);
	void	ReadData_Comp_Disconnector(tagPGBlock* pPGBlock);
	void	ReadData_Comp_SCap(tagPGBlock* pPGBlock);
	void	ReadData_Comp_Bus(tagPGBlock* pPGBlock);

	void	ReadData_PostRead();
	void	ReadData_FormCommonModel();

private:
	int		IsNodeJointSourceWithinVoltage(tagPGBlock* pPGBlock, const int nJudgeNode);
	int		IsBreakerNodeJointSource(tagPGBlock* pPGBlock, const int nJudgeNode, const int nBreaker);
	int		IsTransformerWindingAsSource(tagPGBlock* pPGBlock, const int nTran, const int nTranNode);
private:
	int		isInLnkComp(const int nComp, const int nCheckComp);
	int		isInFcmComp(const int nComp, const int nCmComp);
private:
	void	AddComp(std::vector<tagCmComp>& cmCompArray, const int nDevice, const int nSideNode);
	void	TraceCommComp(const int nCheckDevice, const int nIniNode, std::vector<tagCmComp>& sCompArray);
	void	TraverseLinkComp(const int nCheckDevice, const int nIniNode, std::vector<tagCmComp>& sCompArray);
	void	TraverseRangeNode(const int nIniNode, std::vector<int>& nRgnNodeArray);
	void	TraverseRangeLoad(const int nIniNode, std::vector<int>& nRgnLoadArray);

private:
	void	SaveSystemRResult(tagPGBlock* pPGBlock, const char* lpszRResultFile);

private:
	void	PrevPerturb();
	void	PerturbAmend(const int nPerturb);
	void	PerturbRestore();
	std::vector<tagRCompBackup>	m_CompBackArray;		//	�������ⲿ���صı�������

private:
	int		ReadRDataFile(const char* lpszFileName=NULL);
	void	SaveRDataFile(const char* lpszFileName=NULL);

private:
	void	InitializeRNode(tagRNode* pData);
	void	InitializeRComp(tagRComp* pData);
	void	InitializeRLoad(tagRLoad* pData);
};

extern	const	char*	g_lpszLogFile;
extern	void	Log(const char* lpszLogFile, char* pformat, ...);

