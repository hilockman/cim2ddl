
// ReliablilityOutputDoc.cpp : CReliablilityOutputDoc ���ʵ��
//

#include "stdafx.h"
#include "DNReliabilityDetail.h"
#include "DNReliabilityDetailDoc.h"
#include "../../../../Common/Excel/ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CReliablilityOutputDoc

IMPLEMENT_DYNCREATE(CReliablilityOutputDoc, CDocument)

BEGIN_MESSAGE_MAP(CReliablilityOutputDoc, CDocument)
	ON_COMMAND(ID_REFRESH_RRESULT, &CReliablilityOutputDoc::OnRefresh)
	ON_COMMAND(ID_LOAD_RDETAIL, &CReliablilityOutputDoc::OnLoadRdetail)
END_MESSAGE_MAP()


// CReliablilityOutputDoc ����/����

CReliablilityOutputDoc::CReliablilityOutputDoc()
{
	// TODO: �ڴ�����һ���Թ������

}

CReliablilityOutputDoc::~CReliablilityOutputDoc()
{
	register int	i;

	m_DNRLoadArray.clear();
	m_DNRAreaArray.clear();

	for (i=0; i<(int)m_DNRMinPathArray.size(); i++)
		InitializeDNRMinPath(m_DNRMinPathArray[i]);
	m_DNRMinPathArray.clear();

	m_MCutO1Array.clear();
	m_MCutO2Array.clear();
	m_MCutO3Array.clear();
}

BOOL CReliablilityOutputDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: �ڴ��������³�ʼ������
	// (SDI �ĵ������ø��ĵ�)
	OnRefresh();

	return TRUE;
}




// CReliablilityOutputDoc ���л�

void CReliablilityOutputDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: �ڴ����Ӵ洢����
	}
	else
	{
		// TODO: �ڴ����Ӽ��ش���
	}
}


// CReliablilityOutputDoc ���

#ifdef _DEBUG
void CReliablilityOutputDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CReliablilityOutputDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CReliablilityOutputDoc ����

int CReliablilityOutputDoc::ParseSysXml(void)
{
	TiXmlElement	*pLine, *pSub;
	TiXmlAttribute*	pAttr;

	tagDNRSubcontrolAreaUI	rArea;
	tagDNRLoadUI			sLoad;

	memset(&m_DNRSystem, 0, sizeof(tagDNRSystemUI));
	m_DNRLoadArray.clear();
	m_DNRAreaArray.clear();

	char	szTempPath[260], szFileName[260];
	GetTempPath(260, szTempPath);
	sprintf(szFileName, "%s/%s", szTempPath, g_lpszSysReliableResultFileName);
	if (access(szFileName, 0) != 0)
		return 0;

	TiXmlDocument doc(szFileName);
	if (!doc.LoadFile())
	{
		TRACE("XMLError=%s\n", doc.ErrorDesc());
		return 0;
	}

	TiXmlElement* pRoot = doc.RootElement();
	pLine=pRoot->FirstChildElement();

	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), "SystemReliablilityResult") == 0)
		{
			pSub = pLine->FirstChildElement();
			while (pSub != NULL)
			{
				if (stricmp(pSub->Value(), "SystemRResult") == 0)
				{
					pAttr = pSub->FirstAttribute();
					while (pAttr != NULL)
					{
						if (stricmp(pAttr->Name(), "Cid") == 0)				m_DNRSystem.CID			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Aci") == 0)		m_DNRSystem.ACI			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Asai") == 0)		m_DNRSystem.ASAI		=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Ens") == 0)		m_DNRSystem.ENS			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Saifi") == 0)		m_DNRSystem.SAIFI		=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Saidi") == 0)		m_DNRSystem.SAIDI		=atof(pAttr->Value());

						else if (stricmp(pAttr->Name(), "FaultCid") == 0)	m_DNRSystem.Fault_CID	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultAci") == 0)	m_DNRSystem.Fault_ACI	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultAsai") == 0)	m_DNRSystem.Fault_ASAI	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultEns") == 0)	m_DNRSystem.Fault_ENS	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultSaifi") == 0)	m_DNRSystem.Fault_SAIFI	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultSaidi") == 0)	m_DNRSystem.Fault_SAIDI	=atof(pAttr->Value());

						pAttr = pAttr->Next();
					}
				}
				else if (stricmp(pSub->Value(), "SubcontrolAreaRResult") == 0)
				{
					InitializeDNRSubControlArea(rArea);

					pAttr = pSub->FirstAttribute();
					while (pAttr != NULL)
					{
						if (stricmp(pAttr->Name(), "ResID") == 0)					rArea.strAreaID		=pAttr->Value();
						else if (stricmp(pAttr->Name(), "Name") == 0)				rArea.strAreaName	=pAttr->Value();
						else if (stricmp(pAttr->Name(), "Substation") == 0)			rArea.nSubstation	=atoi(pAttr->Value());
						else if (stricmp(pAttr->Name(), "LoadPoint") == 0)			rArea.nLoadPoint	=atoi(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Customer") == 0)			rArea.fCustomers	=(float)atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "P") == 0)					rArea.fP			=atof(pAttr->Value());

						else if (stricmp(pAttr->Name(), "Cid") == 0)				rArea.CID			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Aci") == 0)				rArea.ACI			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Asai") == 0)				rArea.ASAI			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Ens") == 0)				rArea.ENS			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Saifi") == 0)				rArea.SAIFI			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Saidi") == 0)				rArea.SAIDI			=atof(pAttr->Value());

						else if (stricmp(pAttr->Name(), "FaultCid") == 0)			rArea.Fault_CID		=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultAci") == 0)			rArea.Fault_ACI		=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultAsai") == 0)			rArea.Fault_ASAI	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultEns") == 0)			rArea.Fault_ENS		=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultSaifi") == 0)			rArea.Fault_SAIFI	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FaultSaidi") == 0)			rArea.Fault_SAIDI	=atof(pAttr->Value());

						else if (stricmp(pAttr->Name(), "RContribution") == 0)		rArea.fRContribution	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "UContribution") == 0)		rArea.fUContribution	=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "ENSContribution") == 0)	rArea.fENSRate			=atof(pAttr->Value());

						pAttr = pAttr->Next();
					}
					if (!rArea.strAreaName.empty())		m_DNRAreaArray.push_back(rArea);
				}
				else if (stricmp(pSub->Value(), "EnergyConsumerRResult") == 0)
				{
					InitializeDNRLoad(sLoad);

					pAttr = pSub->FirstAttribute();
					while (pAttr != NULL)
					{
						if (stricmp(pAttr->Name(), "ResID") == 0)					sLoad.strResID			= pAttr->Value();
						else if (stricmp(pAttr->Name(), "Name") == 0)				sLoad.strName			= pAttr->Value();
						else if (stricmp(pAttr->Name(), "SubcontrolArea") == 0)		sLoad.strSubcontrolArea	= pAttr->Value();
						else if (stricmp(pAttr->Name(), "Substation") == 0)			sLoad.strSubstation		= pAttr->Value();
						else if (stricmp(pAttr->Name(), "P") == 0)					sLoad.fP				=(float)atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "Customer") == 0)			sLoad.fCustomer			=(float)atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "R") == 0)					sLoad.fR				=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "U") == 0)					sLoad.fU				=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "T") == 0)					sLoad.fT				=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FR") == 0)					sLoad.fFaultR			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FU") == 0)					sLoad.fFaultU			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FT") == 0)					sLoad.fFaultT			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "AR") == 0)					sLoad.fArrangeR			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "AU") == 0)					sLoad.fArrangeU			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "AT") == 0)					sLoad.fArrangeT			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "RCTime") == 0)				sLoad.fRCTime			=(float)atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "RCCase") == 0)				sLoad.strRCCase			=pAttr->Value();

						else if (stricmp(pAttr->Name(), "SwR") == 0)				sLoad.fSwitchR			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "SwU") == 0)				sLoad.fSwitchU			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "SwT") == 0)				sLoad.fSwitchT			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "CmR") == 0)				sLoad.fCommonR			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "CmU") == 0)				sLoad.fCommonU			=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "CmT") == 0)				sLoad.fCommonT			=atof(pAttr->Value());

						else if (stricmp(pAttr->Name(), "Ens") == 0)				sLoad.fENS				=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "FEns") == 0)				sLoad.fFENS				=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "AEns") == 0)				sLoad.fAENS				=atof(pAttr->Value());

						else if (stricmp(pAttr->Name(), "RContribution") == 0)		sLoad.fRContribution=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "UContribution") == 0)		sLoad.fUContribution=atof(pAttr->Value());
						else if (stricmp(pAttr->Name(), "ENSContribution") == 0)	sLoad.fENSContribution=atof(pAttr->Value());

						pAttr = pAttr->Next();
					}
					m_DNRLoadArray.push_back(sLoad);
				}

				pSub = pSub->NextSiblingElement();
			}
		}

		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();

	return 1;
}

int CReliablilityOutputDoc::ParseLoadXml(const char* lpszLoadName)
{
	TiXmlAttribute*	pAttr;
	TiXmlElement*	pElement;

	int		nCutComp;
	std::vector<std::string>	strEleArray;

	tagDNRUIComp			sCompBuf;
	tagRMinPathUI			sPathBuf;
	tagDNRMCut01UI			sMCut1;
	tagDNRMCut02UI			sMCut2;
	tagDNRMCut03UI			sMCut3;
	tagDNRLoadUI			sLoad;

	InitializeDNRLoad(sLoad);
	InitializeDNRMinPath(sPathBuf);
	InitializeDNRMCut01(sMCut1);
	InitializeDNRMCut02(sMCut2);
	InitializeDNRMCut03(sMCut3);

	m_DNRMinPathArray.clear();
	m_MCutO1Array.clear();
	m_MCutO2Array.clear();
	m_MCutO3Array.clear();

	char	szTempPath[260], szFileName[260];
	GetTempPath(260, szTempPath);
	sprintf(szFileName, "%s/%s", szTempPath, g_lpszSysReliableResultFileName);
	if (access(szFileName, 0) != 0)
		return 0;

	TiXmlDocument doc(szFileName);
	if (!doc.LoadFile())
	{
		TRACE("XMLError=%s\n", doc.ErrorDesc());
		return 0;
	}

	TiXmlElement* pRoot = doc.RootElement();
	if (!pRoot)
		return 0;

	TiXmlElement	*pLine, *pSub;
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), "EnergyConsumerReliablityResult") != 0)
		{
			pLine = pLine->NextSiblingElement();
			continue;
		}
		if (stricmp(pLine->Attribute("Name"), lpszLoadName) != 0)
		{
			pLine = pLine->NextSiblingElement();
			continue;
		}

		pAttr=pLine->FirstAttribute();
		while (pAttr != NULL)
		{
			if (stricmp(pAttr->Name(), "ResID") == 0)				sLoad.strResID			= pAttr->Value();
			else if (stricmp(pAttr->Name(), "Name") == 0)			sLoad.strName			= pAttr->Value();
			else if (stricmp(pAttr->Name(), "SubcontrolArea") == 0)	sLoad.strSubcontrolArea	= pAttr->Value();
			else if (stricmp(pAttr->Name(), "Substation") == 0)		sLoad.strSubstation		= pAttr->Value();
			else if (stricmp(pAttr->Name(), "P") == 0)				sLoad.fP				=(float)atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "Customer") == 0)		sLoad.fCustomer			=(float)atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "R") == 0)				sLoad.fR				=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "U") == 0)				sLoad.fU				=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "T") == 0)				sLoad.fT				=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "FR") == 0)				sLoad.fFaultR			=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "FU") == 0)				sLoad.fFaultU			=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "FT") == 0)				sLoad.fFaultT			=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "AR") == 0)				sLoad.fArrangeR			=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "AU") == 0)				sLoad.fArrangeU			=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "AT") == 0)				sLoad.fArrangeT			=atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "RCTime") == 0)			sLoad.fRCTime			=(float)atof(pAttr->Value());
			else if (stricmp(pAttr->Name(), "RCCase") == 0)			sLoad.strRCCase			=pAttr->Value();

			pAttr = pAttr->Next();
		}

		pSub = pLine->FirstChildElement();
		while (pSub != NULL)
		{
			if (stricmp(pSub->Value(), "MinPath") == 0)
			{
				pElement=pSub->FirstChildElement();

				sPathBuf.sCompArray.clear();
				while (pElement != NULL)
				{
					if (stricmp(pElement->Value(), "PathComp") == 0)
					{
						pAttr=pElement->FirstAttribute();
						while (pAttr != NULL)
						{
							if (stricmp(pAttr->Name(), "Type") == 0)			sCompBuf.strType=pAttr->Value();
							else if (stricmp(pAttr->Name(), "ResID") == 0)		sCompBuf.strResID=pAttr->Value();
							else if (stricmp(pAttr->Name(), "Name") == 0)		sCompBuf.strName=pAttr->Value();
							else if (stricmp(pAttr->Name(), "Rerr") == 0)		sCompBuf.fRerr=atof(pAttr->Value());
							else if (stricmp(pAttr->Name(), "Trep") == 0)		sCompBuf.fTrep=atof(pAttr->Value());
							else if (stricmp(pAttr->Name(), "Rchk") == 0)		sCompBuf.fRchk=atof(pAttr->Value());
							else if (stricmp(pAttr->Name(), "Tchk") == 0)		sCompBuf.fTchk=atof(pAttr->Value());
							pAttr = pAttr->Next();
						}
						sPathBuf.sCompArray.push_back(sCompBuf);
					}
					pElement = pElement->NextSiblingElement();
				}
				m_DNRMinPathArray.push_back(sPathBuf);
			}
			else if (stricmp(pSub->Value(), "MinCut01") == 0)
			{
				pAttr=pSub->FirstAttribute();

				while (pAttr != NULL)
				{
					if (stricmp(pAttr->Name(), "CutType") == 0)				sMCut1.strCutType=pAttr->Value();

					else if (stricmp(pAttr->Name(), "CompType") == 0)		sMCut1.strCompType=pAttr->Value();
					else if (stricmp(pAttr->Name(), "CompID") == 0)			sMCut1.strCompID=pAttr->Value();
					else if (stricmp(pAttr->Name(), "CompName") == 0)		sMCut1.strCompName=pAttr->Value();

					else if (stricmp(pAttr->Name(), "CmBreaker1") == 0)		sMCut1.strCmBreaker[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "CmBreaker2") == 0)		sMCut1.strCmBreaker[1]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "CmBreaker3") == 0)		sMCut1.strCmBreaker[2]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "R") == 0)				sMCut1.fR=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "T") == 0)				sMCut1.fT=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "U") == 0)				sMCut1.fU=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "FR") == 0)				sMCut1.fFaultR=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "FT") == 0)				sMCut1.fFaultT=atof(pAttr->Value());

					else if (stricmp(pAttr->Name(), "RContribution") == 0)	sMCut1.fRContribution=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "UContribution") == 0)	sMCut1.fUContribution=atof(pAttr->Value());
					pAttr = pAttr->Next();
				}
				m_MCutO1Array.push_back(sMCut1);
			}
			else if (stricmp(pSub->Value(), "MinCut02") == 0)
			{
				pAttr=pSub->FirstAttribute();

				nCutComp=0;
				InitializeDNRMCut02(sMCut2);

				while (pAttr != NULL)
				{
					if (stricmp(pAttr->Name(), "CutType") == 0)				sMCut2.strCutType=pAttr->Value();

					else if (stricmp(pAttr->Name(), "Comp1Type") == 0)		sMCut2.strCompType[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp1ID") == 0)		sMCut2.strCompID[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp1Name") == 0)		sMCut2.strCompName[0]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "Comp2Type") == 0)		sMCut2.strCompType[1]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp2ID") == 0)		sMCut2.strCompID[1]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp2Name") == 0)		sMCut2.strCompName[1]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "CmBreaker1") == 0)		sMCut2.strCmBreaker[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "CmBreaker2") == 0)		sMCut2.strCmBreaker[1]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "CmBreaker3") == 0)		sMCut2.strCmBreaker[2]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "R") == 0)			{	sMCut2.fR=atof(pAttr->Value());			sMCut2.fR /= 1000.0;		}
					else if (stricmp(pAttr->Name(), "T") == 0)				sMCut2.fT=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "U") == 0)				sMCut2.fU=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "FR") == 0)			{	sMCut2.fFaultR=atof(pAttr->Value());	sMCut2.fFaultR /= 1000.0;	}
					else if (stricmp(pAttr->Name(), "FT") == 0)				sMCut2.fFaultT=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "AR") == 0)			{	sMCut2.fArrangeR=atof(pAttr->Value());	sMCut2.fArrangeR /= 1000.0;	}
					else if (stricmp(pAttr->Name(), "AT") == 0)				sMCut2.fArrangeT=atof(pAttr->Value());

					else if (stricmp(pAttr->Name(), "DegreeFComp") == 0)	sMCut2.strDegreeComp=pAttr->Value();

					else if (stricmp(pAttr->Name(), "RContribution") == 0)	sMCut2.fRContribution=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "UContribution") == 0)	sMCut2.fUContribution=atof(pAttr->Value());
					pAttr = pAttr->Next();
				}
				m_MCutO2Array.push_back(sMCut2);
			}
			else if (stricmp(pSub->Value(), "MinCut03") == 0)
			{
				pAttr=pSub->FirstAttribute();

				nCutComp=0;
				InitializeDNRMCut03(sMCut3);

				while (pAttr != NULL)
				{
					if (stricmp(pAttr->Name(), "CutType") == 0)				sMCut3.strCutType=pAttr->Value();

					else if (stricmp(pAttr->Name(), "Comp1Type") == 0)		sMCut3.strCompType[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp1ID") == 0)		sMCut3.strCompID[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp1Name") == 0)		sMCut3.strCompName[0]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "Comp2Type") == 0)		sMCut3.strCompType[1]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp2ID") == 0)		sMCut3.strCompID[1]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp2Name") == 0)		sMCut3.strCompName[1]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "Comp3Type") == 0)		sMCut3.strCompType[2]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp3ID") == 0)		sMCut3.strCompID[2]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "Comp3Name") == 0)		sMCut3.strCompName[2]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "DegreeFComp1") == 0)	sMCut3.strDegreeComp[0]=pAttr->Value();
					else if (stricmp(pAttr->Name(), "DegreeFComp2") == 0)	sMCut3.strDegreeComp[1]=pAttr->Value();

					else if (stricmp(pAttr->Name(), "R") == 0)			{	sMCut3.fR=atof(pAttr->Value());			sMCut3.fR /= 1000000.0;			}
					else if (stricmp(pAttr->Name(), "T") == 0)				sMCut3.fT=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "U") == 0)				sMCut3.fU=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "FR") == 0)			{	sMCut3.fFaultR=atof(pAttr->Value());	sMCut3.fFaultR /= 1000000.0;	}
					else if (stricmp(pAttr->Name(), "FT") == 0)				sMCut3.fFaultT=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "AR") == 0)			{	sMCut3.fArrangeR=atof(pAttr->Value());	sMCut3.fArrangeR /= 1000000.0;	}
					else if (stricmp(pAttr->Name(), "AT") == 0)				sMCut3.fArrangeT=atof(pAttr->Value());

					else if (stricmp(pAttr->Name(), "RContribution") == 0)	sMCut3.fRContribution=atof(pAttr->Value());
					else if (stricmp(pAttr->Name(), "UContribution") == 0)	sMCut3.fUContribution=atof(pAttr->Value());
					pAttr = pAttr->Next();
				}
				m_MCutO3Array.push_back(sMCut3);
			}

			pSub = pSub->NextSiblingElement();
		}

		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();

	return 1;
}


void CReliablilityOutputDoc::OnRefresh()
{
	// TODO: �ڴ�����������������
	ParseSysXml();
	AfxGetMainWnd()->PostMessage(UM_REFRESH_SYSR_RESULT, 0, 0);
}

void CReliablilityOutputDoc::InitializeDNRLoad(tagDNRLoadUI& sLoad)
{
	sLoad.strResID.clear();
	sLoad.strName.clear();
	sLoad.strSubcontrolArea.clear();
	sLoad.strSubstation.clear();

	sLoad.fCustomer = 0;
	sLoad.fP = 0;

	sLoad.fR = 0;
	sLoad.fT = 0;
	sLoad.fU = 0;
	sLoad.fFaultR = 0;
	sLoad.fFaultT = 0;
	sLoad.fFaultU = 0;
	sLoad.fArrangeR = 0;
	sLoad.fArrangeT = 0;
	sLoad.fArrangeU = 0;
	sLoad.fSwitchR = 0;
	sLoad.fSwitchT = 0;
	sLoad.fSwitchU = 0;
	sLoad.fCommonR = 0;
	sLoad.fCommonT = 0;
	sLoad.fCommonU = 0;

	sLoad.fENS = 0;
	sLoad.fFENS = 0;
	sLoad.fAENS = 0;

	sLoad.fRCTime = 0;
	sLoad.strRCCase.clear();
	sLoad.fRContribution = 0;
	sLoad.fUContribution = 0;
	sLoad.fENSContribution = 0;
}

void CReliablilityOutputDoc::InitializeDNRSubControlArea(tagDNRSubcontrolAreaUI& sArea)
{
	sArea.strAreaID.clear();
	sArea.strAreaName.clear();
	sArea.nSubstation=0;
	sArea.nLoadPoint=0;
	sArea.fCustomers=0;
	sArea.fP=0;
	sArea.ACI=0;
	sArea.CID=0;
	sArea.ASAI=0;
	sArea.ENS=0;
	sArea.Fault_ACI=0;
	sArea.Fault_CID=0;
	sArea.Fault_ASAI=0;
	sArea.Fault_ENS=0;
	sArea.SAIFI=0;
	sArea.SAIDI=0;
	sArea.Fault_SAIFI=0;
	sArea.Fault_SAIDI=0;
	sArea.fRContribution=0;
	sArea.fUContribution=0;
	sArea.fENSRate=0;
}

void CReliablilityOutputDoc::InitializeDNRMinPath(tagRMinPathUI& sPath)
{
	sPath.fProb=0;
	sPath.sCompArray.clear();
}

void CReliablilityOutputDoc::InitializeDNRMCut01(tagDNRMCut01UI sData)
{
	register int	i;

	sData.strCutType.clear();
	sData.strCompType.clear();
	sData.strCompID.clear();
	sData.strCompName.clear();

	for (i=0; i<3; i++)
		sData.strCmBreaker[i].clear();	//	��ģ�滻

	sData.fR=0;
	sData.fT=0;
	sData.fU=0;
	sData.fFaultR=0;
	sData.fFaultT=0;
	sData.fRContribution=0;
	sData.fUContribution=0;
}

void CReliablilityOutputDoc::InitializeDNRMCut02(tagDNRMCut02UI sData)
{
	register int	i;
	sData.strCutType.clear();

	for (i=0; i<2; i++)
	{
		sData.strCompType[i].clear();
		sData.strCompID[i].clear();
		sData.strCompName[i].clear();
	}

	for (i=0; i<3; i++)
		sData.strCmBreaker[i].clear();	//	��ģ�滻

	sData.strDegreeComp.clear();	//	��ģ����

	sData.fR=0;
	sData.fT=0;
	sData.fU=0;
	sData.fFaultR=0;
	sData.fFaultT=0;
	sData.fArrangeR=0;
	sData.fArrangeT=0;

	sData.fRContribution=0;
	sData.fUContribution=0;
}

void CReliablilityOutputDoc::InitializeDNRMCut03(tagDNRMCut03UI sData)
{
	register int	i;

	sData.strCutType.clear();

	for (i=0; i<3; i++)
	{
		sData.strCompType[i].clear();
		sData.strCompID[i].clear();
		sData.strCompName[i].clear();
	}

	for (i=0; i<2; i++)
		sData.strDegreeComp[i].clear();	//	��ģ����

	sData.fR=0;
	sData.fT=0;
	sData.fU=0;
	sData.fFaultR=0;
	sData.fFaultT=0;
	sData.fArrangeR=0;
	sData.fArrangeT=0;
	sData.fRContribution=0;
	sData.fUContribution=0;
}
void CReliablilityOutputDoc::OnLoadRdetail()
{
	// TODO: �ڴ�����������������
	AfxGetMainWnd()->PostMessage(UM_REFRESH_LOADR_RESULT, 0, 0);
}
