//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DNReliabilityDetail.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_RELIABLILITYMINPATH_FORM    101
#define IDD_RELIABLILITYMINSCUT_FORM    102
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_ReliablilityOutTYPE         130
#define ID_VIEW_OUTPUTWND               149
#define IDS_OUTPUT_WND                  157
#define IDI_OUTPUT_WND                  165
#define IDI_OUTPUT_WND_HC               166
#define IDR_OUTPUT_POPUP                182
#define IDR_THEME_MENU                  200
#define ID_VIEW_APPLOOK_WIN_2000        210
#define ID_VIEW_APPLOOK_OFF_XP          211
#define ID_VIEW_APPLOOK_WIN_XP          212
#define ID_VIEW_APPLOOK_OFF_2003        213
#define ID_VIEW_APPLOOK_VS_2005         214
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define IDS_LOADLIST_TAB                300
#define IDS_DEBUG_TAB                   301
#define IDS_FIND_TAB                    302
#define IDS_EDIT_MENU                   306
#define IDC_FSAIDI                      1000
#define IDC_LABLE_MINPATH               1001
#define IDC_FSAIFI                      1001
#define IDC_LABEL_MCUTO1                1002
#define IDC_FASAI                       1002
#define IDC_LABEL_MCUTO2                1003
#define IDC_FENS                        1003
#define IDC_LABEL_MCUTO3                1004
#define IDC_READ_SYSOUT                 1005
#define IDC_MCUT01_LIST                 1009
#define IDC_MCUT02_LIST                 1010
#define IDC_MCUT03_LIST                 1011
#define IDC_SAIDI                       1012
#define IDC_MINPATH_LIST                1012
#define IDC_CONTAINER_COMBO             1014
#define IDC_SUBSTATION_COMBO            1015
#define IDC_ODRATES                     1016
#define IDC_OFRATES                     1017
#define IDC_ODRATEA                     1018
#define IDC_OFRATEA                     1019
#define IDC_SAIFI                       1020
#define IDC_ASAI                        1021
#define IDC_ENS                         1022
#define IDC_OUTPUT_LOADLIST             10001
#define IDC_OUTPUT_SYSTEMLIST           10002
#define IDC_OUTPUT_SUBCONTROLAREALIST   10003
#define ID_32771                        32771
#define ID_REFRESH_RRESULT                      32772
#define ID_32773                        32773
#define ID_SAVEAS_EXCEL                 32774
#define ID_32775                        32775
#define ID_LOAD_RDETAIL                 32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        311
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
