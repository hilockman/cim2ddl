
// ReliablilityMinPathView.h : CReliablilityMinPathView ��Ľӿ�
//


#pragma once
#include "afxcmn.h"
#include "../../../../Common/MFCControls/MFCListCtrlEx.h"
#include "../../../../Common/Excel/ExcelAccessor.h"

class CReliablilityMinPathView : public CFormView
{
protected: // �������л�����
	CReliablilityMinPathView();
	DECLARE_DYNCREATE(CReliablilityMinPathView)

public:
	enum{ IDD = IDD_RELIABLILITYMINPATH_FORM };

// ����
public:
	CReliablilityOutputDoc* GetDocument() const;
	void	SaveAsExcel(ExcelAccessor& xls);

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
	virtual ~CReliablilityMinPathView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnNMDblclkEnergyconsumerList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCbnSelchangeContainerCombo();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	LRESULT OnRefreshView(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	void RefreshMinPathList(void);
	void Refresh(const int nSubcontrolArea=-1);
private:
	CMFCListCtrlEx m_wndMinPathListCtrl;
};

#ifndef _DEBUG  // ReliablilityMinPathView.cpp �еĵ��԰汾
inline CReliablilityOutputDoc* CReliablilityMinPathView::GetDocument() const
   { return reinterpret_cast<CReliablilityOutputDoc*>(m_pDocument); }
#endif

