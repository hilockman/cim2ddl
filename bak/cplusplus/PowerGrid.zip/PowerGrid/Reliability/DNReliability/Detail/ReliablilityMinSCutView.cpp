// ReliablilityMinSCutView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DNReliabilityDetail.h"
#include "DNReliabilityDetailDoc.h"
#include "ReliablilityMinSCutView.h"

static	const	int	ViewControlSpace=4;
static	const	int	ViewLabelHeight=16;

static	char*	m_lpszMCutO1Column[]=
{
	"���",
	"�����",
	"��豸",
	"ͣ����",
	"ͣ���ʹ��׶�",
	"ͣ��ʱ��",
	"ͣ��ʱ�乱�׶�",
	"������Ϣ",
};
static	char*	m_lpszMCutO2Column[]=
{
	"���",
	"�����",
	"��豸1",
	"��豸2",
	"ͣ����(10E-3)",
	"ͣ���ʹ��׶�",
	"ͣ��ʱ��",
	"ͣ��ʱ�乱�׶�",
	"������Ϣ",
};
static	char*	m_lpszMCutO3Column[]=
{
	"���",
	"�����",
	"��豸1",
	"��豸2",
	"��豸3",
	"ͣ����(10E-6)",
	"ͣ���ʹ��׶�",
	"ͣ��ʱ��",
	"ͣ��ʱ�乱�׶�",
	"������Ϣ",
};

// CReliablilityMinSCutView

IMPLEMENT_DYNCREATE(CReliablilityMinSCutView, CFormView)

CReliablilityMinSCutView::CReliablilityMinSCutView()
	: CFormView(CReliablilityMinSCutView::IDD)
{

}

CReliablilityMinSCutView::~CReliablilityMinSCutView()
{
}

void CReliablilityMinSCutView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MCUT01_LIST, m_wndMCutO1ListCtrl);
	DDX_Control(pDX, IDC_MCUT02_LIST, m_wndMCutO2ListCtrl);
	DDX_Control(pDX, IDC_MCUT03_LIST, m_wndMCutO3ListCtrl);
}

BEGIN_MESSAGE_MAP(CReliablilityMinSCutView, CFormView)
	ON_WM_SIZE()
	ON_MESSAGE(UM_REFRESH_LOADR_RESULT,	OnRefreshView)
END_MESSAGE_MAP()


// CReliablilityMinSCutView ���

#ifdef _DEBUG
void CReliablilityMinSCutView::AssertValid() const
{
	CFormView::AssertValid();
}

#ifndef _WIN32_WCE
void CReliablilityMinSCutView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif

CReliablilityOutputDoc* CReliablilityMinSCutView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CReliablilityOutputDoc)));
	return (CReliablilityOutputDoc*)m_pDocument;
}
#endif //_DEBUG


// CReliablilityMinSCutView ��Ϣ��������

void CReliablilityMinSCutView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();

	// TODO: �ڴ�����ר�ô����/����û���
	register int	i;

	m_wndMCutO1ListCtrl.SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	while (m_wndMCutO1ListCtrl.DeleteColumn(0));
	if (!m_wndMCutO1ListCtrl.DeleteAllItems())
		return;
	for (i=0; i<sizeof(m_lpszMCutO1Column)/sizeof(char*); i++)
		m_wndMCutO1ListCtrl.InsertColumn(i, m_lpszMCutO1Column[i], LVCFMT_LEFT, 100);

	m_wndMCutO2ListCtrl.SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	while (m_wndMCutO2ListCtrl.DeleteColumn(0));
	if (!m_wndMCutO2ListCtrl.DeleteAllItems())
		return;
	for (i=0; i<sizeof(m_lpszMCutO2Column)/sizeof(char*); i++)
		m_wndMCutO2ListCtrl.InsertColumn(i, m_lpszMCutO2Column[i], LVCFMT_LEFT, 100);

	m_wndMCutO3ListCtrl.SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	while (m_wndMCutO3ListCtrl.DeleteColumn(0));
	if (!m_wndMCutO3ListCtrl.DeleteAllItems())
		return;
	for (i=0; i<sizeof(m_lpszMCutO3Column)/sizeof(char*); i++)
		m_wndMCutO3ListCtrl.InsertColumn(i, m_lpszMCutO3Column[i], LVCFMT_LEFT, 100);
}

BOOL CReliablilityMinSCutView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ�����ר�ô����/����û���

	return CFormView::PreCreateWindow(cs);
}

void CReliablilityMinSCutView::OnSize(UINT nType, int cx, int cy)
{
	CFormView::OnSize(nType, cx, cy);

	// TODO: �ڴ˴�������Ϣ�����������
	SetScaleToFitSize(CSize(cx, cy));

	CRect	rc;
	CWnd*	pWnd;
	GetClientRect(&rc);
	int		nHeight=(rc.Height()-9*ViewControlSpace)/4-ViewLabelHeight;

	pWnd=GetDlgItem(IDC_LABEL_MCUTO1);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 0*rc.Height()/10+ViewControlSpace, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	}
	pWnd=GetDlgItem(IDC_MCUT01_LIST);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 0*rc.Height()/10+2*ViewControlSpace+ViewLabelHeight, rc.Width()-2*ViewControlSpace, 4*rc.Height()/10-ViewLabelHeight-3*ViewControlSpace, SWP_NOZORDER);
	}

	pWnd=GetDlgItem(IDC_LABEL_MCUTO2);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 4*rc.Height()/10+ViewControlSpace, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	}
	pWnd=GetDlgItem(IDC_MCUT02_LIST);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 4*rc.Height()/10+2*ViewControlSpace+ViewLabelHeight, rc.Width()-2*ViewControlSpace, 3*rc.Height()/10-ViewLabelHeight-3*ViewControlSpace, SWP_NOZORDER);
	}

	pWnd=GetDlgItem(IDC_LABEL_MCUTO3);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 7*rc.Height()/10+ViewControlSpace, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	}
	pWnd=GetDlgItem(IDC_MCUT03_LIST);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 7*rc.Height()/10+2*ViewControlSpace+ViewLabelHeight, rc.Width()-2*ViewControlSpace, 3*rc.Height()/10-ViewLabelHeight-3*ViewControlSpace, SWP_NOZORDER);
	}
}

void CReliablilityMinSCutView::RefreshMCutO1List(void)
{
	register int	i;
	int			nMCut, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;

	if (!m_wndMCutO1ListCtrl.DeleteAllItems())
		return;

	CReliablilityOutputDoc*	pDoc=GetDocument();

	for (nMCut=0; nMCut<(int)pDoc->m_MCutO1Array.size(); nMCut++)
	{
		sprintf(szBuf, "%d", nMCut+1);
		m_wndMCutO1ListCtrl.InsertItem(nMCut, szBuf);

		nCol=1;
		m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, pDoc->m_MCutO1Array[nMCut].strCutType.c_str());
		sprintf(szBuf, "%s.%s", pDoc->m_MCutO1Array[nMCut].strCompType.c_str(), pDoc->m_MCutO1Array[nMCut].strCompName.c_str());	m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, szBuf);

		sprintf(szBuf, "%f", pDoc->m_MCutO1Array[nMCut].fR);					m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO1Array[nMCut].fRContribution);		m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO1Array[nMCut].fU);					m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO1Array[nMCut].fUContribution);		m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, szBuf);

		memset(szBuf, 0, 260);
		for (i=0; i<3; i++)
		{
			if (!pDoc->m_MCutO1Array[nMCut].strCmBreaker[i].empty())
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, " ");
				else
					strcat(szBuf, "�����·����");
				strcat(szBuf, pDoc->m_MCutO1Array[nMCut].strCmBreaker[i].c_str());
			}
		}
		m_wndMCutO1ListCtrl.SetItemText(nMCut, nCol++, szBuf);
	}
	for (i=0; i<sizeof(m_lpszMCutO1Column)/sizeof(char*); i++)
	{
		m_wndMCutO1ListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMCutO1ListCtrl.GetColumnWidth(i);
		m_wndMCutO1ListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMCutO1ListCtrl.GetColumnWidth(i);

		m_wndMCutO1ListCtrl.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CReliablilityMinSCutView::RefreshMCutO2List(void)
{
	register int	i;
	int			nRow, nCol, nMCut;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;
	std::string	strBuf;

	if (!m_wndMCutO2ListCtrl.DeleteAllItems())
		return;

	CReliablilityOutputDoc*	pDoc=GetDocument();

	nRow=0;
	for (nMCut=0; nMCut<(int)pDoc->m_MCutO2Array.size(); nMCut++)
	{
		sprintf(szBuf, "%d", nRow+1);		m_wndMCutO2ListCtrl.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, pDoc->m_MCutO2Array[nMCut].strCutType.c_str());

		sprintf(szBuf, "%s.%s", pDoc->m_MCutO2Array[nMCut].strCompType[0].c_str(), pDoc->m_MCutO2Array[nMCut].strCompName[0].c_str());	m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%s.%s", pDoc->m_MCutO2Array[nMCut].strCompType[1].c_str(), pDoc->m_MCutO2Array[nMCut].strCompName[1].c_str());	m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", 1000*pDoc->m_MCutO2Array[nMCut].fR);				m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO2Array[nMCut].fRContribution);		m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO2Array[nMCut].fU);					m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO2Array[nMCut].fUContribution);		m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, szBuf);

		strBuf.clear();
		memset(szBuf, 0, 260);
		for (i=0; i<3; i++)
		{
			if (!pDoc->m_MCutO2Array[nMCut].strCmBreaker[i].empty())
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, " ");
				else
					strcat(szBuf, "�����·����");
				strcat(szBuf, pDoc->m_MCutO2Array[nMCut].strCmBreaker[i].c_str());
			}
		}
		strBuf.append(szBuf);

		memset(szBuf, 0, 260);
		if (!pDoc->m_MCutO2Array[nMCut].strDegreeComp.empty())
			sprintf(szBuf, " �����豸 = %s", pDoc->m_MCutO2Array[nMCut].strDegreeComp.c_str());
		strBuf.append(szBuf);

		m_wndMCutO2ListCtrl.SetItemText(nRow, nCol++, strBuf.c_str());

		nRow++;
	}

	for (i=0; i<sizeof(m_lpszMCutO2Column)/sizeof(char*); i++)
	{
		m_wndMCutO2ListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMCutO2ListCtrl.GetColumnWidth(i);
		m_wndMCutO2ListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMCutO2ListCtrl.GetColumnWidth(i);

		m_wndMCutO2ListCtrl.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CReliablilityMinSCutView::RefreshMCutO3List(void)
{
	register int	i;
	int			nRow, nCol, nMCut;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;
	std::string	strBuf;

	if (!m_wndMCutO3ListCtrl.DeleteAllItems())
		return;

	CReliablilityOutputDoc*	pDoc=GetDocument();

	nRow=0;
	for (nMCut=0; nMCut<(int)pDoc->m_MCutO3Array.size(); nMCut++)
	{
		sprintf(szBuf, "%d", nRow+1);		m_wndMCutO3ListCtrl.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, pDoc->m_MCutO3Array[nMCut].strCutType.c_str());
		sprintf(szBuf, "%s.%s", pDoc->m_MCutO3Array[nMCut].strCompType[0].c_str(), pDoc->m_MCutO3Array[nMCut].strCompName[0].c_str());	m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%s.%s", pDoc->m_MCutO3Array[nMCut].strCompType[1].c_str(), pDoc->m_MCutO3Array[nMCut].strCompName[1].c_str());	m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%s.%s", pDoc->m_MCutO3Array[nMCut].strCompType[2].c_str(), pDoc->m_MCutO3Array[nMCut].strCompName[2].c_str());	m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", 1000*1000*pDoc->m_MCutO3Array[nMCut].fR);			m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO3Array[nMCut].fRContribution);		m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO3Array[nMCut].fU);					m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_MCutO3Array[nMCut].fUContribution);		m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, szBuf);

		strBuf.clear();
		memset(szBuf, 0, 260);
		for (i=0; i<2; i++)
		{
			if (!pDoc->m_MCutO3Array[nMCut].strDegreeComp[i].empty())
			{
				if (strlen(szBuf) > 0)
					strcat(szBuf, " ");
				else
					strcat(szBuf, "�����豸��");
			}
			strcat(szBuf, pDoc->m_MCutO3Array[nMCut].strDegreeComp[i].c_str());
		}
		strBuf.append(szBuf);

		m_wndMCutO3ListCtrl.SetItemText(nRow, nCol++, strBuf.c_str());

		nRow++;
	}

	for (i=0; i<sizeof(m_lpszMCutO3Column)/sizeof(char*); i++)
	{
		m_wndMCutO3ListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMCutO3ListCtrl.GetColumnWidth(i);
		m_wndMCutO3ListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMCutO3ListCtrl.GetColumnWidth(i);

		m_wndMCutO3ListCtrl.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

LRESULT CReliablilityMinSCutView::OnRefreshView(WPARAM wParam, LPARAM lParam)
{
	RefreshMCutO1List();
	RefreshMCutO2List();
	RefreshMCutO3List();
	return 0;
}

void	CReliablilityMinSCutView::SaveAsExcel(ExcelAccessor& xls)
{
	int		nRow, nCol, nFieldNum;
	if (m_wndMCutO1ListCtrl.GetItemCount() > 0)
	{
		xls.AddSheet(_T("һ����С�"));
		xls.SetCurSheet(_T("һ����С�"));

		nFieldNum=sizeof(m_lpszMCutO1Column)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszMCutO1Column[nCol]));
		for (nRow=0; nRow<m_wndMCutO1ListCtrl.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndMCutO1ListCtrl.GetItemText(nRow, nCol));
		}
	}
	if (m_wndMCutO2ListCtrl.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������С�"));
		xls.SetCurSheet(_T("������С�"));

		nFieldNum=sizeof(m_lpszMCutO2Column)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszMCutO2Column[nCol]));
		for (nRow=0; nRow<m_wndMCutO2ListCtrl.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndMCutO2ListCtrl.GetItemText(nRow, nCol));
		}
	}
	if (m_wndMCutO3ListCtrl.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������С�"));
		xls.SetCurSheet(_T("������С�"));

		nFieldNum=sizeof(m_lpszMCutO3Column)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszMCutO3Column[nCol]));
		for (nRow=0; nRow<m_wndMCutO3ListCtrl.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndMCutO3ListCtrl.GetItemText(nRow, nCol));
		}
	}
}
