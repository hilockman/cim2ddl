#pragma once
#include "afxcmn.h"
#include "../../../../Common/MFCControls/MFCListCtrlEx.h"
#include "../../../../Common/Excel/ExcelAccessor.h"
// CReliablilityMinSCutView ������ͼ

class CReliablilityMinSCutView : public CFormView
{
	DECLARE_DYNCREATE(CReliablilityMinSCutView)

protected:
	CReliablilityMinSCutView();           // ��̬������ʹ�õ��ܱ����Ĺ��캯��
	virtual ~CReliablilityMinSCutView();

public:
	enum { IDD = IDD_RELIABLILITYMINSCUT_FORM };
	// ����
public:
	CReliablilityOutputDoc* GetDocument() const;
	void	SaveAsExcel(ExcelAccessor& xls);

#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual void OnInitialUpdate();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

	afx_msg void OnSize(UINT nType, int cx, int cy);
	LRESULT OnRefreshView(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	void RefreshMCutO1List(void);
	void RefreshMCutO2List(void);
	void RefreshMCutO3List(void);
public:
	CMFCListCtrlEx m_wndMCutO1ListCtrl;
	CMFCListCtrlEx m_wndMCutO2ListCtrl;
	CMFCListCtrlEx m_wndMCutO3ListCtrl;
};
#ifndef _DEBUG  // ReliablilityMinPathView.cpp �еĵ��԰汾
inline CReliablilityOutputDoc* CReliablilityMinSCutView::GetDocument() const
{ return reinterpret_cast<CReliablilityOutputDoc*>(m_pDocument); }
#endif


