
// ReliablilityMinPathView.cpp : CReliablilityMinPathView ���ʵ��
//

#include "stdafx.h"
#include "DNReliabilityDetail.h"
#include "DNReliabilityDetailDoc.h"
#include "ReliablilityMinPathView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

static	const	int	ViewLabelHeight=16;
static	const	int	ViewControlSpace=4;

static	char*	m_lpszMinPathColumn[]=
{
	"·�����",
	"·���豸",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
	"������(��/��)",
	"����ʱ��(Сʱ)",
};

// CReliablilityMinPathView

IMPLEMENT_DYNCREATE(CReliablilityMinPathView, CFormView)

BEGIN_MESSAGE_MAP(CReliablilityMinPathView, CFormView)
	ON_MESSAGE(UM_REFRESH_LOADR_RESULT,	OnRefreshView)
	ON_WM_SIZE()
END_MESSAGE_MAP()

// CReliablilityMinPathView ����/����

CReliablilityMinPathView::CReliablilityMinPathView()
	: CFormView(CReliablilityMinPathView::IDD)
{
	// TODO: �ڴ˴����ӹ������

}

CReliablilityMinPathView::~CReliablilityMinPathView()
{
}

void CReliablilityMinPathView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MINPATH_LIST, m_wndMinPathListCtrl);
}

BOOL CReliablilityMinPathView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CFormView::PreCreateWindow(cs);
}

void CReliablilityMinPathView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	register int	i;
	m_wndMinPathListCtrl.SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	while (m_wndMinPathListCtrl.DeleteColumn(0));
	if (!m_wndMinPathListCtrl.DeleteAllItems())
		return;
	for (i=0; i<sizeof(m_lpszMinPathColumn)/sizeof(char*); i++)
		m_wndMinPathListCtrl.InsertColumn(i, m_lpszMinPathColumn[i], LVCFMT_LEFT, 100);
}

void CReliablilityMinPathView::OnRButtonUp(UINT nFlags, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CReliablilityMinPathView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CReliablilityMinPathView ���

#ifdef _DEBUG
void CReliablilityMinPathView::AssertValid() const
{
	CFormView::AssertValid();
}

void CReliablilityMinPathView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CReliablilityOutputDoc* CReliablilityMinPathView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CReliablilityOutputDoc)));
	return (CReliablilityOutputDoc*)m_pDocument;
}
#endif //_DEBUG


// CReliablilityMinPathView ��Ϣ��������


LRESULT CReliablilityMinPathView::OnRefreshView(WPARAM wParam, LPARAM lParam)
{
	RefreshMinPathList();
	return 0;
}

void CReliablilityMinPathView::OnSize(UINT nType, int cx, int cy)
{
	CFormView::OnSize(nType, cx, cy);

	// TODO: �ڴ˴�������Ϣ�����������
	SetScaleToFitSize(CSize(cx, cy));
	CRect	rc;
	CWnd*	pWnd;
	GetClientRect(&rc);

	pWnd=GetDlgItem(IDC_LABLE_MINPATH);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, ViewControlSpace, 0, 0, SWP_NOZORDER|SWP_NOSIZE);
	}
	pWnd=GetDlgItem(IDC_MINPATH_LIST);
	if (pWnd->GetSafeHwnd())
	{
		pWnd->SetWindowPos(NULL, ViewControlSpace, 2*ViewControlSpace+ViewLabelHeight, rc.Width()-2*ViewControlSpace, rc.Height()-ViewLabelHeight-3*ViewControlSpace, SWP_NOZORDER);
	}
}


void CReliablilityMinPathView::RefreshMinPathList(void)
{
	register int	i;
	int			nPath, nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;
	if (!m_wndMinPathListCtrl.DeleteAllItems())
		return;

	CReliablilityOutputDoc*	pDoc=GetDocument();

	nRow=0;
	for (nPath=0; nPath<(int)pDoc->m_DNRMinPathArray.size(); nPath++)
	{
		sprintf(szBuf, "·��%d", nPath+1);
		m_wndMinPathListCtrl.InsertItem(nRow, szBuf);
		nRow++;

		for (i=0; i<(int)pDoc->m_DNRMinPathArray[nPath].sCompArray.size(); i++)
		{
			memset(szBuf, 0, 260);
			m_wndMinPathListCtrl.InsertItem(nRow, szBuf);

			nCol=1;
			sprintf(szBuf, "%s.%s", pDoc->m_DNRMinPathArray[nPath].sCompArray[i].strType.c_str(), pDoc->m_DNRMinPathArray[nPath].sCompArray[i].strName.c_str());	m_wndMinPathListCtrl.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%f", pDoc->m_DNRMinPathArray[nPath].sCompArray[i].fRerr);		m_wndMinPathListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", pDoc->m_DNRMinPathArray[nPath].sCompArray[i].fTrep);		m_wndMinPathListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", pDoc->m_DNRMinPathArray[nPath].sCompArray[i].fRchk);		m_wndMinPathListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", pDoc->m_DNRMinPathArray[nPath].sCompArray[i].fTchk);		m_wndMinPathListCtrl.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}
	for (i=0; i<sizeof(m_lpszMinPathColumn)/sizeof(char*); i++)
	{
		m_wndMinPathListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndMinPathListCtrl.GetColumnWidth(i);
		m_wndMinPathListCtrl.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndMinPathListCtrl.GetColumnWidth(i);

		m_wndMinPathListCtrl.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CReliablilityMinPathView::SaveAsExcel(ExcelAccessor& xls)
{
	int		nRow, nCol, nFieldNum;
	if (m_wndMinPathListCtrl.GetItemCount() > 0)
	{
		xls.AddSheet(_T("��С·��"));
		xls.SetCurSheet(_T("��С·��"));

		nFieldNum=sizeof(m_lpszMinPathColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszMinPathColumn[nCol]));
		for (nRow=0; nRow<m_wndMinPathListCtrl.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndMinPathListCtrl.GetItemText(nRow, nCol));
		}
	}
}
