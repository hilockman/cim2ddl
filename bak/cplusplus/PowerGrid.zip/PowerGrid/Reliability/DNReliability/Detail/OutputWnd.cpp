
#include "stdafx.h"
#include "Resource.h"
#include "DNReliabilityDetail.h"
#include "DNReliabilityDetailDoc.h"
#include "MainFrm.h"
#include "OutputWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static	char*	m_lpszLoadColumn[]=
{
	"�豸ID",
	"�豸����",
	"���ɹ���(MW)",
	"�û���",
	"�����ʱ(��)",
	"����ͣ����(��/��)",
	"����ͣ��ʱ��(Сʱ/��)",
	"Ԥ����ͣ����(��/��)",
	"Ԥ����ͣ��ʱ��(Сʱ/��)",
	"ͣ����(��/��)",
	"ͣ��ʱ��(Сʱ/��)",

	"����ͣ��ʱ��(Сʱ/��)",
	"�л�ͣ��ʱ��(Сʱ/��)",

	"�������������(MWh/��)",
	"ͣ������ռ����(%)",
	"ͣ��ʱ����ռ����(%)",
	"����������ռ����(%)",
};
static	char*	m_lpszSystemColumn[]=
{
	"��������",
	"�Ǽƻ�������",
	"�ۺϼ�����",
};
static	char*	m_lpszSubcontrolAreaColumn[]=
{
	"��������",
	"��������",
	"�Ǽƻ�������",
	"�ۺϼ�����",
};
/////////////////////////////////////////////////////////////////////////////
// COutputBar

COutputWnd::COutputWnd()
{
}

COutputWnd::~COutputWnd()
{
}

BEGIN_MESSAGE_MAP(COutputWnd, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()

int COutputWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	//m_Font.CreateStockObject(DEFAULT_GUI_FONT);
	register int	i;
	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// ����ѡ�����:
	if (!m_wndTabs.Create(CMFCTabCtrl::STYLE_FLAT, rectDummy, this, 1, CMFCBaseTabCtrl::LOCATION_TOP))
	{
		TRACE0("δ�ܴ������ѡ�����\n");
		return -1;      // δ�ܴ���
	}

	// �����������:
	if (!m_wndOutputLoadList.Create(WS_VISIBLE | WS_CHILD , rectDummy, &m_wndTabs, IDC_OUTPUT_LOADLIST))
	{
		TRACE0("δ�ܴ���δ�ܴ����������\n");
		return -1;      // δ�ܴ���
	}
	while (m_wndOutputLoadList.DeleteColumn(0));
	if (!m_wndOutputLoadList.DeleteAllItems())
		return 0;
	for (i=0; i<sizeof(m_lpszLoadColumn)/sizeof(char*); i++)
		m_wndOutputLoadList.InsertColumn(i, m_lpszLoadColumn[i], LVCFMT_LEFT, 100);
	m_wndOutputLoadList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT);//|LVS_SHOWSELALWAYS);
	m_wndOutputLoadList.SetExtendedStyle(m_wndOutputLoadList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndOutputLoadList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndOutputLoadList.EnableMarkSortedColumn();

	if (!m_wndOutputSystemList.Create(WS_VISIBLE | WS_CHILD , rectDummy, &m_wndTabs, IDC_OUTPUT_SYSTEMLIST))
	{
		TRACE0("δ�ܴ���δ�ܴ����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndOutputSystemList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndOutputSystemList.SetExtendedStyle(m_wndOutputSystemList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndOutputSystemList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	while (m_wndOutputSystemList.DeleteColumn(0));
	if (!m_wndOutputSystemList.DeleteAllItems())
		return 0;
	for (i=0; i<sizeof(m_lpszSystemColumn)/sizeof(char*); i++)
		m_wndOutputSystemList.InsertColumn(i, m_lpszSystemColumn[i], LVCFMT_LEFT, 100);

	if (!m_wndOutputSubcontrolAreaList.Create(WS_VISIBLE | WS_CHILD , rectDummy, &m_wndTabs, 2))
	{
		TRACE0("δ�ܴ���δ�ܴ����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndOutputSubcontrolAreaList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndOutputSubcontrolAreaList.SetExtendedStyle(m_wndOutputSubcontrolAreaList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndOutputSubcontrolAreaList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	while (m_wndOutputSubcontrolAreaList.DeleteColumn(0));
	if (!m_wndOutputSubcontrolAreaList.DeleteAllItems())
		return 0;
	for (i=0; i<sizeof(m_lpszSubcontrolAreaColumn)/sizeof(char*); i++)
		m_wndOutputSubcontrolAreaList.InsertColumn(i, m_lpszSubcontrolAreaColumn[i], LVCFMT_LEFT, 100);


	// ���б����ڸ��ӵ�ѡ�:
	m_wndTabs.AddTab(&m_wndOutputLoadList, CString("���ɿɿ��Խ��"), (UINT)0);
	m_wndTabs.AddTab(&m_wndOutputSystemList, CString("ϵͳ�ɿ��Խ��"), (UINT)0);
	m_wndTabs.AddTab(&m_wndOutputSubcontrolAreaList, CString("�����ɿ��Խ��"), (UINT)0);

	// ʹ��һЩ�����ı���д���ѡ�(���踴������)

	return 0;
}

void COutputWnd::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	// ѡ��ؼ�Ӧ��������������:
	m_wndTabs.SetWindowPos (NULL, -1, -1, cx, cy, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
	RecalcLayout();
}

int COutputWnd::GetSelectedLoadString(char* lpszLoadResID, char* lpszLoadName)
{
	POSITION	pos=m_wndOutputLoadList.GetFirstSelectedItemPosition();
	if (!pos)
		return 0;

	int		nItem=m_wndOutputLoadList.GetNextSelectedItem(pos);
	strcpy(lpszLoadResID, m_wndOutputLoadList.GetItemText(nItem, 0));
	strcpy(lpszLoadName,  m_wndOutputLoadList.GetItemText(nItem, 1));

	return 1;
}

void COutputWnd::RefreshLoadList()
{
	register int	i;
	int			nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;

	if (!m_wndOutputLoadList.DeleteAllItems())
		return;

	CFrameWndEx* pMainFrame = (CFrameWndEx*)AfxGetMainWnd();
	if (!pMainFrame)
		return;
	CReliablilityOutputDoc*	pDoc=(CReliablilityOutputDoc*)pMainFrame->GetActiveDocument();

	for (i=0; i<(int)pDoc->m_DNRLoadArray.size(); i++)
	{
		m_wndOutputLoadList.InsertItem(i, pDoc->m_DNRLoadArray[i].strResID.c_str());
		m_wndOutputLoadList.SetItemData(i, i);

		nCol=1;
		m_wndOutputLoadList.SetItemText(i, nCol++, pDoc->m_DNRLoadArray[i].strName.c_str());
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fP);				m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fCustomer);		m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fRCTime);			m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fFaultR);			m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fFaultU);			m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fArrangeR);		m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fArrangeU);		m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fR);				m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fU);				m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fCommonU);				m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fSwitchU);				m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fENS);				m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);

		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fRContribution);	m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fUContribution);	m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
		sprintf(szBuf, "%f", pDoc->m_DNRLoadArray[i].fENSContribution);	m_wndOutputLoadList.SetItemText(i, nCol++, szBuf);
	}
	for (i=0; i<sizeof(m_lpszLoadColumn)/sizeof(char*); i++)
	{
		m_wndOutputLoadList.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndOutputLoadList.GetColumnWidth(i);

		//if (pDoc->m_DNRLoadArray.empty())
		{
			m_wndOutputLoadList.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
			nHeaderWidth =m_wndOutputLoadList.GetColumnWidth(i);
		}

		m_wndOutputLoadList.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void COutputWnd::RefreshSystemList()
{
	register int	i;
	int			nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;
	if (!m_wndOutputSystemList.DeleteAllItems())
		return;

	CFrameWndEx* pMainFrame = (CFrameWndEx*)AfxGetMainWnd();
	if (!pMainFrame)
		return;
	CReliablilityOutputDoc*	pDoc=(CReliablilityOutputDoc*)pMainFrame->GetActiveDocument();

	nRow=0;

	nCol=1;
	m_wndOutputSystemList.InsertItem(nRow, CString("��ͣ��Сʱ��(Сʱ/�û�.��)"));
	sprintf(szBuf, "%f", pDoc->m_DNRSystem.Fault_SAIDI);	m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	sprintf(szBuf, "%f", pDoc->m_DNRSystem.SAIDI);			m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	nRow++;

	nCol=1;
	m_wndOutputSystemList.InsertItem(nRow, CString("��ƽ��ͣ�����(��/�û�.��)"));
	sprintf(szBuf, "%f", pDoc->m_DNRSystem.Fault_SAIFI);	m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	sprintf(szBuf, "%f", pDoc->m_DNRSystem.SAIFI);			m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	nRow++;

	nCol=1;
	m_wndOutputSystemList.InsertItem(nRow, CString("ƽ�����۹��������(%)"));
	sprintf(szBuf, "%.8f", 100*pDoc->m_DNRSystem.Fault_ASAI);	m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	sprintf(szBuf, "%.8f", 100*pDoc->m_DNRSystem.ASAI);			m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	nRow++;

	nCol=1;
	m_wndOutputSystemList.InsertItem(nRow, CString("��ƽ������ͣ�����(MWh/��)"));
	sprintf(szBuf, "%f", pDoc->m_DNRSystem.Fault_ENS);		m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	sprintf(szBuf, "%f", pDoc->m_DNRSystem.ENS);			m_wndOutputSystemList.SetItemText(nRow, nCol++, CString(szBuf));
	nRow++;

	for (i=0; i<sizeof(m_lpszSystemColumn)/sizeof(char*); i++)
	{
		m_wndOutputSystemList.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndOutputSystemList.GetColumnWidth(i);
		m_wndOutputSystemList.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndOutputSystemList.GetColumnWidth(i);

		m_wndOutputSystemList.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void COutputWnd::RefreshSubcontrolAreaList()
{
	register int	i;
	int			nArea, nRow, nCol;
	char		szBuf[260];
	int			nColWidth, nHeaderWidth;
	if (!m_wndOutputSubcontrolAreaList.DeleteAllItems())
		return;

	CFrameWndEx* pMainFrame = (CFrameWndEx*)AfxGetMainWnd();
	if (!pMainFrame)
		return;
	CReliablilityOutputDoc*	pDoc=(CReliablilityOutputDoc*)pMainFrame->GetActiveDocument();

	nRow=0;
	for (nArea=0; nArea<(int)pDoc->m_DNRAreaArray.size(); nArea++)
	{
		m_wndOutputSubcontrolAreaList.InsertItem(nRow, (pDoc->m_DNRAreaArray[nArea].strAreaName.c_str()));
		nRow++;

		nCol=1;
		m_wndOutputSubcontrolAreaList.InsertItem(nRow, CString(""));
																			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, ("��ͣ��Сʱ��(Сʱ/�û�.��)"));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].Fault_SAIDI);		m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].SAIDI);			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		nRow++;

		nCol=1;
		m_wndOutputSubcontrolAreaList.InsertItem(nRow, CString(""));
																			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, ("��ƽ��ͣ�����(��/�û�.��)"));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].Fault_SAIFI);		m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].SAIFI);			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		nRow++;

		nCol=1;
		m_wndOutputSubcontrolAreaList.InsertItem(nRow, CString(""));
																			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, ("ƽ�����۹��������(%)"));
		sprintf(szBuf, "%.8f", 100*pDoc->m_DNRAreaArray[nArea].Fault_ASAI);	m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		sprintf(szBuf, "%.8f", 100*pDoc->m_DNRAreaArray[nArea].ASAI);			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		nRow++;

		nCol=1;
		m_wndOutputSubcontrolAreaList.InsertItem(nRow, CString(""));
																			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, ("��ƽ������ͣ�����(MWh/��)"));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].Fault_ENS);		m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].ENS);				m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		nRow++;

		nCol=1;
		m_wndOutputSubcontrolAreaList.InsertItem(nRow, CString(""));
																			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, ("���׶�(%)"));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].fRContribution);			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		sprintf(szBuf, "%.8f", pDoc->m_DNRAreaArray[nArea].fUContribution);			m_wndOutputSubcontrolAreaList.SetItemText(nRow, nCol++, (szBuf));
		nRow++;
	}

	for (i=0; i<sizeof(m_lpszSubcontrolAreaColumn)/sizeof(char*); i++)
	{
		m_wndOutputSubcontrolAreaList.SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = m_wndOutputSubcontrolAreaList.GetColumnWidth(i);
		m_wndOutputSubcontrolAreaList.SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_wndOutputSubcontrolAreaList.GetColumnWidth(i);

		m_wndOutputSubcontrolAreaList.SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	COutputWnd::SaveAsExcel(ExcelAccessor& xls)
{
	int		nRow, nCol, nFieldNum;
	if (m_wndOutputLoadList.GetItemCount() > 0)
	{
		xls.AddSheet(_T("���ɿɿ��Խ��"));
		xls.SetCurSheet(_T("���ɿɿ��Խ��"));

		nFieldNum=sizeof(m_lpszLoadColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszLoadColumn[nCol]));
		for (nRow=0; nRow<m_wndOutputLoadList.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndOutputLoadList.GetItemText(nRow, nCol));
		}
	}
	if (m_wndOutputSystemList.GetItemCount() > 0)
	{
		xls.AddSheet(_T("ϵͳ�ɿ��Խ��"));
		xls.SetCurSheet(_T("ϵͳ�ɿ��Խ��"));

		nFieldNum=sizeof(m_lpszSystemColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszSystemColumn[nCol]));
		for (nRow=0; nRow<m_wndOutputSystemList.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndOutputSystemList.GetItemText(nRow, nCol));
		}
	}
	if (m_wndOutputSubcontrolAreaList.GetItemCount() > 0)
	{
		xls.AddSheet(_T("�����ɿ��Խ��"));
		xls.SetCurSheet(_T("�����ɿ��Խ��"));

		nFieldNum=sizeof(m_lpszSubcontrolAreaColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(m_lpszSubcontrolAreaColumn[nCol]));
		for (nRow=0; nRow<m_wndOutputSubcontrolAreaList.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndOutputSubcontrolAreaList.GetItemText(nRow, nCol));
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// COutputList
//
BEGIN_MESSAGE_MAP(COutputList, CMFCListCtrl)
	ON_NOTIFY_REFLECT(NM_DBLCLK, &COutputList::OnNMDblclk)
END_MESSAGE_MAP()
// /////////////////////////////////////////////////////////////////////////////
// // COutputList ��Ϣ��������

void COutputList::OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (pNMItemActivate->iItem >= 0)
	{
		AfxGetMainWnd()->PostMessage(UM_REFRESH_LOADR_RESULT, 0, 0);
	}
	*pResult = 0;
}

COLORREF COutputList::OnGetCellBkColor(int nRow, int nColum)
{
	if (m_bMarkSortedColumn && nColum == m_iSortedColumn)
	{
		return(nRow % 2) == 0 ? RGB(233, 221, 229) : RGB(176, 218, 234);
	}

	return(nRow % 2) == 0 ? RGB(253, 241, 249) : RGB(196, 238, 254);
}

COLORREF COutputList::OnGetCellTextColor(int nRow, int nColum)
{
	return(nRow % 2) == 0 ? RGB(128, 37, 0) : RGB(0, 0, 0);
}

int COutputList::OnCompareItems(LPARAM lParam1, LPARAM lParam2, int iColumn)
{
	CString strItem1, strItem2;
	LVFINDINFO lvfi;
	lvfi.flags=LVFI_PARAM;
	lvfi.lParam=lParam1;
	strItem1=GetItemText(FindItem(&lvfi, -1), iColumn);

	lvfi.lParam=lParam2;
	strItem2=GetItemText(FindItem(&lvfi, -1), iColumn);

	// ���� �����ַ����Ƚ�
	if (iColumn == 0)
		return _tcsicmp(strItem1, strItem2);
	else
	{
		double fItem1 = atof(strItem1);
		double fItem2 = atof(strItem2);
		return(fItem1 < fItem2 ? -1 : 1);
	}

// 	CString strItem1 = GetItemText((int)(lParam1 < lParam2 ? lParam1 : lParam2), iColumn);
// 	CString strItem2 = GetItemText((int)(lParam1 < lParam2 ? lParam2 : lParam1), iColumn);
//
//  	if (iColumn != 1)
//  	{
//  		double fItem1 = atof(strItem1);
//  		double fItem2 = atof(strItem2);
//  		return(fItem1 < fItem2 ? -1 : 1);
//  	}
//  	else
// 	{
// 		int iSort = strcmp(strItem1, strItem2);
// 		return(iSort);
// 	}
}
