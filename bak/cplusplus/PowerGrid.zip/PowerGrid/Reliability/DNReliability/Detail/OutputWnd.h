#pragma once
#include "afxlistctrl.h"
#include "../../../../Common/MFCControls/MFCListCtrlEx.h"
#include "../../../../Common/Excel/ExcelAccessor.h"
/////////////////////////////////////////////////////////////////////////////
// COutputList ����

class COutputList : public CMFCListCtrl	//CListCtrl
{
protected:
	virtual COLORREF OnGetCellBkColor(int nRow, int nColum);
	virtual COLORREF OnGetCellTextColor(int nRow, int nColum);
	virtual int OnCompareItems(LPARAM lParam1, LPARAM lParam2, int iColumn);
	afx_msg void OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
};

class COutputWnd : public CDockablePane
{
// ����
public:
	COutputWnd();
	void	RefreshLoadList();
	void	RefreshSystemList();
	void	RefreshSubcontrolAreaList();
	void	SaveAsExcel(ExcelAccessor& xls);

	int		GetSelectedLoadString(char* lpszLoadResID, char* lpszLoadName);

// ����
protected:
	//CFont m_Font;
	CMFCTabCtrl		m_wndTabs;
	COutputList		m_wndOutputLoadList;
	CMFCListCtrlEx	m_wndOutputSystemList;
	CMFCListCtrlEx	m_wndOutputSubcontrolAreaList;

protected:

// ʵ��
public:
	virtual ~COutputWnd();

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	DECLARE_MESSAGE_MAP()

private:
};

