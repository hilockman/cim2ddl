
// ReliablilityOutputDoc.h : CReliablilityOutputDoc ��Ľӿ�
//


#pragma once
#include "../DNRGlobal.h"
#include "DNReliabilityUIData.h"

class CReliablilityOutputDoc : public CDocument
{
protected: // �������л�����
	CReliablilityOutputDoc();
	DECLARE_DYNCREATE(CReliablilityOutputDoc)

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// ʵ��
public:
	virtual ~CReliablilityOutputDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnRefresh();
	DECLARE_MESSAGE_MAP()
public:
	int ParseSysXml(void);
	int ParseLoadXml(const char* lpszLoadName);

public:
	tagDNRSystemUI							m_DNRSystem;
	std::vector<tagDNRLoadUI>				m_DNRLoadArray;
	std::vector<tagDNRSubcontrolAreaUI>		m_DNRAreaArray;

	std::vector<tagRMinPathUI>				m_DNRMinPathArray;	//	��С·
	std::vector<tagDNRMCut01UI>				m_MCutO1Array;	//	һ����С��
	std::vector<tagDNRMCut02UI>				m_MCutO2Array;	//	������С��
	std::vector<tagDNRMCut03UI>				m_MCutO3Array;	//	������С��

private:
	void InitializeDNRLoad(tagDNRLoadUI& sLoad);
	void InitializeDNRSubControlArea(tagDNRSubcontrolAreaUI& sArea);
	void InitializeDNRMinPath(tagRMinPathUI& sPath);
	void InitializeDNRMCut01(tagDNRMCut01UI sCut);
	void InitializeDNRMCut02(tagDNRMCut02UI sCut);
	void InitializeDNRMCut03(tagDNRMCut03UI sCut);
public:
	afx_msg void OnLoadRdetail();
};


