#include "stdafx.h"
#include "DNReliability.h"

void CDNREstimate::ParallelShortcutSwitchCalc(const int nFComp, const int nSComp, double& fSwR, double& fSwT)
{
	fSwR=0;
	fSwT=0;

	if (m_CompArray[nFComp].fRerr < FLT_MIN && m_CompArray[nSComp].fRerr < FLT_MIN)
		return;
	if (m_CompArray[nFComp].fTSwitch < FLT_MIN && m_CompArray[nSComp].fTSwitch < FLT_MIN)
		return;

	if (m_CompArray[nFComp].fRerr > m_CompArray[nSComp].fRerr && m_CompArray[nSComp].fTSwitch > FLT_MIN)
	{
		fSwR = m_CompArray[nFComp].fRerr;
		fSwT = m_CompArray[nFComp].fTFLoc;
		fSwT += m_CompArray[nSComp].fRSwitch*(m_CompArray[nSComp].fTSwitch)+(1-m_CompArray[nSComp].fRSwitch)*(m_CompArray[nFComp].fTrep);
	}
	else
	{
		fSwR = m_CompArray[nSComp].fRerr;
		fSwT = m_CompArray[nSComp].fTFLoc;
		fSwT += m_CompArray[nFComp].fRSwitch*(m_CompArray[nFComp].fTSwitch)+(1-m_CompArray[nFComp].fRSwitch)*(m_CompArray[nSComp].fTrep);
	}
}

void CDNREstimate::ParallelShortcutSwitchCalc(const int nComp1, const int nComp2, const int nComp3, double& fSwR, double& fSwT)
{
	fSwR=0;
	fSwT=0;

	if (m_CompArray[nComp1].fRerr < FLT_MIN && m_CompArray[nComp2].fRerr < FLT_MIN && m_CompArray[nComp3].fRerr < FLT_MIN)
		return;
	if (m_CompArray[nComp1].fTSwitch < FLT_MIN && m_CompArray[nComp2].fTSwitch < FLT_MIN && m_CompArray[nComp3].fTSwitch < FLT_MIN)
		return;


	if (m_CompArray[nComp1].fRerr > m_CompArray[nComp2].fRerr && m_CompArray[nComp1].fRerr > m_CompArray[nComp3].fRerr && (m_CompArray[nComp2].fTSwitch > FLT_MIN || m_CompArray[nComp3].fTSwitch > FLT_MIN))
	{
		fSwR=m_CompArray[nComp1].fRerr;
		fSwT=m_CompArray[nComp1].fTFLoc;
		if (m_CompArray[nComp2].fRSwitch > m_CompArray[nComp3].fRSwitch)
			fSwT += m_CompArray[nComp2].fRSwitch*(m_CompArray[nComp2].fTSwitch)+(1-m_CompArray[nComp2].fRSwitch)*(m_CompArray[nComp1].fTrep);
		else
			fSwT += m_CompArray[nComp3].fRSwitch*(m_CompArray[nComp3].fTSwitch)+(1-m_CompArray[nComp3].fRSwitch)*(m_CompArray[nComp1].fTrep);
	}
	else if (m_CompArray[nComp2].fRerr > m_CompArray[nComp1].fRerr && m_CompArray[nComp2].fRerr > m_CompArray[nComp3].fRerr && (m_CompArray[nComp1].fTSwitch > FLT_MIN || m_CompArray[nComp3].fTSwitch > FLT_MIN))
	{
		fSwR=m_CompArray[nComp2].fRerr;
		fSwT=m_CompArray[nComp2].fTFLoc;
		if (m_CompArray[nComp1].fRSwitch > m_CompArray[nComp3].fRSwitch)
			fSwT += m_CompArray[nComp1].fRSwitch*(m_CompArray[nComp1].fTSwitch)+(1-m_CompArray[nComp1].fRSwitch)*(m_CompArray[nComp2].fTrep);
		else
			fSwT += m_CompArray[nComp3].fRSwitch*(m_CompArray[nComp3].fTSwitch)+(1-m_CompArray[nComp3].fRSwitch)*(m_CompArray[nComp2].fTrep);
	}
	else
	{
		fSwR=m_CompArray[nComp3].fRerr;
		fSwT=m_CompArray[nComp3].fTFLoc;
		if (m_CompArray[nComp3].fRSwitch > m_CompArray[nComp2].fRSwitch)
			fSwT += m_CompArray[nComp1].fRSwitch*(m_CompArray[nComp1].fTSwitch)+(1-m_CompArray[nComp1].fRSwitch)*(m_CompArray[nComp3].fTrep);
		else
			fSwT += m_CompArray[nComp2].fRSwitch*(m_CompArray[nComp2].fTSwitch)+(1-m_CompArray[nComp2].fRSwitch)*(m_CompArray[nComp3].fTrep);
	}
}

void CDNREstimate::ParallelShortcutSwitchCalc(const int nComp1, const int nComp2, const int nComp3, const int nComp4, double& fSwR, double& fSwT)
{
	fSwR=0;
	fSwT=0;

	if (m_CompArray[nComp1].fRerr < FLT_MIN && m_CompArray[nComp2].fRerr < FLT_MIN && m_CompArray[nComp3].fRerr < FLT_MIN && m_CompArray[nComp4].fRerr < FLT_MIN)
		return;
	if (m_CompArray[nComp1].fTSwitch < FLT_MIN && m_CompArray[nComp2].fTSwitch < FLT_MIN && m_CompArray[nComp3].fTSwitch < FLT_MIN && m_CompArray[nComp4].fTSwitch < FLT_MIN)
		return;


	if (m_CompArray[nComp1].fRerr > m_CompArray[nComp2].fRerr && m_CompArray[nComp1].fRerr > m_CompArray[nComp3].fRerr && m_CompArray[nComp1].fRerr > m_CompArray[nComp4].fRerr &&
		(m_CompArray[nComp2].fTSwitch > FLT_MIN || m_CompArray[nComp3].fTSwitch > FLT_MIN || m_CompArray[nComp4].fTSwitch > FLT_MIN))
	{
		fSwR=m_CompArray[nComp1].fRerr;
		fSwT=m_CompArray[nComp1].fTFLoc;
		if (m_CompArray[nComp2].fRSwitch > m_CompArray[nComp3].fRSwitch && m_CompArray[nComp2].fRSwitch > m_CompArray[nComp4].fRSwitch)
			fSwT += m_CompArray[nComp2].fRSwitch*(m_CompArray[nComp2].fTSwitch)+(1-m_CompArray[nComp2].fRSwitch)*(m_CompArray[nComp1].fTrep);
		else if (m_CompArray[nComp3].fRSwitch > m_CompArray[nComp2].fRSwitch && m_CompArray[nComp3].fRSwitch > m_CompArray[nComp4].fRSwitch)
			fSwT += m_CompArray[nComp3].fRSwitch*(m_CompArray[nComp3].fTSwitch)+(1-m_CompArray[nComp3].fRSwitch)*(m_CompArray[nComp1].fTrep);
		else
			fSwT += m_CompArray[nComp4].fRSwitch*(m_CompArray[nComp4].fTSwitch)+(1-m_CompArray[nComp4].fRSwitch)*(m_CompArray[nComp1].fTrep);
	}
	else if (m_CompArray[nComp2].fRerr > m_CompArray[nComp1].fRerr && m_CompArray[nComp2].fRerr > m_CompArray[nComp3].fRerr && m_CompArray[nComp2].fRerr > m_CompArray[nComp4].fRerr &&
		(m_CompArray[nComp1].fTSwitch > FLT_MIN || m_CompArray[nComp3].fTSwitch > FLT_MIN || m_CompArray[nComp4].fTSwitch > FLT_MIN))
	{
		fSwR=m_CompArray[nComp2].fRerr;
		fSwT=m_CompArray[nComp2].fTFLoc;
		if (m_CompArray[nComp1].fRSwitch > m_CompArray[nComp3].fRSwitch && m_CompArray[nComp1].fRSwitch > m_CompArray[nComp4].fRSwitch)
			fSwT += m_CompArray[nComp1].fRSwitch*(m_CompArray[nComp1].fTSwitch)+(1-m_CompArray[nComp1].fRSwitch)*(m_CompArray[nComp2].fTrep);
		else if (m_CompArray[nComp1].fRSwitch > m_CompArray[nComp3].fRSwitch && m_CompArray[nComp1].fRSwitch > m_CompArray[nComp4].fRSwitch)
			fSwT += m_CompArray[nComp3].fRSwitch*(m_CompArray[nComp3].fTSwitch)+(1-m_CompArray[nComp3].fRSwitch)*(m_CompArray[nComp2].fTrep);
		else
			fSwT += m_CompArray[nComp4].fRSwitch*(m_CompArray[nComp4].fTSwitch)+(1-m_CompArray[nComp4].fRSwitch)*(m_CompArray[nComp2].fTrep);
	}
	else if (m_CompArray[nComp3].fRerr > m_CompArray[nComp1].fRerr && m_CompArray[nComp3].fRerr > m_CompArray[nComp2].fRerr && m_CompArray[nComp3].fRerr > m_CompArray[nComp4].fRerr &&
		(m_CompArray[nComp2].fTSwitch > FLT_MIN || m_CompArray[nComp2].fTSwitch > FLT_MIN || m_CompArray[nComp4].fTSwitch > FLT_MIN))
	{
		fSwR=m_CompArray[nComp3].fRerr;
		fSwT=m_CompArray[nComp3].fTFLoc;
		if (m_CompArray[nComp1].fRSwitch > m_CompArray[nComp2].fRSwitch && m_CompArray[nComp1].fRSwitch > m_CompArray[nComp4].fRSwitch)
			fSwT += m_CompArray[nComp1].fRSwitch*(m_CompArray[nComp1].fTSwitch)+(1-m_CompArray[nComp1].fRSwitch)*(m_CompArray[nComp3].fTrep);
		else if (m_CompArray[nComp2].fRSwitch > m_CompArray[nComp1].fRSwitch && m_CompArray[nComp2].fRSwitch > m_CompArray[nComp4].fRSwitch)
			fSwT += m_CompArray[nComp2].fRSwitch*(m_CompArray[nComp2].fTSwitch)+(1-m_CompArray[nComp2].fRSwitch)*(m_CompArray[nComp3].fTrep);
		else
			fSwT += m_CompArray[nComp4].fRSwitch*(m_CompArray[nComp4].fTSwitch)+(1-m_CompArray[nComp4].fRSwitch)*(m_CompArray[nComp3].fTrep);
	}
	else
	{
		fSwR=m_CompArray[nComp4].fRerr;
		fSwT=m_CompArray[nComp4].fTFLoc;
		if (m_CompArray[nComp1].fRSwitch > m_CompArray[nComp2].fRSwitch && m_CompArray[nComp1].fRSwitch > m_CompArray[nComp3].fRSwitch)
			fSwT += m_CompArray[nComp1].fRSwitch*(m_CompArray[nComp1].fTSwitch)+(1-m_CompArray[nComp1].fRSwitch)*(m_CompArray[nComp4].fTrep);
		else if (m_CompArray[nComp2].fRSwitch > m_CompArray[nComp1].fRSwitch && m_CompArray[nComp2].fRSwitch > m_CompArray[nComp3].fRSwitch)
			fSwT += m_CompArray[nComp2].fRSwitch*(m_CompArray[nComp2].fTSwitch)+(1-m_CompArray[nComp2].fRSwitch)*(m_CompArray[nComp4].fTrep);
		else
			fSwT += m_CompArray[nComp3].fRSwitch*(m_CompArray[nComp3].fTSwitch)+(1-m_CompArray[nComp3].fRSwitch)*(m_CompArray[nComp4].fTrep);
	}
}

void CDNREstimate::ParallelShortcutSwitch()
{
	register int	i;
	int nComp1=0;
	int nComp2=0;
	int nComp3=0;
	int nComp4=0;

	//��һ�׸û���л�

	//����
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		m_MCutO2Array[i].fSwitchR=0;
		m_MCutO2Array[i].fSwitchT=0;
		if (m_MCutO2Array[i].bDegreed)
			continue;

		nComp1 = m_MCutO2Array[i].nComp[0];
		nComp2 = m_MCutO2Array[i].nComp[1];
		if ((m_CompArray[nComp1].fRSwitch < FLT_MIN || m_CompArray[nComp1].fTSwitch < FLT_MIN) &&
			(m_CompArray[nComp2].fRSwitch < FLT_MIN || m_CompArray[nComp2].fTSwitch < FLT_MIN))
			continue;

		ParallelShortcutSwitchCalc(nComp1, nComp2, m_MCutO2Array[i].fSwitchR, m_MCutO2Array[i].fSwitchT);
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ���׸��л� : [%s %s] R=%f T=%f\n", m_CompArray[nComp1].strName.c_str(), m_CompArray[nComp2].strName.c_str(), m_MCutO2Array[i].fSwitchR, m_MCutO2Array[i].fSwitchT);
#endif
	}

	//����
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		m_MCutO3Array[i].fSwitchR=0;
		m_MCutO3Array[i].fSwitchT=0;
		if (m_MCutO3Array[i].bDegreed)
			continue;

		nComp1 = m_MCutO3Array[i].nComp[0];
		nComp2 = m_MCutO3Array[i].nComp[1];
		nComp3 = m_MCutO3Array[i].nComp[2];
		if ((m_CompArray[nComp1].fRSwitch < FLT_MIN || m_CompArray[nComp1].fTSwitch < FLT_MIN) &&
			(m_CompArray[nComp2].fRSwitch < FLT_MIN || m_CompArray[nComp2].fTSwitch < FLT_MIN) &&
			(m_CompArray[nComp3].fRSwitch < FLT_MIN || m_CompArray[nComp3].fTSwitch < FLT_MIN))
			continue;

		ParallelShortcutSwitchCalc(nComp1, nComp2, nComp3, m_MCutO3Array[i].fSwitchR , m_MCutO3Array[i].fSwitchT);

#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ���׸��л� : R=%f T=%f\n", m_MCutO3Array[i].fSwitchR, m_MCutO3Array[i].fSwitchT);
#endif
	}

	//�Ľ�
	for (i=0; i<(int)m_MCutO4Array.size(); i++)
	{
		m_MCutO4Array[i].fSwitchR=0;
		m_MCutO4Array[i].fSwitchT=0;

		nComp1 = m_MCutO4Array[i].nComp[0];
		nComp2 = m_MCutO4Array[i].nComp[1];
		nComp3 = m_MCutO4Array[i].nComp[2];
		nComp4 = m_MCutO4Array[i].nComp[3];
		if ((m_CompArray[nComp1].fRSwitch < FLT_MIN || m_CompArray[nComp1].fTSwitch < FLT_MIN) &&
			(m_CompArray[nComp2].fRSwitch < FLT_MIN || m_CompArray[nComp2].fTSwitch < FLT_MIN) &&
			(m_CompArray[nComp3].fRSwitch < FLT_MIN || m_CompArray[nComp3].fTSwitch < FLT_MIN) &&
			(m_CompArray[nComp4].fRSwitch < FLT_MIN || m_CompArray[nComp4].fTSwitch < FLT_MIN))
			continue;

		ParallelShortcutSwitchCalc(nComp1, nComp2, nComp3, nComp4, m_MCutO4Array[i].fSwitchR , m_MCutO4Array[i].fSwitchT);

#ifdef _DEBUG
		Log(g_lpszLogFile,  "    �Ľ׸��л� : R=%f T=%f\n", m_MCutO4Array[i].fSwitchR, m_MCutO4Array[i].fSwitchT);
#endif
	}
}
