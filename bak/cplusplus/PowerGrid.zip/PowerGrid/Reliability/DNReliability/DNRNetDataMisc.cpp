#include "stdafx.h"
#include <Windows.h>
#include "DNRNetData.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

const	char*	lpszInDataFile="DisReliableData.xml";
void	CDNRNetData::SaveRDataFile(const char* lpszFileName)
{
	register int	i, j;
	TiXmlElement*	pSecElement;
	TiXmlElement*	pElement;
	TiXmlElement*	pSubElement;
	char			szBuf[260];

	TiXmlDocument*		pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����
	TiXmlDeclaration*	pDeclare = new TiXmlDeclaration("1.0", "GB2312", "no");
	pDocument->LinkEndChild(pDeclare);
	TiXmlElement*		pRoot = new TiXmlElement("DisReliableData");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRoot);

	pSecElement = new TiXmlElement("ReliableNode");
	pRoot->LinkEndChild(pSecElement);
	for (i=0; i<(int)m_RData.m_NodeArray.size(); i++)
	{
		pElement = new TiXmlElement("Node");

		pElement->SetAttribute("TopoBus",	m_RData.m_NodeArray[i].nTopoBus);
		pElement->SetAttribute("NodeTyp",	m_RData.m_NodeArray[i].nNodeTyp);

		pSecElement->LinkEndChild(pElement);
	}

	pSecElement = new TiXmlElement("ReliableGen");
	pRoot->LinkEndChild(pSecElement);
	for (i=0; i<(int)m_RData.m_GenArray.size(); i++)
	{
		pElement = new TiXmlElement("Gen");

		pElement->SetAttribute("Type",		m_RData.m_GenArray[i].nDevTyp);
		pElement->SetAttribute("DevIdx",	m_RData.m_GenArray[i].nDevIdx);
		pElement->SetAttribute("ResID",		m_RData.m_GenArray[i].szResID);
		pElement->SetAttribute("TopoBus",	m_RData.m_GenArray[i].nTopoBus);
		pElement->SetAttribute("NewNode",	m_RData.m_GenArray[i].nNewNode);
		pElement->SetDoubleAttribute("P",	m_RData.m_GenArray[i].fP);
		pElement->SetDoubleAttribute("MaxP", m_RData.m_GenArray[i].fMaxP);

		for (j=0; j<12; j++)
		{
			TiXmlElement*	pSub=new TiXmlElement("PowerOut");
			sprintf(szBuf, "%f", m_RData.m_GenArray[i].fPowerOut[j]);
			pSub->LinkEndChild(new TiXmlText(szBuf));
			pElement->LinkEndChild(pSub);
		}
		for (j=0; j<12; j++)
		{
			TiXmlElement*	pSub=new TiXmlElement("StatProb");
			sprintf(szBuf, "%f", m_RData.m_GenArray[i].fStatProb[j]);
			pSub->LinkEndChild(new TiXmlText(szBuf));
			pElement->LinkEndChild(pSub);
		}

		pSecElement->LinkEndChild(pElement);
	}

	pSecElement = new TiXmlElement("ReliableComp");
	pRoot->LinkEndChild(pSecElement);
	for (i=0; i<(int)m_RData.m_CompArray.size(); i++)
	{
		pElement = new TiXmlElement("Comp");

		pElement->SetAttribute("Type",			m_RData.m_CompArray[i].nDevTyp);
		pElement->SetAttribute("DevIndex",		m_RData.m_CompArray[i].nDevIdx);
		pElement->SetAttribute("CompID",		m_RData.m_CompArray[i].strResID.c_str());
		pElement->SetAttribute("CompName",		m_RData.m_CompArray[i].strName.c_str());
		pElement->SetAttribute("IniNode",		m_RData.m_CompArray[i].nIniNode);
		pElement->SetAttribute("EndNode",		m_RData.m_CompArray[i].nEndNode);
		pElement->SetAttribute("NewIniNode",	m_RData.m_CompArray[i].nNewIniNode);
		pElement->SetAttribute("NewEndNode",	m_RData.m_CompArray[i].nNewEndNode);
		pElement->SetAttribute("IniSub",		m_RData.m_CompArray[i].nIniSub);
		pElement->SetAttribute("EndSub",		m_RData.m_CompArray[i].nEndSub);

		pElement->SetDoubleAttribute("Rerr",	m_RData.m_CompArray[i].fRerr);
		pElement->SetDoubleAttribute("Trep",	m_RData.m_CompArray[i].fTrep);
		pElement->SetDoubleAttribute("Rchk",	m_RData.m_CompArray[i].fRchk);
		pElement->SetDoubleAttribute("Tchk",	m_RData.m_CompArray[i].fTchk);
		pElement->SetDoubleAttribute("RSwitch",	m_RData.m_CompArray[i].fRSwitch);
		pElement->SetDoubleAttribute("TSwitch",	m_RData.m_CompArray[i].fTSwitch);
		pElement->SetDoubleAttribute("TFLoc",	m_RData.m_CompArray[i].fTFLoc);

		pElement->SetAttribute("BreakerType",	m_RData.m_CompArray[i].nBreakerType);

		pElement->SetAttribute("Status",		m_RData.m_CompArray[i].nStatus);
		pElement->SetAttribute("Direct",		m_RData.m_CompArray[i].nDirect);
		pElement->SetAttribute("SourceI",		m_RData.m_CompArray[i].bSourceI);
		pElement->SetAttribute("SourceZ",		m_RData.m_CompArray[i].bSourceZ);
		pElement->SetAttribute("CmBreaker",		m_RData.m_CompArray[i].bCmBreaker);
		pElement->SetDoubleAttribute("Limit",		m_RData.m_CompArray[i].fLimit);
		pElement->SetDoubleAttribute("Length",		m_RData.m_CompArray[i].fLength);
		pElement->SetDoubleAttribute("SpareProb",	m_RData.m_CompArray[i].fSpareProb);
		pElement->SetAttribute("Augmentation",	m_RData.m_CompArray[i].nAugmentation);

		for (j=0; j<(int)m_RData.m_CompArray[i].sLnkDevArray.size(); j++)
		{
			pSubElement=new TiXmlElement("LnkDev");
			pElement->LinkEndChild(pSubElement);
			pSubElement->SetAttribute("Device", m_RData.m_CompArray[i].sLnkDevArray[j].nDevice);
			pSubElement->SetAttribute("SideNode", m_RData.m_CompArray[i].sLnkDevArray[j].nSideNode);
		}

		for (j=0; j<(int)m_RData.m_CompArray[i].sFCmDevArray.size(); j++)
		{
			pSubElement=new TiXmlElement("FCmDev");
			pElement->LinkEndChild(pSubElement);
			pSubElement->SetAttribute("Device", m_RData.m_CompArray[i].sFCmDevArray[j].nDevice);
			pSubElement->SetAttribute("SideNode", m_RData.m_CompArray[i].sFCmDevArray[j].nSideNode);
		}

		pSecElement->LinkEndChild(pElement);
	}

	pSecElement = new TiXmlElement("ReliableLoad");
	pRoot->LinkEndChild(pSecElement);
	for (i=0; i<(int)m_RData.m_LoadArray.size(); i++)
	{
		pElement = new TiXmlElement("Load");

		pElement->SetAttribute("ResID",				m_RData.m_LoadArray[i].strResID.c_str());
		pElement->SetAttribute("Name",				m_RData.m_LoadArray[i].strName.c_str());
		pElement->SetAttribute("SubControlArea",	m_RData.m_LoadArray[i].strSubcontrolArea.c_str());
		pElement->SetAttribute("Substation",		m_RData.m_LoadArray[i].strSubstation.c_str());
		pElement->SetAttribute("TopoBus",			m_RData.m_LoadArray[i].nTopoBus);
		pElement->SetAttribute("NewNode",			m_RData.m_LoadArray[i].nNewNode);
		pElement->SetDoubleAttribute("Customer",	m_RData.m_LoadArray[i].fCustomer);
		pElement->SetDoubleAttribute("P",			m_RData.m_LoadArray[i].fP);
		pElement->SetAttribute("DevTyp",			m_RData.m_LoadArray[i].nDevTyp);
		pElement->SetAttribute("DevIdx",			m_RData.m_LoadArray[i].nDevIdx);
		pElement->SetAttribute("InrangeSpareSource",m_RData.m_LoadArray[i].bInSpareSourceRange);

		pSecElement->LinkEndChild(pElement);
	}

	char	szTempPath[260];
	char	szFileName[260];
	GetTempPath(260, szTempPath);
	if (lpszFileName == NULL)
		sprintf(szFileName, "%s/%s", szTempPath, lpszInDataFile);
	else
		sprintf(szFileName, "%s/%s", szTempPath, lpszFileName);
	pDocument->SaveFile(szFileName);					//���浽�ļ�
	pDocument->Clear();
	delete pDocument;
}

int	CDNRNetData::ReadRDataFile(const char* lpszFileName)
{
	char	szTempPath[260];
	char	szFileName[260];
	GetTempPath(260, szTempPath);
	if (lpszFileName == NULL)
		sprintf(szFileName, "%s/%s", szTempPath, lpszInDataFile);
	else
		sprintf(szFileName, "%s/%s", szTempPath, lpszFileName);

	TiXmlDocument doc(szFileName);
	if (!doc.LoadFile())
	{
		//Log("No File\n"));
		return 0;
	}

	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "DisReliableData") != 0)
	{
		doc.Clear();
		return 0;
	}

	tagRNode		sNodeBuf;
	tagRComp		sCompBuf;
	tagRLoad		sLoadBuf;
	tagRGen			sGenBuf;
	tagCmComp		sCmBuf;

	m_RData.m_NodeArray.clear();
	m_RData.m_CompArray.clear();
	m_RData.m_LoadArray.clear();
	m_RData.m_GenArray.clear();

	InitializeRNode(&sNodeBuf);
	memset(&sGenBuf, 0, sizeof(tagRGen));
	memset(&sCmBuf, 0, sizeof(tagCmComp));

	TiXmlElement* pElement;
	TiXmlElement* pSubElement;
	TiXmlElement* pSection = pRoot->FirstChildElement();
	while (pSection != NULL)
	{
		if (stricmp(pSection->Value(), "ReliableNode") == 0)
		{
			pElement = pSection->FirstChildElement();
			while (pElement != NULL)
			{
				if (stricmp(pElement->Value(), "Node") == 0)
				{
					pElement->Attribute("TopoBus",	&sNodeBuf.nTopoBus);
					pElement->Attribute("NodeTyp",	&sNodeBuf.nNodeTyp);

					m_RData.m_NodeArray.push_back(sNodeBuf);
				}
				pElement = pElement->NextSiblingElement();
			}
		}
		if (stricmp(pSection->Value(), "ReliableComp") == 0)
		{
			pElement = pSection->FirstChildElement();
			while (pElement != NULL)
			{
				if (stricmp(pElement->Value(), "Comp") == 0)
				{
					InitializeRComp(&sCompBuf);

					pElement->Attribute("Type",			&sCompBuf.nDevTyp);
					pElement->Attribute("DevIndex",		&sCompBuf.nDevIdx);
					sCompBuf.strResID=pElement->Attribute("CompID");
					sCompBuf.strName=pElement->Attribute("CompName");
					pElement->Attribute("IniNode",		&sCompBuf.nIniNode);
					pElement->Attribute("EndNode",		&sCompBuf.nEndNode);
					pElement->Attribute("NewIniNode",	&sCompBuf.nNewIniNode);
					pElement->Attribute("NewEndNode",	&sCompBuf.nNewEndNode);
					sCompBuf.nIniSub=atoi(pElement->Attribute("IniSub"));
					sCompBuf.nEndSub=atoi(pElement->Attribute("EndSub"));

					sCompBuf.fRerr=(float)atof(pElement->Attribute("Rerr"));
					sCompBuf.fTrep=(float)atof(pElement->Attribute("Trep"));
					sCompBuf.fRchk=(float)atof(pElement->Attribute("Rchk"));
					sCompBuf.fTchk=(float)atof(pElement->Attribute("Tchk"));
					sCompBuf.fRSwitch=(float)atof(pElement->Attribute("RSwitch"));
					sCompBuf.fTSwitch=(float)atof(pElement->Attribute("TSwitch"));
					sCompBuf.fTFLoc=(float)atof(pElement->Attribute("TFLoc"));

					sCompBuf.nBreakerType=atoi(pElement->Attribute("BreakerType"));

					sCompBuf.nStatus=atoi(pElement->Attribute("Status"));
					sCompBuf.nDirect=atoi(pElement->Attribute("Direct"));
					sCompBuf.bSourceI=atoi(pElement->Attribute("SourceI"));
					sCompBuf.bSourceZ=atoi(pElement->Attribute("SourceZ"));
					sCompBuf.bCmBreaker=atoi(pElement->Attribute("CmBreaker"));
					sCompBuf.fLimit=(float)atof(pElement->Attribute("Limit"));
					sCompBuf.fLength=(float)atof(pElement->Attribute("Length"));
					sCompBuf.fSpareProb=(float)atof(pElement->Attribute("SpareProb"));
					sCompBuf.nAugmentation=atoi(pElement->Attribute("Augmentation"));

					pSubElement = pElement->FirstChildElement();
					while (pSubElement != NULL)
					{
						if (stricmp(pSubElement->Value(), "LnkDev") == 0)
						{
							pSubElement->Attribute("Device",	&sCmBuf.nDevice);
							pSubElement->Attribute("SideNode",	&sCmBuf.nSideNode);

							sCompBuf.sLnkDevArray.push_back(sCmBuf);
						}
						else if (stricmp(pSubElement->Value(), "FCmDev") == 0)
						{
							pSubElement->Attribute("Device",	&sCmBuf.nDevice);
							pSubElement->Attribute("SideNode",	&sCmBuf.nSideNode);

							sCompBuf.sFCmDevArray.push_back(sCmBuf);
						}
						pSubElement = pSubElement->NextSiblingElement();
					}

					m_RData.m_CompArray.push_back(sCompBuf);
				}
				pElement = pElement->NextSiblingElement();
			}
		}
		if (stricmp(pSection->Value(), "ReliableGen") == 0)
		{
			pElement = pSection->FirstChildElement();
			while (pElement != NULL)
			{
				if (stricmp(pElement->Value(), "Gen") == 0)
				{
					pElement->Attribute("Type",		&sGenBuf.nDevTyp);
					pElement->Attribute("DevIdx",	&sGenBuf.nDevIdx);
					strcpy(sGenBuf.szResID, pElement->Attribute("ResID"));
					pElement->Attribute("TopoBus",	&sGenBuf.nTopoBus);
					pElement->Attribute("NewNode",	&sGenBuf.nNewNode);
					sGenBuf.fP=(float)atof(pElement->Attribute("P"));
					sGenBuf.fMaxP=(float)atof(pElement->Attribute("MaxP"));

					m_RData.m_GenArray.push_back(sGenBuf);
				}
				pElement = pElement->NextSiblingElement();
			}
		}
		if (stricmp(pSection->Value(), "ReliableLoad") == 0)
		{
			pElement = pSection->FirstChildElement();
			while (pElement != NULL)
			{
				if (stricmp(pElement->Value(), "Load") == 0)
				{
					InitializeRLoad(&sLoadBuf);
					sLoadBuf.strResID=pElement->Attribute("ResID");
					sLoadBuf.strName=pElement->Attribute("Name");
					sLoadBuf.strSubcontrolArea=pElement->Attribute("SubControlArea");
					sLoadBuf.strSubstation=pElement->Attribute("Substation");
					pElement->Attribute("TopoBus",		&sLoadBuf.nTopoBus);
					pElement->Attribute("NewNode",		&sLoadBuf.nNewNode);
					sLoadBuf.fCustomer=(float)atof(pElement->Attribute("Customer"));
					sLoadBuf.fP=(float)atof(pElement->Attribute("P"));
					sLoadBuf.nDevTyp=atoi(pElement->Attribute("DevTyp"));
					pElement->Attribute("DevIdx",		&sLoadBuf.nDevIdx);
					sLoadBuf.bInSpareSourceRange=atoi(pElement->Attribute("InrangeSpareSource"));

					m_RData.m_LoadArray.push_back(sLoadBuf);
				}
				pElement = pElement->NextSiblingElement();
			}
		}

		pSection = pSection->NextSiblingElement();
	}

	doc.Clear();

	//	2���γɽڵ���Ϣ��
	int		nDev;
	for (nDev=0; nDev<(int)m_RData.m_NodeArray.size(); nDev++)
		m_RData.m_NodeArray[nDev].nCompArray.clear();
	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	{
		if (m_RData.m_CompArray[nDev].nDevTyp == PG_BUSBARSECTION || m_RData.m_CompArray[nDev].nDevTyp == PG_SYNCHRONOUSMACHINE)
			continue;

		m_RData.m_NodeArray[m_RData.m_CompArray[nDev].nNewIniNode].nCompArray.push_back(nDev);
		m_RData.m_NodeArray[m_RData.m_CompArray[nDev].nNewEndNode].nCompArray.push_back(nDev);
	}

	return 1;
}

int	CDNRNetData::IsTransformerWindingAsSource(tagPGBlock* pPGBlock, const int nWind, const int nTranNode)
{
	if (pPGBlock->m_PowerTransformerArray[pPGBlock->m_TransformerWindingArray[nWind].nTran].nWindH == nWind)
	{
		if (pPGBlock->m_PowerTransformerArray[pPGBlock->m_TransformerWindingArray[nWind].nTran].nWindNum == 2)	//	��ѹ����������
		{
			if (nTranNode == pPGBlock->m_TransformerWindingArray[nWind].nNodeI && pPGBlock->m_TransformerWindingArray[nWind].fRatedkVI >= pPGBlock->m_TransformerWindingArray[nWind].fRatedkVJ)
				return 0;
			if (nTranNode == pPGBlock->m_TransformerWindingArray[nWind].nNodeJ && pPGBlock->m_TransformerWindingArray[nWind].fRatedkVI <= pPGBlock->m_TransformerWindingArray[nWind].fRatedkVJ)
				return 0;
			else
				return PG_SYNCHRONOUSMACHINE;
		}
	}
	return PG_SYNCHRONOUSMACHINE;
}

int	CDNRNetData::IsNodeJointSourceWithinVoltage(tagPGBlock* pPGBlock, const int nJudgeNode)
{
	register int	i;
	int		nNode, nNodeNum;

	int*	pnNodeArray=(int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnNodeArray)
		return 0;

	PGTraverseLine(pPGBlock, nJudgeNode, N_CheckStatus, nNodeNum, pnNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[i].nNode == pnNodeArray[nNode])
				goto _Ext1;
		}
	}

	free(pnNodeArray);
	return 0;

_Ext1:
	free(pnNodeArray);
	return 1;
}

int	CDNRNetData::IsBreakerNodeJointSource(tagPGBlock* pPGBlock, const int nJudgeNode, const int nBreaker)
{
	register int	i;
	int		nNode, nNodeNum;
	unsigned	char	nReturn;

	std::vector<unsigned char>	bBStArray, bSStArray;
	int*	pnNodeArray=(int*)malloc(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnNodeArray)
		return 0;

	bBStArray.resize(pPGBlock->m_nRecordNum[PG_BREAKER]);
	bSStArray.resize(pPGBlock->m_nRecordNum[PG_DISCONNECTOR]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_BREAKER]; i++)
	{
		bBStArray[i]=pPGBlock->m_BreakerArray[i].nStatus;
		pPGBlock->m_BreakerArray[i].nStatus=0;
	}
	for (i=0; i<pPGBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
	{
		bSStArray[i]=pPGBlock->m_DisconnectorArray[i].nStatus;
		pPGBlock->m_DisconnectorArray[i].nStatus=0;
	}
	pPGBlock->m_BreakerArray[nBreaker].nStatus=1;

	nReturn=0;
	PGTraverseNet(pPGBlock, nJudgeNode, Y_CheckStatus, 0, nNodeNum, pnNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[i].nNode == pnNodeArray[nNode])
			{
				nReturn=1;
				goto _Out;
			}
		}
	}

_Out:
	for (i=0; i<pPGBlock->m_nRecordNum[PG_BREAKER]; i++)
		pPGBlock->m_BreakerArray[i].nStatus=bBStArray[i];
	for (i=0; i<pPGBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
		pPGBlock->m_DisconnectorArray[i].nStatus=bSStArray[i];
	bBStArray.clear();
	bSStArray.clear();
	free(pnNodeArray);

	return nReturn;
}
