#pragma once

#include "DNRDataDefine.h"

class CDisjointAlgorithm
{
public:
	CDisjointAlgorithm();

public:
	int		DisJoint_Init(std::vector<tagRNode>& sNodeArray, std::vector<tagRComp>& sCompArray, const int nIniNode, std::vector<int>& nNodeArray);
	void	DisJoint_Calc(const int nEndNode, std::vector<int>& nNodeArray);
	void	DisJoint2MinPath(std::vector<tagRNode>& sNodeArray, std::vector<tagRComp>& sCompArray, std::vector<int>& nNodeArray, std::vector<tagRMinPath>& minPathArray);

private:
	int		m_nMaxRoad;
	int		m_nBusNum;
	int		m_nIniBus;
	int		m_nEndBus;
	std::vector<int>	m_nChkVector;
	std::vector<int>	m_nPosVector;
	std::vector< std::vector<int> > m_RouteMatrix;
	std::vector< std::vector<int> >	m_DisjointNodeMatrix;

private:
	int GetVw(int nEdge);
};
