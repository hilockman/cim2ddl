#include "stdafx.h"
#include "DNReliability.h"

//3.3.3��ģ��ʹ�ö�·�������Ĺ����ʺ͹��϶�λ����ʱ�䣬��������·��֧��
void CDNREstimate::FormShortcutCommon()
{
	register int	i;
	int		nComp, nCmF, nCmS;
	int		nFComp, nSComp, nTComp;
	int		nCmComp, nCmCompF, nCmCompS, nCmCompT;
	double	fR1, fR2, fT1, fT2;
	tagCmMCutO1	sCmFCutBuf;
	tagCmMCutO2	sCmSCutBuf;

	m_CmMCutO1Array.clear();
	m_CmMCutO2Array.clear();

	//һ�׸
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		nFComp = m_MCutO1Array[i].nComp;
		if (!m_CompArray[nFComp].bCmBreaker)							//	�����Ƕ�·��
			continue;

#ifdef _DEBUG
		Log(g_lpszLogFile,  "Common һ�׸� ��%s��\n", m_CompArray[nFComp].strName.c_str());
#endif
		for (nComp=0; nComp<(int)m_CompArray[nFComp].sFCmDevArray.size(); nComp++)
		{
			nCmComp=m_CompArray[nFComp].sFCmDevArray[nComp].nDevice;
			if (m_CompArray[nCmComp].fRerr <= FLT_MIN && m_CompArray[nCmComp].fTrep <= FLT_MIN)
				continue;

			if (isInMCut01(nCmComp))
				continue;
			if (isInCommonMCut01(nCmComp))
				continue;
			if (isInDegreeMCut01(nCmComp))
				continue;

			sCmFCutBuf.nCutType = DNREnumCutType_Cut1_Cut1OneBreakerComm;
			sCmFCutBuf.fR=m_CompArray[nCmComp].fRerr;
			sCmFCutBuf.fT=(m_CompArray[nCmComp].fTFLoc <= m_CompArray[nCmComp].fTrep || m_CompArray[nCmComp].fTrep <= FLT_MIN) ? m_CompArray[nCmComp].fTFLoc : m_CompArray[nCmComp].fTrep;

			sCmFCutBuf.nBreaker[0]=nFComp;
			sCmFCutBuf.nBreaker[1]=-1;
			sCmFCutBuf.nBreaker[2]=-1;
			sCmFCutBuf.nComp=nCmComp;

			if (sCmFCutBuf.fR > FLT_MIN && sCmFCutBuf.fT > FLT_MIN)
			{
#ifdef _DEBUG
				Log(g_lpszLogFile,  "            ����·�����ӹ�ģһ�׸� : [%s] R1=%f T1=%f\n", m_CompArray[nCmComp].strName.c_str(), sCmFCutBuf.fR, sCmFCutBuf.fT);
#endif
				m_CmMCutO1Array.push_back(sCmFCutBuf);
			}
		}
	}

	//���׸
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		nFComp = m_MCutO2Array[i].nComp[0];
		nSComp = m_MCutO2Array[i].nComp[1];

		if (!m_CompArray[nFComp].bCmBreaker && !m_CompArray[nSComp].bCmBreaker)
			continue;

#ifdef _DEBUG
		Log(g_lpszLogFile,  "Common ���׸� [%s-%d] [%s-%d]\n", m_CompArray[nFComp].strName.c_str(), m_CompArray[nFComp].sFCmDevArray.size(), m_CompArray[nSComp].strName.c_str(), m_CompArray[nSComp].sFCmDevArray.size());
#endif
		if (m_CompArray[nFComp].bCmBreaker && m_CompArray[nSComp].bCmBreaker)
		{
			for (nCmF=0; nCmF<(int)m_CompArray[nFComp].sFCmDevArray.size(); nCmF++)
			{
				nCmCompF=m_CompArray[nFComp].sFCmDevArray[nCmF].nDevice;
				if (isInMCut01(nCmCompF))
					continue;
				if (isInDegreeMCut01(nCmCompF))
					continue;

				for (nCmS=0; nCmS<(int)m_CompArray[nSComp].sFCmDevArray.size(); nCmS++)
				{
					nCmCompS=m_CompArray[nSComp].sFCmDevArray[nCmS].nDevice;
					if (nCmCompF == nCmCompS)
					{
						memset(&sCmFCutBuf, 0, sizeof(tagCmMCutO1));
						sCmFCutBuf.fR=m_CompArray[nCmCompF].fRerr;
						sCmFCutBuf.fT=(m_CompArray[nCmCompF].fTFLoc <= m_CompArray[nCmCompF].fTrep || m_CompArray[nCmCompF].fTrep <= FLT_MIN) ? m_CompArray[nCmCompF].fTFLoc : m_CompArray[nCmCompF].fTrep;

						sCmFCutBuf.nCutType = DNREnumCutType_Cut1_Cut2TwoBreakerComm;
						sCmFCutBuf.nBreaker[0]=nFComp;
						sCmFCutBuf.nBreaker[1]=nSComp;
						sCmFCutBuf.nBreaker[2]=-1;
						sCmFCutBuf.nComp=nCmCompF;
						if (sCmFCutBuf.fR > FLT_MIN && sCmFCutBuf.fT > FLT_MIN)
							m_CmMCutO1Array.push_back(sCmFCutBuf);
					}
					else
					{
						if (isInMCut01(nCmCompS))
							continue;
						if (isInDegreeMCut01(nCmCompS))
							continue;
						if (isInMCut02(nCmCompF, nCmCompS))
							continue;
						if (isInCommonMCut02(nCmCompF, nCmCompS))
							continue;

						fR1=m_CompArray[nCmCompF].fRerr;
						fR2=m_CompArray[nCmCompS].fRerr;
						fT1=(m_CompArray[nCmCompF].fTFLoc <= m_CompArray[nCmCompF].fTrep || m_CompArray[nCmCompF].fTrep <= FLT_MIN) ? m_CompArray[nCmCompF].fTFLoc : m_CompArray[nCmCompF].fTrep;//fT1=m_CompArray[nFComp].sFCmDevArray[nCmF].fTFLoc;
						fT2=(m_CompArray[nCmCompS].fTFLoc <= m_CompArray[nCmCompS].fTrep || m_CompArray[nCmCompS].fTrep <= FLT_MIN) ? m_CompArray[nCmCompS].fTFLoc : m_CompArray[nCmCompS].fTrep;//fT2=m_CompArray[nSComp].sFCmDevArray[nCmS].fTFLoc;

						sCmSCutBuf.nCutType = DNREnumCutType_Cut2_Cut2TwoBreakerComm;
						sCmSCutBuf.nBreaker[0]=nFComp;
						sCmSCutBuf.nBreaker[1]=nSComp;
						sCmSCutBuf.nBreaker[2]=-1;
						sCmSCutBuf.nComp[0]=nCmCompF;
						sCmSCutBuf.nComp[1]=nCmCompS;
						sCmSCutBuf.fR=fR1*fR2*(fT1+fT2)/8760;
						if (8760*sCmSCutBuf.fR > FLT_MIN)
							sCmSCutBuf.fT=(fR1*fR2*fT1*fT2)/(8760*sCmSCutBuf.fR);

						if (sCmSCutBuf.fR > FLT_MIN && sCmSCutBuf.fT > FLT_MIN)
							m_CmMCutO2Array.push_back(sCmSCutBuf);
					}
				}
			}
		}
		else if (m_CompArray[nFComp].bCmBreaker)
		{
			for (nComp=0; nComp<(int)m_CompArray[nFComp].sFCmDevArray.size(); nComp++)
			{
				nCmComp=m_CompArray[nFComp].sFCmDevArray[nComp].nDevice;
				if (isInMCut01(nCmComp))
					continue;
				if (isInMCut02(nSComp, nCmComp))
					continue;
				if (isInDegreeMCut01(nCmComp))
					continue;
				if (isInCommonMCut02(nSComp, nCmComp))
					continue;

				fR1=m_CompArray[nCmComp].fRerr;
				fT1=(m_CompArray[nCmComp].fTFLoc <= m_CompArray[nCmComp].fTrep || m_CompArray[nCmComp].fTrep <= FLT_MIN) ? m_CompArray[nCmComp].fTFLoc : m_CompArray[nCmComp].fTrep;//fT2=m_CompArray[nFComp].sFCmDevArray[nComp].fTFLoc;

				fR2=m_CompArray[nSComp].fRerr;
				fT2=m_CompArray[nSComp].fTrep;

				sCmSCutBuf.nCutType = DNREnumCutType_Cut2_Cut2OneBreakerComm;
				sCmSCutBuf.nBreaker[0]=nFComp;
				sCmSCutBuf.nBreaker[1]=-1;
				sCmSCutBuf.nBreaker[2]=-1;
				sCmSCutBuf.nComp[0]=nCmComp;
				sCmSCutBuf.nComp[1]=nSComp;
				sCmSCutBuf.fR=fR1*fR2*(fT1+fT2)/8760;
				if (8760*sCmSCutBuf.fR > FLT_MIN)
					sCmSCutBuf.fT=(fR1*fR2*fT1*fT2)/(8760*sCmSCutBuf.fR);

				if (sCmSCutBuf.fR > FLT_MIN && sCmSCutBuf.fT > FLT_MIN)
					m_CmMCutO2Array.push_back(sCmSCutBuf);
			}
		}
		else if (m_CompArray[nSComp].bCmBreaker)
		{
			for (nComp=0; nComp<(int)m_CompArray[nSComp].sFCmDevArray.size(); nComp++)
			{
				nCmComp=m_CompArray[nSComp].sFCmDevArray[nComp].nDevice;

				if (isInMCut01(nCmComp))
					continue;
				if (isInMCut02(nFComp, nCmComp))
					continue;
				if (isInDegreeMCut01(nCmComp))
					continue;
				if (isInCommonMCut02(nFComp, nCmComp))
					continue;

				fR1=m_CompArray[nFComp].fRerr;
				fT1=m_CompArray[nFComp].fTrep;
				fR2=m_CompArray[nCmComp].fRerr;
				fT2=(m_CompArray[nCmComp].fTFLoc <= m_CompArray[nCmComp].fTrep || m_CompArray[nCmComp].fTrep <= FLT_MIN) ? m_CompArray[nCmComp].fTFLoc : m_CompArray[nCmComp].fTrep;

				sCmSCutBuf.nCutType = DNREnumCutType_Cut2_Cut2TwoBreakerComm;
				sCmSCutBuf.nBreaker[0]=nSComp;
				sCmSCutBuf.nBreaker[1]=-1;
				sCmSCutBuf.nBreaker[2]=-1;
				sCmSCutBuf.nComp[0]=nCmComp;
				sCmSCutBuf.nComp[1]=nFComp;
				sCmSCutBuf.fR=fR1*fR2*(fT1+fT2)/8760;
				if (8760*sCmSCutBuf.fR > FLT_MIN)
					sCmSCutBuf.fT=(fR1*fR2*fT1*fT2)/(8760*sCmSCutBuf.fR);

				if (sCmSCutBuf.fR > FLT_MIN && sCmSCutBuf.fT > FLT_MIN)
					m_CmMCutO2Array.push_back(sCmSCutBuf);
			}
		}
	}

	//���׹�ģ�滻�������ǵ���·��������Ϊ����·���������󣬵��ǹ��׶�С��
	int	j1, j2, j3;
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		nFComp = m_MCutO3Array[i].nComp[0];
		nSComp = m_MCutO3Array[i].nComp[1];
		nTComp = m_MCutO3Array[i].nComp[2];

		if (m_CompArray[nFComp].bCmBreaker && m_CompArray[nSComp].bCmBreaker && m_CompArray[nTComp].bCmBreaker)
		{
			for (j1=0; j1<(int)m_CompArray[nFComp].sFCmDevArray.size(); j1++)
			{
				nCmCompF=m_CompArray[nFComp].sFCmDevArray[j1].nDevice;

				for (j2=0; j2<(int)m_CompArray[nSComp].sFCmDevArray.size(); j2++)
				{
					nCmCompS=m_CompArray[nSComp].sFCmDevArray[j2].nDevice;
					if (nCmCompF != nCmCompS)
						continue;

					for (j3=0; j3<(int)m_CompArray[nTComp].sFCmDevArray.size(); j3++)
					{
						nCmCompT=m_CompArray[nTComp].sFCmDevArray[j3].nDevice;
						if (nCmCompF != nCmCompT)
							continue;

						if (isInMCut01(nCmCompF))
							continue;

						memset(&sCmFCutBuf, 0, sizeof(tagCmMCutO1));

						sCmFCutBuf.nCutType = DNREnumCutType_Cut1_Cut3ThreeBreakerComm;
						sCmFCutBuf.fR=m_CompArray[nCmCompF].fRerr;
						sCmFCutBuf.fT=(m_CompArray[nCmCompF].fTFLoc <= m_CompArray[nCmCompF].fTrep || m_CompArray[nCmCompF].fTrep <= FLT_MIN) ? m_CompArray[nCmCompF].fTFLoc : m_CompArray[nCmCompF].fTrep;
						sCmFCutBuf.nBreaker[0]=nFComp;
						sCmFCutBuf.nBreaker[1]=nSComp;
						sCmFCutBuf.nBreaker[2]=nTComp;
						sCmFCutBuf.nComp=nCmCompF;
						if (sCmFCutBuf.fR > FLT_MIN && sCmFCutBuf.fT > FLT_MIN)
							m_CmMCutO1Array.push_back(sCmFCutBuf);
					}
				}
			}
		}
		if (m_CompArray[nFComp].bCmBreaker && m_CompArray[nSComp].bCmBreaker)
		{
			for (j1=0; j1<(int)m_CompArray[nFComp].sFCmDevArray.size(); j1++)
			{
				nCmCompF=m_CompArray[nFComp].sFCmDevArray[j1].nDevice;
				for (j2=0; j2<(int)m_CompArray[nSComp].sFCmDevArray.size(); j2++)
				{
					nCmCompS=m_CompArray[nSComp].sFCmDevArray[j2].nDevice;
					if (nCmCompF != nCmCompS)
						continue;

					if (isInMCut01(nCmCompF))
						continue;
					if (isInMCut02(nCmCompF, nTComp))
						continue;

					fR1=m_CompArray[nCmCompF].fRerr;
					fT1=(m_CompArray[nCmCompF].fTFLoc < m_CompArray[nCmCompF].fTrep || m_CompArray[nCmCompF].fTrep < FLT_MIN) ? m_CompArray[nCmCompF].fTFLoc : m_CompArray[nCmCompF].fTrep;
					fR2=m_CompArray[nTComp].fRerr;
					fT2=m_CompArray[nTComp].fTrep;

					memset(&sCmSCutBuf, 0, sizeof(tagCmMCutO2));
					sCmSCutBuf.nCutType = DNREnumCutType_Cut2_Cut3TwoBreakerComm;
					sCmSCutBuf.nBreaker[0]=nFComp;
					sCmSCutBuf.nBreaker[1]=nSComp;
					sCmSCutBuf.nBreaker[2]=-1;
					sCmSCutBuf.nComp[0]=nCmCompF;
					sCmSCutBuf.nComp[1]=nTComp;
					sCmSCutBuf.fR=fR1*fR2*(fT1+fT2)/8760;
					if (8760*sCmSCutBuf.fR > FLT_MIN)
						sCmSCutBuf.fT=(fR1*fR2*fT1*fT2)/(8760*sCmSCutBuf.fR);

					if (sCmSCutBuf.fR > FLT_MIN && sCmSCutBuf.fT > FLT_MIN)
						m_CmMCutO2Array.push_back(sCmSCutBuf);
				}
			}
		}
		if (m_CompArray[nFComp].bCmBreaker && m_CompArray[nTComp].bCmBreaker)
		{
			for (j1=0; j1<(int)m_CompArray[nFComp].sFCmDevArray.size(); j1++)
			{
				nCmCompF=m_CompArray[nFComp].sFCmDevArray[j1].nDevice;
				for (j2=0; j2<(int)m_CompArray[nTComp].sFCmDevArray.size(); j2++)
				{
					nCmCompT=m_CompArray[nTComp].sFCmDevArray[j2].nDevice;
					if (nCmCompF != nCmCompT)
						continue;

					if (isInMCut01(nCmCompF))
						continue;
					if (isInMCut02(nCmCompF, nSComp))
						continue;

					fR1=m_CompArray[nCmCompF].fRerr;
					fT1=(m_CompArray[nCmCompF].fTFLoc < m_CompArray[nCmCompF].fTrep || m_CompArray[nCmCompF].fTrep < FLT_MIN) ? m_CompArray[nCmCompF].fTFLoc : m_CompArray[nCmCompF].fTrep;
					fR2=m_CompArray[nSComp].fRerr;
					fT2=m_CompArray[nSComp].fTrep;

					memset(&sCmSCutBuf, 0, sizeof(tagCmMCutO2));
					sCmSCutBuf.nCutType = DNREnumCutType_Cut2_Cut3TwoBreakerComm;
					sCmSCutBuf.nBreaker[0]=nFComp;
					sCmSCutBuf.nBreaker[1]=nTComp;
					sCmSCutBuf.nBreaker[2]=-1;
					sCmSCutBuf.nComp[0]=nCmCompF;
					sCmSCutBuf.nComp[1]=nSComp;
					sCmSCutBuf.fR=fR1*fR2*(fT1+fT2)/8760;
					if (8760*sCmSCutBuf.fR > FLT_MIN)
						sCmSCutBuf.fT=(fR1*fR2*fT1*fT2)/(8760*sCmSCutBuf.fR);

					if (sCmSCutBuf.fR > FLT_MIN && sCmSCutBuf.fT > FLT_MIN)
						m_CmMCutO2Array.push_back(sCmSCutBuf);
				}
			}
		}
		if (m_CompArray[nSComp].bCmBreaker && m_CompArray[nTComp].bCmBreaker)
		{
			for (j1=0; j1<(int)m_CompArray[nSComp].sFCmDevArray.size(); j1++)
			{
				nCmCompS=m_CompArray[nSComp].sFCmDevArray[j1].nDevice;
				for (j2=0; j2<(int)m_CompArray[nTComp].sFCmDevArray.size(); j2++)
				{
					nCmCompT=m_CompArray[nTComp].sFCmDevArray[j2].nDevice;
					if (nCmCompS != nCmCompT)
						continue;

					if (isInMCut01(nCmCompS))
						continue;
					if (isInMCut02(nCmCompS, nFComp))
						continue;

					fR1=m_CompArray[nCmCompS].fRerr;
					fT1=(m_CompArray[nCmCompS].fTFLoc < m_CompArray[nCmCompS].fTrep || m_CompArray[nCmCompS].fTrep < FLT_MIN) ? m_CompArray[nCmCompS].fTFLoc : m_CompArray[nCmCompS].fTrep;
					fR2=m_CompArray[nFComp].fRerr;
					fT2=m_CompArray[nFComp].fTrep;

					memset(&sCmSCutBuf, 0, sizeof(tagCmMCutO2));
					sCmSCutBuf.nCutType = DNREnumCutType_Cut2_Cut3TwoBreakerComm;
					sCmSCutBuf.nBreaker[0]=nSComp;
					sCmSCutBuf.nBreaker[1]=nTComp;
					sCmSCutBuf.nBreaker[2]=-1;
					sCmSCutBuf.nComp[0]=nCmCompS;
					sCmSCutBuf.nComp[1]=nFComp;
					sCmSCutBuf.fR=fR1*fR2*(fT1+fT2)/8760;
					if (8760*sCmSCutBuf.fR > FLT_MIN)
						sCmSCutBuf.fT=(fR1*fR2*fT1*fT2)/(8760*sCmSCutBuf.fR);

					if (sCmSCutBuf.fR > FLT_MIN && sCmSCutBuf.fT > FLT_MIN)
						m_CmMCutO2Array.push_back(sCmSCutBuf);
				}
			}
		}
	}

#ifdef _DEBUG
	Log(g_lpszLogFile,  "--------------------------------------------------------------------------------\n");
	for (i=0; i<(int)m_CmMCutO1Array.size(); i++)
	{
		Log(g_lpszLogFile,  "    ��ģ�滻һ����С��[%d/%d]�� %s, %s, %s R=%f T=%f\n", i, m_CmMCutO1Array.size(),
			PGGetTableName(m_CompArray[m_CmMCutO1Array[i].nComp].nDevTyp), m_CompArray[m_CmMCutO1Array[i].nComp].strResID.c_str(), m_CompArray[m_CmMCutO1Array[i].nComp].strName.c_str(),
			m_CmMCutO1Array[i].fR, m_CmMCutO1Array[i].fT);
	}
	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
	{
		Log(g_lpszLogFile,  "    ��ģ�滻������С��[%d/%d]�� %s, %s, %s    %s, %s, %s R=%f T=%f\n", i, m_CmMCutO2Array.size(),
			PGGetTableName(m_CompArray[m_CmMCutO2Array[i].nComp[0]].nDevTyp), m_CompArray[m_CmMCutO2Array[i].nComp[0]].strResID.c_str(), m_CompArray[m_CmMCutO2Array[i].nComp[0]].strName.c_str(),
			PGGetTableName(m_CompArray[m_CmMCutO2Array[i].nComp[1]].nDevTyp), m_CompArray[m_CmMCutO2Array[i].nComp[1]].strResID.c_str(), m_CompArray[m_CmMCutO2Array[i].nComp[1]].strName.c_str(),
			m_CmMCutO2Array[i].fR, m_CmMCutO2Array[i].fT);
	}
	Log(g_lpszLogFile,  "--------------------------------------------------------------------------------\n");
#endif
}
