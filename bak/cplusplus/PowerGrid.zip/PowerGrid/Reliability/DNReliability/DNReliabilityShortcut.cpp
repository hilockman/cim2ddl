#include "stdafx.h"
#include "DNReliability.h"

//3.2�γ���С��
//3.2.1һ��
int CDNREstimate::Judge1Shortcut(const int nComp)
{
	register int	i;

	//��ά�����ĳһ��ȫΪ1, ��Ϊһ����С�����ĳ�豸����������·��
	for (i=0; i <(int)m_MinPathArray.size(); i++)
	{
		if (m_MinPathArray[i].nCompVector[nComp] == 0)	//	����һ�׸�ķ���
			return 0;
	}
	return 1;
}

//3.2.2����
int CDNREstimate::Judge2Shortcut(const int nComp1, const int nComp2)
{
	register int	i;
	//�����ĳһ��ȫΪ1, ��Ϊ������С���·���в�����nComp1��nComp2����nComp1��nComp2һ�����Ƕ��׸�
	for (i=0; i<(int)m_MinPathArray.size(); i++)
	{
		if ( (m_MinPathArray[i].nCompVector[nComp1] == 0 && m_MinPathArray[i].nCompVector[nComp2] == 0))	//	���Ƕ��׸�ķ���
			return 0;
	}
	return 1;
}

//3.2.3����
int CDNREstimate::Judge3Shortcut(const int nComp1, const int nComp2, const int nComp3)
{
	register int	i;

	for (i=0; i<(int)m_MinPathArray.size(); i++)
	{
		if ((m_MinPathArray[i].nCompVector[nComp1] == 0 && m_MinPathArray[i].nCompVector[nComp2] == 0 && m_MinPathArray[i].nCompVector[nComp3] == 0))	//	�������׸�ķ���
			return 0;
	}
	return 1;
}

//3.2.4�Ľ�
int CDNREstimate::Judge4Shortcut(const int nComp1, const int nComp2, const int nComp3, const int nComp4)
{
	register int	i;

	for (i=0; i<(int)m_MinPathArray.size(); i++)
	{
		if ((m_MinPathArray[i].nCompVector[nComp1] == 0 && m_MinPathArray[i].nCompVector[nComp2] == 0 && m_MinPathArray[i].nCompVector[nComp3] == 0 && m_MinPathArray[i].nCompVector[nComp4] == 0))	//	�����Ľ׸�ķ���
			return 0;
	}
	return 1;
}

void CDNREstimate::FormShortCutNormal(const unsigned char bCut4Switch)
{
	int		j1, j2, j3, j4;
	tagRMinCutO1	Cut1Buf;
	tagRMinCutO2	Cut2Buf;
	tagRMinCutO3	Cut3Buf;
	tagRMinCutO4	Cut4Buf;

	m_MCutO1Array.clear();
	m_MCutO2Array.clear();
	m_MCutO3Array.clear();
	m_MCutO4Array.clear();

	InitializeReliMCutO1(Cut1Buf);
	InitializeReliMCutO2(Cut2Buf);
	InitializeReliMCutO3(Cut3Buf);
	InitializeReliMCutO4(Cut4Buf);

	if (m_MinPathArray.empty())
		return;

	for (j1=0; j1<(int)m_CompArray.size(); j1++) //��һ��
	{
		if (!m_CompArray[j1].bInPath)
			continue;

		//	����Ҫ�����л�ʱ�乲ģ�����أ����Բ��ܽ�ͨ��fRerr��fTrep��fRchk��fTchk���о��γɸ
		if (!m_CompArray[j1].bCmBreaker && !isSwitchBreaker(j1) && (m_CompArray[j1].fRerr < FLT_MIN && m_CompArray[j1].fTrep < FLT_MIN) && (m_CompArray[j1].fRchk < FLT_MIN && m_CompArray[j1].fTchk < FLT_MIN))
			continue;

		if (Judge1Shortcut(j1))
		{
			if (!isInMCut01(j1))
			{
				//if ((m_CompArray[j1].fRerr > FLT_MIN && m_CompArray[j1].fTrep > FLT_MIN) || (m_CompArray[j1].fRchk > FLT_MIN && m_CompArray[j1].fTchk > FLT_MIN))
				{
					Cut1Buf.nComp=j1;
					m_MCutO1Array.push_back(Cut1Buf);
				}
			}
			continue;
		}
		if (m_MinPathArray.size() > 1)
		{
			for (j2=0; j2<j1; j2++) //�����
			{
				if (!m_CompArray[j2].bInPath)
					continue;
				if (!m_CompArray[j2].bCmBreaker && !isSwitchBreaker(j2) && (m_CompArray[j2].fRerr < FLT_MIN && m_CompArray[j2].fTrep < FLT_MIN) && (m_CompArray[j2].fRchk < FLT_MIN && m_CompArray[j2].fTchk < FLT_MIN))
					continue;
				if (isInMCut01(j2)) //�����ж�j2�Ƿ񹹳�һ�׸
					continue;

				if (Judge2Shortcut(j2, j1))
				{
					if (!isInMCut02(j1, j2))
					{
						//	����Ҫ�����л�ʱ�乲ģ�����أ����Բ���ͨ��fRerr��fTrep��fRchk��fTchk���о��γɸ
//  					if (((m_CompArray[j1].fRerr > FLT_MIN && m_CompArray[j1].fTrep > FLT_MIN) || (m_CompArray[j1].fRchk > FLT_MIN && m_CompArray[j1].fTchk > FLT_MIN)) ||
//  						((m_CompArray[j2].fRerr > FLT_MIN && m_CompArray[j2].fTrep > FLT_MIN) || (m_CompArray[j2].fRchk > FLT_MIN && m_CompArray[j2].fTchk > FLT_MIN)))
						{
							Cut2Buf.nComp[0]=j2;
							Cut2Buf.nComp[1]=j1;
							m_MCutO2Array.push_back(Cut2Buf);
						}
					}
					continue;
				}
				if (m_MinPathArray.size() > 2)
				{
					for (j3=0; j3<j2; j3++) //������
					{
						if (!m_CompArray[j3].bInPath)
							continue;
						if (!m_CompArray[j3].bCmBreaker &&!isSwitchBreaker(j3) && (m_CompArray[j3].fRerr < FLT_MIN && m_CompArray[j3].fTrep < FLT_MIN) && (m_CompArray[j3].fRchk < FLT_MIN && m_CompArray[j3].fTchk < FLT_MIN))
							continue;
						if (isInMCut01(j3)) //�����ж�j3�Ƿ񹹳�һ�׸
							continue;

						if (isInMCut02(j3, j1) || isInMCut02(j3, j2)) //ɸ������
							continue;

						if (Judge3Shortcut(j3, j2, j1))
						{
							if (!isInMCut03(j1, j2, j3))
							{
								//	����Ҫ�����л�ʱ�乲ģ�����أ����Բ���ͨ��fRerr��fTrep��fRchk��fTchk���о��γɸ
// 								if (((m_CompArray[j1].fRerr > FLT_MIN && m_CompArray[j1].fTrep > FLT_MIN) || (m_CompArray[j1].fRchk > FLT_MIN && m_CompArray[j1].fTchk > FLT_MIN)) ||
// 									((m_CompArray[j2].fRerr > FLT_MIN && m_CompArray[j2].fTrep > FLT_MIN) || (m_CompArray[j2].fRchk > FLT_MIN && m_CompArray[j2].fTchk > FLT_MIN)) ||
// 									((m_CompArray[j3].fRerr > FLT_MIN && m_CompArray[j3].fTrep > FLT_MIN) || (m_CompArray[j3].fRchk > FLT_MIN && m_CompArray[j3].fTchk > FLT_MIN)))
								{
									Cut3Buf.nComp[0]=j3;
									Cut3Buf.nComp[1]=j2;
									Cut3Buf.nComp[2]=j1;
									m_MCutO3Array.push_back(Cut3Buf);
								}
							}
							continue;
						}
						if (bCut4Switch && m_MinPathArray.size() > 3)
						{
							for (j4=0; j4<j3; j4++) //���Ľ�
							{
								if (!m_CompArray[j4].bInPath)
									continue;
								if (m_CompArray[j1].fRerr < FLT_MIN &&
									m_CompArray[j2].fRerr < FLT_MIN &&
									m_CompArray[j3].fRerr < FLT_MIN &&
									m_CompArray[j4].fRerr < FLT_MIN)
									continue;
								if (m_CompArray[j1].fTSwitch < FLT_MIN &&
									m_CompArray[j2].fTSwitch < FLT_MIN &&
									m_CompArray[j3].fTSwitch < FLT_MIN &&
									m_CompArray[j4].fTSwitch < FLT_MIN)
									continue;
								if (m_CompArray[j1].fRerr < FLT_MIN && m_CompArray[j2].fTSwitch < FLT_MIN && m_CompArray[j3].fTSwitch < FLT_MIN && m_CompArray[j4].fTSwitch < FLT_MIN)
									continue;
								if (m_CompArray[j2].fRerr < FLT_MIN && m_CompArray[j1].fTSwitch < FLT_MIN && m_CompArray[j3].fTSwitch < FLT_MIN && m_CompArray[j4].fTSwitch < FLT_MIN)
									continue;
								if (m_CompArray[j3].fRerr < FLT_MIN && m_CompArray[j1].fTSwitch < FLT_MIN && m_CompArray[j2].fTSwitch < FLT_MIN && m_CompArray[j4].fTSwitch < FLT_MIN)
									continue;
								if (m_CompArray[j4].fRerr < FLT_MIN && m_CompArray[j1].fTSwitch < FLT_MIN && m_CompArray[j2].fTSwitch < FLT_MIN && m_CompArray[j3].fTSwitch < FLT_MIN)
									continue;

								if (!isSwitchBreaker(j4) && (m_CompArray[j4].fRerr < FLT_MIN && m_CompArray[j4].fTrep < FLT_MIN))
									continue;
								if (isInMCut01(j4)) //�����ж�j4�Ƿ񹹳�һ�׸
									continue;

								if (isInMCut02(j4, j1) || isInMCut02(j4, j3) || isInMCut02(j4, j2)) //ɸ������
									continue;

								if (isInMCut03(j4, j3, j2) || isInMCut03(j4, j3, j1) || isInMCut03(j4, j2, j1)) //ɸ������
									continue;

								if (Judge4Shortcut(j4, j3, j2, j1))
								{
									if (!isInMCut04(j1, j2, j3, j4))
									{
										Cut4Buf.nComp[0]=j4;
										Cut4Buf.nComp[1]=j3;
										Cut4Buf.nComp[2]=j2;
										Cut4Buf.nComp[3]=j1;
										m_MCutO4Array.push_back(Cut4Buf);
									}
									continue;
								}
							}
						}
					}
				}
			}
		}
	}

#ifdef _DEBUG
	register int	i;
	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		j1=m_MCutO1Array[i].nComp;
		Log(g_lpszLogFile,  "          һ����С��[%d/%d]�� %s, %s, %s [%f %f]\n", i+1, m_MCutO1Array.size(), PGGetTableName(m_CompArray[j1].nDevTyp), m_CompArray[j1].strResID.c_str(), m_CompArray[j1].strName.c_str(),
					m_CompArray[j1].fRerr, m_CompArray[j1].fTrep);
	}
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		j1=m_MCutO2Array[i].nComp[0];
		j2=m_MCutO2Array[i].nComp[1];

		Log(g_lpszLogFile,  "          ������С��[%d/%d]�� %s, %s, %s    %s, %s, %s\n", i, m_MCutO2Array.size(),
			PGGetTableName(m_CompArray[j1].nDevTyp), m_CompArray[j1].strResID.c_str(), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nDevTyp), m_CompArray[j2].strResID.c_str(), m_CompArray[j2].strName.c_str());
	}
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		j1=m_MCutO3Array[i].nComp[0];
		j2=m_MCutO3Array[i].nComp[1];
		j3=m_MCutO3Array[i].nComp[2];

		Log(g_lpszLogFile,  "          ������С��[%d/%d]�� %s, %s, %s    %s, %s, %s    %s, %s, %s\n", i, m_MCutO3Array.size(),
			PGGetTableName(m_CompArray[j1].nDevTyp), m_CompArray[j1].strResID.c_str(), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nDevTyp), m_CompArray[j2].strResID.c_str(), m_CompArray[j2].strName.c_str(),
			PGGetTableName(m_CompArray[j3].nDevTyp), m_CompArray[j3].strResID.c_str(), m_CompArray[j3].strName.c_str());
	}
	for (i=0; i<(int)m_MCutO4Array.size(); i++)
	{
		j1=m_MCutO4Array[i].nComp[0];
		j2=m_MCutO4Array[i].nComp[1];
		j3=m_MCutO4Array[i].nComp[2];
		j4=m_MCutO4Array[i].nComp[3];

		Log(g_lpszLogFile,  "          �Ľ���С��[%d/%d]�� %s, %s, %s    %s, %s, %s    %s, %s, %s    %s, %s, %s\n", i, m_MCutO4Array.size(),
			PGGetTableName(m_CompArray[j1].nDevTyp), m_CompArray[j1].strResID.c_str(), m_CompArray[j1].strName.c_str(),
			PGGetTableName(m_CompArray[j2].nDevTyp), m_CompArray[j2].strResID.c_str(), m_CompArray[j2].strName.c_str(),
			PGGetTableName(m_CompArray[j3].nDevTyp), m_CompArray[j3].strResID.c_str(), m_CompArray[j3].strName.c_str(),
			PGGetTableName(m_CompArray[j4].nDevTyp), m_CompArray[j4].strResID.c_str(), m_CompArray[j4].strName.c_str());
	}

#endif
}
