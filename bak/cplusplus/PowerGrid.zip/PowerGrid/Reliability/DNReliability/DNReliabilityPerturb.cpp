#include "stdafx.h"
#include "DNReliability.h"

void CDNREstimate::PrevPerturb()
{
	int		nDev;
	m_CompBackArray.resize(m_CompArray.size());
	for (nDev=0; nDev<(int)m_CompArray.size(); nDev++)
	{
		m_CompBackArray[nDev].fRerr	=m_CompArray[nDev].fRerr	;
		m_CompBackArray[nDev].fTrep	=m_CompArray[nDev].fTrep	;
		m_CompBackArray[nDev].fRchk	=m_CompArray[nDev].fRchk	;
		m_CompBackArray[nDev].fTchk	=m_CompArray[nDev].fTchk	;
		m_CompBackArray[nDev].fRSwitch	=m_CompArray[nDev].fRSwitch	;
		m_CompBackArray[nDev].fTSwitch	=m_CompArray[nDev].fTSwitch	;
		m_CompBackArray[nDev].fTFLoc=m_CompArray[nDev].fTFLoc;
	}
}

void CDNREstimate::PerturbRestore()
{
	int		nComp;
	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
	{
		m_CompArray[nComp].fRerr	=m_CompBackArray[nComp].fRerr	;
		m_CompArray[nComp].fTrep	=m_CompBackArray[nComp].fTrep	;
		m_CompArray[nComp].fRchk	=m_CompBackArray[nComp].fRchk	;
		m_CompArray[nComp].fTchk	=m_CompBackArray[nComp].fTchk	;
		m_CompArray[nComp].fRSwitch	=m_CompBackArray[nComp].fRSwitch	;
		m_CompArray[nComp].fTSwitch	=m_CompBackArray[nComp].fTSwitch	;
		m_CompArray[nComp].fTFLoc	=m_CompBackArray[nComp].fTFLoc;
	}
}

void CDNREstimate::PerturbAmend(const int nPerturb)
{
	int	nComp;
	for (nComp=0; nComp<(int)m_CompArray.size(); nComp++)
	{
		m_CompArray[nComp].fTFLoc=m_CompArray[nComp].fTFLoc*(1+nPerturb*m_RPerturbParam.fTFLocPerturb);					//	�����ʣ���/�꣩
		m_CompArray[nComp].fRSwitch=m_CompArray[nComp].fRSwitch*(1+nPerturb*m_RPerturbParam.fRSwitchPerturb);			//	�����ʣ���/�꣩
		m_CompArray[nComp].fTSwitch=m_CompArray[nComp].fTSwitch*(1+nPerturb*m_RPerturbParam.fTSwitchPerturb);			//	�����ʣ���/�꣩

		switch (m_CompArray[nComp].nDevTyp)
		{
		case PG_BUSBARSECTION:
			if (m_CompArray[nComp].nAugmentation == 0 || m_CompArray[nComp].nAugmentation == PG_SUBSTATIONENTITY)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fBusbarRerrPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fBusbarTrepPerturb);		//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fBusbarRchkPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fBusbarTchkPerturb);		//	����ʱ�䣨Сʱ��
			}
			else if (m_CompArray[nComp].nAugmentation == PG_DISTRIBUTIONLOAD)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fDistributionLoadRerrPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fDistributionLoadTrepPerturb);		//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fDistributionLoadRchkPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fDistributionLoadTchkPerturb);		//	����ʱ�䣨Сʱ��
			}
			else if (m_CompArray[nComp].nAugmentation == PG_DISTRIBUTIONSWITCH)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fDistributionSwitchRerrPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fDistributionSwitchTrepPerturb);		//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fDistributionSwitchRchkPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fDistributionSwitchTchkPerturb);		//	����ʱ�䣨Сʱ��
			}
			break;
		case PG_ACLINESEGMENT:
			if (m_CompArray[nComp].nAugmentation == PGEnumLine_LineType_Overhead)	//	�ܿ�
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fLineRerrPerturb);				//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fLineTrepPerturb);				//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fLineRchkPerturb);				//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fLineTchkPerturb);				//	����ʱ�䣨Сʱ��
			}
			else
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fCableRerrPerturb);				//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fCableTrepPerturb);				//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fCableRchkPerturb);				//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fCableTchkPerturb);				//	����ʱ�䣨Сʱ��
			}
			break;
		case PG_TRANSFORMERWINDING:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fTransformerRerrPerturb);			//	�����ʣ���/�꣩
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fTransformerTrepPerturb);			//	�޸�ʱ�䣨Сʱ��
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fTransformerRchkPerturb);			//	�����ʣ���/�꣩
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fTransformerTchkPerturb);			//	����ʱ�䣨Сʱ��
			break;
		case PG_SERIESCOMPENSATOR:
			m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fSeriesCompensatorRerrPerturb);		//	�����ʣ���/�꣩
			m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fSeriesCompensatorTrepPerturb);		//	�޸�ʱ�䣨Сʱ��
			m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fSeriesCompensatorRchkPerturb);		//	�����ʣ���/�꣩
			m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fSeriesCompensatorTchkPerturb);		//	����ʱ�䣨Сʱ��
			break;
		case PG_BREAKER:
			if (m_CompArray[nComp].nBreakerType == PGEnumBreakerType_Breaker || m_CompArray[nComp].nBreakerType == PGEnumBreakerType_BuslinkBreaker)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fBreakerRerrPerturb);			//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fBreakerTrepPerturb);			//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fBreakerRchkPerturb);			//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fBreakerTchkPerturb);			//	����ʱ�䣨Сʱ��
			}
			else if (m_CompArray[nComp].nBreakerType == PGEnumBreakerType_HandCartBreaker)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fHandCartBreakerRerrPerturb);	//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fHandCartBreakerTrepPerturb);	//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fHandCartBreakerRchkPerturb);	//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fHandCartBreakerTchkPerturb);	//	����ʱ�䣨Сʱ��
			}
			else if (m_CompArray[nComp].nBreakerType == PGEnumBreakerType_FuseBreaker)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fFuseBreakerRerrPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fFuseBreakerTrepPerturb);		//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fFuseBreakerRchkPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fFuseBreakerTchkPerturb);		//	����ʱ�䣨Сʱ��
			}
			else if (m_CompArray[nComp].nBreakerType == PGEnumBreakerType_LoadBreakSwitch)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fLoadBreakSwitchRerrPerturb);	//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fLoadBreakSwitchTrepPerturb);	//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fLoadBreakSwitchRchkPerturb);	//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fLoadBreakSwitchTchkPerturb);	//	����ʱ�䣨Сʱ��
			}
			else  if (m_CompArray[nComp].nBreakerType != PGEnumBreakerType_Disconnector)
			{
				m_CompArray[nComp].fRerr=m_CompBackArray[nComp].fRerr*(1+nPerturb*m_RPerturbParam.fDisconnectorRerrPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTrep=m_CompBackArray[nComp].fTrep*(1+nPerturb*m_RPerturbParam.fDisconnectorTrepPerturb);		//	�޸�ʱ�䣨Сʱ��
				m_CompArray[nComp].fRchk=m_CompBackArray[nComp].fRchk*(1+nPerturb*m_RPerturbParam.fDisconnectorRchkPerturb);		//	�����ʣ���/�꣩
				m_CompArray[nComp].fTchk=m_CompBackArray[nComp].fTchk*(1+nPerturb*m_RPerturbParam.fDisconnectorTchkPerturb);		//	����ʱ�䣨Сʱ��
			}
			break;
		}
	}
}
