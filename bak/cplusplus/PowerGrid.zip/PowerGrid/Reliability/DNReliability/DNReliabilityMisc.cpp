#include "stdafx.h"
#include "DNReliability.h"

void CDNREstimate::InitializeReliMCutO1(tagRMinCutO1& sMCut)
{
	sMCut.nCutType = DNREnumCutType_Normal;
	sMCut.nComp=0;
	sMCut.fR=0;
	sMCut.fT=0;
	sMCut.fFaultR=0;
	sMCut.fFaultT=0;
	sMCut.fArrangeR=0;
	sMCut.fArrangeT=0;
	sMCut.sMinSparePathArray.clear();

	sMCut.fU=0;
	sMCut.fRContribution=0;
	sMCut.fUContribution=0;
}

void CDNREstimate::InitializeReliMCutO2(tagRMinCutO2& sMCut)
{
	sMCut.nCutType = DNREnumCutType_Normal;
	sMCut.nComp[0]=0;
	sMCut.nComp[1]=0;
	sMCut.fR=0;
	sMCut.fT=0;
	sMCut.fFaultR=0;
	sMCut.fFaultT=0;
	sMCut.fArrangeR=0;
	sMCut.fArrangeT=0;

	sMCut.fSwitchR=0;
	sMCut.fSwitchT=0;

// 	sMCut.fDegreeR=0;
// 	sMCut.fDegreeT=0;
	sMCut.bDegreed=0;
	sMCut.nDegreeFComp=-1;	//	���׹����豸

	sMCut.sMinSparePathArray.clear();

	sMCut.fSpareLoad=0;
	sMCut.fSpareProb=0;

	sMCut.fU=0;
	sMCut.fRContribution=0;
	sMCut.fUContribution=0;
}

void CDNREstimate::InitializeReliMCutO3(tagRMinCutO3& sMCut)
{
	sMCut.nCutType = DNREnumCutType_Normal;
	sMCut.nComp[0]=0;
	sMCut.nComp[1]=0;
	sMCut.nComp[2]=0;
	sMCut.fR=0;
	sMCut.fT=0;
	sMCut.fFaultR=0;
	sMCut.fFaultT=0;
	sMCut.fArrangeR=0;
	sMCut.fArrangeT=0;

	sMCut.fSwitchR=0;
	sMCut.fSwitchT=0;

// 	sMCut.fDegreeR=0;
// 	sMCut.fDegreeT=0;
	sMCut.nDegreeFComp[0]=-1;
	sMCut.nDegreeFComp[1]=-1;
	sMCut.bDegreed=0;

	sMCut.sMinSparePathArray.clear();
	sMCut.fSpareLoad=0;
	sMCut.fSpareProb=0;

	sMCut.fU=0;
	sMCut.fRContribution=0;
	sMCut.fUContribution=0;
}

void CDNREstimate::InitializeReliMCutO4(tagRMinCutO4& sMCut)
{
	sMCut.nCutType = DNREnumCutType_Normal;
	sMCut.nComp[0]=0;
	sMCut.nComp[1]=0;
	sMCut.nComp[2]=0;
	sMCut.nComp[3]=0;

	sMCut.fSwitchR=0;
	sMCut.fSwitchT=0;
}

void CDNREstimate::MCutContribution2Load(const int nLoad)
{
	register int	i;

	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		m_MCutO1Array[i].fRContribution	=		m_MCutO1Array[i].fUContribution=0;
		m_MCutO1Array[i].fU				=		m_MCutO1Array[i].fR*m_MCutO1Array[i].fT;
		if (m_LoadArray[nLoad].fR > FLT_MIN)	m_MCutO1Array[i].fRContribution		=	m_MCutO1Array[i].fR/m_LoadArray[nLoad].fR*100.0;
		if (m_LoadArray[nLoad].fU > FLT_MIN)	m_MCutO1Array[i].fUContribution		=	m_MCutO1Array[i].fU/m_LoadArray[nLoad].fU*100.0;
	}
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		m_MCutO2Array[i].fRContribution	=		m_MCutO2Array[i].fUContribution=0;
		m_MCutO2Array[i].fU				=		m_MCutO2Array[i].fR*m_MCutO2Array[i].fT;
		if (m_LoadArray[nLoad].fR > FLT_MIN)	m_MCutO2Array[i].fRContribution		=	m_MCutO2Array[i].fR/m_LoadArray[nLoad].fR*100.0;
		if (m_LoadArray[nLoad].fU > FLT_MIN)	m_MCutO2Array[i].fUContribution		=	m_MCutO2Array[i].fU/m_LoadArray[nLoad].fU*100.0;
	}
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		m_MCutO3Array[i].fRContribution	=		m_MCutO3Array[i].fUContribution=0;
		m_MCutO3Array[i].fU				=		m_MCutO3Array[i].fR*m_MCutO3Array[i].fT;
		if (m_LoadArray[nLoad].fR > FLT_MIN)	m_MCutO3Array[i].fRContribution		=	m_MCutO3Array[i].fR/m_LoadArray[nLoad].fR*100.0;
		if (m_LoadArray[nLoad].fU > FLT_MIN)	m_MCutO3Array[i].fUContribution		=	m_MCutO3Array[i].fU/m_LoadArray[nLoad].fU*100.0;
	}

	for (i=0; i<(int)m_CmMCutO1Array.size(); i++)
	{
		m_CmMCutO1Array[i].fRContribution	=	m_CmMCutO1Array[i].fUContribution=0;
		m_CmMCutO1Array[i].fU				=	m_CmMCutO1Array[i].fR*m_CmMCutO1Array[i].fT;
		if (m_LoadArray[nLoad].fR > FLT_MIN)	m_CmMCutO1Array[i].fRContribution	=	m_CmMCutO1Array[i].fR/m_LoadArray[nLoad].fR*100.0;
		if (m_LoadArray[nLoad].fU > FLT_MIN)	m_CmMCutO1Array[i].fUContribution	=	m_CmMCutO1Array[i].fU/m_LoadArray[nLoad].fU*100.0;
	}

	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
	{
		m_CmMCutO2Array[i].fRContribution	=	m_CmMCutO2Array[i].fUContribution=0;
		m_CmMCutO2Array[i].fU				=	m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT;
		if (m_LoadArray[nLoad].fR > FLT_MIN)	m_CmMCutO2Array[i].fRContribution	=	m_CmMCutO2Array[i].fR/m_LoadArray[nLoad].fR*100.0;
		if (m_LoadArray[nLoad].fU > FLT_MIN)	m_CmMCutO2Array[i].fUContribution	=	m_CmMCutO2Array[i].fU/m_LoadArray[nLoad].fU*100.0;
	}
}

void CDNREstimate::CompContribution2MCut(const int nLoad)
{
	register int	i;

	int		nFComp, nSComp, nTComp;
	double	fRatio, fTotalR, fTotalU;

	for (i=0; i<(int)m_CompArray.size(); i++)
	{
		m_CompArray[i].fRContribution=0;
		m_CompArray[i].fUContribution=0;
		m_CompArray[i].fENSContribution=0;
	}

	fTotalR=fTotalU=0;
	for (i=0;i<(int)m_MCutO2Array.size();i++)
	{
		nFComp=m_MCutO2Array[i].nComp[0];
		nSComp=m_MCutO2Array[i].nComp[1];

		fTotalR += m_CompArray[nFComp].fRerr+m_CompArray[nSComp].fRerr;
		fTotalU += m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ�����׸�
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	fTotalR=fTotalU=0;
	for (i=0;i<(int)m_MCutO3Array.size();i++)
	{
		nFComp=m_MCutO3Array[i].nComp[0];
		nSComp=m_MCutO3Array[i].nComp[1];
		nTComp=m_MCutO3Array[i].nComp[2];

		fTotalR += m_CompArray[nFComp].fRerr;
		fTotalR += m_CompArray[nSComp].fRerr;
		fTotalR += m_CompArray[nTComp].fRerr;

		fTotalU += m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
		fTotalU += m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep;
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ������׸�
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
 	{
		nFComp=m_CmMCutO2Array[i].nComp[0];
		nSComp=m_CmMCutO2Array[i].nComp[1];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nSComp].fRerr;
		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;

		if (fTotalR > FLT_MIN)
		{
			fRatio=m_CompArray[nFComp].fRerr/fTotalR;
			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR*fRatio;

			fRatio=m_CompArray[nSComp].fRerr/fTotalR;
			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR/2;
			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR/2;
		}
		if (fTotalU > FLT_MIN)
		{
			fRatio=m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep/fTotalU;
			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT*fRatio;
			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT*fRatio;

			fRatio=m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep/fTotalU;
			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT*fRatio;
			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT/2;
			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT/2;

			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT/2;
			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_CmMCutO2Array[i].fR*m_CmMCutO2Array[i].fT/2;
		}
 	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ��㹲ģ
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	for (i=0;i<(int)m_MCutO2Array.size();i++)
	{
		nFComp=m_MCutO2Array[i].nComp[0];
		nSComp=m_MCutO2Array[i].nComp[1];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nSComp].fRerr;
		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;;
// 		if (fTotalR > FLT_MIN)
// 		{
// 			fRatio=m_CompArray[nFComp].fRerr/fTotalR;
// 			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR*fRatio;
// 
// 			fRatio=m_CompArray[nSComp].fRerr/fTotalR;
// 			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR*fRatio;
// 		}
// 		else
// 		{
// 			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR/2;
// 			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR/2;
// 		}
// 		if (fTotalU > FLT_MIN)
// 		{
// 			fRatio=m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep/fTotalU;
// 			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT*fRatio;
// 			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT*fRatio;
// 
// 			fRatio=m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep/fTotalU;
// 			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT*fRatio;
// 			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT*fRatio;
// 		}
// 		else
// 		{
// 			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT/2;
// 			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT/2;
// 
// 			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT/2;
// 			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fDegreeR*m_MCutO2Array[i].fDegreeT/2;
// 		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ�����׸��
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		nFComp=m_MCutO3Array[i].nComp[0];
		nSComp=m_MCutO3Array[i].nComp[1];
		nTComp=m_MCutO3Array[i].nComp[2];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nSComp].fRerr+m_CompArray[nTComp].fRerr;
		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
		fTotalU += m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep;
// 		if (fTotalR > FLT_MIN)
// 		{
// 			fRatio=m_CompArray[nFComp].fRerr/fTotalR;
// 			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*fRatio;
// 
// 			fRatio=m_CompArray[nSComp].fRerr/fTotalR;
// 			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*fRatio;
// 
// 			fRatio=m_CompArray[nTComp].fRerr/fTotalR;
// 			m_CompArray[nTComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*fRatio;
// 		}
// 		else
// 		{
// 			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR/3;
// 			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR/3;
// 			m_CompArray[nTComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR/3;
// 		}
// 		if (fTotalU > FLT_MIN)
// 		{
// 			fRatio=m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep/fTotalU;
// 			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT*fRatio;
// 			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT*fRatio;
// 
// 			fRatio=m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep/fTotalU;
// 			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT*fRatio;
// 			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT*fRatio;
// 
// 			fRatio=m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep/fTotalU;
// 			m_CompArray[nTComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT*fRatio;
// 			m_CompArray[nTComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT*fRatio;
// 		}
// 		else
// 		{
// 			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT/3;
// 			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT/3;
// 
// 			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT/3;
// 			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT/3;
// 
// 			m_CompArray[nTComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT/3;
// 			m_CompArray[nTComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fDegreeR*m_MCutO3Array[i].fDegreeT/3;
// 		}
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//	���ϼ������׸��
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		nFComp=m_MCutO1Array[i].nComp;
		m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO1Array[i].fR;
		m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO1Array[i].fR*m_MCutO1Array[i].fT;
		m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO1Array[i].fR*m_MCutO1Array[i].fT;
	}

	for (i=0;i<(int)m_MCutO2Array.size();i++)
	{
		nFComp=m_MCutO2Array[i].nComp[0];
		nSComp=m_MCutO2Array[i].nComp[1];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk;
		fTotalR += m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk;

		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
		fTotalU += m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk;
		fTotalU += m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk;;

		if (fTotalR > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk)/fTotalR;
			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk)/fTotalR;
			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR/2;
			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR/2;
		}
		if (fTotalU > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk)/fTotalU;
			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT*fRatio;
			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep+m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk)/fTotalU;
			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT*fRatio;
			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT/2;
			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT/2;

			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT/2;
			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO2Array[i].fR*m_MCutO2Array[i].fT/2;
		}
	}

	for (i=0;i<(int)m_MCutO3Array.size();i++)
	{
		nFComp=m_MCutO3Array[i].nComp[0];
		nSComp=m_MCutO3Array[i].nComp[1];
		nTComp=m_MCutO3Array[i].nComp[2];

		fTotalR = m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk;
		fTotalR += m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk;
		fTotalR += m_CompArray[nTComp].fRerr+m_CompArray[nTComp].fRchk;

		fTotalU = m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep;
		fTotalU += m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk;
		fTotalU += m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep;
		fTotalU += m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk;
		fTotalU += m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep;
		fTotalU += m_CompArray[nTComp].fRchk*m_CompArray[nTComp].fTchk;
		if (fTotalR > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr+m_CompArray[nFComp].fRchk)/fTotalR;
			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr+m_CompArray[nSComp].fRchk)/fTotalR;
			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*fRatio;

			fRatio=(m_CompArray[nTComp].fRerr+m_CompArray[nTComp].fRchk)/fTotalR;
			m_CompArray[nTComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR/3;
			m_CompArray[nSComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR/3;
			m_CompArray[nTComp].fRContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR/3;
		}
		if (fTotalU > FLT_MIN)
		{
			fRatio=(m_CompArray[nFComp].fRerr*m_CompArray[nFComp].fTrep+m_CompArray[nFComp].fRchk*m_CompArray[nFComp].fTchk)/fTotalU;
			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT*fRatio;
			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT*fRatio;

			fRatio=(m_CompArray[nSComp].fRerr*m_CompArray[nSComp].fTrep+m_CompArray[nSComp].fRchk*m_CompArray[nSComp].fTchk)/fTotalU;
			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT*fRatio;
			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT*fRatio;

			fRatio=(m_CompArray[nTComp].fRerr*m_CompArray[nTComp].fTrep+m_CompArray[nTComp].fRchk*m_CompArray[nTComp].fTchk)/fTotalU;
			m_CompArray[nTComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT*fRatio;
			m_CompArray[nTComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT*fRatio;
		}
		else
		{
			m_CompArray[nFComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT/3;
			m_CompArray[nFComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT/3;

			m_CompArray[nSComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT/3;
			m_CompArray[nSComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT/3;

			m_CompArray[nTComp].fUContribution += m_LoadArray[nLoad].fCustomer*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT/3;
			m_CompArray[nTComp].fENSContribution += m_LoadArray[nLoad].fP*m_MCutO3Array[i].fR*m_MCutO3Array[i].fT/3;
		}
	}

// 	for (i=0; i<(int)m_CompArray.size(); i++)
// 	{
// 		switch (m_CompArray[i].nType)
// 		{
// 		case	PG_ACLINESEGMENT:
// 			pPGBlock->m_ACLineSegmentArray[m_CompArray[i].nDevIndex].ro_RContribution += (float)fCompRContribArray[i]		;
// 			pPGBlock->m_ACLineSegmentArray[m_CompArray[i].nDevIndex].ro_UContribution += (float)fCompUContribArray[i]		;
// 			pPGBlock->m_ACLineSegmentArray[m_CompArray[i].nDevIndex].ro_ENSContribution += (float)fCompENSContribArray[i]	;
// 			break;
// 		case	PG_TRANSFORMERWINDING:
// 			pPGBlock->m_TransformerWindingArray[m_CompArray[i].nDevIndex].ro_RContribution += (float)fCompRContribArray[i]		;
// 			pPGBlock->m_TransformerWindingArray[m_CompArray[i].nDevIndex].ro_UContribution += (float)fCompUContribArray[i]		;
// 			pPGBlock->m_TransformerWindingArray[m_CompArray[i].nDevIndex].ro_ENSContribution += (float)fCompENSContribArray[i]	;
// 			break;
// 		case	PG_BREAKER:
// 			pPGBlock->m_BreakerArray[m_CompArray[i].nDevIndex].ro_RContribution += (float)fCompRContribArray[i]	;
// 			pPGBlock->m_BreakerArray[m_CompArray[i].nDevIndex].ro_UContribution += (float)fCompUContribArray[i]	;
// 			pPGBlock->m_BreakerArray[m_CompArray[i].nDevIndex].ro_ENSContribution += (float)fCompENSContribArray[i];
// 			break;
// 		case	PG_BUSBARSECTION:
// 			pPGBlock->m_BusbarSectionArray[m_CompArray[i].nDevIndex].ro_RContribution += (float)fCompRContribArray[i]		;
// 			pPGBlock->m_BusbarSectionArray[m_CompArray[i].nDevIndex].ro_UContribution += (float)fCompUContribArray[i]		;
// 			pPGBlock->m_BusbarSectionArray[m_CompArray[i].nDevIndex].ro_ENSContribution += (float)fCompENSContribArray[i]	;
// 			break;
// 		case	PG_SYNCHRONOUSMACHINE:
// 			pPGBlock->m_SynchronousMachineArray[m_CompArray[i].nDevIndex].ro_RContribution += (float)fCompRContribArray[i]		;
// 			pPGBlock->m_SynchronousMachineArray[m_CompArray[i].nDevIndex].ro_UContribution += (float)fCompUContribArray[i]		;
// 			pPGBlock->m_SynchronousMachineArray[m_CompArray[i].nDevIndex].ro_ENSContribution += (float)fCompENSContribArray[i]	;
// 			break;
// 		}
// 	}
}