#include "stdafx.h"
#include <io.h>
#include "DNRNetData.h"
#include "../../../Common/TinyXML/tinyxml.h"
#include "../../../Common/SemaphoreCommon.h"

void	CDNRNetData::OutData_SysCalc(tagPGBlock* pPGBlock, const char* lpszRResultFile)
{
	int		nContainer, nSub, nVolt, nDev;
	double	fFaltNum, fFFaltNum, fAFaltNum;

	//////////////////////////////////////////////////////////////////////////
	//	ȫ��
	//////////////////////////////////////////////////////////////////////////
	fFaltNum=fFFaltNum=fAFaltNum=0;
	for (nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	{
		if (m_RData.m_CompArray[nDev].nDevTyp != PG_ACLINESEGMENT)
			continue;

		fFFaltNum += m_RData.m_CompArray[nDev].fRerr;
		fAFaltNum += m_RData.m_CompArray[nDev].fRchk;
	}
	fFaltNum = fFFaltNum+fAFaltNum;

	//////////////////////////////////////////////////////////////////////////
	//	ϵͳ��
	pPGBlock->m_System.ro_customernum=0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		pPGBlock->m_System.ro_customernum += pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer;

		pPGBlock->m_System.ro_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_r);
		pPGBlock->m_System.ro_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_u);
		pPGBlock->m_System.ro_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_u);

		pPGBlock->m_System.ro_f_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_fr);
		pPGBlock->m_System.ro_f_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_fu);
		pPGBlock->m_System.ro_f_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_fu);

		pPGBlock->m_System.ro_a_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_ar);
		pPGBlock->m_System.ro_a_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_au);
		pPGBlock->m_System.ro_a_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_au);
	}
	if (pPGBlock->m_System.ro_customernum > FLT_MIN)
	{
		pPGBlock->m_System.ro_saifi = (float)(pPGBlock->m_System.ro_aci/pPGBlock->m_System.ro_customernum);
		pPGBlock->m_System.ro_saidi = (float)(pPGBlock->m_System.ro_cid/pPGBlock->m_System.ro_customernum);
		pPGBlock->m_System.ro_asai = (float)(1.0-pPGBlock->m_System.ro_saidi/8760);
		pPGBlock->m_System.ro_aens = (float)(pPGBlock->m_System.ro_ens/pPGBlock->m_System.ro_customernum);

		if (pPGBlock->m_System.ro_saifi > FLT_MIN)
			pPGBlock->m_System.ro_mid = (float)(pPGBlock->m_System.ro_saidi/pPGBlock->m_System.ro_saifi);
		if (fFaltNum > FLT_MIN)
			pPGBlock->m_System.ro_mic = (float)(pPGBlock->m_System.ro_aci/fFaltNum);

		pPGBlock->m_System.ro_f_saifi = (float)(pPGBlock->m_System.ro_f_aci/pPGBlock->m_System.ro_customernum);
		pPGBlock->m_System.ro_f_saidi = (float)(pPGBlock->m_System.ro_f_cid/pPGBlock->m_System.ro_customernum);
		pPGBlock->m_System.ro_f_asai = (float)(1.0-pPGBlock->m_System.ro_f_saidi/8760.0);
		pPGBlock->m_System.ro_f_aens = (float)(pPGBlock->m_System.ro_f_ens/pPGBlock->m_System.ro_customernum);

		if (pPGBlock->m_System.ro_f_saifi > FLT_MIN)
			pPGBlock->m_System.ro_f_mid = (float)(pPGBlock->m_System.ro_f_saidi/pPGBlock->m_System.ro_f_saifi);
		if (fFFaltNum > FLT_MIN)
			pPGBlock->m_System.ro_f_mic = (float)(pPGBlock->m_System.ro_f_aci/fFFaltNum);

		pPGBlock->m_System.ro_a_saifi = (float)(pPGBlock->m_System.ro_a_aci/pPGBlock->m_System.ro_customernum);
		pPGBlock->m_System.ro_a_saidi = (float)(pPGBlock->m_System.ro_a_cid/pPGBlock->m_System.ro_customernum);
		pPGBlock->m_System.ro_a_asai = (float)(1.0-pPGBlock->m_System.ro_a_saidi/8760.0);
		pPGBlock->m_System.ro_a_aens = (float)(pPGBlock->m_System.ro_a_ens/pPGBlock->m_System.ro_customernum);

		if (pPGBlock->m_System.ro_a_saifi > FLT_MIN)
			pPGBlock->m_System.ro_a_mid = (float)(pPGBlock->m_System.ro_a_saidi/pPGBlock->m_System.ro_a_saifi);
		if (fAFaltNum > FLT_MIN)
			pPGBlock->m_System.ro_a_mic = (float)(pPGBlock->m_System.ro_a_aci/fAFaltNum);
	}

	//////////////////////////////////////////////////////////////////////////
	//	��˾��
	for (nContainer=0; nContainer<pPGBlock->m_nRecordNum[PG_COMPANY]; nContainer++)
	{
		fFaltNum=fFFaltNum=fAFaltNum=0;
		for (nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
		{
			if (m_RData.m_CompArray[nDev].nDevTyp != PG_ACLINESEGMENT)
				continue;

			if (m_RData.m_CompArray[nDev].nIniSub < 0 || m_RData.m_CompArray[nDev].nEndSub < 0)
				continue;

			if (strcmp(pPGBlock->m_SubstationArray[m_RData.m_CompArray[nDev].nIniSub].szCompany, pPGBlock->m_CompanyArray[nContainer].szName) == 0)
			{
				fFFaltNum += m_RData.m_CompArray[nDev].fRerr/2;
				fAFaltNum += m_RData.m_CompArray[nDev].fRchk/2;
			}
			if (strcmp(pPGBlock->m_SubstationArray[m_RData.m_CompArray[nDev].nEndSub].szCompany, pPGBlock->m_CompanyArray[nContainer].szName) == 0)
			{
				fFFaltNum += m_RData.m_CompArray[nDev].fRerr/2;
				fAFaltNum += m_RData.m_CompArray[nDev].fRchk/2;
			}
		}
		fFaltNum = fFFaltNum+fAFaltNum;

		pPGBlock->m_CompanyArray[nContainer].ro_customernum=0;
		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[nSub].szCompany, pPGBlock->m_CompanyArray[nContainer].szName) != 0)
				continue;
			for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
				{
					pPGBlock->m_CompanyArray[nContainer].ro_customernum += pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer;

					pPGBlock->m_CompanyArray[nContainer].ro_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_r);
					pPGBlock->m_CompanyArray[nContainer].ro_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_u);
					pPGBlock->m_CompanyArray[nContainer].ro_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_u);

					pPGBlock->m_CompanyArray[nContainer].ro_f_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_fr);
					pPGBlock->m_CompanyArray[nContainer].ro_f_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_fu);
					pPGBlock->m_CompanyArray[nContainer].ro_f_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_fu);

					pPGBlock->m_CompanyArray[nContainer].ro_a_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_ar);
					pPGBlock->m_CompanyArray[nContainer].ro_a_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_au);
					pPGBlock->m_CompanyArray[nContainer].ro_a_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_au);
				}
			}
		}
		if (pPGBlock->m_CompanyArray[nContainer].ro_customernum > FLT_MIN)
		{
			pPGBlock->m_CompanyArray[nContainer].ro_saifi = (float)(pPGBlock->m_CompanyArray[nContainer].ro_aci/pPGBlock->m_CompanyArray[nContainer].ro_customernum);
			pPGBlock->m_CompanyArray[nContainer].ro_saidi = (float)(pPGBlock->m_CompanyArray[nContainer].ro_cid/pPGBlock->m_CompanyArray[nContainer].ro_customernum);
			pPGBlock->m_CompanyArray[nContainer].ro_asai = (float)(1.0-pPGBlock->m_CompanyArray[nContainer].ro_saidi/8760);
			pPGBlock->m_CompanyArray[nContainer].ro_aens = (float)(pPGBlock->m_CompanyArray[nContainer].ro_ens/pPGBlock->m_CompanyArray[nContainer].ro_customernum);

			if (pPGBlock->m_CompanyArray[nContainer].ro_saifi > FLT_MIN)
				pPGBlock->m_CompanyArray[nContainer].ro_mid = (float)(pPGBlock->m_CompanyArray[nContainer].ro_saidi/pPGBlock->m_CompanyArray[nContainer].ro_saifi);
			if (fFaltNum > FLT_MIN)
				pPGBlock->m_CompanyArray[nContainer].ro_mic = (float)(pPGBlock->m_CompanyArray[nContainer].ro_aci/fFaltNum);

			pPGBlock->m_CompanyArray[nContainer].ro_f_saifi = (float)(pPGBlock->m_CompanyArray[nContainer].ro_f_aci/pPGBlock->m_CompanyArray[nContainer].ro_customernum);
			pPGBlock->m_CompanyArray[nContainer].ro_f_saidi = (float)(pPGBlock->m_CompanyArray[nContainer].ro_f_cid/pPGBlock->m_CompanyArray[nContainer].ro_customernum);
			pPGBlock->m_CompanyArray[nContainer].ro_f_asai = (float)(1.0-pPGBlock->m_CompanyArray[nContainer].ro_f_saidi/8760.0);
			pPGBlock->m_CompanyArray[nContainer].ro_f_aens = (float)(pPGBlock->m_CompanyArray[nContainer].ro_f_ens/pPGBlock->m_CompanyArray[nContainer].ro_customernum);

			if (pPGBlock->m_CompanyArray[nContainer].ro_f_saifi > FLT_MIN)
				pPGBlock->m_CompanyArray[nContainer].ro_f_mid = (float)(pPGBlock->m_CompanyArray[nContainer].ro_f_saidi/pPGBlock->m_CompanyArray[nContainer].ro_f_saifi);
			if (fFFaltNum > FLT_MIN)
				pPGBlock->m_CompanyArray[nContainer].ro_f_mic = (float)(pPGBlock->m_CompanyArray[nContainer].ro_f_aci/fFFaltNum);

			pPGBlock->m_CompanyArray[nContainer].ro_a_saifi = (float)(pPGBlock->m_CompanyArray[nContainer].ro_a_aci/pPGBlock->m_CompanyArray[nContainer].ro_customernum);
			pPGBlock->m_CompanyArray[nContainer].ro_a_saidi = (float)(pPGBlock->m_CompanyArray[nContainer].ro_a_cid/pPGBlock->m_CompanyArray[nContainer].ro_customernum);
			pPGBlock->m_CompanyArray[nContainer].ro_a_asai = (float)(1.0-pPGBlock->m_CompanyArray[nContainer].ro_a_saidi/8760.0);
			pPGBlock->m_CompanyArray[nContainer].ro_a_aens = (float)(pPGBlock->m_CompanyArray[nContainer].ro_a_ens/pPGBlock->m_CompanyArray[nContainer].ro_customernum);

			if (pPGBlock->m_CompanyArray[nContainer].ro_a_saifi > FLT_MIN)
				pPGBlock->m_CompanyArray[nContainer].ro_a_mid = (float)(pPGBlock->m_CompanyArray[nContainer].ro_a_saidi/pPGBlock->m_CompanyArray[nContainer].ro_a_saifi);
			if (fAFaltNum > FLT_MIN)
				pPGBlock->m_CompanyArray[nContainer].ro_a_mic = (float)(pPGBlock->m_CompanyArray[nContainer].ro_a_aci/fAFaltNum);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	������
	for (nContainer=0; nContainer<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nContainer++)
	{
		fFaltNum=fFFaltNum=fAFaltNum=0;
		for (nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
		{
			if (m_RData.m_CompArray[nDev].nDevTyp != PG_ACLINESEGMENT)
				continue;

			if (m_RData.m_CompArray[nDev].nIniSub < 0 || m_RData.m_CompArray[nDev].nEndSub < 0)
				continue;

			if (strcmp(pPGBlock->m_SubstationArray[m_RData.m_CompArray[nDev].nIniSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[nContainer].szName) == 0)
			{
				fFFaltNum += m_RData.m_CompArray[nDev].fRerr/2;
				fAFaltNum += m_RData.m_CompArray[nDev].fRchk/2;
			}
			if (strcmp(pPGBlock->m_SubstationArray[m_RData.m_CompArray[nDev].nEndSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[nContainer].szName) == 0)
			{
				fFFaltNum += m_RData.m_CompArray[nDev].fRerr/2;
				fAFaltNum += m_RData.m_CompArray[nDev].fRchk/2;
			}
		}
		fFaltNum = fFFaltNum+fAFaltNum;

		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum=0;
		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[nContainer].szName) != 0)
				continue;
			for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
				{
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum += pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer;

					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_r);
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_u);
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_u);

					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_fr);
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_fu);
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_fu);

					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_aci += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_ar);
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_cid += (float)(pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer*pPGBlock->m_EnergyConsumerArray[nDev].ro_au);
					pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_ens += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_au);
				}
			}
		}
		if (pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum > FLT_MIN)
		{
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saifi = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_aci/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saidi = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_cid/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_asai = (float)(1.0-pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saidi/8760);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_aens = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_ens/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);

			if (pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saifi > FLT_MIN)
				pPGBlock->m_SubcontrolAreaArray[nContainer].ro_mid = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saidi/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saifi);
			if (fFaltNum > FLT_MIN)	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_mic = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_aci/fFaltNum);

			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saifi = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_aci/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saidi = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_cid/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_asai = (float)(1.0-pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saidi/8760.0);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_aens = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_ens/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);

			if (pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saifi > FLT_MIN)
				pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_mid = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saidi/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saifi);
			if (fFFaltNum > FLT_MIN)	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_mic = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_aci/fFFaltNum);

			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saifi = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_aci/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saidi = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_cid/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_asai = (float)(1.0-pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saidi/8760.0);
			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_aens = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_ens/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_customernum);

			if (pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saifi > FLT_MIN)
				pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_mid = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saidi/pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saifi);
			if (fAFaltNum > FLT_MIN)	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_mic = (float)(pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_aci/fAFaltNum);
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��·��
	for (nContainer=0; nContainer<pPGBlock->m_nRecordNum[PG_LINE]; nContainer++)
	{
		if (pPGBlock->m_LineArray[nContainer].ro_customernum > FLT_MIN)
		{
			pPGBlock->m_LineArray[nContainer].ro_saifi = (float)(pPGBlock->m_LineArray[nContainer].ro_aci/pPGBlock->m_LineArray[nContainer].ro_customernum);
			pPGBlock->m_LineArray[nContainer].ro_saidi = (float)(pPGBlock->m_LineArray[nContainer].ro_cid/pPGBlock->m_LineArray[nContainer].ro_customernum);
			pPGBlock->m_LineArray[nContainer].ro_asai = (float)(1.0-pPGBlock->m_LineArray[nContainer].ro_saidi/8760);
			pPGBlock->m_LineArray[nContainer].ro_aens = (float)(pPGBlock->m_LineArray[nContainer].ro_ens/pPGBlock->m_LineArray[nContainer].ro_customernum);

			if (pPGBlock->m_LineArray[nContainer].ro_saifi > FLT_MIN)
			{
				pPGBlock->m_LineArray[nContainer].ro_mid = (float)(pPGBlock->m_LineArray[nContainer].ro_saidi/pPGBlock->m_LineArray[nContainer].ro_saifi);
				pPGBlock->m_LineArray[nContainer].ro_mic = (float)(pPGBlock->m_LineArray[nContainer].ro_customernum/pPGBlock->m_LineArray[nContainer].ro_saifi);
			}

			pPGBlock->m_LineArray[nContainer].ro_f_saifi = (float)(pPGBlock->m_LineArray[nContainer].ro_f_aci/pPGBlock->m_LineArray[nContainer].ro_customernum);
			pPGBlock->m_LineArray[nContainer].ro_f_saidi = (float)(pPGBlock->m_LineArray[nContainer].ro_f_cid/pPGBlock->m_LineArray[nContainer].ro_customernum);
			pPGBlock->m_LineArray[nContainer].ro_f_asai = (float)(1.0-pPGBlock->m_LineArray[nContainer].ro_f_saidi/8760.0);
			pPGBlock->m_LineArray[nContainer].ro_f_aens = (float)(pPGBlock->m_LineArray[nContainer].ro_f_ens/pPGBlock->m_LineArray[nContainer].ro_customernum);

			if (pPGBlock->m_LineArray[nContainer].ro_f_saifi > FLT_MIN)
			{
				pPGBlock->m_LineArray[nContainer].ro_f_mid = (float)(pPGBlock->m_LineArray[nContainer].ro_f_saidi/pPGBlock->m_LineArray[nContainer].ro_f_saifi);
				pPGBlock->m_LineArray[nContainer].ro_f_mic = (float)(pPGBlock->m_LineArray[nContainer].ro_customernum/pPGBlock->m_LineArray[nContainer].ro_f_saifi);
			}

			pPGBlock->m_LineArray[nContainer].ro_a_saifi = (float)(pPGBlock->m_LineArray[nContainer].ro_a_aci/pPGBlock->m_LineArray[nContainer].ro_customernum);
			pPGBlock->m_LineArray[nContainer].ro_a_saidi = (float)(pPGBlock->m_LineArray[nContainer].ro_a_cid/pPGBlock->m_LineArray[nContainer].ro_customernum);
			pPGBlock->m_LineArray[nContainer].ro_a_asai = (float)(1.0-pPGBlock->m_LineArray[nContainer].ro_a_saidi/8760.0);
			pPGBlock->m_LineArray[nContainer].ro_a_aens = (float)(pPGBlock->m_LineArray[nContainer].ro_a_ens/pPGBlock->m_LineArray[nContainer].ro_customernum);

			if (pPGBlock->m_LineArray[nContainer].ro_a_saifi > FLT_MIN)
			{
				pPGBlock->m_LineArray[nContainer].ro_a_mid = (float)(pPGBlock->m_LineArray[nContainer].ro_a_saidi/pPGBlock->m_LineArray[nContainer].ro_a_saifi);
				pPGBlock->m_LineArray[nContainer].ro_a_mic = (float)(pPGBlock->m_LineArray[nContainer].ro_customernum/pPGBlock->m_LineArray[nContainer].ro_a_saifi);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	ָ�깱�׶�
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		pPGBlock->m_EnergyConsumerArray[nDev].ro_RContribution	=0;
		pPGBlock->m_EnergyConsumerArray[nDev].ro_UContribution	=0;
		pPGBlock->m_EnergyConsumerArray[nDev].ro_ENSContribution=0;

		if (pPGBlock->m_System.ro_aci > FLT_MIN)	pPGBlock->m_EnergyConsumerArray[nDev].ro_RContribution			= (float)(100.0*pPGBlock->m_EnergyConsumerArray[nDev].ro_r*pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > FLT_MIN)	pPGBlock->m_EnergyConsumerArray[nDev].ro_UContribution			= (float)(100.0*pPGBlock->m_EnergyConsumerArray[nDev].ro_u*pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > FLT_MIN)	pPGBlock->m_EnergyConsumerArray[nDev].ro_ENSContribution		= (float)(100.0*pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_EnergyConsumerArray[nDev].ro_u		/pPGBlock->m_System.ro_ens);
	}

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDev++)
	{
		pPGBlock->m_SubcontrolAreaArray[nDev].ro_RContribution	=0;
		pPGBlock->m_SubcontrolAreaArray[nDev].ro_UContribution	=0;
		pPGBlock->m_SubcontrolAreaArray[nDev].ro_ENSContribution=0;

		if (pPGBlock->m_System.ro_aci > DBL_MIN)	pPGBlock->m_SubcontrolAreaArray[nDev].ro_RContribution			= (float)(100.0*pPGBlock->m_SubcontrolAreaArray[nDev].ro_aci	/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > DBL_MIN)	pPGBlock->m_SubcontrolAreaArray[nDev].ro_UContribution			= (float)(100.0*pPGBlock->m_SubcontrolAreaArray[nDev].ro_cid	/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > DBL_MIN)	pPGBlock->m_SubcontrolAreaArray[nDev].ro_ENSContribution		= (float)(100.0*pPGBlock->m_SubcontrolAreaArray[nDev].ro_ens	/pPGBlock->m_System.ro_ens);
	}

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (pPGBlock->m_System.ro_aci > FLT_MIN)	pPGBlock->m_ACLineSegmentArray[nDev].ro_RContribution			= (float)(100.0*pPGBlock->m_ACLineSegmentArray[nDev].ro_RContribution	/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > FLT_MIN)	pPGBlock->m_ACLineSegmentArray[nDev].ro_UContribution			= (float)(100.0*pPGBlock->m_ACLineSegmentArray[nDev].ro_UContribution	/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > FLT_MIN)	pPGBlock->m_ACLineSegmentArray[nDev].ro_ENSContribution			= (float)(100.0*pPGBlock->m_ACLineSegmentArray[nDev].ro_ENSContribution	/pPGBlock->m_System.ro_ens);
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		if (pPGBlock->m_System.ro_aci > FLT_MIN)	pPGBlock->m_TransformerWindingArray[nDev].ro_RContribution		= (float)(100.0*pPGBlock->m_TransformerWindingArray[nDev].ro_RContribution	/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > FLT_MIN)	pPGBlock->m_TransformerWindingArray[nDev].ro_UContribution		= (float)(100.0*pPGBlock->m_TransformerWindingArray[nDev].ro_UContribution	/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > FLT_MIN)	pPGBlock->m_TransformerWindingArray[nDev].ro_ENSContribution	= (float)(100.0*pPGBlock->m_TransformerWindingArray[nDev].ro_ENSContribution/pPGBlock->m_System.ro_ens);
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BREAKER]; nDev++)
	{
		if (pPGBlock->m_System.ro_aci > FLT_MIN)	pPGBlock->m_BreakerArray[nDev].ro_RContribution					= (float)(100.0*pPGBlock->m_BreakerArray[nDev].ro_RContribution		/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > FLT_MIN)	pPGBlock->m_BreakerArray[nDev].ro_UContribution					= (float)(100.0*pPGBlock->m_BreakerArray[nDev].ro_UContribution		/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > FLT_MIN)	pPGBlock->m_BreakerArray[nDev].ro_ENSContribution				= (float)(100.0*pPGBlock->m_BreakerArray[nDev].ro_ENSContribution	/pPGBlock->m_System.ro_ens);
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
	{
		if (pPGBlock->m_System.ro_aci > FLT_MIN)	pPGBlock->m_BusbarSectionArray[nDev].ro_RContribution			= (float)(100.0*pPGBlock->m_BusbarSectionArray[nDev].ro_RContribution	/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > FLT_MIN)	pPGBlock->m_BusbarSectionArray[nDev].ro_UContribution			= (float)(100.0*pPGBlock->m_BusbarSectionArray[nDev].ro_UContribution	/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > FLT_MIN)	pPGBlock->m_BusbarSectionArray[nDev].ro_ENSContribution			= (float)(100.0*pPGBlock->m_BusbarSectionArray[nDev].ro_ENSContribution	/pPGBlock->m_System.ro_ens);
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		if (pPGBlock->m_System.ro_aci > FLT_MIN)	pPGBlock->m_SynchronousMachineArray[nDev].ro_RContribution		= (float)(100.0*pPGBlock->m_SynchronousMachineArray[nDev].ro_RContribution	/pPGBlock->m_System.ro_aci);
		if (pPGBlock->m_System.ro_cid > FLT_MIN)	pPGBlock->m_SynchronousMachineArray[nDev].ro_UContribution		= (float)(100.0*pPGBlock->m_SynchronousMachineArray[nDev].ro_UContribution	/pPGBlock->m_System.ro_cid);
		if (pPGBlock->m_System.ro_ens > FLT_MIN)	pPGBlock->m_SynchronousMachineArray[nDev].ro_ENSContribution	= (float)(100.0*pPGBlock->m_SynchronousMachineArray[nDev].ro_ENSContribution/pPGBlock->m_System.ro_ens);
	}

	SaveSystemRResult(pPGBlock, lpszRResultFile);
}

void	CDNRNetData::OutData_SysPerturbCalc(tagPGBlock* pPGBlock)
{
	int		nPerturb, nDev, nLoad;
	double	fCustomerNum;
	double	fFaltNum, fFFaltNum, fAFaltNum;

	if (m_RData.m_RPerturbParam.nReliablePerturbNum <= 0)
		return;

	fCustomerNum=pPGBlock->m_System.ro_customernum;
	for (nPerturb=0; nPerturb<=m_RData.m_RPerturbParam.nReliablePerturbNum; nPerturb++)
	{
		if (nPerturb != 0)
			PerturbAmend(nPerturb);

		fFaltNum=fFFaltNum=fAFaltNum=0;

		for (nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
		{
			if (m_RData.m_CompArray[nDev].nDevTyp != PG_ACLINESEGMENT)
				continue;

			fFFaltNum += m_RData.m_CompArray[nDev].fRerr;
			fAFaltNum += m_RData.m_CompArray[nDev].fRchk;
		}
		fFaltNum = fFFaltNum+fAFaltNum;

		PerturbRestore();

		//////////////////////////////////////////////////////////////////////////
		//	�����ܼ�
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMERRELIABLE]; nDev++)
		{
			nLoad=pPGBlock->m_EnergyConsumerReliableArray[nDev].nLoad;
			if (nLoad < 0 || nLoad >= pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER])
				continue;
			if (pPGBlock->m_EnergyConsumerReliableArray[nDev].nStep != nPerturb)
				continue;

			//////////////////////////////////////////////////////////////////////////
			//	ȫ��
			pPGBlock->m_SystemReliableArray[nPerturb].ro_aci += (pPGBlock->m_EnergyConsumerArray[nLoad].ri_Customer*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_r);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_cid += (pPGBlock->m_EnergyConsumerArray[nLoad].ri_Customer*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_u);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_ens += (pPGBlock->m_EnergyConsumerArray[nLoad].fPlanP*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_u);

			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_aci += (pPGBlock->m_EnergyConsumerArray[nLoad].ri_Customer*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_fr);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_cid += (pPGBlock->m_EnergyConsumerArray[nLoad].ri_Customer*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_fu);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_ens += (pPGBlock->m_EnergyConsumerArray[nLoad].fPlanP*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_fu);

			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_aci += (pPGBlock->m_EnergyConsumerArray[nLoad].ri_Customer*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_ar);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_cid += (pPGBlock->m_EnergyConsumerArray[nLoad].ri_Customer*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_au);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_ens += (pPGBlock->m_EnergyConsumerArray[nLoad].fPlanP*pPGBlock->m_EnergyConsumerReliableArray[nDev].ro_au);
		}

		if (fCustomerNum > FLT_MIN)
		{
			//////////////////////////////////////////////////////////////////////////
			//	ȫ��
			pPGBlock->m_SystemReliableArray[nPerturb].ro_saifi = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_aci/fCustomerNum);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_saidi = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_cid/fCustomerNum);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_asai = (float)(1.0-pPGBlock->m_SystemReliableArray[nPerturb].ro_saidi/8760);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_aens = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_ens/fCustomerNum);

			if (pPGBlock->m_SystemReliableArray[nPerturb].ro_saifi > FLT_MIN)
				pPGBlock->m_SystemReliableArray[nPerturb].ro_mid = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_saidi/pPGBlock->m_SystemReliableArray[nPerturb].ro_saifi);
			if (fFaltNum > FLT_MIN)
				pPGBlock->m_SystemReliableArray[nPerturb].ro_mic = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_aci/fFaltNum);

			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_saifi = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_f_aci/fCustomerNum);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_saidi = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_f_cid/fCustomerNum);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_asai = (float)(1.0-pPGBlock->m_SystemReliableArray[nPerturb].ro_f_saidi/8760.0);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_f_aens = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_f_ens/fCustomerNum);

			if (pPGBlock->m_SystemReliableArray[nPerturb].ro_f_saifi > FLT_MIN)
				pPGBlock->m_SystemReliableArray[nPerturb].ro_f_mid = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_f_saidi/pPGBlock->m_SystemReliableArray[nPerturb].ro_f_saifi);
			if (fFFaltNum > FLT_MIN)
				pPGBlock->m_SystemReliableArray[nPerturb].ro_f_mic = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_f_aci/fFFaltNum);

			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_saifi = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_a_aci/fCustomerNum);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_saidi = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_a_cid/fCustomerNum);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_asai = (float)(1.0-pPGBlock->m_SystemReliableArray[nPerturb].ro_a_saidi/8760.0);
			pPGBlock->m_SystemReliableArray[nPerturb].ro_a_aens = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_a_ens/fCustomerNum);

			if (pPGBlock->m_SystemReliableArray[nPerturb].ro_a_saifi > FLT_MIN)
				pPGBlock->m_SystemReliableArray[nPerturb].ro_a_mid = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_a_saidi/pPGBlock->m_SystemReliableArray[nPerturb].ro_a_saifi);
			if (fAFaltNum > FLT_MIN)
				pPGBlock->m_SystemReliableArray[nPerturb].ro_a_mic = (float)(pPGBlock->m_SystemReliableArray[nPerturb].ro_a_aci/fAFaltNum);
		}
	}
}

void CDNRNetData::SaveSystemRResult(tagPGBlock* pPGBlock, const char* lpszRResultFile)
{
	register int	i;
	int			nSub, nVolt, nContainer;
	int			nSubNum, nLoadNum;
	float		fCustomerNum;
	double		fTotalLoadP;
	TiXmlElement*	pElement;
	char		szBuf[260];

	TiXmlElement*	pRoot=new TiXmlElement("SystemReliablilityResult");

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
			{
				pElement = new TiXmlElement("EnergyConsumerRResult");							//��С·
				pRoot->LinkEndChild(pElement);

				sprintf(szBuf, "%s.%s.%s",					pPGBlock->m_EnergyConsumerArray[i].szSub, pPGBlock->m_EnergyConsumerArray[i].szVolt, pPGBlock->m_EnergyConsumerArray[i].szName);

				pElement->SetAttribute("ResID",				pPGBlock->m_EnergyConsumerArray[i].szResID);
				pElement->SetAttribute("Name",				szBuf);
				pElement->SetAttribute("Substation",		pPGBlock->m_EnergyConsumerArray[i].szSub);
				pElement->SetAttribute("SubcontrolArea",	pPGBlock->m_SubstationArray[nSub].szSubcontrolArea);
				pElement->SetAttribute("RCCase",			PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, pPGBlock->m_EnergyConsumerArray[i].nRCCase));
				pElement->SetDoubleAttribute("RCTime",		pPGBlock->m_EnergyConsumerArray[i].fRCTime);
				pElement->SetDoubleAttribute("P",			pPGBlock->m_EnergyConsumerArray[i].fPlanP);
				pElement->SetDoubleAttribute("Customer",	pPGBlock->m_EnergyConsumerArray[i].ri_Customer);
				pElement->SetDoubleAttribute("R",			pPGBlock->m_EnergyConsumerArray[i].ro_r);
				pElement->SetDoubleAttribute("U",			pPGBlock->m_EnergyConsumerArray[i].ro_u);
				pElement->SetDoubleAttribute("T",			pPGBlock->m_EnergyConsumerArray[i].ro_t);
				pElement->SetDoubleAttribute("FR",			pPGBlock->m_EnergyConsumerArray[i].ro_fr);
				pElement->SetDoubleAttribute("FU",			pPGBlock->m_EnergyConsumerArray[i].ro_fu);
				pElement->SetDoubleAttribute("FT",			pPGBlock->m_EnergyConsumerArray[i].ro_ft);
				pElement->SetDoubleAttribute("AR",			pPGBlock->m_EnergyConsumerArray[i].ro_ar);
				pElement->SetDoubleAttribute("AU",			pPGBlock->m_EnergyConsumerArray[i].ro_au);
				pElement->SetDoubleAttribute("AT",			pPGBlock->m_EnergyConsumerArray[i].ro_at);

				pElement->SetDoubleAttribute("SwR",			pPGBlock->m_EnergyConsumerArray[i].ro_swr);
				pElement->SetDoubleAttribute("SwU",			pPGBlock->m_EnergyConsumerArray[i].ro_swu);
				pElement->SetDoubleAttribute("SwT",			pPGBlock->m_EnergyConsumerArray[i].ro_swt);
				pElement->SetDoubleAttribute("CmR",			pPGBlock->m_EnergyConsumerArray[i].ro_cmr);
				pElement->SetDoubleAttribute("CmU",			pPGBlock->m_EnergyConsumerArray[i].ro_cmu);
				pElement->SetDoubleAttribute("CmT",			pPGBlock->m_EnergyConsumerArray[i].ro_cmt);

				pElement->SetDoubleAttribute("Ens",			pPGBlock->m_EnergyConsumerArray[i].ro_ens);
				pElement->SetDoubleAttribute("FEns",		pPGBlock->m_EnergyConsumerArray[i].ro_f_ens);
				pElement->SetDoubleAttribute("AEns",		pPGBlock->m_EnergyConsumerArray[i].ro_a_ens);

				pElement->SetDoubleAttribute("RContribution",	pPGBlock->m_EnergyConsumerArray[i].ro_RContribution);
				pElement->SetDoubleAttribute("UContribution",	pPGBlock->m_EnergyConsumerArray[i].ro_UContribution);
				pElement->SetDoubleAttribute("ENSContribution",	pPGBlock->m_EnergyConsumerArray[i].ro_ENSContribution);
			}
		}
	}

	pElement = new TiXmlElement("SystemRResult");	//��С·
	pRoot->LinkEndChild(pElement);

	pElement->SetDoubleAttribute("Cid",				pPGBlock->m_System.ro_cid);
	pElement->SetDoubleAttribute("Aci",				pPGBlock->m_System.ro_aci);
	pElement->SetDoubleAttribute("Asai",			pPGBlock->m_System.ro_asai);
	pElement->SetDoubleAttribute("Ens",				pPGBlock->m_System.ro_ens);
	pElement->SetDoubleAttribute("Saifi",			pPGBlock->m_System.ro_saifi);
	pElement->SetDoubleAttribute("Saidi",			pPGBlock->m_System.ro_saidi);
	pElement->SetDoubleAttribute("AEns",			pPGBlock->m_System.ro_aens);

	pElement->SetDoubleAttribute("FaultCid",		pPGBlock->m_System.ro_f_cid);
	pElement->SetDoubleAttribute("FaultAci",		pPGBlock->m_System.ro_f_aci);
	pElement->SetDoubleAttribute("FaultAsai",		pPGBlock->m_System.ro_f_asai);
	pElement->SetDoubleAttribute("FaultEns",		pPGBlock->m_System.ro_f_ens);
	pElement->SetDoubleAttribute("FaultSaifi",		pPGBlock->m_System.ro_f_saifi);
	pElement->SetDoubleAttribute("FaultSaidi",		pPGBlock->m_System.ro_f_saidi);
	pElement->SetDoubleAttribute("FaultAEns",		pPGBlock->m_System.ro_f_aens);

	pElement->SetDoubleAttribute("ArrangeCid",		pPGBlock->m_System.ro_a_cid);
	pElement->SetDoubleAttribute("ArrangeAci",		pPGBlock->m_System.ro_a_aci);
	pElement->SetDoubleAttribute("ArrangeAsai",		pPGBlock->m_System.ro_a_asai);
	pElement->SetDoubleAttribute("ArrangeEns",		pPGBlock->m_System.ro_a_ens);
	pElement->SetDoubleAttribute("ArrangeSaifi",	pPGBlock->m_System.ro_a_saifi);
	pElement->SetDoubleAttribute("ArrangeSaidi",	pPGBlock->m_System.ro_a_saidi);
	pElement->SetDoubleAttribute("ArrangeAEns",		pPGBlock->m_System.ro_a_aens);

	for (nContainer=0; nContainer<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nContainer++)
	{
		fTotalLoadP=0;
		nSubNum=nLoadNum=0;
		fCustomerNum=0;
		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[nContainer].szName) == 0)
			{
				for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
				{
					for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
					{
						fTotalLoadP += pPGBlock->m_EnergyConsumerArray[i].fPlanP;
						fCustomerNum += pPGBlock->m_EnergyConsumerArray[i].ri_Customer;
						nLoadNum++;
					}
				}
				nSubNum++;
			}
		}

		pElement = new TiXmlElement("SubcontrolAreaRResult");	//��С·
		pRoot->LinkEndChild(pElement);

		pElement->SetAttribute("ResID",					pPGBlock->m_SubcontrolAreaArray[nContainer].szResID);
		pElement->SetAttribute("Name",					pPGBlock->m_SubcontrolAreaArray[nContainer].szName);
		pElement->SetAttribute("Substation",			nSubNum);
		pElement->SetAttribute("LoadPoint",				nLoadNum);
		pElement->SetDoubleAttribute("Customer",		fCustomerNum);
		pElement->SetDoubleAttribute("P",				fTotalLoadP);

		pElement->SetDoubleAttribute("Cid",				pPGBlock->m_SubcontrolAreaArray[nContainer].ro_cid);
		pElement->SetDoubleAttribute("Aci",				pPGBlock->m_SubcontrolAreaArray[nContainer].ro_aci);
		pElement->SetDoubleAttribute("Asai",			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_asai);
		pElement->SetDoubleAttribute("Ens",				pPGBlock->m_SubcontrolAreaArray[nContainer].ro_ens);
		pElement->SetDoubleAttribute("Saifi",			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saifi);
		pElement->SetDoubleAttribute("Saidi",			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_saidi);
		pElement->SetDoubleAttribute("AEns",			pPGBlock->m_SubcontrolAreaArray[nContainer].ro_aens);

		pElement->SetDoubleAttribute("FaultCid",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_cid);
		pElement->SetDoubleAttribute("FaultAci",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_aci);
		pElement->SetDoubleAttribute("FaultAsai",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_asai);
		pElement->SetDoubleAttribute("FaultEns",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_ens);
		pElement->SetDoubleAttribute("FaultSaifi",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saifi);
		pElement->SetDoubleAttribute("FaultSaidi",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_saidi);
		pElement->SetDoubleAttribute("FaultAEns",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_f_aens);

		pElement->SetDoubleAttribute("ArrangeCid",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_cid);
		pElement->SetDoubleAttribute("ArrangeAci",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_aci);
		pElement->SetDoubleAttribute("ArrangeAsai",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_asai);
		pElement->SetDoubleAttribute("ArrangeEns",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_ens);
		pElement->SetDoubleAttribute("ArrangeSaifi",	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saifi);
		pElement->SetDoubleAttribute("ArrangeSaidi",	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_saidi);
		pElement->SetDoubleAttribute("ArrangeAEns",		pPGBlock->m_SubcontrolAreaArray[nContainer].ro_a_aens);

		pElement->SetDoubleAttribute("RContribution",	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_RContribution);
		pElement->SetDoubleAttribute("UContribution",	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_UContribution);
		pElement->SetDoubleAttribute("ENSContribution",	pPGBlock->m_SubcontrolAreaArray[nContainer].ro_ENSContribution);
	}

	HANDLE hSem = SemOn(g_lpszSysRResultSemaphore, 1000);
	if (hSem != INVALID_HANDLE_VALUE)
	{
		if (access(lpszRResultFile, 0) == 0)
		{
			FILE*	fp=fopen(lpszRResultFile, "a");
			if (fp != NULL)
			{
				pRoot->Print(fp, 0);
				fprintf(fp, "\n");
				fflush(fp);
				fclose(fp);
			}
		}
		SemOff(hSem);
	}
	else
	{
		Log(g_lpszLogFile, "��ȡ�����ļ�����������\n");
	}

	pRoot->Clear();
	delete pRoot;
}
