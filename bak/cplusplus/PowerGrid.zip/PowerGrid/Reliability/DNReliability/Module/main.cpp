// PGReli.cpp : �������̨Ӧ�ó������ڵ㡣
//
#include <Windows.h>
#include <io.h>
#include <vector>
using namespace std;
#include <crtdbg.h>
#include <process.h>
#include <float.h>

#include "../../../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../lib/PGMemDB.lib")
#else					 
#	pragma comment(lib, "../../../../lib_x64/PGMemDB.lib")
#endif
using namespace PGMemDB;

#include "../../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif

#include "../DNRNetData.h"
#include "../DNReliability.h"
#include "../../../../Common/SemaphoreCommon.h"

#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="DNReliabilityModule.log";

extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);

unsigned __stdcall  REstimateThreaad(void* lParam);
std::vector<unsigned char>	m_bLoadEstimated;

CDNRNetData		g_RData;
tagPGBlock*		m_pPGBlock;

int main(int argc, char** argv, char** envp)
{
	unsigned char	bFCutArrange=0;
	unsigned char	bCut4Switch=0;
	int		nProcessNum=1;
	char	szRResultXml[260];
	char	szRunDir[260];
	clock_t	dBeg, dEnd;
	int		nDur;

	memset(szRResultXml, 0, 260);

	ClearLog(g_lpszLogFile);

	int	nEle=1;
	if (argc > nEle)	strcpy(szRunDir, argv[nEle++]);
	if (argc > nEle)	bFCutArrange=atoi(argv[nEle++]);
	if (argc > nEle)	bCut4Switch=atoi(argv[nEle++]);
	if (argc > nEle)	nProcessNum=atoi(argv[nEle++]);
	if (argc > nEle)
	{
		if (stricmp(argv[nEle], "NULL") != 0)
			strcpy(szRResultXml, argv[nEle]);
		nEle++;
	}
	g_RData.ParsePerturb(nEle, argc, argv);

	Log(g_lpszLogFile,  "%d %d %d %s \n", bFCutArrange, bCut4Switch, nProcessNum, szRResultXml);

	if (strlen(szRResultXml) <= 0)
	{
		char	szTempPath[260];
		GetTempPath(260, szTempPath);
		sprintf(szRResultXml, "%s/%s", szTempPath, g_lpszSysReliableResultFileName);
	}

	dBeg=clock();
	m_pPGBlock=(tagPGBlock*)Init_PGBlock();
	if (!m_pPGBlock)
	{
		Log(g_lpszLogFile,  "��ȡ�ڴ�����\n");
		return 0;
	}

	g_RData.ReadData(m_pPGBlock, 0);	//	��ʱͣ���ֲ�ʽ��Դ
	if (g_RData.m_RData.m_LoadArray.empty())
		return 0;

	g_RData.InitData(m_pPGBlock);
	g_RData.InitRXml(szRResultXml, "DNReliabilityResult");

	int	nThreadNum = 1;
	if (nProcessNum > 1)
	{
		SYSTEM_INFO		sysInfo;
		::GetSystemInfo(&sysInfo);
		nThreadNum = (int)sysInfo.dwNumberOfProcessors;
		if (nThreadNum <= 0)
			nThreadNum = 1;
	}

	HANDLE	hXmlSem = InitSem(g_lpszSysRResultSemaphore);
	if (nThreadNum > 1)
	{
		InitializeCriticalSection(&CDNREstimate::m_csLock);

		{
			register int	i;
			unsigned int	nChildThreadID;
#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
			unsigned long	nMainThreadID;
#else
			pthread_t		nMainThreadID;
#endif

			nMainThreadID = GetCurrentThreadId();

			m_bLoadEstimated.resize(g_RData.m_RData.m_LoadArray.size());
			for (i=0; i<(int)m_bLoadEstimated.size(); i++)
				m_bLoadEstimated[i] = 0;

			PostThreadMessage(nMainThreadID, TM_ESTIMATEBEG, 0, 0);

			std::vector<HANDLE>	m_CalculateThreadArray;
			m_CalculateThreadArray.resize(nThreadNum);
			for (i=0; i<(int)m_CalculateThreadArray.size(); i++)
			{
				tagRThreadInfo*	pInfo=(tagRThreadInfo*)malloc(sizeof(tagRThreadInfo));
				memset(pInfo, 0, sizeof(tagRThreadInfo));

				pInfo->pPGBlock = (char*)m_pPGBlock;
				pInfo->nMainThreadID = nMainThreadID;
				pInfo->pRData = &g_RData.m_RData;
				pInfo->bFCutArrange = bFCutArrange;
				pInfo->bCut4Switch = bCut4Switch;
				strcpy(pInfo->szRResultFile, szRResultXml);

				m_CalculateThreadArray[i] = INVALID_HANDLE_VALUE;
				m_CalculateThreadArray[i] = (HANDLE)_beginthreadex(NULL, 0, REstimateThreaad, (void*)pInfo, 0, &nChildThreadID);
			}

			for (i=0; i<(int)m_CalculateThreadArray.size(); i++)
			{
				DWORD dwRet = WaitForSingleObject(m_CalculateThreadArray[i], INFINITE);
				if (dwRet == WAIT_OBJECT_0)
					Log(g_lpszLogFile, "        �����߳�[%d]���\n", i+1);
				else
					Log(g_lpszLogFile, "        �����߳�[%d]���� RetCode = %d\n", i+1, dwRet);
				if (m_CalculateThreadArray[i] != INVALID_HANDLE_VALUE)
					CloseHandle(m_CalculateThreadArray[i]);
			}

			g_RData.OutData_SysCalc(m_pPGBlock, szRResultXml);
			g_RData.OutData_SysPerturbCalc(m_pPGBlock);

			PostThreadMessage(nMainThreadID, TM_ESTIMATEEND, 0, 0);
		}

		DeleteCriticalSection(&CDNREstimate::m_csLock);
	}
	else
	{
		int				nLoad;
		CDNREstimate	m_REstimate;

		m_REstimate.CloneRData(&g_RData.m_RData);
		for (nLoad=0; nLoad<g_RData.m_RData.m_LoadArray.size(); nLoad++)
			m_REstimate.LoadREstimate(m_pPGBlock, nLoad, 1, bFCutArrange, bCut4Switch, szRResultXml);

		g_RData.OutData_SysCalc(m_pPGBlock, szRResultXml);
		g_RData.OutData_SysPerturbCalc(m_pPGBlock);
	}
	CloseHandle(hXmlSem);

	g_RData.EndRXml(szRResultXml, "DNReliabilityResult");

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	Log(g_lpszLogFile,  "��ʱ�� %d ���� \n", nDur);

	return 1;
}

unsigned __stdcall 	REstimateThreaad(void* lParam)
{
	register int	i;

	tagRThreadInfo*	pInfo=(tagRThreadInfo*)lParam;

	CDNREstimate	m_REstimate;

	m_REstimate.CloneRData(pInfo->pRData);
	while (TRUE)
	{
		int	nEstimateLoad=-1;
		EnterCriticalSection(&CDNREstimate::m_csLock);
		for (i=0; i<(int)m_bLoadEstimated.size(); i++)
		{
			if (m_bLoadEstimated[i] == 0)
			{
				nEstimateLoad = i;
				m_bLoadEstimated[i] = 1;
				break;
			}
		}
		LeaveCriticalSection(&CDNREstimate::m_csLock);
		if (nEstimateLoad < 0)
			break;

		m_REstimate.LoadREstimate((tagPGBlock*)pInfo->pPGBlock, nEstimateLoad, 1, pInfo->bFCutArrange, pInfo->bCut4Switch, pInfo->szRResultFile);

		PostThreadMessage(pInfo->nMainThreadID, TM_ESTIMATING, 1, 0);
	}

	free(pInfo);

	_endthreadex(0);

	return 0;
}
