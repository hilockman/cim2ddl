#include "stdafx.h"
#include "DisjointAlgorithm.hpp"

CDisjointAlgorithm::CDisjointAlgorithm()
{
	m_nMaxRoad = 0;
}

int CDisjointAlgorithm::GetVw(int nEdge)
{
	int nFanOut=1;
	while(1)
	{
		if (m_DisjointNodeMatrix[nFanOut-1][nEdge-1] != -50)
			nFanOut++;
		else
			break;
	}
	return(nFanOut);
}

int CDisjointAlgorithm::DisJoint_Init(std::vector<tagRNode>& sNodeArray, std::vector<tagRComp>& sCompArray, const int nIniNode, std::vector<int>& nNodeArray)
{
	register int	i, j;
	int		nNode, nComp, nOppNode;
	std::vector<int>	nNobnArray;

	m_nBusNum=(int)nNodeArray.size();

	m_RouteMatrix.clear();
	for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
	{
		nNobnArray.clear();
		for (i=0; i<(int)sNodeArray[nNodeArray[nNode]].nCompArray.size(); i++)
		{
			nComp=sNodeArray[nNodeArray[nNode]].nCompArray[i];
			if (sCompArray[nComp].bExcision)	//	����ģ��֧·����
				continue;
			if (sCompArray[nComp].nDirect == 1)
			{
				if (sCompArray[nComp].nNewIniNode == nNodeArray[nNode])
					continue;
			}
			if (sCompArray[nComp].nDirect == 2)
			{
				if (sCompArray[nComp].nNewEndNode == nNodeArray[nNode])
					continue;
			}

			nOppNode=(sCompArray[nComp].nNewIniNode == nNodeArray[nNode]) ? sCompArray[nComp].nNewEndNode : sCompArray[nComp].nNewIniNode;
			for (j=0; j<(int)nNodeArray.size(); j++)
			{
				if (nNodeArray[j] == nOppNode)
				{
					nNobnArray.push_back(j+1);
					break;
				}
			}
		}
		//��Դ���֧·��Ϣ�������仯
		//if (nNobnArray.size() != m_NobnArray[nNodeArray[nNode]].nOppNodeArray.size())
		//	return 0;
		nNobnArray.push_back(0);
		m_RouteMatrix.push_back(nNobnArray);
	}

	m_nIniBus=-1;
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (nIniNode == nNodeArray[i])
		{
			m_nIniBus=i+1;
			break;
		}
	}
	if (m_nIniBus <= 0)
		return 0;
	m_RouteMatrix[m_nIniBus-1][m_RouteMatrix[m_nIniBus-1].size()-1]=-1;

	std::vector<int>	nVBuf;
	nVBuf.resize(m_nConstMaxEdge, -50);
	m_DisjointNodeMatrix.clear();
	for (i=0; i<m_nBusNum+1; i++)
		m_DisjointNodeMatrix.push_back(nVBuf);
	nVBuf.clear();

	m_DisjointNodeMatrix[0][0]=m_nIniBus;

	m_nPosVector.resize(m_nBusNum, 1);
	m_nChkVector.resize(m_nBusNum, 0);

	return 1;
}

void CDisjointAlgorithm::DisJoint_Calc(const int nEndNode, std::vector<int>& nNodeArray)
{
	register int	i, j;
	int	nNode=2, nRoad=1, nBus=m_nIniBus;

	m_nEndBus=-1;
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (nEndNode == nNodeArray[i])
		{
			m_nEndBus=i+1;
			break;
		}
	}
	if (m_nEndBus <= 0)
		return;

	for (i=0; i<m_nBusNum; i++)
	{
		m_nPosVector[i]=1;
		m_nChkVector[i]=0;
	}
	m_nChkVector[m_nIniBus-1]=1;
	m_nChkVector[m_nEndBus-1]=-1;

	for (i=0; i<m_nBusNum+1; i++)
	{
		for (j=0; j<m_nConstMaxEdge; j++)
			m_DisjointNodeMatrix[i][j]=-50;
	}
	m_DisjointNodeMatrix[0][0]=m_nIniBus;

	while(1)
	{
		m_DisjointNodeMatrix[nNode-1][nRoad-1]=m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1];
		if (m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1] > 0)							//	nBus��λ��m_nPosVector[nBus-1]�����ȳ�֧·
		{
			if (m_nChkVector[m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1]-1] > 0)		//	nBus��λ��m_nPosVector[nBus-1]�������Ѿ���������
			{
				m_nPosVector[nBus-1]=m_nPosVector[nBus-1]+1;							//	������һ��λ��
				continue;
			}
			else
			{
				if (m_nChkVector[m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1]-1] == 0)
				{
					nBus=m_DisjointNodeMatrix[nNode-1][nRoad-1];
					m_nChkVector[nBus-1]=1;
					nNode++;
					continue;
				}
				else
				{
					m_nPosVector[nBus-1]=m_nPosVector[nBus-1]+1;

					int Vw=GetVw(nRoad)-2;
					for (i=0; i<Vw; i++)
					{
						m_DisjointNodeMatrix[i][nRoad]=m_DisjointNodeMatrix[i][nRoad-1];
					}
					if (nRoad < m_nConstMaxEdge-1)	nRoad++;

					if (nRoad > m_nMaxRoad)
						m_nMaxRoad=nRoad;

					continue;
				}
			}
		}
		else
		{
			if (m_RouteMatrix[nBus-1][m_nPosVector[nBus-1]-1] == 0)	//	nBus��λ��m_nPosVector[nBus-1]��û���ȳ�֧·
			{
				m_nChkVector[nBus-1]=0;
				m_nPosVector[nBus-1]=1;
				nBus=m_DisjointNodeMatrix[nNode-3][nRoad-1];
				m_nPosVector[nBus-1]=m_nPosVector[nBus-1]+1;
				nNode--;
				continue;
			}
			else	//	nBus��λ��m_nPosVector[nBus-1]������Ŀ���
			{
				break;
			}
		}
	}
	// 	for (i=0; i<m_nConstMaxEdge; i++)
	// 	{
	// 		nEdgeNum=0;
	// 		for(j=0; j<(int)nNodeArray.size()+1; j++)
	// 		{
	// 			if (m_DisjointNodeMatrix[j][i] != -50 && m_DisjointNodeMatrix[j][i] > 0)
	// 			{
	// 				Log(g_lpszLogFile,  "%d\t", nNodeArray[m_DisjointNodeMatrix[j][i]-1]);
	// 				nEdgeNum++;
	// 			}
	// 		}
	// 		if (nEdgeNum > 0)	Log(g_lpszLogFile,  "\n");
	// 	}
}

void CDisjointAlgorithm::DisJoint2MinPath(std::vector<tagRNode>& sNodeArray, std::vector<tagRComp>& sCompArray, std::vector<int>& nNodeArray, std::vector<tagRMinPath>& minPathArray)
{
	register int	i;
	int		nEdge, nNode, nComp, nFrNode, nToNode, nOppNode;
	int		nEdgeNum;
	tagRMinPath	pathBuf;

	for (nEdge=0; nEdge<m_nConstMaxEdge; nEdge++)
	{
		nEdgeNum=0;
		nFrNode=nToNode=-1;
		pathBuf.nCompArray.clear();
		for (nNode=0; nNode<(int)nNodeArray.size()+1; nNode++)
		{
			if (m_DisjointNodeMatrix[nNode][nEdge] != -50 && m_DisjointNodeMatrix[nNode][nEdge] > 0)
			{
				//Log(g_lpszLogFile,  "%d\t", nNodeArray[m_DisjointNodeMatrix[nNode][nEdge]-1]);
				if (nToNode < 0)
				{
					nToNode=nNodeArray[m_DisjointNodeMatrix[nNode][nEdge]-1];
				}
				else if (nToNode >= 0)
				{
					nFrNode=nToNode;
					nToNode=nNodeArray[m_DisjointNodeMatrix[nNode][nEdge]-1];
				}

				if (nFrNode >= 0 && nToNode >= 0)
				{
					nEdgeNum++;
					for (i=0; i<(int)sNodeArray[nFrNode].nCompArray.size(); i++)
					{
						nComp=sNodeArray[nFrNode].nCompArray[i];
						if (sCompArray[nComp].nNewIniNode == sCompArray[nComp].nNewEndNode)
							continue;
						nOppNode=(sCompArray[nComp].nNewIniNode == nFrNode) ? sCompArray[nComp].nNewEndNode : sCompArray[nComp].nNewIniNode;
						if (nOppNode == nToNode)
						{
							pathBuf.nCompArray.push_back(nComp);
							break;
						}
					}
				}
			}
		}
		if (nEdgeNum > 0)
			minPathArray.push_back(pathBuf);
		//if (nEdgeNum > 0)	Log(g_lpszLogFile,  "\n");
	}
}
