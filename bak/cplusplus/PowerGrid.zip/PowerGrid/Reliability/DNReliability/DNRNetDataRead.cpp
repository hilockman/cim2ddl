#include "stdafx.h"
#include "DNRNetData.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"
#include "../../../Common/SemaphoreCommon.h"

void CDNRNetData::ReadData_Gen(tagPGBlock* pPGBlock, const unsigned char bReadWTPV)
{
	register int	i;
	int			nDev;
	tagRGen		sGenBuf;

	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		if (pPGBlock->m_SynchronousMachineArray[nDev].nNode < 0)
			continue;

		if (pPGBlock->m_SynchronousMachineArray[nDev].bOutage)
			continue;

		memset(&sGenBuf, 0, sizeof(tagRGen));
		strcpy(sGenBuf.szResID, pPGBlock->m_SynchronousMachineArray[nDev].szResID);
		sGenBuf.nTopoBus	= pPGBlock->m_SynchronousMachineArray[nDev].nNode;
		sGenBuf.nDevTyp		= PG_SYNCHRONOUSMACHINE;
		sGenBuf.nDevIdx		= nDev;
		sGenBuf.fP			= pPGBlock->m_SynchronousMachineArray[nDev].fPlanP;
		sGenBuf.fMaxP		= pPGBlock->m_SynchronousMachineArray[nDev].fPMax;
		//sprintf(sGenBuf.szName, "%s.%s", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szName);

		m_RData.m_GenArray.push_back(sGenBuf);
	}

	if (bReadWTPV)
	{
		for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_WINDTURBINE]; nDev++)
		{
			if (pPGBlock->m_WindTurbineArray[nDev].nNode < 0)
				continue;

			if (pPGBlock->m_WindTurbineArray[nDev].bOutage)
				continue;

			memset(&sGenBuf, 0, sizeof(tagRGen));
			strcpy(sGenBuf.szResID, pPGBlock->m_WindTurbineArray[nDev].szResID);
			sGenBuf.nTopoBus	= pPGBlock->m_WindTurbineArray[nDev].nNode;
			sGenBuf.nDevTyp		= PG_WINDTURBINE;	//	����Դģ��
			sGenBuf.nDevIdx		= nDev;
			sGenBuf.fP			= pPGBlock->m_WindTurbineArray[nDev].fP;
			sGenBuf.fMaxP		= pPGBlock->m_WindTurbineArray[nDev].fRatedMva;

			i=0;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power1;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power2;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power3;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power4;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power5;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power6;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power7;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power8;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power9;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power10;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power11;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_WindTurbineArray[nDev].output_power12;

			i=0;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob1;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob2;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob3;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob4;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob5;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob6;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob7;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob8;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob9;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob10;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob11;
			sGenBuf.fStatProb[i++]=pPGBlock->m_WindTurbineArray[nDev].state_prob12;
			m_RData.m_GenArray.push_back(sGenBuf);
		}

		for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_PHOTOVOLTAIC]; nDev++)
		{
			if (pPGBlock->m_PhotoVoltaicArray[nDev].nNode < 0)
				continue;

			if (pPGBlock->m_PhotoVoltaicArray[nDev].bOutage)
				continue;

			memset(&sGenBuf, 0, sizeof(tagRGen));
			strcpy(sGenBuf.szResID, pPGBlock->m_PhotoVoltaicArray[nDev].szResID);
			sGenBuf.nTopoBus	= pPGBlock->m_PhotoVoltaicArray[nDev].nNode;
			sGenBuf.nDevTyp		= PG_PHOTOVOLTAIC;	//	����Դģ��
			sGenBuf.nDevIdx		= nDev;
			sGenBuf.fP			= pPGBlock->m_PhotoVoltaicArray[nDev].fP;
			sGenBuf.fMaxP		= pPGBlock->m_PhotoVoltaicArray[nDev].fRatedMva;

			i=0;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power1;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power2;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power3;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power4;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power5;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power6;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power7;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power8;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power9;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power10;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power11;
			sGenBuf.fPowerOut[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].output_power12;

			i=0;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob1;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob2;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob3;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob4;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob5;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob6;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob7;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob8;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob9;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob10;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob11;
			sGenBuf.fStatProb[i++]=pPGBlock->m_PhotoVoltaicArray[nDev].state_prob12;
			m_RData.m_GenArray.push_back(sGenBuf);
		}
	}
}

void CDNRNetData::ReadData_Node(tagPGBlock* pPGBlock, const unsigned char bReadWTPV)
{
	register int	i;
	int			nDev, nNode, nExist;
	tagRNode	sNodeBuf;

	InitializeRNode(&sNodeBuf);
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		if (pPGBlock->m_SynchronousMachineArray[nDev].nNode < 0)
			continue;
		nExist=0;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[nDev].nNode == m_RData.m_NodeArray[i].nTopoBus)
			{
				nExist=1;
				break;
			}
		}
		if (!nExist)
		{
			sNodeBuf.nTopoBus	= pPGBlock->m_SynchronousMachineArray[nDev].nNode;
			sNodeBuf.nNodeTyp	= PG_SYNCHRONOUSMACHINE;
			m_RData.m_NodeArray.push_back(sNodeBuf);
		}
	}

	if (bReadWTPV)
	{
		for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_WINDTURBINE]; nDev++)
		{
			if (pPGBlock->m_WindTurbineArray[nDev].nNode < 0)
				continue;
			nExist=0;
			for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
			{
				if (pPGBlock->m_WindTurbineArray[nDev].nNode == m_RData.m_NodeArray[i].nTopoBus)
				{
					nExist=1;
					break;
				}
			}
			if (!nExist)
			{
				sNodeBuf.nTopoBus	= pPGBlock->m_WindTurbineArray[nDev].nNode;
				sNodeBuf.nNodeTyp	= g_nConstSpareGenNode;	//	����Դģ��
				m_RData.m_NodeArray.push_back(sNodeBuf);
			}
		}
		for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_PHOTOVOLTAIC]; nDev++)
		{
			if (pPGBlock->m_PhotoVoltaicArray[nDev].nNode < 0)
				continue;
			nExist=0;
			for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
			{
				if (pPGBlock->m_PhotoVoltaicArray[nDev].nNode == m_RData.m_NodeArray[i].nTopoBus)
				{
					nExist=1;
					break;
				}
			}
			if (!nExist)
			{
				sNodeBuf.nTopoBus	= pPGBlock->m_PhotoVoltaicArray[nDev].nNode;
				sNodeBuf.nNodeTyp	= g_nConstSpareGenNode;	//	����Դģ��
				m_RData.m_NodeArray.push_back(sNodeBuf);
			}
		}
	}

	InitializeRNode(&sNodeBuf);
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
			continue;

		if (pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer <= FLT_MIN)
			pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer=1;

		nExist=-1;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (pPGBlock->m_EnergyConsumerArray[nDev].nNode == m_RData.m_NodeArray[i].nTopoBus)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuf.nTopoBus	= pPGBlock->m_EnergyConsumerArray[nDev].nNode;
			sNodeBuf.nNodeTyp	=PG_ENERGYCONSUMER;
			m_RData.m_NodeArray.push_back(sNodeBuf);
		}
		else
		{
			if (m_RData.m_NodeArray[nExist].nNodeTyp == 0)
				m_RData.m_NodeArray[nExist].nNodeTyp=PG_ENERGYCONSUMER;
		}
	}

	InitializeRNode(&sNodeBuf);
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		nExist=0;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (pPGBlock->m_TransformerWindingArray[nDev].nNodeI == m_RData.m_NodeArray[i].nTopoBus)
			{
				nExist=1;
				break;
			}
		}
		if (!nExist)
		{
			sNodeBuf.nTopoBus		= pPGBlock->m_TransformerWindingArray[nDev].nNodeI;	//pPGBlock->m_TransformerWindingArray[nDev].nLinkBusI;
			sNodeBuf.nNodeTyp		= 0;
			m_RData.m_NodeArray.push_back(sNodeBuf);
		}
		nExist=0;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (pPGBlock->m_TransformerWindingArray[nDev].nNodeJ == m_RData.m_NodeArray[i].nTopoBus)
			{
				nExist=1;
				break;
			}
		}
		if (!nExist)
		{
			sNodeBuf.nTopoBus		= pPGBlock->m_TransformerWindingArray[nDev].nNodeJ;	//pPGBlock->m_TransformerWindingArray[nDev].nLinkBusJ;
			sNodeBuf.nNodeTyp		= 0;
			m_RData.m_NodeArray.push_back(sNodeBuf);
		}
	}

	InitializeRNode(&sNodeBuf);
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
	{
		nNode=pPGBlock->m_BusbarSectionArray[nDev].nNode;
		if (nNode < 0)
			continue;

		nExist=-1;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (nNode == m_RData.m_NodeArray[i].nTopoBus)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuf.nTopoBus	= nNode;
			sNodeBuf.nNodeTyp	= PG_BUSBARSECTION;
			m_RData.m_NodeArray.push_back(sNodeBuf);
		}
		else
		{
			if (m_RData.m_NodeArray[nExist].nNodeTyp == 0)
				m_RData.m_NodeArray[nExist].nNodeTyp=PG_BUSBARSECTION;
		}
	}

	InitializeRNode(&sNodeBuf);
	for	(nNode=0; nNode<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; nNode++)
	{
		nExist=-1;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (nNode == m_RData.m_NodeArray[i].nTopoBus)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sNodeBuf.nTopoBus	= nNode;
			sNodeBuf.nNodeTyp	= PG_CONNECTIVITYNODE;
			m_RData.m_NodeArray.push_back(sNodeBuf);
		}
		else
		{
			if (m_RData.m_NodeArray[nExist].nNodeTyp == 0)
				m_RData.m_NodeArray[nExist].nNodeTyp=PG_CONNECTIVITYNODE;
		}
	}
}

void CDNRNetData::ReadData_Load(tagPGBlock* pPGBlock)
{
	register int	i;
	int			nDev;
	tagRLoad	sLoadBuf;
	char		szBuf[260];

	InitializeRLoad(&sLoadBuf);
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
			continue;
		if (pPGBlock->m_EnergyConsumerArray[nDev].bOutage)
			continue;

		sprintf(szBuf, "%s.%s.%s", pPGBlock->m_EnergyConsumerArray[nDev].szSub, pPGBlock->m_EnergyConsumerArray[nDev].szVolt, pPGBlock->m_EnergyConsumerArray[nDev].szName);

		sLoadBuf.strResID		= pPGBlock->m_EnergyConsumerArray[nDev].szResID;
		sLoadBuf.strName		= szBuf;
		sLoadBuf.strSubstation	= pPGBlock->m_EnergyConsumerArray[nDev].szSub;

		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[i].szName, pPGBlock->m_EnergyConsumerArray[nDev].szSub) == 0)
			{
				sLoadBuf.strSubcontrolArea = pPGBlock->m_SubstationArray[i].szSubcontrolArea;
				break;
			}
		}

		sLoadBuf.nTopoBus	= pPGBlock->m_EnergyConsumerArray[nDev].nNode;
		sLoadBuf.fCustomer	= (pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer <= FLT_MIN) ? 1 : pPGBlock->m_EnergyConsumerArray[nDev].ri_Customer;
		sLoadBuf.nDevTyp	= PG_ENERGYCONSUMER;
		sLoadBuf.nDevIdx	= nDev;
		sLoadBuf.fP			= pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
		m_RData.m_LoadArray.push_back(sLoadBuf);
	}
}

void CDNRNetData::ReadData_Comp_Line(tagPGBlock* pPGBlock)
{
	int			nDev;
	tagRComp	sCompBuf;

	InitializeRComp(&sCompBuf);
	sCompBuf.fRSwitch	=1;
	sCompBuf.fTSwitch	=0;
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (pPGBlock->m_ACLineSegmentArray[nDev].bOutage)
			continue;

		sCompBuf.nDevTyp	= PG_ACLINESEGMENT;
		sCompBuf.nDevIdx	= nDev;
		sCompBuf.nIniNode	= pPGBlock->m_ACLineSegmentArray[nDev].nNodeI;
		sCompBuf.nEndNode	= pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ;
		sCompBuf.fRerr		= pPGBlock->m_ACLineSegmentArray[nDev].ri_Rerr;
		sCompBuf.fTrep		= pPGBlock->m_ACLineSegmentArray[nDev].ri_Trep;
		sCompBuf.fRchk		= pPGBlock->m_ACLineSegmentArray[nDev].ri_Rchk;
		sCompBuf.fTchk		= pPGBlock->m_ACLineSegmentArray[nDev].ri_Tchk;

		sCompBuf.fTFLoc		= pPGBlock->m_ACLineSegmentArray[nDev].ri_Tfloc;
		sCompBuf.fRSwitch	= pPGBlock->m_ACLineSegmentArray[nDev].ri_RSwitch;
		sCompBuf.fTSwitch	= pPGBlock->m_ACLineSegmentArray[nDev].ri_TSwitch;
		sCompBuf.nStatus	= 0;
		sCompBuf.fLimit		= pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur;
		sCompBuf.fLength	= pPGBlock->m_ACLineSegmentArray[nDev].fLength;

		sCompBuf.nDirect	= 0;	//	����

		sCompBuf.strResID	= pPGBlock->m_ACLineSegmentArray[nDev].szResID;
		sCompBuf.strName	= pPGBlock->m_ACLineSegmentArray[nDev].szName;
		sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ACLineSegmentArray[nDev].szSubI);
		sCompBuf.nEndSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ);

		if (pPGBlock->m_ACLineSegmentArray[nDev].nDirection == PGEnum_BranchFlowDirection_Unknow)
		{
			sCompBuf.bSourceI=IsNodeJointSourceWithinVoltage(pPGBlock, pPGBlock->m_ACLineSegmentArray[nDev].nNodeI);
			sCompBuf.bSourceZ=IsNodeJointSourceWithinVoltage(pPGBlock, pPGBlock->m_ACLineSegmentArray[nDev].nNodeJ);
			if (sCompBuf.bSourceI == sCompBuf.bSourceZ)
			{
			}
			else if (sCompBuf.bSourceI != 0)
				sCompBuf.nDirect=1;
			else if (sCompBuf.bSourceZ != 0)
				sCompBuf.nDirect=2;
		}
		else
		{
			sCompBuf.nDirect=pPGBlock->m_ACLineSegmentArray[nDev].nDirection;
		}

		sCompBuf.nAugmentation=pPGBlock->m_ACLineSegmentArray[nDev].nLineType;
		if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)
		{
			sCompBuf.fRerr=sCompBuf.fTrep=0;
		}
		if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)
		{
			sCompBuf.fRchk=sCompBuf.fTchk=0;
		}
		m_RData.m_CompArray.push_back(sCompBuf);
	}
}

void CDNRNetData::ReadData_Comp_Wind(tagPGBlock* pPGBlock)
{
	int			nSub, nDev;
	tagRComp	sCompBuf;
	char		szBuf[260];

	InitializeRComp(&sCompBuf);
	sCompBuf.fRSwitch	=1;
	sCompBuf.fTSwitch	=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for	(nDev=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			if (pPGBlock->m_TransformerWindingArray[nDev].bOutage)
				continue;

			sprintf(szBuf, "%s.%s", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);

			sCompBuf.nDevTyp	= PG_TRANSFORMERWINDING;
			sCompBuf.nDevIdx	= nDev;
			sCompBuf.nIniNode	= pPGBlock->m_TransformerWindingArray[nDev].nNodeI;
			sCompBuf.nEndNode	= pPGBlock->m_TransformerWindingArray[nDev].nNodeJ;
			sCompBuf.fRerr		= pPGBlock->m_TransformerWindingArray[nDev].ri_Rerr;
			sCompBuf.fTrep		= pPGBlock->m_TransformerWindingArray[nDev].ri_Trep;
			sCompBuf.fRchk		= pPGBlock->m_TransformerWindingArray[nDev].ri_Rchk;
			sCompBuf.fTchk		= pPGBlock->m_TransformerWindingArray[nDev].ri_Tchk;
			sCompBuf.fTFLoc		= pPGBlock->m_TransformerWindingArray[nDev].ri_Tfloc;
			sCompBuf.fRSwitch	= pPGBlock->m_TransformerWindingArray[nDev].ri_RSwitch;
			sCompBuf.fTSwitch	= pPGBlock->m_TransformerWindingArray[nDev].ri_TSwitch;
			sCompBuf.nStatus	= 0;
			sCompBuf.fLimit		= 0;
			sCompBuf.fLength	= 0;

			sCompBuf.strResID	= pPGBlock->m_TransformerWindingArray[nDev].szResID;
			sCompBuf.strName	= szBuf;
			sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_TransformerWindingArray[nDev].szSub);
			sCompBuf.nEndSub	= sCompBuf.nIniSub;

			sCompBuf.nDirect	= 0;	//	����
			if (pPGBlock->m_TransformerWindingArray[nDev].nDirection == PGEnum_BranchFlowDirection_Unknow)
			{
				sCompBuf.bSourceI=IsNodeJointSourceWithinVoltage(pPGBlock, pPGBlock->m_TransformerWindingArray[nDev].nNodeI);
				sCompBuf.bSourceZ=IsNodeJointSourceWithinVoltage(pPGBlock, pPGBlock->m_TransformerWindingArray[nDev].nNodeJ);
				if (sCompBuf.bSourceI == sCompBuf.bSourceZ)
				{
				}
				else if (sCompBuf.bSourceI != 0)
					sCompBuf.nDirect=1;
				else if (sCompBuf.bSourceZ != 0)
					sCompBuf.nDirect=2;
			}
			else
			{
				sCompBuf.nDirect=pPGBlock->m_TransformerWindingArray[nDev].nDirection;
			}

			if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)
			{
				sCompBuf.fRerr=sCompBuf.fTrep=0;
			}
			if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)
			{
				sCompBuf.fRchk=sCompBuf.fTchk=0;
			}
			m_RData.m_CompArray.push_back(sCompBuf);
		}
	}
}

void CDNRNetData::ReadData_Comp_Breaker(tagPGBlock* pPGBlock)
{
	int			nDev;
	tagRComp	sCompBuf;
	char		szBuf[260];

	InitializeRComp(&sCompBuf);
	sCompBuf.fRSwitch	=1;
	sCompBuf.fTSwitch	=0;
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BREAKER]; nDev++)
	{
		if (pPGBlock->m_BreakerArray[nDev].bNonReliBreaker)
			continue;
		if (pPGBlock->m_BreakerArray[nDev].bOutage)
			continue;

		sprintf(szBuf, "%s.%s.%s", pPGBlock->m_BreakerArray[nDev].szSub, pPGBlock->m_BreakerArray[nDev].szVolt, pPGBlock->m_BreakerArray[nDev].szName);

		sCompBuf.nDevTyp	= PG_BREAKER;
		sCompBuf.nDevIdx	= nDev;
		sCompBuf.nIniNode	= pPGBlock->m_BreakerArray[nDev].nNodeI;
		sCompBuf.nEndNode	= pPGBlock->m_BreakerArray[nDev].nNodeJ;
		sCompBuf.fRerr		= pPGBlock->m_BreakerArray[nDev].ri_Rerr;
		sCompBuf.fTrep		= pPGBlock->m_BreakerArray[nDev].ri_Trep;
		sCompBuf.fRchk		= pPGBlock->m_BreakerArray[nDev].ri_Rchk;
		sCompBuf.fTchk		= pPGBlock->m_BreakerArray[nDev].ri_Tchk;
		sCompBuf.fTFLoc		= pPGBlock->m_BreakerArray[nDev].ri_Tfloc;
		sCompBuf.fRSwitch	= pPGBlock->m_BreakerArray[nDev].ri_RSwitch;
		sCompBuf.fTSwitch	= pPGBlock->m_BreakerArray[nDev].ri_TSwitch;
		sCompBuf.nStatus	= pPGBlock->m_BreakerArray[nDev].nStatus;

		sCompBuf.nBreakerType= pPGBlock->m_BreakerArray[nDev].nCategory;

		sCompBuf.fLimit		= 0;
		sCompBuf.fLength	= 0;
		sCompBuf.nDirect	= 0;

		sCompBuf.bSourceI	= IsBreakerNodeJointSource(pPGBlock, pPGBlock->m_BreakerArray[nDev].nNodeI, nDev);
		sCompBuf.bSourceZ	= IsBreakerNodeJointSource(pPGBlock, pPGBlock->m_BreakerArray[nDev].nNodeJ, nDev);
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ���϶�·���豸��%s %s %s�� %d %d\n", pPGBlock->m_BreakerArray[nDev].szSub, pPGBlock->m_BreakerArray[nDev].szVolt, pPGBlock->m_BreakerArray[nDev].szName, sCompBuf.bSourceI, sCompBuf.bSourceZ);
#endif

		sCompBuf.strResID	= pPGBlock->m_BreakerArray[nDev].szResID;
		sCompBuf.strName	= szBuf;
		sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_BreakerArray[nDev].szSub);
		sCompBuf.nEndSub	= sCompBuf.nIniSub;

		sCompBuf.bCmBreaker=(pPGBlock->m_BreakerArray[nDev].nCategory != PGEnumBreakerType_LoadBreakSwitch && pPGBlock->m_BreakerArray[nDev].nCategory != PGEnumBreakerType_Disconnector) ? 1 : 0;

		if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)
		{
			sCompBuf.fRerr=sCompBuf.fTrep=0;
		}
		if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)
		{
			sCompBuf.fRchk=sCompBuf.fTchk=0;
		}
		m_RData.m_CompArray.push_back(sCompBuf);
	}
}

void CDNRNetData::ReadData_Comp_Disconnector(tagPGBlock* pPGBlock)
{
	int			nDev;
	tagRComp	sCompBuf;
	char		szBuf[260];

	InitializeRComp(&sCompBuf);
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_DISCONNECTOR]; nDev++)
	{
		if (pPGBlock->m_DisconnectorArray[nDev].nStatus != 0)
			continue;
		if (pPGBlock->m_DisconnectorArray[nDev].bOutage)
			continue;

		sprintf(szBuf, "%s.%s.%s", pPGBlock->m_DisconnectorArray[nDev].szSub, pPGBlock->m_DisconnectorArray[nDev].szVolt, pPGBlock->m_DisconnectorArray[nDev].szName);

		sCompBuf.nDevTyp	= PG_DISCONNECTOR;
		sCompBuf.nDevIdx	= nDev;
		sCompBuf.nIniNode	= pPGBlock->m_DisconnectorArray[nDev].nNodeI;
		sCompBuf.nEndNode	= pPGBlock->m_DisconnectorArray[nDev].nNodeJ;
		sCompBuf.fRerr		= pPGBlock->m_DisconnectorArray[nDev].ri_Rerr;
		sCompBuf.fTrep		= pPGBlock->m_DisconnectorArray[nDev].ri_Trep;
		sCompBuf.fRchk		= pPGBlock->m_DisconnectorArray[nDev].ri_Rchk;
		sCompBuf.fTchk		= pPGBlock->m_DisconnectorArray[nDev].ri_Tchk;
		sCompBuf.fTFLoc		= pPGBlock->m_DisconnectorArray[nDev].ri_Tfloc;
		sCompBuf.fRSwitch	= pPGBlock->m_DisconnectorArray[nDev].ri_RSwitch;
		sCompBuf.fTSwitch	= pPGBlock->m_DisconnectorArray[nDev].ri_TSwitch;
		sCompBuf.nStatus	= pPGBlock->m_DisconnectorArray[nDev].nStatus;

		sCompBuf.fLimit		= 0;
		sCompBuf.fLength	= 0;
		sCompBuf.nDirect	= 0;

		sCompBuf.bSourceI	= 0;
		sCompBuf.bSourceZ	= 0;

		sCompBuf.strResID	= pPGBlock->m_DisconnectorArray[nDev].szResID;
		sCompBuf.strName	= szBuf;
		sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_DisconnectorArray[nDev].szSub);
		sCompBuf.nEndSub	= sCompBuf.nIniSub;

		if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)
		{
			sCompBuf.fRerr=sCompBuf.fTrep=0;
		}
		if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)
		{
			sCompBuf.fRchk=sCompBuf.fTchk=0;
		}
		m_RData.m_CompArray.push_back(sCompBuf);
	}
}

void	CDNRNetData::ReadData_Comp_SCap(tagPGBlock* pPGBlock)
{
	int			nDev;
	tagRComp	sCompBuf;
	char		szBuf[260];

	InitializeRComp(&sCompBuf);
	sCompBuf.fRSwitch	=1;
	sCompBuf.fTSwitch	=0;
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nDev++)
	{
		if (pPGBlock->m_SeriesCompensatorArray[nDev].bOutage)
			continue;

		sprintf(szBuf, "%s.%s.%s", pPGBlock->m_SeriesCompensatorArray[nDev].szSub, pPGBlock->m_SeriesCompensatorArray[nDev].szVolt, pPGBlock->m_SeriesCompensatorArray[nDev].szName);

		sCompBuf.nDevTyp	= PG_SERIESCOMPENSATOR;
		sCompBuf.nDevIdx	= nDev;
		sCompBuf.nIniNode	= pPGBlock->m_SeriesCompensatorArray[nDev].nNodeI;	//pPGBlock->m_SeriesCompensatorArray[nDev].nLinkBusI;
		sCompBuf.nEndNode	= pPGBlock->m_SeriesCompensatorArray[nDev].nNodeJ;	//pPGBlock->m_SeriesCompensatorArray[nDev].nLinkBusJ;
		sCompBuf.fRerr		= pPGBlock->m_SeriesCompensatorArray[nDev].ri_Rerr;
		sCompBuf.fTrep		= pPGBlock->m_SeriesCompensatorArray[nDev].ri_Trep;
		sCompBuf.fRchk		=  pPGBlock->m_SeriesCompensatorArray[nDev].ri_Rchk;
		sCompBuf.fTchk		= pPGBlock->m_SeriesCompensatorArray[nDev].ri_Tchk;
		sCompBuf.fTFLoc		= pPGBlock->m_SeriesCompensatorArray[nDev].ri_Tfloc;
		sCompBuf.fLimit		= 0;
		sCompBuf.fLength	= 0;
		sCompBuf.nDirect	= 0;

		sCompBuf.strResID	= pPGBlock->m_SeriesCompensatorArray[nDev].szResID;
		sCompBuf.strName	= szBuf;
		sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_SeriesCompensatorArray[nDev].szSub);
		sCompBuf.nEndSub	= sCompBuf.nIniSub;

		if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)	{	sCompBuf.fRerr=sCompBuf.fTrep=0;	}
		if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)	{	sCompBuf.fRchk=sCompBuf.fTchk=0;	}
		m_RData.m_CompArray.push_back(sCompBuf);
	}
}

void	CDNRNetData::ReadData_Comp_Bus(tagPGBlock* pPGBlock)
{
	register int	i;
	int			nDev, nNode, nExist;
	tagRComp	sCompBuf;
	char		szBuf[260];

	InitializeRComp(&sCompBuf);
	sCompBuf.fRSwitch	=1;
	sCompBuf.fTSwitch	=0;
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
	{
		nNode=pPGBlock->m_BusbarSectionArray[nDev].nNode;
		if (nNode < 0)
			continue;

		if ((pPGBlock->m_BusbarSectionArray[nDev].ri_Rerr < FLT_MIN || pPGBlock->m_BusbarSectionArray[nDev].ri_Trep < FLT_MIN) &&
			(pPGBlock->m_BusbarSectionArray[nDev].ri_Rchk < FLT_MIN || pPGBlock->m_BusbarSectionArray[nDev].ri_Tchk < FLT_MIN))
			continue;

		nExist=-1;
		for	(i=0; i<(int)m_RData.m_CompArray.size(); i++)
		{
			if (m_RData.m_CompArray[i].nDevTyp != PG_BUSBARSECTION)
				continue;
			if (nNode == m_RData.m_CompArray[i].nIniNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sprintf(szBuf, "%s.%s.%s", pPGBlock->m_BusbarSectionArray[nDev].szSub, pPGBlock->m_BusbarSectionArray[nDev].szVolt, pPGBlock->m_BusbarSectionArray[nDev].szName);

			sCompBuf.nDevTyp	= PG_BUSBARSECTION;
			sCompBuf.nDevIdx	= nDev;
			sCompBuf.nIniNode	= nNode;
			sCompBuf.nEndNode	= nNode;
			sCompBuf.fRerr		= pPGBlock->m_BusbarSectionArray[nDev].ri_Rerr;
			sCompBuf.fTrep		= pPGBlock->m_BusbarSectionArray[nDev].ri_Trep;
			sCompBuf.fRchk		= pPGBlock->m_BusbarSectionArray[nDev].ri_Rchk;
			sCompBuf.fTchk		= pPGBlock->m_BusbarSectionArray[nDev].ri_Tchk;
			sCompBuf.fTFLoc		= pPGBlock->m_BusbarSectionArray[nDev].ri_Tfloc;
			sCompBuf.nStatus	= 0;
			sCompBuf.nDirect	= 0;
			sCompBuf.fLimit		= 0;
			sCompBuf.fLength	= 0;

			sCompBuf.strResID	= pPGBlock->m_BusbarSectionArray[nDev].szResID;
			sCompBuf.strName	= szBuf;
			sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_BusbarSectionArray[nDev].szSub);
			sCompBuf.nEndSub	= sCompBuf.nIniSub;

			sCompBuf.nAugmentation=pPGBlock->m_BusbarSectionArray[nDev].nParentType;
			for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
			{
				if (pPGBlock->m_SynchronousMachineArray[i].nNode == nNode)
				{
					if (pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_WindTurbine && pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_PhotoVoltaic)
					{
						sCompBuf.nAugmentation=1;
						break;
					}
				}
			}

			if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)	{	sCompBuf.fRerr=sCompBuf.fTrep=0;	}
			if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)	{	sCompBuf.fRchk=sCompBuf.fTchk=0;	}
			m_RData.m_CompArray.push_back(sCompBuf);
		}
		else
		{
			m_RData.m_CompArray[nExist].fRerr=m_RData.m_CompArray[nExist].fRerr*pPGBlock->m_BusbarSectionArray[nDev].ri_Rerr*(m_RData.m_CompArray[nExist].fTrep+pPGBlock->m_BusbarSectionArray[nDev].ri_Trep)/8760;
			if (m_RData.m_CompArray[nExist].fRerr > FLT_MIN)
				m_RData.m_CompArray[nExist].fTrep=(m_RData.m_CompArray[nExist].fRerr*pPGBlock->m_BusbarSectionArray[nDev].ri_Rerr*m_RData.m_CompArray[nExist].fTrep*pPGBlock->m_BusbarSectionArray[nDev].ri_Trep)/(m_RData.m_CompArray[nExist].fRerr*8760);


			m_RData.m_CompArray[nExist].fRchk=m_RData.m_CompArray[nExist].fRchk*pPGBlock->m_BusbarSectionArray[nDev].ri_Rchk*(m_RData.m_CompArray[nExist].fTchk+pPGBlock->m_BusbarSectionArray[nDev].ri_Tchk)/8760;
			if (m_RData.m_CompArray[nExist].fRchk > FLT_MIN)
				m_RData.m_CompArray[nExist].fTchk=(m_RData.m_CompArray[nExist].fRchk*pPGBlock->m_BusbarSectionArray[nDev].ri_Rchk*m_RData.m_CompArray[nExist].fTchk*pPGBlock->m_BusbarSectionArray[nDev].ri_Tchk)/(m_RData.m_CompArray[nExist].fRchk*8760);

			for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
			{
				if (pPGBlock->m_SynchronousMachineArray[i].nNode == nNode)
				{
					if (pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_WindTurbine && pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_PhotoVoltaic)
					{
						m_RData.m_CompArray[nExist].nAugmentation=1;
						break;
					}
				}
			}
		}
	}
}

int	CDNRNetData::ReadData(tagPGBlock* pPGBlock, const unsigned char bReadWTPV)
{
	register int	i;
	int	nDev, nNode, nExist;
	tagRComp	sCompBuf;
	char		szBuf[260];

	m_RData.m_NodeArray.clear();
	m_RData.m_CompArray.clear();
	m_RData.m_LoadArray.clear();
	m_RData.m_GenArray.clear();


	//	1���γɷ����ģ��
	ReadData_Gen(pPGBlock, bReadWTPV);

	//	2���γɽڵ�ģ��
	ReadData_Node(pPGBlock, bReadWTPV);

	//	3���γɸ���ģ��
	ReadData_Load(pPGBlock);

	//	4���γ��豸ģ��
	ReadData_Comp_Line(pPGBlock);
	ReadData_Comp_Wind(pPGBlock);
	ReadData_Comp_SCap(pPGBlock);
	ReadData_Comp_Breaker(pPGBlock);
	ReadData_Comp_Disconnector(pPGBlock);
	ReadData_Comp_Bus(pPGBlock);

	sCompBuf.fRSwitch	=1;
	sCompBuf.fTSwitch	=0;
	for	(nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		nNode=pPGBlock->m_SynchronousMachineArray[nDev].nNode;
		if (nNode < 0)
			continue;

		if ((pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep < FLT_MIN) &&
			(pPGBlock->m_SynchronousMachineArray[nDev].ri_Rchk < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nDev].ri_Tchk < FLT_MIN))
			continue;

		nExist=-1;
		for	(i=0; i<(int)m_RData.m_CompArray.size(); i++)
		{
			if (m_RData.m_CompArray[i].nDevTyp != PG_SYNCHRONOUSMACHINE && m_RData.m_CompArray[i].nDevTyp != PG_BUSBARSECTION)
				continue;
			if (nNode == m_RData.m_CompArray[i].nIniNode)
			{
				nExist=i;
				break;
			}
		}
		if (nExist < 0)
		{
			sprintf(szBuf, "%s.%s.%s", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szVolt, pPGBlock->m_SynchronousMachineArray[nDev].szName);

			sCompBuf.nDevTyp	= PG_SYNCHRONOUSMACHINE;
			sCompBuf.nDevIdx	= nDev;
			sCompBuf.nIniNode	= nNode;
			sCompBuf.nEndNode	= nNode;
			sCompBuf.fRerr		= pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr;
			sCompBuf.fTrep		= pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep;
			sCompBuf.fRchk		= pPGBlock->m_SynchronousMachineArray[nDev].ri_Rchk;
			sCompBuf.fTchk		= pPGBlock->m_SynchronousMachineArray[nDev].ri_Tchk;
			sCompBuf.fTFLoc		= pPGBlock->m_SynchronousMachineArray[nDev].ri_Tfloc;
			sCompBuf.nStatus	= 0;
			sCompBuf.nDirect	= 0;
			sCompBuf.fLimit		= 0;
			sCompBuf.fLength	= 0;

			sCompBuf.strResID	= pPGBlock->m_SynchronousMachineArray[nDev].szResID;
			sCompBuf.strName	= szBuf;
			sCompBuf.nIniSub	= PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_SynchronousMachineArray[nDev].szSub);
			sCompBuf.nEndSub	= sCompBuf.nIniSub;

			sCompBuf.nAugmentation=1;
			for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
			{
				if (pPGBlock->m_SynchronousMachineArray[i].nNode == nNode)
				{
					if (pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_WindTurbine && pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_PhotoVoltaic)
					{
						sCompBuf.nAugmentation=1;
						break;
					}
				}
			}

			if (sCompBuf.fRerr < FLT_MIN || sCompBuf.fTrep < FLT_MIN)	{	sCompBuf.fRerr=sCompBuf.fTrep=0;	}
			if (sCompBuf.fRchk < FLT_MIN || sCompBuf.fTchk < FLT_MIN)	{	sCompBuf.fRchk=sCompBuf.fTchk=0;	}
			m_RData.m_CompArray.push_back(sCompBuf);
		}
		else
		{
			m_RData.m_CompArray[nExist].fRerr=m_RData.m_CompArray[nExist].fRerr*pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr*(m_RData.m_CompArray[nExist].fTrep+pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep)/8760;
			if (m_RData.m_CompArray[nExist].fRerr > FLT_MIN)
				m_RData.m_CompArray[nExist].fTrep=(m_RData.m_CompArray[nExist].fRerr*pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr*m_RData.m_CompArray[nExist].fTrep*pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep)/(m_RData.m_CompArray[nExist].fRerr*8760);


			m_RData.m_CompArray[nExist].fRchk=m_RData.m_CompArray[nExist].fRchk*pPGBlock->m_SynchronousMachineArray[nDev].ri_Rchk*(m_RData.m_CompArray[nExist].fTchk+pPGBlock->m_SynchronousMachineArray[nDev].ri_Tchk)/8760;
			if (m_RData.m_CompArray[nExist].fRchk > FLT_MIN)
				m_RData.m_CompArray[nExist].fTchk=(m_RData.m_CompArray[nExist].fRchk*pPGBlock->m_SynchronousMachineArray[nDev].ri_Rchk*m_RData.m_CompArray[nExist].fTchk*pPGBlock->m_SynchronousMachineArray[nDev].ri_Tchk)/(m_RData.m_CompArray[nExist].fRchk*8760);

			for (i=pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
			{
				if (pPGBlock->m_SynchronousMachineArray[i].nNode == nNode)
				{
					if (pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_WindTurbine && pPGBlock->m_SynchronousMachineArray[i].nType != PGEnumSynchronousMachine_Type_PhotoVoltaic)
					{
						m_RData.m_CompArray[nExist].nAugmentation=1;
						break;
					}
				}
			}
		}
	}

	//	5��
	ReadData_PostRead();

	SaveRDataFile();

	PrevPerturb();

	return	1;
}

void CDNRNetData::ReadData_PostRead()
{
	register int	i;
	int	nDev, nNode;
	//double	fBuf;
	std::vector<int>	nSpareLoadArray;

	// 	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	// 	{
	// 		// 		m_RData.m_CompArray[nDev].fFaultR=m_RData.m_CompArray[nDev].fRerr;
	// 		// 		m_RData.m_CompArray[nDev].fFaultT=m_RData.m_CompArray[nDev].fTrep;
	// 		//
	// 		// 		m_RData.m_CompArray[nDev].fArrangeR=m_RData.m_CompArray[nDev].fRchk;
	// 		// 		m_RData.m_CompArray[nDev].fArrangeT=m_RData.m_CompArray[nDev].fTchk;
	//
	// 		fBuf=m_RData.m_CompArray[nDev].fCloseTime;
	// 		if (fBuf > FLT_MIN)
	// 		{
	// 			m_fChangeTime=fBuf;
	// 		}
	// 	}
	//	�����Ǽ����ø�ͣ�˸��ԭ������Щ���⣬ͣ���ˡ�
	// 	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	// 	{
	// 		if (m_RData.m_CompArray[nDev].fRchk > FLT_MIN)
	// 		{
	// 			m_RData.m_CompArray[nDev].fR=m_RData.m_CompArray[nDev].fRerr+m_RData.m_CompArray[nDev].fRchk; 																		//Ϊ������Ԥ������(����)�õ�Ԫ����Чͣ���ʺ�ͣ��ʱ��
	// 			m_RData.m_CompArray[nDev].fT=(m_RData.m_CompArray[nDev].fRerr*m_RData.m_CompArray[nDev].fTrep+m_RData.m_CompArray[nDev].fRchk*m_RData.m_CompArray[nDev].fTchk)/m_RData.m_CompArray[nDev].fFaultR;
	// 		}
	// 		else
	// 		{
	// 			m_RData.m_CompArray[nDev].fR=m_RData.m_CompArray[nDev].fRerr;
	// 			m_RData.m_CompArray[nDev].fT=m_RData.m_CompArray[nDev].fTrep;
	// 		}
	// 	}

	//	1���ڵ��ţ��ɲ������Ľڵ����γ������Ľڵ��ţ�Ϊ�˷�ֹ�����������еľ�������
	int	nFlag;
	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	{
		nFlag=0;
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (m_RData.m_CompArray[nDev].nIniNode == m_RData.m_NodeArray[i].nTopoBus)
			{
				m_RData.m_CompArray[nDev].nNewIniNode=i;
				nFlag++;
			}
			if (m_RData.m_CompArray[nDev].nEndNode == m_RData.m_NodeArray[i].nTopoBus)
			{
				m_RData.m_CompArray[nDev].nNewEndNode=i;
				nFlag++;
			}
			if (nFlag >= 2)
				break;
		}
	}
	for (nDev=0; nDev<(int)m_RData.m_LoadArray.size(); nDev++)
	{
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (m_RData.m_LoadArray[nDev].nTopoBus == m_RData.m_NodeArray[i].nTopoBus)
			{
				m_RData.m_LoadArray[nDev].nNewNode=i;
				break;
			}
		}
	}
	for (nDev=0; nDev<(int)m_RData.m_GenArray.size(); nDev++)
	{
		for	(i=0; i<(int)m_RData.m_NodeArray.size(); i++)
		{
			if (m_RData.m_GenArray[nDev].nTopoBus == m_RData.m_NodeArray[i].nTopoBus)
			{
				m_RData.m_GenArray[nDev].nNewNode=i;
				break;
			}
		}
	}

	//	2���γɽڵ���Ϣ��
	for (i=0; i<(int)m_RData.m_NodeArray.size(); i++)
	{
		m_RData.m_NodeArray[i].nCompArray.clear();
		m_RData.m_NodeArray[i].nLoadArray.clear();
		m_RData.m_NodeArray[i].nBusArray.clear();
		m_RData.m_NodeArray[i].nGenArray.clear();
	}
	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	{
		if (m_RData.m_CompArray[nDev].nDevTyp == PG_BUSBARSECTION || m_RData.m_CompArray[nDev].nDevTyp == PG_SYNCHRONOUSMACHINE)
			continue;

		m_RData.m_NodeArray[m_RData.m_CompArray[nDev].nNewIniNode].nCompArray.push_back(nDev);
		m_RData.m_NodeArray[m_RData.m_CompArray[nDev].nNewEndNode].nCompArray.push_back(nDev);
	}
	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	{
		if (m_RData.m_CompArray[nDev].nDevTyp != PG_BUSBARSECTION)
			continue;

		m_RData.m_NodeArray[m_RData.m_CompArray[nDev].nNewIniNode].nBusArray.push_back(nDev);
	}
	for	(nDev=0; nDev<(int)m_RData.m_CompArray.size(); nDev++)
	{
		if (m_RData.m_CompArray[nDev].nDevTyp != PG_SYNCHRONOUSMACHINE)
			continue;

		m_RData.m_NodeArray[m_RData.m_CompArray[nDev].nNewIniNode].nGenArray.push_back(nDev);
	}
	for	(nDev=0; nDev<(int)m_RData.m_LoadArray.size(); nDev++)
	{
		m_RData.m_NodeArray[m_RData.m_LoadArray[nDev].nNewNode].nLoadArray.push_back(nDev);
	}

	for (nNode=0; nNode<(int)m_RData.m_NodeArray.size(); nNode++)
	{
		if (m_RData.m_NodeArray[nNode].nNodeTyp == g_nConstSpareGenNode)
		{
			TraverseRangeLoad(nNode, nSpareLoadArray);
			for (i=0; i<(int)nSpareLoadArray.size(); i++)
				m_RData.m_LoadArray[nSpareLoadArray[i]].bInSpareSourceRange=1;
		}
	}

	printf("    Node=%d\n", m_RData.m_NodeArray.size());
	printf("    Comp=%d\n", m_RData.m_CompArray.size());
	printf("    Load=%d\n", m_RData.m_LoadArray.size());

	ReadData_FormCommonModel();
}

void CDNRNetData::ReadData_FormCommonModel()
{
	int		nComp;

	for	(nComp=0; nComp<(int)m_RData.m_CompArray.size(); nComp++)
		m_RData.m_CompArray[nComp].bExcision=(m_RData.m_CompArray[nComp].nDevTyp == PG_BREAKER || m_RData.m_CompArray[nComp].nDevTyp == PG_DISCONNECTOR) ? 1 : 0;

	//	1���������豸������ͨ�豸�����������߽�Ϊ��·�������뿪�صȿ����豸
	//		��������С·�������޿ɿ��Բ�����·������ͨ�豸��Ϊ����·
	for	(nComp=0; nComp<(int)m_RData.m_CompArray.size(); nComp++)
	{
		m_RData.m_CompArray[nComp].sLnkDevArray.clear();
		TraverseLinkComp(nComp, m_RData.m_CompArray[nComp].nNewIniNode, m_RData.m_CompArray[nComp].sLnkDevArray);
		if (m_RData.m_CompArray[nComp].nNewIniNode != m_RData.m_CompArray[nComp].nNewEndNode)
			TraverseLinkComp(nComp, m_RData.m_CompArray[nComp].nNewEndNode, m_RData.m_CompArray[nComp].sLnkDevArray);
	}

	for	(nComp=0; nComp<(int)m_RData.m_CompArray.size(); nComp++)
		m_RData.m_CompArray[nComp].bExcision=m_RData.m_CompArray[nComp].bCmBreaker ? 1 : 0;

	//	2�������ж�·�����й��Ϲ�ģ�豸�����������߽�Ϊ��·��
	for	(nComp=0; nComp<(int)m_RData.m_CompArray.size(); nComp++)
	{
		m_RData.m_CompArray[nComp].sFCmDevArray.clear();
		if (!m_RData.m_CompArray[nComp].bCmBreaker)	continue;

		if (m_RData.m_CompArray[nComp].bSourceZ)
			TraceCommComp(nComp, m_RData.m_CompArray[nComp].nNewIniNode, m_RData.m_CompArray[nComp].sFCmDevArray);
		if (m_RData.m_CompArray[nComp].nNewIniNode != m_RData.m_CompArray[nComp].nNewEndNode)
		{
			if (m_RData.m_CompArray[nComp].bSourceI)
				TraceCommComp(nComp, m_RData.m_CompArray[nComp].nNewEndNode, m_RData.m_CompArray[nComp].sFCmDevArray);
		}
	}

	for	(nComp=0; nComp<(int)m_RData.m_CompArray.size(); nComp++)
		m_RData.m_CompArray[nComp].bExcision=0;

	//	3���Ӷ�·����ʼ���й��϶�λ����ʱ�����
	//		A��������·���Ĺ�ģ�����豸��
	//		B����ÿ����ģ�����豸���·���������·��������
	//		C���������豸�Ĺ��ϸ���ʱ������ۼӡ�

#ifdef _DEBUG
	register int	i;
	for	(nComp=0; nComp<(int)m_RData.m_CompArray.size(); nComp++)
	{
		Log(g_lpszLogFile,  "�����豸[%s] = %s INode=%d ZNode=%d\n", PGGetTableDesp(m_RData.m_CompArray[nComp].nDevTyp), m_RData.m_CompArray[nComp].strName.c_str(), m_RData.m_CompArray[nComp].nNewIniNode, m_RData.m_CompArray[nComp].nNewEndNode);
		for (i=0; i<(int)m_RData.m_CompArray[nComp].sLnkDevArray.size(); i++)
			Log(g_lpszLogFile,  "    ��ͨ�豸[%d]=%s \n", i+1, m_RData.m_CompArray[m_RData.m_CompArray[nComp].sLnkDevArray[i].nDevice].strName.c_str());
		for (i=0; i<(int)m_RData.m_CompArray[nComp].sFCmDevArray.size(); i++)
			Log(g_lpszLogFile,  "    ���Ϲ�ģ�豸[%d]=%s \n", i+1, m_RData.m_CompArray[m_RData.m_CompArray[nComp].sFCmDevArray[i].nDevice].strName.c_str());
	}
#endif
}
