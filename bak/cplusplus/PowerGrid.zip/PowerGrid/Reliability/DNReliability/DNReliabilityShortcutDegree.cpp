#include "stdafx.h"
#include "DNReliability.h"

void CDNREstimate::FormShortcutDegree3To2(const int nMCut, const int nFCmBreaker, const int nComp1, const int nComp2)
{
	double	fR, fT, fR1, fT1, fR2, fT2;

	if (isInFcmComp(nFCmBreaker, nComp1) || isInFcmComp(nFCmBreaker, nComp2))
	{
		if (!isInMCut02(nComp1, nComp2) && !isInDegreeMCut02(nComp1, nComp2))
		{
			fR1=m_CompArray[nComp1].fRerr;
			fR2=m_CompArray[nComp2].fRerr;
			fT1=m_CompArray[nComp1].fTrep;
			fT2=m_CompArray[nComp2].fTrep;

			fR=fR1*fR2*(fT1+fT2)/8760;
			fT=0;
			if (8760*fR > FLT_MIN)
				fT=(fR1*fR2*fT1*fT2)/(8760*fR);

			if (fT > FLT_MIN && fR > FLT_MIN)
			{
				m_MCutO3Array[nMCut].nCutType = DNREnumCutType_3Degree2;
				m_MCutO3Array[nMCut].bDegreed = 1;

				m_MCutO3Array[nMCut].nDegreeFComp[0] = nComp1;
				m_MCutO3Array[nMCut].nDegreeFComp[1] = nComp2;
			}
#ifdef _DEBUG
			Log(g_lpszLogFile,  "    ���׸���ؽ�Ϊ���� : [%s %s %s]\n", m_CompArray[nFCmBreaker].strName.c_str(), m_CompArray[nComp1].strName.c_str(), m_CompArray[nComp2].strName.c_str());
#endif
		}
	}
}

void CDNREstimate::FormShortcutDegree3To1(const int nMCut, const int nFCmBreaker1, const int nFCmBreaker2, const int nComp)
{
	double	fR, fT;

	if (isInMCut01(nComp))
		return;

	if (!(isInFcmComp(nFCmBreaker1, nComp) && isInFcmComp(nFCmBreaker2, nComp)))
		return;

	if (!isInDegreeMCut01(nComp))
	{
		fR=m_CompArray[nComp].fRerr;
		fT=m_CompArray[nComp].fTrep;

		if (fT > FLT_MIN && fR > FLT_MIN)
		{
			m_MCutO3Array[nMCut].nCutType = DNREnumCutType_3Degree1;
// 			m_MCutO3Array[nMCut].fDegreeT = (m_MCutO3Array[nMCut].fDegreeT*m_MCutO3Array[nMCut].fDegreeR+fR*fT)/(m_MCutO3Array[nMCut].fDegreeR+fR);
// 			m_MCutO3Array[nMCut].fDegreeR += fR;
			m_MCutO3Array[nMCut].bDegreed = 2;
			m_MCutO3Array[nMCut].nDegreeFComp[0] = nComp;
			m_MCutO3Array[nMCut].nDegreeFComp[1] = -1;
		}
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ���׸�˫���ؽ�Ϊһ�� : [%s %s %s]\n", m_CompArray[nFCmBreaker1].strName.c_str(), m_CompArray[nFCmBreaker2].strName.c_str(), m_CompArray[nComp].strName.c_str());
#endif
	}
}

//	�ɶ�·���ҹ�ģ�豸�Ӷ��γɽ��ף����������ڸ����������Ҫ������С·�γɵĸ֧��
//		�򵥶��Խ���ʵ���ǵ��豸���ס����׸����豸�Ƕ�·���Ĺ�ģ���γɽ���
//3.3.4��ģ����
void CDNREstimate::FormShortcutDegree()
{
	register int	i;
	double	fR, fT;
	int		nFComp, nSComp, nTComp;

	//һ�׸������

	//���ף���ģ�豸���޸�ʱ����Ҫ�ù��϶�λʱ��
	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
// 		m_MCutO2Array[i].fDegreeR=0;
// 		m_MCutO2Array[i].fDegreeT=0;
		m_MCutO2Array[i].bDegreed=0;
		m_MCutO2Array[i].nDegreeFComp=-1;

		nFComp=m_MCutO2Array[i].nComp[0];
		nSComp=m_MCutO2Array[i].nComp[1];

// #ifdef _DEBUG
// 		Log(g_lpszLogFile,  "Degree ���׸� : [%s %s]\n", m_CompArray[nFComp].strCompName.c_str(), m_CompArray[nSComp].strCompName.c_str());
// #endif

		if (m_CompArray[nFComp].bCmBreaker && isInFcmComp(nFComp, nSComp))
		{
			if (!isInMCut01(nSComp) && !isInDegreeMCut01(nSComp))
			{
				fR=m_CompArray[nSComp].fRerr;
				fT=(m_CompArray[nSComp].fTFLoc <= m_CompArray[nSComp].fTrep || m_CompArray[nSComp].fTrep < FLT_MIN) ? m_CompArray[nSComp].fTFLoc : m_CompArray[nSComp].fTrep;

				if (fT > FLT_MIN && fR > FLT_MIN)
				{
					m_MCutO2Array[i].nCutType = DNREnumCutType_2Degree1;
// 					m_MCutO2Array[i].fDegreeT = (m_MCutO2Array[i].fDegreeT*m_MCutO2Array[i].fDegreeR+fR*fT)/(m_MCutO2Array[i].fDegreeR+fR);
// 					m_MCutO2Array[i].fDegreeR += fR;
					m_MCutO2Array[i].bDegreed = 1;
					m_MCutO2Array[i].nDegreeFComp=nSComp;
#ifdef _DEBUG
					Log(g_lpszLogFile,  "    1�����׸��Ϊһ�׸� : [%s %s] R=%f T=%f\n", m_CompArray[nFComp].strName.c_str(), m_CompArray[nSComp].strName.c_str(), fR, fT);
#endif
				}
			}
		}
		if (m_CompArray[nSComp].bCmBreaker && isInFcmComp(nSComp, nFComp))
		{
			if (!isInDegreeMCut01(nFComp) && !isInMCut01(nFComp))
			{
				fR=m_CompArray[nFComp].fRerr;
				fT=(m_CompArray[nFComp].fTFLoc < m_CompArray[nFComp].fTrep || m_CompArray[nFComp].fTrep < FLT_MIN) ? m_CompArray[nFComp].fTFLoc : m_CompArray[nFComp].fTrep;

				if (fT > FLT_MIN && fR > FLT_MIN)
				{
					m_MCutO2Array[i].nCutType = DNREnumCutType_2Degree1;
// 					m_MCutO2Array[i].fDegreeT = (m_MCutO2Array[i].fDegreeT*m_MCutO2Array[i].fDegreeR+fR*fT)/(m_MCutO2Array[i].fDegreeR+fR);
// 					m_MCutO2Array[i].fDegreeR += fR;
					m_MCutO2Array[i].bDegreed = 1;
					m_MCutO2Array[i].nDegreeFComp=nFComp;
#ifdef _DEBUG
					Log(g_lpszLogFile,  "    2�����׸��Ϊһ�׸� : [%s %s] R=%f T=%f\n", m_CompArray[nSComp].strName.c_str(), m_CompArray[nFComp].strName.c_str(), fR, fT);
#endif
				}
			}
		}

	}

	//���ף�
	//	����Ϊ����ʱ��ģ�豸���޸�ʱ����Ҫ�ù��϶�λʱ��
	//	����Ϊһ��ʱ��ģ�豸���޸�ʱ����Ҫ����С���϶�λʱ��
	//	һ�����ؽ�Ϊ����
	//	�������ؽ�Ϊһ��
	//	�������ؽ�Ϊһ�׻����
	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		m_MCutO3Array[i].bDegreed=0;

		nFComp=m_MCutO3Array[i].nComp[0];
		nSComp=m_MCutO3Array[i].nComp[1];
		nTComp=m_MCutO3Array[i].nComp[2];

// #ifdef _DEBUG
// 		Log(g_lpszLogFile,  "Degree ���׸� : [%s %s %s]\n", m_CompArray[nFComp].strCompName.c_str(), m_CompArray[nSComp].strCompName.c_str(), m_CompArray[nTComp].strCompName.c_str());
// #endif

 		//if (!m_CompArray[nFComp].bCmBreaker && !m_CompArray[nSComp].bCmBreaker && !m_CompArray[nTComp].bCmBreaker)
 		//	continue;

		if (m_CompArray[nFComp].bCmBreaker && m_CompArray[nSComp].bCmBreaker)
			FormShortcutDegree3To1(i, nFComp, nSComp, nTComp);
		if (m_CompArray[nFComp].bCmBreaker && m_CompArray[nTComp].bCmBreaker)
			FormShortcutDegree3To1(i, nFComp, nTComp, nSComp);
		if (m_CompArray[nSComp].bCmBreaker && m_CompArray[nTComp].bCmBreaker)
			FormShortcutDegree3To1(i, nSComp, nTComp, nFComp);
		if (m_CompArray[nFComp].bCmBreaker)
			FormShortcutDegree3To2(i, nFComp, nSComp, nTComp);
		if (m_CompArray[nSComp].bCmBreaker)
			FormShortcutDegree3To2(i, nSComp, nFComp, nTComp);
		if (m_CompArray[nTComp].bCmBreaker)
			FormShortcutDegree3To2(i, nTComp, nFComp, nSComp);
	}
}
