#include "stdafx.h"
#include "DNReliability.h"

void CDNREstimate::SpareRevise(tagRMinCutO1* pCut, std::vector<tagRMinPath>& minPath)
{
	register int	i;
	int				nPath, nComp, nNode, nSpareGen;
	std::vector<int>	nJointNodeArray, nJointLoadArray;
	std::vector<int>	nPathCompArray;
	std::vector<double>	fPathCompProbArray;
	double			fP0, fSpareR, fSpareT, fBuf1, fBuf2;
	unsigned char	bInRange;

	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		if (minPath[nPath].nCompArray.empty())
			continue;

		minPath[nPath].fSpareLoad=minPath[nPath].fSpareProb=0;
		nSpareGen=-1;
		nJointNodeArray.clear();
		nJointLoadArray.clear();

		for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
		{
			bInRange=0;
			for (i=0; i<(int)nJointNodeArray.size(); i++)
			{
				if (nJointNodeArray[i] == m_CompArray[minPath[nPath].nCompArray[nComp]].nNewIniNode)
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nJointNodeArray.push_back(m_CompArray[minPath[nPath].nCompArray[nComp]].nNewIniNode);
			bInRange=0;
			for (i=0; i<(int)nJointNodeArray.size(); i++)
			{
				if (nJointNodeArray[i] == m_CompArray[minPath[nPath].nCompArray[nComp]].nNewEndNode)
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nJointNodeArray.push_back(m_CompArray[minPath[nPath].nCompArray[nComp]].nNewEndNode);

#ifdef _DEBUG
			Log(g_lpszLogFile,  "          �������С·[%d-%d]�� %s, %s, %s, %f, %f, %f, %f\n", nPath, nComp,
				PGGetTableName(m_CompArray[minPath[nPath].nCompArray[nComp]].nDevTyp),
				m_CompArray[minPath[nPath].nCompArray[nComp]].strResID.c_str(),
				m_CompArray[minPath[nPath].nCompArray[nComp]].strName.c_str(),
				m_CompArray[minPath[nPath].nCompArray[nComp]].fRerr,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fTrep,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fRchk,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fTchk);
#endif
		}

		for (nNode=0; nNode<(int)nJointNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_LoadArray.size(); i++)
			{
				if (m_LoadArray[i].nNewNode == nJointNodeArray[nNode])
				{
					nJointLoadArray.push_back(i);
					break;
				}
			}
		}
		for (nNode=0; nNode<(int)nJointNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_GenArray.size(); i++)
			{
				if (m_GenArray[i].nDevTyp == PG_SYNCHRONOUSMACHINE)
					continue;
				if (m_GenArray[i].nNewNode == nJointNodeArray[nNode])
				{
					nSpareGen=i;
					break;
				}
			}
		}
		for (i=0; i<(int)nJointLoadArray.size(); i++)
		{
			minPath[nPath].fSpareLoad += m_LoadArray[nJointLoadArray[i]].fP;
		}
		if (nSpareGen >= 0)
		{
			for (i=0; i<g_nConstMaxState-1; i++)
			{
				if (m_GenArray[nSpareGen].fPowerOut[i] <= minPath[nPath].fSpareLoad && minPath[nPath].fSpareLoad < m_GenArray[nSpareGen].fPowerOut[i+1])
				{
					minPath[nPath].fSpareProb=m_GenArray[nSpareGen].fStatProb[i];
					break;
				}
			}
		}
#ifdef _DEBUG
		Log(g_lpszLogFile,  "          ·�ϸ��ɣ�%f Prob��%f\n", minPath[nPath].fSpareLoad, minPath[nPath].fSpareProb);
#endif
	}


	nPathCompArray.clear();
	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
		{
			bInRange=0;
			for (i=0; i<(int)nPathCompArray.size(); i++)
			{
				if (nPathCompArray[i] == minPath[nPath].nCompArray[nComp])
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nPathCompArray.push_back(minPath[nPath].nCompArray[nComp]);
		}
	}

	fPathCompProbArray.resize(nPathCompArray.size(), 0);	//	֧·������С·����
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		fBuf1=fBuf2=1.0;
		for (nPath=0; nPath<(int)minPath.size(); nPath++)
		{
			if (minPath[nPath].nCompArray.empty())
				continue;

			bInRange=0;
			for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
			{
				if (nPathCompArray[i] == minPath[nPath].nCompArray[nComp])
				{
					bInRange=1;
					break;
				}
			}
			if (bInRange)
			{
				fBuf1 *= (1.0-minPath[nPath].fSpareProb);
			}
			else
				fBuf2 *= (1.0-minPath[nPath].fSpareProb);
		}
		fPathCompProbArray[i]=(1.0-fBuf1)*fBuf2;

#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ֧·(%s.%s)�������ʣ�%f\n", PGGetTableName(m_CompArray[nPathCompArray[i]].nDevTyp), m_CompArray[nPathCompArray[i]].strName.c_str(), fPathCompProbArray[i]);
#endif
	}

	fP0=1.0;
	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		if (minPath[nPath].nCompArray.empty())
			continue;
		fP0 *= (1-minPath[nPath].fSpareProb);
	}

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fR;
	fSpareT=pCut->fT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fT*pCut->fR/fSpareR;
	pCut->fR=fSpareR;
	pCut->fT=fSpareT;

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ��������: P0=%f PrevR=%f PostR=%f PrevT=%f PostT=%f\n", fP0, pCut->fR, fSpareR, pCut->fT, fSpareT);
#endif

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fFaultT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fFaultR;
	fSpareT=pCut->fFaultT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fFaultT*pCut->fFaultR/fSpareR;
	pCut->fFaultR=fSpareR;
	pCut->fFaultT=fSpareT;

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fArrangeT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fArrangeR;
	fSpareT=pCut->fArrangeT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fArrangeT*pCut->fArrangeR/fSpareR;
	pCut->fArrangeR=fSpareR;
	pCut->fArrangeT=fSpareT;

}

void CDNREstimate::SpareRevise(tagRMinCutO2* pCut, std::vector<tagRMinPath>& minPath)
{
	register int	i;
	int				nPath, nComp, nNode, nSpareGen;
	std::vector<int>	nJointNodeArray, nJointLoadArray;
	std::vector<int>	nPathCompArray;
	std::vector<double>	fPathCompProbArray;
	double			fP0, fSpareR, fSpareT, fBuf1, fBuf2;
	unsigned char	bInRange;

	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		if (minPath[nPath].nCompArray.empty())
			continue;

		minPath[nPath].fSpareLoad=minPath[nPath].fSpareProb=0;
		nSpareGen=-1;
		nJointNodeArray.clear();
		nJointLoadArray.clear();

		for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
		{
			bInRange=0;
			for (i=0; i<(int)nJointNodeArray.size(); i++)
			{
				if (nJointNodeArray[i] == m_CompArray[minPath[nPath].nCompArray[nComp]].nNewIniNode)
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nJointNodeArray.push_back(m_CompArray[minPath[nPath].nCompArray[nComp]].nNewIniNode);
			bInRange=0;
			for (i=0; i<(int)nJointNodeArray.size(); i++)
			{
				if (nJointNodeArray[i] == m_CompArray[minPath[nPath].nCompArray[nComp]].nNewEndNode)
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nJointNodeArray.push_back(m_CompArray[minPath[nPath].nCompArray[nComp]].nNewEndNode);

#ifdef _DEBUG
			Log(g_lpszLogFile,  "          �������С·[%d-%d]�� %s, %s, %s, %f, %f, %f, %f\n", nPath, nComp,
				PGGetTableName(m_CompArray[minPath[nPath].nCompArray[nComp]].nDevTyp),
				m_CompArray[minPath[nPath].nCompArray[nComp]].strResID.c_str(),
				m_CompArray[minPath[nPath].nCompArray[nComp]].strName.c_str(),
				m_CompArray[minPath[nPath].nCompArray[nComp]].fRerr,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fTrep,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fRchk,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fTchk);
#endif
		}

		for (nNode=0; nNode<(int)nJointNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_LoadArray.size(); i++)
			{
				if (m_LoadArray[i].nNewNode == nJointNodeArray[nNode])
				{
					nJointLoadArray.push_back(i);
					break;
				}
			}
		}
		for (nNode=0; nNode<(int)nJointNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_GenArray.size(); i++)
			{
				if (m_GenArray[i].nDevTyp == PG_SYNCHRONOUSMACHINE)
					continue;
				if (m_GenArray[i].nNewNode == nJointNodeArray[nNode])
				{
					nSpareGen=i;
					break;
				}
			}
		}
		for (i=0; i<(int)nJointLoadArray.size(); i++)
		{
			minPath[nPath].fSpareLoad += m_LoadArray[nJointLoadArray[i]].fP;
		}
		if (nSpareGen >= 0)
		{
			for (i=0; i<g_nConstMaxState-1; i++)
			{
				if (m_GenArray[nSpareGen].fPowerOut[i] <= minPath[nPath].fSpareLoad && minPath[nPath].fSpareLoad < m_GenArray[nSpareGen].fPowerOut[i+1])
				{
					minPath[nPath].fSpareProb=m_GenArray[nSpareGen].fStatProb[i];
					break;
				}
			}
		}
#ifdef _DEBUG
		Log(g_lpszLogFile,  "          ·�ϸ��ɣ�%f Prob��%f\n", minPath[nPath].fSpareLoad, minPath[nPath].fSpareProb);
#endif
	}


	nPathCompArray.clear();
	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
		{
			bInRange=0;
			for (i=0; i<(int)nPathCompArray.size(); i++)
			{
				if (nPathCompArray[i] == minPath[nPath].nCompArray[nComp])
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nPathCompArray.push_back(minPath[nPath].nCompArray[nComp]);
		}
	}

	fPathCompProbArray.resize(nPathCompArray.size(), 0);	//	֧·������С·����
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		fBuf1=fBuf2=1.0;
		for (nPath=0; nPath<(int)minPath.size(); nPath++)
		{
			if (minPath[nPath].nCompArray.empty())
				continue;

			bInRange=0;
			for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
			{
				if (nPathCompArray[i] == minPath[nPath].nCompArray[nComp])
				{
					bInRange=1;
					break;
				}
			}
			if (bInRange)
			{
				fBuf1 *= (1.0-minPath[nPath].fSpareProb);
			}
			else
				fBuf2 *= (1.0-minPath[nPath].fSpareProb);
		}
		fPathCompProbArray[i]=(1.0-fBuf1)*fBuf2;

#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ֧·(%s.%s)�������ʣ�%f\n", PGGetTableName(m_CompArray[nPathCompArray[i]].nDevTyp) , m_CompArray[nPathCompArray[i]].strName.c_str(), fPathCompProbArray[i]);
#endif
	}

	fP0=1.0;
	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		if (minPath[nPath].nCompArray.empty())
			continue;
		fP0 *= (1-minPath[nPath].fSpareProb);
	}

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}

	fSpareR=(fP0+fBuf1)*pCut->fR;
	fSpareT=pCut->fT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fT*pCut->fR/fSpareR;
	pCut->fR=fSpareR;
	pCut->fT=fSpareT;

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ��������: P0=%f PrevR=%f PostR=%f PrevT=%f PostT=%f\n", fP0, pCut->fR, fSpareR, pCut->fT, fSpareT);
#endif

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fFaultT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fFaultR;
	fSpareT=pCut->fFaultT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fFaultT*pCut->fFaultR/fSpareR;
	pCut->fFaultR=fSpareR;
	pCut->fFaultT=fSpareT;

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fArrangeT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fArrangeR;
	fSpareT=pCut->fArrangeT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fArrangeT*pCut->fArrangeR/fSpareR;
	pCut->fArrangeR=fSpareR;
	pCut->fArrangeT=fSpareT;
}

void CDNREstimate::SpareRevise(tagRMinCutO3* pCut, std::vector<tagRMinPath>& minPath)
{
	register int	i;
	int				nPath, nComp, nNode, nSpareGen;
	std::vector<int>	nJointNodeArray, nJointLoadArray;
	std::vector<int>	nPathCompArray;
	std::vector<double>	fPathCompProbArray;
	double			fP0, fSpareR, fSpareT, fBuf1, fBuf2;
	unsigned char	bInRange;

	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		if (minPath[nPath].nCompArray.empty())
			continue;

		minPath[nPath].fSpareLoad=minPath[nPath].fSpareProb=0;
		nSpareGen=-1;
		nJointNodeArray.clear();
		nJointLoadArray.clear();

		for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
		{
			bInRange=0;
			for (i=0; i<(int)nJointNodeArray.size(); i++)
			{
				if (nJointNodeArray[i] == m_CompArray[minPath[nPath].nCompArray[nComp]].nNewIniNode)
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nJointNodeArray.push_back(m_CompArray[minPath[nPath].nCompArray[nComp]].nNewIniNode);
			bInRange=0;
			for (i=0; i<(int)nJointNodeArray.size(); i++)
			{
				if (nJointNodeArray[i] == m_CompArray[minPath[nPath].nCompArray[nComp]].nNewEndNode)
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nJointNodeArray.push_back(m_CompArray[minPath[nPath].nCompArray[nComp]].nNewEndNode);

#ifdef _DEBUG
			Log(g_lpszLogFile,  "          �������С·[%d-%d]�� %s, %s, %s, %f, %f, %f, %f\n", nPath, nComp,
				PGGetTableName(m_CompArray[minPath[nPath].nCompArray[nComp]].nDevTyp),
				m_CompArray[minPath[nPath].nCompArray[nComp]].strResID.c_str(),
				m_CompArray[minPath[nPath].nCompArray[nComp]].strName.c_str(),
				m_CompArray[minPath[nPath].nCompArray[nComp]].fRerr,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fTrep,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fRchk,
				m_CompArray[minPath[nPath].nCompArray[nComp]].fTchk);
#endif
		}

		for (nNode=0; nNode<(int)nJointNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_LoadArray.size(); i++)
			{
				if (m_LoadArray[i].nNewNode == nJointNodeArray[nNode])
				{
					nJointLoadArray.push_back(i);
					break;
				}
			}
		}
		for (nNode=0; nNode<(int)nJointNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_GenArray.size(); i++)
			{
				if (m_GenArray[i].nDevTyp == PG_SYNCHRONOUSMACHINE)
					continue;
				if (m_GenArray[i].nNewNode == nJointNodeArray[nNode])
				{
					nSpareGen=i;
					break;
				}
			}
		}
		for (i=0; i<(int)nJointLoadArray.size(); i++)
		{
			minPath[nPath].fSpareLoad += m_LoadArray[nJointLoadArray[i]].fP;
		}
		if (nSpareGen >= 0)
		{
			for (i=0; i<g_nConstMaxState-1; i++)
			{
				if (m_GenArray[nSpareGen].fPowerOut[i] <= minPath[nPath].fSpareLoad && minPath[nPath].fSpareLoad < m_GenArray[nSpareGen].fPowerOut[i+1])
				{
					minPath[nPath].fSpareProb=m_GenArray[nSpareGen].fStatProb[i];
					break;
				}
			}
		}
#ifdef _DEBUG
		Log(g_lpszLogFile,  "          ·�ϸ��ɣ�%f Prob��%f\n", minPath[nPath].fSpareLoad, minPath[nPath].fSpareProb);
#endif
	}


	nPathCompArray.clear();
	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
		{
			bInRange=0;
			for (i=0; i<(int)nPathCompArray.size(); i++)
			{
				if (nPathCompArray[i] == minPath[nPath].nCompArray[nComp])
				{
					bInRange=1;
					break;
				}
			}
			if (!bInRange)
				nPathCompArray.push_back(minPath[nPath].nCompArray[nComp]);
		}
	}

	fPathCompProbArray.resize(nPathCompArray.size(), 0);	//	֧·������С·����
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		fBuf1=fBuf2=1.0;
		for (nPath=0; nPath<(int)minPath.size(); nPath++)
		{
			if (minPath[nPath].nCompArray.empty())
				continue;

			bInRange=0;
			for (nComp=0; nComp<(int)minPath[nPath].nCompArray.size(); nComp++)
			{
				if (nPathCompArray[i] == minPath[nPath].nCompArray[nComp])
				{
					bInRange=1;
					break;
				}
			}
			if (bInRange)
				fBuf1 *= (1.0-minPath[nPath].fSpareProb);
			else
				fBuf2 *= (1.0-minPath[nPath].fSpareProb);
		}
		fPathCompProbArray[i]=(1.0-fBuf1)*fBuf2;

#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ֧·(%s.%s)�������ʣ�%f\n", PGGetTableName(m_CompArray[nPathCompArray[i]].nDevTyp), m_CompArray[nPathCompArray[i]].strName.c_str(), fPathCompProbArray[i]);
#endif
	}

	fP0=1.0;
	for (nPath=0; nPath<(int)minPath.size(); nPath++)
	{
		if (minPath[nPath].nCompArray.empty())
			continue;
		fP0 *= (1-minPath[nPath].fSpareProb);
	}

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}

	fSpareR=(fP0+fBuf1)*pCut->fR;
	fSpareT=pCut->fT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fT*pCut->fR/fSpareR;
	pCut->fR=fSpareR;
	pCut->fT=fSpareT;

#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ��������: P0=%f PrevR=%f PostR=%f PrevT=%f PostT=%f\n", fP0, pCut->fR, fSpareR, pCut->fT, fSpareT);
#endif

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fFaultT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fFaultR;
	fSpareT=pCut->fFaultT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fFaultT*pCut->fFaultR/fSpareR;
	pCut->fFaultR=fSpareR;
	pCut->fFaultT=fSpareT;

	fBuf1=fBuf2=0;
	for (i=0; i<(int)nPathCompArray.size(); i++)
	{
		nComp=nPathCompArray[i];
		fBuf1 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*(pCut->fArrangeT+m_CompArray[nComp].fTrep)/8760;
		fBuf2 += fPathCompProbArray[i]*m_CompArray[nComp].fRerr*m_CompArray[nComp].fTrep/8760;
	}
	fSpareR=(fP0+fBuf1)*pCut->fArrangeR;
	fSpareT=pCut->fArrangeT;
	if (fSpareR > FLT_MIN)
		fSpareT=(fP0+fBuf2)*pCut->fArrangeT*pCut->fArrangeR/fSpareR;
	pCut->fArrangeR=fSpareR;
	pCut->fArrangeT=fSpareT;
}

int CDNREstimate::FormSpareMinPath(const int nLoad, const int nSourceType, std::vector<int>& nExCompArray, std::vector<tagRMinPath>& sMinPathArray)
{
	register int	i;
	int		nNode;
	std::vector<int>	nNodeArray, nUnitNodeArray;
	unsigned char	bJointUnit;
	clock_t	dBeg, dEnd;
	int		nDur;

	//Log(g_lpszLogFile,  "        FormSpareMinPath: %s %s\n", pPGBlock->m_EnergyConsumerArray[m_LoadArray[nLoad].nDevIdx].szSub, pPGBlock->m_EnergyConsumerArray[m_LoadArray[nLoad].nDevIdx].szName);
	for (i=0; i<(int)m_CompArray.size(); i++)
		m_CompArray[i].bExcision=0;
	for (i=0; i<(int)nExCompArray.size(); i++)
	{
		m_CompArray[nExCompArray[i]].bExcision=1;
		//Log(g_lpszLogFile,  "        ExComp[%d]= %s\n", i, m_CompArray[nExCompArray[i]].szName);
	}

	sMinPathArray.clear();

	nUnitNodeArray.clear();
	TraverseRangeNode(m_LoadArray[nLoad].nNewNode, nSourceType, nNodeArray);
	if (nNodeArray.size() <= 1)
		return 0;
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (m_NodeArray[nNodeArray[i]].nNodeTyp == nSourceType)
			nUnitNodeArray.push_back(nNodeArray[i]);
	}

	bJointUnit=0;
	for (nNode=0; nNode<(int)nUnitNodeArray.size(); nNode++)
	{
		if (m_LoadArray[nLoad].nNewNode == nUnitNodeArray[nNode])
		{
			bJointUnit=1;
			break;
		}
	}
	if (bJointUnit)
		return 0;

	dBeg=clock();
	if (!m_AlgDisJoint.DisJoint_Init(m_NodeArray, m_CompArray, m_LoadArray[nLoad].nNewNode, nNodeArray))
		return 0;

	for (nNode=0; nNode<(int)nUnitNodeArray.size(); nNode++)
	{
		m_AlgDisJoint.DisJoint_Calc(nUnitNodeArray[nNode], nNodeArray);
		m_AlgDisJoint.DisJoint2MinPath(m_NodeArray, m_CompArray, nNodeArray, sMinPathArray);
	}
	ExtendMinPath(1, sMinPathArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
#ifdef _DEBUG
	Log(g_lpszLogFile,  "    ������С·(MinPath)��ɣ���ʱ%d����\n", nDur);
#endif

	for (i=0; i<(int)m_CompArray.size(); i++)
		m_CompArray[i].bExcision=0;

	return 1;
}

void	CDNREstimate::SpareMinPath(const int nLoad)
{
	register int	i;
	int		nMCut;
	std::vector<int>	nExCompArray;

	for (nMCut=0; nMCut<(int)m_MCutO1Array.size(); nMCut++)
	{
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    һ����С��[%d/%d]�� %s, %s, %s\n", nMCut, m_MCutO1Array.size(), PGGetTableName(m_CompArray[m_MCutO1Array[nMCut].nComp].nDevTyp), m_CompArray[m_MCutO1Array[nMCut].nComp].strResID.c_str(), m_CompArray[m_MCutO1Array[nMCut].nComp].strName.c_str());
#endif
		nExCompArray.clear();
		m_MCutO1Array[nMCut].sMinSparePathArray.clear();
		if (m_CompArray[m_MCutO1Array[nMCut].nComp].nDevTyp == PG_BUSBARSECTION || m_CompArray[m_MCutO1Array[nMCut].nComp].nDevTyp == PG_SYNCHRONOUSMACHINE)
		{
			for (i=0; i<(int)m_NodeArray[m_CompArray[m_MCutO1Array[nMCut].nComp].nNewIniNode].nCompArray.size(); i++)
				nExCompArray.push_back(m_NodeArray[m_CompArray[m_MCutO1Array[nMCut].nComp].nNewIniNode].nCompArray[i]);
		}
		else
		{
			nExCompArray.push_back(m_MCutO1Array[nMCut].nComp);
		}
		FormSpareMinPath(nLoad, g_nConstSpareGenNode, nExCompArray, m_MCutO1Array[nMCut].sMinSparePathArray);
		ExtendMinPath(0, m_MCutO1Array[nMCut].sMinSparePathArray);
		SpareRevise(&m_MCutO1Array[nMCut], m_MCutO1Array[nMCut].sMinSparePathArray);
	}

	for (nMCut=0; nMCut<(int)m_MCutO2Array.size(); nMCut++)
	{
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ������С��[%d/%d]�� %s, %s, %s    %s, %s, %s\n", nMCut, m_MCutO2Array.size(),
			PGGetTableName(m_CompArray[m_MCutO2Array[nMCut].nComp[0]].nDevTyp), m_CompArray[m_MCutO2Array[nMCut].nComp[0]].strResID.c_str(), m_CompArray[m_MCutO2Array[nMCut].nComp[0]].strName.c_str(),
			PGGetTableName(m_CompArray[m_MCutO2Array[nMCut].nComp[1]].nDevTyp), m_CompArray[m_MCutO2Array[nMCut].nComp[1]].strResID.c_str(), m_CompArray[m_MCutO2Array[nMCut].nComp[1]].strName.c_str());
#endif

		nExCompArray.clear();
		m_MCutO2Array[nMCut].sMinSparePathArray.clear();
		if (m_CompArray[m_MCutO2Array[nMCut].nComp[0]].nDevTyp == PG_BUSBARSECTION || m_CompArray[m_MCutO2Array[nMCut].nComp[0]].nDevTyp == PG_SYNCHRONOUSMACHINE)
		{
			for (i=0; i<(int)m_NodeArray[m_CompArray[m_MCutO2Array[nMCut].nComp[0]].nNewIniNode].nCompArray.size(); i++)
				nExCompArray.push_back(m_NodeArray[m_CompArray[m_MCutO2Array[nMCut].nComp[0]].nNewIniNode].nCompArray[i]);
		}
		else
		{
			nExCompArray.push_back(m_MCutO2Array[nMCut].nComp[0]);
		}

		if (m_CompArray[m_MCutO2Array[nMCut].nComp[1]].nDevTyp == PG_BUSBARSECTION || m_CompArray[m_MCutO2Array[nMCut].nComp[1]].nDevTyp == PG_SYNCHRONOUSMACHINE)
		{
			for (i=0; i<(int)m_NodeArray[m_CompArray[m_MCutO2Array[nMCut].nComp[1]].nNewIniNode].nCompArray.size(); i++)
				nExCompArray.push_back(m_NodeArray[m_CompArray[m_MCutO2Array[nMCut].nComp[1]].nNewIniNode].nCompArray[i]);
		}
		else
		{
			nExCompArray.push_back(m_MCutO2Array[nMCut].nComp[1]);
		}
		FormSpareMinPath(nLoad, g_nConstSpareGenNode, nExCompArray, m_MCutO2Array[nMCut].sMinSparePathArray);
		ExtendMinPath(0, m_MCutO2Array[nMCut].sMinSparePathArray);
		SpareRevise(&m_MCutO2Array[nMCut], m_MCutO2Array[nMCut].sMinSparePathArray);
	}

	for (nMCut=0; nMCut<(int)m_MCutO3Array.size(); nMCut++)
	{
#ifdef _DEBUG
		Log(g_lpszLogFile,  "    ������С��[%d/%d]�� %s, %s, %s    %s, %s, %s    %s, %s, %s\n", nMCut, m_MCutO3Array.size(),
			PGGetTableName(m_CompArray[m_MCutO3Array[nMCut].nComp[0]].nDevTyp), m_CompArray[m_MCutO3Array[nMCut].nComp[0]].strResID.c_str(), m_CompArray[m_MCutO3Array[nMCut].nComp[0]].strName.c_str(),
			PGGetTableName(m_CompArray[m_MCutO3Array[nMCut].nComp[1]].nDevTyp), m_CompArray[m_MCutO3Array[nMCut].nComp[1]].strResID.c_str(), m_CompArray[m_MCutO3Array[nMCut].nComp[1]].strName.c_str(),
			PGGetTableName(m_CompArray[m_MCutO3Array[nMCut].nComp[2]].nDevTyp), m_CompArray[m_MCutO3Array[nMCut].nComp[2]].strResID.c_str(), m_CompArray[m_MCutO3Array[nMCut].nComp[2]].strName.c_str());
#endif
		nExCompArray.clear();
		m_MCutO3Array[nMCut].sMinSparePathArray.clear();
		if (m_CompArray[m_MCutO3Array[nMCut].nComp[0]].nDevTyp == PG_BUSBARSECTION || m_CompArray[m_MCutO3Array[nMCut].nComp[0]].nDevTyp == PG_SYNCHRONOUSMACHINE)
		{
			for (i=0; i<(int)m_NodeArray[m_CompArray[m_MCutO3Array[nMCut].nComp[0]].nNewIniNode].nCompArray.size(); i++)
				nExCompArray.push_back(m_NodeArray[m_CompArray[m_MCutO3Array[nMCut].nComp[0]].nNewIniNode].nCompArray[i]);
		}
		else
		{
			nExCompArray.push_back(m_MCutO3Array[nMCut].nComp[0]);
		}

		if (m_CompArray[m_MCutO3Array[nMCut].nComp[1]].nDevTyp == PG_BUSBARSECTION || m_CompArray[m_MCutO3Array[nMCut].nComp[1]].nDevTyp == PG_SYNCHRONOUSMACHINE)
		{
			for (i=0; i<(int)m_NodeArray[m_CompArray[m_MCutO3Array[nMCut].nComp[1]].nNewIniNode].nCompArray.size(); i++)
				nExCompArray.push_back(m_NodeArray[m_CompArray[m_MCutO3Array[nMCut].nComp[1]].nNewIniNode].nCompArray[i]);
		}
		else
		{
			nExCompArray.push_back(m_MCutO3Array[nMCut].nComp[1]);
		}

		if (m_CompArray[m_MCutO3Array[nMCut].nComp[2]].nDevTyp == PG_BUSBARSECTION || m_CompArray[m_MCutO3Array[nMCut].nComp[2]].nDevTyp == PG_SYNCHRONOUSMACHINE)
		{
			for (i=0; i<(int)m_NodeArray[m_CompArray[m_MCutO3Array[nMCut].nComp[2]].nNewIniNode].nCompArray.size(); i++)
				nExCompArray.push_back(m_NodeArray[m_CompArray[m_MCutO3Array[nMCut].nComp[2]].nNewIniNode].nCompArray[i]);
		}
		else
		{
			nExCompArray.push_back(m_MCutO3Array[nMCut].nComp[2]);
		}
		FormSpareMinPath(nLoad, g_nConstSpareGenNode, nExCompArray, m_MCutO3Array[nMCut].sMinSparePathArray);
		ExtendMinPath(0, m_MCutO3Array[nMCut].sMinSparePathArray);
		SpareRevise(&m_MCutO3Array[nMCut], m_MCutO3Array[nMCut].sMinSparePathArray);
	}
}

void	CDNREstimate::SpareMinPathRevise()
{
	register int		i;

	for (i=0; i<(int)m_MCutO1Array.size(); i++)
		SpareRevise(&m_MCutO1Array[i], m_MCutO1Array[i].sMinSparePathArray);

	for (i=0; i<(int)m_MCutO2Array.size(); i++)
		SpareRevise(&m_MCutO2Array[i], m_MCutO2Array[i].sMinSparePathArray);

	for (i=0; i<(int)m_MCutO3Array.size(); i++)
		SpareRevise(&m_MCutO3Array[i], m_MCutO3Array[i].sMinSparePathArray);
}
