#include "stdafx.h"
#include <io.h>
#include "DNReliability.h"
#include "../../../Common/SemaphoreCommon.h"

void CDNREstimate::SaveLoadRResult(const int nLoad, const char* lpszRResultFile)
{
	if (!lpszRResultFile)
		return;
	if (strlen(lpszRResultFile) <= 0)
		return;

	TiXmlElement*	pLoadElement= new TiXmlElement("EnergyConsumerReliablityResult");

	pLoadElement->SetAttribute("ResID",			m_LoadArray[nLoad].strResID);
	pLoadElement->SetAttribute("Name",			m_LoadArray[nLoad].strName.c_str());
	pLoadElement->SetAttribute("SubcontrolArea", m_LoadArray[nLoad].strSubcontrolArea.c_str());
	pLoadElement->SetAttribute("Substation",	m_LoadArray[nLoad].strSubstation.c_str());
	pLoadElement->SetDoubleAttribute("P",		m_LoadArray[nLoad].fP);
	pLoadElement->SetDoubleAttribute("Customer",m_LoadArray[nLoad].fCustomer);
	pLoadElement->SetDoubleAttribute("R",		m_LoadArray[nLoad].fR);
	pLoadElement->SetDoubleAttribute("U",		m_LoadArray[nLoad].fU);
	pLoadElement->SetDoubleAttribute("T",		m_LoadArray[nLoad].fT);
	pLoadElement->SetDoubleAttribute("FR",		m_LoadArray[nLoad].fFaultR);
	pLoadElement->SetDoubleAttribute("FU",		m_LoadArray[nLoad].fFaultU);
	pLoadElement->SetDoubleAttribute("FT",		m_LoadArray[nLoad].fFaultT);
	pLoadElement->SetDoubleAttribute("AR",		m_LoadArray[nLoad].fArrangeR);
	pLoadElement->SetDoubleAttribute("AU",		m_LoadArray[nLoad].fArrangeU);
	pLoadElement->SetDoubleAttribute("AT",		m_LoadArray[nLoad].fArrangeT);
	pLoadElement->SetDoubleAttribute("CMR",		m_LoadArray[nLoad].fCommonR);
	pLoadElement->SetDoubleAttribute("CMU",		m_LoadArray[nLoad].fCommonU);
	pLoadElement->SetDoubleAttribute("CMT",		m_LoadArray[nLoad].fCommonT);
	pLoadElement->SetDoubleAttribute("SWR",		m_LoadArray[nLoad].fSwitchR);
	pLoadElement->SetDoubleAttribute("SWU",		m_LoadArray[nLoad].fSwitchU);
	pLoadElement->SetDoubleAttribute("SWT",		m_LoadArray[nLoad].fSwitchT);
	pLoadElement->SetAttribute("RCCase",		PGGetFieldEnumString(PG_ENERGYCONSUMER, PG_ENERGYCONSUMER_RCCASE, m_LoadArray[nLoad].nRCCase));
	pLoadElement->SetDoubleAttribute("RCTime",	m_LoadArray[nLoad].fRCTime);

	pLoadElement->SetDoubleAttribute("Ens",		m_LoadArray[nLoad].fP*m_LoadArray[nLoad].fU);
	pLoadElement->SetDoubleAttribute("FEns",	m_LoadArray[nLoad].fP*m_LoadArray[nLoad].fFaultU);
	pLoadElement->SetDoubleAttribute("AEns",	m_LoadArray[nLoad].fP*m_LoadArray[nLoad].fArrangeU);

	SaveLoadRResult_MinPath(nLoad, m_MinPathArray, pLoadElement);
	SaveLoadRResult_MCutO1(nLoad, pLoadElement);
	SaveLoadRResult_MCutO2(nLoad, pLoadElement);
	SaveLoadRResult_MCutO3(nLoad, pLoadElement);

	HANDLE hSem = SemOn(g_lpszSysRResultSemaphore, 1000);
	if (hSem != INVALID_HANDLE_VALUE)
	{
		if (access(lpszRResultFile, 0) == 0)
		{
			FILE*	fp=fopen(lpszRResultFile, "a");
			if (fp != NULL)
			{
				pLoadElement->Print(fp, 0);
				fprintf(fp, "\n");
				fflush(fp);
				fclose(fp);
			}
		}
		SemOff(hSem);
	}
	else
	{
		Log(g_lpszLogFile, "��ȡ�����ļ�����������\n");
	}

	pLoadElement->Clear();
	delete pLoadElement;
}

void CDNREstimate::SaveLoadRResult_MinPath(const int nLoad, std::vector<tagRMinPath> minPathArray, TiXmlElement* pLoadElement)
{
	register int	i, j;
	int		nComp;
	TiXmlElement*	pSecElement;
	TiXmlElement*	pAttrElement;

	for (i=0; i<(int)minPathArray.size(); i++)
	{
		if (minPathArray[i].nCompArray.empty())
			continue;

		pSecElement = new TiXmlElement("MinPath");
		pLoadElement->LinkEndChild(pSecElement);
		for (j=0; j<(int)minPathArray[i].nCompArray.size(); j++)
		{
			nComp=minPathArray[i].nCompArray[j];
			if (m_CompArray[nComp].fRerr < FLT_MIN && m_CompArray[nComp].fTrep < FLT_MIN && m_CompArray[nComp].fRchk < FLT_MIN && m_CompArray[nComp].fTchk < FLT_MIN)
				continue;

			pAttrElement = new TiXmlElement("PathComp");
			pSecElement->LinkEndChild(pAttrElement);

			pAttrElement->SetAttribute("Type",		PGGetTableDesp(m_CompArray[nComp].nDevTyp));
			pAttrElement->SetAttribute("ResID",		m_CompArray[nComp].strResID.c_str());
			pAttrElement->SetAttribute("Name",		m_CompArray[nComp].strName.c_str());
			pAttrElement->SetDoubleAttribute("Rerr", m_CompArray[nComp].fRerr);
			pAttrElement->SetDoubleAttribute("Trep", m_CompArray[nComp].fTrep);
			pAttrElement->SetDoubleAttribute("Rchk", m_CompArray[nComp].fRchk);
			pAttrElement->SetDoubleAttribute("Tchk", m_CompArray[nComp].fTchk);
		}
	}
}

void CDNREstimate::SaveLoadRResult_MCutO1(const int nLoad, TiXmlElement* pLoadElement)
{
	register int	i;
	int		nComp;
	int		nBreaker;
	TiXmlElement*	pAttrElement;
	char	szBuf[260];

	for (i=0; i<(int)m_MCutO1Array.size(); i++)
	{
		if (m_MCutO1Array[i].fR < FLT_MIN && m_MCutO1Array[i].fT < FLT_MIN)
			continue;

		nComp=m_MCutO1Array[i].nComp;

		pAttrElement = new TiXmlElement("MinCut01");
		pLoadElement->LinkEndChild(pAttrElement);

		pAttrElement->SetAttribute("CutType", g_lpszCutType[m_MCutO1Array[i].nCutType]);

		pAttrElement->SetAttribute("CompType",	PGGetTableDesp(m_CompArray[nComp].nDevTyp));
		pAttrElement->SetAttribute("CompID",	m_CompArray[nComp].strResID.c_str());
		pAttrElement->SetAttribute("CompName",	m_CompArray[nComp].strName.c_str());

		pAttrElement->SetDoubleAttribute("FR",	m_MCutO1Array[i].fFaultR);
		pAttrElement->SetDoubleAttribute("FT",	m_MCutO1Array[i].fFaultT);
		pAttrElement->SetDoubleAttribute("AR",	m_MCutO1Array[i].fArrangeR);
		pAttrElement->SetDoubleAttribute("AT",	m_MCutO1Array[i].fArrangeT);
		pAttrElement->SetDoubleAttribute("R",	m_MCutO1Array[i].fR);
		pAttrElement->SetDoubleAttribute("T",	m_MCutO1Array[i].fT);
		pAttrElement->SetDoubleAttribute("U",	m_MCutO1Array[i].fU);

		pAttrElement->SetDoubleAttribute("RContribution", m_MCutO1Array[i].fRContribution);
		pAttrElement->SetDoubleAttribute("UContribution", m_MCutO1Array[i].fUContribution);

		SaveLoadRResult_MinPath(nLoad, m_MCutO1Array[i].sMinSparePathArray, pAttrElement);
	}

	for (i=0; i<(int)m_CmMCutO1Array.size(); i++)
	{
		if (m_CmMCutO1Array[i].fR < FLT_MIN && m_CmMCutO1Array[i].fT < FLT_MIN)
			continue;

		nComp=m_CmMCutO1Array[i].nComp;
		nBreaker=m_CmMCutO1Array[i].nBreaker[0];

		pAttrElement = new TiXmlElement("MinCut01");
		pLoadElement->LinkEndChild(pAttrElement);

		pAttrElement->SetAttribute("CutType", g_lpszCutType[m_CmMCutO1Array[i].nCutType]);

		pAttrElement->SetAttribute("CompType",	PGGetTableDesp(m_CompArray[nComp].nDevTyp));
		pAttrElement->SetAttribute("CompID",	m_CompArray[nComp].strResID.c_str());
		pAttrElement->SetAttribute("CompName",	m_CompArray[nComp].strName.c_str());

		for (nBreaker=0; nBreaker<3; nBreaker++)
		{
			if (m_CmMCutO1Array[i].nBreaker[nBreaker] >= 0)
			{
				sprintf(szBuf, "CmBreaker%d", nBreaker+1);
				pAttrElement->SetAttribute(szBuf, m_CompArray[m_CmMCutO1Array[i].nBreaker[nBreaker]].strName.c_str());
			}
		}

		pAttrElement->SetDoubleAttribute("R", m_CmMCutO1Array[i].fR);
		pAttrElement->SetDoubleAttribute("T", m_CmMCutO1Array[i].fT);
		pAttrElement->SetDoubleAttribute("U", m_CmMCutO1Array[i].fU);

		pAttrElement->SetDoubleAttribute("RContribution", m_CmMCutO1Array[i].fRContribution);
		pAttrElement->SetDoubleAttribute("UContribution", m_CmMCutO1Array[i].fUContribution);
	}
}

void CDNREstimate::SaveLoadRResult_MCutO2(const int nLoad, TiXmlElement* pLoadElement)
{
	register int	i;
	int		nComp1, nComp2;
	int		nFComp, nBreaker, nBreaker1, nBreaker2;
	char	szBuf[260];

	TiXmlElement*	pAttrElement;

	for (i=0; i<(int)m_MCutO2Array.size(); i++)
	{
		if (m_MCutO2Array[i].fR < FLT_MIN && m_MCutO2Array[i].fT < FLT_MIN)
			continue;

		nComp1=m_MCutO2Array[i].nComp[0];
		nComp2=m_MCutO2Array[i].nComp[1];

		pAttrElement = new TiXmlElement("MinCut02");
		pLoadElement->LinkEndChild(pAttrElement);

		pAttrElement->SetAttribute("CutType", g_lpszCutType[m_MCutO2Array[i].nCutType]);

		pAttrElement->SetAttribute("Comp1Type",	PGGetTableDesp(m_CompArray[nComp1].nDevTyp));
		pAttrElement->SetAttribute("Comp1ID",	m_CompArray[nComp1].strResID.c_str());
		pAttrElement->SetAttribute("Comp1Name",	m_CompArray[nComp1].strName.c_str());

		pAttrElement->SetAttribute("Comp2Type",	PGGetTableDesp(m_CompArray[nComp2].nDevTyp));
		pAttrElement->SetAttribute("Comp2ID",	m_CompArray[nComp2].strResID.c_str());
		pAttrElement->SetAttribute("Comp2Name",	m_CompArray[nComp2].strName.c_str());

		pAttrElement->SetDoubleAttribute("FR",	1000*m_MCutO2Array[i].fFaultR);
		pAttrElement->SetDoubleAttribute("FT",	m_MCutO2Array[i].fFaultT);
		pAttrElement->SetDoubleAttribute("AR",	1000*m_MCutO2Array[i].fArrangeR);
		pAttrElement->SetDoubleAttribute("AT",	m_MCutO2Array[i].fArrangeT);
		pAttrElement->SetDoubleAttribute("R",	1000*m_MCutO2Array[i].fR);
		pAttrElement->SetDoubleAttribute("T",	m_MCutO2Array[i].fT);
		pAttrElement->SetDoubleAttribute("U",	m_MCutO2Array[i].fU);

		pAttrElement->SetDoubleAttribute("RContribution", m_MCutO2Array[i].fRContribution);
		pAttrElement->SetDoubleAttribute("UContribution", m_MCutO2Array[i].fUContribution);

		if (m_MCutO2Array[i].bDegreed)
		{
			nFComp=m_MCutO2Array[i].nDegreeFComp;
			if (nFComp >= 0)	pAttrElement->SetAttribute("DegreeFComp", m_CompArray[nFComp].strName.c_str());
		}

		SaveLoadRResult_MinPath(nLoad, m_MCutO2Array[i].sMinSparePathArray, pAttrElement);
	}

	for (i=0; i<(int)m_CmMCutO2Array.size(); i++)
	{
		if (m_CmMCutO2Array[i].fR < FLT_MIN && m_CmMCutO2Array[i].fT < FLT_MIN)
			continue;

		nComp1=m_CmMCutO2Array[i].nComp[0];
		nComp2=m_CmMCutO2Array[i].nComp[1];
		nBreaker1=m_CmMCutO2Array[i].nBreaker[0];
		nBreaker2=m_CmMCutO2Array[i].nBreaker[1];

		pAttrElement = new TiXmlElement("MinCut02");
		pLoadElement->LinkEndChild(pAttrElement);

		pAttrElement->SetAttribute("CutType", g_lpszCutType[m_CmMCutO2Array[i].nCutType]);

		pAttrElement->SetAttribute("Comp1Type", PGGetTableDesp(m_CompArray[nComp1].nDevTyp));
		pAttrElement->SetAttribute("Comp1ID", m_CompArray[nComp1].strResID.c_str());
		pAttrElement->SetAttribute("Comp1Name", m_CompArray[nComp1].strName.c_str());

		pAttrElement->SetAttribute("Comp2Type", PGGetTableDesp(m_CompArray[nComp2].nDevTyp));
		pAttrElement->SetAttribute("Comp2ID", m_CompArray[nComp2].strResID.c_str());
		pAttrElement->SetAttribute("Comp2Name", m_CompArray[nComp2].strName.c_str());

		for (nBreaker=0; nBreaker<3; nBreaker++)
		{
			if (m_CmMCutO1Array[i].nBreaker[nBreaker] >= 0)
			{
				sprintf(szBuf, "CmBreaker%d", nBreaker+1);
				pAttrElement->SetAttribute(szBuf, m_CompArray[m_CmMCutO2Array[i].nBreaker[nBreaker]].strName.c_str());
			}
		}

		pAttrElement->SetDoubleAttribute("R", 1000*m_CmMCutO2Array[i].fR);
		pAttrElement->SetDoubleAttribute("T", m_CmMCutO2Array[i].fT);
		pAttrElement->SetDoubleAttribute("U", m_CmMCutO2Array[i].fU);

		pAttrElement->SetDoubleAttribute("RContribution", m_CmMCutO2Array[i].fRContribution);
		pAttrElement->SetDoubleAttribute("UContribution", m_CmMCutO2Array[i].fUContribution);
	}
}

void CDNREstimate::SaveLoadRResult_MCutO3(const int nLoad, TiXmlElement* pLoadElement)
{
	register int	i;
	int		nComp1, nComp2, nComp3;
	int		nFComp1, nFComp2;

	TiXmlElement*	pAttrElement;

	for (i=0; i<(int)m_MCutO3Array.size(); i++)
	{
		if (m_MCutO3Array[i].fR < FLT_MIN && m_MCutO3Array[i].fT < FLT_MIN)
			continue;

		nComp1=m_MCutO3Array[i].nComp[0];
		nComp2=m_MCutO3Array[i].nComp[1];
		nComp3=m_MCutO3Array[i].nComp[2];

		pAttrElement = new TiXmlElement("MinCut03");
		pLoadElement->LinkEndChild(pAttrElement);

		pAttrElement->SetAttribute("CutType", g_lpszCutType[m_MCutO3Array[i].nCutType]);

		pAttrElement->SetAttribute("Comp1Type", PGGetTableDesp(m_CompArray[nComp1].nDevTyp));
		pAttrElement->SetAttribute("Comp1ID", m_CompArray[nComp1].strResID.c_str());
		pAttrElement->SetAttribute("Comp1Name", m_CompArray[nComp1].strName.c_str());

		pAttrElement->SetAttribute("Comp2Type", PGGetTableDesp(m_CompArray[nComp2].nDevTyp));
		pAttrElement->SetAttribute("Comp2ID", m_CompArray[nComp2].strResID.c_str());
		pAttrElement->SetAttribute("Comp2Name", m_CompArray[nComp2].strName.c_str());

		pAttrElement->SetAttribute("Comp3Type", PGGetTableDesp(m_CompArray[nComp3].nDevTyp));
		pAttrElement->SetAttribute("Comp3ID", m_CompArray[nComp3].strResID.c_str());
		pAttrElement->SetAttribute("Comp3Name", m_CompArray[nComp3].strName.c_str());

		pAttrElement->SetDoubleAttribute("FR", 1000*1000*m_MCutO3Array[i].fFaultR);
		pAttrElement->SetDoubleAttribute("FT", m_MCutO3Array[i].fFaultT);
		pAttrElement->SetDoubleAttribute("AR", 1000*1000*m_MCutO3Array[i].fArrangeR);
		pAttrElement->SetDoubleAttribute("AT", m_MCutO3Array[i].fArrangeT);
		pAttrElement->SetDoubleAttribute("R", 1000*1000*m_MCutO3Array[i].fR);
		pAttrElement->SetDoubleAttribute("T", m_MCutO3Array[i].fT);
		pAttrElement->SetDoubleAttribute("U", m_MCutO3Array[i].fU);

		pAttrElement->SetDoubleAttribute("RContribution", m_MCutO3Array[i].fRContribution);
		pAttrElement->SetDoubleAttribute("UContribution", m_MCutO3Array[i].fUContribution);

		if (m_MCutO3Array[i].bDegreed)
		{
			nFComp1=m_MCutO3Array[i].nDegreeFComp[0];
			nFComp2=m_MCutO3Array[i].nDegreeFComp[1];

			if (nFComp1 >= 0)	pAttrElement->SetAttribute("DegreeFComp1", m_CompArray[nFComp1].strName.c_str());
			if (nFComp2 >= 0)	pAttrElement->SetAttribute("DegreeFComp2", m_CompArray[nFComp2].strName.c_str());
		}

		SaveLoadRResult_MinPath(nLoad, m_MCutO3Array[i].sMinSparePathArray, pAttrElement);
	}
}
