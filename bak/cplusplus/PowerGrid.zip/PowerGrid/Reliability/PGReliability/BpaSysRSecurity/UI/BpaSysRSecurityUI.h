
// BpaRSecurityUI.h : PROJECT_NAME Ӧ�ó������ͷ�ļ�
//

#pragma once

#ifndef __AFXWIN_H__
	#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"		// ������

#define	WM_ESTIMATEBEG	WM_APP+1001
#define	WM_ESTIMATING	WM_APP+1002
#define	WM_ESTIMATEEND	WM_APP+1003


// CBpaRSecurityUIApp:
// �йش����ʵ�֣������ BpaRSecurityUI.cpp
//

class CBpaRSecurityUIApp : public CWinAppEx
{
public:
	CBpaRSecurityUIApp();

// ��д
	public:
	virtual BOOL InitInstance();

// ʵ��

	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();
	afx_msg void OnSecurityEstimateBeg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSecurityEstimating(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSecurityEstimateEnd(WPARAM wParam, LPARAM lParam);
};

extern CBpaRSecurityUIApp theApp;
extern tagBpaBlock*			g_pBpaBlock;
extern tagPRBlock*			g_pPRBlock;
extern CPRMemDBInterface	g_PRMemDBInterface;
extern CBpaMemDBInterface	g_BpaMemDBInterface;

extern tagBpaPRSecuritySetting	g_PRSsaSetting;
extern CPRSecurity				g_PRSecurity;
extern char						g_szRunDir[260];

extern	const	char*	g_lpszLogFile;
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	void	ClearLog(const char* lpszLogFile);
extern	void	PrintMessage(char* pformat, ...);

extern	void	ReadIni();
extern	void	SaveIni();
