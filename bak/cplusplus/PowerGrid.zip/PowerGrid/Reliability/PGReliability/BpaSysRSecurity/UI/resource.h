//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BpaSysRSecurityUI.rc
//
#define IDD_BPARSECURITYUI_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_CRITERIA_DIALOG             132
#define IDD_CURVE_SETDIALOG             136
#define IDC_MULTI_THREAD                1001
#define IDC_BPA_WORKDIR                 1014
#define IDC_CRITERIA                    1016
#define IDC_BROWSE_WORKDIR              1020
#define IDC_SAVEAS_EXCEL                1021
#define IDC_CLEAR_MESG                  1022
#define IDC_MESG_LIST                   1070
#define IDC_MAX_ANGLE                   1078
#define IDC_MIN_VOLT                    1080
#define IDC_PROGRESS                    1081
#define IDC_MINV_DURITION               1082
#define IDC_CURVE_COMBO                 1083
#define IDC_MAX_FREQ                    1085
#define IDC_MAX_VOLT                    1088
#define IDC_SECURITY_RESULT             1089
#define IDC_MAXV_DURITION               1091
#define IDC_MIN_FREQ                    1093
#define IDC_MAXF_DURITION               1096
#define IDC_MINF_DURITION               1098
#define IDC_ADEQUACY_FILTER             1099
#define IDC_ADEQUACY_REFRESH            1100
#define IDC_SYSTEM_SECURITY_ANALYSIS    1103
#define IDC_FDEVICE_LIST                1104
#define IDC_STATE_SECURITY_ANALYSIS     1105
#define IDC_SECURITYANALYSIS_MAXSTATE   1115
#define IDC_SECURITYANALYSIS_MINLTFAULT 1120
#define IDC_SECURITYANALYSIS_MAXLTFAULT 1125
#define IDC_LTFAULT_ONLY                1138
#define IDC_BACKGROUND                  1149
#define IDC_FOREGROUND                  1151
#define IDC_CURVE                       1153
#define IDC_TAB                         1155
#define IDC_AXIAS                       1156
#define IDC_XPACE                       1162
#define IDC_REESTIMATE                  1163
#define IDC_YPACE                       1164
#define IDC_CURVE_VISIBLE_SET           1165
#define IDC_MAX_CY                      1170
#define IDC_MIN_CY                      1172
#define IDC_MAX_DT                      1173
#define IDC_MIN_DT                      1175

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
