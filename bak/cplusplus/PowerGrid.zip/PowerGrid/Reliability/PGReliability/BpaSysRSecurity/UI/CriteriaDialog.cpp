// CriteriaDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRSecurityUI.h"
#include "CriteriaDialog.h"

// CCriteriaDialog �Ի���

IMPLEMENT_DYNAMIC(CCriteriaDialog, CDialog)

CCriteriaDialog::CCriteriaDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CCriteriaDialog::IDD, pParent)
{
	m_fMaxAngle=200;
	m_fMaxVolt =1.2;
	m_fMaxVDur =1;
	m_fMinVolt =0.8;
	m_fMinVDur =1;
	m_fMaxFreq =52.5;
	m_fMaxFDur =1;
	m_fMinFreq =47.5;
	m_fMinFDur =1;
}

CCriteriaDialog::~CCriteriaDialog()
{
}

void CCriteriaDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CCriteriaDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCriteriaDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CCriteriaDialog ��Ϣ��������

BOOL CCriteriaDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	char	szBuf[260];

	sprintf(szBuf, "%f", m_fMaxAngle);	GetDlgItem(IDC_MAX_ANGLE)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMaxVolt);	GetDlgItem(IDC_MAX_VOLT)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMaxVDur);	GetDlgItem(IDC_MAXV_DURITION)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMinVolt);	GetDlgItem(IDC_MIN_VOLT)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMinVDur);	GetDlgItem(IDC_MINV_DURITION)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMaxFreq);	GetDlgItem(IDC_MAX_FREQ)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMaxFDur);	GetDlgItem(IDC_MAXF_DURITION)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMinFreq);	GetDlgItem(IDC_MIN_FREQ)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", m_fMinFDur);	GetDlgItem(IDC_MINF_DURITION)->SetWindowText(szBuf);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CCriteriaDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];
	GetDlgItem(IDC_MAX_ANGLE)->GetWindowText(szBuf, 260);		m_fMaxAngle=atof(szBuf);	
	GetDlgItem(IDC_MAX_VOLT)->GetWindowText(szBuf, 260);		m_fMaxVolt=atof(szBuf);	
	GetDlgItem(IDC_MAXV_DURITION)->GetWindowText(szBuf, 260);	m_fMaxVDur=atof(szBuf);	
	GetDlgItem(IDC_MIN_VOLT)->GetWindowText(szBuf, 260);		m_fMinVolt=atof(szBuf);	
	GetDlgItem(IDC_MINV_DURITION)->GetWindowText(szBuf, 260);	m_fMinVDur=atof(szBuf);	
	GetDlgItem(IDC_MAX_FREQ)->GetWindowText(szBuf, 260);		m_fMaxFreq=atof(szBuf);	
	GetDlgItem(IDC_MAXF_DURITION)->GetWindowText(szBuf, 260);	m_fMaxFDur=atof(szBuf);	
	GetDlgItem(IDC_MIN_FREQ)->GetWindowText(szBuf, 260);		m_fMinFreq=atof(szBuf);	
	GetDlgItem(IDC_MINF_DURITION)->GetWindowText(szBuf, 260);	m_fMinFDur=atof(szBuf);	

	OnOK();
}
