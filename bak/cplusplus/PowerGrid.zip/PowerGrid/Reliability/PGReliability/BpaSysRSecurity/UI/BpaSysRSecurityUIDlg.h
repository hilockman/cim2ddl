
// BpaRSecurityUIDlg.h : ͷ�ļ�
//

#pragma once

#include "../../../../../Common/MFCControls/SimpleCurveWnd.h"
#include "../../../../../Common/MFCControls/SubListCtrlEx.h"

// CBpaRSecurityUIDlg �Ի���
class CBpaRSecurityUIDlg : public CDialog
{
// ����
public:
	CBpaRSecurityUIDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BPARSECURITYUI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

public:
	void	PrintMessage(char* pformat, ...);


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	afx_msg void OnCbnSelchangeCurveCombo();
	afx_msg void OnBnClickedCurveVisibleSet();
	afx_msg void OnBnClickedLoadOut();
	afx_msg void OnNMDblclkFstateList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedAnalysisModel();
	afx_msg void OnBnClickedSaveasExcel();
	afx_msg void OnBnClickedReestimate();
	afx_msg void OnBnClickedCriteria();
	afx_msg void OnBnClickedAdequacyFilter();

	afx_msg void OnBnClickedDatBrowse();
	afx_msg void OnBnClickedSwiBrowse();
	afx_msg void OnBnClickedBrowseWorkdir();
	afx_msg void OnEnChangeRParam();
	afx_msg void OnBnClickedLtfaultOnly();
	afx_msg void OnBnClickedRefresh();
	afx_msg void OnBnClickedSystemSecurityAnalysis();
	afx_msg void OnBnClickedStateSecurityAnalysis();

	afx_msg LRESULT OnClickSecureStateList(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnDblClickSecureStateList(WPARAM wParam, LPARAM lParam);

	afx_msg LRESULT OnSecurityEstimateBegin(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnSecurityEstimating(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnSecurityEstimateEnded(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedClearMesg();
	DECLARE_MESSAGE_MAP()

private:
	CSimpleCurveWnd	m_wndCurve;
	CMFCButton		m_btnLoadOut, m_btnSysSsa;
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndListPRSample;
	CSubListCtrlEx	m_wndListPRSecure;

private:
	int		GetTextLen(LPCTSTR lpszText);
	void	RefreshFStateList();
	void	RefreshFSecurityList();
	void	RefreshFDeviceList();

private:
	int		m_nSecurityEstimateNum;
	HANDLE	m_hSecurityEstimateHandle;
public:
};
