// CurveVisibleSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRSecurityUI.h"
#include "CurveVisibleSetDialog.h"


// CCurveVisibleSetDialog �Ի���

IMPLEMENT_DYNAMIC(CCurveVisibleSetDialog, CDialog)

CCurveVisibleSetDialog::CCurveVisibleSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CCurveVisibleSetDialog::IDD, pParent)
{
	m_clrBack=RGB(0, 0, 0);
	m_clrFore=RGB(128, 128, 128);
	m_clrCurve=RGB(255, 0, 0);
	m_clrAxias=RGB(255, 255, 255);
	m_nXPace=10;
	m_nYPace=10;
}

CCurveVisibleSetDialog::~CCurveVisibleSetDialog()
{
}

void CCurveVisibleSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BACKGROUND, m_btnBackColor);
	DDX_Control(pDX, IDC_FOREGROUND, m_btnForeColor);
	DDX_Control(pDX, IDC_CURVE, m_btnCurveColor);
	DDX_Control(pDX, IDC_AXIAS, m_btnAxiasColor);
}


BEGIN_MESSAGE_MAP(CCurveVisibleSetDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCurveVisibleSetDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CCurveVisibleSetDialog ��Ϣ��������

BOOL CCurveVisibleSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_btnBackColor.EnableAutomaticButton(_T("Automatic"), m_clrBack);
	m_btnBackColor.EnableOtherButton(_T("����"));
	m_btnBackColor.SetColor(m_clrBack);
	m_btnBackColor.SetColumnsNumber(10);

	m_btnForeColor.EnableAutomaticButton(_T("Automatic"), m_clrFore);
	m_btnForeColor.EnableOtherButton(_T("����"));
	m_btnForeColor.SetColor(m_clrFore);
	m_btnForeColor.SetColumnsNumber(10);

	m_btnCurveColor.EnableAutomaticButton(_T("Automatic"), m_clrCurve);
	m_btnCurveColor.EnableOtherButton(_T("����"));
	m_btnCurveColor.SetColor(m_clrCurve);
	m_btnCurveColor.SetColumnsNumber(10);

	m_btnAxiasColor.EnableAutomaticButton(_T("Automatic"), m_clrAxias);
	m_btnAxiasColor.EnableOtherButton(_T("����"));
	m_btnAxiasColor.SetColor(m_clrAxias);
	m_btnAxiasColor.SetColumnsNumber(10);

	char	szBuf[260];
	sprintf(szBuf, "%d", m_nXPace);	GetDlgItem(IDC_XPACE)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", m_nYPace);	GetDlgItem(IDC_YPACE)->SetWindowText(szBuf);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CCurveVisibleSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];
	m_clrBack=m_btnBackColor.GetColor();
	m_clrFore=m_btnForeColor.GetColor();
	m_clrCurve=m_btnCurveColor.GetColor();
	m_clrAxias=m_btnAxiasColor.GetColor();
	GetDlgItem(IDC_XPACE)->GetWindowText(szBuf, 260);	m_nXPace=atoi(szBuf);
	GetDlgItem(IDC_YPACE)->GetWindowText(szBuf, 260);	m_nYPace=atoi(szBuf);

	if (m_nXPace < 2)	m_nXPace=2;
	if (m_nYPace < 2)	m_nYPace=2;

	OnOK();
}
