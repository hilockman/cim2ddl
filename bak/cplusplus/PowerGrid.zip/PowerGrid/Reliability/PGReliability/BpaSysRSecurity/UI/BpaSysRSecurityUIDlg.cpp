
// BpaRSecurityUIDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRSecurityUI.h"
#include "BpaSysRSecurityUIDlg.h"
#include "CurveVisibleSetDialog.h"
#include "CriteriaDialog.h"
#include "../../../../../Common/Excel//ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CBpaRSecurityUIDlg �Ի���
#define		IDC_RSAMPLESTATE_LISTCTRL	20011
#define		IDC_RSECURESTATE_LISTCTRL	20012

clock_t	m_dBeg;

static	unsigned char	m_bUIFreezed = 0;

static	char*	lpszFSampleColumn[]=
{
	"״̬��", 
	"��������", 
	"�豸��", 
	"����", 
	"����ʱ��", 
	"��������", 
};

static	char*	lpszFSecureColumn[]=
{
	"״̬��", 
	"״̬����", 
	"����ʱ��", 
	"֧·����", 
	"���й���", 
	"������ʧ", 
	"�������", 
};

static	char*	lpszFDeviceColumn[]=
{
	"�豸����", 
	"�豸����", 
	"��������", 
	"����λ��", 
};


CBpaRSecurityUIDlg::CBpaRSecurityUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaRSecurityUIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nSecurityEstimateNum = 0;
	m_hSecurityEstimateHandle = INVALID_HANDLE_VALUE;
}

void CBpaRSecurityUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CURVE, m_wndCurve);
	DDX_Control(pDX, IDC_SECURITY_RESULT, m_btnLoadOut);
	DDX_Control(pDX, IDC_SYSTEM_SECURITY_ANALYSIS, m_btnSysSsa);
}

BEGIN_MESSAGE_MAP(CBpaRSecurityUIDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_CURVE_COMBO, &CBpaRSecurityUIDlg::OnCbnSelchangeCurveCombo)
	ON_BN_CLICKED(IDC_CURVE_VISIBLE_SET, &CBpaRSecurityUIDlg::OnBnClickedCurveVisibleSet)
	ON_BN_CLICKED(IDC_SECURITY_RESULT, &CBpaRSecurityUIDlg::OnBnClickedLoadOut)
	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CBpaRSecurityUIDlg::OnBnClickedSaveasExcel)
	ON_BN_CLICKED(IDC_REESTIMATE, &CBpaRSecurityUIDlg::OnBnClickedReestimate)

	//ON_NOTIFY(NM_DBLCLK, IDC_FSECURITY_LIST, &CBpaRSecurityUIDlg::OnNMDblclkFstateList)

	ON_EN_CHANGE(IDC_SECURITYANALYSIS_MAXSTATE, &CBpaRSecurityUIDlg::OnEnChangeRParam)
	ON_EN_CHANGE(IDC_SECURITYANALYSIS_MINLTFAULT, &CBpaRSecurityUIDlg::OnEnChangeRParam)
	ON_EN_CHANGE(IDC_SECURITYANALYSIS_MAXLTFAULT, &CBpaRSecurityUIDlg::OnEnChangeRParam)
	ON_EN_CHANGE(IDC_MULTI_THREAD, &CBpaRSecurityUIDlg::OnEnChangeRParam)
	//ON_EN_CHANGE(IDC_MPROCESS_NUM, &CBpaRSecurityUIDlg::OnEnChangeRParam)

	ON_BN_CLICKED(IDC_BROWSE_WORKDIR, &CBpaRSecurityUIDlg::OnBnClickedBrowseWorkdir)
	ON_BN_CLICKED(IDC_LTFAULT_ONLY, &CBpaRSecurityUIDlg::OnBnClickedLtfaultOnly)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CRITERIA, &CBpaRSecurityUIDlg::OnBnClickedCriteria)
	ON_BN_CLICKED(IDC_ADEQUACY_FILTER, &CBpaRSecurityUIDlg::OnBnClickedAdequacyFilter)
	ON_BN_CLICKED(IDC_ADEQUACY_REFRESH, &CBpaRSecurityUIDlg::OnBnClickedRefresh)
	ON_BN_CLICKED(IDC_SYSTEM_SECURITY_ANALYSIS, &CBpaRSecurityUIDlg::OnBnClickedSystemSecurityAnalysis)
	ON_BN_CLICKED(IDC_STATE_SECURITY_ANALYSIS, &CBpaRSecurityUIDlg::OnBnClickedStateSecurityAnalysis)

	ON_MESSAGE(UM_SUBLISTCTRL_NMCLICKED, &CBpaRSecurityUIDlg::OnClickSecureStateList)
	ON_MESSAGE(UM_SUBLISTCTRL_NMDBLCLK, &CBpaRSecurityUIDlg::OnDblClickSecureStateList)

	ON_MESSAGE(WM_ESTIMATEBEG, OnSecurityEstimateBegin)
	ON_MESSAGE(WM_ESTIMATING, OnSecurityEstimating)
	ON_MESSAGE(WM_ESTIMATEEND, OnSecurityEstimateEnded)
	ON_BN_CLICKED(IDC_CLEAR_MESG, &CBpaRSecurityUIDlg::OnBnClickedClearMesg)
END_MESSAGE_MAP()


// CBpaRSecurityUIDlg ��Ϣ��������
BOOL CBpaRSecurityUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	CRect	rectDummy;
	int		nColumn;

	m_bUIFreezed = 1;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListPRSample.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_RSAMPLESTATE_LISTCTRL))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPRSample.ModifyStyle(LVS_SINGLESEL, LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPRSample.SetExtendedStyle(m_wndListPRSample.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPRSample.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszFSampleColumn)/sizeof(char*); nColumn++)
		m_wndListPRSample.InsertColumn(nColumn, lpszFSampleColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListPRSecure.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_RSECURESTATE_LISTCTRL))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPRSecure.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPRSecure.SetExtendedStyle(m_wndListPRSecure.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPRSecure.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszFSecureColumn)/sizeof(char*); nColumn++)
		m_wndListPRSecure.InsertColumn(nColumn, lpszFSecureColumn[nColumn],	LVCFMT_LEFT,	100);
	m_wndListPRSecure.SetParentWindow(this);

	m_wndTab.AddTab (&m_wndListPRSample,	_T("����״̬��"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListPRSecure,	_T("����״̬��"),	-1, FALSE);

	OnBnClickedRefresh();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FDEVICE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (nColumn=0; nColumn<sizeof(lpszFDeviceColumn)/sizeof(char*); nColumn++)
		pListCtrl->InsertColumn(nColumn, lpszFDeviceColumn[nColumn]);
	RefreshFDeviceList();

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_CURVE_COMBO);
	pCombo->ResetContent();

	m_btnLoadOut.SetTooltip("�۲�����ǰ����װ�ؽ��");
	m_btnSysSsa.SetTooltip("������ȫ�������Զ�����״̬ɸѡ");

	RefreshFStateList();
	RefreshFSecurityList();

	char	szBuf[260];

	GetDlgItem(IDC_BPA_WORKDIR)->SetWindowText(g_PRSsaSetting.szBpaWorkDir);
	sprintf(szBuf, "%d", g_PRSsaSetting.nMinSsaLTFault);
	GetDlgItem(IDC_SECURITYANALYSIS_MINLTFAULT)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRSsaSetting.nMaxSsaLTFault);
	GetDlgItem(IDC_SECURITYANALYSIS_MAXLTFAULT)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRSsaSetting.nMaxSsaState);
	GetDlgItem(IDC_SECURITYANALYSIS_MAXSTATE)->SetWindowText(szBuf);

	((CButton*)GetDlgItem(IDC_LTFAULT_ONLY))->SetCheck(g_PRSsaSetting.bLTFaultOnly);

	m_bUIFreezed = 0;

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CBpaRSecurityUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CBpaRSecurityUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CBpaRSecurityUIDlg::OnBnClickedBrowseWorkdir()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString		strFolder=g_PRSsaSetting.szBpaWorkDir;
	if (theApp.GetShellManager()->BrowseForFolder(strFolder, this, strFolder))
	{
		strcpy(g_PRSsaSetting.szBpaWorkDir, strFolder);
		GetDlgItem(IDC_BPA_WORKDIR)->SetWindowText(strFolder);
		g_PRSecurity.SaveBpaPRSecuritySetting(&g_PRSsaSetting);
	}
}

void CBpaRSecurityUIDlg::OnBnClickedLtfaultOnly()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRSsaSetting.bLTFaultOnly=((CButton*)GetDlgItem(IDC_LTFAULT_ONLY))->GetCheck();
	g_PRSecurity.SaveBpaPRSecuritySetting(&g_PRSsaSetting);
}

void CBpaRSecurityUIDlg::OnEnChangeRParam()
{
	char	szBuffer[260];

	if (m_bUIFreezed)
		return;

	GetDlgItem(IDC_SECURITYANALYSIS_MAXSTATE)->GetWindowText(szBuffer, 260);	g_PRSsaSetting.nMaxSsaState=atoi(szBuffer);
	GetDlgItem(IDC_SECURITYANALYSIS_MINLTFAULT)->GetWindowText(szBuffer, 260);	g_PRSsaSetting.nMinSsaLTFault=atoi(szBuffer);
	GetDlgItem(IDC_SECURITYANALYSIS_MAXLTFAULT)->GetWindowText(szBuffer, 260);	g_PRSsaSetting.nMaxSsaLTFault=atoi(szBuffer);

	g_PRSsaSetting.bMutliThread = ((CButton*)GetDlgItem(IDC_MULTI_THREAD))->GetCheck();
	//GetDlgItem(IDC_MPROCESS_NUM)->GetWindowText(szBuffer, 260);					g_PRSsaSetting.nProcessNum=atoi(szBuffer);

	g_PRSecurity.SaveBpaPRSecuritySetting(&g_PRSsaSetting);
}

void CBpaRSecurityUIDlg::OnCbnSelchangeCurveCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_CURVE_COMBO);
	int		nCurve=pCombo->GetCurSel();
	if (nCurve == CB_ERR)
		return;

	char	szBuffer[260];
	pCombo->GetLBText(nCurve, szBuffer);

	tagSimpleCurve*	pCurve=g_PRSecurity.GetBpaOutCurve(szBuffer);
	if (pCurve != NULL)
	{
		m_wndCurve.SetCurve(pCurve);
		sprintf(szBuffer, "%.3f", pCurve->fMaxY);	GetDlgItem(IDC_MAX_CY)->SetWindowText(szBuffer);
		sprintf(szBuffer, "%.3f", pCurve->fMinY);	GetDlgItem(IDC_MIN_CY)->SetWindowText(szBuffer);
		sprintf(szBuffer, "%.1f", pCurve->fMaxY_X);	GetDlgItem(IDC_MAX_DT)->SetWindowText(szBuffer);
		sprintf(szBuffer, "%.1f", pCurve->fMinY_X);	GetDlgItem(IDC_MIN_DT)->SetWindowText(szBuffer);
	}
}

void CBpaRSecurityUIDlg::OnBnClickedCurveVisibleSet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CCurveVisibleSetDialog	dlg;
	dlg.m_clrBack	= g_PRSsaSetting.clrBackGround	 ;
	dlg.m_clrFore	= g_PRSsaSetting.clrForeGround	 ;
	dlg.m_clrCurve	= g_PRSsaSetting.clrCurve			 ;
	dlg.m_clrAxias	= g_PRSsaSetting.clrAxias			 ;
	dlg.m_nXPace	= g_PRSsaSetting.nXPace			 ;
	dlg.m_nYPace	= g_PRSsaSetting.nYPace			 ;
	if (dlg.DoModal() == IDOK)
	{
		g_PRSsaSetting.clrBackGround	= dlg.m_clrBack;
		g_PRSsaSetting.clrForeGround	= dlg.m_clrFore;
		g_PRSsaSetting.clrCurve			= dlg.m_clrCurve;
		g_PRSsaSetting.clrAxias			= dlg.m_clrAxias;
		g_PRSsaSetting.nXPace			= dlg.m_nXPace;
		g_PRSsaSetting.nYPace			= dlg.m_nYPace;
		g_PRSecurity.SaveBpaPRSecuritySetting(&g_PRSsaSetting);

		m_wndCurve.SetColor(g_PRSsaSetting.clrBackGround, g_PRSsaSetting.clrForeGround, g_PRSsaSetting.clrCurve, g_PRSsaSetting.clrAxias);
		m_wndCurve.SetCurveGrid(g_PRSsaSetting.nXPace, g_PRSsaSetting.nYPace);

		m_wndCurve.Invalidate();
	}
}

void CBpaRSecurityUIDlg::OnBnClickedCriteria()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CCriteriaDialog	dlg;
	dlg.m_fMaxAngle=g_PRSsaSetting.fCriteriaMaxAngle;
	dlg.m_fMaxVolt =g_PRSsaSetting.fCriteriaMaxVolt ;
	dlg.m_fMaxVDur =g_PRSsaSetting.fCriteriaMaxVDur ;
	dlg.m_fMinVolt =g_PRSsaSetting.fCriteriaMinVolt ;
	dlg.m_fMinVDur =g_PRSsaSetting.fCriteriaMinVDur ;
	dlg.m_fMaxFreq =g_PRSsaSetting.fCriteriaMaxFreq ;
	dlg.m_fMaxFDur =g_PRSsaSetting.fCriteriaMaxFDur ;
	dlg.m_fMinFreq =g_PRSsaSetting.fCriteriaMinFreq ;
	dlg.m_fMinFDur =g_PRSsaSetting.fCriteriaMinFDur ;
	if (dlg.DoModal() == IDOK)
	{
		g_PRSsaSetting.fCriteriaMaxAngle=dlg.m_fMaxAngle;
		g_PRSsaSetting.fCriteriaMaxVolt =dlg.m_fMaxVolt ;
		g_PRSsaSetting.fCriteriaMaxVDur =dlg.m_fMaxVDur ;
		g_PRSsaSetting.fCriteriaMinVolt =dlg.m_fMinVolt ;
		g_PRSsaSetting.fCriteriaMinVDur =dlg.m_fMinVDur ;
		g_PRSsaSetting.fCriteriaMaxFreq =dlg.m_fMaxFreq ;
		g_PRSsaSetting.fCriteriaMaxFDur =dlg.m_fMaxFDur ;
		g_PRSsaSetting.fCriteriaMinFreq =dlg.m_fMinFreq ;
		g_PRSsaSetting.fCriteriaMinFDur =dlg.m_fMinFDur ;
		g_PRSecurity.SaveBpaPRSecuritySetting(&g_PRSsaSetting);
	}
}

void CBpaRSecurityUIDlg::OnBnClickedLoadOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int			nSelFSecurity=-1;
	POSITION	pos=m_wndListPRSecure.GetFirstSelectedItemPosition();
	if (pos)
		nSelFSecurity=m_wndListPRSecure.GetNextSelectedItem(pos);

	if (nSelFSecurity < 0 || nSelFSecurity >= g_pPRBlock->m_nRecordNum[PR_FSECURITY])
		return;

	if (g_pPRBlock->m_FSecurityArray[nSelFSecurity].nSaResult == PRFSecurity_Result_Unknown)
		return;

	if (g_PRSecurity.ParseBpaOutFile(g_pPRBlock->m_FSecurityArray[nSelFSecurity].szOutFile))
	{
		int		nCurve;
		CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_CURVE_COMBO);
		pCombo->ResetContent();
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMaxAng. strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMinVolt.strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMaxVolt.strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMinFreq.strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMaxFreq.strCurveName.c_str());
		for (nCurve=0; nCurve<(int)g_PRSecurity.g_BpaOutCurveArray.size(); nCurve++)
			pCombo->AddString(g_PRSecurity.g_BpaOutCurveArray[nCurve].strCurveName.c_str());
		pCombo->SetCurSel(0);
		OnCbnSelchangeCurveCombo();
	}
}

void CBpaRSecurityUIDlg::OnNMDblclkFstateList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnBnClickedLoadOut();

	*pResult = 0;
}

void CBpaRSecurityUIDlg::RefreshFStateList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	int		nColWidth, nHeaderWidth;

	m_bUIFreezed=1;

	int			nSelFSecurity=-1;
	POSITION	pos=m_wndListPRSample.GetFirstSelectedItemPosition();
	if (pos)
		nSelFSecurity=m_wndListPRSample.GetNextSelectedItem(pos);
	m_wndListPRSample.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_FSTATE]; i++)
	{
		sprintf(szBuf, "%d", i);	m_wndListPRSample.InsertItem(nRow, szBuf);	m_wndListPRSample.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListPRSample.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_SAMPLETYPE, g_pPRBlock->m_FStateArray[i].nSampleType));
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateArray[i].nFDevNum);		m_wndListPRSample.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[i].fStateProb);	m_wndListPRSample.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[i].fStateDur);		m_wndListPRSample.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateArray[i].nStateNum);		m_wndListPRSample.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	for (nCol=0; nCol<sizeof(lpszFSecureColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPRSample.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPRSample.GetColumnWidth(nCol);
		m_wndListPRSample.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPRSample.GetColumnWidth(nCol);

		m_wndListPRSample.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelFSecurity >= 0 && nSelFSecurity < m_wndListPRSample.GetItemCount())
	{
		m_wndListPRSample.SetItemState(nSelFSecurity, TVIS_SELECTED, TVIS_SELECTED);
		m_wndListPRSample.EnsureVisible(nSelFSecurity, FALSE);
	}
	m_bUIFreezed=0;
}

void CBpaRSecurityUIDlg::RefreshFSecurityList()
{
	register int	i;
	int		nRow, nCol;
	int		nFState;
	char	szBuf[260];
	int		nColWidth, nHeaderWidth;

	m_bUIFreezed=1;

	int			nSelFSecurity=-1;
	POSITION	pos=m_wndListPRSecure.GetFirstSelectedItemPosition();
	if (pos)
		nSelFSecurity=m_wndListPRSecure.GetNextSelectedItem(pos);
	m_wndListPRSecure.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_FSECURITY]; i++)
	{
		nFState=g_pPRBlock->m_FSecurityArray[i].nFStateNo;
		sprintf(szBuf, "%d", nFState);	m_wndListPRSecure.InsertItem(nRow, szBuf);	m_wndListPRSecure.SetItemData(nRow, nRow);


		nCol=1;
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[nFState].fStateProb);		m_wndListPRSecure.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[nFState].fStateDur);		m_wndListPRSecure.SetItemText(nRow, nCol++, szBuf);

		if (g_pPRBlock->m_FSecurityArray[i].nLTFault)
			m_wndListPRSecure.SetItemText(nRow, nCol++, "��");
		else
			m_wndListPRSecure.SetItemText(nRow, nCol++, "��");

		if (g_pPRBlock->m_FSecurityArray[i].bMIsland)
			m_wndListPRSecure.SetItemText(nRow, nCol++, "��");
		else
			m_wndListPRSecure.SetItemText(nRow, nCol++, "��");

		sprintf(szBuf, "%f", g_pPRBlock->m_FSecurityArray[i].fLossGenP);		m_wndListPRSecure.SetItemText(nRow, nCol++, szBuf);

		m_wndListPRSecure.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSECURITY, PR_FSECURITY_RESULT, g_pPRBlock->m_FSecurityArray[i].nSaResult));

		nRow++;
	}

	for (nCol=0; nCol<sizeof(lpszFSecureColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPRSecure.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPRSecure.GetColumnWidth(nCol);
		m_wndListPRSecure.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPRSecure.GetColumnWidth(nCol);

		m_wndListPRSecure.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelFSecurity >= 0 && nSelFSecurity < m_wndListPRSecure.GetItemCount())
	{
		m_wndListPRSecure.SetItemState(nSelFSecurity, TVIS_SELECTED, TVIS_SELECTED);
		m_wndListPRSecure.EnsureVisible(nSelFSecurity, FALSE);
	}
	m_bUIFreezed=0;
}

void	CBpaRSecurityUIDlg::RefreshFDeviceList()
{
	register int	i;
	int		nRow, nCol;
	int		nField, nFState;
	char	szBuf[260];

	POSITION	pos=m_wndListPRSecure.GetFirstSelectedItemPosition();
	if (!pos)
		return;

	int		nFSecurity=m_wndListPRSecure.GetNextSelectedItem(pos);
	if (nFSecurity < 0 || nFSecurity >= g_pPRBlock->m_nRecordNum[PR_FSECURITY])
		return;

	nFState=g_pPRBlock->m_FSecurityArray[nFSecurity].nFStateNo;

	CListCtrl* pListCtrl=(CListCtrl*)GetDlgItem(IDC_FDEVICE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; i++)
	{
		if (g_pPRBlock->m_FStateFDevArray[i].nFStateNo != nFState)
			continue;

		pListCtrl->InsertItem(nRow, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp));	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;

		nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp, "Name");
		g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[i].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[i].nFDevIdx, szBuf);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATEFDEV, PR_FSTATEFDEV_DFLTTYP, g_pPRBlock->m_FStateFDevArray[i].nDFltTyp));
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateFDevArray[i].nDFltPos);																	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszFDeviceColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CBpaRSecurityUIDlg::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;
	if (m_wndListPRSecure.GetItemCount() > 0)
	{
		xls.AddSheet(_T("��ȫ������"));
		xls.SetCurSheet(_T("��ȫ������"));

		nFieldNum=sizeof(lpszFSecureColumn)/sizeof(char*);
		//xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszFSecureColumn[nCol]));
		for (nRow=0; nRow<m_wndListPRSecure.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListPRSecure.GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));
}

void CBpaRSecurityUIDlg::OnBnClickedReestimate()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		nState;

	PrintMessage("��ȫ���������㿪ʼ\n");
	for (nState=0; nState<g_pPRBlock->m_nRecordNum[PR_FSECURITY]; nState++)
	{
		g_pPRBlock->m_FSecurityArray[nState].nSaResult=g_PRSecurity.IsBpaOutStable(g_pPRBlock->m_FSecurityArray[nState].szOutFile, 
			g_PRSsaSetting.fRealCriteriaMaxAngle, 
			g_PRSsaSetting.fRealCriteriaMaxVolt, 
			g_PRSsaSetting.fRealCriteriaMaxVDur, 
			g_PRSsaSetting.fRealCriteriaMinVolt, 
			g_PRSsaSetting.fRealCriteriaMinVDur, 
			g_PRSsaSetting.fRealCriteriaMaxFreq, 
			g_PRSsaSetting.fRealCriteriaMaxFDur, 
			g_PRSsaSetting.fRealCriteriaMinFreq, 
			g_PRSsaSetting.fRealCriteriaMinFDur);
	}
	PrintMessage("��ȫ�������������\n");

	RefreshFSecurityList();
}

void CBpaRSecurityUIDlg::OnBnClickedAdequacyFilter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRSecurity.SecurityStateFilter(g_pPRBlock, g_PRSsaSetting.nMinSsaLTFault, g_PRSsaSetting.nMaxSsaLTFault, g_PRSsaSetting.nMaxSsaState, g_PRSsaSetting.bLTFaultOnly);
	RefreshFSecurityList();

	m_wndTab.SetActiveTab(1);
}

void CBpaRSecurityUIDlg::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];
	m_bUIFreezed=1;

	GetDlgItem(IDC_BPA_WORKDIR)	->SetWindowText(g_PRSsaSetting.szBpaWorkDir);

	((CButton*)GetDlgItem(IDC_MULTI_THREAD))->SetCheck(g_PRSsaSetting.bMutliThread);
	//sprintf(szBuf, "%d", g_PRSsaSetting.nProcessNum);	GetDlgItem(IDC_MPROCESS_NUM)->SetWindowText(szBuf);

	((CButton*)GetDlgItem(IDC_LTFAULT_ONLY))->SetCheck(g_PRSsaSetting.bLTFaultOnly);
	sprintf(szBuf, "%d", g_PRSsaSetting.nMaxSsaState);	GetDlgItem(IDC_SECURITYANALYSIS_MAXSTATE)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRSsaSetting.nMinSsaLTFault);	GetDlgItem(IDC_SECURITYANALYSIS_MINLTFAULT)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRSsaSetting.nMaxSsaLTFault);	GetDlgItem(IDC_SECURITYANALYSIS_MAXLTFAULT)->SetWindowText(szBuf);

	m_bUIFreezed=0;

	RefreshFStateList();

	m_wndTab.SetActiveTab(0);
}

void CBpaRSecurityUIDlg::OnBnClickedSystemSecurityAnalysis()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	char	szExec[260];

	UpdateData();

	m_dBeg = dBeg = clock();

	if (strlen(g_pPRBlock->m_System.szBpaDatFile) <= 0)
	{
		AfxMessageBox("���鳱�������ļ�");
		return;
	}

	if (strlen(g_pPRBlock->m_System.szBpaSwiFile) <= 0)
	{
		AfxMessageBox("�����ȶ������ļ�");
		return;
	}

	sprintf(szExec, "%s/pfnt.exe", g_szRunDir);
	if (access(szExec, 0) != 0)
	{
		AfxMessageBox("���鳱����������");
		Log(g_lpszLogFile, "������������������ (%s)\n", szExec);
		return;
	}

	sprintf(szExec, "%s/swnt.exe", g_szRunDir);
	if (_access(szExec, 0) != 0)
	{
		AfxMessageBox("�����ȶ���������");
		Log(g_lpszLogFile, "�ȶ��������������� (%s)\n", szExec);
		return;
	}

	strcpy(g_pPRBlock->m_System.szSaRunPath, g_szRunDir);
	g_pPRBlock->m_System.fMaxAngle=	g_PRSsaSetting.fRealCriteriaMaxAngle;
	g_pPRBlock->m_System.fMaxVolt=	g_PRSsaSetting.fRealCriteriaMaxVolt;
	g_pPRBlock->m_System.fMaxVDur=	g_PRSsaSetting.fRealCriteriaMaxVDur;
	g_pPRBlock->m_System.fMinVolt=	g_PRSsaSetting.fRealCriteriaMinVolt;
	g_pPRBlock->m_System.fMinVDur=	g_PRSsaSetting.fRealCriteriaMinVDur;
	g_pPRBlock->m_System.fMaxFreq=	g_PRSsaSetting.fRealCriteriaMaxFreq;
	g_pPRBlock->m_System.fMaxFDur=	g_PRSsaSetting.fRealCriteriaMaxFDur;
	g_pPRBlock->m_System.fMinFreq=	g_PRSsaSetting.fRealCriteriaMinFreq;
	g_pPRBlock->m_System.fMinFDur=	g_PRSsaSetting.fRealCriteriaMinFDur;

	g_PRSecurity.SecurityStateFilter(g_pPRBlock, g_PRSsaSetting.nMinSsaLTFault, g_PRSsaSetting.nMaxSsaLTFault, g_PRSsaSetting.nMaxSsaState, g_PRSsaSetting.bLTFaultOnly);
	HANDLE hEstimate = g_PRSecurity.SecurityEstimate(g_pPRBlock, g_pBpaBlock, g_PRSsaSetting.szBpaWorkDir, g_PRSsaSetting.fEndDT, g_PRSsaSetting.bMutliThread);
	if (hEstimate == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox("��ȫ��������������......����ȴ�������������");
		return;
	}

	m_hSecurityEstimateHandle = hEstimate;

	m_wndTab.SetActiveTab(1);
}

void CBpaRSecurityUIDlg::OnBnClickedStateSecurityAnalysis()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	std::vector<int>	nFStateArray;
	nFStateArray.clear();

	POSITION	pos=m_wndListPRSample.GetFirstSelectedItemPosition();
	while (pos)
	{
		int		nItem=m_wndListPRSample.GetNextSelectedItem(pos);
		if (nItem >= 0 && nItem < g_pPRBlock->m_nRecordNum[PR_FSTATE])
			nFStateArray.push_back(nItem);
	}
	g_PRSecurity.SecurityStateFill(g_pPRBlock, nFStateArray);
	if (nFStateArray.empty())
	{
		AfxMessageBox("���� ����״̬�� ѡ����Ҫ��ȫ�����ĳ���״̬");
		return;
	}

	strcpy(g_pPRBlock->m_System.szSaRunPath, g_szRunDir);
	g_pPRBlock->m_System.fMaxAngle=	g_PRSsaSetting.fRealCriteriaMaxAngle;
	g_pPRBlock->m_System.fMaxVolt=	g_PRSsaSetting.fRealCriteriaMaxVolt;
	g_pPRBlock->m_System.fMaxVDur=	g_PRSsaSetting.fRealCriteriaMaxVDur;
	g_pPRBlock->m_System.fMinVolt=	g_PRSsaSetting.fRealCriteriaMinVolt;
	g_pPRBlock->m_System.fMinVDur=	g_PRSsaSetting.fRealCriteriaMinVDur;
	g_pPRBlock->m_System.fMaxFreq=	g_PRSsaSetting.fRealCriteriaMaxFreq;
	g_pPRBlock->m_System.fMaxFDur=	g_PRSsaSetting.fRealCriteriaMaxFDur;
	g_pPRBlock->m_System.fMinFreq=	g_PRSsaSetting.fRealCriteriaMinFreq;
	g_pPRBlock->m_System.fMinFDur=	g_PRSsaSetting.fRealCriteriaMinFDur;
	HANDLE hEstimate = g_PRSecurity.SecurityEstimate(g_pPRBlock, g_pBpaBlock, g_PRSsaSetting.szBpaWorkDir, g_PRSsaSetting.fEndDT, g_PRSsaSetting.bMutliThread);
	if (hEstimate == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox("��ȫ��������������......����ȴ�������������");
		return;
	}

	m_hSecurityEstimateHandle = hEstimate;
	m_wndTab.SetActiveTab(1);
}

LRESULT CBpaRSecurityUIDlg::OnClickSecureStateList(WPARAM wParam, LPARAM lParam)
{
	if (wParam != IDC_RSECURESTATE_LISTCTRL)
		return 0;

	RefreshFDeviceList();

	return 0;
}

LRESULT CBpaRSecurityUIDlg::OnDblClickSecureStateList(WPARAM wParam, LPARAM lParam)
{
	if (wParam != IDC_RSECURESTATE_LISTCTRL)
		return 0;

	int			nSelFSecurity=-1;
	POSITION	pos=m_wndListPRSecure.GetFirstSelectedItemPosition();
	if (pos)
		nSelFSecurity=m_wndListPRSecure.GetNextSelectedItem(pos);

	if (nSelFSecurity < 0 || nSelFSecurity >= g_pPRBlock->m_nRecordNum[PR_FSECURITY])
		return 0;

	if (g_pPRBlock->m_FSecurityArray[nSelFSecurity].nSaResult == PRFSecurity_Result_Unknown)
		return 0;

	if (g_PRSecurity.ParseBpaOutFile(g_pPRBlock->m_FSecurityArray[nSelFSecurity].szOutFile))
	{
		int		nCurve;
		CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_CURVE_COMBO);
		pCombo->ResetContent();
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMaxAng. strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMinVolt.strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMaxVolt.strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMinFreq.strCurveName.c_str());
		pCombo->AddString(g_PRSecurity.g_BpaOutCurveMaxFreq.strCurveName.c_str());
		for (nCurve=0; nCurve<(int)g_PRSecurity.g_BpaOutCurveArray.size(); nCurve++)
			pCombo->AddString(g_PRSecurity.g_BpaOutCurveArray[nCurve].strCurveName.c_str());
		pCombo->SetCurSel(0);
		OnCbnSelchangeCurveCombo();
	}

	return 0;
}

LRESULT CBpaRSecurityUIDlg::OnSecurityEstimateBegin(WPARAM wParam, LPARAM lParam)
{
	m_nSecurityEstimateNum = 0;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetRange(0, g_pPRBlock->m_nRecordNum[PR_FSECURITY]);

	PrintMessage("��ȫ�������㿪ʼ\n");
	return 0;
}

LRESULT CBpaRSecurityUIDlg::OnSecurityEstimating(WPARAM wParam, LPARAM lParam)
{
	m_nSecurityEstimateNum += wParam;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos(m_nSecurityEstimateNum);
	return 0;
}

LRESULT CBpaRSecurityUIDlg::OnSecurityEstimateEnded(WPARAM wParam, LPARAM lParam)
{
	clock_t	dEnd;
	int		nDur;

	m_nSecurityEstimateNum = 0;
	m_hSecurityEstimateHandle = INVALID_HANDLE_VALUE;

	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos(g_pPRBlock->m_nRecordNum[PR_FSECURITY]);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-m_dBeg))/CLOCKS_PER_SEC);

	PrintMessage("��ȫ����������ϣ���ʱ%d����\n", nDur);

	g_PRSecurity.ExitSecurityEstimate(g_pPRBlock);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-m_dBeg))/CLOCKS_PER_SEC);

	PrintMessage("ͳ�Ƽ�������ɣ���ʱ%d����\n", nDur);

	RefreshFSecurityList();
	return 0;
}

void	CBpaRSecurityUIDlg::PrintMessage(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);

	vsprintf(szMesg, pformat, args);

	int	iExt = GetTextLen(szMesg);
	if (iExt > pListBox->GetHorizontalExtent())
		pListBox->SetHorizontalExtent(iExt);
	pListBox->AddString(szMesg);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	va_end(args);
}

int CBpaRSecurityUIDlg::GetTextLen(LPCTSTR lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC* pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(lpszText, (int) _tcslen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(lpszText, (int) _tcslen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CBpaRSecurityUIDlg::OnBnClickedClearMesg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	pListBox->ResetContent();
}
