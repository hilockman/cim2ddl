#include <process.h>
#include <io.h>
#include <vector>
using namespace std;
#include <crtdbg.h>
#include <float.h>

#include "../../../../../MemDB/BpaMemDB/BpaMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../../lib/BpaMemDB.lib")
#	pragma message("Link LibX86 BpaMemDB.lib")
#else
#	pragma comment(lib, "../../../../../lib_x64/BpaMemDB.lib")
#	pragma message("Link LibX64 BpaMemDB.lib")
#endif
using	namespace	BpaMemDB;

#include "../../../../../MemDB/PRMemDB/PRMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../../lib/PRMemDB.lib")
#else
#	pragma comment(lib, "../../../../../lib_x64/PRMemDB.lib")
#endif
using	namespace	PRMemDB;

#include "../../../../DCNetwork/DCNetwork.h"
using	namespace	DCNetwork;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libDCNetworkMDd.lib")
#		pragma message("Link LibX86 DCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libDCNetworkMD.lib")
#		pragma message("Link LibX86 DCNetworkMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libDCNetworkMDd.lib")
#		pragma message("Link LibX64 DCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libDCNetworkMD.lib")
#		pragma message("Link LibX64 DCNetworkMD.lib")
#	endif
#endif

#include "../../PRAdequacyBase/PRAdequacyBase.h"
using	namespace	PRAdequacyBase;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libPRAdequacyBaseMDd.lib")
#		pragma message("Link LibX86 PRAdequacyBaseMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libPRAdequacyBaseMD.lib")
#		pragma message("Link LibX86 PRAdequacyBaseMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libPRAdequacyBaseMDd.lib")
#		pragma message("Link LibX64 PRAdequacyBaseMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libPRAdequacyBaseMD.lib")
#		pragma message("Link LibX64 PRAdequacyBaseMD.lib")
#	endif
#endif

#include "../../../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libTinyXmlMDd.lib")
#		pragma message("Link LibX86 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libTinyXmlMD.lib")
#		pragma message("Link LibX86 TinyXmlMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libTinyXmlMDd.lib")
#		pragma message("Link LibX64 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libTinyXmlMD.lib")
#		pragma message("Link LibX64 TinyXmlMD.lib")
#	endif
#endif


#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

// #ifdef _DEBUG
// #define new DEBUG_NEW
// #endif

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="BpaSysAdequacyModule.log";
extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

tagBpaBlock*			g_pBpaBlock;
tagPRBlock*				g_pPRBlock;
CPRMemDBInterface		g_PRMemDBInterface;
CBpaMemDBInterface		g_BpaMemDBInterface;
CPRAdequacyEstimate		g_PRAdeEstimate;
CPRAdequacyStateSample	g_PRStateSample;
CBpaPRParam		g_BpaPRParam;

void PrintMessage(const char* pformat, ...);

int main(int argc, char** argv, char** envp)
{
	char	szRunDir[260], szRResultFile[260];
	tagBpaPRAdequacySetting	sPRAdeSetting;
	clock_t	dBeg, dEnd;
	int		nDur;

	ClearLog(g_lpszLogFile);
	GetCurrentDirectory(260, szRunDir);
	InitBpaPRAdequacySetting(&sPRAdeSetting);

	int	nEle=1;
	if (argc > nEle)	strcpy(szRunDir, argv[nEle++]);							else	return 0;
	if (argc > nEle)	sPRAdeSetting.nMCSSimulateTime = atoi(argv[nEle++]);	else	return 0;
	if (argc > nEle)	sPRAdeSetting.nMaxGenFault = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.nMaxBranFault = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.bGenBusLoadAsAux = atoi(argv[nEle++]);	else	return 0;
	if (argc > nEle)	sPRAdeSetting.fDc2AcFactor = atof(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.nPRSampleMethod = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaDatFile = argv[nEle++];				else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaSwiFile = argv[nEle++];				else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaRParamFile = argv[nEle++];			else	return 0;
	if (argc > nEle)	strcpy(szRResultFile, argv[nEle++]);					else	return 0;

	ClearLog(g_lpszLogFile);
	dBeg=clock();

	{
		g_pBpaBlock=(tagBpaBlock*)g_BpaMemDBInterface.Init_BpaBlock();
		if (!g_pBpaBlock)
		{
			PrintMessage("��ȡBpa�ڴ�����\n");
			return FALSE;
		}

		g_pPRBlock=(tagPRBlock*)g_PRMemDBInterface.Init_PRBlock();
		if (!g_pPRBlock)
		{
			PrintMessage("��ȡPR�ڴ�����\n");
			return FALSE;
		}
	}
	{
		char	drive[260], dir[260], fname[260], ext[260];
		char	szFileName[260], szBpaPFExec[260], szWorkDir[260], szExec[260];

		sprintf(szBpaPFExec, "%s/pfnt.exe", szRunDir);
		if (access(szBpaPFExec, 0) != 0)
			return 0;

		g_BpaMemDBInterface.BpaFiles2MemDB(g_pBpaBlock, sPRAdeSetting.strBpaDatFile.c_str(), sPRAdeSetting.strBpaSwiFile.c_str(), 0);

		_splitpath(sPRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
		_makepath(szWorkDir, drive, dir, NULL, NULL);
		SetCurrentDirectory(szWorkDir);

		sprintf(szFileName,"%s%s",fname,ext);
		sprintf(szExec,"%s %s", szBpaPFExec, szFileName);
		PrintMessage(szExec);
		StartProcess(szExec, NULL, SW_HIDE);

		_makepath(szFileName, drive, dir, fname, ".pfo");
		if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName) <= 0)
		{
			PrintMessage("��PFO�ļ�������㽻������\n");
			return 0;
		}

		BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, sPRAdeSetting.strBpaDatFile.c_str(), sPRAdeSetting.strBpaSwiFile.c_str(), sPRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������
		g_BpaPRParam.ReadBpaPRParam(sPRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}
	{

		int	nStateNum = g_PRStateSample.Sample(g_pPRBlock, 0, PRFState_SamplingMethod_MonteCarlo, &sPRAdeSetting);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("״̬������ϣ���ʱ%d���� ״̬��=%d\n",nDur, nStateNum);
		printf("״̬������ϣ���ʱ%d���� ״̬��=%d\n",nDur, nStateNum);
		if (nStateNum <= 0)
			return 0;
	}
	{
		register int		i;
		TiXmlElement*		pElement;
		TiXmlDocument*		pDocument = new TiXmlDocument();						//����һ��XML���ĵ�����
		TiXmlDeclaration*	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
		pDocument->LinkEndChild(pDeclare);

		TiXmlElement*		pRoot = new TiXmlElement(g_PRMemDBInterface.PRGetTableName(PR_FSTATE));			//����һ����Ԫ�ز����ӡ�
		pDocument->LinkEndChild(pRoot);
		pRoot->SetAttribute("StateNum", g_pPRBlock->m_nRecordNum[PR_FSTATE]);

		for (int nFState=0; nFState<g_pPRBlock->m_nRecordNum[PR_FSTATE]; nFState++)
		{
			pElement= new TiXmlElement(g_PRMemDBInterface.PRGetTableName(PR_FSTATE));
			pRoot->LinkEndChild(pElement);

			pElement->SetAttribute("ID",																		nFState											);
			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_FDEVNUM),				g_pPRBlock->m_FStateArray[nFState].nFDevNum		);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_PROBABILITY),	g_pPRBlock->m_FStateArray[nFState].fStateProb	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_DURITION),		g_pPRBlock->m_FStateArray[nFState].fStateDur	);
			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_STATENUM),			g_pPRBlock->m_FStateArray[nFState].nStateNum	);

			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_FLOSSGEN),		g_pPRBlock->m_FStateArray[nFState].fFLossGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_FLOSSLOAD),		g_pPRBlock->m_FStateArray[nFState].fFLossLoad	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_FLOSSGENCAP),	g_pPRBlock->m_FStateArray[nFState].fFLossGenCap	);

			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_MISLAND),				g_pPRBlock->m_FStateArray[nFState].bMIsland		);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_MIINSGEN),		g_pPRBlock->m_FStateArray[nFState].fMIInsGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_MICUTGEN),		g_pPRBlock->m_FStateArray[nFState].fMICutGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_MICUTLOAD),		g_pPRBlock->m_FStateArray[nFState].fMIOutLoad	);

			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_AGCINSGEN),		g_pPRBlock->m_FStateArray[nFState].fAgcInsGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_AGCCUTGEN),		g_pPRBlock->m_FStateArray[nFState].fAgcCutGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_AGCCUTLOAD),	g_pPRBlock->m_FStateArray[nFState].fEnsCutLoad	);

			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_OVERLIMIT),			g_pPRBlock->m_FStateArray[nFState].bOverLimit	);
			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_ELCUTLOAD),			g_pPRBlock->m_FStateArray[nFState].bELCutLoad	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_ELCUTGEN),		g_pPRBlock->m_FStateArray[nFState].fELCutGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_ELINSGEN),		g_pPRBlock->m_FStateArray[nFState].fELInsGen	);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_ELCUTLOAD),		g_pPRBlock->m_FStateArray[nFState].fELCutLoad	);
			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_ELRESULT),			g_pPRBlock->m_FStateArray[nFState].nELResult	);

			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_MAXFAULTZONE),		g_pPRBlock->m_FStateArray[nFState].nMaxFaultZone);
			pElement->SetDoubleAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_MAXFAULTRATIO),	g_pPRBlock->m_FStateArray[nFState].fMaxFaultRatio);
			pElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATE, PR_FSTATE_FAULTGRADE),			g_pPRBlock->m_FStateArray[nFState].nFaultGrade	);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; i++)
			{
				if (g_pPRBlock->m_FStateFDevArray[i].nFStateNo < nFState)
					continue;
				if (g_pPRBlock->m_FStateFDevArray[i].nFStateNo > nFState)
					break;

				TiXmlElement*	pSubElement= new TiXmlElement(g_PRMemDBInterface.PRGetTableName(PR_FSTATEFDEV));
				pElement->LinkEndChild(pSubElement);

				pSubElement->SetAttribute(g_PRMemDBInterface.PRGetFieldName(PR_FSTATEFDEV, PR_FSTATEFDEV_FDEVTYP), g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp)	);
				switch (g_pPRBlock->m_FStateFDevArray[i].nFDevTyp)
				{
				case	PR_GENERATOR:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_GeneratorArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_POWERLOAD:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_PowerLoadArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_ACLINE:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_ACLineArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_WIND:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_WindArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_HVDC:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_HVDCArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_TCSC:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_TCSCArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_UPFC:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_UPFCArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_CONVERTER:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_ConverterArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				case	PR_DCLINE:
					pSubElement->SetAttribute("DevName",	g_pPRBlock->m_DCLineArray[g_pPRBlock->m_FStateFDevArray[i].nFDevIdx].szName);
					break;
				}
			}
		}

		pDocument->SaveFile(szRResultFile);					//���浽�ļ�
		pDocument->Clear();
		delete pDocument;
	}
}

void PrintMessage(const char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];

	vsprintf(szMesg, pformat, args);
	vfprintf(stdout, pformat, args);
	fprintf(stdout, "\n");

	Log(g_lpszLogFile, szMesg);

	va_end(args);
}
