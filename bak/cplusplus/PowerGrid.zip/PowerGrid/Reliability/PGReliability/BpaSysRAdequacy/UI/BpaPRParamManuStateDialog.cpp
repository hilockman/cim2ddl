// PRParamManuDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamManuStateDialog.h"
#include "BpaDeviceSelectDialog.h"

// CPRParamManuDialog �Ի���

IMPLEMENT_DYNAMIC(CBpaPRParamManualFaultDialog, CDialog)

CBpaPRParamManualFaultDialog::CBpaPRParamManualFaultDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamManualFaultDialog::IDD, pParent)
{

}

CBpaPRParamManualFaultDialog::~CBpaPRParamManualFaultDialog()
{
}

void CBpaPRParamManualFaultDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamManualFaultDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD_STATE, &CBpaPRParamManualFaultDialog::OnBnClickedAddState)
	ON_BN_CLICKED(IDC_DEL_STATE, &CBpaPRParamManualFaultDialog::OnBnClickedDelState)
	ON_BN_CLICKED(IDC_ADD_FDEV, &CBpaPRParamManualFaultDialog::OnBnClickedAddFdev)
	ON_BN_CLICKED(IDC_DEL_FDEV, &CBpaPRParamManualFaultDialog::OnBnClickedDelFdev)
END_MESSAGE_MAP()


// CPRParamManuDialog ��Ϣ��������

BOOL CBpaPRParamManualFaultDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	RefreshManualFaultTree();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamManualFaultDialog::RefreshManualFaultTree()
{
	register int	i;
	int		nMFault, nFDev, nFDevNum;

	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_MANUAL_STATE_TREE);
	HTREEITEM	hSelectedItem = pTreeCtrl->GetSelectedItem();

	if (!pTreeCtrl->DeleteAllItems())
		return;

	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]; i++)
		g_pPRBlock->m_ManualFaultArray[i].bProc = 0;

	TV_INSERTSTRUCT insItem;
	HTREEITEM	hRoot, hState, hDevice;
	char		szBuf[260];

	insItem.hParent=TVI_ROOT;
	insItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
	insItem.item.pszText=_T("�����¼�����");
	insItem.item.cchTextMax=12;
	insItem.item.lParam=0;
	insItem.item.state=TVIS_BOLD | TVIS_EXPANDED;
	insItem.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
	hRoot=pTreeCtrl->InsertItem(&insItem);
	for (nMFault=0; nMFault<g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]; nMFault++)
	{
		if (g_pPRBlock->m_ManualFaultArray[nMFault].bProc)
			continue;

		sprintf(szBuf, "%s ", g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_SAMPLETYPE, PRFState_SamplingMethod_Manual));
		if (strlen(g_pPRBlock->m_ManualFaultArray[nMFault].szName) > 0)
		{
			strcat(szBuf, " - ");
			strcat(szBuf, g_pPRBlock->m_ManualFaultArray[nMFault].szName);
		}

		insItem.hParent=hRoot;
		insItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
		insItem.item.stateMask=TVIS_EXPANDED | TVIS_SELECTED;
		insItem.item.pszText=szBuf;
		insItem.item.cchTextMax=260;
		insItem.item.lParam=nMFault;
		hState = pTreeCtrl->InsertItem(&insItem);
		pTreeCtrl->SetItemData(hState, nMFault+1);

		nFDevNum = 0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]; i++)
		{
			if (stricmp(g_pPRBlock->m_ManualFaultArray[nMFault].szName, g_pPRBlock->m_ManualFaultArray[i].szName) != 0)
				continue;

			nFDevNum++;
		}

		nFDev = 0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]; i++)
		{
			if (stricmp(g_pPRBlock->m_ManualFaultArray[nMFault].szName, g_pPRBlock->m_ManualFaultArray[i].szName) != 0)
				continue;
			g_pPRBlock->m_ManualFaultArray[i].bProc = 1;

			sprintf(szBuf, "�����豸[%d/%d] %s %s", nFDev+1, nFDevNum, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_ManualFaultArray[i].nFDevType), g_pPRBlock->m_ManualFaultArray[i].szFDevName);

			insItem.hParent=hState;
			insItem.item.mask=TVIF_TEXT | TVIF_PARAM;
			insItem.item.pszText=szBuf;
			insItem.item.cchTextMax=260;
			insItem.item.lParam=nMFault;
			hDevice = pTreeCtrl->InsertItem(&insItem);
			pTreeCtrl->SetItemData(hDevice, i+1);

			nFDev++;
		}
	}

	if (hSelectedItem != NULL)
		pTreeCtrl->SelectItem(hSelectedItem);
}

void CBpaPRParamManualFaultDialog::OnBnClickedAddState()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	tagPRManualFault	sMFault;
	memset(&sMFault, 0, sizeof(tagPRManualFault));

	time_t		now;
	struct tm	when;
	time(&now);
	when = *localtime( &now );
	sprintf(sMFault.szName, "�¼�%.4d%.2d%.2d%.2d%.2d%.2d", when.tm_year+1900, when.tm_mon+1, when.tm_mday, when.tm_hour, when.tm_min, when.tm_sec);

	CBpaDeviceSelectDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;
	sMFault.nFDevType = dlg.m_nDevType;

	register int	i;
	int				nDev;
	unsigned char	bExist;
	for (nDev=0; nDev<(int)dlg.m_strDevArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]; i++)
		{
			if (stricmp(g_pPRBlock->m_ManualFaultArray[i].szName, sMFault.szName) != 0)
				continue;

			if (g_pPRBlock->m_ManualFaultArray[i].nFDevType == sMFault.nFDevType && stricmp(g_pPRBlock->m_ManualFaultArray[i].szFDevName, dlg.m_strDevArray[nDev].c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			strcpy(sMFault.szFDevName, dlg.m_strDevArray[nDev].c_str());
			if (g_pPRBlock->m_nRecordNum[PR_MANUALFAULT] < g_PRMemDBInterface.PRGetTableMax(PR_MANUALFAULT))
				memcpy(&g_pPRBlock->m_ManualFaultArray[g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]++], &sMFault, sizeof(tagPRManualFault));
		}
	}
	RefreshManualFaultTree();
}

void CBpaPRParamManualFaultDialog::OnBnClickedDelState()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_MANUAL_STATE_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ����ɾ���¼�");
		return;
	}

	char	szMFaultName[MDB_CHARLEN];
	int		nMFault=(int)pTreeCtrl->GetItemData(hItem)-1;
	if (nMFault >= 0 && nMFault < g_pPRBlock->m_nRecordNum[PR_MANUALFAULT])
	{
		strcpy(szMFaultName, g_pPRBlock->m_ManualFaultArray[nMFault].szName);

		nMFault = 0;
		while (nMFault < g_pPRBlock->m_nRecordNum[PR_MANUALFAULT])
		{
			if (stricmp(g_pPRBlock->m_ManualFaultArray[nMFault].szName, szMFaultName) == 0)
				g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_MANUALFAULT, nMFault);
			else
				nMFault++;
		}
		RefreshManualFaultTree();
	}
}

void CBpaPRParamManualFaultDialog::OnBnClickedAddFdev()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_MANUAL_STATE_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ�������ӹ����豸���¼�");
		return;
	}

	tagPRManualFault	sMFault;
	int		nMFault=(int)pTreeCtrl->GetItemData(hItem)-1;
	if (nMFault < 0 || nMFault >= g_pPRBlock->m_nRecordNum[PR_MANUALFAULT])
		return;
	strcpy(sMFault.szName, g_pPRBlock->m_ManualFaultArray[nMFault].szName);

	CBpaDeviceSelectDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;
	sMFault.nFDevType = dlg.m_nDevType;

	register int	i, j;
	unsigned char	bExist;
	for (i=0; i<(int)dlg.m_strDevArray.size(); i++)
	{
		bExist=0;
		for (j=0; j<g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]; j++)
		{
			if (stricmp(g_pPRBlock->m_ManualFaultArray[j].szName, sMFault.szName) != 0)
				continue;

			if (g_pPRBlock->m_ManualFaultArray[j].nFDevType == sMFault.nFDevType && stricmp(g_pPRBlock->m_ManualFaultArray[j].szFDevName, dlg.m_strDevArray[i].c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			strcpy(sMFault.szFDevName, dlg.m_strDevArray[i].c_str());
			if (g_pPRBlock->m_nRecordNum[PR_MANUALFAULT] < g_PRMemDBInterface.PRGetTableMax(PR_MANUALFAULT))
				memcpy(&g_pPRBlock->m_ManualFaultArray[g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]++], &sMFault, sizeof(tagPRManualFault));
		}
	}

	RefreshManualFaultTree();
}

void CBpaPRParamManualFaultDialog::OnBnClickedDelFdev()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_MANUAL_STATE_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ����ɾ�������豸");
		return;
	}

	int	nMFault=(int)pTreeCtrl->GetItemData(hItem)-1;
	if (nMFault < 0 || nMFault >= g_pPRBlock->m_nRecordNum[PR_MANUALFAULT])
		return;

	g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_MANUALFAULT, nMFault);

	RefreshManualFaultTree();
}
