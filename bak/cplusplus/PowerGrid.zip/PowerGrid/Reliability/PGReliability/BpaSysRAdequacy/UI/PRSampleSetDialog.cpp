// FStateSampleSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PRSampleSetDialog.h"


// CFStateSampleSetDialog �Ի���

IMPLEMENT_DYNAMIC(CPRSampleSetDialog, CDialog)

CPRSampleSetDialog::CPRSampleSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPRSampleSetDialog::IDD, pParent)
{
	m_nSampleType = 0;
	m_nPRSampleMethod = PRFState_SamplingMethod_Unknown;
	m_nPRSampleObject=1;
}

CPRSampleSetDialog::~CPRSampleSetDialog()
{
}

void CPRSampleSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_PRCOMP_ALL, m_nPRSampleObject);
	DDX_Radio(pDX, IDC_MONTECARLO, m_nSampleType);
}


BEGIN_MESSAGE_MAP(CPRSampleSetDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPRSampleSetDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CFStateSampleSetDialog ��Ϣ��������

BOOL CPRSampleSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	char	szBuf[260];

	m_nPRSampleObject = g_PRAdeSetting.nPRSampleObject ;
	m_nSampleType = g_PRAdeSetting.nPRSampleMethod-1 ;

	sprintf(szBuf, "%d", g_PRAdeSetting.nMaxGenFault);		GetDlgItem(IDC_MAXFAULT_GEN)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRAdeSetting.nMaxBranFault);		GetDlgItem(IDC_MAXFAULT_BRAN)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRAdeSetting.nMCSSimulateTime);	GetDlgItem(IDC_MCS_SIMULATETIME)->SetWindowText(szBuf);
	sprintf(szBuf, "%g", g_PRAdeSetting.fMCSMinStateProb);	GetDlgItem(IDC_MCS_MINSTATEPROB)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRAdeSetting.nFSTMaxStateNum);	GetDlgItem(IDC_FST_MAXSTATE)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", g_PRAdeSetting.fFSTMaxCumuProb);	GetDlgItem(IDC_FST_MAXCUMUPROB)->SetWindowText(szBuf);
	sprintf(szBuf, "%g", g_PRAdeSetting.fFSTMinStateProb);	GetDlgItem(IDC_FST_MINSTATEPROB)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_PRAdeSetting.nSTSMaxStateNum);	GetDlgItem(IDC_STS_MAXSTATE)->SetWindowText(szBuf);
	sprintf(szBuf, "%g", g_PRAdeSetting.fANAMinStateProb);	GetDlgItem(IDC_ANA_MINSTATEPROB)->SetWindowText(szBuf);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPRSampleSetDialog::ResolveRSampleParam()
{
	char	szBuffer[260];

	UpdateData();

	g_PRAdeSetting.nPRSampleObject = m_nPRSampleObject;
	g_PRAdeSetting.nPRSampleMethod = m_nSampleType+1;

	GetDlgItem(IDC_MAXFAULT_GEN)->GetWindowText(szBuffer, 260);					g_PRAdeSetting.nMaxGenFault=atoi(szBuffer);
	GetDlgItem(IDC_MAXFAULT_BRAN)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.nMaxBranFault=atoi(szBuffer);

	GetDlgItem(IDC_MCS_SIMULATETIME)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.nMCSSimulateTime=atoi(szBuffer);
	GetDlgItem(IDC_MCS_MINSTATEPROB)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.fMCSMinStateProb=atof(szBuffer);

	GetDlgItem(IDC_FST_MAXCUMUPROB)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.fFSTMaxCumuProb=atof(szBuffer);
	GetDlgItem(IDC_FST_MAXSTATE)->GetWindowText(szBuffer, 260);					g_PRAdeSetting.nFSTMaxStateNum=atoi(szBuffer);
	GetDlgItem(IDC_FST_MINSTATEPROB)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.fFSTMinStateProb=atof(szBuffer);

	GetDlgItem(IDC_STS_MAXSTATE)->GetWindowText(szBuffer, 260);					g_PRAdeSetting.nSTSMaxStateNum=atoi(szBuffer);
	GetDlgItem(IDC_ANA_MINSTATEPROB)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.fANAMinStateProb=atof(szBuffer);

	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CPRSampleSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	ResolveRSampleParam();
	switch (m_nSampleType)
	{
	case	0:
		m_nPRSampleMethod = PRFState_SamplingMethod_MonteCarlo;
		break;
	case	1:
		m_nPRSampleMethod = PRFState_SamplingMethod_StateSample;
		break;
	case	2:
		m_nPRSampleMethod = PRFState_SamplingMethod_Analytical;
		break;
	case	3:
		m_nPRSampleMethod = PRFState_SamplingMethod_FastSort;
		break;
	default:
		m_nPRSampleMethod = PRFState_SamplingMethod_Unknown;
		break;
	}

	OnOK();
}
