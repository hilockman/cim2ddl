#pragma once
#include "../../../../../Common/Excel/ExcelAccessor.h"

// CPResultBusReliabilityDialog �Ի���

class CPResultBusReliabilityDialog : public CDialog
{
	DECLARE_DYNAMIC(CPResultBusReliabilityDialog)

public:
	CPResultBusReliabilityDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPResultBusReliabilityDialog();

	void	RefreshUI();
	void	ExcelOut(ExcelAccessor* pXls);

// �Ի�������
	enum { IDD = IDD_PRESULT_BUSRELIABILITY_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedShowHasvalueOnly();
	DECLARE_MESSAGE_MAP()

private:
	void	RefreshPRBusResultList();

public:

};
