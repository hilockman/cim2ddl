#pragma once

#include "../../../../../Common/MFCControls/MFCListCtrlEx.h"

// CBpaDCFlowDialog �Ի���

class CBpaDCFlowDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaDCFlowDialog)

public:
	CBpaDCFlowDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaDCFlowDialog();

// �Ի�������
	enum { IDD = IDD_BPA_DCFLOW_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedDCFlow();
	afx_msg void OnBnClickedShowFilter();
	afx_msg void OnBnClickedSaveasExcel();
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrlEx	m_wndListFlowBus, m_wndListFlowLine, m_wndListFlowTran;

private:
	void	RefreshDCFlowBusList(const int nRadial=0);
	void	RefreshDCFlowBranList(const int nRadial=0);
public:
};
