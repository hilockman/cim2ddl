// BpaPRMultStateDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamMultStateDialog.h"


// CBpaPRParamMultStateDialog �Ի���
static	int		nMStateDevType[]=
{
	PR_GENERATOR,
//	PR_POWERLOAD,
	PR_HVDC,
};

static	char*	lpszMStateColumn[]=
{
	"�豸����",
	"�豸����",
	"״̬��",
};

IMPLEMENT_DYNAMIC(CBpaPRParamMultStateDialog, CDialog)

CBpaPRParamMultStateDialog::CBpaPRParamMultStateDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamMultStateDialog::IDD, pParent)
{

}

CBpaPRParamMultStateDialog::~CBpaPRParamMultStateDialog()
{
}

void CBpaPRParamMultStateDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamMultStateDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_STATENUM_COMBO, &CBpaPRParamMultStateDialog::OnCbnSelchangeStatenumCombo)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CBpaPRParamMultStateDialog::OnCbnSelchangeDevtypeCombo)
	ON_NOTIFY(NM_CLICK, IDC_MSTATE_LIST, &CBpaPRParamMultStateDialog::OnNMClickMstateList)
	ON_BN_CLICKED(IDC_ADD, &CBpaPRParamMultStateDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CBpaPRParamMultStateDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_MOD, &CBpaPRParamMultStateDialog::OnBnClickedMod)
END_MESSAGE_MAP()


// CBpaPRParamMultStateDialog ��Ϣ��������

BOOL CBpaPRParamMultStateDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CComboBox*	pComboBox;
	CListCtrl*	pListCtrl;
	char		szBuf[260];

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszMStateColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszMStateColumn[i],	LVCFMT_LEFT,	60);
	RefreshMStateList();

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(nMStateDevType)/sizeof(int); i++)
		pComboBox->AddString(g_PRMemDBInterface.PRGetTableDesp(nMStateDevType[i]));

	pComboBox=(CComboBox*)GetDlgItem(IDC_STATENUM_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<8; i++)
	{
		sprintf(szBuf, "%d", i+1);
		pComboBox->AddString(szBuf);
	}
	OnCbnSelchangeStatenumCombo();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamMultStateDialog::OnCbnSelchangeStatenumCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int			nRow, nCol;
	for (nRow=0; nRow<8; nRow++)
	{
		GetDlgItem(IDC_RATE1+nRow)->EnableWindow(FALSE);
		GetDlgItem(IDC_PROB1+nRow)->EnableWindow(FALSE);
		for (nCol=0; nCol<8; nCol++)
			GetDlgItem(IDC_FREQ11+10*nRow+nCol)->EnableWindow(FALSE);
	}

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_STATENUM_COMBO);
	int			nStateNum=pComboBox->GetCurSel();
	if (nStateNum == CB_ERR)
		return;

	nStateNum++;

	for (nRow=0; nRow<nStateNum; nRow++)
	{
		GetDlgItem(IDC_RATE1+nRow)->EnableWindow(TRUE);
		GetDlgItem(IDC_PROB1+nRow)->EnableWindow(TRUE);
		for (nCol=0; nCol<nStateNum; nCol++)
			GetDlgItem(IDC_FREQ11+10*nRow+nCol)->EnableWindow(TRUE);
	}
}

void CBpaPRParamMultStateDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CComboBox*	pCombo;

	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int	nDevType = pCombo->GetCurSel();
	if (nDevType == CB_ERR)
		return;

	pCombo=(CComboBox*)GetDlgItem(IDC_DEVNAME_COMBO);
	pCombo->ResetContent();
	switch (nMStateDevType[nDevType])
	{
	case	PR_GENERATOR:
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_GENERATOR]; i++)
			pCombo->AddString(g_pPRBlock->m_GeneratorArray[i].szName);
		break;
	case	PR_POWERLOAD:
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_POWERLOAD]; i++)
			pCombo->AddString(g_pPRBlock->m_PowerLoadArray[i].szName);
		break;
	case	PR_HVDC:
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_HVDC]; i++)
			pCombo->AddString(g_pPRBlock->m_HVDCArray[i].szName);
		break;
	}
}

void CBpaPRParamMultStateDialog::RefreshMStateList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	int			nSelItem=-1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_DEVMSTATE]; i++)
	{
		pListCtrl->InsertItem(nRow, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_DevMStateArray[i].nType));

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_DevMStateArray[i].szName);
		sprintf(szBuf, "%d", g_pPRBlock->m_DevMStateArray[i].nStateNum);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszMStateColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		pListCtrl->SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamMultStateDialog::RefreshMStateText()
{
	int			nState, nFreq;
	CComboBox*	pComboBox;
	char		szBuf[260];
	double		*pfRate, *pfProb, *pfFreq;

	int			nSelItem=-1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);
	if (nSelItem < 0)
		return;

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pComboBox->SetCurSel(pComboBox->FindString(-1, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_DevMStateArray[nSelItem].nType)));
	OnCbnSelchangeDevtypeCombo();

	pComboBox=(CComboBox*)GetDlgItem(IDC_STATENUM_COMBO);
	pComboBox->SetCurSel(g_pPRBlock->m_DevMStateArray[nSelItem].nStateNum-1);
	OnCbnSelchangeStatenumCombo();

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVNAME_COMBO);
	pComboBox->SetCurSel(pComboBox->FindString(-1, g_pPRBlock->m_DevMStateArray[nSelItem].szName));

	pfRate=&g_pPRBlock->m_DevMStateArray[nSelItem].fState1Rate;
	pfProb=&g_pPRBlock->m_DevMStateArray[nSelItem].fState1Prob;
	pfFreq=&g_pPRBlock->m_DevMStateArray[nSelItem].fState1Freq1;
	for (nState=0; nState<g_pPRBlock->m_DevMStateArray[nSelItem].nStateNum; nState++)
	{
		sprintf(szBuf, "%f", pfRate[nState]);
		GetDlgItem(IDC_RATE1+nState)->SetWindowText(szBuf);
		sprintf(szBuf, "%f", pfProb[nState]);
		GetDlgItem(IDC_PROB1+nState)->SetWindowText(szBuf);
		for (nFreq=0; nFreq<g_pPRBlock->m_DevMStateArray[nSelItem].nStateNum; nFreq++)
		{
			sprintf(szBuf, "%f", pfFreq[nState*g_pPRBlock->m_DevMStateArray[nSelItem].nStateNum+nFreq]);
			GetDlgItem(IDC_FREQ11+10*nState+nFreq)->SetWindowText(szBuf);
		}
	}
}

int CBpaPRParamMultStateDialog::ResolveMStateText(tagPRDevMState* pMState)
{
	int			nBuffer, nState, nFreq;
	char		szBuf[260];
	CComboBox*	pComboBox;
	double		*pfRate, *pfProb, *pfFreq;

	memset(pMState, 0, sizeof(tagPRDevMState));

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	nBuffer = pComboBox->GetCurSel();
	if (nBuffer == CB_ERR)
		return 0;
	pMState->nType = nMStateDevType[nBuffer];

	pComboBox=(CComboBox*)GetDlgItem(IDC_STATENUM_COMBO);
	nBuffer = pComboBox->GetCurSel();
	if (nBuffer == CB_ERR)
		return 0;
	pMState->nStateNum = nBuffer+1;

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVNAME_COMBO);
	nBuffer = pComboBox->GetCurSel();
	if (nBuffer == CB_ERR)
		return 0;
	pComboBox->GetLBText(nBuffer, pMState->szName);

	pfRate=&pMState->fState1Rate;
	pfProb=&pMState->fState1Prob;
	pfFreq=&pMState->fState1Freq1;
	for (nState=0; nState<pMState->nStateNum; nState++)
	{
		GetDlgItem(IDC_RATE1+nState)->GetWindowText(szBuf, 260);
		pfRate[nState] = atof(szBuf);

		GetDlgItem(IDC_PROB1+nState)->GetWindowText(szBuf, 260);
		pfProb[nState] = atof(szBuf);

		for (nFreq=0; nFreq<pMState->nStateNum; nFreq++)
		{
			GetDlgItem(IDC_FREQ11+10*nState+nFreq)->GetWindowText(szBuf, 260);
			pfFreq[nState*pMState->nStateNum+nFreq] = atof(szBuf);
		}
	}

	return 1;
}

void CBpaPRParamMultStateDialog::OnNMClickMstateList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshMStateText();
	*pResult = 0;
}

void CBpaPRParamMultStateDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	tagPRDevMState	stBuffer;
	if (ResolveMStateText(&stBuffer))
	{
		if (PRAdequacyBase::AppendMStateParam(g_pPRBlock, &stBuffer))
		{
			g_PRMemDBInterface.PRMaint(g_pPRBlock);
			RefreshMStateList();
		}
	}
}

void CBpaPRParamMultStateDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int			nSelItem=-1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);
	if (nSelItem < 0)
		return;

	char	szMesg[260];
	sprintf(szMesg, "��ȷ��ɾ�� %s %s", g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_DevMStateArray[nSelItem].nType), g_pPRBlock->m_DevMStateArray[nSelItem].szName);
	if (AfxMessageBox(szMesg, MB_YESNO | MB_SYSTEMMODAL) == IDNO)
		return;

	g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_DEVMSTATE, nSelItem);
	RefreshMStateList();
}

void CBpaPRParamMultStateDialog::OnBnClickedMod()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int			nSelItem=-1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);
	if (nSelItem < 0)
		return;

	char	szMesg[260];
	sprintf(szMesg, "��ȷ���޸� %s %s", g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_DevMStateArray[nSelItem].nType), g_pPRBlock->m_DevMStateArray[nSelItem].szName);
	if (AfxMessageBox(szMesg, MB_YESNO | MB_SYSTEMMODAL) == IDNO)
		return;

	tagPRDevMState	stBuffer;
	if (ResolveMStateText(&stBuffer))
	{
		if (PRAdequacyBase::ModifyMStateParam(g_pPRBlock, nSelItem, &stBuffer))
		{
			g_PRMemDBInterface.PRMaint(g_pPRBlock);
			RefreshMStateList();
		}
	}
}
