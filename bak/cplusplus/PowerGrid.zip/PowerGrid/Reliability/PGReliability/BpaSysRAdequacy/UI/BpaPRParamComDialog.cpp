// BpaPRParamComDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamComDialog.h"


// CPRParamComDialog �Ի���
static	int		nPRParamDevType[]=
{
	PR_ACBUS,
	PR_GENERATOR,
	PR_ACLINE,
	PR_WIND,
	PR_POWERLOAD,
	PR_HVDC,
};

static	char*	lpszComColumn[]=
{
	"�豸����",
	"�ؼ���",
	"������(��/��̨/��)",
	"�޸�ʱ��(Сʱ)",
	"��ѹ����(�RkV)",
	"��ѹ����(��kV)",
	"��������(�RMW)",
	"��������(��MW)",
};

IMPLEMENT_DYNAMIC(CBpaPRParamComDialog, CDialog)

CBpaPRParamComDialog::CBpaPRParamComDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamComDialog::IDD, pParent)
{

}

CBpaPRParamComDialog::~CBpaPRParamComDialog()
{
}

void CBpaPRParamComDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamComDialog, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_COMMPARAM_LIST, &CBpaPRParamComDialog::OnNMClickCommparamList)
	ON_BN_CLICKED(IDC_ADD, &CBpaPRParamComDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CBpaPRParamComDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_UP, &CBpaPRParamComDialog::OnBnClickedUp)
	ON_BN_CLICKED(IDC_DN, &CBpaPRParamComDialog::OnBnClickedDn)
	ON_BN_CLICKED(IDC_MOD, &CBpaPRParamComDialog::OnBnClickedMod)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CBpaPRParamComDialog::OnCbnSelchangeDevtypeCombo)
	ON_BN_CLICKED(IDC_ALL, &CBpaPRParamComDialog::OnBnClickedAll)
END_MESSAGE_MAP()


// CPRParamComDialog ��Ϣ��������

BOOL CBpaPRParamComDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;
	CComboBox*	pComboBox;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszComColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszComColumn[i],	LVCFMT_LEFT,	60);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(nPRParamDevType)/sizeof(int); i++)
		pComboBox->AddString(g_PRMemDBInterface.PRGetTableDesp(nPRParamDevType[i]));
	pComboBox->SetCurSel(0);

	OnCbnSelchangeDevtypeCombo();

	RefreshPRParamCom();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamComDialog::RefreshPRParamCom()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	int			nSelItem=-1;
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMRPARAM]; i++)
	{
		pListCtrl->InsertItem(nRow, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_CommRParamArray[i].nDevType));

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_CommRParamArray[i].szKeyWord);

		sprintf(szBuf, "%f", g_pPRBlock->m_CommRParamArray[i].fRerr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CommRParamArray[i].fTrep);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CommRParamArray[i].fDnVLmt);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CommRParamArray[i].fUpVLmt);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CommRParamArray[i].fDnCapLmt);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CommRParamArray[i].fUpCapLmt);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszComColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		pListCtrl->SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamComDialog::OnNMClickCommparamList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int		nCol=0;
		int		nItem=pListCtrl->GetNextSelectedItem(pos);

		CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
		pComboBox->SetCurSel(pComboBox->FindString(-1, pListCtrl->GetItemText(nItem, nCol++)));

		GetDlgItem(IDC_ZONE)->			SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		GetDlgItem(IDC_RERR)->			SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		GetDlgItem(IDC_TREP)->			SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		GetDlgItem(IDC_DNV_LIMIT)->		SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		GetDlgItem(IDC_UPV_LIMIT)->		SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		GetDlgItem(IDC_DNCAP_LIMIT)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		GetDlgItem(IDC_UPCAP_LIMIT)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
	}
	*pResult = 0;
}

void CBpaPRParamComDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int		nTable = pComboBox->GetCurSel();
	if (nTable == CB_ERR)
	{
		AfxMessageBox("��ȷ���豸����");
		return;
	}

	char	szBuf[260];
	tagPRCommRParam	sParam;
	memset(&sParam, 0, sizeof(tagPRCommRParam));
	sParam.nDevType = nPRParamDevType[nTable];

	GetDlgItem(IDC_ZONE)->GetWindowText(szBuf, 260);
	if (strlen(szBuf) <= 0)	strcpy(szBuf, "ALL");
	strcpy(sParam.szKeyWord, szBuf);

	GetDlgItem(IDC_RERR)->			GetWindowText(szBuf, 260);	sParam.fRerr = atof(szBuf);
	GetDlgItem(IDC_TREP)->			GetWindowText(szBuf, 260);	sParam.fTrep = atof(szBuf);
	GetDlgItem(IDC_DNV_LIMIT)->		GetWindowText(szBuf, 260);	sParam.fDnVLmt = atof(szBuf);
	GetDlgItem(IDC_UPV_LIMIT)->		GetWindowText(szBuf, 260);	sParam.fUpVLmt = atof(szBuf);
	GetDlgItem(IDC_DNCAP_LIMIT)->	GetWindowText(szBuf, 260);	sParam.fDnCapLmt = atof(szBuf);
	GetDlgItem(IDC_UPCAP_LIMIT)->	GetWindowText(szBuf, 260);	sParam.fUpCapLmt = atof(szBuf);
	memcpy(&g_pPRBlock->m_CommRParamArray[g_pPRBlock->m_nRecordNum[PR_COMMRPARAM]++], &sParam, sizeof(tagPRCommRParam));

	RefreshPRParamCom();
}

void CBpaPRParamComDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nSelItem=pListCtrl->GetNextSelectedItem(pos);
		if (nSelItem >= 0 && nSelItem < g_pPRBlock->m_nRecordNum[PR_COMMRPARAM])
			g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_COMMRPARAM, nSelItem);
	}

	RefreshPRParamCom();
}

void CBpaPRParamComDialog::OnBnClickedMod()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int			nTable = pComboBox->GetCurSel();
	if (nTable == CB_ERR)
	{
		AfxMessageBox("��ȷ���豸����");
		return;
	}

	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
	{
		AfxMessageBox("��ȷ���޸ĵĲ���");
		return;
	}
	int	nSelItem=pListCtrl->GetNextSelectedItem(pos);
	if (nSelItem < 0 || nSelItem >= g_pPRBlock->m_nRecordNum[PR_COMMRPARAM])
	{
		AfxMessageBox("��ȷ���޸ĵĲ���");
		return;
	}

	char	szBuf[260];
	g_pPRBlock->m_CommRParamArray[nSelItem].nDevType = nPRParamDevType[nTable];

	GetDlgItem(IDC_ZONE)->GetWindowText(szBuf, 260);
	if (strlen(szBuf) <= 0)	strcpy(szBuf, "ALL");

	strcpy(g_pPRBlock->m_CommRParamArray[nSelItem].szKeyWord, szBuf);
	GetDlgItem(IDC_DNV_LIMIT)->GetWindowText(szBuf, 260);	g_pPRBlock->m_CommRParamArray[nSelItem].fDnVLmt = atof(szBuf);
	GetDlgItem(IDC_UPV_LIMIT)->GetWindowText(szBuf, 260);	g_pPRBlock->m_CommRParamArray[nSelItem].fUpVLmt = atof(szBuf);
	GetDlgItem(IDC_DNCAP_LIMIT)->GetWindowText(szBuf, 260);	g_pPRBlock->m_CommRParamArray[nSelItem].fDnCapLmt = atof(szBuf);
	GetDlgItem(IDC_UPCAP_LIMIT)->GetWindowText(szBuf, 260);	g_pPRBlock->m_CommRParamArray[nSelItem].fUpCapLmt = atof(szBuf);
	GetDlgItem(IDC_RERR)->GetWindowText(szBuf, 260);		g_pPRBlock->m_CommRParamArray[nSelItem].fRerr = atof(szBuf);
	GetDlgItem(IDC_TREP)->GetWindowText(szBuf, 260);		g_pPRBlock->m_CommRParamArray[nSelItem].fTrep = atof(szBuf);

	RefreshPRParamCom();
}

void CBpaPRParamComDialog::OnBnClickedUp()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);
		if (nItem > 0 && nItem < g_pPRBlock->m_nRecordNum[PR_COMMRPARAM])
		{
			tagPRCommRParam	sParam;
			memcpy(&sParam, &g_pPRBlock->m_CommRParamArray[nItem], sizeof(tagPRCommRParam));
			memcpy(&g_pPRBlock->m_CommRParamArray[nItem], &g_pPRBlock->m_CommRParamArray[nItem-1], sizeof(tagPRCommRParam));
			memcpy(&g_pPRBlock->m_CommRParamArray[nItem-1], &sParam, sizeof(tagPRCommRParam));
		}
		break;
	}

	RefreshPRParamCom();
}

void CBpaPRParamComDialog::OnBnClickedDn()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_COMMPARAM_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);
		if (nItem >= 0 && nItem < g_pPRBlock->m_nRecordNum[PR_COMMRPARAM]-1)
		{
			tagPRCommRParam	sParam;
			memcpy(&sParam, &g_pPRBlock->m_CommRParamArray[nItem], sizeof(tagPRCommRParam));
			memcpy(&g_pPRBlock->m_CommRParamArray[nItem], &g_pPRBlock->m_CommRParamArray[nItem+1], sizeof(tagPRCommRParam));
			memcpy(&g_pPRBlock->m_CommRParamArray[nItem+1], &sParam, sizeof(tagPRCommRParam));
		}
		break;
	}

	RefreshPRParamCom();
}

void CBpaPRParamComDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int		nTable = pComboBox->GetCurSel();
	if (nTable == CB_ERR)
		return;

	if (nPRParamDevType[nTable] == PR_ACLINE || nPRParamDevType[nTable] == PR_HVDC)
	{
		GetDlgItem(IDC_RERR_UNIT)->SetWindowText("��/�ٹ���.��");
	}
	else
	{
		GetDlgItem(IDC_RERR_UNIT)->SetWindowText("��/��̨(��).��");
	}
}

void CBpaPRParamComDialog::OnBnClickedAll()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItem(IDC_ZONE)->SetWindowText("ALL");
}
