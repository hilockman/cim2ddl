#pragma once


// CBpaPRParamConverterDialog �Ի���

class CBpaPRParamConverterDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamConverterDialog)

public:
	CBpaPRParamConverterDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamConverterDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_CONVERTER_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedRectifier();
	afx_msg void OnBnClickedInverter();
	DECLARE_MESSAGE_MAP()

private:
	void RefreshDeviceList();

private:
	int m_nConverterType;
public:
	afx_msg void OnBnClickedAddConverter();
	afx_msg void OnBnClickedDelConverter();
	afx_msg void OnNMClickGenloadList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedShowBushasconverter();
};
