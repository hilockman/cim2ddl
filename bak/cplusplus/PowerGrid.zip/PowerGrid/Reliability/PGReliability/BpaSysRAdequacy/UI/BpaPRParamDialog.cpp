// PRParamDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamDialog.h"


// CPRParamDialog �Ի���

IMPLEMENT_DYNAMIC(CBpaPRParamDialog, CDialog)

CBpaPRParamDialog::CBpaPRParamDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamDialog::IDD, pParent)
{

}

CBpaPRParamDialog::~CBpaPRParamDialog()
{
}

void CBpaPRParamDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamDialog, CDialog)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_SAVE, &CBpaPRParamDialog::OnBnClickedSave)
	ON_BN_CLICKED(IDC_SAVEAS, &CBpaPRParamDialog::OnBnClickedSaveas)
END_MESSAGE_MAP()


// CPRParamDialog ��Ϣ��������

BOOL CBpaPRParamDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CRect	rectDummy;
	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndPRParamCom.	Create(IDD_PRPARAM_COM_DIALOG,			&m_wndTab);
	m_wndPRParamDev.	Create(IDD_PRPARAM_DEV_DIALOG,			&m_wndTab);
	m_wndPRParamTcsc.	Create(IDD_PRPARAM_TCSC_DIALOG,			&m_wndTab);
	m_wndPRParamUpfc.	Create(IDD_PRPARAM_UPFC_DIALOG,			&m_wndTab);
	m_wndPRConverter.	Create(IDD_PRPARAM_CONVERTER_DIALOG,	&m_wndTab);
	m_wndPRDCLine.		Create(IDD_PRPARAM_DCLINE_DIALOG,		&m_wndTab);
	m_wndPRManuState.	Create(IDD_PRPARAM_MANUALFAULT_DIALOG,	&m_wndTab);
	m_wndPRCommonFault.	Create(IDD_PRPARAM_COMMONFAULT_DIALOG,	&m_wndTab);
	m_wndPRMultState.	Create(IDD_PRPARAM_MULTSTATE_DIALOG,	&m_wndTab);

	m_wndTab.AddTab (&m_wndPRParamCom,		_T("�����ɿ��Բ���"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndPRParamDev,		_T("�豸�ɿ��Բ���"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndPRParamTcsc,		_T("TCSC����"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndPRParamUpfc,		_T("UPFC����"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndPRConverter,		_T("�任��"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndPRDCLine,		_T("ֱ����·"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndPRManuState,		_T("�¼�"),				-1, FALSE);
	m_wndTab.AddTab (&m_wndPRCommonFault,	_T("����"),				-1, FALSE);
	m_wndTab.AddTab (&m_wndPRMultState,		_T("��״̬����"),		-1, FALSE);

	GetDlgItem(IDC_BPA_RPARAM_FILE)	->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

void CBpaPRParamDialog::OnBnClickedSave()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (g_PRAdeSetting.strBpaRParamFile.empty())
	{
		CString	fileExt=_T("RPAR");
		CString	defaultFileName=_T("");
		CString	fileFilter=_T("�ɿ��Բ����ļ�(*.rpar)|*.rpar;*.RPAR|�����ļ�(*.*)|*.*||");
		DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

		CFileDialog	dlg(FALSE,fileExt,
			defaultFileName,
			dwFlags,
			fileFilter,
			NULL);

		dlg.m_ofn.lpstrTitle=_T("�����ɿ��Բ����ļ�");
		dlg.m_ofn.lpstrInitialDir=_T("");
		dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

		if (dlg.DoModal() == IDCANCEL)
			return;

		g_PRAdeSetting.strBpaRParamFile = dlg.GetPathName();
		g_BpaPRParam.SaveBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}
	else
	{
		g_BpaPRParam.SaveBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}
}

void CBpaPRParamDialog::OnBnClickedSaveas()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("rpar");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("RPAR�ļ�(*.rpar)|*.rpar;*.RPAR|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�ɿ��Բ����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PRAdeSetting.strBpaRParamFile = dlg.GetPathName();
	g_BpaPRParam.SaveBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	GetDlgItem(IDC_BPA_RPARAM_FILE)->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());
}
