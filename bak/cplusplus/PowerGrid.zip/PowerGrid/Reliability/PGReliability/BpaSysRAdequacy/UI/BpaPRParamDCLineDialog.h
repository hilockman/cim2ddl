#pragma once


// CBpaPRParamDCLineDialog �Ի���

class CBpaPRParamDCLineDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamDCLineDialog)

public:
	CBpaPRParamDCLineDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamDCLineDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_DCLINE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedAddDcline();
	afx_msg void OnBnClickedDelDcline();
	afx_msg void OnNMClickDclineList(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
public:
private:
	void	RefreshDCLineList();
public:
};
