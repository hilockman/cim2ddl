#pragma once


// CPRParamManuDialog �Ի���

class CBpaPRParamManualFaultDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamManualFaultDialog)

public:
	CBpaPRParamManualFaultDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamManualFaultDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_MANUALFAULT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedAddState();
	afx_msg void OnBnClickedDelState();
	afx_msg void OnBnClickedAddFdev();
	afx_msg void OnBnClickedDelFdev();
	DECLARE_MESSAGE_MAP()
private:
	void	RefreshManualFaultTree();
public:
};
