// PRParamManuDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamCommonFaultDialog.h"
#include "BpaDeviceSelectDialog.h"

// CPRParamCommonFaultDialog �Ի���

IMPLEMENT_DYNAMIC(CBpaPRParamCommonFaultDialog, CDialog)

CBpaPRParamCommonFaultDialog::CBpaPRParamCommonFaultDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamCommonFaultDialog::IDD, pParent)
	, m_nCommFaultType(0)
	, m_nCommDeviceType(0)
{

}

CBpaPRParamCommonFaultDialog::~CBpaPRParamCommonFaultDialog()
{
}

void CBpaPRParamCommonFaultDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_COMMFAULT_STATUS, m_nCommFaultType);
	DDX_Radio(pDX, IDC_COMMDEVICE_COMMON, m_nCommDeviceType);
}


BEGIN_MESSAGE_MAP(CBpaPRParamCommonFaultDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD_COMMONFAULT, &CBpaPRParamCommonFaultDialog::OnBnClickedAddCommonFault)
	ON_BN_CLICKED(IDC_DEL_COMMONFAULT, &CBpaPRParamCommonFaultDialog::OnBnClickedDelCommonFault)
	ON_BN_CLICKED(IDC_ADD_COMMRESION_DEVICE, &CBpaPRParamCommonFaultDialog::OnBnClickedAddCommResionDevice)
	ON_BN_CLICKED(IDC_DEL_COMMDEVICE, &CBpaPRParamCommonFaultDialog::OnBnClickedDelCommDevice)
	ON_BN_CLICKED(IDC_MOD_COMMTYPE, &CBpaPRParamCommonFaultDialog::OnBnClickedModCommonFltType)
	ON_BN_CLICKED(IDC_MOD_DEVTYPE, &CBpaPRParamCommonFaultDialog::OnBnClickedModCommonDevType)
	ON_BN_CLICKED(IDC_ADD_COMMRESULT_DEVICE, &CBpaPRParamCommonFaultDialog::OnBnClickedAddCommResultDevice)
	ON_BN_CLICKED(IDC_CHECK_COMMDEVICE, &CBpaPRParamCommonFaultDialog::OnBnClickedCheckCommdevice)
END_MESSAGE_MAP()


// CPRParamManuDialog ��Ϣ��������

BOOL CBpaPRParamCommonFaultDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	RefreshCommonFaultTree();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamCommonFaultDialog::RefreshCommonFaultTree()
{
	register int	i;
	int			nCommon;

	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hSelectedItem = pTreeCtrl->GetSelectedItem();

	if (!pTreeCtrl->DeleteAllItems())
		return;

	TV_INSERTSTRUCT insItem;
	HTREEITEM	hRoot, hFPair, hDevice;
	int			nDevNum;
	char		szBuf[260];

	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; i++)
		g_pPRBlock->m_CommonFaultArray[i].bProc = 0;

	insItem.hParent=TVI_ROOT;
	insItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
	insItem.item.pszText=_T("�����¼����");
	insItem.item.cchTextMax=12;
	insItem.item.lParam=0;
	insItem.item.state=TVIS_BOLD | TVIS_EXPANDED;
	insItem.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
	hRoot=pTreeCtrl->InsertItem(&insItem);
	for (nCommon=0; nCommon<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; nCommon++)
	{
		if (g_pPRBlock->m_CommonFaultArray[nCommon].bProc)
			continue;

		nDevNum = 0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; i++)
		{
			if (stricmp(g_pPRBlock->m_CommonFaultArray[nCommon].szName, g_pPRBlock->m_CommonFaultArray[i].szName) != 0)
				continue;
			nDevNum++;
		}

		sprintf(szBuf, "����");

		insItem.hParent=hRoot;
		insItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
		insItem.item.stateMask=TVIS_EXPANDED | TVIS_SELECTED;
		insItem.item.pszText=szBuf;
		insItem.item.cchTextMax=260;
		insItem.item.lParam=nCommon;
		hFPair = pTreeCtrl->InsertItem(&insItem);
		pTreeCtrl->SetItemData(hFPair, nCommon+1);

		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; i++)
		{
			if (stricmp(g_pPRBlock->m_CommonFaultArray[nCommon].szName, g_pPRBlock->m_CommonFaultArray[i].szName) != 0)
				continue;
			g_pPRBlock->m_CommonFaultArray[i].bProc = 1;

			sprintf(szBuf, "�������� %s  �豸���� %s  �����豸[%d/%d] %s %s ",
				g_PRMemDBInterface.PRGetFieldEnumString(PR_COMMONFAULT, PR_COMMONFAULT_COMMFAULTTYPE, g_pPRBlock->m_CommonFaultArray[nCommon].nCommonFaultType),
				g_PRMemDBInterface.PRGetFieldEnumString(PR_COMMONFAULT, PR_COMMONFAULT_DEVICECOMMTYPE, g_pPRBlock->m_CommonFaultArray[i].nDeviceCommonType),
				i+1, nDevNum,
				g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_CommonFaultArray[i].nDevType), g_pPRBlock->m_CommonFaultArray[i].szDevName);

			insItem.hParent=hFPair;
			insItem.item.mask=TVIF_TEXT | TVIF_PARAM;
			insItem.item.pszText=szBuf;
			insItem.item.cchTextMax=260;
			insItem.item.lParam=nCommon;
			hDevice = pTreeCtrl->InsertItem(&insItem);
			pTreeCtrl->SetItemData(hDevice, i+1);
		}
	}

	if (hSelectedItem != NULL)
		pTreeCtrl->SelectItem(hSelectedItem);
}

void CBpaPRParamCommonFaultDialog::OnBnClickedAddCommonFault()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	tagPRCommonFault	sCommon;
	memset(&sCommon, 0, sizeof(tagPRCommonFault));

	time_t		now;
	struct tm	when;
	time(&now);
	when = *localtime( &now );
	sprintf(sCommon.szName, "����%.4d%.2d%.2d%.2d%.2d%.2d", when.tm_year+1900, when.tm_mon+1, when.tm_mday, when.tm_hour, when.tm_min, when.tm_sec);
	sCommon.nDeviceCommonType = PRCommonFault_DeviceCommonType_Resion;
	sCommon.nCommonFaultType = m_nCommFaultType;

	CBpaDeviceSelectDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;

	sCommon.nDevType = dlg.m_nDevType;

	register int	i;
	int				nDev;
	unsigned char	bExist;
	for (nDev=0; nDev<(int)dlg.m_strDevArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; i++)
		{
			if (stricmp(g_pPRBlock->m_CommonFaultArray[i].szName, sCommon.szName) != 0)
				continue;

			if (g_pPRBlock->m_CommonFaultArray[i].nDevType == sCommon.nDevType && stricmp(g_pPRBlock->m_CommonFaultArray[i].szDevName, dlg.m_strDevArray[nDev].c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			if (g_pPRBlock->m_nRecordNum[PR_COMMONFAULT] < g_PRMemDBInterface.PRGetTableMax(PR_COMMONFAULT))
			{
				strcpy(sCommon.szDevName, dlg.m_strDevArray[nDev].c_str());
				memcpy(&g_pPRBlock->m_CommonFaultArray[g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]++], &sCommon, sizeof(tagPRCommonFault));
			}
		}
	}

	RefreshCommonFaultTree();
}

void CBpaPRParamCommonFaultDialog::OnBnClickedDelCommonFault()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ����ɾ�������¼");
		return;
	}

	char	szCommonFault[MDB_CHARLEN];
	int	nCommon=(int)pTreeCtrl->GetItemData(hItem) - 1;
	if (nCommon < 0 || nCommon >= g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
		return;

	strcpy(szCommonFault, g_pPRBlock->m_CommonFaultArray[nCommon].szName);

	nCommon = 0;
	while (nCommon < g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
	{
		if (stricmp(g_pPRBlock->m_CommonFaultArray[nCommon].szName, szCommonFault) == 0)
			g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_COMMONFAULT, nCommon);
		else
			nCommon++;
	}
	RefreshCommonFaultTree();
}


void CBpaPRParamCommonFaultDialog::OnBnClickedModCommonFltType()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ�����޸��豸");
		return;
	}

	char	szCommonFault[MDB_CHARLEN];
	int	nComm=(int)pTreeCtrl->GetItemData(hItem) - 1;
	if (nComm < 0 || nComm >= g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
		return;
	strcpy(szCommonFault, g_pPRBlock->m_CommonFaultArray[nComm].szName);

	for (nComm=0; nComm<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; nComm++)
	{
		if (stricmp(g_pPRBlock->m_CommonFaultArray[nComm].szName, szCommonFault) == 0)
			g_pPRBlock->m_CommonFaultArray[nComm].nCommonFaultType = m_nCommFaultType;
	}



	RefreshCommonFaultTree();
}


void CBpaPRParamCommonFaultDialog::OnBnClickedAddCommResionDevice()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ���������豸�Ĺ����¼");
		return;
	}

	UpdateData();

	int	nCommon=(int)pTreeCtrl->GetItemData(hItem) - 1;
	if (nCommon < 0 || nCommon >= g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
		return;

	tagPRCommonFault		sCommon;
	CBpaDeviceSelectDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;

	memset(&sCommon, 0, sizeof(tagPRCommonFault));

	strcpy(sCommon.szName, g_pPRBlock->m_CommonFaultArray[nCommon].szName);
	sCommon.nCommonFaultType = g_pPRBlock->m_CommonFaultArray[nCommon].nCommonFaultType;
	sCommon.nDevType = dlg.m_nDevType;
	sCommon.nDeviceCommonType = PRCommonFault_DeviceCommonType_Resion;

	register int	i;
	int				nDev;
	unsigned char	bExist;
	for (nDev=0; nDev<(int)dlg.m_strDevArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; i++)
		{
			if (g_pPRBlock->m_CommonFaultArray[i].nDevType == sCommon.nDevType && stricmp(g_pPRBlock->m_CommonFaultArray[i].szDevName, dlg.m_strDevArray[nDev].c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			strcpy(sCommon.szDevName, dlg.m_strDevArray[nDev].c_str());
			if (g_pPRBlock->m_nRecordNum[PR_COMMONFAULT] < g_PRMemDBInterface.PRGetTableMax(PR_COMMONFAULT))
				memcpy(&g_pPRBlock->m_CommonFaultArray[g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]++], &sCommon, sizeof(tagPRCommonFault));
		}
	}

	RefreshCommonFaultTree();
}

void CBpaPRParamCommonFaultDialog::OnBnClickedAddCommResultDevice()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ���������豸�Ĺ����¼");
		return;
	}

	UpdateData();

	int	nCommon=(int)pTreeCtrl->GetItemData(hItem) - 1;
	if (nCommon < 0 || nCommon >= g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
		return;

	tagPRCommonFault		sCommon;
	CBpaDeviceSelectDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;

	memset(&sCommon, 0, sizeof(tagPRCommonFault));

	strcpy(sCommon.szName, g_pPRBlock->m_CommonFaultArray[nCommon].szName);
	sCommon.nCommonFaultType = g_pPRBlock->m_CommonFaultArray[nCommon].nCommonFaultType;

	sCommon.nDevType = dlg.m_nDevType;
	sCommon.nDeviceCommonType = PRCommonFault_DeviceCommonType_Result;

	register int	i;
	int				nDev;
	unsigned char	bExist;
	for (nDev=0; nDev<(int)dlg.m_strDevArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; i++)
		{
			if (g_pPRBlock->m_CommonFaultArray[i].nDevType == sCommon.nDevType && stricmp(g_pPRBlock->m_CommonFaultArray[i].szDevName, dlg.m_strDevArray[nDev].c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			strcpy(sCommon.szDevName, dlg.m_strDevArray[nDev].c_str());
			if (g_pPRBlock->m_nRecordNum[PR_COMMONFAULT] < g_PRMemDBInterface.PRGetTableMax(PR_COMMONFAULT))
				memcpy(&g_pPRBlock->m_CommonFaultArray[g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]++], &sCommon, sizeof(tagPRCommonFault));
		}
	}

	RefreshCommonFaultTree();
}

void CBpaPRParamCommonFaultDialog::OnBnClickedDelCommDevice()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ����ɾ���豸");
		return;
	}

	int	nCommonFault=(int)pTreeCtrl->GetItemData(hItem) - 1;
	if (nCommonFault < 0 || nCommonFault >= g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
		return;

	g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_COMMONFAULT, nCommonFault);
	RefreshCommonFaultTree();
}

void CBpaPRParamCommonFaultDialog::OnBnClickedModCommonDevType()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTreeCtrl*	pTreeCtrl=(CTreeCtrl*)GetDlgItem(IDC_COMMON_FAULT_TREE);
	HTREEITEM	hItem=pTreeCtrl->GetSelectedItem();
	if (hItem == NULL)
	{
		AfxMessageBox("��ȷ�����޸��豸");
		return;
	}

	int	nCommonFault=(int)pTreeCtrl->GetItemData(hItem) - 1;
	if (nCommonFault < 0 || nCommonFault >= g_pPRBlock->m_nRecordNum[PR_COMMONFAULT])
		return;

	UpdateData();
	g_pPRBlock->m_CommonFaultArray[nCommonFault].nDeviceCommonType = m_nCommDeviceType;

	RefreshCommonFaultTree();
}

void CBpaPRParamCommonFaultDialog::OnBnClickedCheckCommdevice()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		nCommType, nCommDev;
	for (nCommType=0; nCommType<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; nCommType++)
		g_pPRBlock->m_CommonFaultArray[nCommType].bProc = 0;

	for (nCommType=0; nCommType<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; nCommType++)
	{
		if (g_pPRBlock->m_CommonFaultArray[nCommType].bProc)
			continue;

		if (g_pPRBlock->m_CommonFaultArray[nCommType].nCommonFaultType != PRCommonFault_CommonFaultType_PValue)
			continue;

		unsigned char	bHasError = 0;
		for (nCommDev=0; nCommDev<g_pPRBlock->m_nRecordNum[PR_COMMONFAULT]; nCommDev++)
		{
			if (stricmp(g_pPRBlock->m_CommonFaultArray[nCommDev].szName, g_pPRBlock->m_CommonFaultArray[nCommType].szName) != 0)
				continue;

			g_pPRBlock->m_CommonFaultArray[nCommDev].bProc = 1;
			if (g_pPRBlock->m_CommonFaultArray[nCommDev].nDevType != PR_GENERATOR && g_pPRBlock->m_CommonFaultArray[nCommDev].nDevType != PR_POWERLOAD)
			{
				char	szMesg[260];
				sprintf(szMesg, "�����¼=%s �����豸=%s[%s] ��ģģʽ���ʵ���ģʽ���豸�����Ƿ���͸��ɣ���֧����·����ѹ����",
					g_pPRBlock->m_CommonFaultArray[nCommType].szName, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_CommonFaultArray[nCommDev].nDevType), g_pPRBlock->m_CommonFaultArray[nCommDev].szDevName);
				AfxMessageBox(szMesg);
				bHasError = 1;
				break;
			}
		}
		if (bHasError)
			break;
	}
}
