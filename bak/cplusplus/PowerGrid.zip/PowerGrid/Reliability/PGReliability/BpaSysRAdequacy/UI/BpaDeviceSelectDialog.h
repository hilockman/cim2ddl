#pragma once

#include "../../../../../Common/MFCControls/MFCListCtrlEx.h"

// CBpaDeviceSelectDialog �Ի���

class CBpaDeviceSelectDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaDeviceSelectDialog)

public:
	CBpaDeviceSelectDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaDeviceSelectDialog();

// �Ի�������
	enum { IDD = IDD_BPA_DEVICE_SELECT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnCbnSelchangeDevtypeCombo();

	DECLARE_MESSAGE_MAP()

private:
	void	RefreshDeviceList();

public:
	int		m_nDevType;
	std::vector<std::string>	m_strDevArray;
};
