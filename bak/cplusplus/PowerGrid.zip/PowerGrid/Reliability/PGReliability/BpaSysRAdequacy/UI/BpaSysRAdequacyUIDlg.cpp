
// PRelibilityUIDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaSysRAdequacyUIDlg.h"
#include "BpaZILDetailDialog.h"
#include "BpaRingRadDialog.h"
#include "BpaDCFlowDialog.h"
#include "BpaPRParamDialog.h"
#include "PRSampleSetDialog.h"
#include "PREstimateSetDialog.h"

#include "../../../../../Common/String2Double.hpp"
#include "../../../../../Common/Excel/ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

clock_t	m_dBeg;

extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);
extern	void	PRSetting2BpaPRSetting(tagPRSetting* pPRSetting, tagBpaPRAdequacySetting* pBpaPRSetting);
extern	void	PRParam2BpaPRParam(tagPRBlock* pPRBlock, CPRParam* pPRParam, CBpaPRParam* pBpaPRParam);

//////////////////////////////////////////////////////////////////////////
// CPRelibilityUIDlg �Ի���

#define	IDC_RSYSRESULT_LISTCTRL	20022
#define	IDC_RBUSRESULT_LISTCTRL	20023
#define	IDC_ROVLADJUST_LISTCTRL	20024

static	unsigned char	m_bUIFreezed = 0;

static	char*	lpszRSysResultColumn[]={
	"ָ��",
	"���",
};

CBpaSysAdequacyUIDlg::CBpaSysAdequacyUIDlg(CWnd* pParent /*=NULL*/)
: CDialog(CBpaSysAdequacyUIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_nAdequacyEstimateNum = 0;
	m_hAdequacyEstimateHandle = INVALID_HANDLE_VALUE;

}

void CBpaSysAdequacyUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CBpaSysAdequacyUIDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_EN_CHANGE(IDC_DC2AC_FACTOR, &CBpaSysAdequacyUIDlg::OnChangeRParam)
	ON_EN_CHANGE(IDC_ZERO_IMPEDANCE_THRESHOLD, &CBpaSysAdequacyUIDlg::OnChangeRParam)
	ON_BN_CLICKED(IDC_GENBUS_LOAD_ASAUX, &CBpaSysAdequacyUIDlg::OnChangeRParam)

	ON_BN_CLICKED(IDC_SYSADEQUACY_SAMPLE,   &CBpaSysAdequacyUIDlg::OnBnClickedSysAdequacySample)
	ON_BN_CLICKED(IDC_SYSADEQUACY_ESTIMATE, &CBpaSysAdequacyUIDlg::OnBnClickedSysAdequacyEstimate)

	ON_BN_CLICKED(IDC_DAT_BROWSE, &CBpaSysAdequacyUIDlg::OnBnClickedDatBrowse)
	ON_BN_CLICKED(IDC_SWI_BROWSE, &CBpaSysAdequacyUIDlg::OnBnClickedSwiBrowse)
	ON_BN_CLICKED(IDC_CLEAR_MESG, &CBpaSysAdequacyUIDlg::OnBnClickedClearMesg)
	ON_BN_CLICKED(IDC_BROWSE_RAI, &CBpaSysAdequacyUIDlg::OnBnClickedBrowseRai)
	ON_BN_CLICKED(IDC_BROWSE_RML, &CBpaSysAdequacyUIDlg::OnBnClickedBrowseRml)
	ON_BN_CLICKED(IDC_EDIT_RPARAM, &CBpaSysAdequacyUIDlg::OnBnClickedRParamEdit)

	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CBpaSysAdequacyUIDlg::OnBnClickedSaveasExcel)
	ON_BN_CLICKED(IDC_RPARAM_BROWSE, &CBpaSysAdequacyUIDlg::OnBnClickedRParamBrowse)

	ON_MESSAGE(WM_ESTIMATEBEG, OnAdequacyEstimateBegin)
	ON_MESSAGE(WM_ESTIMATING, OnAdequacyEstimating)
	ON_MESSAGE(WM_ESTIMATEEND, OnAdequacyEstimateEnded)
	ON_BN_CLICKED(IDC_DAT_ERASE, &CBpaSysAdequacyUIDlg::OnBnClickedDatErase)
	ON_BN_CLICKED(IDC_SWI_ERASE, &CBpaSysAdequacyUIDlg::OnBnClickedSwiErase)
	ON_BN_CLICKED(IDC_ERASE_RPARAM, &CBpaSysAdequacyUIDlg::OnBnClickedRParamErase)
	ON_BN_CLICKED(IDC_DCFLOW, &CBpaSysAdequacyUIDlg::OnBnClickedDcflow)
	ON_BN_CLICKED(IDC_ACFLOW, &CBpaSysAdequacyUIDlg::OnBnClickedAcflow)
	ON_BN_CLICKED(IDC_MERGEZIL, &CBpaSysAdequacyUIDlg::OnBnClickedMergezil)
	ON_BN_CLICKED(IDC_DECOMPOSE, &CBpaSysAdequacyUIDlg::OnBnClickedDecompose)
END_MESSAGE_MAP()

// CPRelibilityUIDlg ��Ϣ��������

BOOL CBpaSysAdequacyUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	CRect	rectDummy;
	int		nColumn;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndSampleState.Create(IDD_PRESULT_SAMPLESTATE_DIALOG,	&m_wndTab);
	m_wndBusReliability.Create(IDD_PRESULT_BUSRELIABILITY_DIALOG,	&m_wndTab);
	m_wndOverLimit.Create(IDD_PRESULT_OVERLIMIT_DIALOG,	&m_wndTab);
	m_wndDevice.Create(IDD_PRESULT_DEVICE_DIALOG,	&m_wndTab);

	if (!m_wndPRSysResultList.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndTab, IDC_RSYSRESULT_LISTCTRL))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndPRSysResultList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndPRSysResultList.SetExtendedStyle(m_wndPRSysResultList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndPRSysResultList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRSysResultColumn)/sizeof(char*); nColumn++)
		m_wndPRSysResultList.InsertColumn(nColumn, lpszRSysResultColumn[nColumn],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndSampleState,			_T("����״̬��"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndPRSysResultList,		_T("ϵͳ������"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndBusReliability,		_T("ĸ�߼�����"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndOverLimit,			_T("Խ���豸����"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndDevice,				_T("�豸������Ϣ"),	-1, FALSE);

	LoadBpaModelFile();

	RefreshParam();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CBpaSysAdequacyUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CBpaSysAdequacyUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void	CBpaSysAdequacyUIDlg::PrintMessage(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);

	vsprintf(szMesg, pformat, args);

	int	iExt = GetTextLen(szMesg);
	if (iExt > pListBox->GetHorizontalExtent())
		pListBox->SetHorizontalExtent(iExt);
	pListBox->AddString(szMesg);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	va_end(args);
}

int CBpaSysAdequacyUIDlg::GetTextLen(LPCTSTR lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC* pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(lpszText, (int) _tcslen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(lpszText, (int) _tcslen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CBpaSysAdequacyUIDlg::RefreshParam()
{
	char	szBuf[260];

	m_bUIFreezed=1;

	((CButton*)GetDlgItem(IDC_GENBUS_LOAD_ASAUX))->SetCheck(g_PRAdeSetting.bGenBusLoadAsAux);
	sprintf(szBuf, "%g", g_PRAdeSetting.fZIL);				GetDlgItem(IDC_ZERO_IMPEDANCE_THRESHOLD)->SetWindowText(szBuf);
	sprintf(szBuf, "%.3f", g_PRAdeSetting.fDc2AcFactor);		GetDlgItem(IDC_DC2AC_FACTOR)->SetWindowText(szBuf);

	GetDlgItem(IDC_BPADAT_FILE)		->SetWindowText(g_PRAdeSetting.strBpaDatFile.c_str());
	GetDlgItem(IDC_BPASWI_FILE)		->SetWindowText(g_PRAdeSetting.strBpaSwiFile.c_str());
	GetDlgItem(IDC_BPA_RPARAM_FILE)	->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());

	m_bUIFreezed=0;
}

void CBpaSysAdequacyUIDlg::OnChangeRParam()
{
	char	szBuffer[260];

	if (m_bUIFreezed)
		return;

	g_PRAdeSetting.bGenBusLoadAsAux = ((CButton*)GetDlgItem(IDC_GENBUS_LOAD_ASAUX))->GetCheck();
	GetDlgItem(IDC_ZERO_IMPEDANCE_THRESHOLD)->GetWindowText(szBuffer, 260);		g_PRAdeSetting.fZIL=atof(szBuffer);
	GetDlgItem(IDC_DC2AC_FACTOR)->GetWindowText(szBuffer, 260);					g_PRAdeSetting.fDc2AcFactor=atof(szBuffer);
	if (g_PRAdeSetting.fDc2AcFactor < 1 || g_PRAdeSetting.fDc2AcFactor > 2)
		g_PRAdeSetting.fDc2AcFactor=1.15;

	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaSysAdequacyUIDlg::OnBnClickedDatBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("dat");
	CString	defaultFileName=g_PRAdeSetting.strBpaDatFile.c_str();
	CString	fileFilter=_T("BPA�����ļ�(*.dat)|*.dat;*.DAT|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("��BPA�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;


	g_PRAdeSetting.strBpaDatFile = dlg.GetPathName();
	GetDlgItem(IDC_BPADAT_FILE)->SetWindowText(g_PRAdeSetting.strBpaDatFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
	LoadBpaModelFile();

	PrintMessage("����BPA���������ļ����");
}

void CBpaSysAdequacyUIDlg::OnBnClickedSwiBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("swi");
	CString	defaultFileName=g_PRAdeSetting.strBpaSwiFile.c_str();
	CString	fileFilter=_T("BPA�ȶ��ļ�(*.swi)|*.swi;*.SWI|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("��BPA�ȶ��ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PRAdeSetting.strBpaSwiFile = dlg.GetPathName();
	GetDlgItem(IDC_BPASWI_FILE)->SetWindowText(g_PRAdeSetting.strBpaSwiFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
	LoadBpaModelFile();

	PrintMessage("����BPA�ȶ������ļ����");
}

void CBpaSysAdequacyUIDlg::OnBnClickedRParamBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("RPAR");
	CString	defaultFileName=g_PRAdeSetting.strBpaRParamFile.c_str();
	CString	fileFilter=_T("�ɿ��Բ����ļ�(*.rpar)|*.rpar;*.RPAR|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�ɿ��Բ����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PRAdeSetting.strBpaRParamFile = dlg.GetPathName();
	GetDlgItem(IDC_BPA_RPARAM_FILE)->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);

	g_BpaPRParam.ReadBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
}

void CBpaSysAdequacyUIDlg::OnBnClickedDatErase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRAdeSetting.strBpaDatFile.clear();
	GetDlgItem(IDC_BPADAT_FILE)->SetWindowText(g_PRAdeSetting.strBpaDatFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaSysAdequacyUIDlg::OnBnClickedSwiErase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRAdeSetting.strBpaSwiFile.clear();
	GetDlgItem(IDC_BPASWI_FILE)->SetWindowText(g_PRAdeSetting.strBpaSwiFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaSysAdequacyUIDlg::OnBnClickedRParamErase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRAdeSetting.strBpaRParamFile.clear();
	GetDlgItem(IDC_BPA_RPARAM_FILE)->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaSysAdequacyUIDlg::OnBnClickedBrowseRai()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("rai");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("�ɿ��Լ�������ļ�(*.rai)|*.rai;*.RAI|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪿ɿ��Լ�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	char	szFileName[260];
	strcpy(szFileName, dlg.GetPathName());
	if (m_PRParam.ParseRaiFile(szFileName, &m_PRSetting))
	{
		PRSetting2BpaPRSetting(&m_PRSetting, &g_PRAdeSetting);
		PrintMessage("���ؿɿ���RAI�����ļ����");
	}

	LoadBpaModelFile();

	RefreshParam();
}

void CBpaSysAdequacyUIDlg::OnBnClickedBrowseRml()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("rml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("�ɿ����豸�����ļ�(*.rml)|*.rml;*.RML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlgRML(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlgRML.m_ofn.lpstrTitle=_T("�ɿ����豸�����ļ�");
	dlgRML.m_ofn.lpstrInitialDir=_T("");
	dlgRML.m_ofn.lStructSize=sizeof(dlgRML.m_ofn);

	if (dlgRML.DoModal() == IDCANCEL)
		return;

	m_PRParam.ParseRmlFile2PRMemDB(g_pPRBlock, dlgRML.GetPathName());
	PRParam2BpaPRParam(g_pPRBlock, &m_PRParam, &g_BpaPRParam);
	PrintMessage("���ؿɿ���RML�����ļ����");
}

void CBpaSysAdequacyUIDlg::OnBnClickedClearMesg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	pListBox->ResetContent();
}

LRESULT CBpaSysAdequacyUIDlg::OnAdequacyEstimateBegin(WPARAM wParam, LPARAM lParam)
{
	m_nAdequacyEstimateNum = 0;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetRange32(0, g_pPRBlock->m_nRecordNum[PR_FSTATE]);

	PrintMessage("���������㿪ʼ\n");
	return 0;
}

LRESULT CBpaSysAdequacyUIDlg::OnAdequacyEstimating(WPARAM wParam, LPARAM lParam)
{
	m_nAdequacyEstimateNum += (int)wParam;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos(m_nAdequacyEstimateNum);
	return 0;
}

LRESULT CBpaSysAdequacyUIDlg::OnAdequacyEstimateEnded(WPARAM wParam, LPARAM lParam)
{
	clock_t	dEnd;
	int		nDur;

	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos((int)wParam);

	m_nAdequacyEstimateNum = 0;
	if (m_hAdequacyEstimateHandle != INVALID_HANDLE_VALUE)
		CloseHandle(m_hAdequacyEstimateHandle);
	m_hAdequacyEstimateHandle = INVALID_HANDLE_VALUE;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-m_dBeg))/CLOCKS_PER_SEC);

	PrintMessage("������������ϣ���ʱ%d����\n", nDur);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-m_dBeg))/CLOCKS_PER_SEC);

	PrintMessage("ͳ�Ƽ�������ɣ���ʱ%d����\n", nDur);

	m_wndSampleState.RefreshUI(2);
	RefreshPRSysResultList();
	m_wndBusReliability.RefreshUI();
	m_wndOverLimit.RefreshUI();

	return 0;
}

int  CBpaSysAdequacyUIDlg::PreparePRData()
{
	char	drive[260], dir[260], fname[260], ext[260];
	char	szFileName[260], szBpaPFExec[260], szWorkDir[260], szExec[260];

	sprintf(szBpaPFExec, "%s/pfnt.exe", g_szRunDir);
	if (access(szBpaPFExec, 0) != 0)
		return 0;

	_splitpath(g_PRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
	_makepath(szWorkDir, drive, dir, NULL, NULL);
	SetCurrentDirectory(szWorkDir);

	sprintf(szFileName,"%s%s",fname,ext);
	sprintf(szExec,"%s %s", szBpaPFExec, szFileName);
	PrintMessage(szExec);
	StartProcess(szExec, NULL, SW_HIDE);

	_makepath(szFileName, drive, dir, fname, ".pfo");
	if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName) <= 0)
	{
		PrintMessage("��PFO�ļ�������㽻������\n");
		return 0;
	}

	BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������
	g_PRAdeEstimate.AdjustDeviceRated(g_pPRBlock, g_PRAdeSetting.fDc2AcFactor, 0);
	if (!g_PRAdeSetting.strBpaRParamFile.empty())
		g_BpaPRParam.ReadBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);

	return 1;
}

void CBpaSysAdequacyUIDlg::OnBnClickedRParamEdit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CBpaPRParamDialog	dlg;
	dlg.DoModal();
	GetDlgItem(IDC_BPA_RPARAM_FILE)	->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());
}

void CBpaSysAdequacyUIDlg::RefreshPRSysResultList()
{
	int		nRow, nCol;
	char	szBuf[260];
	int	nColWidth,nHeaderWidth;

	m_wndPRSysResultList.DeleteAllItems();

	nRow=0;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_MAXFLTDEV));		sprintf(szBuf,"%d",g_pPRBlock->m_System.nMaxFltDev);		m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_PLC));				sprintf(szBuf,"%f",g_pPRBlock->m_System.fPLC);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_EFLC));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fEFLC);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_EDLC));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fEDLC);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_ADLC));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fADLC);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_ELC));				sprintf(szBuf,"%f",g_pPRBlock->m_System.fELC);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_EENS));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fEENS);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_BPII));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fBPII);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_BPECI));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fBPECI);			m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_SI));				sprintf(szBuf,"%f",g_pPRBlock->m_System.fSI);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_LOLE));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fLOLE);				m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_MIEENS));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fMIslandEENS);		m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_AGCEENS));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fLossGenEENS);		m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_ELEENS));			sprintf(szBuf,"%f",g_pPRBlock->m_System.fERLimitEENS);		m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE0PROB));	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade0Prob);	m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE1PROB));	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade1Prob);	m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE2PROB));	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade2Prob);	m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE3PROB));	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade3Prob);	m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;
	m_wndPRSysResultList.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE4PROB));	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade4Prob);	m_wndPRSysResultList.SetItemText(nRow, 1, szBuf);	nRow++;

	for (nCol=0; nCol<sizeof(lpszRSysResultColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndPRSysResultList.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndPRSysResultList.GetColumnWidth(nCol);
		m_wndPRSysResultList.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndPRSysResultList.GetColumnWidth(nCol);

		m_wndPRSysResultList.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaSysAdequacyUIDlg::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_wndPRSysResultList.GetItemCount() <= 0)
	{
		PrintMessage("�޼�����");
		return;
	}

	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	PrintMessage("Excel������ʼ");

	int		nRow, nCol, nFieldNum;
	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	m_wndBusReliability.ExcelOut(&xls);
	m_wndOverLimit.ExcelOut(&xls);
	m_wndSampleState.ExcelOut(&xls);
	m_wndDevice.ExcelOut(&xls);

	xls.AddSheet(_T("ϵͳ�ɿ��Լ�����"));
	xls.SetCurSheet(_T("ϵͳ�ɿ��Լ�����"));

	nFieldNum=sizeof(lpszRSysResultColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		xls.AddCell(CString(lpszRSysResultColumn[nCol]));
	for (nRow=0; nRow<m_wndPRSysResultList.GetItemCount(); nRow++)
	{
		xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(m_wndPRSysResultList.GetItemText(nRow, nCol));
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));

	PrintMessage("Excel�������");
}

void CBpaSysAdequacyUIDlg::LoadBpaModelFile(void)
{
	if (_access(g_PRAdeSetting.strBpaDatFile.c_str(), 0) == 0)
	{
		char	drive[260], dir[260], fname[260], ext[260];
		char	szFileName[260];

		g_BpaMemDBInterface.BpaFiles2MemDB(g_pBpaBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.fZIL);

		_splitpath(g_PRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
		_makepath(szFileName, drive, dir, fname, ".pfo");
		if (_access(szFileName, 0) == 0)
			g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName);

		BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������
		//g_PRAdeEstimate.AdjustDeviceRated(g_pPRBlock, g_PRAdeSetting.fDc2AcFactor, 0);
		if (!g_PRAdeSetting.strBpaRParamFile.empty())
			g_BpaPRParam.ReadBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}
}

void CBpaSysAdequacyUIDlg::OnBnClickedSysAdequacySample()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CPRSampleSetDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	UpdateData();
	if (!PreparePRData())
		return;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("ReadBpaData ( �������� = %s �豸���� = %s ) ��ϣ���ʱ%d����\n",
		g_PRMemDBInterface.PRGetFieldEnumString(PR_SYSTEM, PR_SYSTEM_SAMPLEMETHOD, dlg.m_nPRSampleMethod),
		g_PRMemDBInterface.PRGetFieldEnumString(PR_SYSTEM, PR_SYSTEM_SAMPLEOBJECT, g_PRAdeSetting.nPRSampleObject), nDur);

	int	nStateNum=g_PRStateSample.Sample(g_pPRBlock, dlg.m_nPRSampleObject, dlg.m_nPRSampleMethod, &g_PRAdeSetting);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("״̬������ϣ���ʱ%d���� ״̬��=%d\n",nDur, nStateNum);

	m_wndSampleState.RefreshUI(0);

	RefreshPRSysResultList();
	m_wndTab.SetActiveTab(0);
}

void CBpaSysAdequacyUIDlg::OnBnClickedSysAdequacyEstimate()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_dBeg=clock();

	if (m_hAdequacyEstimateHandle != INVALID_HANDLE_VALUE)
	{
		AfxMessageBox("�����ϵͳ��ԣ����������������......����ȴ�������������");
		return;
	}

	CPREstimateSetDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;

	UpdateData();

	m_hAdequacyEstimateHandle = g_PRAdeEstimate.SysAdequacyEstimate(g_pPRBlock,
		g_PRAdeSetting.nMultiThread,
		g_PRAdeSetting.fDc2AcFactor,
		g_PRAdeSetting.fMinIslandGLRatio,
		g_PRAdeSetting.bLineELimit,
		g_PRAdeSetting.bTranELimit,
		g_PRAdeSetting.bGenPELimit,
		g_PRAdeSetting.bUPFCELimit,
		g_PRAdeSetting.bAuxLoadAdjust,
		g_PRAdeSetting.bEQGenAdjust,
		g_PRAdeSetting.bEQLoadAdjust,
		g_PRAdeSetting.bUPFCAdjustRC);

	m_wndTab.SetActiveTab(1);
}

void CBpaSysAdequacyUIDlg::OnBnClickedDcflow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CBpaDCFlowDialog	dlg;
	dlg.DoModal();
}

void CBpaSysAdequacyUIDlg::OnBnClickedAcflow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (_access(g_PRAdeSetting.strBpaDatFile.c_str(), 0) != 0)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;
	int		nPFResult;
	char	drive[260], dir[260], fname[260], ext[260];
	char	szWorkDir[260], szBpaPFExec[260], szPfoFileName[260], szExec[260];

	dBeg=clock();

	sprintf(szBpaPFExec, "%s/pfnt.exe", g_szRunDir);
	if (access(szBpaPFExec, 0) != 0)
	{
		PrintMessage("AC������������������");
		return;
	}

	if (access(g_PRAdeSetting.strBpaDatFile.c_str(), 0) != 0)
	{
		PrintMessage("BPA�����ļ�������");
		return;
	}

	_splitpath(g_PRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
	_makepath(szWorkDir, drive, dir, NULL, NULL);
	_makepath(szPfoFileName, drive, dir, fname, ".pfo");

	SetCurrentDirectory(szWorkDir);

	sprintf(szExec,"%s %s", szBpaPFExec, g_PRAdeSetting.strBpaDatFile.c_str());
	PrintMessage(szExec);
	//StartProcess(szExec, szWorkDir, SW_HIDE);
	system(szExec);

	nPFResult=0;
	if (access(szPfoFileName, 0) == 0)
	{
		if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szPfoFileName) > 0)
		{
			nPFResult=1;
		}
	}
	else
	{
		PrintMessage("AC����������PFO���");
		return;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	if (nPFResult)
		PrintMessage("AC����������ɣ���ʱ %d ����", nDur);
	else
		PrintMessage("AC�������㲻��������ʱ %d ����", nDur);
}

void CBpaSysAdequacyUIDlg::OnBnClickedMergezil()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	g_BpaMemDBInterface.BpaMergeZILLine(g_pBpaBlock, g_PRAdeSetting.fZIL);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("С֧·������ɣ���ʱ %d ����", nDur);

	CBpaZILDetailDialog	dlg;
	dlg.DoModal();
}

void CBpaSysAdequacyUIDlg::OnBnClickedDecompose()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CBpaRingRadDialog	dlg;
	dlg.DoModal();
}
