// BpaPRParamUPFCDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamUPFCDialog.h"

// CBpaPRParamUPFCDialog �Ի���
const	int		m_nConstLineColumn = 1;
static	char*	lpszACLineColumn[]=
{
	"���",
	"��·����",
	"RatedMva(MVA)",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
	"����(MVA)",
	"����ĸ��",
	"����ĸ��",
};

IMPLEMENT_DYNAMIC(CBpaPRParamUPFCDialog, CDialog)

CBpaPRParamUPFCDialog::CBpaPRParamUPFCDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamUPFCDialog::IDD, pParent)
{

}

CBpaPRParamUPFCDialog::~CBpaPRParamUPFCDialog()
{
}

void CBpaPRParamUPFCDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamUPFCDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD_UPFC, &CBpaPRParamUPFCDialog::OnBnClickedAddUpfc)
	ON_BN_CLICKED(IDC_DEL_UPFC, &CBpaPRParamUPFCDialog::OnBnClickedDelUpfc)
	ON_NOTIFY(NM_CLICK, IDC_ACLINE_LIST, &CBpaPRParamUPFCDialog::OnNMClickAclineList)
	ON_BN_CLICKED(IDC_SEARCH, &CBpaPRParamUPFCDialog::OnBnClickedSearch)
	ON_BN_CLICKED(IDC_SHOW_LINEHASUPFC, &CBpaPRParamUPFCDialog::OnBnClickedShowLinehasupfc)
END_MESSAGE_MAP()


// CBpaPRParamUPFCDialog ��Ϣ��������

BOOL CBpaPRParamUPFCDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszACLineColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszACLineColumn[i],	LVCFMT_LEFT,	60);

	CComboBox*	pComboBox;
	pComboBox=(CComboBox*)GetDlgItem(IDC_SERIESBUS_COMBO);
	pComboBox->ResetContent();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PARALLELBUS_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=1; i<g_pPRBlock->m_nRecordNum[PR_ACBUS]; i++)
		pComboBox->AddString(g_pPRBlock->m_ACBusArray[i].szName);

	RefreshACLineList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamUPFCDialog::RefreshACLineList()
{
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);

	register int	i;
	int		nDev, nRow, nCol, nDevice;
	char	szBuf[260];
	unsigned char	bShowHasUpfcOnly = ((CButton*)GetDlgItem(IDC_SHOW_LINEHASUPFC))->GetCheck();

	int			nSelItem=-1;
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<(int)g_pPRBlock->m_nRecordNum[PR_ACLINE]; nDev++)
	{
		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_UPFC]; i++)
		{
			if (stricmp(g_pPRBlock->m_UPFCArray[i].szName, g_pPRBlock->m_ACLineArray[nDev].szName) == 0)
			{
				nDevice = i;
				break;
			}
		}
		if (bShowHasUpfcOnly)
		{
			if (nDevice < 0)
				continue;
		}
		sprintf(szBuf, "%d", nRow+1);
		pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_ACLineArray[nDev].szName);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[nDev].fRated);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		if (nDevice >= 0)
		{
			sprintf(szBuf, "%f", g_pPRBlock->m_UPFCArray[nDevice].fRerr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_UPFCArray[nDevice].fTrep);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_UPFCArray[nDevice].fCapacity);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_UPFCArray[nDevice].szSeriesBus);
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_UPFCArray[nDevice].szParallelBus);
		}
		else
		{
			nCol++;
			nCol++;
			nCol++;
			nCol++;
		}

		nRow++;
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszACLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		pListCtrl->SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamUPFCDialog::OnBnClickedAddUpfc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDevice;
	double	fRerr, fTrep, fMva;
	char	szSBus[MDB_CHARLEN_SHORT], szPBus[MDB_CHARLEN_SHORT], szBuf[260];

	CComboBox*	pComboBox;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);

	GetDlgItem(IDC_UPFC_RERR)->	GetWindowText(szBuf, 260);	fRerr = atof(szBuf);
	GetDlgItem(IDC_UPFC_TREP)->	GetWindowText(szBuf, 260);	fTrep = atof(szBuf);
	GetDlgItem(IDC_UPFC_MVA)->	GetWindowText(szBuf, 260);	fMva = atof(szBuf);

	memset(szSBus, 0, MDB_CHARLEN_SHORT);
	memset(szPBus, 0, MDB_CHARLEN_SHORT);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SERIESBUS_COMBO);
	nDevice = pComboBox->GetCurSel();
	if (nDevice != CB_ERR)
		pComboBox->GetLBText(nDevice, szSBus);
	else
	{
		AfxMessageBox("��ȷ��UPFC����ĸ��");
		return;
	}

	pComboBox=(CComboBox*)GetDlgItem(IDC_PARALLELBUS_COMBO);
	nDevice = pComboBox->GetCurSel();
	if (nDevice != CB_ERR)
		pComboBox->GetLBText(nDevice, szPBus);

	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);

		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_UPFC]; i++)
		{
			if (stricmp(g_pPRBlock->m_UPFCArray[i].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn)) == 0)
			{
				nDevice = i;
				break;
			}
		}
		if (nDevice >= 0)
		{
			g_pPRBlock->m_UPFCArray[nDevice].fRerr = fRerr;
			g_pPRBlock->m_UPFCArray[nDevice].fTrep = fTrep;
			g_pPRBlock->m_UPFCArray[nDevice].fCapacity = (float)fMva;
			strcpy(g_pPRBlock->m_UPFCArray[nDevice].szSeriesBus, szSBus);
			strcpy(g_pPRBlock->m_UPFCArray[nDevice].szParallelBus, szPBus);
		}
		else
		{
			if (g_pPRBlock->m_nRecordNum[PR_UPFC] < g_PRMemDBInterface.PRGetTableMax(PR_UPFC)-1)
			{
				memset(&g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]], 0, sizeof(tagPRUPFC));
				strcpy(g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn));
				g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]].fRerr = fRerr;
				g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]].fTrep = fTrep;
				g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]].fCapacity = (float)fMva;
				strcpy(g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]].szSeriesBus, szSBus);
				strcpy(g_pPRBlock->m_UPFCArray[g_pPRBlock->m_nRecordNum[PR_UPFC]].szParallelBus, szPBus);
				g_pPRBlock->m_nRecordNum[PR_UPFC]++;
			}
			else
				Log(g_lpszLogFile, "        ********** %s ���ݿⳬ��\n", g_PRMemDBInterface.PRGetTableDesp(PR_UPFC));
		}
	}

	RefreshACLineList();
}

void CBpaPRParamUPFCDialog::OnBnClickedDelUpfc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDevice;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nSelItem=pListCtrl->GetNextSelectedItem(pos);

		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_UPFC]; i++)
		{
			if (stricmp(g_pPRBlock->m_UPFCArray[i].szName, pListCtrl->GetItemText(nSelItem, m_nConstLineColumn)) == 0)
			{
				nDevice = i;
				break;
			}
		}

		if (nDevice >= 0)
			g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_UPFC, nDevice);
	}

	RefreshACLineList();
}

void CBpaPRParamUPFCDialog::OnNMClickAclineList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_SERIESBUS_COMBO);
	pComboBox->ResetContent();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		register int	i;
		int		nItem=pListCtrl->GetNextSelectedItem(pos);
		int		nCol, nACLine = -1;
		char	szBuf[260];
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
		{
			if (stricmp(g_pPRBlock->m_ACLineArray[i].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn)) == 0)
			{
				nACLine = i;
				break;

			}
		}

		if (nACLine >= 0)
		{
			sprintf(szBuf, "%s%g", g_pPRBlock->m_ACLineArray[nACLine].szBusI, g_pPRBlock->m_ACLineArray[nACLine].fkVI);	pComboBox->AddString(szBuf);
			sprintf(szBuf, "%s%g", g_pPRBlock->m_ACLineArray[nACLine].szBusJ, g_pPRBlock->m_ACLineArray[nACLine].fkVJ);	pComboBox->AddString(szBuf);

			pComboBox->SetCurSel(pComboBox->FindString(-1, pListCtrl->GetItemText(nItem, 6)));

			pComboBox=(CComboBox*)GetDlgItem(IDC_PARALLELBUS_COMBO);
			pComboBox->SetCurSel(pComboBox->FindString(-1, pListCtrl->GetItemText(nItem, 7)));
		}

		nCol=3;
		if (strlen(pListCtrl->GetItemText(nItem, nCol)) > 0)
		{
			GetDlgItem(IDC_UPFC_RERR)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
			GetDlgItem(IDC_UPFC_TREP)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
			GetDlgItem(IDC_UPFC_MVA)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		}
	}
	*pResult = 0;
}

void CBpaPRParamUPFCDialog::OnBnClickedSearch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nSelectItem, nStartItem = 0;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nStartItem=pListCtrl->GetNextSelectedItem(pos);

	char	szSearch[260];
	GetDlgItem(IDC_SEARCH_STRING)->GetWindowText(szSearch, 260);

	nSelectItem = -1;
	for (i=nStartItem+1; i<pListCtrl->GetItemCount(); i++)
	{
		if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
		{
			nSelectItem = i;
			break;
		}
	}
	if (nSelectItem < 0 && nStartItem > 0)
	{
		for (i=0; i<nStartItem; i++)
		{
			if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
			{
				nSelectItem = i;
				break;
			}
		}
	}
	if (nSelectItem >= 0)
	{
		pListCtrl->SetItemState(nSelectItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelectItem, FALSE);
	}
}

void CBpaPRParamUPFCDialog::OnBnClickedShowLinehasupfc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshACLineList();
}
