// PResultDeviceDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PResultDeviceDialog.h"


// CPResultDeviceDialog �Ի���
static	int		m_nDeviceType[]=
{
	PR_ACBUS,
	PR_GENERATOR,
	PR_ACLINE,
	PR_WIND,
	PR_POWERLOAD,
	PR_HVDC,
	PR_CONVERTER,
	PR_DCLINE,
	PR_TCSC,
	PR_UPFC,
};

static	char*	m_lpszDeviceColumn[]=
{
	"����״̬",
	"����",
	"Խ��",					
	"���粻��ʧ����(MW)",			
	"����ʧ����(MW)",		
	"����ʧ����(MW)",		
	"�����豸",
};

IMPLEMENT_DYNAMIC(CPResultDeviceDialog, CDialog)

CPResultDeviceDialog::CPResultDeviceDialog(CWnd* pParent /*=NULL*/)
: CDialog(CPResultDeviceDialog::IDD, pParent)
{

}

CPResultDeviceDialog::~CPResultDeviceDialog()
{
}

void CPResultDeviceDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPResultDeviceDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CPResultDeviceDialog::OnCbnSelchangeDevtypeCombo)
	ON_CBN_SELCHANGE(IDC_DEVNAME_COMBO, &CPResultDeviceDialog::OnCbnSelchangeDevnameCombo)
	ON_BN_CLICKED(IDC_SEARACH, &CPResultDeviceDialog::OnBnClickedSearach)
	ON_BN_CLICKED(IDC_SHOW_HASVALUE_ONLY, &CPResultDeviceDialog::OnBnClickedShowHasvalueOnly)
END_MESSAGE_MAP()


// CPResultDeviceDialog ��Ϣ��������

BOOL CPResultDeviceDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int			i;
	CComboBox*	pComboBox;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(m_lpszDeviceColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, m_lpszDeviceColumn[i],	LVCFMT_LEFT,	100);

	((CButton*)GetDlgItem(IDC_SHOW_HASVALUE_ONLY))->SetCheck(TRUE);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(m_nDeviceType)/sizeof(int); i++)
		pComboBox->AddString(g_PRMemDBInterface.PRGetTableDesp(m_nDeviceType[i]));

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVNAME_COMBO);
	pComboBox->ResetContent();

	RefreshDeviceCombo();
	RefreshDeviceList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPResultDeviceDialog::RefreshDeviceCombo()
{
	CComboBox*	pComboBox;
	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int		nTable=pComboBox->GetCurSel();
	if (nTable == CB_ERR)
		return;

	register int	i;
	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVNAME_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	switch (m_nDeviceType[nTable])
	{
	case	PR_ACBUS:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_ACBusArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_ACBusArray[i].szName);
		}
		break;
	case	PR_GENERATOR:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_GeneratorArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_GeneratorArray[i].szName);
		}
		break;
	case	PR_ACLINE:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_ACLineArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_ACLineArray[i].szName);
		}
		break;
	case	PR_WIND:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_WindArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_WindArray[i].szName);
		}
		break;
	case	PR_POWERLOAD:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_PowerLoadArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_PowerLoadArray[i].szName);
		}
		break;
	case	PR_HVDC:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_HVDCArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_HVDCArray[i].szName);
		}
		break;
	case	PR_CONVERTER:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_ConverterArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_ConverterArray[i].szName);
		}
		break;
	case	PR_DCLINE:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_DCLineArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_DCLineArray[i].szName);
		}
		break;
	case	PR_TCSC:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_TCSCArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_TCSCArray[i].szName);
		}
		break;
	case	PR_UPFC:
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDeviceType[nTable]]; i++)
		{
			if (g_pPRBlock->m_UPFCArray[i].nFaultFreq <= 0)
				continue;
			pComboBox->AddString(g_pPRBlock->m_UPFCArray[i].szName);
		}
		break;
	}
}

void CPResultDeviceDialog::RefreshDeviceList()
{
	register int	i;
	int		nRow, nCol;
	int		nSel, nFState, nFDev, nFDevNum;
	int		nDevType, nDevIndex;
	unsigned char	bHasDev;
	char	szDevName[MDB_CHARLEN], szBuf[260];

	CComboBox*	pComboBox;

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
		return;
	nDevType = m_nDeviceType[nSel];

	nDevIndex = -1;
	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVNAME_COMBO);
	nSel=pComboBox->GetCurSel();
	if (nSel != CB_ERR)
	{
		pComboBox->GetLBText(nSel, szDevName);
		if (strlen(szDevName) > 0)
		{
			nDevIndex = g_PRMemDBInterface.PRFindRecordbyKey(g_pPRBlock, nDevType, szDevName);
			if (nDevIndex < 0)
				return;
		}
	}

	CButton*		pButton=(CButton*)GetDlgItem(IDC_SHOW_HASVALUE_ONLY);
	unsigned char	bShowHasVOnly=pButton->GetCheck();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nFState=0; nFState<g_pPRBlock->m_nRecordNum[PR_FSTATE]; nFState++)
	{
		if (g_pPRBlock->m_FStateArray[nFState].nFDevNum <= 0)
			continue;

		if (bShowHasVOnly)
		{
			if (!g_pPRBlock->m_FStateArray[nFState].bMIsland &&
				!g_pPRBlock->m_FStateArray[nFState].bOverLimit &&
				g_pPRBlock->m_FStateArray[nFState].fEnsCutLoad < FLT_MIN &&
				g_pPRBlock->m_FStateArray[nFState].fMIOutLoad < FLT_MIN &&
				g_pPRBlock->m_FStateArray[nFState].fELCutLoad < FLT_MIN)
				continue;
		}

		bHasDev = 0;
		for (nFDev=0; nFDev<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; nFDev++)
		{
			if (g_pPRBlock->m_FStateFDevArray[nFDev].nFStateNo < nFState)
				continue;
			if (g_pPRBlock->m_FStateFDevArray[nFDev].nFStateNo > nFState)
				break;

			if (nDevIndex < 0)
			{
				if (g_pPRBlock->m_FStateFDevArray[nFDev].nFDevTyp == nDevType)
				{
					bHasDev=1;
					break;
				}
			}
			else
			{
				if (g_pPRBlock->m_FStateFDevArray[nFDev].nFDevTyp == nDevType &&
					g_pPRBlock->m_FStateFDevArray[nFDev].nFDevIdx == nDevIndex)
				{
					bHasDev=1;
					break;
				}
			}
		}
		if (!bHasDev)
			continue;

		sprintf(szBuf,"%d", nFState);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_MISLAND, g_pPRBlock->m_FStateArray[nFState].bMIsland));
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_OVERLIMIT, g_pPRBlock->m_FStateArray[nFState].bOverLimit));
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fEnsCutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fMIOutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELCutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nFDevNum = 0;
		for (nFDev=0; nFDev<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; nFDev++)
		{
			if (g_pPRBlock->m_FStateFDevArray[nFDev].nFStateNo < nFState)
				continue;
			if (g_pPRBlock->m_FStateFDevArray[nFDev].nFStateNo > nFState)
				break;

			int nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[nFDev].nFDevTyp, "Name");
			if (nField >= 0)
			{
				char	szRec[MDB_CHARLEN_LONG];
				if (nFDevNum > 0)
					pListCtrl->InsertItem(nRow, "");

				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[nFDev].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[nFDev].nFDevIdx, szRec);

				sprintf(szBuf, "(%d/%d) %s %s [%s]", nFDevNum+1, g_pPRBlock->m_FStateArray[nFState].nFDevNum, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[nFDev].nFDevTyp), szRec,
					g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATEFDEV, PR_FSTATEFDEV_DFLTTYP, g_pPRBlock->m_FStateFDevArray[nFDev].nDFltTyp));

				pListCtrl->SetItemText(nRow, nCol, szBuf);
				nRow++;

				nFDevNum++;
			}
		}
	}

	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(m_lpszDeviceColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		//if (nRow <= 0)
		{
			pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
			nHeaderWidth = pListCtrl->GetColumnWidth(i);
		}

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPResultDeviceDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceCombo();
}

void CPResultDeviceDialog::OnCbnSelchangeDevnameCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CPResultDeviceDialog::OnBnClickedSearach()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CPResultDeviceDialog::OnBnClickedShowHasvalueOnly()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CPResultDeviceDialog::ExcelOut(ExcelAccessor* pXls)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	if (pListCtrl->GetItemCount() <= 0)
		return;

	PrintMessage("Excel�����豸�ɿ������鿪ʼ");

	int		nRow, nCol, nFieldNum;

	pXls->AddSheet(_T("�豸�ɿ�������"));
	pXls->SetCurSheet(_T("�豸�ɿ�������"));

	nFieldNum=sizeof(m_lpszDeviceColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		pXls->AddCell(CString(m_lpszDeviceColumn[nCol]));
	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		pXls->NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			pXls->AddCell(pListCtrl->GetItemText(nRow, nCol));
	}

	PrintMessage("Excel�����豸�ɿ����������");
}
