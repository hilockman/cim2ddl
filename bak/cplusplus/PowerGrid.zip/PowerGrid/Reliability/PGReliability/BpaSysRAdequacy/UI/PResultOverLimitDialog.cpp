// PROvlDeviceListDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PResultOverLimitDialog.h"
#include "PRDetailOverLimitDialog.h"

// CPResultOverLimitDialog �Ի���

static	char*	lpszROvlmtDevColumn[]=
{
	"���",
	"�豸����",
	"�豸����",
	"Խ�޴���",
	"Խ�޹���(MW/��)",
	"Խ���и��ɵ����ܼ�(MW.h/��)",
};

IMPLEMENT_DYNAMIC(CPResultOverLimitDialog, CDialog)

CPResultOverLimitDialog::CPResultOverLimitDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPResultOverLimitDialog::IDD, pParent)
{

}

CPResultOverLimitDialog::~CPResultOverLimitDialog()
{
}

void CPResultOverLimitDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPResultOverLimitDialog, CDialog)
	ON_BN_CLICKED(IDC_SHOW_HASVALUE_ONLY, &CPResultOverLimitDialog::OnBnClickedShowHasvalueOnly)
	ON_BN_CLICKED(IDC_DETAIL, &CPResultOverLimitDialog::OnBnClickedDetail)
END_MESSAGE_MAP()


// CPResultOverLimitDialog ��Ϣ��������

BOOL CPResultOverLimitDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int		nColumn;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLDEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszROvlmtDevColumn)/sizeof(char*); nColumn++)
		pListCtrl->InsertColumn(nColumn, lpszROvlmtDevColumn[nColumn],	LVCFMT_LEFT,	100);

	((CButton*)GetDlgItem(IDC_SHOW_HASVALUE_ONLY))->SetCheck(TRUE);

	RefreshPROvlDeviceList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPResultOverLimitDialog::RefreshUI()
{
	RefreshPROvlDeviceList();
}

void CPResultOverLimitDialog::OnBnClickedShowHasvalueOnly()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPROvlDeviceList();
}

void CPResultOverLimitDialog::RefreshPROvlDeviceList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLDEVICE_LIST);
	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOW_HASVALUE_ONLY);
	unsigned char	bShowHasVOnly=pButton->GetCheck();

	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
	{
		if (bShowHasVOnly)
		{
			if (g_pPRBlock->m_ACLineArray[i].nOLmtFreq <= 0)
				continue;
		}
		sprintf(szBuf,"%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetTableDesp(PR_ACLINE));
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_ACLineArray[i].szName);
		sprintf(szBuf, "%d", g_pPRBlock->m_ACLineArray[i].nOLmtFreq);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_ACLineArray[i].fOLmtValue);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_ACLineArray[i].fELmtCutEnergy);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_WIND]; i++)
	{
		if (bShowHasVOnly)
		{
			if (g_pPRBlock->m_WindArray[i].nOLmtFreq <= 0)
				continue;
		}
		sprintf(szBuf,"%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetTableDesp(PR_WIND));
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_WindArray[i].szName);
		sprintf(szBuf, "%d", g_pPRBlock->m_WindArray[i].nOLmtFreq);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_WindArray[i].fOLmtValue);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_WindArray[i].fELmtCutEnergy);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszROvlmtDevColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPResultOverLimitDialog::ExcelOut(ExcelAccessor* pXls)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLDEVICE_LIST);
	if (pListCtrl->GetItemCount() <= 0)
		return;

	PrintMessage("Excel�����豸Խ����Ϣ��ʼ");

	int		nRow, nCol, nFieldNum;

	pXls->AddSheet(_T("�豸Խ����Ϣ"));
	pXls->SetCurSheet(_T("�豸Խ����Ϣ"));

	nFieldNum=sizeof(lpszROvlmtDevColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		pXls->AddCell(CString(lpszROvlmtDevColumn[nCol]));
	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		pXls->NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			pXls->AddCell(pListCtrl->GetItemText(nRow, nCol));
	}

	PrintMessage("Excel�����豸Խ����Ϣ���");
}

void CPResultOverLimitDialog::OnBnClickedDetail()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLDEVICE_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	char	szDevName[260];
	int	nCol = 1;
	int nItem = pListCtrl->GetNextSelectedItem(pos);
	int	nDevType = g_PRMemDBInterface.PRGetTableIndex(pListCtrl->GetItemText(nItem, nCol++));
	strcpy(szDevName, pListCtrl->GetItemText(nItem, nCol++));


	CPRDetailOverLimitDialog	dlg;
	dlg.SetOvlDevice(nDevType, szDevName);
	dlg.DoModal();
}
