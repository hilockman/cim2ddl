// BpaPRParamConverterDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamConverterDialog.h"

// CBpaPRParamConverterDialog �Ի���
const	int		m_nConstDevColumn = 1;
const	int		m_nConstBusColumn = 2;
const	int		m_nConstPColumn = 4;
static	char*	lpszDevColumn[]=
{
	"���",
	"�豸����",
	"ĸ��",
	"��ѹ",
	"�й�",
	"�޹�",
	"�任��",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
};

IMPLEMENT_DYNAMIC(CBpaPRParamConverterDialog, CDialog)

CBpaPRParamConverterDialog::CBpaPRParamConverterDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamConverterDialog::IDD, pParent)
	, m_nConverterType(0)
{

}

CBpaPRParamConverterDialog::~CBpaPRParamConverterDialog()
{
}

void CBpaPRParamConverterDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RECTIFIER, m_nConverterType);
}


BEGIN_MESSAGE_MAP(CBpaPRParamConverterDialog, CDialog)
	ON_BN_CLICKED(IDC_RECTIFIER, &CBpaPRParamConverterDialog::OnBnClickedRectifier)
	ON_BN_CLICKED(IDC_INVERTER, &CBpaPRParamConverterDialog::OnBnClickedInverter)
	ON_BN_CLICKED(IDC_ADD_CONVERTER, &CBpaPRParamConverterDialog::OnBnClickedAddConverter)
	ON_BN_CLICKED(IDC_DEL_CONVERTER, &CBpaPRParamConverterDialog::OnBnClickedDelConverter)
	ON_NOTIFY(NM_CLICK, IDC_GENLOAD_LIST, &CBpaPRParamConverterDialog::OnNMClickGenloadList)
	ON_BN_CLICKED(IDC_SHOW_BUSHASCONVERTER, &CBpaPRParamConverterDialog::OnBnClickedShowBushasconverter)
END_MESSAGE_MAP()


// CBpaPRParamConverterDialog ��Ϣ��������

BOOL CBpaPRParamConverterDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_GENLOAD_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDevColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszDevColumn[i],	LVCFMT_LEFT,	60);

	RefreshDeviceList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamConverterDialog::RefreshDeviceList()
{
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_GENLOAD_LIST);
	unsigned char	bShowHasConverterOnly = ((CButton*)GetDlgItem(IDC_SHOW_BUSHASCONVERTER))->GetCheck();

	register int	i;
	int		nDev, nRow, nCol, nConverter;
	char	szBuf[260];

	UpdateData();

	int			nSelItem=-1;
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();

	nRow=0;
	if (m_nConverterType == 0)
	{
		for (nDev=0; nDev<(int)g_pPRBlock->m_nRecordNum[PR_POWERLOAD]; nDev++)
		{
			if (g_pPRBlock->m_PowerLoadArray[nDev].bAuxLoad)
				continue;

			nConverter = -1;
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_CONVERTER]; i++)
			{
				if (stricmp(g_pPRBlock->m_ConverterArray[i].szName, g_pPRBlock->m_PowerLoadArray[nDev].szName) == 0)
				{
					nConverter = i;
					break;
				}
			}
			if (bShowHasConverterOnly)
			{
				if (nConverter < 0)
					continue;
			}

			sprintf(szBuf, "%d", nRow+1);
			pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_PowerLoadArray[nDev].szName);
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_PowerLoadArray[nDev].szBus);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_PowerLoadArray[nDev].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_PowerLoadArray[nDev].fP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_PowerLoadArray[nDev].fQ);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

			if (nConverter >= 0)
			{
				pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_CONVERTER, PR_CONVERTER_TYPE, PRConverter_Type_Rectifier));
				sprintf(szBuf, "%f", g_pPRBlock->m_ConverterArray[nConverter].fRerr);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_ConverterArray[nConverter].fTrep);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			}
			nRow++;
		}
	}
	else
	{
		for (nDev=0; nDev<(int)g_pPRBlock->m_nRecordNum[PR_GENERATOR]; nDev++)
		{
			sprintf(szBuf, "%d", nRow+1);
			pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_GeneratorArray[nDev].szName);
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_GeneratorArray[nDev].szBus);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_GeneratorArray[nDev].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_GeneratorArray[nDev].fP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_GeneratorArray[nDev].fQ);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nConverter = -1;
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_CONVERTER]; i++)
			{
				if (stricmp(g_pPRBlock->m_ConverterArray[i].szName, g_pPRBlock->m_GeneratorArray[nDev].szName) == 0)
				{
					nConverter = i;
					break;
				}
			}
			if (nConverter >= 0)
			{
				pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_CONVERTER, PR_CONVERTER_TYPE, PRConverter_Type_Inverter));
				sprintf(szBuf, "%f", g_pPRBlock->m_ConverterArray[nConverter].fRerr);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_ConverterArray[nConverter].fTrep);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			}

			nRow++;
		}
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDevColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		pListCtrl->SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamConverterDialog::OnBnClickedRectifier()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CBpaPRParamConverterDialog::OnBnClickedInverter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CBpaPRParamConverterDialog::OnBnClickedAddConverter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nConverter;
	double	fRerr, fTrep;
	char	szBuf[260];

	UpdateData();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_GENLOAD_LIST);

	GetDlgItem(IDC_CONVERTER_RERR)->	GetWindowText(szBuf, 260);	fRerr = atof(szBuf);
	GetDlgItem(IDC_CONVERTER_TREP)->	GetWindowText(szBuf, 260);	fTrep = atof(szBuf);

	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);

		nConverter = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_CONVERTER]; i++)
		{
			if (stricmp(g_pPRBlock->m_ConverterArray[i].szName, pListCtrl->GetItemText(nItem, m_nConstDevColumn)) == 0)
			{
				nConverter = i;
				break;
			}
		}
		if (nConverter >= 0)
		{
			g_pPRBlock->m_ConverterArray[nConverter].fRerr = fRerr;
			g_pPRBlock->m_ConverterArray[nConverter].fTrep = fTrep;
			g_pPRBlock->m_ConverterArray[nConverter].fConverterPower = (float)atof(pListCtrl->GetItemText(nItem, m_nConstPColumn));
			g_pPRBlock->m_ConverterArray[nConverter].nType = m_nConverterType;
			sprintf(g_pPRBlock->m_ConverterArray[nConverter].szACBus, "%s%g", pListCtrl->GetItemText(nItem, m_nConstBusColumn), atof(pListCtrl->GetItemText(nItem, m_nConstBusColumn+1)));
		}
		else
		{
			if (g_pPRBlock->m_nRecordNum[PR_CONVERTER] < g_PRMemDBInterface.PRGetTableMax(PR_CONVERTER)-1)
			{
				memset(&g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]], 0, sizeof(tagPRUPFC));
				strcpy(g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]].szName, pListCtrl->GetItemText(nItem, m_nConstDevColumn));
				g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]].fRerr = fRerr;
				g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]].fTrep = fTrep;
				g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]].fConverterPower = (float)atof(pListCtrl->GetItemText(nItem, m_nConstPColumn));
				g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]].nType = m_nConverterType;
				sprintf(g_pPRBlock->m_ConverterArray[g_pPRBlock->m_nRecordNum[PR_CONVERTER]].szACBus, "%s%g", pListCtrl->GetItemText(nItem, m_nConstBusColumn), atof(pListCtrl->GetItemText(nItem, m_nConstBusColumn+1)));
				g_pPRBlock->m_nRecordNum[PR_CONVERTER]++;
			}
			else
				Log(g_lpszLogFile, "        ********** %s ���ݿⳬ��\n", g_PRMemDBInterface.PRGetTableDesp(PR_CONVERTER));
		}
	}

	RefreshDeviceList();
}

void CBpaPRParamConverterDialog::OnBnClickedDelConverter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDevice;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_GENLOAD_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nSelItem=pListCtrl->GetNextSelectedItem(pos);

		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_CONVERTER]; i++)
		{
			if (stricmp(g_pPRBlock->m_ConverterArray[i].szName, pListCtrl->GetItemText(nSelItem, m_nConstDevColumn)) == 0)
			{
				nDevice = i;
				break;
			}
		}

		if (nDevice >= 0)
			g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_CONVERTER, nDevice);
	}

	RefreshDeviceList();
}

void CBpaPRParamConverterDialog::OnNMClickGenloadList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_GENLOAD_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int		nItem=pListCtrl->GetNextSelectedItem(pos);
		int		nCol;

		nCol=7;
		if (strlen(pListCtrl->GetItemText(nItem, nCol)) > 0)
		{
			GetDlgItem(IDC_CONVERTER_RERR)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
			GetDlgItem(IDC_CONVERTER_TREP)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		}

	}
	*pResult = 0;
}

void CBpaPRParamConverterDialog::OnBnClickedShowBushasconverter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}
