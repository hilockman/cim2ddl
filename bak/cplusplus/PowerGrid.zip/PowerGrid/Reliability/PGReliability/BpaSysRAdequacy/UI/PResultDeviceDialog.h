#pragma once
#include "../../../../../Common/Excel/ExcelAccessor.h"


// CPResultDeviceDialog �Ի���

class CPResultDeviceDialog : public CDialog
{
	DECLARE_DYNAMIC(CPResultDeviceDialog)

public:
	CPResultDeviceDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPResultDeviceDialog();

// �Ի�������
	enum { IDD = IDD_PRESULT_DEVICE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnCbnSelchangeDevtypeCombo();
	afx_msg void OnCbnSelchangeDevnameCombo();
	DECLARE_MESSAGE_MAP()

private:
	void	RefreshDeviceCombo();
	void	RefreshDeviceList();

public:
	void	ExcelOut(ExcelAccessor* pXls);
	afx_msg void OnBnClickedSearach();
	afx_msg void OnBnClickedShowHasvalueOnly();
};
