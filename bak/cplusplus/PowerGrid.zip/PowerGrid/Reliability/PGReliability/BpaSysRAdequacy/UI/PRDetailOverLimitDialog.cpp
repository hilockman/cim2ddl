// OvldevDetailDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PRDetailOverLimitDialog.h"
#include "../../../../../Common/Excel/ExcelAccessor.h"

// CPRDetailOverLimitDialog �Ի���


const	int		nFaultDevColumn = 1;
const	int		nInsGenColumn = 8;
const	int		nDesGenColumn = 9;
const	int		nCutLoadColumn = 10;
const	int		nUPFCColumn = 11;
static	char*	lpszSampleStateColumn[]=
{
	"״̬��",
	"�����豸",
	"����",
	"����ʱ��",
	"��������",

	"ʧ����",
	"ʧ����",

	"�����и���",
	"����������",
	"���޼�����",
	"����ʧ����",
	"UPFC������",
	"����ʧ���ɵ���",
};

IMPLEMENT_DYNAMIC(CPRDetailOverLimitDialog, CDialog)

CPRDetailOverLimitDialog::CPRDetailOverLimitDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPRDetailOverLimitDialog::IDD, pParent)
{
	m_nDevType = -1;
	memset(m_szDevName, 0, 260);
}

CPRDetailOverLimitDialog::~CPRDetailOverLimitDialog()
{
}

void CPRDetailOverLimitDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPRDetailOverLimitDialog, CDialog)
	ON_BN_CLICKED(IDC_FSTATE, &CPRDetailOverLimitDialog::OnBnClickedFstate)
	ON_BN_CLICKED(IDC_SHOW_ELCUTLOAD, &CPRDetailOverLimitDialog::OnBnClickedShowElimitcutload)
	ON_BN_CLICKED(IDC_EXCEL_OUT, &CPRDetailOverLimitDialog::OnBnClickedExcelOut)
END_MESSAGE_MAP()


// CPRDetailOverLimitDialog ��Ϣ��������

BOOL CPRDetailOverLimitDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*		pListCtrl;

	if (m_nDevType <= 0)
	{
		EndDialog(IDCANCEL);
		return FALSE;
	}
	
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszSampleStateColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszSampleStateColumn[i],	LVCFMT_LEFT,	60);

	((CButton*)GetDlgItem(IDC_SHOW_ELCUTLOAD))->SetCheck(TRUE);

	char	szBuf[260];
	sprintf(szBuf, "%s %s", g_PRMemDBInterface.PRGetTableDesp(m_nDevType), m_szDevName);
	GetDlgItem(IDC_OVLDEVICE)->SetWindowText(szBuf);

	if (m_nDevType == PR_ACLINE)
	{
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDevType]; i++)
		{
			if (stricmp(g_pPRBlock->m_ACLineArray[i].szName, m_szDevName) == 0)
			{
				sprintf(szBuf, "%d", g_pPRBlock->m_ACLineArray[i].nOLmtFreq);
				GetDlgItem(IDC_OVLFREQ)->SetWindowText(szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[i].fOLmtValue);
				GetDlgItem(IDC_OVLP)->SetWindowText(szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[i].fELmtCutEnergy);
				GetDlgItem(IDC_OVLELOAD)->SetWindowText(szBuf);
				break;
			}
		}
	}
	else if (m_nDevType == PR_WIND)
	{
		for (i=0; i<g_pPRBlock->m_nRecordNum[m_nDevType]; i++)
		{
			if (stricmp(g_pPRBlock->m_WindArray[i].szName, m_szDevName) == 0)
			{
				sprintf(szBuf, "%d", g_pPRBlock->m_WindArray[i].nOLmtFreq);
				GetDlgItem(IDC_OVLFREQ)->SetWindowText(szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_WindArray[i].fOLmtValue);
				GetDlgItem(IDC_OVLP)->SetWindowText(szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_WindArray[i].fELmtCutEnergy);
				GetDlgItem(IDC_OVLELOAD)->SetWindowText(szBuf);
				break;
			}
		}
	}
	
	RefreshPRFStateList(m_nDevType, m_szDevName);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPRDetailOverLimitDialog::RefreshPRFStateList(const int nDevType, const char* lpszDevName)
{
	int		nFState, nDev, nOvlDevNum, nField, nRow, nCol;
	int		nMaxNextRowNum, nFStateRow, nInsGenRow, nDesGenRow,nELoadRow, nUPFCRow, nFDevRow;
	int		nFStateNum;
	char	szBuf[260], szRec[MDB_CHARLEN_LONG];
	int		nColWidth, nHeaderWidth;

	unsigned char	bShowELmtCutLoad = ((CButton*)GetDlgItem(IDC_SHOW_ELCUTLOAD))->GetCheck();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	pListCtrl->DeleteAllItems();
	if (nDevType <= 0 || !lpszDevName)
		return;

	nFStateNum = 0;

	nRow=0;
	for (nFState=0; nFState<g_pPRBlock->m_nRecordNum[PR_FSTATE]; nFState++)
	{
		if (bShowELmtCutLoad)
		{
			if (g_pPRBlock->m_FStateArray[nFState].fELCutLoad <= FLT_MIN)
				continue;
		}

		nFStateNum++;

		nOvlDevNum = 0;
		for (nDev=0; nDev<g_pPRBlock->m_nRecordNum[PR_FSTATEOVLDEV]; nDev++)
		{
			if (g_pPRBlock->m_FStateOvlDevArray[nDev].nFStateNo < nFState)
				continue;
			if (g_pPRBlock->m_FStateOvlDevArray[nDev].nFStateNo > nFState)
				break;

			if (g_pPRBlock->m_FStateOvlDevArray[nDev].nDevTyp != nDevType)
				continue;
			if (g_pPRBlock->m_FStateOvlDevArray[nDev].nDevTyp == PR_ACLINE)
			{
				if (stricmp(g_pPRBlock->m_ACLineArray[g_pPRBlock->m_FStateOvlDevArray[nDev].nDevIdx].szName, lpszDevName) == 0)
					nOvlDevNum++;
			}
			else if (g_pPRBlock->m_FStateOvlDevArray[nDev].nDevTyp == PR_WIND)
			{
				if (stricmp(g_pPRBlock->m_WindArray[g_pPRBlock->m_FStateOvlDevArray[nDev].nDevIdx].szName, lpszDevName) == 0)
					nOvlDevNum++;
			}
		}
		if (nOvlDevNum <= 0)
			continue;

		sprintf(szBuf, "%d", nFState);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateArray[nFState].nFDevNum);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[nFState].fStateProb);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[nFState].fStateDur);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateArray[nFState].nStateNum);			pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fFLossGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fFLossGenCap);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_ELIMIT, g_pPRBlock->m_FStateArray[nFState].bELCutLoad));
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELInsGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELCutGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELCutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
																					pListCtrl->SetItemText(nRow, nCol++, "");
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fStateDur*g_pPRBlock->m_FStateArray[nFState].fELCutLoad);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;

		nFStateRow = nRow;

		nInsGenRow = nDesGenRow = nELoadRow = nUPFCRow = nFDevRow = 0;
		nMaxNextRowNum = 0;
		for (nDev=0; nDev<g_pPRBlock->m_nRecordNum[PR_FSTATEOVLAD]; nDev++)
		{
			if (g_pPRBlock->m_FStateOvlAdArray[nDev].nFStateNo < nFState)
				continue;
			if (g_pPRBlock->m_FStateOvlAdArray[nDev].nFStateNo > nFState)
				break;

			if (g_pPRBlock->m_FStateOvlAdArray[nDev].nOvlDevTyp != nDevType)
				continue;
			if (g_pPRBlock->m_FStateOvlAdArray[nDev].nOvlDevTyp == PR_ACLINE)
			{
				if (stricmp(g_pPRBlock->m_ACLineArray[g_pPRBlock->m_FStateOvlAdArray[nDev].nOvlDevIdx].szName, lpszDevName) != 0)
					continue;
			}
			else if (g_pPRBlock->m_FStateOvlAdArray[nDev].nOvlDevTyp == PR_WIND)
			{
				if (stricmp(g_pPRBlock->m_WindArray[g_pPRBlock->m_FStateOvlAdArray[nDev].nOvlDevIdx].szName, lpszDevName) != 0)
					continue;
			}

			if (g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevTyp == PR_GENERATOR && g_pPRBlock->m_FStateOvlAdArray[nDev].fAdValue > FLT_MIN)
			{
				if (nInsGenRow >= nMaxNextRowNum)
					pListCtrl->InsertItem(nFStateRow+nInsGenRow, "");

				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, PR_ACBUS, PR_ACBUS_NAME, g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevIdx, szRec);
				sprintf(szBuf,"%s %f", szRec, g_pPRBlock->m_FStateOvlAdArray[nDev].fAdValue);
				pListCtrl->SetItemText(nFStateRow+nInsGenRow, nInsGenColumn, szBuf);
				nInsGenRow++;
			}
			else if (g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevTyp == PR_GENERATOR && g_pPRBlock->m_FStateOvlAdArray[nDev].fAdValue < -FLT_MIN)
			{
				if (nDesGenRow >= nMaxNextRowNum)
					pListCtrl->InsertItem(nFStateRow+nDesGenRow, "");

				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, PR_ACBUS, PR_ACBUS_NAME, g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevIdx, szRec);
				sprintf(szBuf,"%s %f", szRec, g_pPRBlock->m_FStateOvlAdArray[nDev].fAdValue);
				pListCtrl->SetItemText(nFStateRow+nDesGenRow, nDesGenColumn, szBuf);
				nDesGenRow++;
			}
			else if (g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevTyp == PR_POWERLOAD)
			{
				if (nELoadRow >= nMaxNextRowNum)
					pListCtrl->InsertItem(nFStateRow+nELoadRow, "");
				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, PR_ACBUS, PR_ACBUS_NAME, g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevIdx, szRec);
				sprintf(szBuf,"%s %f", szRec, g_pPRBlock->m_FStateOvlAdArray[nDev].fAdValue);
				pListCtrl->SetItemText(nFStateRow+nELoadRow, nCutLoadColumn, szBuf);
				nELoadRow++;
			}
			else if (g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevTyp == PR_UPFC)
			{
				if (nUPFCRow >= nMaxNextRowNum)
					pListCtrl->InsertItem(nFStateRow+nUPFCRow, "");
				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, PR_UPFC, PR_UPFC_NAME, g_pPRBlock->m_FStateOvlAdArray[nDev].nAdjDevIdx, szRec);
				sprintf(szBuf,"%s %f", szRec, g_pPRBlock->m_FStateOvlAdArray[nDev].fAdValue);
				pListCtrl->SetItemText(nFStateRow+nUPFCRow, nUPFCColumn, szBuf);
				nUPFCRow++;
			}

			nMaxNextRowNum = max(max(max(max(nMaxNextRowNum, nInsGenRow), nDesGenRow), nELoadRow), nUPFCRow);
		}
		for (nDev=0; nDev<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; nDev++)
		{
			if (g_pPRBlock->m_FStateFDevArray[nDev].nFStateNo < nFState)
				continue;
			if (g_pPRBlock->m_FStateFDevArray[nDev].nFStateNo > nFState)
				break;

			nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[nDev].nFDevTyp, "Name");
			if (nField >= 0)
			{
				if (nFDevRow >= nMaxNextRowNum)
					pListCtrl->InsertItem(nFStateRow+nFDevRow, "");

				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[nDev].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[nDev].nFDevIdx, szRec);
				sprintf(szBuf, "%s %s", g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[nDev].nFDevTyp), szRec);
				pListCtrl->SetItemText(nFStateRow+nFDevRow, nFaultDevColumn, szBuf);
				nFDevRow++;
			}

			nMaxNextRowNum = max(max(max(max(max(nMaxNextRowNum, nInsGenRow), nDesGenRow), nELoadRow), nUPFCRow), nFDevRow);
		}
		nRow += nMaxNextRowNum;
	}

	for (nCol=0; nCol<sizeof(lpszSampleStateColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	sprintf(szBuf, "%d", nFStateNum);
	GetDlgItem(IDC_STATENUM)->SetWindowText(szBuf);
}

void CPRDetailOverLimitDialog::OnBnClickedFstate()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPRFStateList(m_nDevType, m_szDevName);
}

void CPRDetailOverLimitDialog::OnBnClickedShowElimitcutload()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPRFStateList(m_nDevType, m_szDevName);
}

void CPRDetailOverLimitDialog::OnBnClickedExcelOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl;
	
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	if (pListCtrl->GetItemCount() <= 0)
		return;

	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS;*.xlsx;*.XLSX|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	PrintMessage("Excel������ʼ");

	int		nRow, nCol, nFieldNum;
	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	//////////////////////////////////////////////////////////////////////////
	//	�豸Խ��״̬
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	xls.AddSheet(_T("�豸Խ��״̬"));
	xls.SetCurSheet(_T("�豸Խ��״̬"));

	xls.AddCell(CString(g_PRMemDBInterface.PRGetTableDesp(m_nDevType)));
	xls.AddCell(CString(m_szDevName));
	xls.NewLine();

	if (pListCtrl->GetItemCount() > 0)
	{
		nFieldNum=sizeof(lpszSampleStateColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszSampleStateColumn[nCol]));
		for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(pListCtrl->GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));

	PrintMessage("Excel�������");
}
