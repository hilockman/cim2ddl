#pragma once


// CPRDetailOverLimitDialog �Ի���

class CPRDetailOverLimitDialog : public CDialog
{
	DECLARE_DYNAMIC(CPRDetailOverLimitDialog)

public:
	CPRDetailOverLimitDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPRDetailOverLimitDialog();

	void	SetOvlDevice(const int nDevType, const char* lpszDevName)
	{
		m_nDevType = nDevType;
		strcpy(m_szDevName, lpszDevName);
	}

// �Ի�������
	enum { IDD = IDD_OVLDEV_DETAIL_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedFstate();
	afx_msg void OnBnClickedShowElimitcutload();
	afx_msg void OnBnClickedExcelOut();

	DECLARE_MESSAGE_MAP()

private:
	void	RefreshPRFStateList(const int nDevType, const char* lpszDevName);

private:
	int		m_nDevType;
	char	m_szDevName[260];
};
