#pragma once


// CPRParamManuDialog �Ի���

class CBpaPRParamCommonFaultDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamCommonFaultDialog)

public:
	CBpaPRParamCommonFaultDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamCommonFaultDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_COMMONFAULT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedAddCommonFault();
	afx_msg void OnBnClickedDelCommonFault();
	afx_msg void OnBnClickedAddCommResionDevice();
	afx_msg void OnBnClickedDelCommDevice();
	afx_msg void OnBnClickedModCommonFltType();
	afx_msg void OnBnClickedModCommonDevType();
	afx_msg void OnBnClickedAddCommResultDevice();
	afx_msg void OnBnClickedCheckCommdevice();
	DECLARE_MESSAGE_MAP()
private:
	void	RefreshCommonFaultTree();
public:
	int m_nCommFaultType;
	int m_nCommDeviceType;
};
