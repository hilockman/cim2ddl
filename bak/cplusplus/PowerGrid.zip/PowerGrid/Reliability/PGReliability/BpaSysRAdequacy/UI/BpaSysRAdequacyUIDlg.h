
// PRelibilityUIDlg.h : ͷ�ļ�
//

#pragma once

#include "PResultSampleStateDialog.h"
#include "PResultBusReliabilityDialog.h"
#include "PResultOverLimitDialog.h"
#include "PResultDeviceDialog.h"

#include "../../../../../Common/MFCControls/MFCListCtrlEx.h"

//	Ϊ����ԭ�ȵ����ݰ汾����
#include "../../PRParam.h"

// CPRelibilityUIDlg �Ի���

class CBpaSysAdequacyUIDlg : public CDialog
{
// ����
public:
	CBpaSysAdequacyUIDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BPA_SYSADEQUACY_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

public:
	void	PrintMessage(char* pformat, ...);

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	afx_msg void OnBnClickedSysAdequacyEstimate();

	afx_msg void OnBnClickedBrowseRai();
	afx_msg void OnBnClickedBrowseRml();
	afx_msg void OnBnClickedDatBrowse();
	afx_msg void OnBnClickedSwiBrowse();
	afx_msg void OnBnClickedRParamBrowse();
	afx_msg void OnBnClickedDatErase();
	afx_msg void OnBnClickedSwiErase();
	afx_msg void OnBnClickedRParamErase();
	afx_msg void OnBnClickedRParamEdit();

	afx_msg void OnBnClickedClearMesg();

	afx_msg void OnChangeRParam();

	afx_msg void OnBnClickedSaveasExcel();

	afx_msg LRESULT OnAdequacyEstimateBegin(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnAdequacyEstimating(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnAdequacyEstimateEnded(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedSysAdequacySample();
	afx_msg void OnBnClickedDcflow();
	afx_msg void OnBnClickedAcflow();
	afx_msg void OnBnClickedMergezil();
	afx_msg void OnBnClickedDecompose();
	DECLARE_MESSAGE_MAP()

private:
	int		GetTextLen(LPCTSTR lpszText);

	void	RefreshPRSysResultList();

	void	RefreshParam();
	int		PreparePRData();
	void	LoadBpaModelFile(void);

private:
	CMFCTabCtrl						m_wndTab;
	CMFCListCtrlEx					m_wndPRSysResultList;
	CPResultSampleStateDialog		m_wndSampleState;
	CPResultBusReliabilityDialog	m_wndBusReliability;
	CPResultOverLimitDialog			m_wndOverLimit;
	CPResultDeviceDialog			m_wndDevice;

private:
	tagPRSetting	m_PRSetting;
	CPRParam		m_PRParam;
public:
private:
	int				m_nAdequacyEstimateNum;
	HANDLE			m_hAdequacyEstimateHandle;
public:
};

