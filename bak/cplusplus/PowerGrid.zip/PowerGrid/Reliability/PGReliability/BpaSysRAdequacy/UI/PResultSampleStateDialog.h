#pragma once

#include "../../../../../Common/Excel/ExcelAccessor.h"

// CPResultSampleStateDialog �Ի���

class CPResultSampleStateDialog : public CDialog
{
	DECLARE_DYNAMIC(CPResultSampleStateDialog)

public:
	CPResultSampleStateDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPResultSampleStateDialog();

	void	RefreshUI(const int nShowType);
	void	ExcelOut(ExcelAccessor* pXls);

// �Ի�������
	enum { IDD = IDD_PRESULT_SAMPLESTATE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedShow();
	afx_msg void OnBnClickedFstateDetail();
	afx_msg void OnBnClickedRefresh();

	DECLARE_MESSAGE_MAP()

private:
	void	RefreshFStateList();
};
