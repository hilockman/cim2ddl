#pragma once


// CPRSampleSetDialog �Ի���

class CPRSampleSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CPRSampleSetDialog)

public:
	CPRSampleSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPRSampleSetDialog();

// �Ի�������
	enum { IDD = IDD_SET_SAMPLE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedMontecarlo();
	afx_msg void OnBnClickedFastsort();
	afx_msg void OnBnClickedStatesample();
	afx_msg void OnBnClickedAnalytical();
	afx_msg void OnBnClickedOk();
	DECLARE_MESSAGE_MAP()

public:
	int		m_nSampleType;

	int		m_nPRSampleMethod;
	int		m_nPRSampleObject;

private:
	void	ResolveRSampleParam();
};
