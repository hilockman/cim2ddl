// ZILDetailDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaZILDetailDialog.h"


// CZILDetailDialog �Ի���
static	char*	lpszDataColumn[]=
{
	"���",
	"���ĸ��",
	"�յ�ĸ��",
	"��·��",
	"����(pu)",
	"�翹(pu)",
	"�ϲ�ĸ��",
};


IMPLEMENT_DYNAMIC(CBpaZILDetailDialog, CDialog)

CBpaZILDetailDialog::CBpaZILDetailDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaZILDetailDialog::IDD, pParent)
{

}

CBpaZILDetailDialog::~CBpaZILDetailDialog()
{
}

void CBpaZILDetailDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaZILDetailDialog, CDialog)
	ON_BN_CLICKED(IDC_REFRESH, &CBpaZILDetailDialog::OnBnClickedRefresh)
END_MESSAGE_MAP()


// CZILDetailDialog ��Ϣ��������

BOOL CBpaZILDetailDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ZIL_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDataColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszDataColumn[i],	LVCFMT_LEFT,	60);

	RefreshZILList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaZILDetailDialog::RefreshZILList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[MDB_CHARLEN_LONG];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ZIL_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pBpaBlock->m_nRecordNum[BPA_DAT_ZIL]; i++)
	{
		sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ZILArray[i].szBusI, g_pBpaBlock->m_BpaDat_ZILArray[i].fkVI);	pListCtrl->SetItemText(nRow,nCol++,szBuf);
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ZILArray[i].szBusJ, g_pBpaBlock->m_BpaDat_ZILArray[i].fkVJ);	pListCtrl->SetItemText(nRow,nCol++,szBuf);
		sprintf(szBuf,"%c", g_pBpaBlock->m_BpaDat_ZILArray[i].cLoop);												pListCtrl->SetItemText(nRow,nCol++,szBuf);
		sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_ZILArray[i].fR);													pListCtrl->SetItemText(nRow,nCol++,szBuf);
		sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_ZILArray[i].fX);													pListCtrl->SetItemText(nRow,nCol++,szBuf);
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ZILArray[i].szMBus, g_pBpaBlock->m_BpaDat_ZILArray[i].fMkV);	pListCtrl->SetItemText(nRow,nCol++,szBuf);

		nRow++;
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDataColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaZILDetailDialog::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshZILList();
}
