// PRFStateEstimateSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PREstimateSetDialog.h"


// CPREstimateSetDialog �Ի���

IMPLEMENT_DYNAMIC(CPREstimateSetDialog, CDialog)

CPREstimateSetDialog::CPREstimateSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPREstimateSetDialog::IDD, pParent)
{
}

CPREstimateSetDialog::~CPREstimateSetDialog()
{
}

void CPREstimateSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPREstimateSetDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPREstimateSetDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDC_MULTI_THREAD, &CPREstimateSetDialog::OnBnClickedMultiThread)
END_MESSAGE_MAP()


// CPREstimateSetDialog ��Ϣ��������

BOOL CPREstimateSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	char	szBuf[260];

	((CButton*)GetDlgItem(IDC_LINE_LIMIT))		->SetCheck(g_PRAdeSetting.bLineELimit);
	((CButton*)GetDlgItem(IDC_TRAN_LIMIT))		->SetCheck(g_PRAdeSetting.bTranELimit);

	((CButton*)GetDlgItem(IDC_GEN_ELIMIT))		->SetCheck(g_PRAdeSetting.bGenPELimit);
	((CButton*)GetDlgItem(IDC_UPFC_ELIMIT))		->SetCheck(g_PRAdeSetting.bUPFCELimit);
	((CButton*)GetDlgItem(IDC_UPFC_ADJUSTRC))	->SetCheck(g_PRAdeSetting.bUPFCAdjustRC);

	((CButton*)GetDlgItem(IDC_AUXLOAD_ADJUST))	->SetCheck(g_PRAdeSetting.bAuxLoadAdjust);
	((CButton*)GetDlgItem(IDC_EQGEN_ADJUST))	->SetCheck(g_PRAdeSetting.bEQGenAdjust);
	((CButton*)GetDlgItem(IDC_EQLOAD_ADJUST))	->SetCheck(g_PRAdeSetting.bEQLoadAdjust);

	((CButton*)GetDlgItem(IDC_MULTI_THREAD))	->SetCheck(g_PRAdeSetting.nMultiThread > 1);
	sprintf(szBuf, "%d", g_PRAdeSetting.nMultiThread);	GetDlgItem(IDC_THREAD_NUM)->SetWindowText(szBuf);

	sprintf(szBuf, "%.3f", g_PRAdeSetting.fMinIslandGLRatio);	GetDlgItem(IDC_ISLAND_MINIMAL_GLRATIO)->SetWindowText(szBuf);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPREstimateSetDialog::ResolveREstimateParam()
{
	char	szBuffer[260];

	UpdateData();

	g_PRAdeSetting.bLineELimit		= ((CButton*)GetDlgItem(IDC_LINE_LIMIT))	->GetCheck();
	g_PRAdeSetting.bTranELimit		= ((CButton*)GetDlgItem(IDC_TRAN_LIMIT))	->GetCheck();
	g_PRAdeSetting.bGenPELimit		= ((CButton*)GetDlgItem(IDC_GEN_ELIMIT))	->GetCheck();
	g_PRAdeSetting.bUPFCELimit		= ((CButton*)GetDlgItem(IDC_UPFC_ELIMIT))	->GetCheck();
	g_PRAdeSetting.bAuxLoadAdjust	= ((CButton*)GetDlgItem(IDC_AUXLOAD_ADJUST))->GetCheck();
	g_PRAdeSetting.bEQGenAdjust		= ((CButton*)GetDlgItem(IDC_EQGEN_ADJUST))	->GetCheck();
	g_PRAdeSetting.bEQLoadAdjust	= ((CButton*)GetDlgItem(IDC_EQLOAD_ADJUST))	->GetCheck();
	g_PRAdeSetting.bUPFCAdjustRC	= ((CButton*)GetDlgItem(IDC_UPFC_ADJUSTRC))	->GetCheck();

	//g_PRAdeSetting.nMultiThread		= ((CButton*)GetDlgItem(IDC_MULTI_THREAD))	->GetCheck();
	GetDlgItem(IDC_THREAD_NUM)->GetWindowText(szBuffer, 260);				g_PRAdeSetting.nMultiThread=atoi(szBuffer);
	if (g_PRAdeSetting.nMultiThread < 1)	g_PRAdeSetting.nMultiThread = 1;
	GetDlgItem(IDC_ISLAND_MINIMAL_GLRATIO)->GetWindowText(szBuffer, 260);	g_PRAdeSetting.fMinIslandGLRatio=atof(szBuffer);

	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CPREstimateSetDialog::OnBnClickedMultiThread()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (((CButton*)GetDlgItem(IDC_MULTI_THREAD))->GetCheck())
	{
		char	szBuffer[260];
		SYSTEM_INFO sysInfo;
		::GetSystemInfo(&sysInfo);
		sprintf(szBuffer, "%d", (int)sysInfo.dwNumberOfProcessors/2);
		GetDlgItem(IDC_THREAD_NUM)->SetWindowText(szBuffer);
	}
	else
	{
		GetDlgItem(IDC_THREAD_NUM)->SetWindowText("1");
	}
}

void CPREstimateSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	ResolveREstimateParam();

	OnOK();
}
