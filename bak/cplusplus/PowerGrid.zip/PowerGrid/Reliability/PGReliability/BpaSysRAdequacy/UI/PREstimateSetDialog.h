#pragma once


// CPREstimateSetDialog �Ի���

class CPREstimateSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CPREstimateSetDialog)

public:
	CPREstimateSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPREstimateSetDialog();

// �Ի�������
	enum { IDD = IDD_SET_ESTIMATE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	DECLARE_MESSAGE_MAP()
public:

private:
	void	ResolveREstimateParam();
public:
	afx_msg void OnBnClickedMultiThread();
};
