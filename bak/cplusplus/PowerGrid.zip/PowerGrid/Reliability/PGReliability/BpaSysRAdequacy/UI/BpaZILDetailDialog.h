#pragma once


// CZILDetailDialog �Ի���

class CBpaZILDetailDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaZILDetailDialog)

public:
	CBpaZILDetailDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaZILDetailDialog();

// �Ի�������
	enum { IDD = IDD_ZILDETAIL_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedRefresh();
	DECLARE_MESSAGE_MAP()
private:
	void	RefreshZILList();
public:
};
