
// BpaRAdequacyUI.h : PROJECT_NAME Ӧ�ó������ͷ�ļ�
//

#pragma once

#include "../../PRAdequacyBase/PRAdequacyBase.h"

#ifndef __AFXWIN_H__
	#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"		// ������

#define	WM_ESTIMATEBEG	WM_APP+1001
#define	WM_ESTIMATING	WM_APP+1002
#define	WM_ESTIMATEEND	WM_APP+1003

// CBpaRAdequacyUIApp:
// �йش����ʵ�֣������ BpaRAdequacyUI.cpp
//

class CBpaSysAdequacyUIApp : public CWinAppEx
{
public:
	CBpaSysAdequacyUIApp();

// ��д
	public:
	virtual BOOL InitInstance();

// ʵ��
protected:
	afx_msg void OnAdequacyEstimateBeg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnAdequacyEstimating(WPARAM wParam, LPARAM lParam);
	afx_msg void OnAdequacyEstimateEnd(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

extern	CBpaSysAdequacyUIApp theApp;
extern	tagBpaBlock*		g_pBpaBlock;
extern	tagPRBlock*			g_pPRBlock;
extern	CBpaMemDBInterface	g_BpaMemDBInterface;
extern	CPRMemDBInterface	g_PRMemDBInterface;
extern	char				g_szRunDir[260];

extern	tagBpaPRAdequacySetting		g_PRAdeSetting;
extern	CBpaPRParam					g_BpaPRParam;
extern	CPRAdequacyStateSample		g_PRStateSample;			//	���ؿ���״̬����
extern	CPRAdequacyEstimate			g_PRAdeEstimate;

extern	const	char*	g_lpszLogFile;
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	void	ClearLog(const char* lpszLogFile);
extern	void	PrintMessage(char* pformat, ...);

extern	void	BpaMemDB2PRMemDB(tagBpaBlock* pBpaBlock, tagPRBlock* pPRBlock, const char* lpszBpaDatFile, const char* lpszBpaSwiFile, const unsigned char bGenBusLoadAsAux=0);
