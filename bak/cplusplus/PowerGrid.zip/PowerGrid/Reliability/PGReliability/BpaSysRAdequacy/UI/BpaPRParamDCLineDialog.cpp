// BpaPRParamDCLineDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamDCLineDialog.h"

// CBpaPRParamDCLineDialog �Ի���
const	int		m_nConstLineColumn = 1;
static	char*	lpszDCLineColumn[]=
{
	"���",
	"��·����",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
	"I��ĸ��",
	"J��ĸ��",
};


IMPLEMENT_DYNAMIC(CBpaPRParamDCLineDialog, CDialog)

CBpaPRParamDCLineDialog::CBpaPRParamDCLineDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamDCLineDialog::IDD, pParent)
{

}

CBpaPRParamDCLineDialog::~CBpaPRParamDCLineDialog()
{
}

void CBpaPRParamDCLineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamDCLineDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD_DCLINE, &CBpaPRParamDCLineDialog::OnBnClickedAddDcline)
	ON_BN_CLICKED(IDC_DEL_DCLINE, &CBpaPRParamDCLineDialog::OnBnClickedDelDcline)
	ON_NOTIFY(NM_CLICK, IDC_DCLINE_LIST, &CBpaPRParamDCLineDialog::OnNMClickDclineList)
END_MESSAGE_MAP()


// CBpaPRParamDCLineDialog ��Ϣ��������

BOOL CBpaPRParamDCLineDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DCLINE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDCLineColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszDCLineColumn[i],	LVCFMT_LEFT,	60);

	CComboBox*	pComboBox;
	pComboBox=(CComboBox*)GetDlgItem(IDC_DCBUSI_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_DCBUS]; i++)
		pComboBox->AddString(g_pPRBlock->m_DCBusArray[i].szName);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DCBUSJ_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_DCBUS]; i++)
		pComboBox->AddString(g_pPRBlock->m_DCBusArray[i].szName);

	RefreshDCLineList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamDCLineDialog::RefreshDCLineList()
{
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DCLINE_LIST);

	int		nDev, nRow, nCol;
	char	szBuf[260];

	int			nSelItem=-1;
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<(int)g_pPRBlock->m_nRecordNum[PR_DCLINE]; nDev++)
	{
		sprintf(szBuf, "%d", nRow+1);
		pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_DCLineArray[nDev].szName);
		sprintf(szBuf, "%f", g_pPRBlock->m_DCLineArray[nDev].fRerr);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_DCLineArray[nDev].fTrep);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_DCLineArray[nDev].szDCBusI);
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_DCLineArray[nDev].szDCBusJ);

		nRow++;
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDCLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		pListCtrl->SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamDCLineDialog::OnBnClickedAddDcline()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		nDevice;
	double	fRerr, fTrep;
	char	szBusI[MDB_CHARLEN_SHORT], szBusJ[MDB_CHARLEN_SHORT], szBuf[260];

	CComboBox*	pComboBox;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DCLINE_LIST);

	GetDlgItem(IDC_DCLINE_RERR)->	GetWindowText(szBuf, 260);	fRerr = atof(szBuf);
	GetDlgItem(IDC_DCLINE_TREP)->	GetWindowText(szBuf, 260);	fTrep = atof(szBuf);

	memset(szBusI, 0, MDB_CHARLEN_SHORT);
	memset(szBusJ, 0, MDB_CHARLEN_SHORT);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DCBUSI_COMBO);
	nDevice = pComboBox->GetCurSel();
	if (nDevice != CB_ERR)
		pComboBox->GetLBText(nDevice, szBusI);
	else
	{
		AfxMessageBox("��ȷ��DCLINE����ĸ��");
		return;
	}

	pComboBox=(CComboBox*)GetDlgItem(IDC_DCBUSJ_COMBO);
	nDevice = pComboBox->GetCurSel();
	if (nDevice != CB_ERR)
		pComboBox->GetLBText(nDevice, szBusJ);

	if (g_pPRBlock->m_nRecordNum[PR_DCLINE] < g_PRMemDBInterface.PRGetTableMax(PR_DCLINE)-1)
	{
		memset(&g_pPRBlock->m_DCLineArray[g_pPRBlock->m_nRecordNum[PR_DCLINE]], 0, sizeof(tagPRDCLine));
		sprintf(g_pPRBlock->m_DCLineArray[g_pPRBlock->m_nRecordNum[PR_DCLINE]].szName, "%s-%s", szBusI, szBusJ);
		g_pPRBlock->m_DCLineArray[g_pPRBlock->m_nRecordNum[PR_DCLINE]].fRerr = fRerr;
		g_pPRBlock->m_DCLineArray[g_pPRBlock->m_nRecordNum[PR_DCLINE]].fTrep = fTrep;
		strcpy(g_pPRBlock->m_DCLineArray[g_pPRBlock->m_nRecordNum[PR_DCLINE]].szDCBusI, szBusI);
		strcpy(g_pPRBlock->m_DCLineArray[g_pPRBlock->m_nRecordNum[PR_DCLINE]].szDCBusJ, szBusJ);
		g_pPRBlock->m_nRecordNum[PR_DCLINE]++;
	}
	else
		Log(g_lpszLogFile, "        ********** %s ���ݿⳬ��\n", g_PRMemDBInterface.PRGetTableDesp(PR_DCLINE));

	RefreshDCLineList();
}

void CBpaPRParamDCLineDialog::OnBnClickedDelDcline()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDevice;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DCLINE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nSelItem=pListCtrl->GetNextSelectedItem(pos);

		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_DCLINE]; i++)
		{
			if (stricmp(g_pPRBlock->m_DCLineArray[i].szName, pListCtrl->GetItemText(nSelItem, m_nConstLineColumn)) == 0)
			{
				nDevice = i;
				break;
			}
		}

		if (nDevice >= 0)
			g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_DCLINE, nDevice);
	}

	RefreshDCLineList();
}

void CBpaPRParamDCLineDialog::OnNMClickDclineList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DCLINE_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		register int	i;
		int		nItem=pListCtrl->GetNextSelectedItem(pos);
		int		nCol, nDCLine = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_DCLINE]; i++)
		{
			if (stricmp(g_pPRBlock->m_DCLineArray[i].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn)) == 0)
			{
				nDCLine = i;
				break;

			}
		}

		if (nDCLine >= 0)
		{
			CComboBox*	pComboBox;

			pComboBox=(CComboBox*)GetDlgItem(IDC_DCBUSI_COMBO);
			pComboBox->SetCurSel(pComboBox->FindString(-1, pListCtrl->GetItemText(nItem, 4)));

			pComboBox=(CComboBox*)GetDlgItem(IDC_DCBUSJ_COMBO);
			pComboBox->SetCurSel(pComboBox->FindString(-1, pListCtrl->GetItemText(nItem, 5)));
		}

		nCol=2;
		if (strlen(pListCtrl->GetItemText(nItem, nCol)) > 0)
		{
			GetDlgItem(IDC_DCLINE_RERR)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
			GetDlgItem(IDC_DCLINE_TREP)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		}
	}
	*pResult = 0;
}
