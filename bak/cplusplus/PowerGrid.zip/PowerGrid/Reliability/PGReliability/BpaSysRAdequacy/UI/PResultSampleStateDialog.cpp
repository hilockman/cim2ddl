// PRFStateListDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PResultSampleStateDialog.h"
#include "PRDetailSampleStateDialog.h"

// CPResultSampleStateDialog �Ի���
const	int		nFaultDevColumn = 2;
static	char*	lpszSampleStateColumn[]=
{
	"״̬��",
	"��������",
	"�����豸",
	"����",
	"����ʱ��",
	"״̬��",

	"����ʧ����",
	"����ʧ����",
	"����ʧ����",

	"ƽ��������",
	"ƽ�������",
	"ƽ��ʧ����",

	"�µ�",
	"�µ�������",
	"�µ�������",
	"�µ�ʧ����",

	"�����и���",
	"����������",
	"���޼�����",
	"����ʧ����",

	"�¹ʵȼ�",
	"ʧ���ɱ���",
	"ʧ��������",
	"ʧ���ɵ���",
};

IMPLEMENT_DYNAMIC(CPResultSampleStateDialog, CDialog)

CPResultSampleStateDialog::CPResultSampleStateDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPResultSampleStateDialog::IDD, pParent)
{
}

CPResultSampleStateDialog::~CPResultSampleStateDialog()
{
}

void CPResultSampleStateDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPResultSampleStateDialog, CDialog)
	ON_BN_CLICKED(IDC_SHOW_ENSLOSSLOAD, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_MILOSSLOAD, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_ELLOSSLOAD, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_DEVOVLMT, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_MISLAND, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_FAULTGRADE0, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_FAULTGRADE1, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_FAULTGRADE2, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_FAULTGRADE3, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_FAULTGRADE4, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_SHOW_FAULTDEVICE, &CPResultSampleStateDialog::OnBnClickedShow)
	ON_BN_CLICKED(IDC_REFRESH, &CPResultSampleStateDialog::OnBnClickedRefresh)
	ON_BN_CLICKED(IDC_FSTATE_DETAIL, &CPResultSampleStateDialog::OnBnClickedFstateDetail)
END_MESSAGE_MAP()


// CPResultSampleStateDialog ��Ϣ��������

BOOL CPResultSampleStateDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int		nColumn;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszSampleStateColumn)/sizeof(char*); nColumn++)
		pListCtrl->InsertColumn(nColumn, lpszSampleStateColumn[nColumn],	LVCFMT_LEFT,	100);

	((CButton*)GetDlgItem(IDC_SHOW_ENSLOSSLOAD))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_MILOSSLOAD))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_ELLOSSLOAD))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_DEVOVLMT))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_MISLAND))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE0))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE1))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE2))->SetCheck(FALSE);
	((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE3))->SetCheck(TRUE);
	((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE4))->SetCheck(TRUE);

	((CButton*)GetDlgItem(IDC_SHOW_FAULTDEVICE))->SetCheck(FALSE);

	RefreshFStateList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPResultSampleStateDialog::RefreshUI(const int nShowType)
{
	RefreshFStateList();
}

void CPResultSampleStateDialog::RefreshFStateList()
{
	int		nFState, nFltDev, nRow, nCol;
	char	szBuf[260];
	int		nColWidth, nHeaderWidth;
	unsigned char	bShow, nFDevNum;
	int		nStateNum;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	pListCtrl->DeleteAllItems();

	unsigned char	bShowEnsLossLoad=((CButton*)GetDlgItem(IDC_SHOW_ENSLOSSLOAD))->GetCheck();
	unsigned char	bShowMILossLoad=((CButton*)GetDlgItem(IDC_SHOW_MILOSSLOAD))->GetCheck();
	unsigned char	bShowELLossLoad=((CButton*)GetDlgItem(IDC_SHOW_ELLOSSLOAD))->GetCheck();
	unsigned char	bShowDevOvlmt=((CButton*)GetDlgItem(IDC_SHOW_DEVOVLMT))->GetCheck();
	unsigned char	bShowMIsland=((CButton*)GetDlgItem(IDC_SHOW_MISLAND))->GetCheck();
	unsigned char	bShowFGrade0=((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE0))->GetCheck();
	unsigned char	bShowFGrade1=((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE1))->GetCheck();
	unsigned char	bShowFGrade2=((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE2))->GetCheck();
	unsigned char	bShowFGrade3=((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE3))->GetCheck();
	unsigned char	bShowFGrade4=((CButton*)GetDlgItem(IDC_SHOW_FAULTGRADE4))->GetCheck();
	unsigned char	bShowFDevice=((CButton*)GetDlgItem(IDC_SHOW_FAULTDEVICE))->GetCheck();

	nStateNum = 0;
	nRow=0;
	for (nFState=0; nFState<g_pPRBlock->m_nRecordNum[PR_FSTATE]; nFState++)
	{
		bShow = 0;
		if (bShowEnsLossLoad && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].fEnsCutLoad > FLT_MIN)
				bShow=1;
		}
		if (bShowMILossLoad && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].fMIOutLoad > FLT_MIN)
				bShow=1;
		}
		if (bShowELLossLoad && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].bELCutLoad > FLT_MIN)
				bShow=1;
		}
		if (bShowDevOvlmt && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].bOverLimit)
				bShow=1;
		}
		if (bShowMIsland && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].bMIsland)
				bShow=1;
		}
		if (bShowFGrade0 && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].nFaultGrade == PRFState_FaultGrade_0)
				bShow=1;
		}
		if (bShowFGrade1 && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].nFaultGrade == PRFState_FaultGrade_1)
				bShow=1;
		}
		if (bShowFGrade2 && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].nFaultGrade == PRFState_FaultGrade_2)
				bShow=1;
		}
		if (bShowFGrade3 && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].nFaultGrade == PRFState_FaultGrade_3)
				bShow=1;
		}
		if (bShowFGrade4 && !bShow)
		{
			if (g_pPRBlock->m_FStateArray[nFState].nFaultGrade == PRFState_FaultGrade_4)
				bShow=1;
		}

		if (!bShow)
			continue;

		sprintf(szBuf, "%d", nFState);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);
		nStateNum++;

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_SAMPLETYPE, g_pPRBlock->m_FStateArray[nFState].nSampleType));
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateArray[nFState].nFDevNum);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[nFState].fStateProb);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateArray[nFState].fStateDur);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%d", g_pPRBlock->m_FStateArray[nFState].nStateNum);			pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fFLossGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fFLossGenCap);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fFLossLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fAgcInsGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fAgcCutGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fEnsCutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_MISLAND, g_pPRBlock->m_FStateArray[nFState].bMIsland));

		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fMIInsGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fMICutGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fMIOutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_ELIMIT, g_pPRBlock->m_FStateArray[nFState].bELCutLoad));

		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELInsGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELCutGen);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_FStateArray[nFState].fELCutLoad);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		pListCtrl->SetItemText(nRow,nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_FSTATE, PR_FSTATE_FAULTGRADE, g_pPRBlock->m_FStateArray[nFState].nFaultGrade));
		sprintf(szBuf, "%.2f", 100*g_pPRBlock->m_FStateArray[nFState].fMaxFaultRatio);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_ZoneArray[g_pPRBlock->m_FStateArray[nFState].nMaxFaultZone].szName);

		sprintf(szBuf,"%.2f", g_pPRBlock->m_FStateArray[nFState].fStateDur*(g_pPRBlock->m_FStateArray[nFState].fFLossLoad+g_pPRBlock->m_FStateArray[nFState].fEnsCutLoad+g_pPRBlock->m_FStateArray[nFState].fMIOutLoad+g_pPRBlock->m_FStateArray[nFState].fELCutLoad)*8760/g_pPRBlock->m_System.fMCSSimTime);
		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		if (bShowFDevice && g_pPRBlock->m_FStateArray[nFState].nFDevNum > 0)
		{
			nFDevNum = 0;
			for (nFltDev=0; nFltDev<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; nFltDev++)
			{
				if (g_pPRBlock->m_FStateFDevArray[nFltDev].nFStateNo < nFState)
					continue;
				if (g_pPRBlock->m_FStateFDevArray[nFltDev].nFStateNo > nFState)
					break;

				int nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevTyp, "Name");
				if (nField >= 0)
				{
					char	szRec[MDB_CHARLEN_LONG];
					if (nFDevNum > 0)
						pListCtrl->InsertItem(nRow, "");

					g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevIdx, szRec);

					sprintf(szBuf, "(%d/%d) %s %s", nFDevNum+1, g_pPRBlock->m_FStateArray[nFState].nFDevNum, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevTyp), szRec);
					pListCtrl->SetItemText(nRow, nFaultDevColumn, szBuf);
					nRow++;

					nFDevNum++;
				}
			}
		}
		else
		{
			nRow++;
		}
	}
	sprintf(szBuf, "%d", nStateNum);	GetDlgItem(IDC_STATE_NUM)->SetWindowText(szBuf);

	for (nCol=0; nCol<sizeof(lpszSampleStateColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPResultSampleStateDialog::OnBnClickedShow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshFStateList();
}

void CPResultSampleStateDialog::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshFStateList();
}

void CPResultSampleStateDialog::ExcelOut(ExcelAccessor* pXls)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	if (pListCtrl->GetItemCount() <= 0)
		return;

	PrintMessage("Excel��������״̬��ʼ");

	int		nRow, nCol, nFieldNum;

	pXls->AddSheet(_T("����״̬"));
	pXls->SetCurSheet(_T("����״̬"));

	nFieldNum=sizeof(lpszSampleStateColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		pXls->AddCell(CString(lpszSampleStateColumn[nCol]));
	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		pXls->NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			pXls->AddCell(pListCtrl->GetItemText(nRow, nCol));
	}

	PrintMessage("Excel��������״̬���");
}

void CPResultSampleStateDialog::OnBnClickedFstateDetail()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	int nItem = pListCtrl->GetNextSelectedItem(pos);
	int nFState = atoi(pListCtrl->GetItemText(nItem, 0));
	if (nFState <= 0)
		return;

	CPRDetailSampleStateDialog	dlg;
	dlg.SetFState(nFState);
	dlg.DoModal();
}
