#pragma once


// CBpaPRParamTCSCDialog �Ի���

class CBpaPRParamTCSCDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamTCSCDialog)

public:
	CBpaPRParamTCSCDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamTCSCDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_TCSC_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedAddTcsc();
	afx_msg void OnBnClickedDelTcsc();
	afx_msg void OnNMClickAclineList(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
public:

private:
	void	RefreshACLineList();
public:
	afx_msg void OnBnClickedSearch();
	afx_msg void OnBnClickedShowLinehastcsc();
};
