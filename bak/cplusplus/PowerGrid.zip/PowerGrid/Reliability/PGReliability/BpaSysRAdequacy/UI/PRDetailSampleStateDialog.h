#pragma once

// CFStateDetailDialog �Ի���

class CPRDetailSampleStateDialog : public CDialog
{
	DECLARE_DYNAMIC(CPRDetailSampleStateDialog)

public:
	CPRDetailSampleStateDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPRDetailSampleStateDialog();

	void	SetFState(const int nFState)
	{
		m_nFState = nFState;
	}

// �Ի�������
	enum { IDD = IDD_SAMPLESTATE_DETAIL_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedManuFault();
	DECLARE_MESSAGE_MAP()

private:
	void	RefreshList(const int nFState = 0);
	void	RefreshFStateList(const int nFState);
	void	RefreshFDeviceList(const int nFState);
	void	RefreshMStateList(const int nFState);
	void	RefreshOvLmtDevList(const int nFState);
	void	RefreshOvLmtAdList(const int nFState);

private:
	int		m_nFState;
public:
};
