// FStateDetailDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "PRDetailSampleStateDialog.h"


// CFStateDetailDialog �Ի���
IMPLEMENT_DYNAMIC(CPRDetailSampleStateDialog, CDialog)

CPRDetailSampleStateDialog::CPRDetailSampleStateDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPRDetailSampleStateDialog::IDD, pParent)
{
	m_nFState=-1;
}

CPRDetailSampleStateDialog::~CPRDetailSampleStateDialog()
{
}

void CPRDetailSampleStateDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPRDetailSampleStateDialog, CDialog)
	ON_BN_CLICKED(IDC_MANU_FAULT, &CPRDetailSampleStateDialog::OnBnClickedManuFault)
END_MESSAGE_MAP()


// CFStateDetailDialog ��Ϣ��������

static	char*	lpszSampleStateColumn[]=
{
	"��",
	"ֵ",
};

static	char*	lpszFDevColumn[]=
{
	"�豸����",
	"�豸����",
};

static	char*	lpszOvLmtDevColumn[]=
{
	"�豸����",
	"�豸����",
	"Խ��ֵ",
	"����ֵ",
	"�ֵ",
};

static	char*	lpszOvLmtAdColumn[]=
{
	"���",
	"�豸����",
	"�豸����",
	"���ʵ�����",
};

static	char*	lpszPRMStateColumn[]=
{
	"���",
	"�豸����",
	"�豸����",
	"�豸״̬",
};


BOOL CPRDetailSampleStateDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;

	if (m_nFState <= 0)
	{
		EndDialog(IDCANCEL);
		return FALSE;
	}

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszSampleStateColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszSampleStateColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FDEVICE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszFDevColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszFDevColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTDEV_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszOvLmtDevColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszOvLmtDevColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTAD_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszOvLmtAdColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszOvLmtAdColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszPRMStateColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszPRMStateColumn[i],	LVCFMT_LEFT,	100);

	char	szBuf[260];
	sprintf(szBuf, "%d", m_nFState);
	GetDlgItem(IDC_FSTATE_NUMBER)->SetWindowText(szBuf);

	RefreshList(m_nFState);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPRDetailSampleStateDialog::RefreshList(const int nFState)
{
	RefreshFStateList(nFState);
	RefreshFDeviceList(nFState);
	RefreshMStateList(nFState);
	RefreshOvLmtDevList(nFState);
	RefreshOvLmtAdList(nFState);
}

void	CPRDetailSampleStateDialog::RefreshFStateList(const int nFState)
{
	int		nField, nRow;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FSTATE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nField=0; nField<g_PRMemDBInterface.PRGetTableFieldNum(PR_FSTATE); nField++)
	{
		if (g_PRMemDBInterface.PRGetFieldCategory(PR_FSTATE, nField) == MDBFieldCategoryAid)
			continue;

		pListCtrl->InsertItem(nRow, g_PRMemDBInterface.PRGetFieldDesp(PR_FSTATE, nField));
		g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, PR_FSTATE, nField, nFState, szBuf);	pListCtrl->SetItemText(nRow, 1, szBuf);
		nRow++;
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (nField=0; nField<sizeof(lpszSampleStateColumn)/sizeof(char*); nField++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nField, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nField);
		pListCtrl->SetColumnWidth(nField, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nField);

		pListCtrl->SetColumnWidth(nField, max(nColWidth, nHeaderWidth));
	}
}

void	CPRDetailSampleStateDialog::RefreshFDeviceList(const int nFState)
{
	register int	i;
	int		nRow, nCol;
	int		nField;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FDEVICE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; i++)
	{
		if (g_pPRBlock->m_FStateFDevArray[i].nFStateNo == nFState)
		{
			pListCtrl->InsertItem(nRow, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp));	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp, "Name");
			g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[i].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[i].nFDevIdx, szBuf);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszFDevColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPRDetailSampleStateDialog::RefreshMStateList(const int nFState)
{
	register int	i;
	int		nRow, nCol;
	int		nTable, nRecord, nField;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_System.nMStateDevNum; i++)
	{
		sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nTable =g_pPRBlock->m_FStateMStateArray[g_pPRBlock->m_System.nMStateDevNum*g_pPRBlock->m_FStateArray[nFState].nMSoutIndex+i].nMSDevType;
		nRecord=g_pPRBlock->m_FStateMStateArray[g_pPRBlock->m_System.nMStateDevNum*g_pPRBlock->m_FStateArray[nFState].nMSoutIndex+i].nMSDevIdx;

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetTableDesp(nTable));
		nField=g_PRMemDBInterface.PRGetFieldIndex(nTable, "Name");
		g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, nTable, nField, nRecord, szBuf);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateMStateArray[g_pPRBlock->m_System.nMStateDevNum*g_pPRBlock->m_FStateArray[nFState].nMSoutIndex+i].fStatePout);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszPRMStateColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPRDetailSampleStateDialog::RefreshOvLmtDevList(const int nFState)
{
	register int	i;
	int		nField, nRow, nCol;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTDEV_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEOVLDEV]; i++)
	{
		if (g_pPRBlock->m_FStateOvlDevArray[i].nFStateNo == nFState)
		{
			pListCtrl->InsertItem(nRow, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateOvlDevArray[i].nDevTyp));	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateOvlDevArray[i].nDevTyp, "Name");	g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateOvlDevArray[i].nDevTyp, nField, g_pPRBlock->m_FStateOvlDevArray[i].nDevIdx, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f[%.1f]", g_pPRBlock->m_FStateOvlDevArray[i].fOvLmtP, g_PRAdeSetting.fDc2AcFactor*g_pPRBlock->m_FStateOvlDevArray[i].fOvLmtP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f[%.1f]", g_pPRBlock->m_FStateOvlDevArray[i].fAdLmtP, g_PRAdeSetting.fDc2AcFactor*g_pPRBlock->m_FStateOvlDevArray[i].fAdLmtP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", g_pPRBlock->m_FStateOvlDevArray[i].fRated);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszOvLmtDevColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPRDetailSampleStateDialog::RefreshOvLmtAdList(const int nFState)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTAD_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEOVLAD]; i++)
	{
		if (g_pPRBlock->m_FStateOvlAdArray[i].nFStateNo == nFState)
		{
			sprintf(szBuf,"%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetTableDesp(g_pPRBlock->m_FStateOvlAdArray[i].nAdjDevTyp));

			memset(szBuf, 0, 260);
			if (g_pPRBlock->m_FStateOvlAdArray[i].nAdjDevTyp == PR_UPFC)
				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateOvlAdArray[i].nAdjDevTyp, PR_UPFC_NAME, g_pPRBlock->m_FStateOvlAdArray[i].nAdjDevIdx, szBuf);
			else
				g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, PR_ACBUS, PR_ACBUS_NAME, g_pPRBlock->m_FStateOvlAdArray[i].nAdjDevIdx, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf,"%f", g_pPRBlock->m_FStateOvlAdArray[i].fAdValue);											pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszOvLmtAdColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPRDetailSampleStateDialog::OnBnClickedManuFault()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	time_t		now;
	struct tm	when;

	int					nFltDev, nField;
	tagPRManualFault	sMFault;

	if (m_nFState <= 0)
	{
		AfxMessageBox("��״̬�����豸��=0");
		return;
	}

	memset(&sMFault, 0, sizeof(tagPRManualFault));

	time(&now);
	when = *localtime( &now );
	sprintf(sMFault.szName, "�¼�%.4d%.2d%.2d%.2d%.2d%.2d", when.tm_year+1900, when.tm_mon+1, when.tm_mday, when.tm_hour, when.tm_min, when.tm_sec);

	for (nFltDev=0; nFltDev<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; nFltDev++)
	{
		if (g_pPRBlock->m_FStateFDevArray[nFltDev].nFStateNo < m_nFState)
			continue;
		if (g_pPRBlock->m_FStateFDevArray[nFltDev].nFStateNo > m_nFState)
			break;

		nField=g_PRMemDBInterface.PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevTyp, "Name");
		if (nField >= 0)
		{
			sMFault.nFDevType = g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevTyp;
			g_PRMemDBInterface.PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[nFltDev].nFDevIdx, sMFault.szFDevName);

			if (g_pPRBlock->m_nRecordNum[PR_MANUALFAULT] < g_PRMemDBInterface.PRGetTableMax(PR_MANUALFAULT))
				memcpy(&g_pPRBlock->m_ManualFaultArray[g_pPRBlock->m_nRecordNum[PR_MANUALFAULT]++], &sMFault, sizeof(tagPRManualFault));
		}
	}
}
