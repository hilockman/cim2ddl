#pragma once


// CBpaPRParamMultStateDialog �Ի���

class CBpaPRParamMultStateDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamMultStateDialog)

public:
	CBpaPRParamMultStateDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamMultStateDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_MULTSTATE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeStatenumCombo();
	afx_msg void OnCbnSelchangeDevtypeCombo();
	afx_msg void OnNMClickMstateList(NMHDR *pNMHDR, LRESULT *pResult);

	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedMod();
	DECLARE_MESSAGE_MAP()

private:
	void RefreshMStateList();
	void RefreshMStateText();
	int	ResolveMStateText(tagPRDevMState* pMState);
public:
};
