#pragma once


// CBpaPRParamUPFCDialog �Ի���

class CBpaPRParamUPFCDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamUPFCDialog)

public:
	CBpaPRParamUPFCDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamUPFCDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_UPFC_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedAddUpfc();
	afx_msg void OnBnClickedDelUpfc();
	afx_msg void OnNMClickAclineList(NMHDR *pNMHDR, LRESULT *pResult);

	DECLARE_MESSAGE_MAP()
public:

private:
	void	RefreshACLineList();
public:
	afx_msg void OnBnClickedSearch();
	afx_msg void OnBnClickedShowLinehasupfc();
};
