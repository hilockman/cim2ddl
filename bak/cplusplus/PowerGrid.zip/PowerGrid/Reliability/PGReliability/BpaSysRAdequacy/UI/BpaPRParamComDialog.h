#pragma once
#include "afxcmn.h"

#include "../../../../../Common/MFCControls/MFCListCtrlEx.h"


// CPRParamComDialog �Ի���

class CBpaPRParamComDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamComDialog)

public:
	CBpaPRParamComDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamComDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_COM_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnNMClickCommparamList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedMod();
	afx_msg void OnBnClickedUp();
	afx_msg void OnBnClickedDn();
	afx_msg void OnCbnSelchangeDevtypeCombo();
	DECLARE_MESSAGE_MAP()
private:
	void RefreshPRParamCom();
public:
	afx_msg void OnBnClickedAll();
};
