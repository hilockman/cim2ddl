#pragma once
#include "BpaPRParamComDialog.h"
#include "BpaPRParamDevDialog.h"
#include "BpaPRParamTCSCDialog.h"
#include "BpaPRParamUPFCDialog.h"
#include "BpaPRParamConverterDialog.h"
#include "BpaPRParamDCLineDialog.h"
#include "BpaPRParamManuStateDialog.h"
#include "BpaPRParamCommonFaultDialog.h"
#include "BpaPRParamMultStateDialog.h"

// CPRParamDialog �Ի���

class CBpaPRParamDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamDialog)

public:
	CBpaPRParamDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedSave();

	afx_msg void OnBnClickedSaveas();
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl						m_wndTab;
	CBpaPRParamComDialog			m_wndPRParamCom;
	CBpaPRParamDevDialog			m_wndPRParamDev;
	CBpaPRParamTCSCDialog			m_wndPRParamTcsc;
	CBpaPRParamUPFCDialog			m_wndPRParamUpfc;
	CBpaPRParamConverterDialog		m_wndPRConverter;
	CBpaPRParamDCLineDialog			m_wndPRDCLine;
	CBpaPRParamManualFaultDialog	m_wndPRManuState;
	CBpaPRParamCommonFaultDialog	m_wndPRCommonFault;
	CBpaPRParamMultStateDialog		m_wndPRMultState;
public:
};
