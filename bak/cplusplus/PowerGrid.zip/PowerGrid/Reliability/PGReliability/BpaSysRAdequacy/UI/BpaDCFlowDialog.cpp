// BpaDCFlowDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaDCFlowDialog.h"
#include "../../../../../Common/Excel/ExcelAccessor.h"

// CBpaDCFlowDialog �Ի���
#define		IDC_DCFLOW_BUS	20011
#define		IDC_DCFLOW_LINE	20012
#define		IDC_DCFLOW_TRAN	20013

static	char*	lpszDCFlowBusColumn[]={
	"����",
	"��ѹ�ȼ�",
	"����ڵ�",
	"AC��ѹ(pu)",
	"DC����",
	"����",
	"����",
	"��Ч���为��",
	"���Ե�",
	"��Դ",
	"�絺",
	"ƽ��ڵ�",
};

static	char*	lpszDCFlowBranColumn[]={
	"����",
	"��ѹI",
	"��ѹJ",
	"��ڵ�",
	"�սڵ�",
	"����",
	"�翹",
	"��ֵ",
	"AC����I",
	"AC����J",
	"DC����I",
	"DC����J",
	"DC������",
	"DC׼ȷ��",
	"�絺",
};

IMPLEMENT_DYNAMIC(CBpaDCFlowDialog, CDialog)

CBpaDCFlowDialog::CBpaDCFlowDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaDCFlowDialog::IDD, pParent)
{

}

CBpaDCFlowDialog::~CBpaDCFlowDialog()
{
}

void CBpaDCFlowDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaDCFlowDialog, CDialog)
	ON_BN_CLICKED(IDC_DCFLOW, &CBpaDCFlowDialog::OnBnClickedDCFlow)
	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CBpaDCFlowDialog::OnBnClickedSaveasExcel)
	ON_BN_CLICKED(IDC_35kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_110kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_220kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_330kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_500kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_750kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_1000kV, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_OVERLIMIT, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_CBN_SELCHANGE(IDC_ISLAND_COMBO, &CBpaDCFlowDialog::OnBnClickedShowFilter)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CBpaDCFlowDialog ��Ϣ��������

BOOL CBpaDCFlowDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CRect	rectDummy;
	register int	i;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListFlowBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_DCFLOW_BUS))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListFlowBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListFlowBus.SetExtendedStyle(m_wndListFlowBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListFlowBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDCFlowBusColumn)/sizeof(char*); i++)
		m_wndListFlowBus.InsertColumn(i, lpszDCFlowBusColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListFlowLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_DCFLOW_LINE))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListFlowLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListFlowLine.SetExtendedStyle(m_wndListFlowLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListFlowLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDCFlowBranColumn)/sizeof(char*); i++)
		m_wndListFlowLine.InsertColumn(i, lpszDCFlowBranColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListFlowTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_DCFLOW_TRAN))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListFlowTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListFlowTran.SetExtendedStyle(m_wndListFlowTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListFlowTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDCFlowBranColumn)/sizeof(char*); i++)
		m_wndListFlowTran.InsertColumn(i, lpszDCFlowBranColumn[i],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndListFlowBus,			_T("ֱ������ĸ��"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListFlowLine,		_T("ֱ��������·"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListFlowTran,		_T("ֱ����������"),		-1, FALSE);

	char	szRadiate[MDB_CHARLEN];
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DCFLOW_TYPE_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("��������");
	for (i=1; i<g_pBpaBlock->m_nRecordNum[BPA_DAT_RADIATE]; i++)
	{
		sprintf(szRadiate, "���� %d", i);
		pComboBox->AddString(szRadiate);
	}

	((CButton*)GetDlgItem(IDC_35kV))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_110kV))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_220kV))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_330kV))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_500kV))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_750kV))->SetCheck(1);
	((CButton*)GetDlgItem(IDC_1000kV))->SetCheck(1);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaDCFlowDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

void CBpaDCFlowDialog::RefreshDCFlowBusList(const int nRadial)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	int		nBusNum;
	double	fTotalGen,fTotalLoad;

	m_wndListFlowBus.DeleteAllItems();

	fTotalGen=fTotalLoad=0;

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	int	nIsland=pCombo->GetCurSel();

	nBusNum=0;

	nRow=0;
	for (i=1; i<(int)g_pPRBlock->m_nRecordNum[PR_ACBUS]; i++)
	{
		if (strlen(g_pPRBlock->m_ACBusArray[i].szName) <= 0)
			continue;

		if (nRadial == 0)
		{
			if (g_pPRBlock->m_ACBusArray[i].nRadial != 0)
				continue;
			if (nIsland > 0)
			{
				if (g_pPRBlock->m_ACBusArray[i].nIsland != nIsland)
					continue;
			}
		}
		else
		{
			if (g_pPRBlock->m_ACBusArray[i].nRadial != nRadial && i != g_pPRBlock->m_RadialArray[nRadial].nRingBoundBus)
				continue;
		}

		m_wndListFlowBus.InsertItem(nRow, g_pPRBlock->m_ACBusArray[i].szName);	m_wndListFlowBus.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf,"%g",g_pPRBlock->m_ACBusArray[i].fkV);					m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",i);													m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%g",g_pPRBlock->m_ACBusArray[i].fRtV);					m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_ACBusArray[i].fPfD*180/M_PI);			m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%g",g_pPRBlock->m_ACBusArray[i].fGenP);					m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_ACBusArray[i].fLoadP);					m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_ACBusArray[i].fRadP);					m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%d",g_pPRBlock->m_ACBusArray[i].bMidBus);				m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_ACBusArray[i].bSrcBus);				m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_ACBusArray[i].nIsland);				m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_ACBusArray[i].bSlack);					m_wndListFlowBus.SetItemText(nRow, nCol++, szBuf);

		fTotalGen += g_pPRBlock->m_ACBusArray[i].fGenP;
		fTotalLoad += g_pPRBlock->m_ACBusArray[i].fLoadP;
		nBusNum++;

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDCFlowBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListFlowBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListFlowBus.GetColumnWidth(nCol);
		m_wndListFlowBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListFlowBus.GetColumnWidth(nCol);

		m_wndListFlowBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaDCFlowDialog::RefreshDCFlowBranList(const int nRadial)
{
	register int	i;
	int		nRow,nCol;
	int		nLineNum,nTranNum;
	double	fVoltage, fBuffer, fMvaBase, fPfRate;
	char	szBuf[260];

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	int	nIsland=pCombo->GetCurSel();

	m_wndListFlowLine.DeleteAllItems();
	m_wndListFlowTran.DeleteAllItems();

	nLineNum=nTranNum=0;

	nRow=0;
	for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
	{
		if (nRadial == 0)
		{
			if (g_pPRBlock->m_ACLineArray[i].nIRadial != 0 || g_pPRBlock->m_ACLineArray[i].nZRadial != 0)
				continue;
			if (nIsland > 0)
			{
				if (g_pPRBlock->m_ACLineArray[i].nIsland != nIsland)
					continue;
			}
		}
		else
		{
			if (g_pPRBlock->m_ACLineArray[i].nIRadial != nRadial && g_pPRBlock->m_ACLineArray[i].nZRadial != nRadial)
				continue;
		}

		fPfRate=0;
		if (g_pPRBlock->m_ACLineArray[i].fRated > FLT_MIN)
			fPfRate=g_PRAdeSetting.fDc2AcFactor*fabs(g_pPRBlock->m_ACLineArray[i].fPfPi)/g_pPRBlock->m_ACLineArray[i].fRated;

		fVoltage=max(g_pBpaBlock->m_BpaDat_ACLineArray[g_pPRBlock->m_ACLineArray[i].nIndex].fkVI, g_pBpaBlock->m_BpaDat_ACLineArray[g_pPRBlock->m_ACLineArray[i].nIndex].fkVJ);
		if (fVoltage < 100)
		{
			if (!((CButton*)GetDlgItem(IDC_35kV))->GetCheck())	continue;
		}
		else if (100 <= fVoltage && fVoltage < 200)
		{
			if (!((CButton*)GetDlgItem(IDC_110kV))->GetCheck())	continue;
		}
		else if (200 <= fVoltage && fVoltage < 300)
		{
			if (!((CButton*)GetDlgItem(IDC_220kV))->GetCheck())	continue;
		}
		else if (300 <= fVoltage && fVoltage < 450)
		{
			if (!((CButton*)GetDlgItem(IDC_330kV))->GetCheck())	continue;
		}
		else if (450 <= fVoltage && fVoltage < 600)
		{
			if (!((CButton*)GetDlgItem(IDC_500kV))->GetCheck())	continue;
		}
		else if (600 <= fVoltage && fVoltage < 900)
		{
			if (!((CButton*)GetDlgItem(IDC_750kV))->GetCheck())	continue;
		}
		else
		{
			if (!((CButton*)GetDlgItem(IDC_1000kV))->GetCheck())	continue;
		}

		if (((CButton*)GetDlgItem(IDC_OVERLIMIT))->GetCheck())
		{
			if (fPfRate <= 1)		continue;
		}

		m_wndListFlowLine.InsertItem(nRow, g_pPRBlock->m_ACLineArray[i].szName);	m_wndListFlowLine.SetItemData(nRow, nRow);

		nCol=1;

		sprintf(szBuf,"%g",fVoltage);								m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",fVoltage);								m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_ACLineArray[i].nIBus);		m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_ACLineArray[i].nZBus);		m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_ACLineArray[i].fR);		m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_ACLineArray[i].fX);		m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_ACLineArray[i].fRated);	m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%.1f",g_pPRBlock->m_ACLineArray[i].fRtPi);	m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%.1f",g_pPRBlock->m_ACLineArray[i].fRtPz);	m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%.1f",g_pPRBlock->m_ACLineArray[i].fPfPi);	m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%.1f",g_pPRBlock->m_ACLineArray[i].fPfPz);	m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%.2f",fPfRate);								m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);

		fMvaBase=g_fDCNMvaBase_220;
		if (fVoltage < 150)
			fMvaBase=g_fDCNMvaBase_110;
		else if (150 <= fVoltage && fVoltage < 250)
			fMvaBase=g_fDCNMvaBase_220;
		else if (250 <= fVoltage && fVoltage < 350)
			fMvaBase=g_fDCNMvaBase_330;
		else
			fMvaBase=g_fDCNMvaBase_500;
		fBuffer=100;
		if (g_pPRBlock->m_ACLineArray[i].fRtPi > -999990 && fMvaBase > FLT_MIN)
			fBuffer=100*(1.0-fabs(fabs(g_pPRBlock->m_ACLineArray[i].fRtPi)-fabs(g_pPRBlock->m_ACLineArray[i].fPfPi))/fMvaBase);
		sprintf(szBuf,"%.2f",fBuffer);							m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_ACLineArray[i].nIsland);	m_wndListFlowLine.SetItemText(nRow, nCol++, szBuf);

		nLineNum++;
		nRow++;
	}

	nRow=0;
	for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_WIND]; i++)
	{
		if (nRadial == 0)
		{
			if (g_pPRBlock->m_WindArray[i].nIRadial != 0 || g_pPRBlock->m_WindArray[i].nZRadial != 0)
				continue;
			if (nIsland > 0)
			{
				if (g_pPRBlock->m_WindArray[i].nIsland != nIsland)
					continue;
			}
		}
		else
		{
			if (g_pPRBlock->m_WindArray[i].nIRadial != nRadial && g_pPRBlock->m_WindArray[i].nZRadial != nRadial)
				continue;
		}

		fPfRate=0;
		if (g_pPRBlock->m_WindArray[i].fRated > FLT_MIN)
			fPfRate=g_PRAdeSetting.fDc2AcFactor*fabs(g_pPRBlock->m_WindArray[i].fPfPi)/g_pPRBlock->m_WindArray[i].fRated;

		fVoltage=max(g_pBpaBlock->m_BpaDat_WindArray[g_pPRBlock->m_WindArray[i].nIndex].fkVI, g_pBpaBlock->m_BpaDat_WindArray[g_pPRBlock->m_WindArray[i].nIndex].fkVJ);
		if (fVoltage < 100)
		{
			if (!((CButton*)GetDlgItem(IDC_35kV))->GetCheck())	continue;
		}
		else if (100 <= fVoltage && fVoltage < 200)
		{
			if (!((CButton*)GetDlgItem(IDC_110kV))->GetCheck())	continue;
		}
		else if (200 <= fVoltage && fVoltage < 300)
		{
			if (!((CButton*)GetDlgItem(IDC_220kV))->GetCheck())	continue;
		}
		else if (300 <= fVoltage && fVoltage < 450)
		{
			if (!((CButton*)GetDlgItem(IDC_330kV))->GetCheck())	continue;
		}
		else if (450 <= fVoltage && fVoltage < 600)
		{
			if (!((CButton*)GetDlgItem(IDC_500kV))->GetCheck())	continue;
		}
		else if (600 <= fVoltage && fVoltage < 900)
		{
			if (!((CButton*)GetDlgItem(IDC_750kV))->GetCheck())	continue;
		}
		else
		{
			if (!((CButton*)GetDlgItem(IDC_1000kV))->GetCheck())	continue;
		}

		if (((CButton*)GetDlgItem(IDC_OVERLIMIT))->GetCheck())
		{
			if (fPfRate <= 1)
				continue;
		}

		m_wndListFlowTran.InsertItem(nRow, g_pPRBlock->m_WindArray[i].szName);	m_wndListFlowTran.SetItemData(nRow, nRow);

		nCol=1;

		sprintf(szBuf,"%g",g_pPRBlock->m_WindArray[i].fkVI);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_WindArray[i].fkVJ);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_WindArray[i].nIBus);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_WindArray[i].nZBus);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_WindArray[i].fR);			m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_WindArray[i].fX);			m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%g",g_pPRBlock->m_WindArray[i].fRated);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%.1f",g_pPRBlock->m_WindArray[i].fRtPi);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%.1f",g_pPRBlock->m_WindArray[i].fRtPz);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%.1f",g_pPRBlock->m_WindArray[i].fPfPi);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%.1f",g_pPRBlock->m_WindArray[i].fPfPz);		m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf,"%.2f",fPfRate);								m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);

		fMvaBase=g_fDCNMvaBase_220;
		if (fVoltage < 150)
			fMvaBase=g_fDCNMvaBase_110;
		else if (150 <= fVoltage && fVoltage < 250)
			fMvaBase=g_fDCNMvaBase_220;
		else if (250 <= fVoltage && fVoltage < 350)
			fMvaBase=g_fDCNMvaBase_330;
		else
			fMvaBase=g_fDCNMvaBase_500;
		fBuffer=100;
		if (g_pPRBlock->m_WindArray[i].fRtPi > -999990 && fMvaBase > FLT_MIN)
			fBuffer=100*(1.0-fabs(fabs(g_pPRBlock->m_WindArray[i].fRtPi)-fabs(g_pPRBlock->m_WindArray[i].fPfPi))/fMvaBase);
		sprintf(szBuf,"%.2f",fBuffer);							m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%d",g_pPRBlock->m_WindArray[i].nIsland);	m_wndListFlowTran.SetItemText(nRow, nCol++, szBuf);

		nTranNum++;
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDCFlowBranColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListFlowLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListFlowLine.GetColumnWidth(nCol);
		m_wndListFlowLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListFlowLine.GetColumnWidth(nCol);

		m_wndListFlowLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
	for (nCol=0; nCol<sizeof(lpszDCFlowBranColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListFlowTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListFlowTran.GetColumnWidth(nCol);
		m_wndListFlowTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListFlowTran.GetColumnWidth(nCol);

		m_wndListFlowTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaDCFlowDialog::OnBnClickedDCFlow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;
	char	szBuf[260];

	dBeg=clock();

	register int	i;
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DCFLOW_TYPE_COMBO);
	int			nRadial=pComboBox->GetCurSel();
	if (nRadial == CB_ERR)
		nRadial=0;

	BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.bGenBusLoadAsAux);
	//g_pPRBlock->m_ACLineArray[130].bOutage = 1;
	if (!g_PRAdeSetting.strBpaRParamFile.empty())
		g_BpaPRParam.ReadBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("ReadBpaData��ϣ���ʱ%d����\n",nDur);

	pComboBox=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");

	//g_PReliable.CalculateBusPQ();
	DCNetwork::CDCNetwork*	pDCNetwork=new DCNetwork::CDCNetwork();
	if (nRadial == 0)
	{
		double	fSign;

		if (((CButton*)GetDlgItem(IDC_UPFC_CONTROL))->GetCheck())
		{
			pDCNetwork->PRDCFlow(g_pPRBlock, UPFC_MODE_NO);
			for (int nUpfc=0; nUpfc<g_pPRBlock->m_nRecordNum[PR_UPFC]; nUpfc++)
			{
				if (g_pPRBlock->m_UPFCArray[nUpfc].nACLine < 0)
					continue;
				if (g_pPRBlock->m_UPFCArray[nUpfc].bOutage)
					continue;
				if (g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].bOutage)
					continue;

				g_pPRBlock->m_UPFCArray[nUpfc].fPControl=0;
				g_pPRBlock->m_UPFCArray[nUpfc].fLinePse=0;

				if (g_pPRBlock->m_UPFCArray[nUpfc].nSeriesBus == g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].nIBus)	//	��·I���Ǵ�����
					g_pPRBlock->m_UPFCArray[nUpfc].fLinePse = -g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi;
				else
					g_pPRBlock->m_UPFCArray[nUpfc].fLinePse =  g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi;

				fSign = (fabs(g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi) > FLT_MIN) ? g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi/fabs(g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi) : 1;
				g_pPRBlock->m_UPFCArray[nUpfc].fPControl = (fabs(g_PRAdeSetting.fDc2AcFactor*g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi) > g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fRated) ?
					fSign*(fabs(g_PRAdeSetting.fDc2AcFactor*g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi)-g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fRated) : 0;

				::PrintMessage("    ��%s��UPFC״̬��ʼ�� PFlow=%f Rated=%f PControl=%f",
					g_pPRBlock->m_UPFCArray[nUpfc].szName,
					g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi*g_PRAdeSetting.fDc2AcFactor,
					g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fRated, g_pPRBlock->m_UPFCArray[nUpfc].fPControl);

				if (fabs(g_pPRBlock->m_UPFCArray[nUpfc].fPControl) > g_pPRBlock->m_UPFCArray[nUpfc].fCapacity)
				{
					Log(g_lpszLogFile, "        UPFCInitial    ��UPFC��·�ж�Խ�� = %s UPFC Pi=%f Rated=%f Capacity=%f\n", g_pPRBlock->m_UPFCArray[nUpfc].szName,
						g_PRAdeSetting.fDc2AcFactor*g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fPfPi, g_pPRBlock->m_ACLineArray[g_pPRBlock->m_UPFCArray[nUpfc].nACLine].fRated, g_pPRBlock->m_UPFCArray[nUpfc].fCapacity);

					g_pPRBlock->m_UPFCArray[nUpfc].fPControl = fSign*g_pPRBlock->m_UPFCArray[nUpfc].fCapacity;
				}
			}
			pDCNetwork->PRDCFlow(g_pPRBlock, UPFC_MODE_UPFC);
		}
		else
		{
			pDCNetwork->PRDCFlow(g_pPRBlock, UPFC_MODE_NO);
			//pDCNetwork->PRDCFlow(g_pPRBlock, UPFC_MODE_NO);
		}

		for (i=1; i<g_pPRBlock->m_nRecordNum[PR_ACISLAND]; i++)
		{
			sprintf(szBuf, "%d", i);
			pComboBox->AddString(szBuf);
		}
	}
	else
	{
		pDCNetwork->PRDCFlow(g_pPRBlock, UPFC_MODE_NO, nRadial);
	}
	delete pDCNetwork;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	PrintMessage("DC����������ϣ���ʱ%d����\n",nDur);
	RefreshDCFlowBusList(nRadial);
	RefreshDCFlowBranList(nRadial);
}

void CBpaDCFlowDialog::OnBnClickedShowFilter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDCFlowBusList();
	RefreshDCFlowBranList();
}

void CBpaDCFlowDialog::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;

	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;
	if (m_wndListFlowBus.GetItemCount() > 0)
	{
		xls.AddSheet(_T("ֱ������ĸ��"));
		xls.SetCurSheet(_T("ֱ������ĸ��"));
		nFieldNum=sizeof(lpszDCFlowBusColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszDCFlowBusColumn[nCol]));
		for (nRow=0; nRow<m_wndListFlowBus.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListFlowBus.GetItemText(nRow, nCol));
		}
	}

	if (m_wndListFlowLine.GetItemCount() > 0)
	{
		xls.AddSheet(_T("ֱ��������·"));
		xls.SetCurSheet(_T("ֱ��������·"));
		nFieldNum=sizeof(lpszDCFlowBranColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszDCFlowBranColumn[nCol]));
		for (nRow=0; nRow<m_wndListFlowLine.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListFlowLine.GetItemText(nRow, nCol));
		}
	}

	if (m_wndListFlowTran.GetItemCount() > 0)
	{
		xls.AddSheet(_T("ֱ��������ѹ��"));
		xls.SetCurSheet(_T("ֱ��������ѹ��"));
		nFieldNum=sizeof(lpszDCFlowBranColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszDCFlowBranColumn[nCol]));
		for (nRow=0; nRow<m_wndListFlowTran.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListFlowTran.GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));
}
