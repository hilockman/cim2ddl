// BpaRingRadDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaRingRadDialog.h"
#include "../../../../../Common/Excel/ExcelAccessor.h"

// CBpaRingRadDialog �Ի���
#define	IDC_RINGRAD_LISTRING	20001
#define	IDC_RINGRAD_LISTBOUND	20002
#define	IDC_RINGRAD_LISTRAD		20003

static	char*	lpszRingColumn[]={
	"���",
	"����",
	"����Ϣ",
	"����Ϣ",
};
static	char*	lpszBoundColumn[]={
	"���",
	"����",
	"����",
	"����Ϣ",
	"����Ϣ",
	"�й�",
	"�޹�",
};

static	char*	lpszRadiateColumn[]={
	"���",
	"�豸����",
	"��ڵ�",
	"�սڵ�",
};

IMPLEMENT_DYNAMIC(CBpaRingRadDialog, CDialog)

CBpaRingRadDialog::CBpaRingRadDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaRingRadDialog::IDD, pParent)
{

}

CBpaRingRadDialog::~CBpaRingRadDialog()
{
}

void CBpaRingRadDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaRingRadDialog, CDialog)
	ON_BN_CLICKED(IDC_DECOMPOSE, &CBpaRingRadDialog::OnBnClickedDecompose)
	ON_BN_CLICKED(IDC_ERASE_RADIATE, &CBpaRingRadDialog::OnBnClickedEraseRadiate)
	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CBpaRingRadDialog::OnBnClickedSaveasExcel)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CBpaRingRadDialog ��Ϣ��������

BOOL CBpaRingRadDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CRect	rectDummy;
	int		nColumn;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListRingDev.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_RINGRAD_LISTRING))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRingDev.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRingDev.SetExtendedStyle(m_wndListRingDev.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRingDev.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRingColumn)/sizeof(char*); nColumn++)
		m_wndListRingDev.InsertColumn(nColumn, lpszRingColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBoundDev.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_RINGRAD_LISTBOUND))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBoundDev.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBoundDev.SetExtendedStyle(m_wndListBoundDev.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBoundDev.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszBoundColumn)/sizeof(char*); nColumn++)
		m_wndListBoundDev.InsertColumn(nColumn, lpszBoundColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListRadiate.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT, rectDummy, &m_wndTab, IDC_RINGRAD_LISTRAD))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRadiate.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRadiate.SetExtendedStyle(m_wndListRadiate.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRadiate.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRadiateColumn)/sizeof(char*); nColumn++)
		m_wndListRadiate.InsertColumn(nColumn, lpszRadiateColumn[nColumn],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndListRingDev,			_T("�����豸"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListBoundDev,		_T("�߽��豸"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListRadiate,			_T("������"),			-1, FALSE);

	GetDlgItem(IDC_TINYGEN_THRESHOLD)->SetWindowText("0");
	GetDlgItem(IDC_LOWVOLT_THRESHOLD)->SetWindowText("10");

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaRingRadDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

void CBpaRingRadDialog::RefreshRingRadList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];
	int		nGroup;
	int	nColWidth,nHeaderWidth;

	m_wndListRingDev.DeleteAllItems();
	m_wndListBoundDev.DeleteAllItems();
	m_wndListRadiate.DeleteAllItems();

	//////////////////////////////////////////////////////////////////////////
	//	�����豸
	nRow=0;
	for (i=0; i<(int)g_pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
	{
		if (!g_pBpaBlock->m_BpaDat_ACBusArray[i].bInRing)
			continue;

		sprintf(szBuf,"%d",nRow+1);	m_wndListRingDev.InsertItem(nRow, szBuf);		m_wndListRingDev.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListRingDev.SetItemText(nRow, nCol++, g_BpaMemDBInterface.BpaGetTableDesp(BPA_DAT_ACBUS));
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACBusArray[i].szName, g_pBpaBlock->m_BpaDat_ACBusArray[i].fkV);	m_wndListRingDev.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	for (i=0; i<(int)g_pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
	{
		if (!g_pBpaBlock->m_BpaDat_ACLineArray[i].bInRing)
			continue;

		sprintf(szBuf,"%d",nRow+1);	m_wndListRingDev.InsertItem(nRow, szBuf);		m_wndListRingDev.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListRingDev.SetItemText(nRow, nCol++, g_BpaMemDBInterface.BpaGetTableDesp(BPA_DAT_ACLINE));
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACLineArray[i].szBusI, g_pBpaBlock->m_BpaDat_ACLineArray[i].fkVI);	m_wndListRingDev.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACLineArray[i].szBusJ, g_pBpaBlock->m_BpaDat_ACLineArray[i].fkVJ);	m_wndListRingDev.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}
	for (i=0; i<(int)g_pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
	{
		if (!g_pBpaBlock->m_BpaDat_WindArray[i].bInRing)
			continue;

		sprintf(szBuf,"%d",nRow+1);	m_wndListRingDev.InsertItem(nRow, szBuf);		m_wndListRingDev.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListRingDev.SetItemText(nRow, nCol++, g_BpaMemDBInterface.BpaGetTableDesp(BPA_DAT_WIND));
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_WindArray[i].szBusI, g_pBpaBlock->m_BpaDat_WindArray[i].fkVI);	m_wndListRingDev.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_WindArray[i].szBusJ, g_pBpaBlock->m_BpaDat_WindArray[i].fkVJ);	m_wndListRingDev.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	//////////////////////////////////////////////////////////////////////////
	//	�߽��豸
	nRow=0;
	for (i=0; i<g_pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
	{
		if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[i].nIBus].bInRing != g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[i].nZBus].bInRing)
		{
			sprintf(szBuf,"%d",nRow+1);	m_wndListBoundDev.InsertItem(nRow, szBuf);		m_wndListBoundDev.SetItemData(nRow, nRow);

			nCol=1;
			m_wndListBoundDev.SetItemText(nRow, nCol++, g_BpaMemDBInterface.BpaGetTableDesp(BPA_DAT_ACLINE));
			m_wndListBoundDev.SetItemText(nRow, nCol++, g_pBpaBlock->m_BpaDat_ACLineArray[i].szKeyName);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACLineArray[i].szBusI, g_pBpaBlock->m_BpaDat_ACLineArray[i].fkVI);	m_wndListBoundDev.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACLineArray[i].szBusJ, g_pBpaBlock->m_BpaDat_ACLineArray[i].fkVJ);	m_wndListBoundDev.SetItemText(nRow, nCol++, szBuf);

			if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[i].nIBus].bInRing)
			{
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_ACLineArray[i].fPi);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_ACLineArray[i].fQi);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
			}
			else
			{
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_ACLineArray[i].fPz);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_ACLineArray[i].fQz);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
			}

			nRow++;
		}
	}
	for (i=0; i<g_pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
	{
		if (g_pBpaBlock->m_BpaDat_WindArray[i].bRCard)
			continue;

		if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[i].nIBus].bInRing != g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[i].nZBus].bInRing)
		{
			sprintf(szBuf,"%d",nRow+1);	m_wndListBoundDev.InsertItem(nRow, szBuf);		m_wndListBoundDev.SetItemData(nRow, nRow);

			nCol=1;
			m_wndListBoundDev.SetItemText(nRow, nCol++, g_BpaMemDBInterface.BpaGetTableDesp(BPA_DAT_WIND));
			m_wndListBoundDev.SetItemText(nRow, nCol++,	g_pBpaBlock->m_BpaDat_WindArray[i].szKeyName);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_WindArray[i].szBusI, g_pBpaBlock->m_BpaDat_WindArray[i].fkVI);	m_wndListBoundDev.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_WindArray[i].szBusJ, g_pBpaBlock->m_BpaDat_WindArray[i].fkVJ);	m_wndListBoundDev.SetItemText(nRow, nCol++, szBuf);

			if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[i].nIBus].bInRing)
			{
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_WindArray[i].fPi);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_WindArray[i].fQi);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
			}
			else
			{
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_WindArray[i].fPz);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
				sprintf(szBuf,"%g", g_pBpaBlock->m_BpaDat_WindArray[i].fQz);	m_wndListBoundDev.SetItemText(nRow, nCol++,	szBuf);
			}

			nRow++;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	������
	nRow=0;
	for (nGroup=0; nGroup<g_pBpaBlock->m_nRecordNum[BPA_DAT_RADIATE]; nGroup++)
	{
		sprintf(szBuf,"%d (BoundBus=%s[%g] GenP=%g LoadP=%g)", nGroup+1,
			g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_RadiateArray[nGroup].nBoundBus].szName,
			g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_RadiateArray[nGroup].nBoundBus].fkV,
			g_pBpaBlock->m_BpaDat_RadiateArray[nGroup].fGenP,
			g_pBpaBlock->m_BpaDat_RadiateArray[nGroup].fLoadP);
		m_wndListRadiate.InsertItem(nRow++, szBuf);		m_wndListRadiate.SetItemData(nRow, nRow);

		for (i=0; i<g_pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (g_pBpaBlock->m_BpaDat_ACBusArray[i].nRadiate != nGroup)
				continue;

			m_wndListRadiate.InsertItem(nRow, "");	m_wndListRadiate.SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf,"ĸ��[%d]=%s", i+1, g_pBpaBlock->m_BpaDat_ACBusArray[i].szName);									m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACBusArray[i].szName, g_pBpaBlock->m_BpaDat_ACBusArray[i].fkV);	m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}
		for (i=0; i<(int)g_pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
		{
			if (g_pBpaBlock->m_BpaDat_ACLineArray[i].nRadiate != nGroup)
				continue;

			m_wndListRadiate.InsertItem(nRow, "");	m_wndListRadiate.SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf,"��·[%d]=%s", i+1, g_pBpaBlock->m_BpaDat_ACLineArray[i].szKeyName);									m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACLineArray[i].szBusI, g_pBpaBlock->m_BpaDat_ACLineArray[i].fkVI);	m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_ACLineArray[i].szBusJ, g_pBpaBlock->m_BpaDat_ACLineArray[i].fkVJ);	m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}
		for (i=0; i<g_pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
		{
			if (g_pBpaBlock->m_BpaDat_WindArray[i].nRadiate != nGroup)
				continue;

			m_wndListRadiate.InsertItem(nRow, "");	m_wndListRadiate.SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf,"��ѹ��[%d]=%s", i+1, g_pBpaBlock->m_BpaDat_WindArray[i].szKeyName);								m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_WindArray[i].szBusI, g_pBpaBlock->m_BpaDat_WindArray[i].fkVI);	m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%s[%g]", g_pBpaBlock->m_BpaDat_WindArray[i].szBusJ, g_pBpaBlock->m_BpaDat_WindArray[i].fkVJ);	m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}
	}

	for (nCol=0; nCol<sizeof(lpszRingColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRingDev.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRingDev.GetColumnWidth(nCol);
		m_wndListRingDev.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRingDev.GetColumnWidth(nCol);

		m_wndListRingDev.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	for (nCol=0; nCol<sizeof(lpszBoundColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBoundDev.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBoundDev.GetColumnWidth(nCol);
		m_wndListBoundDev.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBoundDev.GetColumnWidth(nCol);

		m_wndListBoundDev.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	for (nCol=0; nCol<6; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRadiate.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRadiate.GetColumnWidth(nCol);
		m_wndListRadiate.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRadiate.GetColumnWidth(nCol);

		m_wndListRadiate.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaRingRadDialog::OnBnClickedDecompose()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	char	szBuf[260];
	double	fTinyGenThreshold, fLowVoltThreshold;

	dBeg=clock();

	GetDlgItem(IDC_TINYGEN_THRESHOLD)->GetWindowText(szBuf, 260);	fTinyGenThreshold = atof(szBuf);
	GetDlgItem(IDC_LOWVOLT_THRESHOLD)->GetWindowText(szBuf, 260);	fLowVoltThreshold = atof(szBuf);

	g_BpaMemDBInterface.BpaRingRadDecompose(g_pBpaBlock, fLowVoltThreshold, fTinyGenThreshold);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("����������ɣ���ʱ %d ����", nDur);

	RefreshRingRadList();
}

void CBpaRingRadDialog::OnBnClickedEraseRadiate()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	int		nDev;
	for (nDev=0; nDev<g_pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nDev++)
	{
		if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nIBus].bInRing != g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nZBus].bInRing)
		{
			if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nIBus].bInRing)
			{
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nIBus].fLoadP += g_pBpaBlock->m_BpaDat_ACLineArray[nDev].fPi;
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nIBus].fLoadQ += g_pBpaBlock->m_BpaDat_ACLineArray[nDev].fQi;
			}
			else
			{
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nZBus].fLoadP += g_pBpaBlock->m_BpaDat_ACLineArray[nDev].fPz;
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_ACLineArray[nDev].nZBus].fLoadQ += g_pBpaBlock->m_BpaDat_ACLineArray[nDev].fQz;
			}
		}
	}

	for (nDev=0; nDev<g_pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nDev++)
	{
		if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nIBus].bInRing != g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nZBus].bInRing)
		{
			if (g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nIBus].bInRing)
			{
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nIBus].fLoadP += g_pBpaBlock->m_BpaDat_WindArray[nDev].fPi;
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nIBus].fLoadQ += g_pBpaBlock->m_BpaDat_WindArray[nDev].fQi;
			}
			else
			{
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nZBus].fLoadP += g_pBpaBlock->m_BpaDat_WindArray[nDev].fPz;
				g_pBpaBlock->m_BpaDat_ACBusArray[g_pBpaBlock->m_BpaDat_WindArray[nDev].nZBus].fLoadQ += g_pBpaBlock->m_BpaDat_WindArray[nDev].fQz;
			}
		}
	}

	//	for (nDev=0; nDev<(int)m_RadiateArray.size(); nDev++)
	//	{
	//		g_pBpaBlock->m_BpaDat_ACBusArray[m_RadiateArray[nDev].nBoundBus].fLoadP += m_RadiateArray[nDev].fLoadP;
	//		g_pBpaBlock->m_BpaDat_ACBusArray[m_RadiateArray[nDev].nBoundBus].fLoadQ += m_RadiateArray[nDev].fLoadQ;
	//	}

	nDev=0;
	while (nDev < g_pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS])
	{
		if (!g_pBpaBlock->m_BpaDat_ACBusArray[nDev].bInRing)
			g_BpaMemDBInterface.BpaRemoveRecord(g_pBpaBlock, BPA_DAT_ACBUS, nDev);
		else
			nDev++;
	}

	nDev=0;
	while (nDev < g_pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE])
	{
		if (!g_pBpaBlock->m_BpaDat_ACLineArray[nDev].bInRing)
			g_BpaMemDBInterface.BpaRemoveRecord(g_pBpaBlock, BPA_DAT_ACLINE, nDev);
		else
			nDev++;
	}

	nDev=0;
	while (nDev < g_pBpaBlock->m_nRecordNum[BPA_DAT_WIND])
	{
		if (!g_pBpaBlock->m_BpaDat_WindArray[nDev].bInRing)
			g_BpaMemDBInterface.BpaRemoveRecord(g_pBpaBlock, BPA_DAT_WIND, nDev);
		else
			nDev++;
	}

	nDev=0;
	while (nDev < g_pBpaBlock->m_nRecordNum[BPA_DAT_LINEHG])
	{
		if (!g_pBpaBlock->m_BpaDat_LineHGArray[nDev].bInRing)
			g_BpaMemDBInterface.BpaRemoveRecord(g_pBpaBlock, BPA_DAT_LINEHG, nDev);
		else
			nDev++;
	}

	g_BpaMemDBInterface.BpaMaint(g_pBpaBlock, g_PRAdeSetting.fZIL);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("���ݿ������ɣ���ʱ %d ����", nDur);
}

void CBpaRingRadDialog::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;

	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;
	if (m_wndListRingDev.GetItemCount() > 0)
	{
		xls.AddSheet(_T("�ɻ��豸"));
		xls.SetCurSheet(_T("�ɻ��豸"));

		nFieldNum=sizeof(lpszRingColumn)/sizeof(char*);
		//xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszRingColumn[nCol]));
		for (nRow=0; nRow<m_wndListRingDev.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListRingDev.GetItemText(nRow, nCol));
		}
	}

	if (m_wndListRadiate.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������"));
		xls.SetCurSheet(_T("������"));
		nFieldNum=sizeof(lpszRadiateColumn)/sizeof(char*);

		//xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszRadiateColumn[nCol]));
		for (nRow=0; nRow<m_wndListRadiate.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListRadiate.GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));
}
