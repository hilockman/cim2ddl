// BpaPRParamTCSCDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaPRParamTCSCDialog.h"

// CBpaPRParamTCSCDialog �Ի���
const	int		m_nConstLineColumn = 1;
static	char*	lpszACLineColumn[]=
{
	"���",
	"��·����",
	"X(pu)",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
	"TCSC�翹(pu)",
	"��װĸ��",
};

IMPLEMENT_DYNAMIC(CBpaPRParamTCSCDialog, CDialog)

CBpaPRParamTCSCDialog::CBpaPRParamTCSCDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamTCSCDialog::IDD, pParent)
{

}

CBpaPRParamTCSCDialog::~CBpaPRParamTCSCDialog()
{
}

void CBpaPRParamTCSCDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaPRParamTCSCDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD_TCSC, &CBpaPRParamTCSCDialog::OnBnClickedAddTcsc)
	ON_BN_CLICKED(IDC_DEL_TCSC, &CBpaPRParamTCSCDialog::OnBnClickedDelTcsc)
	ON_NOTIFY(NM_CLICK, IDC_ACLINE_LIST, &CBpaPRParamTCSCDialog::OnNMClickAclineList)
	ON_BN_CLICKED(IDC_SEARCH, &CBpaPRParamTCSCDialog::OnBnClickedSearch)
	ON_BN_CLICKED(IDC_SHOW_LINEHASTCSC, &CBpaPRParamTCSCDialog::OnBnClickedShowLinehastcsc)
END_MESSAGE_MAP()


// CBpaPRParamTCSCDialog ��Ϣ��������

BOOL CBpaPRParamTCSCDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszACLineColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszACLineColumn[i],	LVCFMT_LEFT,	60);

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_INSTBUS_COMBO);
	pComboBox->ResetContent();

	RefreshACLineList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamTCSCDialog::RefreshACLineList()
{
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);

	register int	i;
	int		nDev, nRow, nCol, nDevice;
	char	szBuf[260];
	unsigned char	bShowHasTcscOnly = ((CButton*)GetDlgItem(IDC_SHOW_LINEHASTCSC))->GetCheck();

	int			nSelItem=-1;
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=pListCtrl->GetNextSelectedItem(pos);

	pListCtrl->DeleteAllItems();


	nRow=0;
	for (nDev=0; nDev<(int)g_pPRBlock->m_nRecordNum[PR_ACLINE]; nDev++)
	{
		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
		{
			if (stricmp(g_pPRBlock->m_TCSCArray[i].szName, g_pPRBlock->m_ACLineArray[nDev].szName) == 0)
			{
				nDevice = i;
				break;
			}
		}
		if (bShowHasTcscOnly)
		{
			if (nDevice < 0)
				continue;
		}
		sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_ACLineArray[nDev].szName);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[nDev].fX);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		if (nDevice >= 0)
		{
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[nDevice].fRerr);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[nDevice].fTrep);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[nDevice].fX);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_TCSCArray[nDevice].szInstBus);
		}
		else
		{
			nCol++;
			nCol++;
			nCol++;
			nCol++;
		}

		nRow++;
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszACLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		pListCtrl->SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamTCSCDialog::OnBnClickedAddTcsc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDevice;
	double	fRerr, fTrep, fX;
	char	szInstBus[MDB_CHARLEN_SHORT], szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_INSTBUS_COMBO);

	GetDlgItem(IDC_TCSC_RERR)->		GetWindowText(szBuf, 260);	fRerr = atof(szBuf);
	GetDlgItem(IDC_TCSC_TREP)->		GetWindowText(szBuf, 260);	fTrep = atof(szBuf);
	GetDlgItem(IDC_TCSC_X)->		GetWindowText(szBuf, 260);	fX = atof(szBuf);

	memset(szInstBus, 0, MDB_CHARLEN_SHORT);
	nDevice = pComboBox->GetCurSel();
	if (nDevice != CB_ERR)
		pComboBox->GetLBText(nDevice, szInstBus);
	else
	{
		AfxMessageBox("��ȷ��TCSC��װĸ��");
		return;
	}

	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);
		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
		{
			if (stricmp(g_pPRBlock->m_TCSCArray[i].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn)) == 0)
			{
				nDevice = i;
				break;
			}
		}
		if (nDevice >= 0)
		{
			g_pPRBlock->m_TCSCArray[nDevice].fRerr = fRerr;
			g_pPRBlock->m_TCSCArray[nDevice].fTrep = fTrep;
			g_pPRBlock->m_TCSCArray[nDevice].fX = (float)fX;
			strcpy(g_pPRBlock->m_TCSCArray[nDevice].szInstBus, szInstBus);
		}
		else
		{
			if (g_pPRBlock->m_nRecordNum[PR_TCSC] < g_PRMemDBInterface.PRGetTableMax(PR_TCSC)-1)
			{
				memset(&g_pPRBlock->m_TCSCArray[g_pPRBlock->m_nRecordNum[PR_TCSC]], 0, sizeof(tagPRTCSC));
				strcpy(g_pPRBlock->m_TCSCArray[g_pPRBlock->m_nRecordNum[PR_TCSC]].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn));
				g_pPRBlock->m_TCSCArray[g_pPRBlock->m_nRecordNum[PR_TCSC]].fRerr = fRerr;
				g_pPRBlock->m_TCSCArray[g_pPRBlock->m_nRecordNum[PR_TCSC]].fTrep = fTrep;
				g_pPRBlock->m_TCSCArray[g_pPRBlock->m_nRecordNum[PR_TCSC]].fX = (float)fX;
				strcpy(g_pPRBlock->m_TCSCArray[g_pPRBlock->m_nRecordNum[PR_TCSC]].szInstBus, szInstBus);
				g_pPRBlock->m_nRecordNum[PR_TCSC]++;
			}
			else
				Log(g_lpszLogFile, "        ********** %s ���ݿⳬ��\n", g_PRMemDBInterface.PRGetTableDesp(PR_TCSC));
		}
	}

	RefreshACLineList();
}

void CBpaPRParamTCSCDialog::OnBnClickedDelTcsc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDevice;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nSelItem=pListCtrl->GetNextSelectedItem(pos);

		nDevice = -1;
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
		{
			if (stricmp(g_pPRBlock->m_TCSCArray[i].szName, pListCtrl->GetItemText(nSelItem, m_nConstLineColumn)) == 0)
			{
				nDevice = i;
				break;
			}
		}

		if (nDevice >= 0)
			g_PRMemDBInterface.PRRemoveRecord(g_pPRBlock, PR_TCSC, nDevice);
	}
	RefreshACLineList();
}

void CBpaPRParamTCSCDialog::OnNMClickAclineList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_INSTBUS_COMBO);
	pComboBox->ResetContent();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	POSITION pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);
		register int	i;
		int		nACLine = -1;
		char	szBuf[260];
		for (i=0; i<g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
		{
			if (stricmp(g_pPRBlock->m_ACLineArray[i].szName, pListCtrl->GetItemText(nItem, m_nConstLineColumn)) == 0)
			{
				nACLine = i;
				break;

			}
		}
		if (nACLine >= 0)
		{
			sprintf(szBuf, "%s%g", g_pPRBlock->m_ACLineArray[nACLine].szBusI, g_pPRBlock->m_ACLineArray[nACLine].fkVI);	pComboBox->AddString(szBuf);
			sprintf(szBuf, "%s%g", g_pPRBlock->m_ACLineArray[nACLine].szBusJ, g_pPRBlock->m_ACLineArray[nACLine].fkVJ);	pComboBox->AddString(szBuf);
		}

		int	nCol=3;
		if (strlen(pListCtrl->GetItemText(nItem, nCol)) > 0)
		{
			GetDlgItem(IDC_TCSC_RERR)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
			GetDlgItem(IDC_TCSC_TREP)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
			GetDlgItem(IDC_TCSC_X)->	SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
		}
	}
	*pResult = 0;
}

void CBpaPRParamTCSCDialog::OnBnClickedSearch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nSelectItem, nStartItem = 0;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ACLINE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	nStartItem = 0;
	if (pos)
		nStartItem=pListCtrl->GetNextSelectedItem(pos);

	char	szSearch[260];
	GetDlgItem(IDC_SEARCH_STRING)->GetWindowText(szSearch, 260);

	nSelectItem = -1;
	for (i=nStartItem+1; i<pListCtrl->GetItemCount(); i++)
	{
		if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
		{
			nSelectItem = i;
			break;
		}
	}
	if (nSelectItem < 0 && nStartItem > 0)
	{
		for (i=0; i<nStartItem; i++)
		{
			if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
			{
				nSelectItem = i;
				break;
			}
		}
	}
	if (nSelectItem >= 0)
	{
		pListCtrl->SetItemState(nSelectItem,LVIS_SELECTED, 0xffff);
		pListCtrl->EnsureVisible(nSelectItem, FALSE);
	}
}

void CBpaPRParamTCSCDialog::OnBnClickedShowLinehastcsc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshACLineList();
}
