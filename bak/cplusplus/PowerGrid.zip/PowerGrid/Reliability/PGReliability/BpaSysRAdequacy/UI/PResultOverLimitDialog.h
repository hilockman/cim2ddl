#pragma once
#include "../../../../../Common/Excel/ExcelAccessor.h"

// CPResultOverLimitDialog �Ի���

class CPResultOverLimitDialog : public CDialog
{
	DECLARE_DYNAMIC(CPResultOverLimitDialog)

public:
	CPResultOverLimitDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPResultOverLimitDialog();

	void	RefreshUI();

// �Ի�������
	enum { IDD = IDD_PRESULT_OVERLIMIT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedShowHasvalueOnly();
	afx_msg void OnBnClickedDetail();

	DECLARE_MESSAGE_MAP()

private:
	void	RefreshPROvlDeviceList();

public:
	void	ExcelOut(ExcelAccessor* pXls);
};
