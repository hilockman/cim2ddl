#pragma once


// CBpaRingRadDialog �Ի���

class CBpaRingRadDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaRingRadDialog)

public:
	CBpaRingRadDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaRingRadDialog();

// �Ի�������
	enum { IDD = IDD_BPA_RINGRAD_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedDecompose();
	afx_msg void OnBnClickedEraseRadiate();

	afx_msg void OnBnClickedSaveasExcel();
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndListRingDev,m_wndListBoundDev, m_wndListRadiate;

private:
	void	RefreshRingRadList();
public:
};
