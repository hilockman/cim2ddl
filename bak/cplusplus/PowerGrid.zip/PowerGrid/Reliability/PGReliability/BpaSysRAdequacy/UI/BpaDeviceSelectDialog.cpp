// BpaDeviceSelectDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaSysRAdequacyUI.h"
#include "BpaDeviceSelectDialog.h"


// CBpaDeviceSelectDialog �Ի���
static	int		nSelectedDeviceType[] = 
{
	PR_GENERATOR,
	PR_POWERLOAD,
	PR_ACLINE,
	PR_WIND,
	PR_HVDC,
	PR_TCSC,
	PR_UPFC,
	PR_CONVERTER,
	PR_DCLINE,
};

static	char*	lpszGenLoadColumn[]=
{
	"���",
	"����",
	"ĸ��",
	"��ѹ",
	"����/����",
};
static	char*	lpszBranColumn[]=
{
	"���",
	"����",
	"ĸ��I",
	"��ѹI",
	"ĸ��J",
	"��ѹJ",
	"��·��",
};
static	char*	lpszDCColumn[]=
{
	"���",
	"����",
	"ĸ��I",
	"��ѹI",
	"ĸ��J",
	"��ѹJ",
};

IMPLEMENT_DYNAMIC(CBpaDeviceSelectDialog, CDialog)

CBpaDeviceSelectDialog::CBpaDeviceSelectDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaDeviceSelectDialog::IDD, pParent)
{
	m_nDevType=-1;
	m_strDevArray.clear();
}

CBpaDeviceSelectDialog::~CBpaDeviceSelectDialog()
{
}

void CBpaDeviceSelectDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBpaDeviceSelectDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CBpaDeviceSelectDialog::OnBnClickedOk)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CBpaDeviceSelectDialog::OnCbnSelchangeDevtypeCombo)
END_MESSAGE_MAP()


// CBpaDeviceSelectDialog ��Ϣ��������

BOOL CBpaDeviceSelectDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(nSelectedDeviceType)/sizeof(int); i++)
		pComboBox->AddString(g_PRMemDBInterface.PRGetTableDesp(nSelectedDeviceType[i]));
	pComboBox->SetCurSel(0);
	OnCbnSelchangeDevtypeCombo();

	RefreshDeviceList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaDeviceSelectDialog::RefreshDeviceList()
{
	register int	i;
	int			nCol;
	char		szBuf[260];
	int			nFieldNum, nColWidth,nHeaderWidth;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	nFieldNum=0;
	while (pListCtrl->DeleteColumn(0));
	pListCtrl->DeleteAllItems();

	switch (m_nDevType)
	{
	case	PR_GENERATOR:
		{
			nFieldNum=sizeof(lpszGenLoadColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszGenLoadColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_GENERATOR]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_GeneratorArray[i].szName);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_GeneratorArray[i].szBus);
				sprintf(szBuf, "%f", g_pPRBlock->m_GeneratorArray[i].fkV);	pListCtrl->SetItemText(i, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_GeneratorArray[i].fP);	pListCtrl->SetItemText(i, nCol++, szBuf);
			}

		}
		break;
	case	PR_POWERLOAD:
		{
			nFieldNum=sizeof(lpszGenLoadColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszGenLoadColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_POWERLOAD]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_PowerLoadArray[i].szName);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_PowerLoadArray[i].szBus);
				sprintf(szBuf, "%f", g_pPRBlock->m_PowerLoadArray[i].fkV);	pListCtrl->SetItemText(i, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPRBlock->m_PowerLoadArray[i].fP);	pListCtrl->SetItemText(i, nCol++, szBuf);
			}

		}
		break;
	case	PR_ACLINE:
		{
			nFieldNum=sizeof(lpszBranColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszBranColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_ACLineArray[i].szName);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_ACLineArray[i].szBusI);
				sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[i].fkVI);		pListCtrl->SetItemText(i, nCol++, szBuf);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_ACLineArray[i].szBusJ);
				sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[i].fkVJ);		pListCtrl->SetItemText(i, nCol++, szBuf);
				szBuf[0]=g_pPRBlock->m_ACLineArray[i].cLoop;	szBuf[1]='\0';	pListCtrl->SetItemText(i, nCol++, szBuf);
			}
		}
		break;
	case	PR_WIND:
		{
			nFieldNum=sizeof(lpszBranColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszBranColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_WIND]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_WindArray[i].szName);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_WindArray[i].szBusI);
				sprintf(szBuf, "%f", g_pPRBlock->m_WindArray[i].fkVI);		pListCtrl->SetItemText(i, nCol++, szBuf);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_WindArray[i].szBusJ);
				sprintf(szBuf, "%f", g_pPRBlock->m_WindArray[i].fkVJ);		pListCtrl->SetItemText(i, nCol++, szBuf);
				szBuf[0]=g_pPRBlock->m_WindArray[i].cLoop;	szBuf[1]='\0';	pListCtrl->SetItemText(i, nCol++, szBuf);
			}
		}
		break;
	case	PR_HVDC:
		{
			nFieldNum=sizeof(lpszDCColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszDCColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_HVDC]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_HVDCArray[i].szName);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_HVDCArray[i].szACBusR);
				sprintf(szBuf, "%f", g_pPRBlock->m_HVDCArray[i].fkVR);		pListCtrl->SetItemText(i, nCol++, szBuf);
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_HVDCArray[i].szACBusI);
				sprintf(szBuf, "%f", g_pPRBlock->m_HVDCArray[i].fkVI);		pListCtrl->SetItemText(i, nCol++, szBuf);
			}
		}
		break;
	case	PR_TCSC:
		{
			nFieldNum=sizeof(lpszDCColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszDCColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_TCSCArray[i].szName);
			}
		}
		break;
	case	PR_UPFC:
		{
			nFieldNum=sizeof(lpszDCColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszDCColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_UPFC]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_UPFCArray[i].szName);
			}
		}
		break;
	case	PR_CONVERTER:
		{
			nFieldNum=sizeof(lpszDCColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszDCColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_CONVERTER]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_ConverterArray[i].szName);
			}
		}
		break;
	case	PR_DCLINE:
		{
			nFieldNum=sizeof(lpszDCColumn)/sizeof(char*);
			for (i=0; i<nFieldNum; i++)
				pListCtrl->InsertColumn(i,	lpszDCColumn[i],	LVCFMT_LEFT,	60);

			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_DCLINE]; i++)
			{
				sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(i, szBuf);	pListCtrl->SetItemData(i, i);

				nCol=1;
				pListCtrl->SetItemText(i, nCol++, g_pPRBlock->m_DCLineArray[i].szName);
			}
		}
		break;
	}
	for (nCol=0; nCol<nFieldNum; nCol++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaDeviceSelectDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int			nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
	{
		AfxMessageBox("��ȷ���豸����");
		return;
	}
	m_nDevType = nSelectedDeviceType[nSel];

	m_strDevArray.clear();
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int		nItem=pListCtrl->GetNextSelectedItem(pos);
		m_strDevArray.push_back(pListCtrl->GetItemText(nItem, 1).GetBuffer());
	}
	if (m_strDevArray.empty())
	{
		AfxMessageBox("��ѡ���豸");
		return;
	}

	OnOK();
}

void CBpaDeviceSelectDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int			nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
		return;
	m_nDevType = nSelectedDeviceType[nSel];

	RefreshDeviceList();
}
