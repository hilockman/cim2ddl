#include <process.h>
#include <io.h>
#include <vector>
using namespace std;
#include <crtdbg.h>
#include <float.h>

#include "../../../../../MemDB/BpaMemDB/BpaMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../../lib/BpaMemDB.lib")
#	pragma message("Link LibX86 BpaMemDB.lib")
#else
#	pragma comment(lib, "../../../../../lib_x64/BpaMemDB.lib")
#	pragma message("Link LibX64 BpaMemDB.lib")
#endif
using	namespace	BpaMemDB;

#include "../../../../../MemDB/PRMemDB/PRMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../../lib/PRMemDB.lib")
#else
#	pragma comment(lib, "../../../../../lib_x64/PRMemDB.lib")
#endif
using	namespace	PRMemDB;

#include "../../../../DCNetwork/DCNetwork.h"
using	namespace	DCNetwork;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libDCNetworkMDd.lib")
#		pragma message("Link LibX86 DCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libDCNetworkMD.lib")
#		pragma message("Link LibX86 DCNetworkMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libDCNetworkMDd.lib")
#		pragma message("Link LibX64 DCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libDCNetworkMD.lib")
#		pragma message("Link LibX64 DCNetworkMD.lib")
#	endif
#endif

#include "../../PRAdequacyBase/PRAdequacyBase.h"
using	namespace	PRAdequacyBase;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libPRAdequacyBaseMDd.lib")
#		pragma message("Link LibX86 PRAdequacyBaseMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libPRAdequacyBaseMD.lib")
#		pragma message("Link LibX86 PRAdequacyBaseMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libPRAdequacyBaseMDd.lib")
#		pragma message("Link LibX64 PRAdequacyBaseMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libPRAdequacyBaseMD.lib")
#		pragma message("Link LibX64 PRAdequacyBaseMD.lib")
#	endif
#endif

#include "../../../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libTinyXmlMDd.lib")
#		pragma message("Link LibX86 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libTinyXmlMD.lib")
#		pragma message("Link LibX86 TinyXmlMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libTinyXmlMDd.lib")
#		pragma message("Link LibX64 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libTinyXmlMD.lib")
#		pragma message("Link LibX64 TinyXmlMD.lib")
#	endif
#endif


#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="BpaSysAdequacyModule.log";
extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

tagBpaBlock*			g_pBpaBlock;
tagPRBlock*				g_pPRBlock;
CPRMemDBInterface		g_PRMemDBInterface;
CBpaMemDBInterface		g_BpaMemDBInterface;
CPRAdequacyEstimate		g_PRAdeEstimate;
CPRAdequacyStateSample	g_PRStateSample;
CBpaPRParam		g_BpaPRParam;

void PrintMessage(const char* pformat, ...);

int main(int argc, char** argv, char** envp)
{
	char	szRunDir[260], szRResultFile[260];
	tagBpaPRAdequacySetting	sPRAdeSetting;
	clock_t	dBeg, dEnd;
	int		nDur;

	ClearLog(g_lpszLogFile);
	GetCurrentDirectory(260, szRunDir);
	InitBpaPRAdequacySetting(&sPRAdeSetting);

	int	nEle=1;
	if (argc > nEle)	strcpy(szRunDir, argv[nEle++]);							else	return 0;
	if (argc > nEle)	sPRAdeSetting.nMCSSimulateTime = atoi(argv[nEle++]);	else	return 0;
	if (argc > nEle)	sPRAdeSetting.nMaxGenFault = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.nMaxBranFault = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.bGenBusLoadAsAux = atoi(argv[nEle++]);	else	return 0;
	if (argc > nEle)	sPRAdeSetting.fDc2AcFactor = atof(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.bLineELimit = atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	sPRAdeSetting.bTranELimit = atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	sPRAdeSetting.bGenPELimit = atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	sPRAdeSetting.bUPFCELimit = atoi(argv[nEle++]);			else	return 0;
	if (argc > nEle)	sPRAdeSetting.bAuxLoadAdjust = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.bEQGenAdjust = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.bEQLoadAdjust = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.fMinIslandGLRatio = atoi(argv[nEle++]);	else	return 0;
	if (argc > nEle)	sPRAdeSetting.bUPFCAdjustRC = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.nPRSampleMethod = atoi(argv[nEle++]);		else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaDatFile = argv[nEle++];				else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaSwiFile = argv[nEle++];				else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaRParamFile = argv[nEle++];			else	return 0;
	if (argc > nEle)	strcpy(szRResultFile, argv[nEle++]);					else	return 0;

	ClearLog(g_lpszLogFile);
	dBeg=clock();

	{
		g_pBpaBlock=(tagBpaBlock*)g_BpaMemDBInterface.Init_BpaBlock();
		if (!g_pBpaBlock)
		{
			PrintMessage("��ȡBpa�ڴ�����\n");
			return FALSE;
		}

		g_pPRBlock=(tagPRBlock*)g_PRMemDBInterface.Init_PRBlock();
		if (!g_pPRBlock)
		{
			PrintMessage("��ȡPR�ڴ�����\n");
			return FALSE;
		}
	}
	{
		char	drive[260], dir[260], fname[260], ext[260];
		char	szFileName[260], szBpaPFExec[260], szWorkDir[260], szExec[260];

		sprintf(szBpaPFExec, "%s/pfnt.exe", szRunDir);
		if (access(szBpaPFExec, 0) != 0)
			return 0;

		g_BpaMemDBInterface.BpaFiles2MemDB(g_pBpaBlock, sPRAdeSetting.strBpaDatFile.c_str(), sPRAdeSetting.strBpaSwiFile.c_str(), 0);

		_splitpath(sPRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
		_makepath(szWorkDir, drive, dir, NULL, NULL);
		SetCurrentDirectory(szWorkDir);

		sprintf(szFileName,"%s%s",fname,ext);
		sprintf(szExec,"%s %s", szBpaPFExec, szFileName);
		PrintMessage(szExec);
		StartProcess(szExec, NULL, SW_HIDE);

		_makepath(szFileName, drive, dir, fname, ".pfo");
		if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName) <= 0)
		{
			PrintMessage("��PFO�ļ�������㽻������\n");
			return 0;
		}

		BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, sPRAdeSetting.strBpaDatFile.c_str(), sPRAdeSetting.strBpaSwiFile.c_str(), sPRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������
		g_BpaPRParam.ReadBpaPRParam(sPRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}
	{
		int	nStateNum = g_PRStateSample.Sample(g_pPRBlock, 0, PRFState_SamplingMethod_MonteCarlo, &sPRAdeSetting);
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("״̬������ϣ���ʱ%d���� ״̬��=%d\n",nDur, nStateNum);
		if (nStateNum <= 0)
			return 0;
	}

	{

		{
// 			//////////////////////////////////////////////////////////////////////////
// 			//	������ֵ
// 			PRMemDBIsland(g_pPRBlock);
// 			CDCNetwork*	pDCNetwork=new CDCNetwork();
// 
// 			pDCNetwork->PRDCFlow(g_pPRBlock);
// 			delete pDCNetwork;
// 
// 			register int	i;
// 			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
// 			{
// 				if (g_pPRBlock->m_ACLineArray[i].fRated > FLT_MIN && 1.01*fDC2ACRatio*fabs(g_pPRBlock->m_ACLineArray[i].fPfPi) > g_pPRBlock->m_ACLineArray[i].fRated)
// 					g_pPRBlock->m_ACLineArray[i].fRated=(float)(1.01*fDC2ACRatio*fabs(g_pPRBlock->m_ACLineArray[i].fPfPi));
// 			}
// 			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_WIND]; i++)
// 			{
// 				if (g_pPRBlock->m_WindArray[i].fRated > FLT_MIN && 1.01*fDC2ACRatio*fabs(g_pPRBlock->m_WindArray[i].fPfPi) > g_pPRBlock->m_WindArray[i].fRated)
// 					g_pPRBlock->m_WindArray[i].fRated=(float)(1.01*fDC2ACRatio*fabs(g_pPRBlock->m_WindArray[i].fPfPi));
// 			}
// 			//	������ֵ
// 			//////////////////////////////////////////////////////////////////////////

		}


		{
			SYSTEM_INFO sysInfo;
			::GetSystemInfo(&sysInfo);

			unsigned int	nChildThreadID;
			tagAdequacyThreadInfo*	pInfo=(tagAdequacyThreadInfo*)malloc(sizeof(tagAdequacyThreadInfo));
			pInfo->pPRBlock = g_pPRBlock;
			pInfo->nParentThreadID = GetCurrentThreadId();
			pInfo->fAC2DCFactor = sPRAdeSetting.fDc2AcFactor;
			pInfo->bLineEOvl = sPRAdeSetting.bLineELimit;
			pInfo->bTranEOvl = sPRAdeSetting.bTranELimit;
			pInfo->bGenEOvl  = sPRAdeSetting.bGenPELimit ;
			pInfo->bUPFCEOvl = sPRAdeSetting.bUPFCELimit;
			pInfo->bAuxLoadAdjust = sPRAdeSetting.bAuxLoadAdjust;
			pInfo->bEQGenAdjust = sPRAdeSetting.bEQGenAdjust;
			pInfo->bEQLoadAdjust = sPRAdeSetting.bEQLoadAdjust;
			pInfo->bUPFCAdjustRC = sPRAdeSetting.bUPFCAdjustRC;
			pInfo->fMinGLRatio = sPRAdeSetting.fMinIslandGLRatio;
			pInfo->nMultiThread = sysInfo.dwNumberOfProcessors/2;
			strcpy(pInfo->szResultXmlFile, szRResultFile);
			HANDLE hControl = (HANDLE)_beginthreadex(NULL, 0, SysAdequacyEstimateConThreaad, (void*)pInfo, 0, &nChildThreadID);
			DWORD dwRet=WaitForSingleObject(hControl, INFINITE);

			if (dwRet == WAIT_OBJECT_0)
				Log(g_lpszLogFile, "        �����ϵͳ�ɿ�����������������\n");
			else
				Log(g_lpszLogFile, "        �����ϵͳ�ɿ�������������̴��� RetCode = %d\n", dwRet);
			if (hControl != INVALID_HANDLE_VALUE)
				CloseHandle(hControl);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�����ϵͳ�ɿ�������������ɣ���ʱ %d ����", nDur);
}

void PrintMessage(const char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];

	vsprintf(szMesg, pformat, args);
	vfprintf(stdout, pformat, args);
	fprintf(stdout, "\n");

	Log(g_lpszLogFile, szMesg);

	va_end(args);
}
