#include <Windows.h>
#include <io.h>
#include <vector>
using namespace std;
#include <crtdbg.h>
#include <float.h>
#include <process.h>

#include "../../../../../MemDB/BpaMemDB/BpaMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../../lib/BpaMemDB.lib")
#	pragma message("Link LibX86 BpaMemDB.lib")
#else
#	pragma comment(lib, "../../../../../lib_x64/BpaMemDB.lib")
#	pragma message("Link LibX64 BpaMemDB.lib")
#endif
using	namespace	BpaMemDB;

#include "../../../../../MemDB/PRMemDB/PRMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../../lib/PRMemDB.lib")
#else
#	pragma comment(lib, "../../../../../lib_x64/PRMemDB.lib")
#endif
using	namespace	PRMemDB;

#include "../../../../DCNetwork/DCNetwork.h"
using	namespace	DCNetwork;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libDCNetworkMDd.lib")
#		pragma message("Link LibX86 DCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libDCNetworkMD.lib")
#		pragma message("Link LibX86 DCNetworkMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libDCNetworkMDd.lib")
#		pragma message("Link LibX64 DCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libDCNetworkMD.lib")
#		pragma message("Link LibX64 DCNetworkMD.lib")
#	endif
#endif

#include "../../PRAdequacyBase/PRAdequacyBase.h"
using	namespace	PRAdequacyBase;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libPRAdequacyBaseMDd.lib")
#		pragma message("Link LibX86 PRAdequacyBaseMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libPRAdequacyBaseMD.lib")
#		pragma message("Link LibX86 PRAdequacyBaseMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libPRAdequacyBaseMDd.lib")
#		pragma message("Link LibX64 PRAdequacyBaseMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libPRAdequacyBaseMD.lib")
#		pragma message("Link LibX64 PRAdequacyBaseMD.lib")
#	endif
#endif

#include "../../../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib/libTinyXmlMDd.lib")
#		pragma message("Link LibX86 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib/libTinyXmlMD.lib")
#		pragma message("Link LibX86 TinyXmlMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../../lib_x64/libTinyXmlMDd.lib")
#		pragma message("Link LibX64 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../../lib_x64/libTinyXmlMD.lib")
#		pragma message("Link LibX64 TinyXmlMD.lib")
#	endif
#endif

#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="BpaGenAdequacyModule.log";
extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
tagBpaBlock*			g_pBpaBlock;
tagPRBlock*				g_pPRBlock;
CPRMemDBInterface		g_PRMemDBInterface;
CBpaMemDBInterface		g_BpaMemDBInterface;
CPRCopTable				m_CopTable;

CBpaPRParam				g_BpaPRParam;
CPRAdequacyStateSample	g_PRStateSample;			//	���ؿ���״̬����
CPRAdequacyEstimate		g_PRAdeEstimate;

extern	int	StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

void PrintMessage(const char* pformat, ...);

int main(int argc, char** argv, char** envp)
{
	unsigned char	nMethod;
	double	fCOPTStep;
	char	szRunDir[260], szRResultFile[260];
	tagBpaPRAdequacySetting	sPRAdeSetting;
	clock_t	dBeg, dEnd;
	int		nDur;

	fCOPTStep = 100;
	GetCurrentDirectory(260, szRunDir);
	InitBpaPRAdequacySetting(&sPRAdeSetting);

	int	nEle=1;
	if (argc > nEle)	strcpy(szRunDir, argv[nEle++]);								else	return 0;
	if (argc > nEle)	nMethod = atoi(argv[nEle++]);								else	return 0;
	if (nMethod == 0)
	{
		if (argc > nEle)	sPRAdeSetting.nMCSSimulateTime = atoi(argv[nEle++]);	else	return 0;
		if (argc > nEle)	sPRAdeSetting.nMaxGenFault = atoi(argv[nEle++]);		else	return 0;
		if (argc > nEle)	sPRAdeSetting.bGenBusLoadAsAux = atoi(argv[nEle++]);	else	return 0;
	}
	else
	{
		if (argc > nEle)	fCOPTStep = atof(argv[nEle++]);							else	return 0;
	}

	if (argc > nEle)	sPRAdeSetting.strBpaDatFile = argv[nEle++];					else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaSwiFile = argv[nEle++];					else	return 0;
	if (argc > nEle)	sPRAdeSetting.strBpaRParamFile = argv[nEle++];				else	return 0;
	if (argc > nEle)	strcpy(szRResultFile, argv[nEle++]);						else	return 0;

	if (access(sPRAdeSetting.strBpaDatFile.c_str(), 0) != 0)
		return 0;
	if (access(sPRAdeSetting.strBpaSwiFile.c_str(), 0) != 0)
		return 0;
	if (access(sPRAdeSetting.strBpaRParamFile.c_str(), 0) != 0)
		return 0;
	ClearLog(g_lpszLogFile);

	dBeg=clock();

	{
		g_pBpaBlock=(tagBpaBlock*)g_BpaMemDBInterface.Init_BpaBlock();
		if (!g_pBpaBlock)
		{
			PrintMessage("��ȡBpa�ڴ�����\n");
			return FALSE;
		}

		g_pPRBlock=(tagPRBlock*)g_PRMemDBInterface.Init_PRBlock();
		if (!g_pPRBlock)
		{
			PrintMessage("��ȡPR�ڴ�����\n");
			return FALSE;
		}
	}

	{
		char	szFileName[260], szBpaPFExec[260], szWorkDir[260], szExec[260];
		char	drive[260], dir[260], fname[260], ext[260];

		sprintf(szBpaPFExec, "%s/pfnt.exe", szRunDir);
		if (access(szBpaPFExec, 0) != 0)
			return 0;

		g_BpaMemDBInterface.BpaFiles2MemDB(g_pBpaBlock, sPRAdeSetting.strBpaDatFile.c_str(), sPRAdeSetting.strBpaSwiFile.c_str(), 0);

		_splitpath(sPRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
		_makepath(szWorkDir, drive, dir, NULL, NULL);
		SetCurrentDirectory(szWorkDir);

		sprintf(szFileName,"%s%s",fname,ext);
		sprintf(szExec,"%s %s", szBpaPFExec, szFileName);
		PrintMessage(szExec);
		StartProcess(szExec, NULL, SW_HIDE);

		_makepath(szFileName, drive, dir, fname, ".pfo");
		if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName) <= 0)
		{
			PrintMessage("��PFO�ļ�������㽻������\n");
			return 0;
		}

		BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, sPRAdeSetting.strBpaDatFile.c_str(), sPRAdeSetting.strBpaSwiFile.c_str(), sPRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������
		g_BpaPRParam.ReadBpaPRParam(sPRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}

	if (nMethod == 0)
	{
		int nStateNum=g_PRStateSample.Sample(g_pPRBlock, 2, PRFState_SamplingMethod_MonteCarlo, &sPRAdeSetting);

		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		PrintMessage("״̬������ϣ���ʱ%d���� ״̬��=%d\n",nDur, nStateNum);
		if (nStateNum <= 0)
			return 0;

		{
			SYSTEM_INFO sysInfo;
			::GetSystemInfo(&sysInfo);

			unsigned int	nChildThreadID;
			tagAdequacyThreadInfo*	pInfo=(tagAdequacyThreadInfo*)malloc(sizeof(tagAdequacyThreadInfo));
			pInfo->pPRBlock = g_pPRBlock;
			pInfo->nParentThreadID = GetCurrentThreadId();
			pInfo->nMultiThread = sysInfo.dwNumberOfProcessors/2;
			strcpy(pInfo->szResultXmlFile, szRResultFile);
			HANDLE hControl = (HANDLE)_beginthreadex(NULL, 0, GenAdequacyEstimateConThreaad, (void*)pInfo, 0, &nChildThreadID);
			DWORD dwRet=WaitForSingleObject(hControl, INFINITE);

			if (dwRet == WAIT_OBJECT_0)
				Log(g_lpszLogFile, "        ����ϵͳ�ɿ�����������������\n");
			else
				Log(g_lpszLogFile, "        ����ϵͳ�ɿ�������������̴��� RetCode = %d\n", dwRet);
			if (hControl != INVALID_HANDLE_VALUE)
				CloseHandle(hControl);
		}
	}
	else
	{
		m_CopTable.CopTable(g_pPRBlock, fCOPTStep, szRResultFile);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("����ϵͳ��ԣ������������ɣ���ʱ %d ����", nDur);
}

void PrintMessage(const char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];

	vsprintf(szMesg, pformat, args);
	vfprintf(stdout, pformat, args);
	fprintf(stdout, "\n");

	Log(g_lpszLogFile, szMesg);

	va_end(args);
}