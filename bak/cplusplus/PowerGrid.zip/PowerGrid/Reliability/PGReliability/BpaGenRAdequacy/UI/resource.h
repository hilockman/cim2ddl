//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BpaGenRAdequacyUI.rc
//
#define IDB_COM_BKGND                   101
#define IDB_COM_CONBKGND                102
#define IDB_VISIBLED                    103
#define IDB_VISIBLED_OVER               104
#define IDB_VISIBLEU                    105
#define IDB_VISIBLEU_OVER               106
#define IDD_PRESULT_SAMPLESTATE_DIALOG  153
#define IDD_FSTATE_ESTIMATE_SET_DIALOG  155
#define IDC_ACFLOW                      1007
#define IDC_BPA_RPARAMFILE              1013
#define IDC_BPAPF_FILE                  1015
#define IDC_BPASW_FILE                  1016
#define IDC_RPARAM_BROWSE               1019
#define IDC_ERASE_RPARAM                1020
#define IDC_CLEAR_MESG                  1021
#define IDC_COMMPARAM_LIST              1022
#define IDC_DAT_BROWSE                  1023
#define IDC_DAT_ERASE                   1026
#define IDC_DEVTYPE_COMBO               1040
#define IDC_PARAMSRC_COMBO              1041
#define IDC_DEVPARAM_LIST               1043
#define IDC_DN                          1044
#define IDC_DNV_LIMIT                   1045
#define IDC_EDIT_RPARAM                 1046
#define IDC_DNCAP_LIMIT                 1046
#define IDC_GENADEQUACY_ESTIMATE        1056
#define IDC_MAXFAULT_GEN                1066
#define IDC_MCS_MINSTATEPROB            1067
#define IDC_MCS_SIMULATETIME            1068
#define IDC_COPT                        1068
#define IDC_MCS_MINSTATEPROB2           1069
#define IDC_THREAD_NUM                  1069
#define IDC_MESG_LIST                   1070
#define IDC_COPT_STEP                   1071
#define IDC_PROGRESS                    1081
#define IDC_RERR                        1083
#define IDC_SAVE                        1084
#define IDC_SIM_SAVEAS_EXCEL            1086
#define IDC_COP_SAVEAS_EXCEL            1087
#define IDC_SET_DEVPARAM                1088
#define IDC_USE_COMPARAM                1089
#define IDC_SHOW_HASVALUE_ONLY          1093
#define IDC_STATE_NUM                   1097
#define IDC_SWI_BROWSE                  1102
#define IDC_TAB                         1104
#define IDC_SWI_ERASE                   1105
#define IDC_COPT_INIT                   1106
#define IDC_AUXLOAD_ADJUST              1109
#define IDC_TREP                        1109
#define IDC_MULTI_THREAD                1110
#define IDC_UP                          1112
#define IDC_UPV_LIMIT                   1113
#define IDC_UPCAP_LIMIT                 1114
#define IDC_ZONE                        1116
#define IDD_BPA_GENADEQUACY_DIALOG      1117
#define IDD_PRPARAM_DIALOG              1125
#define IDR_MAINFRAME                   1130
#define IDD_PRPARAM_COM_DIALOG          1130
#define IDD_PRPARAM_DEV_DIALOG          1131
#define IDD_PRESULT_BUSRELIABILITY_DIALOG 1132
#define IDC_ADD                         1169
#define IDC_DEL                         1170
#define IDC_MOD                         1171
#define IDC_FSTATE_LIST                 1173
#define IDC_DNVLMT_UNIT                 1176
#define IDC_UPLMT_UNIT                  1177
#define IDC_RERR_UNIT                   1178
#define IDC_BUSRESULT_LIST              1179
#define IDC_DNLMT_UNIT2                 1179
#define IDC_UPLMT_UNIT2                 1180
#define IDC_MSTATE_MODEL                1183
#define IDC_EQ_MODEL                    1184
#define IDC_SHOW_FAULTGRADE1            1204
#define IDC_SHOW_FAULTGRADE2            1205
#define IDC_SHOW_FAULTGRADE3            1206
#define IDC_SHOW_FAULTGRADE4            1207
#define IDC_SHOW_FAULTGRADE0            1208
#define IDC_SHOW_ENSLOSSLOAD            1210
#define IDC_SHOW_FAULTDEVICE            1214

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        154
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1180
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
