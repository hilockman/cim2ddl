
// PRelibilityUIDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaGenRAdequacyUI.h"
#include "BpaGenRAdequacyUIDlg.h"
#include "BpaPRParamDialog.h"
#include "PREstimateSetDialog.h"

#include "../../../../../Common/String2Double.hpp"
#include "../../../../../Common/Excel/ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

clock_t	m_dBeg;

extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

//////////////////////////////////////////////////////////////////////////
// CBpaGenAdequacyUIDlg �Ի���

#define	IDC_RSYSRESULT_LISTCTRL	20022
#define	IDC_RBUSRESULT_LISTCTRL	20023
#define	IDC_ROVLADJUST_LISTCTRL	20024

static	unsigned char	m_bUIFreezed = 0;

static	char*	lpszRSysResultColumn[]={
	"ָ��",
	"����",
	"���",
};


static	char*	lpszGenProbColumn[]={
	"����", 
	"����", 
	"������", 
	"�޸�ʱ��", 
	"�޸���", 
	"ǿ��ͣ����", 
	"��������1", 
	"��������2", 
	"����ϵ��", 
};

static	char*	lpszCOPTableColumn[]={
	"״̬", 
	"ͣ�˷�������", 
	"���÷�������", 
	"ȷ��״̬����", 
	"�ۻ�״̬����", 
	"ȷ��״̬Ƶ��", 
	"�ۻ�״̬Ƶ��", 
	"������ȥ��", 
	"������ȥ��", 
};


CBpaGenAdequacyUIDlg::CBpaGenAdequacyUIDlg(CWnd* pParent /*=NULL*/)
: CDialog(CBpaGenAdequacyUIDlg::IDD, pParent)
, m_fCoptCapacityStep(100)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_nAdequacyEstimateNum = 0;
	m_hAdequacyEstimateHandle = INVALID_HANDLE_VALUE;
}

void CBpaGenAdequacyUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_COPT_STEP, m_fCoptCapacityStep);
}

BEGIN_MESSAGE_MAP(CBpaGenAdequacyUIDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_GENADEQUACY_ESTIMATE, &CBpaGenAdequacyUIDlg::OnBnClickedGenAdequacy)

	ON_BN_CLICKED(IDC_DAT_BROWSE, &CBpaGenAdequacyUIDlg::OnBnClickedDatBrowse)
	ON_BN_CLICKED(IDC_SWI_BROWSE, &CBpaGenAdequacyUIDlg::OnBnClickedSwiBrowse)
	ON_BN_CLICKED(IDC_CLEAR_MESG, &CBpaGenAdequacyUIDlg::OnBnClickedClearMesg)
	ON_BN_CLICKED(IDC_EDIT_RPARAM, &CBpaGenAdequacyUIDlg::OnBnClickedRParamEdit)

	ON_BN_CLICKED(IDC_SIM_SAVEAS_EXCEL, &CBpaGenAdequacyUIDlg::OnBnClickedSimSaveAsExcel)
	ON_BN_CLICKED(IDC_COP_SAVEAS_EXCEL, &CBpaGenAdequacyUIDlg::OnBnClickedCopSaveAsExcel)
	ON_BN_CLICKED(IDC_RPARAM_BROWSE, &CBpaGenAdequacyUIDlg::OnBnClickedRParamBrowse)

	ON_MESSAGE(WM_ESTIMATEBEG, OnAdequacyEstimateBegin)
	ON_MESSAGE(WM_ESTIMATING, OnAdequacyEstimating)
	ON_MESSAGE(WM_ESTIMATEEND, OnAdequacyEstimateEnded)

	ON_BN_CLICKED(IDC_DAT_ERASE, &CBpaGenAdequacyUIDlg::OnBnClickedDatErase)
	ON_BN_CLICKED(IDC_SWI_ERASE, &CBpaGenAdequacyUIDlg::OnBnClickedSwiErase)
	ON_BN_CLICKED(IDC_ERASE_RPARAM, &CBpaGenAdequacyUIDlg::OnBnClickedRParamErase)
	ON_BN_CLICKED(IDC_COPT_INIT, &CBpaGenAdequacyUIDlg::OnBnClickedCoptInit)
	ON_BN_CLICKED(IDC_COPT, &CBpaGenAdequacyUIDlg::OnBnClickedCopt)
	ON_BN_CLICKED(IDC_ACFLOW, &CBpaGenAdequacyUIDlg::OnBnClickedAcflow)
END_MESSAGE_MAP()

// CBpaGenAdequacyUIDlg ��Ϣ��������

BOOL CBpaGenAdequacyUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	CRect	rectDummy;
	int		nColumn;
	int		nListID=100;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndSampleState.Create(IDD_PRESULT_SAMPLESTATE_DIALOG,	&m_wndTab);
	m_wndBusReliability.Create(IDD_PRESULT_BUSRELIABILITY_DIALOG,	&m_wndTab);

	if (!m_wndListPRSysResult.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectDummy, &m_wndTab, IDC_RSYSRESULT_LISTCTRL))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPRSysResult.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPRSysResult.SetExtendedStyle(m_wndListPRSysResult.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPRSysResult.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRSysResultColumn)/sizeof(char*); nColumn++)
		m_wndListPRSysResult.InsertColumn(nColumn, lpszRSysResultColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListGenProb.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectDummy, &m_wndTab, nListID++))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListGenProb.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListGenProb.SetExtendedStyle(m_wndListGenProb.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListGenProb.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszGenProbColumn)/sizeof(char*); nColumn++)
		m_wndListGenProb.InsertColumn(nColumn, lpszGenProbColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListCOPT.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectDummy, &m_wndTab, nListID++))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListCOPT.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListCOPT.SetExtendedStyle(m_wndListCOPT.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListCOPT.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszCOPTableColumn)/sizeof(char*); nColumn++)
		m_wndListCOPT.InsertColumn(nColumn, lpszCOPTableColumn[nColumn],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndSampleState,			_T("����״̬��"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListPRSysResult,		_T("�ɿ���ϵͳ������"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndBusReliability,		_T("�ɿ���ĸ�߼�����"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListGenProb,			_T("ͣ������-�����"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListCOPT,			_T("ͣ������-���ʱ�"),	-1, FALSE);

	LoadBpaModelFile();

	RefreshParam();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CBpaGenAdequacyUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CBpaGenAdequacyUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void	CBpaGenAdequacyUIDlg::PrintMessage(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);

	vsprintf(szMesg, pformat, args);

	int	iExt = GetTextLen(szMesg);
	if (iExt > pListBox->GetHorizontalExtent())
		pListBox->SetHorizontalExtent(iExt);
	pListBox->AddString(szMesg);
	pListBox->SetCaretIndex(pListBox->GetCount()-1);

	va_end(args);
}

int CBpaGenAdequacyUIDlg::GetTextLen(LPCTSTR lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC* pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(lpszText, (int) _tcslen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(lpszText, (int) _tcslen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CBpaGenAdequacyUIDlg::RefreshParam()
{
	m_bUIFreezed=1;

	UpdateData(FALSE);

	GetDlgItem(IDC_BPAPF_FILE)		->SetWindowText(g_PRAdeSetting.strBpaDatFile.c_str());
	GetDlgItem(IDC_BPASW_FILE)		->SetWindowText(g_PRAdeSetting.strBpaSwiFile.c_str());
	GetDlgItem(IDC_BPA_RPARAMFILE)	->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());

	m_bUIFreezed=0;
}

void CBpaGenAdequacyUIDlg::OnBnClickedDatBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("dat");
	CString	defaultFileName=g_PRAdeSetting.strBpaDatFile.c_str();
	CString	fileFilter=_T("BPA�����ļ�(*.dat)|*.dat;*.DAT|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("��BPA�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PRAdeSetting.strBpaDatFile = dlg.GetPathName();
	GetDlgItem(IDC_BPAPF_FILE)->SetWindowText(g_PRAdeSetting.strBpaDatFile.c_str());

	SaveBpaPRAdequacySetting(&g_PRAdeSetting);

	LoadBpaModelFile();

	PrintMessage("����BPA���������ļ����");
}

void CBpaGenAdequacyUIDlg::OnBnClickedSwiBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("swi");
	CString	defaultFileName=g_PRAdeSetting.strBpaSwiFile.c_str();
	CString	fileFilter=_T("BPA�ȶ��ļ�(*.swi)|*.swi;*.SWI|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("��BPA�ȶ��ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PRAdeSetting.strBpaSwiFile = dlg.GetPathName();
	GetDlgItem(IDC_BPASW_FILE)->SetWindowText(g_PRAdeSetting.strBpaSwiFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);

	LoadBpaModelFile();

	PrintMessage("����BPA�ȶ������ļ����");
}

void CBpaGenAdequacyUIDlg::OnBnClickedRParamBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("XML");
	CString	defaultFileName=g_PRAdeSetting.strBpaRParamFile.c_str();
	CString	fileFilter=_T("�ɿ����豸�����ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�ɿ����豸�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PRAdeSetting.strBpaRParamFile = dlg.GetPathName();
	GetDlgItem(IDC_BPA_RPARAMFILE)->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaGenAdequacyUIDlg::OnBnClickedDatErase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRAdeSetting.strBpaDatFile.clear();
	GetDlgItem(IDC_BPAPF_FILE)->SetWindowText(g_PRAdeSetting.strBpaDatFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaGenAdequacyUIDlg::OnBnClickedSwiErase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRAdeSetting.strBpaSwiFile.clear();
	GetDlgItem(IDC_BPASW_FILE)->SetWindowText(g_PRAdeSetting.strBpaSwiFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaGenAdequacyUIDlg::OnBnClickedRParamErase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PRAdeSetting.strBpaRParamFile.clear();
	GetDlgItem(IDC_BPA_RPARAMFILE)->SetWindowText(g_PRAdeSetting.strBpaRParamFile.c_str());
	SaveBpaPRAdequacySetting(&g_PRAdeSetting);
}

void CBpaGenAdequacyUIDlg::OnBnClickedClearMesg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	pListBox->ResetContent();
}

void CBpaGenAdequacyUIDlg::OnBnClickedGenAdequacy()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	CPREstimateSetDialog	dlg;
	if (dlg.DoModal() == IDCANCEL)
		return;

	dBeg=m_dBeg=clock();

	UpdateData();
	if (!PreparePRData(2))
		return;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("ReadBpaData��ϣ���ʱ%d����\n",nDur);

	int	nStateNum=g_PRStateSample.Sample(g_pPRBlock, 2, PRFState_SamplingMethod_MonteCarlo, &g_PRAdeSetting);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("״̬������ϣ���ʱ%d���� ״̬��=%d\n",nDur, nStateNum);

	HANDLE hEstimate = g_PRAdeEstimate.GenAdequacyEstimate(g_pPRBlock, g_PRAdeSetting.nMultiThread);
	if (hEstimate == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox("����ϵͳ��ԣ����������������......����ȴ�������������");
		return;
	}

	m_hAdequacyEstimateHandle = hEstimate;
	m_wndTab.SetActiveTab(1);
}

LRESULT CBpaGenAdequacyUIDlg::OnAdequacyEstimateBegin(WPARAM wParam, LPARAM lParam)
{
	m_nAdequacyEstimateNum = 0;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetRange(0, g_pPRBlock->m_nRecordNum[PR_FSTATE]);

	PrintMessage("���������㿪ʼ\n");
	return 0;
}

LRESULT CBpaGenAdequacyUIDlg::OnAdequacyEstimating(WPARAM wParam, LPARAM lParam)
{
	m_nAdequacyEstimateNum += wParam;
	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos(m_nAdequacyEstimateNum);
	return 0;
}

LRESULT CBpaGenAdequacyUIDlg::OnAdequacyEstimateEnded(WPARAM wParam, LPARAM lParam)
{
	clock_t	dEnd;
	int		nDur;

	m_nAdequacyEstimateNum = 0;
	m_hAdequacyEstimateHandle = INVALID_HANDLE_VALUE;

	CProgressCtrl*	pCtrl=(CProgressCtrl*)GetDlgItem(IDC_PROGRESS);
	pCtrl->SetPos(g_pPRBlock->m_nRecordNum[PR_FSTATE]);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-m_dBeg))/CLOCKS_PER_SEC);

	PrintMessage("������������ϣ���ʱ%d����\n", nDur);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-m_dBeg))/CLOCKS_PER_SEC);

	PrintMessage("ͳ�Ƽ�������ɣ���ʱ%d����\n", nDur);

	m_wndSampleState.RefreshUI(0);
	RefreshPRSysResultList();
	m_wndBusReliability.RefreshUI();

	return 0;
}

int  CBpaGenAdequacyUIDlg::PreparePRData(const int nSampleType)
{
	char	drive[260], dir[260], fname[260], ext[260];
	char	szFileName[260], szBpaPFExec[260], szWorkDir[260], szExec[260];

	//////////////////////////////////////////////////////////////////////////
	//	����BPA����
	{
		sprintf(szBpaPFExec, "%s/pfnt.exe", g_szRunDir);
		if (access(szBpaPFExec, 0) != 0)
		{
			PrintMessage("�޳�����������\n");
			return 0;
		}

		_splitpath(g_PRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
		_makepath(szWorkDir, drive, dir, NULL, NULL);
		SetCurrentDirectory(szWorkDir);

		sprintf(szFileName,"%s%s",fname,ext);
		sprintf(szExec,"%s %s", szBpaPFExec, szFileName);
		PrintMessage(szExec);
		StartProcess(szExec, NULL, SW_HIDE);

		_makepath(szFileName, drive, dir, fname, ".pfo");
		if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName) <= 0)
		{
			PrintMessage("��PFO�ļ�������㽻������\n");
			return 0;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	BPA���ݿ�->PR���ݿ�
	BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������

	//////////////////////////////////////////////////////////////////////////
	//	��������Ʋ���
	if (!g_PRAdeSetting.strBpaRParamFile.empty())
		g_BpaPRParam.ReadBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);

	return 1;
}

void CBpaGenAdequacyUIDlg::OnBnClickedRParamEdit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	//C2StateRParamDialog	dlg;
	CBpaPRParamDialog	dlg;
	dlg.DoModal();
}

void CBpaGenAdequacyUIDlg::RefreshPRSysResultList()
{
	int		nRow, nCol;
	char	szBuf[260];
	int	nColWidth,nHeaderWidth;

	m_wndListPRSysResult.DeleteAllItems();

	nRow=0;
	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_MAXFLTDEV));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_MAXFLTDEV));
	sprintf(szBuf,"%d",g_pPRBlock->m_System.nMaxFltDev);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_PLC));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_PLC));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fPLC);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_EFLC));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_EFLC));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fEFLC);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_EDLC));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_EDLC));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fEDLC);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_ADLC));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_ADLC));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fADLC);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_ELC));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_ELC));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fELC);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_EENS));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_EENS));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fEENS);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_BPII));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_BPII));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fBPII);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_BPECI));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_BPECI));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fBPECI);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_SI));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_SI));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fSI);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_LOLP));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_LOLP));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fLOLP);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_LOLF));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_LOLF));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fLOLF);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_LOLE));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_LOLE));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fLOLE);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_MIEENS));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_MIEENS));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fMIslandEENS);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_AGCEENS));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_AGCEENS));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fLossGenEENS);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_ELEENS));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_ELEENS));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fERLimitEENS);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_FLTGRADE0PROB));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE0PROB));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade0Prob);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_FLTGRADE1PROB));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE1PROB));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade1Prob);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_FLTGRADE2PROB));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE2PROB));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade2Prob);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_FLTGRADE3PROB));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE3PROB));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade3Prob);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	m_wndListPRSysResult.InsertItem(nRow, g_PRMemDBInterface.PRGetFieldName(PR_SYSTEM, PR_SYSTEM_FLTGRADE4PROB));
	m_wndListPRSysResult.SetItemText(nRow, 1, g_PRMemDBInterface.PRGetFieldDesp(PR_SYSTEM, PR_SYSTEM_FLTGRADE4PROB));
	sprintf(szBuf,"%f",g_pPRBlock->m_System.fFltGrade4Prob);
	m_wndListPRSysResult.SetItemText(nRow, 2, szBuf);
	nRow++;

	for (nCol=0; nCol<sizeof(lpszRSysResultColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPRSysResult.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPRSysResult.GetColumnWidth(nCol);
		m_wndListPRSysResult.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPRSysResult.GetColumnWidth(nCol);

		m_wndListPRSysResult.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaGenAdequacyUIDlg::RefreshCOPTList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	int	nColWidth, nHeaderWidth;

	m_wndListGenProb.DeleteAllItems();
	m_wndListCOPT.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COPGEN]; i++)
	{
		m_wndListGenProb.InsertItem(nRow, g_pPRBlock->m_GeneratorArray[g_pPRBlock->m_CopGenArray[i].nGenIndex].szName);	m_wndListGenProb.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%g", g_pPRBlock->m_CopGenArray[i].fCapacity);	m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CopGenArray[i].fRerr);		m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CopGenArray[i].fTrep);		m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CopGenArray[i].fRrep);		m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CopGenArray[i].fRout);		m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%g", g_pPRBlock->m_CopGenArray[i].fCapL);		m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%g", g_pPRBlock->m_CopGenArray[i].fCapH);		m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_CopGenArray[i].fAlpha);	m_wndListGenProb.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_COPTABLE]; i++)
	{
		sprintf(szBuf, "%d", i+1);	m_wndListCOPT.InsertItem(nRow, szBuf);	m_wndListCOPT.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%g", g_pPRBlock->m_CopTableArray[i].fOutageCapacity);	m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%g", g_pPRBlock->m_CopTableArray[i].fAvailCapacity);	m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.12f", g_pPRBlock->m_CopTableArray[i].fStateProb);	m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.12f", g_pPRBlock->m_CopTableArray[i].fAccumProb);	m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.12f", g_pPRBlock->m_CopTableArray[i].fStateFreq);	m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.12f", g_pPRBlock->m_CopTableArray[i].fAccumFreq);	m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.12f", g_pPRBlock->m_CopTableArray[i].fDepRP);		m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.12f", g_pPRBlock->m_CopTableArray[i].fDepRN);		m_wndListCOPT.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	for (nCol=0; nCol<sizeof(lpszGenProbColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListGenProb.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListGenProb.GetColumnWidth(nCol);
		m_wndListGenProb.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListGenProb.GetColumnWidth(nCol);

		m_wndListGenProb.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	for (nCol=0; nCol<sizeof(lpszCOPTableColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListCOPT.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListCOPT.GetColumnWidth(nCol);
		m_wndListCOPT.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListCOPT.GetColumnWidth(nCol);

		m_wndListCOPT.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaGenAdequacyUIDlg::OnBnClickedSimSaveAsExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	PrintMessage("Excel������ʼ");

	ExcelAccessor	xls;

	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;

	m_wndBusReliability.ExcelOut(&xls);
	m_wndSampleState.ExcelOut(&xls);
	if (m_wndListPRSysResult.GetItemCount() > 0)
	{
		xls.AddSheet(_T("ϵͳ�ɿ��Լ�����"));
		xls.SetCurSheet(_T("ϵͳ�ɿ��Լ�����"));

		nFieldNum=sizeof(lpszRSysResultColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszRSysResultColumn[nCol]));
		for (nRow=0; nRow<m_wndListPRSysResult.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListPRSysResult.GetItemText(nRow, nCol));
		}
	}

	PrintMessage("Excel����ϵͳ�ɿ��Լ��������");


	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));

	PrintMessage("Excel�������");
}

void CBpaGenAdequacyUIDlg::OnBnClickedCopSaveAsExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	PrintMessage("Excel������ʼ");

	ExcelAccessor	xls;

	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;

	if (m_wndListGenProb.GetItemCount() > 0)
	{
		xls.AddSheet(_T("���������"));
		xls.SetCurSheet(_T("���������"));

		nFieldNum=sizeof(lpszGenProbColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszGenProbColumn[nCol]));
		for (nRow=0; nRow<m_wndListGenProb.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListGenProb.GetItemText(nRow, nCol));
		}
	}

	PrintMessage("Excel����������������");


	if (m_wndListCOPT.GetItemCount() > 0)
	{
		xls.AddSheet(_T("�����ͣ�˸��ʱ�"));
		xls.SetCurSheet(_T("�����ͣ�˸��ʱ�"));

		nFieldNum=sizeof(lpszGenProbColumn)/sizeof(char*);
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszGenProbColumn[nCol]));
		for (nRow=0; nRow<m_wndListCOPT.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListCOPT.GetItemText(nRow, nCol));
		}
	}

	PrintMessage("Excel���������ͣ�˸��ʱ����");

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));

	PrintMessage("Excel�������");
}

void CBpaGenAdequacyUIDlg::LoadBpaModelFile(void)
{
	if (_access(g_PRAdeSetting.strBpaDatFile.c_str(), 0) == 0)
	{
		char	drive[260], dir[260], fname[260], ext[260];
		char	szFileName[260];

		g_BpaMemDBInterface.BpaFiles2MemDB(g_pBpaBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.fZIL);

		_splitpath(g_PRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
		_makepath(szFileName, drive, dir, fname, ".pfo");
		if (_access(szFileName, 0) == 0)
			g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szFileName);

		BpaMemDB2PRMemDB(g_pBpaBlock, g_pPRBlock, g_PRAdeSetting.strBpaDatFile.c_str(), g_PRAdeSetting.strBpaSwiFile.c_str(), g_PRAdeSetting.bGenBusLoadAsAux);	//	��ȫ������
		if (!g_PRAdeSetting.strBpaRParamFile.empty())
			g_BpaPRParam.ReadBpaPRParam(g_PRAdeSetting.strBpaRParamFile.c_str(), g_pPRBlock);
	}
}

void CBpaGenAdequacyUIDlg::OnBnClickedCoptInit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	LoadBpaModelFile();

	m_CopTable.CopInit(g_pPRBlock, m_fCoptCapacityStep);

	RefreshCOPTList();
	m_wndTab.SetActiveTab(m_wndTab.GetTabsNum()-2);
}

void CBpaGenAdequacyUIDlg::OnBnClickedCopt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	LoadBpaModelFile();

	m_CopTable.CopTable(g_pPRBlock, m_fCoptCapacityStep);

	RefreshCOPTList();
	m_wndTab.SetActiveTab(m_wndTab.GetTabsNum()-1);
}

void CBpaGenAdequacyUIDlg::OnBnClickedAcflow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (_access(g_PRAdeSetting.strBpaDatFile.c_str(), 0) != 0)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;
	int		nPFResult;
	char	drive[260], dir[260], fname[260], ext[260];
	char	szWorkDir[260], szBpaPFExec[260], szPfoFileName[260], szExec[260];

	dBeg=clock();

	sprintf(szBpaPFExec, "%s/pfnt.exe", g_szRunDir);
	if (access(szBpaPFExec, 0) != 0)
	{
		PrintMessage("AC������������������");
		return;
	}

	if (access(g_PRAdeSetting.strBpaDatFile.c_str(), 0) != 0)
	{
		PrintMessage("BPA�����ļ�������");
		return;
	}

	_splitpath(g_PRAdeSetting.strBpaDatFile.c_str(), drive, dir, fname, ext);
	_makepath(szWorkDir, drive, dir, NULL, NULL);
	_makepath(szPfoFileName, drive, dir, fname, ".pfo");

	SetCurrentDirectory(szWorkDir);

	sprintf(szExec,"%s %s", szBpaPFExec, g_PRAdeSetting.strBpaDatFile.c_str());
	PrintMessage(szExec);
	//StartProcess(szExec, szWorkDir, SW_HIDE);
	system(szExec);

	nPFResult=0;
	if (access(szPfoFileName, 0) == 0)
	{
		if (g_BpaMemDBInterface.BpaParsePfoFile(g_pBpaBlock, szPfoFileName) > 0)
		{
			nPFResult=1;
		}
	}
	else
	{
		PrintMessage("AC����������PFO���");
		return;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	if (nPFResult)
		PrintMessage("AC����������ɣ���ʱ %d ����", nDur);
	else
		PrintMessage("AC�������㲻��������ʱ %d ����", nDur);
}
