#pragma once
#include "BpaPRParamComDialog.h"
#include "BpaPRParamDevDialog.h"

// CPRParamDialog �Ի���

class CBpaPRParamDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamDialog)

public:
	CBpaPRParamDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedSave();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl						m_wndTab;
	CBpaPRParamComDialog			m_wndPRParamCom;
	CBpaPRParamDevDialog			m_wndPRParamDev;
public:
};
