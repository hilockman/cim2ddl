// BpaPRParamDevDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaGenRAdequacyUI.h"
#include "BpaPRParamDevDialog.h"


// CPRParamDevDialog �Ի���
static	int		nPRParamDevType[]=
{
	//PR_ACBUS,
	PR_GENERATOR,
	PR_ACLINE,
	PR_WIND,
	PR_HVDC,
	PR_POWERLOAD,
// 	PR_TCSC,
// 	PR_UPFC,
};

static	char*	lpszDevColumn[]=
{
	"���",
	"�豸����",
	"��ѹ�ȼ�",
	"������(��/��)",
	"�޸�ʱ��(Сʱ)",
	"��������",
	"��״̬",
	"��ֵ",
};

IMPLEMENT_DYNAMIC(CBpaPRParamDevDialog, CDialog)

CBpaPRParamDevDialog::CBpaPRParamDevDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPRParamDevDialog::IDD, pParent)
{

}

CBpaPRParamDevDialog::~CBpaPRParamDevDialog()
{
}

void CBpaPRParamDevDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_DEVPARAM_LIST, m_lstDevParam);
}


BEGIN_MESSAGE_MAP(CBpaPRParamDevDialog, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_DEVPARAM_LIST, &CBpaPRParamDevDialog::OnNMClickDevparamList)
	ON_BN_CLICKED(IDC_SET_DEVPARAM, &CBpaPRParamDevDialog::OnBnClickedSetDevparam)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CBpaPRParamDevDialog::OnCbnSelchangeDevtypeCombo)
	ON_BN_CLICKED(IDC_USE_COMPARAM, &CBpaPRParamDevDialog::OnBnClickedUseComParameter)
	ON_CBN_SELCHANGE(IDC_PARAMSRC_COMBO, &CBpaPRParamDevDialog::OnCbnSelchangeParamsrcCombo)
END_MESSAGE_MAP()


// CPRParamDevDialog ��Ϣ��������

BOOL CBpaPRParamDevDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CComboBox*	pComboBox;

	m_lstDevParam.SetExtendedStyle(m_lstDevParam.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_lstDevParam.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszDevColumn)/sizeof(char*); i++)
		m_lstDevParam.InsertColumn(i,	lpszDevColumn[i],	LVCFMT_LEFT,	60);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(nPRParamDevType)/sizeof(int); i++)
		pComboBox->AddString(g_PRMemDBInterface.PRGetTableDesp(nPRParamDevType[i]));
	pComboBox->SetCurSel(0);
	OnCbnSelchangeDevtypeCombo();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PARAMSRC_COMBO);
	pComboBox->AddString("");
	for (i=0; i<g_PRMemDBInterface.PRGetFieldEnumNum(PR_GENERATOR, PR_GENERATOR_RPARAMTYPE); i++)
		pComboBox->AddString(g_PRMemDBInterface.PRGetFieldEnumString(PR_GENERATOR, PR_GENERATOR_RPARAMTYPE, i));

	RefreshPRParamDev();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaPRParamDevDialog::RefreshPRParamDev()
{
	CComboBox*	pComboBox;
	char		szParamSrc[260];
	
	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int		nTable = pComboBox->GetCurSel();
	if (nTable == CB_ERR)
		return;

	memset(szParamSrc, 0, 260);
	pComboBox=(CComboBox*)GetDlgItem(IDC_PARAMSRC_COMBO);
	int		nParamSrc = pComboBox->GetCurSel();
	if (nParamSrc != CB_ERR)
		pComboBox->GetLBText(nParamSrc, szParamSrc);

	((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->EnableWindow(FALSE);
	((CButton*)GetDlgItem(IDC_USE_COMPARAM))->EnableWindow(TRUE);

	if (nPRParamDevType[nTable] == PR_GENERATOR || nPRParamDevType[nTable] == PR_POWERLOAD)
		((CButton*)GetDlgItem(IDC_EQ_MODEL))->EnableWindow(TRUE);
	else
		((CButton*)GetDlgItem(IDC_EQ_MODEL))->EnableWindow(FALSE);

	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	int			nSelItem=-1;
	POSITION	pos=m_lstDevParam.GetFirstSelectedItemPosition();
	if (pos)
		nSelItem=m_lstDevParam.GetNextSelectedItem(pos);

	m_lstDevParam.DeleteAllItems();

	nRow=0;
	if (nPRParamDevType[nTable] == PR_ACBUS)
	{
		for (i=1; i<(int)g_pPRBlock->m_nRecordNum[PR_ACBUS]; i++)
		{
			if (strlen(szParamSrc) > 0)
			{
				if (stricmp(szParamSrc, g_PRMemDBInterface.PRGetFieldEnumString(PR_ACBUS, PR_ACBUS_RPARAMTYPE, g_pPRBlock->m_ACBusArray[i].nRParamType)) != 0)
					continue;
			}

			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_ACBusArray[i].szName);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_ACBusArray[i].fkV);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_ACBUS, PR_ACBUS_RPARAMTYPE, g_pPRBlock->m_ACBusArray[i].nRParamType));

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_GENERATOR)
	{
		((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->EnableWindow(TRUE);
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_GENERATOR]; i++)
		{
			if (strlen(szParamSrc) > 0)
			{
				if (stricmp(szParamSrc, g_PRMemDBInterface.PRGetFieldEnumString(PR_GENERATOR, PR_GENERATOR_RPARAMTYPE, g_pPRBlock->m_GeneratorArray[i].nRParamType)) != 0)
					continue;
			}

			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_GeneratorArray[i].szName);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_GeneratorArray[i].fkV);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_GeneratorArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_GeneratorArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);

			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_GENERATOR, PR_GENERATOR_RPARAMTYPE, g_pPRBlock->m_GeneratorArray[i].nRParamType));
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_GENERATOR, PR_GENERATOR_MSMODEL, g_pPRBlock->m_GeneratorArray[i].bMSModel));
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_GENERATOR, PR_GENERATOR_EQGEN, g_pPRBlock->m_GeneratorArray[i].bEQGen));

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_POWERLOAD)
	{
		((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->EnableWindow(TRUE);
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_POWERLOAD]; i++)
		{
			if (strlen(szParamSrc) > 0)
			{
				if (stricmp(szParamSrc, g_PRMemDBInterface.PRGetFieldEnumString(PR_POWERLOAD, PR_POWERLOAD_RPARAMTYPE, g_pPRBlock->m_PowerLoadArray[i].nRParamType)) != 0)
					continue;
			}

			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_PowerLoadArray[i].szName);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_PowerLoadArray[i].fkV);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_PowerLoadArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_PowerLoadArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);

			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_POWERLOAD, PR_POWERLOAD_RPARAMTYPE, g_pPRBlock->m_PowerLoadArray[i].nRParamType));
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_POWERLOAD, PR_POWERLOAD_MSMODEL, g_pPRBlock->m_PowerLoadArray[i].bMSModel));
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_POWERLOAD, PR_POWERLOAD_EQLOAD, g_pPRBlock->m_PowerLoadArray[i].bEQLoad));

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_ACLINE)
	{
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
		{
			if (strlen(szParamSrc) > 0)
			{
				if (stricmp(szParamSrc, g_PRMemDBInterface.PRGetFieldEnumString(PR_ACLINE, PR_ACLINE_RPARAMTYPE, g_pPRBlock->m_ACLineArray[i].nRParamType)) != 0)
					continue;
			}

			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_ACLineArray[i].szName);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_ACLineArray[i].fkVI);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_ACLineArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_ACLINE, PR_ACLINE_RPARAMTYPE, g_pPRBlock->m_ACLineArray[i].nRParamType));

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_WIND)
	{
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_WIND]; i++)
		{
			if (strlen(szParamSrc) > 0)
			{
				if (stricmp(szParamSrc, g_PRMemDBInterface.PRGetFieldEnumString(PR_WIND, PR_WIND_RPARAMTYPE, g_pPRBlock->m_WindArray[i].nRParamType)) != 0)
					continue;
			}

			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_WindArray[i].szName);
			sprintf(szBuf, "%.2f/%.2f", g_pPRBlock->m_WindArray[i].fkVI, g_pPRBlock->m_WindArray[i].fkVJ);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_WindArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_WindArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_WIND, PR_WIND_RPARAMTYPE, g_pPRBlock->m_WindArray[i].nRParamType));

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_HVDC)
	{
		((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->EnableWindow(TRUE);
		((CButton*)GetDlgItem(IDC_USE_COMPARAM))->EnableWindow(FALSE);
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_HVDC]; i++)
		{
			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_HVDCArray[i].szName);
			sprintf(szBuf, "%.2f", g_pPRBlock->m_HVDCArray[i].fkVI);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_HVDCArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_HVDCArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			nCol++;

			m_lstDevParam.SetItemText(nRow, nCol++, g_PRMemDBInterface.PRGetFieldEnumString(PR_HVDC, PR_HVDC_MSMODEL, g_pPRBlock->m_HVDCArray[i].bMSModel));

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_TCSC)
	{
		((CButton*)GetDlgItem(IDC_USE_COMPARAM))->EnableWindow(FALSE);
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
		{
			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_TCSCArray[i].szName);
			nCol++;
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_TCSC)
	{
		((CButton*)GetDlgItem(IDC_USE_COMPARAM))->EnableWindow(FALSE);
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
		{
			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_TCSCArray[i].szName);
			nCol++;
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_TCSCArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}
	else if (nPRParamDevType[nTable] == PR_UPFC)
	{
		((CButton*)GetDlgItem(IDC_USE_COMPARAM))->EnableWindow(FALSE);
		for (i=0; i<(int)g_pPRBlock->m_nRecordNum[PR_UPFC]; i++)
		{
			sprintf(szBuf, "%d", nRow+1);
			m_lstDevParam.InsertItem(nRow, szBuf);
			m_lstDevParam.SetItemData(nRow, nRow);

			nCol=1;
			m_lstDevParam.SetItemText(nRow, nCol++, g_pPRBlock->m_UPFCArray[i].szName);
			sprintf(szBuf, "%f", g_pPRBlock->m_UPFCArray[i].fRerr);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPRBlock->m_UPFCArray[i].fTrep);	m_lstDevParam.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

	int		nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDevColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;

		m_lstDevParam.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_lstDevParam.GetColumnWidth(nCol);
		m_lstDevParam.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =m_lstDevParam.GetColumnWidth(nCol);

		m_lstDevParam.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (nSelItem >= 0)
	{
		m_lstDevParam.SetItemState(nSelItem,LVIS_SELECTED, 0xffff);
		m_lstDevParam.EnsureVisible(nSelItem, FALSE);
	}
}

void CBpaPRParamDevDialog::OnNMClickDevparamList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	POSITION pos=m_lstDevParam.GetFirstSelectedItemPosition();
	if (pos)
	{
		int	nCol=2;
		int	nItem=m_lstDevParam.GetNextSelectedItem(pos);
		GetDlgItem(IDC_RERR)->		SetWindowText(m_lstDevParam.GetItemText(nItem, nCol++));
		GetDlgItem(IDC_TREP)->		SetWindowText(m_lstDevParam.GetItemText(nItem, nCol++));
		nCol++;

		if (stricmp(m_lstDevParam.GetItemText(nItem, nCol++), "��") == 0)
			((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->SetCheck(1);
		else
			((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->SetCheck(0);

		if (stricmp(m_lstDevParam.GetItemText(nItem, nCol++), "��") == 0)
			((CButton*)GetDlgItem(IDC_EQ_MODEL))->SetCheck(1);
		else
			((CButton*)GetDlgItem(IDC_EQ_MODEL))->SetCheck(0);
	}
	*pResult = 0;
}

void CBpaPRParamDevDialog::OnBnClickedUseComParameter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int		nTable = pComboBox->GetCurSel();
	if (nTable == CB_ERR)
		return;

	POSITION pos=m_lstDevParam.GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=m_lstDevParam.GetNextSelectedItem(pos);
		g_BpaPRParam.SetBpaPRComParam(g_pPRBlock, nPRParamDevType[nTable], m_lstDevParam.GetItemText(nItem, 1));
	}
	RefreshPRParamDev();
}

void CBpaPRParamDevDialog::OnBnClickedSetDevparam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	double	fRerr, fTrep;
	char	szBuf[260];

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int			nTable = pComboBox->GetCurSel();
	if (nTable == CB_ERR)
		return;

	GetDlgItem(IDC_RERR)->		GetWindowText(szBuf, 260);	fRerr = atof(szBuf);
	GetDlgItem(IDC_TREP)->		GetWindowText(szBuf, 260);	fTrep = atof(szBuf);

	POSITION pos=m_lstDevParam.GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=m_lstDevParam.GetNextSelectedItem(pos);
		if (nPRParamDevType[nTable] == PR_ACBUS)
		{
			for (i=1; i<g_pPRBlock->m_nRecordNum[PR_ACBUS]; i++)
			{
				if (stricmp(g_pPRBlock->m_ACBusArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_ACBusArray[i].fRerr = fRerr;
					g_pPRBlock->m_ACBusArray[i].fTrep = fTrep;
					g_pPRBlock->m_ACBusArray[i].nRParamType = PRDevice_RParamType_Device;
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_GENERATOR)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_GENERATOR]; i++)
			{
				if (stricmp(g_pPRBlock->m_GeneratorArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_GeneratorArray[i].fRerr = fRerr;
					g_pPRBlock->m_GeneratorArray[i].fTrep = fTrep;
					g_pPRBlock->m_GeneratorArray[i].nRParamType = PRDevice_RParamType_Device;
					g_pPRBlock->m_GeneratorArray[i].bMSModel = ((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->GetCheck();
					g_pPRBlock->m_GeneratorArray[i].bEQGen = ((CButton*)GetDlgItem(IDC_EQ_MODEL))->GetCheck();
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_POWERLOAD)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_POWERLOAD]; i++)
			{
				if (stricmp(g_pPRBlock->m_PowerLoadArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_PowerLoadArray[i].fRerr = fRerr;
					g_pPRBlock->m_PowerLoadArray[i].fTrep = fTrep;
					g_pPRBlock->m_PowerLoadArray[i].nRParamType = PRDevice_RParamType_Device;
					g_pPRBlock->m_PowerLoadArray[i].bMSModel = ((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->GetCheck();
					g_pPRBlock->m_PowerLoadArray[i].bEQLoad = ((CButton*)GetDlgItem(IDC_EQ_MODEL))->GetCheck();
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_ACLINE)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_ACLINE]; i++)
			{
				if (stricmp(g_pPRBlock->m_ACLineArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_ACLineArray[i].fRerr = fRerr;
					g_pPRBlock->m_ACLineArray[i].fTrep = fTrep;
					g_pPRBlock->m_ACLineArray[i].nRParamType = PRDevice_RParamType_Device;
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_WIND)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_WIND]; i++)
			{
				if (stricmp(g_pPRBlock->m_WindArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_WindArray[i].fRerr = fRerr;
					g_pPRBlock->m_WindArray[i].fTrep = fTrep;
					g_pPRBlock->m_WindArray[i].nRParamType = PRDevice_RParamType_Device;
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_HVDC)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_HVDC]; i++)
			{
				if (stricmp(g_pPRBlock->m_HVDCArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_HVDCArray[i].fRerr = fRerr;
					g_pPRBlock->m_HVDCArray[i].fTrep = fTrep;
					g_pPRBlock->m_HVDCArray[i].bMSModel = ((CButton*)GetDlgItem(IDC_MSTATE_MODEL))->GetCheck();
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_TCSC)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_TCSC]; i++)
			{
				if (stricmp(g_pPRBlock->m_TCSCArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_TCSCArray[i].fRerr = fRerr;
					g_pPRBlock->m_TCSCArray[i].fTrep = fTrep;
					break;
				}
			}
		}
		else if (nPRParamDevType[nTable] == PR_UPFC)
		{
			for (i=0; i<g_pPRBlock->m_nRecordNum[PR_UPFC]; i++)
			{
				if (stricmp(g_pPRBlock->m_UPFCArray[i].szName, m_lstDevParam.GetItemText(nItem, 1)) == 0)
				{
					g_pPRBlock->m_UPFCArray[i].fRerr = fRerr;
					g_pPRBlock->m_UPFCArray[i].fTrep = fTrep;
					break;
				}
			}
		}
	}
	RefreshPRParamDev();
}

void CBpaPRParamDevDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPRParamDev();
}

void CBpaPRParamDevDialog::OnCbnSelchangeParamsrcCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPRParamDev();
}