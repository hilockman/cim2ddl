// FStateDetailDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaGenRAdequacyUI.h"
#include "PRFStateDetailDialog.h"


// CFStateDetailDialog �Ի���
IMPLEMENT_DYNAMIC(CPRFStateDetailDialog, CDialog)

CPRFStateDetailDialog::CPRFStateDetailDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPRFStateDetailDialog::IDD, pParent)
{
	m_pParent = pParent;
}

CPRFStateDetailDialog::~CPRFStateDetailDialog()
{
}

void CPRFStateDetailDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPRFStateDetailDialog, CDialog)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDCANCEL, &CPRFStateDetailDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CFStateDetailDialog ��Ϣ��������

static	char*	lpszFDevColumn[]=
{
	"�豸����",
	"�豸����",
};

static	char*	lpszOvLmtDevColumn[]=
{
	"�豸����",
	"�豸����",
	"Խ��ֵ",
	"����ֵ",
	"�ֵ",
};

static	char*	lpszOvLmtAdColumn[]=
{
	"���",
	"�豸����",
	"�豸����",
	"���ʵ�����",
};

static	char*	lpszPRMStateColumn[]=
{
	"���",
	"�豸����",
	"�豸����",
	"�豸״̬",
};

BOOL CPRFStateDetailDialog::Create(CWnd *pParentWnd)
{
	return CDialog::Create(IDD, pParentWnd);
}

BOOL CPRFStateDetailDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FDEVICE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszFDevColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszFDevColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTDEV_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszOvLmtDevColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszOvLmtDevColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTAD_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszOvLmtAdColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszOvLmtAdColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszPRMStateColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i,	lpszPRMStateColumn[i],	LVCFMT_LEFT,	100);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

BOOL CPRFStateDetailDialog::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (pMsg->message == WM_KEYDOWN)
	{
		switch ((int)pMsg->wParam)
		{
		case VK_RETURN:
			return true; 
			break;
		case VK_ESCAPE:
			m_pParent->PostMessage(UM_HIDE_FSTATEDETAIL, 1, 0);
			return true;
		}
	}
	// Tooltip management
	return CDialog::PreTranslateMessage(pMsg);
}

void CPRFStateDetailDialog::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	if (m_pParent)	m_pParent->PostMessage(UM_HIDE_FSTATEDETAIL, 1, 0);

	CDialog::OnClose();
}

void CPRFStateDetailDialog::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_pParent)	m_pParent->PostMessage(UM_HIDE_FSTATEDETAIL, 1, 0);

	//OnCancel();
}

void CPRFStateDetailDialog::RefreshList(const int nFState)
{
	RefreshFDeviceList(nFState);
	RefreshMStateList(nFState);
	RefreshOvLmtDevList(nFState);
	RefreshOvLmtAdList(nFState);
}

void	CPRFStateDetailDialog::RefreshFDeviceList(const int nFState)
{
	register int	i;
	int		nRow, nCol;
	int		nField;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FDEVICE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEFDEV]; i++)
	{
		if (g_pPRBlock->m_FStateFDevArray[i].nFState == nFState)
		{
			pListCtrl->InsertItem(nRow, PRGetTableDesp(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp));	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			nField=PRGetFieldIndex(g_pPRBlock->m_FStateFDevArray[i].nFDevTyp, "Name");
			PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateFDevArray[i].nFDevTyp, nField, g_pPRBlock->m_FStateFDevArray[i].nFDevIdx, szBuf);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszFDevColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPRFStateDetailDialog::RefreshMStateList(const int nFState)
{
	register int	i;
	int		nRow, nCol;
	int		nTable, nRecord, nField;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_MSTATE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_System.nMStateDevNum; i++)
	{
		sprintf(szBuf, "%d", i+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nTable =g_pPRBlock->m_FStateMStateArray[g_pPRBlock->m_System.nMStateDevNum*g_pPRBlock->m_FStateArray[nFState].nMSoutIndex+i].nMSDevType;
		nRecord=g_pPRBlock->m_FStateMStateArray[g_pPRBlock->m_System.nMStateDevNum*g_pPRBlock->m_FStateArray[nFState].nMSoutIndex+i].nMSDevIdx;

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, PRGetTableDesp(nTable));
		nField=PRGetFieldIndex(nTable, "Name");
		PRGetRecordValue(g_pPRBlock, nTable, nField, nRecord, szBuf);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_FStateMStateArray[g_pPRBlock->m_System.nMStateDevNum*g_pPRBlock->m_FStateArray[nFState].nMSoutIndex+i].fStatePout);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszPRMStateColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPRFStateDetailDialog::RefreshOvLmtDevList(const int nFState)
{
	register int	i;
	int		nField, nRow, nCol;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTDEV_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEOVLDEV]; i++)
	{
		if (g_pPRBlock->m_FStateOvlDevArray[i].nFState == nFState)
		{
			pListCtrl->InsertItem(nRow, PRGetTableDesp(g_pPRBlock->m_FStateOvlDevArray[i].nDevTyp));	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			nField=PRGetFieldIndex(g_pPRBlock->m_FStateOvlDevArray[i].nDevTyp, "Name");	PRGetRecordValue(g_pPRBlock, g_pPRBlock->m_FStateOvlDevArray[i].nDevTyp, nField, g_pPRBlock->m_FStateOvlDevArray[i].nDevIdx, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f[%.1f]", g_pPRBlock->m_FStateOvlDevArray[i].fOvLmtP, g_PRAdequacy.m_PRAdequacySetting.fDc2AcFactor*g_pPRBlock->m_FStateOvlDevArray[i].fOvLmtP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f[%.1f]", g_pPRBlock->m_FStateOvlDevArray[i].fAdLmtP, g_PRAdequacy.m_PRAdequacySetting.fDc2AcFactor*g_pPRBlock->m_FStateOvlDevArray[i].fAdLmtP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", g_pPRBlock->m_FStateOvlDevArray[i].fRated);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszOvLmtDevColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPRFStateDetailDialog::RefreshOvLmtAdList(const int nFState)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	if (nFState < 0 || nFState >= g_pPRBlock->m_nRecordNum[PR_FSTATE])
		goto _Out;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OVLMTAD_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPRBlock->m_nRecordNum[PR_FSTATEOVLAD]; i++)
	{
		if (g_pPRBlock->m_FStateOvlAdArray[i].nFState == nFState)
		{
			sprintf(szBuf,"%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			if (g_pPRBlock->m_FStateOvlAdArray[i].nAdDevTyp == PR_ACBUS)		pListCtrl->SetItemText(nRow, nCol++, "����");
			else if (g_pPRBlock->m_FStateOvlAdArray[i].nAdDevTyp == PR_GEN)	pListCtrl->SetItemText(nRow, nCol++, "�����");
			else															pListCtrl->SetItemText(nRow, nCol++, "ĸ��");

			PRGetRecordValue(g_pPRBlock, PR_ACBUS, PR_ACBUS_NAME, g_pPRBlock->m_FStateOvlAdArray[i].nAdDevBus, szBuf);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%f", g_pPRBlock->m_FStateOvlAdArray[i].fAdValue);										pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

_Out:
	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszOvLmtAdColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}
