#pragma once
#include "afxcmn.h"
#include "../../../../../Common/MFCControls/MFCListCtrlEx.h"

// CPRParamDevDialog �Ի���

class CBpaPRParamDevDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaPRParamDevDialog)

public:
	CBpaPRParamDevDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaPRParamDevDialog();

// �Ի�������
	enum { IDD = IDD_PRPARAM_DEV_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnNMClickDevparamList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedSetDevparam();
	afx_msg void OnCbnSelchangeDevtypeCombo();
	afx_msg void OnBnClickedUseComParameter();
	afx_msg void OnCbnSelchangeParamsrcCombo();
	DECLARE_MESSAGE_MAP()
private:
	CMFCListCtrlEx m_lstDevParam;
	void RefreshPRParamDev();
public:
};
