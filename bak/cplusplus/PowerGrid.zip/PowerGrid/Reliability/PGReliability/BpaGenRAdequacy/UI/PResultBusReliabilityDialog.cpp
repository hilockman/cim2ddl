// BusResultListDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BpaGenRAdequacyUI.h"
#include "PResultBusReliabilityDialog.h"

// CPResultBusReliabilityDialog �Ի���
static	char*	lpszRBusResultColumn[]=
{
	"���",
	"ĸ������",
	"ĸ�ߵ�ѹ",
	"����",
	"�и��ɸ���",					
	"�и���Ƶ��(��/��)",			
	"�и��ɳ���ʱ��(Сʱ/��)",		
	"ÿ���и��ɳ���ʱ��(Сʱ/��)",	
	"�����г�����ֵ(MW/��)",		
	"������������ֵ(MWh/��)",		
	"ϵͳ��������ָ��(MWh/MW.��)",	
	"ϵͳͣ��ָ��(MW/MW.��)",		
	"���س̶�ָ��(ϵͳ��/��)",		
};

IMPLEMENT_DYNAMIC(CPResultBusReliabilityDialog, CDialog)

CPResultBusReliabilityDialog::CPResultBusReliabilityDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPResultBusReliabilityDialog::IDD, pParent)
{

}

CPResultBusReliabilityDialog::~CPResultBusReliabilityDialog()
{
}

void CPResultBusReliabilityDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPResultBusReliabilityDialog, CDialog)
	ON_BN_CLICKED(IDC_SHOW_HASVALUE_ONLY, &CPResultBusReliabilityDialog::OnBnClickedShowHasvalueOnly)
END_MESSAGE_MAP()


// CPResultBusReliabilityDialog ��Ϣ��������

BOOL CPResultBusReliabilityDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int		nColumn;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BUSRESULT_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRBusResultColumn)/sizeof(char*); nColumn++)
		pListCtrl->InsertColumn(nColumn, lpszRBusResultColumn[nColumn],	LVCFMT_LEFT,	100);

	((CButton*)GetDlgItem(IDC_SHOW_HASVALUE_ONLY))->SetCheck(TRUE);

	RefreshPRBusResultList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPResultBusReliabilityDialog::RefreshUI()
{
	RefreshPRBusResultList();
}

void CPResultBusReliabilityDialog::RefreshPRBusResultList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	CButton*		pButon=(CButton*)GetDlgItem(IDC_SHOW_HASVALUE_ONLY);
	unsigned char	bShowHasVOnly=pButon->GetCheck();

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BUSRESULT_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=1; i<g_pPRBlock->m_nRecordNum[PR_ACBUS]; i++)
	{
		if (bShowHasVOnly)
		{
			if (g_pPRBlock->m_ACBusArray[i].fPLC <= FLT_MIN)
				continue;
		}
		sprintf(szBuf,"%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPRBlock->m_ACBusArray[i].szName);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_ACBusArray[i].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.2f", g_pPRBlock->m_ACBusArray[i].fLoadP);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fPLC);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fEFLC);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fEDLC);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fADLC);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fELC);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fEENS);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fBPECI);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fBPII);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPRBlock->m_ACBusArray[i].fSI);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (i=0; i<sizeof(lpszRBusResultColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		if (nRow <= 0)
		{
			pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
			nHeaderWidth = pListCtrl->GetColumnWidth(i);
		}

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPResultBusReliabilityDialog::OnBnClickedShowHasvalueOnly()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPRBusResultList();
}

void CPResultBusReliabilityDialog::ExcelOut(ExcelAccessor* pXls)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BUSRESULT_LIST);
	if (pListCtrl->GetItemCount() <= 0)
		return;

	PrintMessage("Excel����ĸ�߼�������ʼ");

	int		nRow, nCol, nFieldNum;

	pXls->AddSheet(_T("ĸ�߿ɿ��Լ�����"));
	pXls->SetCurSheet(_T("ĸ�߿ɿ��Լ�����"));

	nFieldNum=sizeof(lpszRBusResultColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		pXls->AddCell(CString(lpszRBusResultColumn[nCol]));
	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		pXls->NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			pXls->AddCell(pListCtrl->GetItemText(nRow, nCol));
	}

	PrintMessage("Excel����ĸ�߼��������");
}
