
// PRelibilityUIDlg.h : ͷ�ļ�
//

#pragma once

#include "PResultSampleStateDialog.h"
#include "PResultBusReliabilityDialog.h"
#include "../../../../../Common/MFCControls/MFCListCtrlEx.h"

//	Ϊ����ԭ�ȵ����ݰ汾����
#include "../../PRParam.h"

// CPRelibilityUIDlg �Ի���

class CBpaGenAdequacyUIDlg : public CDialog
{
// ����
public:
	CBpaGenAdequacyUIDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BPA_GENADEQUACY_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

public:
	void	PrintMessage(char* pformat, ...);

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	afx_msg void OnBnClickedGenAdequacy();

	afx_msg void OnBnClickedDatBrowse();
	afx_msg void OnBnClickedSwiBrowse();
	afx_msg void OnBnClickedRParamBrowse();
	afx_msg void OnBnClickedDatErase();
	afx_msg void OnBnClickedSwiErase();
	afx_msg void OnBnClickedRParamErase();
	afx_msg void OnBnClickedRParamEdit();

	afx_msg void OnBnClickedClearMesg();

	afx_msg void OnBnClickedSimSaveAsExcel();
	afx_msg void OnBnClickedCopSaveAsExcel();

	afx_msg LRESULT OnAdequacyEstimateBegin(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnAdequacyEstimating(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnAdequacyEstimateEnded(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedCoptInit();
	afx_msg void OnBnClickedCopt();
	afx_msg void OnBnClickedAcflow();
	DECLARE_MESSAGE_MAP()

private:
	int		GetTextLen(LPCTSTR lpszText);

	void	RefreshPRSysResultList();

	void	RefreshCOPTList();

	void	RefreshParam();
	int		PreparePRData(const int nSampleType=0);
	void	LoadBpaModelFile(void);

private:
	CMFCTabCtrl						m_wndTab;
	CMFCListCtrlEx					m_wndListPRSysResult;
	CMFCListCtrlEx					m_wndListGenProb, m_wndListCOPT;
	CPResultSampleStateDialog		m_wndSampleState;
	CPResultBusReliabilityDialog	m_wndBusReliability;

private:

private:
	tagPRSetting	m_PRSetting;
	CPRParam		m_PRParam;
public:
	CPRCopTable		m_CopTable;

private:
	int				m_nAdequacyEstimateNum;
	HANDLE			m_hAdequacyEstimateHandle;
public:
	double m_fCoptCapacityStep;
};

