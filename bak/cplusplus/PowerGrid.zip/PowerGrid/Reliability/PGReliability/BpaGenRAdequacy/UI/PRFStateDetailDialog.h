#pragma once

// CFStateDetailDialog �Ի���
#define		UM_SHOW_FSTATEDETAIL	WM_APP+2000
#define		UM_HIDE_FSTATEDETAIL	WM_APP+2001

class CPRFStateDetailDialog : public CDialog
{
	DECLARE_DYNAMIC(CPRFStateDetailDialog)

public:
	CPRFStateDetailDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPRFStateDetailDialog();
	void	RefreshList(const int nFState = 0);

	BOOL Create(CWnd* pParentWnd);
	CWnd*				m_pParent;

// �Ի�������
	enum { IDD = IDD_FSTATE_DETAIL_DIALOG };

protected:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnBnClickedCancel();
	DECLARE_MESSAGE_MAP()

private:
	void	RefreshFDeviceList(const int nFState);
	void	RefreshMStateList(const int nFState);
	void	RefreshOvLmtDevList(const int nFState);
	void	RefreshOvLmtAdList(const int nFState);
};
