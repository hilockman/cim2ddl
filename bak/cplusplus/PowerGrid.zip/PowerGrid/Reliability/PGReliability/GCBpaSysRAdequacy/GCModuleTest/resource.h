//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GCModuleTest.rc
//
#define IDD_GCMODULETEST_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_T1                          1000
#define IDC_BPA_LOADER                  1000
#define IDC_T2                          1001
#define IDC_BPA_2PR                     1001
#define IDC_BUTTON3                     1002
#define IDC_T3                          1002
#define IDC_STATE_SAMPLE                1002
#define IDC_BUTTON4                     1003
#define IDC_STATE_ESTIMATE              1003
#define IDC_BUTTON5                     1004
#define IDC_RELIABILITY_INDEX           1004
#define IDC_REMOTE_PORT                 1005
#define IDC_NETWORK_DATAREADY           1006
#define IDC_REMOTE_ADDR                 1007
#define IDC_NETWORK_STATEESTIMATE       1008
#define IDC_NETWORK_STATEESTIMATE2      1009
#define IDC_NETWORK_JOBFINISHED         1009
#define IDC_LOCAL_PORT                  1010
#define IDC_ANA_MINSTATEPROB            1011
#define IDC_CLEAR_MESG                  1012
#define IDC_BPA_RPARAMFILE              1013
#define IDC_BPA_RPARAM_FILE             1013
#define IDC_MESG_LIST                   1014
#define IDC_BPADAT_FILE                 1015
#define IDC_BPASWI_FILE                 1016
#define IDC_LOCAL_PORT2                 1017
#define IDC_THREAD_NUM                  1017
#define IDC_RPARAM_BROWSE               1019
#define IDC_DAT_BROWSE                  1023
#define IDC_DC2AC_FACTOR                1024
#define IDC_FST_MAXCUMUPROB             1050
#define IDC_FST_MAXSTATE                1051
#define IDC_FST_MINSTATEPROB            1052
#define IDC_ISLAND_MINIMAL_GLRATIO      1059
#define IDC_LINE_LIMIT                  1060
#define IDC_MAXFAULT_BRAN               1065
#define IDC_MAXFAULT_GEN                1066
#define IDC_MCS_MINSTATEPROB            1067
#define IDC_MCS_SIMULATETIME            1068
#define IDC_PRCOMP_ALL                  1078
#define IDC_PRCOMP_GEN                  1079
#define IDC_PRCOMP_LT                   1080
#define IDC_STS_MAXSTATE                1101
#define IDC_SWI_BROWSE                  1102
#define IDC_TRAN_LIMIT                  1108
#define IDC_AUXLOAD_ADJUST              1109
#define IDC_UPFC_ADJUSTRC               1110
#define IDC_EQGEN_ADJUST                1111
#define IDC_GEN_ELIMIT                  1112
#define IDC_UPFC_ELIMIT                 1113
#define IDC_EQLOAD_ADJUST               1116
#define IDC_GENBUS_LOAD_ASAUX           1158
#define IDC_MONTECARLO                  1192
#define IDC_FASTSORT                    1193
#define IDC_STATESAMPLE                 1194
#define IDC_ANALYTICAL                  1195

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
