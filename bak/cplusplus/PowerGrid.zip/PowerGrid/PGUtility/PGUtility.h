#pragma once
#include "../../MemDB/PGMemDB/PGMemDB.h"
#include "PGUtilityDefine.h"

typedef	struct _PGTLine
{
	std::vector<int>	nLineArray;
}	tagPGTLine;

typedef	struct
{
	int		nBorderNode;
	int		nBoundDevice;
	double	fP;
	double	fQ;
}	tagBoundDevice;

typedef	struct
{
	std::vector<int>	nBoundBusArray;
	std::vector<int>	nLineArray;
	std::vector<int>	nTranArray;
	double				fLoadP;
}	tagRadiate;

class CPGUtility
{
public:
	CPGUtility(void);
	~CPGUtility(void);

public:
	void	LowVGen2Load(tagPGBlock* pBlock, const double fLowVThreshold);
	void	EraseLowVPCap(tagPGBlock* pBlock, const double fLowVThreshold);
	void	LowVLine2Load(tagPGBlock* pBlock, const double fLowVThreshold);
	void	EraseLowVNet(tagPGBlock* pBlock, const double fMinimalVoltage);

	void	MergeZeroXLine(tagPGBlock* pBlock, const double fZeroZ);
	void	UpgradeVoltageOfSynchronousMachine(tagPGBlock* pBlock);
	void	UpgradeVoltageOfEnergyConsumer(tagPGBlock* pBlock);

	void	GetVacantTran(tagPGBlock* pBlock, std::vector<int>& nVacantArray);
	void	GetVacantWind(tagPGBlock* pBlock, std::vector<int>& nVacantArray);
	void	EraseVacantTran(tagPGBlock* pBlock);
	void	EraseVacantWind(tagPGBlock* pBlock);

private:
	int		GetNodeUpVoltageBus(tagPGBlock* pBlock, const int nJudgeNode);

private:
	int		IsNodeVacant(tagPGBlock* pBlock, const int nCheckNode);
	void	SetVacantState(tagPGBlock* pBlock, const int nVacantNode, 
				std::vector<unsigned char>& bBusStateArray, 
				std::vector<unsigned char>& bSCapStateArray, 
				std::vector<unsigned char>& bBreakerStateArray, 
				std::vector<unsigned char>& bSwitchStateArray, 
				std::vector<unsigned char>& bSwGroundStateArray);

private:
	void	GetTLine(tagPGBlock* pBlock, const int nTLine, std::vector<int>& nTLineArray);
	void	FormTLine(tagPGBlock* pBlock);
	void	GetParallelLine(tagPGBlock* pBlock, const int nJudgeLine, std::vector<int>& nParallelArray);
	void	GetLinePQ(tagPGBlock* pBlock, const int nLine, const int nMeasureNode, double& fP, double& fQ);
	void	GetTranPQ(tagPGBlock* pBlock, const int nWind, const int nMeasureNode, double& fP, double& fQ);

public:
	void	Decompose(tagPGBlock* pBlock, const double fOpenRingVolt);

public:
	std::vector<tagPGTLine>			m_TLineArray;
	std::vector<int>				m_nLineBelongToTLineArray;

	std::vector<unsigned char>		m_bRingedLineArray;
	std::vector<unsigned char>		m_bRingedTranArray;
	std::vector<tagBoundDevice>		m_BoundLineArray;
	std::vector<tagBoundDevice>		m_BoundTranArray;
	std::vector<int>				m_nHubSubstationArray;
	std::vector<tagRadiate>			m_RadiateArray;

};

extern	void	AddMessage(const char* lpszFormat, ...);
