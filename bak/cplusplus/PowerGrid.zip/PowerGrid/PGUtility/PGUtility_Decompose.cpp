#include "stdafx.h"
#include "PGUtility.h"

void	CPGUtility::GetTLine(tagPGBlock* pBlock, const int nTLine, std::vector<int>& nTLineArray)
{
	register int	i, j;
	int	nLine, nDev, nMidL, nMidH;
	unsigned char	bIIsT, bZIsT;
	int	nNodeNum, nNodeArray[400];

	std::vector<unsigned char>	bLineProcArray;
	bLineProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	nTLineArray.clear();

	nTLineArray.push_back(nTLine);
	bLineProcArray[nTLine]=1;

	nMidL=0;
	nMidH=(int)nTLineArray.size();
	while (1)
	{
		for (nLine=nMidL; nLine<nMidH; nLine++)
		{
			if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeI))
			{
				PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeI, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				for (i=0; i<nNodeNum; i++)
				{
					for (j=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; j++)
					{
						nDev=pBlock->m_EdgeACLineSegmentArray[j].nACLineSegment;
						bIIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI);
						bZIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ);
						//TRACE("TLine=%s %d %d %d\n", pBlock->m_ACLineSegmentArray[nDev].szName, bLineProcArray[nDev], bIIsT, bZIsT);
						if (!bLineProcArray[nDev] && (bIIsT || bZIsT))
						{
							nTLineArray.push_back(nDev);
							bLineProcArray[nDev]=1;
						}
					}
				}
			}
			if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeJ))
			{
				PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeJ, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				for (i=0; i<nNodeNum; i++)
				{
					for (j=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; j++)
					{
						nDev=pBlock->m_EdgeACLineSegmentArray[j].nACLineSegment;
						bIIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI);
						bZIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ);
						//TRACE("TLine=%s %d %d %d\n", pBlock->m_ACLineSegmentArray[nDev].szName, bLineProcArray[nDev], bIIsT, bZIsT);
						if (!bLineProcArray[nDev] && (bIIsT || bZIsT))
						{
							nTLineArray.push_back(nDev);
							bLineProcArray[nDev]=1;
						}
					}
				}
			}
		}
		if (nMidH == nTLineArray.size())
			break;
		nMidL=nMidH;
		nMidH=(int)nTLineArray.size();
	}
}

void	CPGUtility::FormTLine(tagPGBlock* pBlock)
{
	register int	i;
	int			nLine;
	tagPGTLine	lBuf;
	std::vector<unsigned char>	bLineProcArray;
	std::vector<int>			nTLineArray;

	bLineProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	m_TLineArray.clear();
	m_nLineBelongToTLineArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		m_nLineBelongToTLineArray[i]=-1;

	for (nLine=0; nLine<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		if (bLineProcArray[nLine])
			continue;
		bLineProcArray[nLine]=1;

		if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nLine].nNodeI) || PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nLine].nNodeJ))
		{
			GetTLine(pBlock, nLine, nTLineArray);
			for (i=0; i<(int)nTLineArray.size(); i++)
				bLineProcArray[nTLineArray[i]]=1;

			lBuf.nLineArray.clear();
			for (i=0; i<(int)nTLineArray.size(); i++)
			{
				lBuf.nLineArray.push_back(nTLineArray[i]);
			}
			m_TLineArray.push_back(lBuf);
		}
	}
	for (nLine=0; nLine<(int)m_TLineArray.size(); nLine++)
	{
		for (i=0; i<(int)m_TLineArray[nLine].nLineArray.size(); i++)
		{
			m_nLineBelongToTLineArray[m_TLineArray[nLine].nLineArray[i]]=nLine;
		}
	}
}

void	CPGUtility::GetParallelLine(tagPGBlock* pBlock, const int nJudgeLine, std::vector<int>& nParallelArray)
{
	nParallelArray.clear();

	register int	i, j;
	int		nBranI, nNodeINum, nNodeIArray[400];
	int		nBranJ, nNodeJNum, nNodeJArray[400];
	int		nNodeI=pBlock->m_ACLineSegmentArray[nJudgeLine].nNodeI;
	int		nNodeJ=pBlock->m_ACLineSegmentArray[nJudgeLine].nNodeJ;

	PGTraverseVolt(pBlock, nNodeI, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeINum, nNodeIArray);
	PGTraverseVolt(pBlock, nNodeJ, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeJNum, nNodeJArray);
	for (nNodeI=0; nNodeI<nNodeINum; nNodeI++)
	{
		for (i=pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]+1].nACLineSegmentRange; i++)
		{
			nBranI=pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;
			for (nNodeJ=0; nNodeJ<nNodeJNum; nNodeJ++)
			{
				for (j=pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]+1].nACLineSegmentRange; j++)
				{
					nBranJ=pBlock->m_EdgeACLineSegmentArray[j].nACLineSegment;

					if (m_nLineBelongToTLineArray[nBranI] >= 0 && m_nLineBelongToTLineArray[nBranJ] >= 0)	//	������·����T����·
					{
						if (m_nLineBelongToTLineArray[nBranI] == m_nLineBelongToTLineArray[nBranJ])			//	������·����ͬһT����·��
						{
							nParallelArray.push_back(nBranI);
							nParallelArray.push_back(nBranJ);
						}
					}
					else if (m_nLineBelongToTLineArray[nBranI] < 0 && m_nLineBelongToTLineArray[nBranJ] < 0)
					{
						if (nBranI == nBranJ)
							nParallelArray.push_back(nBranI);
					}
				}
			}
		}
	}

	i=0;
	while (i < (int)nParallelArray.size())
	{
		nBranI=0;
		for (j=i+1; j<(int)nParallelArray.size(); j++)
		{
			if (nParallelArray[i] == nParallelArray[j])
			{
				nBranI=1;
				break;
			}
		}
		if (nBranI)
			nParallelArray.erase(nParallelArray.begin()+i);
		else
			i++;
	}
}

void	CPGUtility::GetLinePQ(tagPGBlock* pBlock, const int nLine, const int nMeasureNode, double& fP, double& fQ)
{
	fP=fQ=0;
	if (pBlock->m_ACLineSegmentArray[nLine].nNodeI == nMeasureNode)
	{
		if (pBlock->m_ACLineSegmentArray[nLine].fPi > -999990)
			fP=pBlock->m_ACLineSegmentArray[nLine].fPi;
		else if (pBlock->m_ACLineSegmentArray[nLine].fPz > -999990)
			fP=-pBlock->m_ACLineSegmentArray[nLine].fPz;

		if (pBlock->m_ACLineSegmentArray[nLine].fQi > -999990)
			fQ=pBlock->m_ACLineSegmentArray[nLine].fQi;
	}
	else
	{
		if (pBlock->m_ACLineSegmentArray[nLine].fPz > -999990)
			fP=pBlock->m_ACLineSegmentArray[nLine].fPz;
		else if (pBlock->m_ACLineSegmentArray[nLine].fPi > -999990)
			fP=-pBlock->m_ACLineSegmentArray[nLine].fPi;

		if (pBlock->m_ACLineSegmentArray[nLine].fQz > -999990)
			fQ=pBlock->m_ACLineSegmentArray[nLine].fQz;
	}
}

void	CPGUtility::GetTranPQ(tagPGBlock* pBlock, const int nWind, const int nMeasureNode, double& fP, double& fQ)
{
	register int	i;
	unsigned char	bMeasured;
	double			fBuf;
	std::vector<int>	nWindArray;

	int		nTran=pBlock->m_TransformerWindingArray[nWind].nTran;

	fP=fQ=0;
	if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nMeasureNode)
	{
		if (pBlock->m_TransformerWindingArray[nWind].fPi > -999990)
		{
			fP=pBlock->m_TransformerWindingArray[nWind].fPi;
		}
		else
		{
			if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 1)
			{
				if (pBlock->m_TransformerWindingArray[nWind].fPz > -999990)
					fP=-pBlock->m_TransformerWindingArray[nWind].fPz;
			}
			else
			{
				fBuf=0;
				bMeasured=1;

				nWindArray.clear();
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindH);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindM);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindL);
				for (i=0; i<(int)nWindArray.size(); i++)
				{
					if (nWindArray[i] == nWind)
						continue;

					if (pBlock->m_TransformerWindingArray[nWindArray[i]].bTranMidSide == 1)
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fPz < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fPz; 
					}
					else
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fPi < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fPi; 
					}
				}

				if (bMeasured)
					fP=-fBuf;
			}
		}


		if (pBlock->m_TransformerWindingArray[nWind].fQi > -999990)
		{
			fQ=pBlock->m_TransformerWindingArray[nWind].fQi;
		}
		else
		{
			if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 1)
			{
				if (pBlock->m_TransformerWindingArray[nWind].fQz > -999990)
					fQ=-pBlock->m_TransformerWindingArray[nWind].fQz;
			}
			else
			{
				fBuf=0;
				bMeasured=1;

				nWindArray.clear();
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindH);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindM);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindL);
				for (i=0; i<(int)nWindArray.size(); i++)
				{
					if (nWindArray[i] == nWind)
						continue;

					if (pBlock->m_TransformerWindingArray[nWindArray[i]].bTranMidSide == 1)
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fQz < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fQz; 
					}
					else
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fQi < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fQi; 
					}
				}

				if (bMeasured)
					fQ=-fBuf;
			}
		}
	}
	else
	{
		if (pBlock->m_TransformerWindingArray[nWind].fPz > -999990)
		{
			fP=pBlock->m_TransformerWindingArray[nWind].fPz;
		}
		else
		{
			if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 1)
			{
				if (pBlock->m_TransformerWindingArray[nWind].fPi > -999990)
					fP=-pBlock->m_TransformerWindingArray[nWind].fPi;
			}
			else
			{
				fBuf=0;
				bMeasured=1;

				nWindArray.clear();
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindH);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindM);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindL);
				for (i=0; i<(int)nWindArray.size(); i++)
				{
					if (nWindArray[i] == nWind)
						continue;

					if (pBlock->m_TransformerWindingArray[nWindArray[i]].bTranMidSide == 1)
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fPz < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fPz; 
					}
					else
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fPi < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fPi; 
					}
				}

				if (bMeasured)
					fP=-fBuf;
			}
		}

		if (pBlock->m_TransformerWindingArray[nWind].fQz > -999990)
		{
			fQ=pBlock->m_TransformerWindingArray[nWind].fQz;
		}
		else
		{
			if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 1)
			{
				if (pBlock->m_TransformerWindingArray[nWind].fQi > -999990)
					fQ=-pBlock->m_TransformerWindingArray[nWind].fQi;
			}
			else
			{
				fBuf=0;
				bMeasured=1;

				nWindArray.clear();
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindH);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindM);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindL);
				for (i=0; i<(int)nWindArray.size(); i++)
				{
					if (nWindArray[i] == nWind)
						continue;

					if (pBlock->m_TransformerWindingArray[nWindArray[i]].bTranMidSide == 1)
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fQz < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fQz; 
					}
					else
					{
						if (pBlock->m_TransformerWindingArray[nWindArray[i]].fQi < -999990)
							bMeasured=0;
						else
							fBuf += pBlock->m_TransformerWindingArray[nWindArray[i]].fQi; 
					}
				}

				if (bMeasured)
					fQ=-fBuf;
			}
		}
	}
}

void CPGUtility::Decompose(tagPGBlock* pBlock, const double fOpenRingVolt)
{
	register int	i;
	int		nSub, nVolt, nNode, nDev, nONode, nLine, nWind, nUnitRec1, nUnitRec2;
	unsigned char	bRinged, bFlaged;
	std::vector<int>	nWindArray, nWindNodeArray;
	std::vector<int>	nParallelArray;
	std::vector<unsigned char>	bRingedNodeArray;
	std::vector<unsigned char>	bProcArray;
	std::vector<int>	nBoundNodeArray;

	int		nNodeNum, nOppNodeNum;
	int*	nNodeArray;
	int*	nOppNodeArray;

	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	m_bRingedLineArray.clear();
	m_bRingedTranArray.clear();
	m_BoundLineArray.clear();
	m_BoundTranArray.clear();
	m_nHubSubstationArray.clear();

	nNodeArray=(int*)malloc(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (nNodeArray == NULL)
		return;
	nOppNodeArray=(int*)malloc(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (nOppNodeArray == NULL)
		return;

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pBlock->m_ACLineSegmentArray[i].bOpen=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		pBlock->m_TransformerWindingArray[i].bOpen=0;

	PGMemDBTopo(pBlock);
	PGMemDBStatus(pBlock, 1);
	FormTLine(pBlock);

	//��ʼ����Ϣ����ͣ���豸�ĺϻ�״̬����Ϊ0����ͣ���豸�ĺϻ�״̬����Ϊ1
	bRingedNodeArray.resize(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		bRingedNodeArray[i]=0;

	m_bRingedLineArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (pBlock->m_ACLineSegmentArray[i].bOutage != 0)
			m_bRingedLineArray[i]=0;
		else
			m_bRingedLineArray[i]=1;
	}

	m_bRingedTranArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING], 0);
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
		{
			if (pBlock->m_TransformerWindingArray[i].bOutage != 0)
				m_bRingedTranArray[i]=0;
			else
				m_bRingedTranArray[i]=1;
		}
	}

	//ClearLog();

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	AddMessage("Decompose����ʼ����ʱ%d����\n", nDur);

	//һ���ж���·�Ƿ�ɻ�
	//	�����жϵ�ѹ��·�ϻ������ǵ�Դ�ϻ��ĵ�ѹ�ߺϻ���·�÷֡�
	//	����жϸ�ѹ��·�ϻ����ϻ��жϰ���ѹ�ȼ��жϣ�

	//	1������˫����·����˫����ΪOPEN�������������
	//	2������ڵ���ͨ��Ϊ������·
	//	3������ڵ㲻��ͨ��������е�Դ������·�������е�ԴΪ������·���������д��ڵ�Դ��
	unsigned char	bLowVRing;
	bProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (pBlock->m_ACLineSegmentArray[nDev].bOutage != 0)
			continue;
		if (bProcArray[nDev] != 0)
			continue;

		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > fOpenRingVolt)
			continue;

		bLowVRing=0;
		GetParallelLine(pBlock, nDev, nParallelArray);
		for (i=0; i<(int)nParallelArray.size(); i++)
		{
			bProcArray[nParallelArray[i]]=1;
			pBlock->m_ACLineSegmentArray[nParallelArray[i]].bOpen=1;
		}

		PGTraverseNet(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI, Y_CheckStatus, 0, nNodeNum, nNodeArray);

		bRinged=0;
		for (i=0; i<nNodeNum; i++)
		{
			if (nNodeArray[i] == pBlock->m_ACLineSegmentArray[nDev].nNodeJ)
			{
				bRinged=1;
				break;
			}
		}
		if (bRinged)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fOpenRingVolt)
			{
				bLowVRing=1;
				AddMessage("  ��ѹ�ϻ���·: %s[%s]��%s <-> %s)\n", pBlock->m_ACLineSegmentArray[nDev].szName, pBlock->m_ACLineSegmentArray[nDev].szVoltI, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szSubJ);
				for (i=0; i<(int)nParallelArray.size(); i++)
				{
					pBlock->m_ACLineSegmentArray[nParallelArray[i]].bOpen=1;
					m_bRingedLineArray[nParallelArray[i]]=0;
				}
			}
		}
		if (!bRinged)
		{
			nUnitRec1=nUnitRec2=-1;
			bFlaged=0;
			for (nNode=0; nNode<nNodeNum; nNode++)
			{
				for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
				{
					if (pBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
					{
						nUnitRec1=i;
						bFlaged++;
						break;
					}
				}
				if (nUnitRec1 >= 0)
					break;
			}

			PGTraverseNet(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ, Y_CheckStatus, 0, nOppNodeNum, nOppNodeArray);
			for (nNode=0; nNode<nOppNodeNum; nNode++)
			{
				for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
				{
					if (pBlock->m_SynchronousMachineArray[i].nNode == nOppNodeArray[nNode])
					{
						nUnitRec2=i;
						bFlaged++;
						break;
					}
				}
				if (nUnitRec2 >= 0)
					break;
			}
			if (bFlaged < 2)
			{
				for (nNode=0; nNode<(int)nParallelArray.size(); nNode++)
					m_bRingedLineArray[nParallelArray[nNode]]=0;
			}
			else
			{
				if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fOpenRingVolt)
				{
					//AddMessage("  ��Դ�ϻ���·: %s[%s]��%s <-> %s) ����� (%s.%s) (%s.%s)\n", 
					//	pBlock->m_ACLineSegmentArray[nDev].szName, 
					//	pBlock->m_ACLineSegmentArray[nDev].szVoltI, 
					//	pBlock->m_ACLineSegmentArray[nDev].szSubI, 
					//	pBlock->m_ACLineSegmentArray[nDev].szSubJ, 
					//	pBlock->m_SynchronousMachineArray[nUnitRec1].szSub, pBlock->m_SynchronousMachineArray[nUnitRec1].szName, 
					//	pBlock->m_SynchronousMachineArray[nUnitRec2].szSub, pBlock->m_SynchronousMachineArray[nUnitRec2].szName);
				}
			}
		}

		if (!bLowVRing)
		{
			for (i=0; i<(int)nParallelArray.size(); i++)
				pBlock->m_ACLineSegmentArray[nParallelArray[i]].bOpen=0;
		}
	}

	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		//if (nDev == 178 || nDev == 179)
		//	ASSERT(FALSE);

		if (pBlock->m_ACLineSegmentArray[nDev].bOutage != 0)
			continue;
		if (bProcArray[nDev] != 0)
			continue;

		//if (strcmp(pBlock->m_ACLineSegmentArray[nDev].szName, "�ȱ�һ") == 0 || strcmp(pBlock->m_ACLineSegmentArray[nDev].szName, "�ȱ���") == 0)
		//	ASSERT(FALSE);
		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage <= fOpenRingVolt)
			continue;

		//if (strstr(pBlock->m_ACLineSegmentArray[nDev].szName, "�ȱ�") != NULL || strstr(pBlock->m_ACLineSegmentArray[nDev].szName, "�Թ�") != NULL)
		//	ASSERT(FALSE);
		//if (strcmp(pBlock->m_ACLineSegmentArray[nDev].szName, "�ȱ�һ") == 0 || strcmp(pBlock->m_ACLineSegmentArray[nDev].szName, "�ȱ���") == 0)
		//	ASSERT(FALSE);
		GetParallelLine(pBlock, nDev, nParallelArray);
		for (i=0; i<(int)nParallelArray.size(); i++)
		{
			//if (nParallelArray[i] == 178 || nParallelArray[i] == 179)
			//	ASSERT(FALSE);

			bProcArray[nParallelArray[i]]=1;
			pBlock->m_ACLineSegmentArray[nParallelArray[i]].bOpen=1;
		}

		PGTraverseNet(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI, Y_CheckStatus, 0, nNodeNum, nNodeArray);

		bRinged=0;
		for (i=0; i<nNodeNum; i++)
		{
			if (nNodeArray[i] == pBlock->m_ACLineSegmentArray[nDev].nNodeJ)
			{
				bRinged=1;
				break;
			}
		}
		if (!bRinged)
		{
			nUnitRec1=nUnitRec2=-1;
			bFlaged=0;
			for (nNode=0; nNode<nNodeNum; nNode++)
			{
				for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
				{
					if (pBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
					{
						nUnitRec1=i;
						bFlaged++;
						break;
					}
				}
				if (nUnitRec1 >= 0)
					break;
			}

			PGTraverseNet(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ, Y_CheckStatus, 0, nOppNodeNum, nOppNodeArray);
			for (nNode=0; nNode<nOppNodeNum; nNode++)
			{
				for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
				{
					if (pBlock->m_SynchronousMachineArray[i].nNode == nOppNodeArray[nNode])
					{
						nUnitRec2=i;
						bFlaged++;
						break;
					}
				}
				if (nUnitRec2 >= 0)
					break;
			}
			if (bFlaged < 2)
			{
				for (i=0; i<(int)nParallelArray.size(); i++)
					m_bRingedLineArray[nParallelArray[i]]=0;
			}
		}

		for (i=0; i<(int)nParallelArray.size(); i++)
			pBlock->m_ACLineSegmentArray[nParallelArray[i]].bOpen=0;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	AddMessage("Decompose����·����������ʱ%d����\n", nDur);

	//�����жϱ�ѹ�������Ƿ�ɻ�
	//	1���ó������б�ѹ��ΪOPEN�������������
	//		A��������
	//			A.1����ѹ������ڵ���ͨ��Ϊ������ѹ��
	//			A.2����ѹ������ڵ㲻��ͨ��������е�Դ������ѹ���������е�ԴΪ�����ѹ�����������д��ڵ�Դ��
	//		B��������
	//			B.1������ѹ������ڵ���ͨ��������ѹ������Ϊ������ѹ������
	//			B.2������ѹ������ڵ㲻��ͨ��������е�Դ������ѹ�����飬�����е�ԴΪ�����ѹ�����飻�������д��ڵ�Դ��
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nDev=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			if (pBlock->m_TransformerWindingArray[nDev].bOutage != 0)
				continue;
			if (m_bRingedTranArray[nDev] == 0)
				continue;

			//	��ѹ�������ó��ڲ���
			nParallelArray.clear();
			for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				nParallelArray.push_back(i);

			if (pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].nWindNum == 3)
			{
				nWindArray.clear();
				nWindArray.push_back(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].nWindH);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].nWindM);
				nWindArray.push_back(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].nWindL);

				nWindNodeArray.clear();
				for (i=0; i<(int)nWindArray.size(); i++)
				{
					if (pBlock->m_TransformerWindingArray[nWindArray[i]].bTranMidSide == 1)
						nWindNodeArray.push_back(pBlock->m_TransformerWindingArray[nWindArray[i]].nNodeJ);
					else
						nWindNodeArray.push_back(pBlock->m_TransformerWindingArray[nWindArray[i]].nNodeI);
				}

				bRinged=0;
				for (nWind=0; nWind<(int)nWindNodeArray.size(); nWind++)
				{
					for (i=nWind+1; i<(int)nWindNodeArray.size(); i++)
					{
						if (nWindNodeArray[nWind] == nWindNodeArray[i])
						{
							bRinged=1;
							break;
						}
					}
					if (bRinged)
						break;
				}
				if (bRinged)	//	��ѹ���Ժϻ�
				{
					m_bRingedTranArray[nDev]=0;
					pBlock->m_TransformerWindingArray[nDev].bOpen=1;
					AddMessage("         ��ѹ��[%d]��%s.%s��%s <-> %s���Ժϻ�\n", nDev, 
						pBlock->m_TransformerWindingArray[nDev].szSub, 
						pBlock->m_TransformerWindingArray[nDev].szName, 
						pBlock->m_TransformerWindingArray[nDev].szVoltI, 
						pBlock->m_TransformerWindingArray[nDev].szVoltJ);
					continue;
				}

				//if (strcmp(pBlock->m_SubstationArray[nSub].szName, "������.�ʺ�") == 0)
				//	ASSERT(FALSE);
				//PGGetParallel3WTran(pBlock, nDev, nParallelArray);
				for (i=0; i<(int)nParallelArray.size(); i++)
					pBlock->m_TransformerWindingArray[nParallelArray[i]].bOpen=1;

				nNode=(pBlock->m_TransformerWindingArray[nDev].bTranMidSide == 1) ? pBlock->m_TransformerWindingArray[nDev].nNodeJ : pBlock->m_TransformerWindingArray[nDev].nNodeI;
				PGTraverseNet(pBlock, nNode, Y_CheckStatus, 0, nNodeNum, nNodeArray);
				//if (strcmp(pBlock->m_TransformerWindingArray[nDev].szSub, "ֱ��.����") == 0)
				//{
				//	for (i=0; i<nNodeNum; i++)
				//	{
				//		nVolt=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].iRkV;
				//		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fOpenRingVolt)
				//		{
				//			AddMessage("        �ڵ�[%d]��%s.%s.%s\n", nNodeArray[i], 
				//					pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szSub, 
				//					pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szVolt, 
				//					pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szName);
				//		}
				//	}
				//}

				bRinged=0;
				for (nWind=0; nWind<(int)nWindArray.size(); nWind++)
				{
					if (nWindArray[nWind] == nDev)
						continue;
					nONode = (pBlock->m_TransformerWindingArray[nWindArray[nWind]].bTranMidSide == 1) ? pBlock->m_TransformerWindingArray[nWindArray[nWind]].nNodeJ : pBlock->m_TransformerWindingArray[nWindArray[nWind]].nNodeI;
					for (i=0; i<nNodeNum; i++)
					{
						if (nNodeArray[i] == nONode)
						{
							bRinged=1;
							break;
						}
					}
					if (bRinged)
						break;
				}

				if (!bRinged)
				{
					for (nWind=0; nWind<(int)nWindArray.size(); nWind++)
					{
						if (nWindArray[nWind] == nDev)
							continue;

						nUnitRec1=nUnitRec2=-1;
						bFlaged=0;
						for (nNode=0; nNode<nNodeNum; nNode++)
						{
							for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
							{
								if (pBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
								{
									nUnitRec1=i;
									bFlaged++;
									break;
								}
							}
							if (nUnitRec1 >= 0)
								break;
						}
						nONode = (pBlock->m_TransformerWindingArray[nWindArray[nWind]].bTranMidSide == 1) ? pBlock->m_TransformerWindingArray[nWindArray[nWind]].nNodeJ : pBlock->m_TransformerWindingArray[nWindArray[nWind]].nNodeI;
						PGTraverseNet(pBlock, nONode, Y_CheckStatus, 0, nOppNodeNum, nOppNodeArray);
						for (nNode=0; nNode<nOppNodeNum; nNode++)
						{
							for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
							{
								if (pBlock->m_SynchronousMachineArray[i].nNode == nOppNodeArray[nNode])
								{
									nUnitRec2=i;
									bFlaged++;
									break;
								}
							}
							if (nUnitRec2 >= 0)
								break;
						}
						if (bFlaged >= 2)
						{
							AddMessage("  ��Դ�ϻ���ѹ��: %s.%s��%s <-> %s) ����� (%s.%s) (%s.%s)\n", 
								pBlock->m_TransformerWindingArray[nDev].szSub, pBlock->m_TransformerWindingArray[nDev].szName, 
								pBlock->m_TransformerWindingArray[nDev].szVoltI, pBlock->m_TransformerWindingArray[nDev].szVoltJ, 
								pBlock->m_SynchronousMachineArray[nUnitRec1].szSub, pBlock->m_SynchronousMachineArray[nUnitRec1].szName, 
								pBlock->m_SynchronousMachineArray[nUnitRec2].szSub, pBlock->m_SynchronousMachineArray[nUnitRec2].szName);
							bRinged=1;
							break;
						}
					}
				}
				if (!bRinged)
					m_bRingedTranArray[nDev]=0;
			}
			else
			{
				//PGGetParallel2WTran(pBlock, nDev, nParallelArray);
				for (i=0; i<(int)nParallelArray.size(); i++)
					pBlock->m_TransformerWindingArray[nParallelArray[i]].bOpen=1;

				PGTraverseNet(pBlock, pBlock->m_TransformerWindingArray[nDev].nNodeI, Y_CheckStatus, 0, nNodeNum, nNodeArray);

				bRinged=0;
				for (i=0; i<nNodeNum; i++)
				{
					if (nNodeArray[i] == pBlock->m_TransformerWindingArray[nDev].nNodeJ)
					{
						bRinged=1;
						break;
					}
				}
				if (!bRinged)
				{
					nUnitRec1=nUnitRec2=-1;
					bFlaged=0;
					for (nNode=0; nNode<nNodeNum; nNode++)
					{
						for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
						{
							if (pBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
							{
								nUnitRec1=i;
								bFlaged++;
								break;
							}
						}
						if (nUnitRec1 >= 0)
							break;
					}

					PGTraverseNet(pBlock, pBlock->m_TransformerWindingArray[nDev].nNodeJ, Y_CheckStatus, 0, nOppNodeNum, nOppNodeArray);
					for (nNode=0; nNode<nOppNodeNum; nNode++)
					{
						for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nOppNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
						{
							if (pBlock->m_SynchronousMachineArray[i].nNode == nOppNodeArray[nNode])
							{
								nUnitRec2=i;
								bFlaged++;
								break;
							}
						}
						if (nUnitRec2 >= 0)
							break;
					}
					if (bFlaged < 2)
						m_bRingedTranArray[nDev]=0;
					else
					{
						AddMessage("  ��Դ�ϻ���ѹ��: %s.%s��%s <-> %s) ����� (%s.%s) (%s.%s)\n", 
							pBlock->m_TransformerWindingArray[nDev].szSub, pBlock->m_TransformerWindingArray[nDev].szName, 
							pBlock->m_TransformerWindingArray[nDev].szVoltI, pBlock->m_TransformerWindingArray[nDev].szVoltJ, 
							pBlock->m_SynchronousMachineArray[nUnitRec1].szSub, pBlock->m_SynchronousMachineArray[nUnitRec1].szName, 
							pBlock->m_SynchronousMachineArray[nUnitRec2].szSub, pBlock->m_SynchronousMachineArray[nUnitRec2].szName);
					}
				}
			}

			for (i=0; i<(int)nParallelArray.size(); i++)
				pBlock->m_TransformerWindingArray[nParallelArray[i]].bOpen=0;
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	AddMessage("Decompose����ѹ������������ʱ%d����\n", nDur);

	//�����γ���������Ϣ
	//	1�������зǻ�����·�ͱ�ѹ��ΪOPEN
	//	2�����е��絺�����豸״̬����
	//	3���޳������������豸
	// 	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	// 	{
	// 		pBlock->m_ACLineSegmentArray[i].bOpen=1;
	// 		if (m_bRingedLineArray[i])
	// 			pBlock->m_ACLineSegmentArray[i].bOpen=0;
	// 	}
	// 	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	// 	{
	// 		pBlock->m_TransformerWindingArray[i].bOpen=1;
	// 		if (m_bRingedTranArray[i])
	// 			pBlock->m_TransformerWindingArray[i].bOpen=0;
	// 	}
	// 
	// 	PGMemDBStatus(pBlock, 1);

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		//if (strstr(pBlock->m_ACLineSegmentArray[i].szName, "����") != NULL)
		//	ASSERT(FALSE);

		// 		if (pBlock->m_ACLineSegmentArray[i].remove != 0)
		// 			m_bRingedLineArray[i]=0;

		pBlock->m_ACLineSegmentArray[i].bOpen=1;
		if (m_bRingedLineArray[i])
			pBlock->m_ACLineSegmentArray[i].bOpen=0;
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		// 		if (pBlock->m_TransformerWindingArray[i].remove != 0)
		// 			m_bRingedTranArray[i]=0;

		pBlock->m_TransformerWindingArray[i].bOpen=1;
		if (m_bRingedTranArray[i])
			pBlock->m_TransformerWindingArray[i].bOpen=0;
	}

	nNode=-1;
	for (nLine=0; nLine<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		if (m_bRingedLineArray[nLine])
		{
			nNode=pBlock->m_ACLineSegmentArray[nLine].nNodeI;
			break;
		}
	}
	if (nNode >= 0)
	{
		PGTraverseNet(pBlock, nNode, Y_CheckStatus, 0, nNodeNum, nNodeArray);
		for (i=0; i<nNodeNum; i++)
		{
			bRingedNodeArray[nNodeArray[i]]=1;
			nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szSub);
			m_nHubSubstationArray.push_back(nSub);
		}
		nSub=0;
		while (nSub < (int)m_nHubSubstationArray.size())
		{
			bFlaged=0;
			for (i=nSub+1; i<(int)m_nHubSubstationArray.size(); i++)
			{
				if (m_nHubSubstationArray[nSub] == m_nHubSubstationArray[i])
				{
					m_nHubSubstationArray.erase(m_nHubSubstationArray.begin()+nSub);
					bFlaged=1;
					break;
				}
			}
			if (!bFlaged)
				nSub++;
		}
	}

	//�塢�γɱ߽���Ϣͨ����·�ͱ�ѹ������ڵ��Ƿ����ڻ����ж�
	int		nBoundNode, nBoundWind;
	tagBoundDevice	bndBuffer;
	nBoundNodeArray.clear();
	memset(&bndBuffer, 0, sizeof(tagBoundDevice));
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (bRingedNodeArray[pBlock->m_ACLineSegmentArray[nDev].nNodeI] != bRingedNodeArray[pBlock->m_ACLineSegmentArray[nDev].nNodeJ])
		{
			bndBuffer.nBoundDevice=nDev;
			if (bRingedNodeArray[pBlock->m_ACLineSegmentArray[nDev].nNodeI])
			{
				bndBuffer.nBorderNode=pBlock->m_ACLineSegmentArray[nDev].nNodeI;
				nBoundNodeArray.push_back(pBlock->m_ACLineSegmentArray[nDev].nNodeI);
			}
			else
			{
				bndBuffer.nBorderNode=pBlock->m_ACLineSegmentArray[nDev].nNodeJ;
				nBoundNodeArray.push_back(pBlock->m_ACLineSegmentArray[nDev].nNodeJ);
			}
			GetLinePQ(pBlock, bndBuffer.nBoundDevice, bndBuffer.nBorderNode, bndBuffer.fP, bndBuffer.fQ);
			m_BoundLineArray.push_back(bndBuffer);
		}
	}

	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nDev++)
	{
		if (pBlock->m_PowerTransformerArray[nDev].nWindNum == 3)
		{
			nWindArray.clear();
			nWindArray.push_back(pBlock->m_PowerTransformerArray[nDev].nWindH);
			nWindArray.push_back(pBlock->m_PowerTransformerArray[nDev].nWindM);
			nWindArray.push_back(pBlock->m_PowerTransformerArray[nDev].nWindL);

			nWindNodeArray.clear();
			for (i=0; i<(int)nWindArray.size(); i++)
			{
				if (pBlock->m_TransformerWindingArray[nWindArray[i]].bTranMidSide == 1)
					nWindNodeArray.push_back(pBlock->m_TransformerWindingArray[nWindArray[i]].nNodeJ);
				else
					nWindNodeArray.push_back(pBlock->m_TransformerWindingArray[nWindArray[i]].nNodeI);
			}

			bRinged=0;
			for (i=0; i<(int)nWindArray.size(); i++)
			{
				if (bRingedNodeArray[nWindNodeArray[i]])
				{
					nBoundWind=nWindArray[i];
					nBoundNode=nWindNodeArray[i];
					bRinged++;
				}
			}
			if (bRinged == 1)
			{
				bndBuffer.nBorderNode=nBoundNode;
				bndBuffer.nBoundDevice=nBoundWind;
				GetTranPQ(pBlock, bndBuffer.nBoundDevice, bndBuffer.nBorderNode, bndBuffer.fP, bndBuffer.fQ);
				m_BoundTranArray.push_back(bndBuffer);

				nBoundNodeArray.push_back(nBoundNode);
			}
		}
		else
		{
			if (bRingedNodeArray[pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI] != bRingedNodeArray[pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeJ])
			{
				bndBuffer.nBoundDevice=pBlock->m_PowerTransformerArray[nDev].nWindH;
				if (bRingedNodeArray[pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI])
				{
					bndBuffer.nBorderNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI;
					nBoundNodeArray.push_back(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI);
				}
				else
				{
					bndBuffer.nBorderNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeJ;
					nBoundNodeArray.push_back(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeJ);
				}

				GetTranPQ(pBlock, bndBuffer.nBoundDevice, bndBuffer.nBorderNode, bndBuffer.fP, bndBuffer.fQ);
				m_BoundTranArray.push_back(bndBuffer);
			}
		}
	}

	//for (i=0; i<(int)nBoundNodeArray.size(); i++)
	//{
	//	AddMessage("�߽�ڵ�[%d/%d]: %s %s %s\n", i, nBoundNodeArray.size(), pBlock->m_ConnectivityNodeArray[nBoundNodeArray[i]].szSub, pBlock->m_ConnectivityNodeArray[nBoundNodeArray[i]].szVolt, pBlock->m_ConnectivityNodeArray[nBoundNodeArray[i]].szName);
	//}
	//for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	//{
	//	if (m_bBoundLineArray[i])
	//	{
	//		AddMessage("�߽���·: %s %s (%s-%s)\n", pBlock->m_ACLineSegmentArray[i].szName, pBlock->m_ACLineSegmentArray[i].szVoltI, pBlock->m_ACLineSegmentArray[i].szSubI, pBlock->m_ACLineSegmentArray[i].szSubJ);
	//	}
	//}
	//for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	//{
	//	if (m_bBoundTranArray[i])
	//	{
	//		AddMessage("�߽��ѹ��: %s.%s(%s-%s)\n", pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_TransformerWindingArray[i].szName, pBlock->m_TransformerWindingArray[i].szVoltI, pBlock->m_TransformerWindingArray[i].szVoltJ);
	//	}
	//}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	AddMessage("Decompose���߽������ʱ%d����\n", nDur);

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		pBlock->m_ACLineSegmentArray[i].bOpen=0;
		if (m_bRingedLineArray[i])
			pBlock->m_ACLineSegmentArray[i].bOpen=1;
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		pBlock->m_TransformerWindingArray[i].bOpen=0;
		if (m_bRingedTranArray[i])
			pBlock->m_TransformerWindingArray[i].bOpen=1;
	}

	bProcArray.resize(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	tagRadiate	rBuf;
	m_RadiateArray.clear();
	for (nNode=0; nNode<(int)nBoundNodeArray.size(); nNode++)
	{
		if (bProcArray[nBoundNodeArray[nNode]])
			continue;
		bProcArray[nNode]=1;

		rBuf.nBoundBusArray.clear();
		rBuf.nLineArray.clear();
		rBuf.nTranArray.clear();
		PGTraverseVolt(pBlock, nBoundNodeArray[nNode], Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
		for (i=0; i<nNodeNum; i++)
			rBuf.nBoundBusArray.push_back(pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nTopoBus);

		nDev=0;
		while (nDev < (int)rBuf.nBoundBusArray.size())
		{
			bFlaged=0;
			for (i=nDev+1; i<(int)rBuf.nBoundBusArray.size(); i++)
			{
				if (rBuf.nBoundBusArray[nDev] == rBuf.nBoundBusArray[i])
				{
					rBuf.nBoundBusArray.erase(rBuf.nBoundBusArray.begin()+nDev);
					bFlaged=1;
					break;
				}
			}
			if (!bFlaged)
				nDev++;
		}

		PGTraverseNet(pBlock, nBoundNodeArray[nNode], Y_CheckStatus, 0, nNodeNum, nNodeArray);
		for (i=0; i<nNodeNum; i++)
		{
			bProcArray[nNodeArray[i]]=1;
			for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; nDev++)
			{
				if (m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment])
					continue;
				rBuf.nLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment);
			}
			for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nTransformerWindingRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nTransformerWindingRange; nDev++)
			{
				if (m_bRingedTranArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding])
					continue;
				rBuf.nTranArray.push_back(pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding);
			}
		}

		nDev=0;
		while (nDev < (int)rBuf.nLineArray.size())
		{
			bFlaged=0;
			for (i=nDev+1; i<(int)rBuf.nLineArray.size(); i++)
			{
				if (rBuf.nLineArray[nDev] == rBuf.nLineArray[i])
				{
					rBuf.nLineArray.erase(rBuf.nLineArray.begin()+nDev);
					bFlaged=1;
					break;
				}
			}
			if (!bFlaged)
				nDev++;
		}
		nDev=0;
		while (nDev < (int)rBuf.nTranArray.size())
		{
			bFlaged=0;
			for (i=nDev+1; i<(int)rBuf.nTranArray.size(); i++)
			{
				if (rBuf.nTranArray[nDev] == rBuf.nTranArray[i])
				{
					rBuf.nTranArray.erase(rBuf.nTranArray.begin()+nDev);
					bFlaged=1;
					break;
				}
			}
			if (!bFlaged)
				nDev++;
		}

		if (!rBuf.nLineArray.empty() || !rBuf.nTranArray.empty())
			m_RadiateArray.push_back(rBuf);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	AddMessage("Decompose��������������ʱ%d����\n", nDur);

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pBlock->m_ACLineSegmentArray[i].bOpen=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		pBlock->m_TransformerWindingArray[i].bOpen=0;
	PGMemDBStatus(pBlock, 1);

	if (nNodeArray)
	{
		free(nNodeArray);
		nNodeArray=NULL;
	}
	if (nOppNodeArray)
	{
		free(nOppNodeArray);
		nOppNodeArray=NULL;
	}
}
