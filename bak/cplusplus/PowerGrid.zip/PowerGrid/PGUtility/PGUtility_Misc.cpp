#include "stdafx.h"
#include "PGUtility.h"

void CPGUtility::MergeZeroXLine(tagPGBlock* pBlock, const double fZeroZ)
{
	register int	i;
	int		nLine;
	double	fBuf;

	for (nLine=0; nLine<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
		pBlock->m_ACLineSegmentArray[nLine].bOutage=0;

	for (nLine=0; nLine<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		fBuf =pBlock->m_ACLineSegmentArray[nLine].fR*pBlock->m_ACLineSegmentArray[nLine].fR;
		fBuf += pBlock->m_ACLineSegmentArray[nLine].fX*pBlock->m_ACLineSegmentArray[nLine].fX;
		//fBuf += pBlock->m_ACLineSegmentArray[nLine].g*pBlock->m_ACLineSegmentArray[nLine].g;
		//fBuf += pBlock->m_ACLineSegmentArray[nLine].b*pBlock->m_ACLineSegmentArray[nLine].b;
		if (sqrt(fBuf) <= fZeroZ)
		{
			for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
			{
				if (strcmp(pBlock->m_BusbarSectionArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_BusbarSectionArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_BusbarSectionArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_BusbarSectionArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_EnergyConsumerArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_EnergyConsumerArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_EnergyConsumerArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; i++)
			{
				if (strcmp(pBlock->m_ShuntCompensatorArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_ShuntCompensatorArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_ShuntCompensatorArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_ShuntCompensatorArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
			{
				if (strcmp(pBlock->m_SynchronousMachineArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_SynchronousMachineArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_SynchronousMachineArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_SynchronousMachineArray[i].szNode, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
			{
				if (nLine == i)
					continue;
				if (strcmp(pBlock->m_ACLineSegmentArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_ACLineSegmentArray[i].szSubI, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_ACLineSegmentArray[i].szVoltI, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_ACLineSegmentArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
				if (strcmp(pBlock->m_ACLineSegmentArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_ACLineSegmentArray[i].szSubJ, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_ACLineSegmentArray[i].szVoltJ, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_ACLineSegmentArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
			{
				if (strcmp(pBlock->m_TransformerWindingArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_TransformerWindingArray[i].szVoltI, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_TransformerWindingArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
				if (strcmp(pBlock->m_TransformerWindingArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_TransformerWindingArray[i].szVoltJ, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_TransformerWindingArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
			{
				if (strcmp(pBlock->m_SeriesCompensatorArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_SeriesCompensatorArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_SeriesCompensatorArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_SeriesCompensatorArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
				if (strcmp(pBlock->m_SeriesCompensatorArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_SeriesCompensatorArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_SeriesCompensatorArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_SeriesCompensatorArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
			{
				if (strcmp(pBlock->m_BreakerArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_BreakerArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_BreakerArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_BreakerArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
				if (strcmp(pBlock->m_BreakerArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_BreakerArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_BreakerArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_BreakerArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
			{
				if (strcmp(pBlock->m_DisconnectorArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_DisconnectorArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_DisconnectorArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_DisconnectorArray[i].szNodeI, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
				if (strcmp(pBlock->m_DisconnectorArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeJ) == 0)
				{
					strcpy(pBlock->m_DisconnectorArray[i].szSub, pBlock->m_ACLineSegmentArray[nLine].szSubI);
					strcpy(pBlock->m_DisconnectorArray[i].szVolt, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
					strcpy(pBlock->m_DisconnectorArray[i].szNodeJ, pBlock->m_ACLineSegmentArray[nLine].szNodeI);
				}
			}
			pBlock->m_ACLineSegmentArray[nLine].bOutage=1;
		}
	}

	nLine=0;
	while (nLine < pBlock->m_nRecordNum[PG_ACLINESEGMENT])
	{
		if (pBlock->m_ACLineSegmentArray[nLine].bOutage)
		{
			AddMessage("ɾ����·:%s.%s.%s\n", pBlock->m_ACLineSegmentArray[nLine].szSubI, pBlock->m_ACLineSegmentArray[nLine].szSubJ, pBlock->m_ACLineSegmentArray[nLine].szName);
			PGRemoveRecord(pBlock, PG_ACLINESEGMENT, nLine);
		}
		else
		{
			nLine++;
		}
	}
	PGMaint(pBlock);
}

int	CPGUtility::GetNodeUpVoltageBus(tagPGBlock* pBlock, const int nJudgeNode)
{
	register int	i;
	int		nVolt, nNode, nTranNodeV;
	int		nTran, nTranNum, nTranCoil[10], nTranNode[10];
	int		nNodeNum, nNodeArray[400];

	std::vector<int>	nTranArray;
	float	fHVolt;
	int		nHVolt, nHVNode, nHVBus;

	nVolt=pBlock->m_ConnectivityNodeArray[nJudgeNode].nVoltageLevelPtr;
	if (nVolt < 0)
		return -1;

	nTranArray.clear();
	PGTraverseVolt(pBlock, nJudgeNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; i++)
			nTranArray.push_back(pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding);
	}
	if (nTranArray.empty())
		return -1;

	fHVolt=-1;
	nHVolt=-1;
	nHVNode=0;
	for (nTran=0; nTran<(int)nTranArray.size(); nTran++)
	{
		PGGetTranCoil(pBlock, nTranArray[nTran], nTranNum, nTranCoil, nTranNode);

		nTranNodeV=pBlock->m_ConnectivityNodeArray[nTranNode[0]].nVoltageLevelPtr;
		if (fHVolt < pBlock->m_VoltageLevelArray[nTranNodeV].nominalVoltage)
		{
			fHVolt=pBlock->m_VoltageLevelArray[nTranNodeV].nominalVoltage;
			nHVolt=nTranNodeV;
			nHVNode=nTranNode[0];
		}
	}
	if (fHVolt < 0 || nHVolt == nVolt)
		return -1;

	nHVBus=-1;
	PGTraverseVolt(pBlock, nHVNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pBlock->m_VoltageLevelArray[nHVolt].nBusbarSectionRange; i<pBlock->m_VoltageLevelArray[nHVolt+1].nBusbarSectionRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_BusbarSectionArray[i].nNode && pBlock->m_BusbarSectionArray[i].bBypass == 0)	//	�������ӵ���ĸ
			{
				nHVBus=i;
				break;
			}
		}
		if (nHVBus >= 0)
			break;
	}
	return nHVBus;
}

void CPGUtility::UpgradeVoltageOfSynchronousMachine(tagPGBlock* pBlock)
{
	register int	i;
	int		nSub, nVolt, nDev;
	int		nHVBus;

	std::vector<unsigned char>	bTransformerWindingStateArray;
	std::vector<unsigned char>	bEnergyConsumerStateArray;

	bTransformerWindingStateArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	bEnergyConsumerStateArray.resize(pBlock->m_nRecordNum[PG_ENERGYCONSUMER]);

	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		bTransformerWindingStateArray[i] = 0;
	for (i=0; i<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		bEnergyConsumerStateArray[i] = 0;

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 200)
				continue;

			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				if (pBlock->m_SynchronousMachineArray[nDev].nNode < 0)
					continue;

				nHVBus=GetNodeUpVoltageBus(pBlock, pBlock->m_SynchronousMachineArray[nDev].nNode);
				if (nHVBus < 0)
					continue;

				strcpy(pBlock->m_SynchronousMachineArray[nDev].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szVolt);
				strcpy(pBlock->m_SynchronousMachineArray[nDev].szNode, pBlock->m_BusbarSectionArray[nHVBus].szNode);
				AddMessage("    �����(%s.%s.%s)���Ӹ�ѹĸ��Ϊ:(%s.%s.%s)\n", 
					pBlock->m_SynchronousMachineArray[nDev].szSub, pBlock->m_SynchronousMachineArray[nDev].szVolt, pBlock->m_SynchronousMachineArray[nDev].szName, 
					pBlock->m_BusbarSectionArray[nHVBus].szSub, pBlock->m_BusbarSectionArray[nHVBus].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szName);
			}
		}
	}
	i=0;
	while (i < pBlock->m_nRecordNum[PG_ENERGYCONSUMER])
	{
		if (bEnergyConsumerStateArray[i])
		{
			AddMessage("ɾ�����õ�:(%s.%s)\n", pBlock->m_EnergyConsumerArray[i].szSub, pBlock->m_EnergyConsumerArray[i].szName);
			PGRemoveRecord(pBlock, PG_ENERGYCONSUMER, i);
			bEnergyConsumerStateArray.erase(bEnergyConsumerStateArray.begin()+i);
		}
		else
			i++;
	}
	PGMaint(pBlock, 0);
	//i=0;
	//while (i < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	//{
	//	if (bTransformerWindingStateArray[i])
	//	{
	//		AddMessage("ɾ����ѹ��:(%s.%s)\n", pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_TransformerWindingArray[i].szName);
	//		PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, i);
	//		bTransformerWindingStateArray.erase(bTransformerWindingStateArray.begin()+i);
	//	}
	//	else
	//		i++;
	//}
	//PGMaint(pBlock);
}

void CPGUtility::UpgradeVoltageOfEnergyConsumer(tagPGBlock* pBlock)
{
	int		nSub, nVolt, nDev;
	int		nHVBus;

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 200)
				continue;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;

				nHVBus=GetNodeUpVoltageBus(pBlock, pBlock->m_EnergyConsumerArray[nDev].nNode);
				if (nHVBus < 0)
					continue;

				AddMessage("����:(%s.%s.%s)���Ӹ�ѹĸ��:(%s.%s.%s)\n", 
					pBlock->m_EnergyConsumerArray[nDev].szSub, pBlock->m_EnergyConsumerArray[nDev].szVolt, pBlock->m_EnergyConsumerArray[nDev].szName, 
					pBlock->m_BusbarSectionArray[nHVBus].szSub, pBlock->m_BusbarSectionArray[nHVBus].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szName);
				strcpy(pBlock->m_EnergyConsumerArray[nDev].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szVolt);
				strcpy(pBlock->m_EnergyConsumerArray[nDev].szNode, pBlock->m_BusbarSectionArray[nHVBus].szNode);
				pBlock->m_EnergyConsumerArray[nDev].fPlanP += (float)(sqrt(pBlock->m_EnergyConsumerArray[nDev].fPlanP*pBlock->m_EnergyConsumerArray[nDev].fPlanP+pBlock->m_EnergyConsumerArray[nDev].fPlanQ*pBlock->m_EnergyConsumerArray[nDev].fPlanQ)*0.015);
				pBlock->m_EnergyConsumerArray[nDev].fPlanQ += (float)(sqrt(pBlock->m_EnergyConsumerArray[nDev].fPlanP*pBlock->m_EnergyConsumerArray[nDev].fPlanP+pBlock->m_EnergyConsumerArray[nDev].fPlanQ*pBlock->m_EnergyConsumerArray[nDev].fPlanQ)*0.15);
			}
		}
	}
	PGMaint(pBlock, 0);
}
