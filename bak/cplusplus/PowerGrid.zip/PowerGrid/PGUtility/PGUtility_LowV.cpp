#include "stdafx.h"
#include "PGUtility.h"

void	CPGUtility::LowVGen2Load(tagPGBlock* pBlock, const double fLowVThreshold)
{
	register int	i;
	int		nSub, nVolt, nDev;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	std::vector<unsigned char>	bSynchronousMachineStateArray;
	bSynchronousMachineStateArray.resize(pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);
	for (i=0; i<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		bSynchronousMachineStateArray[i]=0;
	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= fLowVThreshold)
				continue;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				bSynchronousMachineStateArray[nDev] = 1;

				strcpy(szField[PG_ENERGYCONSUMER_RESOURCEID],		pBlock->m_SynchronousMachineArray[nDev].szResID);
				strcpy(szField[PG_ENERGYCONSUMER_NAME],				pBlock->m_SynchronousMachineArray[nDev].szName);
				strcpy(szField[PG_ENERGYCONSUMER_DESC],				pBlock->m_SynchronousMachineArray[nDev].szDesp);
	
				strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION],		pBlock->m_SynchronousMachineArray[nDev].szSub);
				strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL],		pBlock->m_SynchronousMachineArray[nDev].szVolt);
				strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE],	pBlock->m_SynchronousMachineArray[nDev].szNode);

				sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	-pBlock->m_SynchronousMachineArray[nDev].fPlanP);
				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	-pBlock->m_SynchronousMachineArray[nDev].fPlanQ);
				sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	-pBlock->m_SynchronousMachineArray[nDev].fPlanP);
				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	-pBlock->m_SynchronousMachineArray[nDev].fPlanQ);

				PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ENERGYCONSUMER, szField);
			}
		}
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE])
	{
		if (bSynchronousMachineStateArray[i])
		{
			PGRemoveRecord(pBlock, PG_SYNCHRONOUSMACHINE, i);
			bSynchronousMachineStateArray.erase(bSynchronousMachineStateArray.begin()+i);
		}
		else
			i++;
	}

	PGMaint(pBlock);
}

void CPGUtility::EraseLowVPCap(tagPGBlock* pBlock, const double fLowVThreshold)
{
	int		nSub, nVolt, nDev;

	std::vector<unsigned char>	bShuntCompensatorStateArray;
	bShuntCompensatorStateArray.resize(pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]);
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; nDev++)
		bShuntCompensatorStateArray[nDev]=0;

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= fLowVThreshold)
				continue;

			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nDev++)
				bShuntCompensatorStateArray[nDev]=1;
		}
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR])
	{
		if (bShuntCompensatorStateArray[nDev])
		{
			PGRemoveRecord(pBlock, PG_SHUNTCOMPENSATOR, nDev);
			bShuntCompensatorStateArray.erase(bShuntCompensatorStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	PGMaint(pBlock);

}

void CPGUtility::LowVLine2Load(tagPGBlock* pBlock, const double fLowVThreshold)
{
	register int	i;
	int		nDev, nVolt, nNode;
	std::vector<unsigned char>	bProcArray;
	std::vector<int>			nLoadArray;
	std::vector<int>			nUnitArray;
	int		nNodeNum, nNodeArray[1024];

	int		nHVBus;

	std::vector<unsigned char>	bACLineSegmentStateArray;
	bProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT], 0);

	bACLineSegmentStateArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		bACLineSegmentStateArray[i]=0;

	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (bProcArray[nDev])
			continue;

		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > fLowVThreshold)
			continue;
		bACLineSegmentStateArray[nDev] = 1;

		nLoadArray.clear();
		nUnitArray.clear();
		PGTraverseLine(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI, Y_CheckStatus, nNodeNum, nNodeArray);
		for (nNode=0; nNode<nNodeNum; nNode++)
		{
			for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
			{
				bProcArray[pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment]=1;
				bACLineSegmentStateArray[pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment] = 1;
			}
		}

		for (i=0; i<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		{
			for (nNode=0; nNode<nNodeNum; nNode++)
			{
				if (pBlock->m_EnergyConsumerArray[i].nNode == nNodeArray[nNode])
				{
					nLoadArray.push_back(i);
					break;
				}
			}
		}
		for (i=0; i<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			for (nNode=0; nNode<nNodeNum; nNode++)
			{
				if (pBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
				{
					nUnitArray.push_back(i);
					break;
				}
			}
		}
		nHVBus=-1;
		for (nNode=0; nNode<nNodeNum; nNode++)
		{
			nHVBus=GetNodeUpVoltageBus(pBlock, nNodeArray[nNode]);
			if (nHVBus >= 0)
				break;
		}

		if (nHVBus < 0)
			continue;

		for (i=0; i<(int)nLoadArray.size(); i++)
		{
			AddMessage("����:(%s.%s.%s)���Ӹ�ѹĸ��:(%s.%s.%s)\n", 
				pBlock->m_EnergyConsumerArray[nLoadArray[i]].szSub, pBlock->m_EnergyConsumerArray[nLoadArray[i]].szVolt, pBlock->m_EnergyConsumerArray[nLoadArray[i]].szName, 
				pBlock->m_BusbarSectionArray[nHVBus].szSub, pBlock->m_BusbarSectionArray[nHVBus].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szName);
			strcpy(pBlock->m_EnergyConsumerArray[nLoadArray[i]].szSub, pBlock->m_BusbarSectionArray[nHVBus].szSub);
			strcpy(pBlock->m_EnergyConsumerArray[nLoadArray[i]].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szVolt);
			strcpy(pBlock->m_EnergyConsumerArray[nLoadArray[i]].szNode, pBlock->m_BusbarSectionArray[nHVBus].szNode);
		}
		for (i=0; i<(int)nUnitArray.size(); i++)
		{
			AddMessage("    �����(%s.%s.%s)���Ӹ�ѹĸ��Ϊ:(%s.%s.%s)\n", 
				pBlock->m_SynchronousMachineArray[nUnitArray[i]].szSub, pBlock->m_SynchronousMachineArray[nUnitArray[i]].szVolt, pBlock->m_SynchronousMachineArray[nUnitArray[i]].szName, 
				pBlock->m_BusbarSectionArray[nHVBus].szSub, pBlock->m_BusbarSectionArray[nHVBus].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szName);
			strcpy(pBlock->m_SynchronousMachineArray[nUnitArray[i]].szSub, pBlock->m_BusbarSectionArray[nHVBus].szSub);
			strcpy(pBlock->m_SynchronousMachineArray[nUnitArray[i]].szVolt, pBlock->m_BusbarSectionArray[nHVBus].szVolt);
			strcpy(pBlock->m_SynchronousMachineArray[nUnitArray[i]].szNode, pBlock->m_BusbarSectionArray[nHVBus].szNode);
		}
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_ACLINESEGMENT])
	{
		if (bACLineSegmentStateArray[i])
		{
			AddMessage("ɾ����·:%s(%s.%s)\n", pBlock->m_ACLineSegmentArray[i].szName, pBlock->m_ACLineSegmentArray[i].szSubI, pBlock->m_ACLineSegmentArray[i].szSubJ);
			PGRemoveRecord(pBlock, PG_ACLINESEGMENT, i);
			bACLineSegmentStateArray.erase(bACLineSegmentStateArray.begin()+i);
		}
		else
			i++;
	}

	PGMaint(pBlock);
}

void CPGUtility::EraseLowVNet(tagPGBlock* pBlock, const double fMinimalVoltage)
{
	register int	i;
	int		nSub, nVolt, nNode, nDev;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	std::vector<int>			nTranArray;

	std::vector<unsigned char>	bACLineSegmentStateArray;
	std::vector<unsigned char>	bTransformerWindingStateArray;
	std::vector<unsigned char>	bBusbarSectionStateArray;
	std::vector<unsigned char>	bBreakerStateArray;
	std::vector<unsigned char>	bDisconnectorStateArray;
	std::vector<unsigned char>	bSynchronousMachineStateArray;
	std::vector<unsigned char>	bEnergyConsumerStateArray;
	std::vector<unsigned char>	bShuntCompensatorStateArray;

	bACLineSegmentStateArray.resize			(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	bTransformerWindingStateArray.resize	(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	bBusbarSectionStateArray.resize			(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	bBreakerStateArray.resize				(pBlock->m_nRecordNum[PG_BREAKER]);
	bDisconnectorStateArray.resize			(pBlock->m_nRecordNum[PG_DISCONNECTOR]);
	bSynchronousMachineStateArray.resize	(pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);
	bEnergyConsumerStateArray.resize		(pBlock->m_nRecordNum[PG_ENERGYCONSUMER]);
	bShuntCompensatorStateArray.resize		(pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]);

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		bACLineSegmentStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		bTransformerWindingStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		bBusbarSectionStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
		bBreakerStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
		bDisconnectorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		bSynchronousMachineStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		bEnergyConsumerStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; i++)
		bShuntCompensatorStateArray[i]=0;

	nTranArray.clear();
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pBlock->m_SubstationArray[nSub].st_type != PGEnumst_type_Substation)
			continue;
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fMinimalVoltage)
				continue;

			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=pBlock->m_ConnectivityNodeArray[nNode].nTransformerWindingRange; nDev<pBlock->m_ConnectivityNodeArray[nNode+1].nTransformerWindingRange; nDev++)
					nTranArray.push_back(nDev);
			}
		}
	}


	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= fMinimalVoltage)
				continue;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
				bBusbarSectionStateArray[nDev]=1;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
				bSynchronousMachineStateArray[nDev]=1;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
				bEnergyConsumerStateArray[nDev]=1;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nDev++)
				bShuntCompensatorStateArray[nDev]=1;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
				bBreakerStateArray[nDev]=1;
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
				bDisconnectorStateArray[nDev]=1;
		}
	}

	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		bACLineSegmentStateArray[nDev]=0;
		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fMinimalVoltage)
			bACLineSegmentStateArray[nDev]=1;
	}

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nDev=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			bTransformerWindingStateArray[nDev]=1;
			if (pBlock->m_SubstationArray[nSub].st_type < PGEnumst_type_Substation)
			{
				nVolt=pBlock->m_TransformerWindingArray[nDev].nVoltI;
				if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= fMinimalVoltage)
					bTransformerWindingStateArray[nDev]=0;
				nVolt=pBlock->m_TransformerWindingArray[nDev].nVoltJ;
				if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= fMinimalVoltage)
					bTransformerWindingStateArray[nDev]=0;
			}
		}
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		if (bTransformerWindingStateArray[nDev])
		{
			AddMessage("ɾ����ѹ��:%s.%s\n", pBlock->m_TransformerWindingArray[nDev].szSub, pBlock->m_TransformerWindingArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, nDev);
			bTransformerWindingStateArray.erase(bTransformerWindingStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_ACLINESEGMENT])
	{
		if (bACLineSegmentStateArray[nDev])
		{
			AddMessage("ɾ����·:%s(%s.%s)\n", pBlock->m_ACLineSegmentArray[nDev].szName, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szSubJ);
			PGRemoveRecord(pBlock, PG_ACLINESEGMENT, nDev);
			bACLineSegmentStateArray.erase(bACLineSegmentStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_BUSBARSECTION])
	{
		if (bBusbarSectionStateArray[nDev])
		{
			AddMessage("ɾ��ĸ��:%s(%s.%s)\n", pBlock->m_BusbarSectionArray[nDev].szSub, pBlock->m_BusbarSectionArray[nDev].szVolt, pBlock->m_BusbarSectionArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_BUSBARSECTION, nDev);
			bBusbarSectionStateArray.erase(bBusbarSectionStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE])
	{
		if (bSynchronousMachineStateArray[nDev])
		{
			AddMessage("ɾ�������:%s(%s.%s)\n", pBlock->m_SynchronousMachineArray[nDev].szSub, pBlock->m_SynchronousMachineArray[nDev].szVolt, pBlock->m_SynchronousMachineArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_SYNCHRONOUSMACHINE, nDev);
			bSynchronousMachineStateArray.erase(bSynchronousMachineStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_ENERGYCONSUMER])
	{
		if (bEnergyConsumerStateArray[nDev])
		{
			AddMessage("ɾ������:%s(%s.%s)\n", pBlock->m_EnergyConsumerArray[nDev].szSub, pBlock->m_EnergyConsumerArray[nDev].szVolt, pBlock->m_EnergyConsumerArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_ENERGYCONSUMER, nDev);
			bEnergyConsumerStateArray.erase(bEnergyConsumerStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR])
	{
		if (bShuntCompensatorStateArray[nDev])
		{
			AddMessage("ɾ������:%s(%s.%s)\n", pBlock->m_ShuntCompensatorArray[nDev].szSub, pBlock->m_ShuntCompensatorArray[nDev].szVolt, pBlock->m_ShuntCompensatorArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_SHUNTCOMPENSATOR, nDev);
			bShuntCompensatorStateArray.erase(bShuntCompensatorStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_BREAKER])
	{
		if (bBreakerStateArray[nDev])
		{
			AddMessage("ɾ������:%s(%s.%s)\n", pBlock->m_BreakerArray[nDev].szSub, pBlock->m_BreakerArray[nDev].szVolt, pBlock->m_BreakerArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_BREAKER, nDev);
			bBreakerStateArray.erase(bBreakerStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		if (bDisconnectorStateArray[nDev])
		{
			AddMessage("ɾ����բ:%s(%s.%s)\n", pBlock->m_DisconnectorArray[nDev].szSub, pBlock->m_DisconnectorArray[nDev].szVolt, pBlock->m_DisconnectorArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_DISCONNECTOR, nDev);
			bDisconnectorStateArray.erase(bDisconnectorStateArray.begin()+nDev);
		}
		else
			nDev++;
	}


	for (nDev=0; nDev<(int)nTranArray.size(); nDev++)
	{
		for (i=0; i<MAXMDBFIELDNUM; i++)
			memset(szField[i], 0, MDB_CHARLEN_LONG);

		float	fBuffer = (stricmp(pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode, pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].szNodeI) == 0) ?
			pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPi : pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPz;
		if (fBuffer > 0)
		{
			strcpy(szField[PG_ENERGYCONSUMER_NAME],				pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szName);
			strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szSub);
			strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szVolt);
			strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE],	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode);

			if (stricmp(pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode, pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].szNodeI) == 0)
			{
				sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPi);
				sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPi);
				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQi);
				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQi);
			}
			else
			{
				sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPz);
				sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPz);
				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQz);
				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQz);
			}
// 			sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fP);
// 			sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fP);
// 			if (pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fQ > 0)
// 			{
// 				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fQ);
// 				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fQ);
// 			}

			PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ENERGYCONSUMER, szField);

			AddMessage("���ӱ�ѹ����Ч����:(%s.%s.%s) %s %s\n", 
				szField[PG_ENERGYCONSUMER_SUBSTATION], 
				szField[PG_ENERGYCONSUMER_VOLTAGELEVEL], 
				szField[PG_ENERGYCONSUMER_NAME], 
				szField[PG_ENERGYCONSUMER_PLANP], szField[PG_ENERGYCONSUMER_PLANQ]);

			// 			strcpy(szField[PG_SYNCHRONOUSMACHINE_NAME],				pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szName);
			// 			strcpy(szField[PG_SYNCHRONOUSMACHINE_SUBSTATION],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szSub);
			// 			strcpy(szField[PG_SYNCHRONOUSMACHINE_VOLTAGELEVEL],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szVolt);
			// 			strcpy(szField[PG_SYNCHRONOUSMACHINE_CONNECTIVITYNODE],	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode);
			// 
			// 			PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SYNCHRONOUSMACHINE, szField);
			// 
			// 			AddMessage("���ӱ�ѹ����Ч�����:(%s.%s.%s) %s %s\n", 
			// 				szField[PG_SYNCHRONOUSMACHINE_SUBSTATION], 
			// 				szField[PG_SYNCHRONOUSMACHINE_VOLTAGELEVEL], 
			// 				szField[PG_SYNCHRONOUSMACHINE_NAME], 
			// 				szField[PG_SYNCHRONOUSMACHINE_PLANP], szField[PG_SYNCHRONOUSMACHINE_PLANQ]);
		}
		else
		{
			strcpy(szField[PG_ENERGYCONSUMER_NAME],				pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szName);
			strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szSub);
			strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szVolt);
			strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE],	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode);

			if (stricmp(pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode, pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].szNodeI) == 0)
			{
				sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPi);
				sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPi);
				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQi);
				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQi);
			}
			else
			{
				sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPz);
				sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fPz);
				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQz);
				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].nTransformerWinding].fQz);
			}
// 			sprintf(szField[PG_ENERGYCONSUMER_PLANP],	"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fP);
// 			sprintf(szField[PG_ENERGYCONSUMER_P],		"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fP);
// 			if (pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fQ > 0)
// 			{
// 				sprintf(szField[PG_ENERGYCONSUMER_PLANQ],	"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fQ);
// 				sprintf(szField[PG_ENERGYCONSUMER_Q],		"%f",	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].fQ);
// 			}
			PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ENERGYCONSUMER, szField);

			// AddMessage("���ӱ�ѹ����Ч����:(%s.%s.%s) %s %s\n", 
			// 	szField[PG_ENERGYCONSUMER_SUBSTATION], 
			// 	szField[PG_ENERGYCONSUMER_VOLTAGELEVEL], 
			// 	szField[PG_ENERGYCONSUMER_NAME], 
			// 	szField[PG_ENERGYCONSUMER_PLANP], szField[PG_ENERGYCONSUMER_PLANQ]);
			// 
			// strcpy(szField[PG_SYNCHRONOUSMACHINE_NAME],				pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szName);
			// strcpy(szField[PG_SYNCHRONOUSMACHINE_SUBSTATION],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szSub);
			// strcpy(szField[PG_SYNCHRONOUSMACHINE_VOLTAGELEVEL],		pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szVolt);
			// strcpy(szField[PG_SYNCHRONOUSMACHINE_CONNECTIVITYNODE],	pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].szNode);
			// 
			// sprintf(szField[PG_SYNCHRONOUSMACHINE_PLANP],	"%f",	-pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].p);
			// sprintf(szField[PG_SYNCHRONOUSMACHINE_PLANQ],	"%f",	-pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].q);
			// sprintf(szField[PG_SYNCHRONOUSMACHINE_P],		"%f",	-pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].p);
			// sprintf(szField[PG_SYNCHRONOUSMACHINE_Q],		"%f",	-pBlock->m_EdgeTransformerWindingArray[nTranArray[nDev]].q);
			// strcpy(szField[PG_SYNCHRONOUSMACHINE_PVND],	"1");
			// 
			// PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SYNCHRONOUSMACHINE, szField);
			// 
			// AddMessage("���ӱ�ѹ����Ч�����:(%s.%s.%s) %s %s\n", 
			// 	szField[PG_SYNCHRONOUSMACHINE_SUBSTATION], 
			// 	szField[PG_SYNCHRONOUSMACHINE_VOLTAGELEVEL], 
			// 	szField[PG_SYNCHRONOUSMACHINE_NAME], 
			// 	szField[PG_SYNCHRONOUSMACHINE_PLANP], szField[PG_SYNCHRONOUSMACHINE_PLANQ]);
		}
	}

	PGMaint(pBlock);
}
