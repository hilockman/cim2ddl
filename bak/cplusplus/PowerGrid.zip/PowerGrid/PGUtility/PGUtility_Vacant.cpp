#include "stdafx.h"
#include "PGUtility.h"

int CPGUtility::IsNodeVacant(tagPGBlock* pBlock, const int nCheckNode)
{
	register int	i;
	int		nVolt, nNode;
	int		nDevNum, nNodeNum, nNodeArray[400];

	nDevNum=0;
	PGTraverseVolt(pBlock, nCheckNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	nVolt=pBlock->m_ConnectivityNodeArray[nCheckNode].nVoltageLevelPtr;
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		nDevNum += (
			pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange - pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange);

		for (i=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_SynchronousMachineArray[i].nNode)
				nDevNum++;
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_EnergyConsumerArray[i].nNode)
				nDevNum++;
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_ShuntCompensatorArray[i].nNode)
				nDevNum++;
		}
	}

	if (nDevNum == 0)
		return 1;

	return 0;
}

void CPGUtility::SetVacantState(tagPGBlock* pBlock, const int nVacantNode, 
								   std::vector<unsigned char>& bBusStateArray, 
								   std::vector<unsigned char>& bSCapStateArray, 
								   std::vector<unsigned char>& bBreakerStateArray, 
								   std::vector<unsigned char>& bSwitchStateArray, 
								   std::vector<unsigned char>& bSwGroundStateArray)
{
	register int	i;
	int		nVolt, nNode;
	int		nNodeNum, nNodeArray[400];

	nVolt=pBlock->m_ConnectivityNodeArray[nVacantNode].nVoltageLevelPtr;
	//AddMessage("���õ�ѹ�ȼ��µ��豸������Ϣ:(%s.%s)\n", pBlock->m_VoltageLevelArray[nVolt].szSub, pBlock->m_VoltageLevelArray[nVolt].szName);

	PGTraverseVolt(pBlock, nVacantNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_BusbarSectionArray[i].nNode)
			{
				bBusStateArray[i]=1;
				//AddMessage("    ����ĸ������:(%s.%s.%s)\n", pBlock->m_BusbarSectionArray[i].szSub, pBlock->m_BusbarSectionArray[i].szVolt, pBlock->m_BusbarSectionArray[i].szName);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].nSeriesCompensatorRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nSeriesCompensatorRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_SeriesCompensatorArray[i].nNodeI || nNodeArray[nNode] == pBlock->m_SeriesCompensatorArray[i].nNodeJ)
			{
				bSCapStateArray[i]=1;
				//AddMessage("    ���ô�����������:(%s.%s.%s)\n", pBlock->m_SeriesCompensatorArray[i].szSub, pBlock->m_SeriesCompensatorArray[i].szVolt, pBlock->m_SeriesCompensatorArray[i].szName);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_BreakerArray[i].nNodeI || nNodeArray[nNode] == pBlock->m_BreakerArray[i].nNodeJ)
			{
				bBreakerStateArray[i]=1;
				//AddMessage("    ���ÿ�������:(%s.%s.%s)\n", pBlock->m_BreakerArray[i].szSub, pBlock->m_BreakerArray[i].szVolt, pBlock->m_BreakerArray[i].szName);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_DisconnectorArray[i].nNodeI || nNodeArray[nNode] == pBlock->m_DisconnectorArray[i].nNodeJ)
			{
				bSwitchStateArray[i]=1;
				//AddMessage("    ɾ����բ����:(%s.%s.%s)\n", pBlock->m_DisconnectorArray[i].szSub, pBlock->m_DisconnectorArray[i].szVolt, pBlock->m_DisconnectorArray[i].szName);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].nGroundDisconnectorRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nGroundDisconnectorRange; i++)
		{
			if (nNodeArray[nNode] == pBlock->m_GroundDisconnectorArray[i].nNode)
			{
				bSwGroundStateArray[i]=1;
				//AddMessage("    ���ýӵص�բ����:(%s.%s.%s)\n", pBlock->m_GroundDisconnectorArray[i].szSub, pBlock->m_GroundDisconnectorArray[i].szVolt, pBlock->m_GroundDisconnectorArray[i].szName);
			}
		}
	}
}

void CPGUtility::GetVacantTran(tagPGBlock* pBlock, std::vector<int>& nVacantArray)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		nTran, nWind;
	int		nTranMidNode, bVacantH, bVacantM, bVacantL;

	nVacantArray.clear();

	for (nTran=0; nTran<pBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nTran++)
	{
		////AddMessage("�ж�����:(%s.%s)\n", pBlock->m_PowerTransformerArray[nTran].szSub, pBlock->m_PowerTransformerArray[nTran].szName);
		if (pBlock->m_PowerTransformerArray[nTran].nWindNum <= 2)
		{
			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);
			bVacantL=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ);
			if (bVacantH && bVacantL || bVacantH || bVacantL)
				nVacantArray.push_back(nTran);
		}
		else
		{
			if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI ||
				pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ)
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI;
			else
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
			bVacantM=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
			bVacantL=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			if (bVacantH && bVacantM && bVacantL || bVacantM && bVacantL || bVacantH && bVacantL || bVacantH && bVacantM)
				nVacantArray.push_back(nTran);
		}
	}
}

void CPGUtility::GetVacantWind(tagPGBlock* pBlock, std::vector<int>& nVacantArray)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		nTran, nWind;
	int		nTranMidNode, bVacantH, bVacantM, bVacantL;

	nVacantArray.clear();

	for (nTran=0; nTran<pBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nTran++)
	{
		//AddMessage("�ж�����:(%s.%s)\n", pBlock->m_PowerTransformerArray[nTran].szSub, pBlock->m_PowerTransformerArray[nTran].szName);
		if (pBlock->m_PowerTransformerArray[nTran].nWindNum <= 2)
		{
			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);
			bVacantL=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ);
			if (bVacantH && bVacantL || bVacantH || bVacantL)
			{
				nVacantArray.push_back(nWind);
			}
		}
		else
		{
			if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI ||
				pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ)
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI;
			else
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
			bVacantM=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
			bVacantL=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			if (bVacantH)
				nVacantArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindH);

			if (bVacantM)
				nVacantArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindM);

			if (bVacantH)
				nVacantArray.push_back(pBlock->m_PowerTransformerArray[nTran].nWindL);
		}
	}
}

void CPGUtility::EraseVacantTran(tagPGBlock* pBlock)
{
	register int	i;
	int		nTran, nWind;
	int		nVacantNode, nTranMidNode, bVacantH, bVacantM, bVacantL;

	std::vector<unsigned char>	bTransformerWindingStateArray;
	std::vector<unsigned char>	bBusbarSectionStateArray;
	std::vector<unsigned char>	bBreakerStateArray;
	std::vector<unsigned char>	bDisconnectorStateArray;
	std::vector<unsigned char>	bGroundDisconnectorStateArray;
	std::vector<unsigned char>	bSeriesCompensatorStateArray;

	bTransformerWindingStateArray.resize	(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	bBusbarSectionStateArray.resize			(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	bBreakerStateArray.resize				(pBlock->m_nRecordNum[PG_BREAKER]);
	bDisconnectorStateArray.resize			(pBlock->m_nRecordNum[PG_DISCONNECTOR]);
	bGroundDisconnectorStateArray.resize	(pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]);
	bSeriesCompensatorStateArray.resize		(pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]);

	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		bTransformerWindingStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		bBusbarSectionStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
		bBreakerStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
		bDisconnectorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]; i++)
		bGroundDisconnectorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
		bSeriesCompensatorStateArray[i]=0;

	for (nTran=0; nTran<pBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nTran++)
	{
		//AddMessage("�ж�����:(%s.%s)\n", pBlock->m_PowerTransformerArray[nTran].szSub, pBlock->m_PowerTransformerArray[nTran].szName);
		if (pBlock->m_PowerTransformerArray[nTran].nWindNum <= 2)
		{
			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);
			bVacantL=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ);
			if (bVacantH && bVacantL || bVacantH || bVacantL)
			{
				bTransformerWindingStateArray[nWind]=1;
				if (bVacantH)
					SetVacantState(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
				if (bVacantL)
					SetVacantState(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
			}
		}
		else
		{
			if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI ||
				pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ)
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI;
			else
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
			bVacantM=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
			bVacantL=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			if (bVacantH && bVacantM && bVacantL || bVacantM && bVacantL || bVacantH && bVacantL || bVacantH && bVacantM)
			{
				bTransformerWindingStateArray[pBlock->m_PowerTransformerArray[nTran].nWindH]=1;
				bTransformerWindingStateArray[pBlock->m_PowerTransformerArray[nTran].nWindM]=1;
				bTransformerWindingStateArray[pBlock->m_PowerTransformerArray[nTran].nWindL]=1;

				if (bVacantH)
				{
					nVacantNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == nTranMidNode) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI;
					SetVacantState(pBlock, nVacantNode, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
				}

				if (bVacantM)
				{
					nVacantNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nTranMidNode) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI;
					SetVacantState(pBlock, nVacantNode, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
				}

				if (bVacantH)
				{
					nVacantNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nTranMidNode) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI;
					SetVacantState(pBlock, nVacantNode, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
				}
			}
		}
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		if (bTransformerWindingStateArray[i])
		{
			AddMessage("ɾ����ѹ��:(%s.%s)\n", pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_TransformerWindingArray[i].szName);
			PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, i);
			bTransformerWindingStateArray.erase(bTransformerWindingStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR])
	{
		if (bGroundDisconnectorStateArray[i])
		{
			AddMessage("ɾ���ӵص�բ:(%s.%s.%s)\n", pBlock->m_GroundDisconnectorArray[i].szSub, pBlock->m_GroundDisconnectorArray[i].szVolt, pBlock->m_GroundDisconnectorArray[i].szName);
			PGRemoveRecord(pBlock, PG_GROUNDDISCONNECTOR, i);
			bGroundDisconnectorStateArray.erase(bGroundDisconnectorStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		if (bDisconnectorStateArray[i])
		{
			AddMessage("ɾ����բ:(%s.%s.%s)\n", pBlock->m_DisconnectorArray[i].szSub, pBlock->m_DisconnectorArray[i].szVolt, pBlock->m_DisconnectorArray[i].szName);
			PGRemoveRecord(pBlock, PG_DISCONNECTOR, i);
			bDisconnectorStateArray.erase(bDisconnectorStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_BREAKER])
	{
		if (bBreakerStateArray[i])
		{
			AddMessage("ɾ������:(%s.%s.%s)\n", pBlock->m_BreakerArray[i].szSub, pBlock->m_BreakerArray[i].szVolt, pBlock->m_BreakerArray[i].szName);
			PGRemoveRecord(pBlock, PG_BREAKER, i);
			bBreakerStateArray.erase(bBreakerStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_BUSBARSECTION])
	{
		if (bBusbarSectionStateArray[i])
		{
			AddMessage("ɾ��ĸ��:(%s.%s.%s)\n", pBlock->m_BusbarSectionArray[i].szSub, pBlock->m_BusbarSectionArray[i].szVolt, pBlock->m_BusbarSectionArray[i].szName);
			PGRemoveRecord(pBlock, PG_BUSBARSECTION, i);
			bBusbarSectionStateArray.erase(bBusbarSectionStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR])
	{
		if (bSeriesCompensatorStateArray[i])
		{
			AddMessage("ɾ����������:(%s.%s.%s)\n", pBlock->m_SeriesCompensatorArray[i].szSub, pBlock->m_SeriesCompensatorArray[i].szVolt, pBlock->m_SeriesCompensatorArray[i].szName);
			PGRemoveRecord(pBlock, PG_SERIESCOMPENSATOR, i);
			bSeriesCompensatorStateArray.erase(bSeriesCompensatorStateArray.begin()+i);
		}
		else
			i++;
	}

	PGMaint(pBlock);

	AddMessage("���ձ�ѹ��ɾ�����");
}

void CPGUtility::EraseVacantWind(tagPGBlock* pBlock)
{
	register int	i;
	int		nTran, nWind;
	int		nVacantNode, nTranMidNode, bVacantH, bVacantM, bVacantL;

	std::vector<unsigned char>	bTransformerWindingStateArray;
	std::vector<unsigned char>	bBusbarSectionStateArray;
	std::vector<unsigned char>	bBreakerStateArray;
	std::vector<unsigned char>	bDisconnectorStateArray;
	std::vector<unsigned char>	bGroundDisconnectorStateArray;
	std::vector<unsigned char>	bSeriesCompensatorStateArray;

	bTransformerWindingStateArray.resize	(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	bBusbarSectionStateArray.resize			(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	bBreakerStateArray.resize				(pBlock->m_nRecordNum[PG_BREAKER]);
	bDisconnectorStateArray.resize			(pBlock->m_nRecordNum[PG_DISCONNECTOR]);
	bGroundDisconnectorStateArray.resize	(pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]);
	bSeriesCompensatorStateArray.resize		(pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]);

	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		bTransformerWindingStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		bBusbarSectionStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
		bBreakerStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
		bDisconnectorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]; i++)
		bGroundDisconnectorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
		bSeriesCompensatorStateArray[i]=0;

	for (nTran=0; nTran<pBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nTran++)
	{
		//AddMessage("�ж�����:(%s.%s)\n", pBlock->m_PowerTransformerArray[nTran].szSub, pBlock->m_PowerTransformerArray[nTran].szName);
		if (pBlock->m_PowerTransformerArray[nTran].nWindNum <= 2)
		{
			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);
			bVacantL=IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ);
			if (bVacantH && bVacantL || bVacantH || bVacantL)
			{
				bTransformerWindingStateArray[nWind]=1;
				if (bVacantH)
					SetVacantState(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
				if (bVacantL)
					SetVacantState(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
			}
		}
		else
		{
			if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI ||
				pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ)
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI;
			else
				nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
			bVacantH=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
			bVacantM=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
			bVacantL=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMidNode) ? IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeJ) : IsNodeVacant(pBlock, pBlock->m_TransformerWindingArray[nWind].nNodeI);

			if (bVacantH)
			{
				bTransformerWindingStateArray[pBlock->m_PowerTransformerArray[nTran].nWindH]=1;
				nVacantNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == nTranMidNode) ?
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI;
				SetVacantState(pBlock, nVacantNode, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
			}

			if (bVacantM)
			{
				bTransformerWindingStateArray[pBlock->m_PowerTransformerArray[nTran].nWindM]=1;
				nVacantNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nTranMidNode) ?
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI;
				SetVacantState(pBlock, nVacantNode, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
			}

			if (bVacantH)
			{
				bTransformerWindingStateArray[pBlock->m_PowerTransformerArray[nTran].nWindL]=1;
				nVacantNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nTranMidNode) ?
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI;
				SetVacantState(pBlock, nVacantNode, bBusbarSectionStateArray, bSeriesCompensatorStateArray, bBreakerStateArray, bDisconnectorStateArray, bGroundDisconnectorStateArray);
			}
		}
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		if (bTransformerWindingStateArray[i])
		{
			AddMessage("ɾ����ѹ��:(%s.%s)\n", pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_TransformerWindingArray[i].szName);
			PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, i);
			bTransformerWindingStateArray.erase(bTransformerWindingStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR])
	{
		if (bGroundDisconnectorStateArray[i])
		{
			AddMessage("ɾ���ӵص�բ:(%s.%s.%s)\n", pBlock->m_GroundDisconnectorArray[i].szSub, pBlock->m_GroundDisconnectorArray[i].szVolt, pBlock->m_GroundDisconnectorArray[i].szName);
			PGRemoveRecord(pBlock, PG_GROUNDDISCONNECTOR, i);
			bGroundDisconnectorStateArray.erase(bGroundDisconnectorStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		if (bDisconnectorStateArray[i])
		{
			AddMessage("ɾ����բ:(%s.%s.%s)\n", pBlock->m_DisconnectorArray[i].szSub, pBlock->m_DisconnectorArray[i].szVolt, pBlock->m_DisconnectorArray[i].szName);
			PGRemoveRecord(pBlock, PG_DISCONNECTOR, i);
			bDisconnectorStateArray.erase(bDisconnectorStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_BREAKER])
	{
		if (bBreakerStateArray[i])
		{
			AddMessage("ɾ������:(%s.%s.%s)\n", pBlock->m_BreakerArray[i].szSub, pBlock->m_BreakerArray[i].szVolt, pBlock->m_BreakerArray[i].szName);
			PGRemoveRecord(pBlock, PG_BREAKER, i);
			bBreakerStateArray.erase(bBreakerStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_BUSBARSECTION])
	{
		if (bBusbarSectionStateArray[i])
		{
			AddMessage("ɾ��ĸ��:(%s.%s.%s)\n", pBlock->m_BusbarSectionArray[i].szSub, pBlock->m_BusbarSectionArray[i].szVolt, pBlock->m_BusbarSectionArray[i].szName);
			PGRemoveRecord(pBlock, PG_BUSBARSECTION, i);
			bBusbarSectionStateArray.erase(bBusbarSectionStateArray.begin()+i);
		}
		else
			i++;
	}

	i=0;
	while (i < pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR])
	{
		if (bSeriesCompensatorStateArray[i])
		{
			AddMessage("ɾ����������:(%s.%s.%s)\n", pBlock->m_SeriesCompensatorArray[i].szSub, pBlock->m_SeriesCompensatorArray[i].szVolt, pBlock->m_SeriesCompensatorArray[i].szName);
			PGRemoveRecord(pBlock, PG_SERIESCOMPENSATOR, i);
			bSeriesCompensatorStateArray.erase(bSeriesCompensatorStateArray.begin()+i);
		}
		else
			i++;
	}

	PGMaint(pBlock);

	AddMessage("���ձ�ѹ��ɾ�����");
}
