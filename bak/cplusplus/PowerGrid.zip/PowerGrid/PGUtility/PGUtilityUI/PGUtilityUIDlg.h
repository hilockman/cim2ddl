
// PGUtilityUIDlg.h : ͷ�ļ�
//

#pragma once


// CPGUtilityUIDlg �Ի���
class CPGUtilityUIDlg : public CDialog
{
// ����
public:
	CPGUtilityUIDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PGUTILITYUI_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnUtilityMenu();
	afx_msg void OnBnClickedLowVGen2Load();
	afx_msg void OnBnClickedRemoveVacantTran();
	afx_msg void OnBnClickedRemoveLowvshuntcap();
	afx_msg void OnBnClickedRemoveVacantWind();
	afx_msg void OnEnChangeGenlowvThreshold();
	afx_msg void OnEnChangeShuntcaplowvThreshold();
	afx_msg void OnEnChangeLowvThreshold();
	afx_msg void OnBnClickedLowvLine2load();
	afx_msg void OnBnClickedDecompose();
	afx_msg void OnBnClickedClearMesg();
	afx_msg void OnBnClickedDcflow();
	afx_msg void OnBnClickedDcflowTrip();
	DECLARE_MESSAGE_MAP()

public:
	void	PrintMessage(const char* lpszMesg);

private:
	int		GetTextLen(LPCTSTR lpszText);

	void	RefreshLowVGen();
	void	RefreshLowVPCap();
	void	RefreshLowVLine();
	void	RefreshVacantTran();
	void	RefreshVacantWind();

	void	RefreshRingLineList();
	void	RefreshRingTranList();
	void	RefreshBoundLineList();
	void	RefreshBoundTranList();
	void	RefreshRadiateList();

	void	RefreshDCFlowBusList();
	void	RefreshDCFlowBranchList();

private:
	CMFCMenuButton		m_btnUtility;
	CMFCTabCtrl			m_wndTab;
	CMFCListCtrl		m_wndListLowVGen, m_wndListLowVPCap, m_wndListLowVLine, m_wndListLowVNet;
	CMFCListCtrl		m_wndListVacantTran, m_wndListVacantWind;

	CMFCListCtrl		m_wndListRingLine, m_wndListRingTran, m_wndListBoundLine, m_wndListBoundTran, m_wndListRadiate;
	CMFCListCtrl		m_wndListFlowBus, m_wndListFlowBranch;

	CMenu				m_menuUtility;

private:
	double m_fGenLowVThreshold;
	double m_fPCapLowVThreshold;
	double m_fLowVThreshold;
private:
	std::vector<int>	m_VancantTranArray;
	std::vector<int>	m_VancantWindArray;
};
