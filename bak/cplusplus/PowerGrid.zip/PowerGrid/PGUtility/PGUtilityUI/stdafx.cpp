
// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// PGUtilityUI.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PRMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PRMemDB.lib")
#endif

#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib/libDCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../lib/libDCNetworkMD.lib")
#	endif
#	pragma message("Link LibX86 DCNetwork.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib_x64/libDCNetworkMDd.lib")
#	else
#		pragma comment(lib, "../../../lib_x64/libDCNetworkMD.lib")
#	endif
#	pragma message("Link LibX64 DCNetwork.lib")
#endif

#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif
