
// PGUtilityUIDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGUtilityUI.h"
#include "PGUtilityUIDlg.h"
#include "TripDevSelectDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPGUtilityUIDlg �Ի���

static	const	char*	lpszDeviceColumn[]=
{
	"���", 
	"�豸����", 
	"��վ����", 
	"��ѹ�ȼ�", 
	"�豸����", 
};

static	const	char*	lpszGenColumn[]=
{
	"���", 
	"�豸����", 
	"��վ����", 
	"��ѹ�ȼ�", 
	"�豸����", 
	"����й�", 
	"����޹�", 
	"�й�����", 
	"�޹�����", 
};

static	const	char*	lpszPCapColumn[]=
{
	"���", 
	"�豸����", 
	"��վ����", 
	"��ѹ�ȼ�", 
	"�豸����", 
	"����", 
};

static	const	char*	lpszLineColumn[]=
{
	"���", 
	"�豸����", 
	"��վ", 
	"�ճ�վ", 
	"��ѹ�ȼ�", 
	"����", 
	"������", 
};

static	char*	lpszRingColumn[]={
	"���", 
	"����", 
	"����Ϣ", 
	"����Ϣ", 
};
static	char*	lpszBoundColumn[]={
	"���", 
	"����", 
	"����Ϣ", 
	"����Ϣ", 
	"�й�", 
	"�޹�", 
};
static	char*	lpszRadiateColumn[]={
	"���", 
	"�豸����", 
	"��ڵ�", 
	"�սڵ�", 
};

static	char*	lpszDCFlowBusColumn[]={
	"���", 
	"����", 
	"����ڵ�", 
	"����", 
	"����", 
	"����", 
	"���Ե���", 
	"��Դ���", 
	"��Ч���", 
};
static	char*	lpszDCFlowBranchColumn[]={
	"���", 
	"����", 
	"��ڵ�", 
	"�սڵ�", 
	"�翹", 
	"��ֵ", 
	"����I", 
	"����Z", 
	"������", 
	"׼ȷ��", 
};



CPGUtilityUIDlg::CPGUtilityUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPGUtilityUIDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_fGenLowVThreshold=1.0;
	m_fPCapLowVThreshold=100;
	m_fLowVThreshold=120;
}

void CPGUtilityUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_UTILITY, m_btnUtility);
	DDX_Text(pDX, IDC_GENLOWV_THRESHOLD, m_fGenLowVThreshold);
	DDX_Text(pDX, IDC_SHUNTCAPLOWV_THRESHOLD, m_fPCapLowVThreshold);
	DDX_Text(pDX, IDC_LOWV_THRESHOLD, m_fLowVThreshold);
}

BEGIN_MESSAGE_MAP(CPGUtilityUIDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_UTILITY, OnUtilityMenu)
	ON_BN_CLICKED(IDC_LOWV_GEN2LOAD, &CPGUtilityUIDlg::OnBnClickedLowVGen2Load)
	ON_BN_CLICKED(IDC_REMOVE_VACANT_TRAN, &CPGUtilityUIDlg::OnBnClickedRemoveVacantTran)
	ON_BN_CLICKED(IDC_REMOVE_LOWVSHUNTCAP, &CPGUtilityUIDlg::OnBnClickedRemoveLowvshuntcap)
	ON_BN_CLICKED(IDC_REMOVE_VACANT_WIND, &CPGUtilityUIDlg::OnBnClickedRemoveVacantWind)
	ON_EN_CHANGE(IDC_GENLOWV_THRESHOLD, &CPGUtilityUIDlg::OnEnChangeGenlowvThreshold)
	ON_EN_CHANGE(IDC_SHUNTCAPLOWV_THRESHOLD, &CPGUtilityUIDlg::OnEnChangeShuntcaplowvThreshold)
	ON_EN_CHANGE(IDC_LOWV_THRESHOLD, &CPGUtilityUIDlg::OnEnChangeLowvThreshold)
	ON_BN_CLICKED(IDC_LOWV_LINE2LOAD, &CPGUtilityUIDlg::OnBnClickedLowvLine2load)
	ON_BN_CLICKED(IDC_DECOMPOSE, &CPGUtilityUIDlg::OnBnClickedDecompose)
	ON_BN_CLICKED(IDC_CLEAR_MESG, &CPGUtilityUIDlg::OnBnClickedClearMesg)
	ON_BN_CLICKED(IDC_DCFLOW, &CPGUtilityUIDlg::OnBnClickedDcflow)
	ON_BN_CLICKED(IDC_DCFLOW_TRIP, &CPGUtilityUIDlg::OnBnClickedDcflowTrip)
END_MESSAGE_MAP()


// CPGUtilityUIDlg ��Ϣ��������

BOOL CPGUtilityUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������

	register int	i;
	int		nColumn;
	CRect	rectBuf;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListLowVGen.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 11))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLowVGen.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLowVGen.SetExtendedStyle(m_wndListLowVGen.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLowVGen.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	nColumn=0;
	for (i=0; i<sizeof(lpszGenColumn)/sizeof(char*); i++)
		m_wndListLowVGen.InsertColumn(nColumn++, lpszGenColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLowVPCap.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 12))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLowVPCap.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLowVPCap.SetExtendedStyle(m_wndListLowVPCap.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLowVPCap.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	nColumn=0;
	for (i=0; i<sizeof(lpszPCapColumn)/sizeof(char*); i++)
		m_wndListLowVPCap.InsertColumn(nColumn++, lpszPCapColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLowVLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 13))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLowVLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLowVLine.SetExtendedStyle(m_wndListLowVLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLowVLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	nColumn=0;
	for (i=0; i<sizeof(lpszLineColumn)/sizeof(char*); i++)
		m_wndListLowVLine.InsertColumn(nColumn++, lpszLineColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLowVNet.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 14))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLowVNet.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLowVNet.SetExtendedStyle(m_wndListLowVNet.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLowVNet.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszDeviceColumn)/sizeof(char*); nColumn++)
		m_wndListLowVNet.InsertColumn(nColumn, lpszDeviceColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListVacantTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 21))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListVacantTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListVacantTran.SetExtendedStyle(m_wndListVacantTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListVacantTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszDeviceColumn)/sizeof(char*); nColumn++)
		m_wndListVacantTran.InsertColumn(nColumn, lpszDeviceColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListVacantWind.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 22))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListVacantWind.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListVacantWind.SetExtendedStyle(m_wndListVacantWind.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListVacantWind.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszDeviceColumn)/sizeof(char*); nColumn++)
		m_wndListVacantWind.InsertColumn(nColumn, lpszDeviceColumn[nColumn],	LVCFMT_LEFT,	100);





	if (!m_wndListRingLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 31))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRingLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRingLine.SetExtendedStyle(m_wndListRingLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRingLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRingColumn)/sizeof(char*); nColumn++)
		m_wndListRingLine.InsertColumn(nColumn, lpszRingColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListRingTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 32))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRingTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRingTran.SetExtendedStyle(m_wndListRingTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRingTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRingColumn)/sizeof(char*); nColumn++)
		m_wndListRingTran.InsertColumn(nColumn, lpszRingColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBoundLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 33))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBoundLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBoundLine.SetExtendedStyle(m_wndListBoundLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBoundLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszBoundColumn)/sizeof(char*); nColumn++)
		m_wndListBoundLine.InsertColumn(nColumn, lpszBoundColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBoundTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 34))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBoundTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBoundTran.SetExtendedStyle(m_wndListBoundTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBoundTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszBoundColumn)/sizeof(char*); nColumn++)
		m_wndListBoundTran.InsertColumn(nColumn, lpszBoundColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListRadiate.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 35))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRadiate.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRadiate.SetExtendedStyle(m_wndListRadiate.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRadiate.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRadiateColumn)/sizeof(char*); nColumn++)
		m_wndListRadiate.InsertColumn(nColumn, lpszRadiateColumn[nColumn],	LVCFMT_LEFT,	100);


	if (!m_wndListFlowBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 41))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListFlowBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListFlowBus.SetExtendedStyle(m_wndListFlowBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListFlowBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszDCFlowBusColumn)/sizeof(char*); nColumn++)
		m_wndListFlowBus.InsertColumn(nColumn, lpszDCFlowBusColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListFlowBranch.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 42))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListFlowBranch.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListFlowBranch.SetExtendedStyle(m_wndListFlowBranch.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListFlowBranch.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszDCFlowBranchColumn)/sizeof(char*); nColumn++)
		m_wndListFlowBranch.InsertColumn(nColumn, lpszDCFlowBranchColumn[nColumn],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndListLowVGen,			_T("��ѹ�����"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListLowVPCap,		_T("��ѹ��������"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListLowVLine,		_T("��ѹ��·"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListLowVNet,			_T("��ѹ����"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListVacantTran,		_T("���յ�����ѹ��"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListVacantWind,		_T("���ձ�ѹ������"),	-1, FALSE);

	m_wndTab.AddTab (&m_wndListRingLine,		_T("������·"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListRingTran,		_T("������ѹ��"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListBoundLine,		_T("�߽���·"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListBoundTran,		_T("�߽��ѹ��"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListRadiate,			_T("������"),			-1, FALSE);

	m_wndTab.AddTab (&m_wndListFlowBus,			_T("ֱ����������ĸ��"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListFlowBranch,		_T("ֱ����������֧·"),	-1, FALSE);

	m_menuUtility.LoadMenu(IDR_UTILITY_MENU);
	m_btnUtility.m_hMenu = m_menuUtility.GetSubMenu(0)->GetSafeHmenu();
	m_btnUtility.m_bOSMenu = FALSE;

	RefreshLowVGen();
	RefreshLowVPCap();
	RefreshLowVLine();

	RefreshVacantTran();
	RefreshVacantWind();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CPGUtilityUIDlg::OnUtilityMenu()
{
	switch (m_btnUtility.m_nMenuResult)
	{
	case	ID_VACANT_TRAN:
		g_PGUtility.GetVacantTran(g_pPGBlock, m_VancantTranArray);
		RefreshVacantTran();
		break;
	case	ID_VACANT_WIND:
		g_PGUtility.GetVacantWind(g_pPGBlock, m_VancantWindArray);
		RefreshVacantWind();
		break;
	case	ID_LOWV_NET:
		break;
	case	ID_SAME_BREAKER_LINE:
		break;
	case	ID_REFRESH:
		RefreshLowVGen();
		RefreshLowVPCap();
		RefreshLowVLine();

		break;
	default:
		return;
		break;
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CPGUtilityUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CPGUtilityUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


int CPGUtilityUIDlg::GetTextLen(LPCTSTR lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC* pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(lpszText, (int) _tcslen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(lpszText, (int) _tcslen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void	CPGUtilityUIDlg::PrintMessage(const char* lpszMesg)
{
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	int			iExt = GetTextLen(lpszMesg);
	pListBox->AddString(lpszMesg);
	if (iExt > pListBox->GetHorizontalExtent())
		pListBox->SetHorizontalExtent(iExt);
}

void CPGUtilityUIDlg::OnBnClickedLowVGen2Load()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	g_PGUtility.LowVGen2Load(g_pPGBlock, m_fGenLowVThreshold);
	AddMessage("��ѹ������������");
}

void CPGUtilityUIDlg::OnBnClickedRemoveLowvshuntcap()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	g_PGUtility.EraseLowVPCap(g_pPGBlock, m_fPCapLowVThreshold);
	AddMessage("��ѹ���������������");
}

void CPGUtilityUIDlg::OnBnClickedRemoveVacantTran()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	g_PGUtility.EraseVacantTran(g_pPGBlock);
}

void CPGUtilityUIDlg::OnBnClickedRemoveVacantWind()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	g_PGUtility.EraseVacantWind(g_pPGBlock);
}

void CPGUtilityUIDlg::OnEnChangeGenlowvThreshold()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	RefreshLowVGen();
}

void CPGUtilityUIDlg::OnEnChangeShuntcaplowvThreshold()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	RefreshLowVPCap();
}

void CPGUtilityUIDlg::OnEnChangeLowvThreshold()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	RefreshLowVLine();
}

void CPGUtilityUIDlg::OnBnClickedLowvLine2load()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	g_PGUtility.LowVLine2Load(g_pPGBlock, m_fLowVThreshold);
}

void CPGUtilityUIDlg::OnBnClickedDecompose()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	g_PGUtility.Decompose(g_pPGBlock, m_fLowVThreshold);

	RefreshRingLineList();
	RefreshRingTranList();
	RefreshBoundLineList();
	RefreshBoundTranList();
	RefreshRadiateList();
	//RefreshHubSubList();
}

void CPGUtilityUIDlg::OnBnClickedClearMesg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	pListBox->ResetContent();
}

void CPGUtilityUIDlg::OnBnClickedDcflow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	g_DCFlow.PGDCFlow(g_pPGBlock);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	AddMessage("������ϣ���ʱ%d����\n", nDur);

	RefreshDCFlowBusList();
	RefreshDCFlowBranchList();
}

void	CPGUtilityUIDlg::RefreshLowVGen()
{
	int		nSub, nVolt, nDev, nRow, nCol;
	char	szBuf[260];

	UpdateData();

	m_wndListLowVGen.DeleteAllItems();

	nRow=0;
	for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=g_pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (g_pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= m_fGenLowVThreshold)
				continue;

			for (nDev=g_pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<g_pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				sprintf(szBuf, "%d", nRow+1);	m_wndListLowVGen.InsertItem(nRow, szBuf);

				nCol=1;
				m_wndListLowVGen.SetItemText(nRow, nCol++, PGGetTableDesp(PG_SYNCHRONOUSMACHINE));
				m_wndListLowVGen.SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nDev].szSub);
				m_wndListLowVGen.SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nDev].szVolt);
				m_wndListLowVGen.SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nDev].szName);

				sprintf(szBuf, "%.2f", g_pPGBlock->m_SynchronousMachineArray[nDev].fPMax);		m_wndListLowVGen.SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%.2f", g_pPGBlock->m_SynchronousMachineArray[nDev].fQMax);		m_wndListLowVGen.SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%.2f", g_pPGBlock->m_SynchronousMachineArray[nDev].fPlanP);	m_wndListLowVGen.SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%.2f", g_pPGBlock->m_SynchronousMachineArray[nDev].fPlanQ);	m_wndListLowVGen.SetItemText(nRow, nCol++, szBuf);

				nRow++;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszGenColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLowVGen.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLowVGen.GetColumnWidth(nCol);
		m_wndListLowVGen.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLowVGen.GetColumnWidth(nCol);

		m_wndListLowVGen.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CPGUtilityUIDlg::RefreshLowVPCap()
{
	int		nSub, nVolt, nDev, nRow, nCol;
	char	szBuf[260];

	UpdateData();

	m_wndListLowVPCap.DeleteAllItems();

	nRow=0;
	for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=g_pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (g_pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= m_fPCapLowVThreshold)
				continue;

			for (nDev=g_pPGBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nDev<g_pPGBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nDev++)
			{
				sprintf(szBuf, "%d", nRow+1);	m_wndListLowVPCap.InsertItem(nRow, szBuf);

				nCol=1;
				m_wndListLowVPCap.SetItemText(nRow, nCol++, PGGetTableDesp(PG_SHUNTCOMPENSATOR));
				m_wndListLowVPCap.SetItemText(nRow, nCol++, g_pPGBlock->m_ShuntCompensatorArray[nDev].szSub);
				m_wndListLowVPCap.SetItemText(nRow, nCol++, g_pPGBlock->m_ShuntCompensatorArray[nDev].szVolt);
				m_wndListLowVPCap.SetItemText(nRow, nCol++, g_pPGBlock->m_ShuntCompensatorArray[nDev].szName);

				sprintf(szBuf, "%.2f", g_pPGBlock->m_ShuntCompensatorArray[nDev].fCap);	m_wndListLowVPCap.SetItemText(nRow, nCol++, szBuf);

				nRow++;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPCapColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLowVPCap.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLowVPCap.GetColumnWidth(nCol);
		m_wndListLowVPCap.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLowVPCap.GetColumnWidth(nCol);

		m_wndListLowVPCap.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CPGUtilityUIDlg::RefreshLowVLine()
{
	int		nVolt, nDev, nRow, nCol;
	char	szBuf[260];

	UpdateData();

	m_wndListLowVLine.DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		nVolt=PGFindRecordbyKey(g_pPGBlock, PG_VOLTAGELEVEL, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubI, g_pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (nVolt < 0)
			continue;
		if (g_pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= m_fLowVThreshold)
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListLowVLine.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListLowVLine.SetItemText(nRow, nCol++, PGGetTableDesp(PG_ACLINESEGMENT));
		m_wndListLowVLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubI);
		m_wndListLowVLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubJ);
		m_wndListLowVLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
		m_wndListLowVLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[nDev].szName);

		sprintf(szBuf, "%.2f", g_pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur);	m_wndListLowVLine.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLowVLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLowVLine.GetColumnWidth(nCol);
		m_wndListLowVLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLowVLine.GetColumnWidth(nCol);

		m_wndListLowVLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CPGUtilityUIDlg::RefreshVacantTran()
{
	int		nDev, nRow, nCol;
	char	szBuf[260];

	UpdateData();

	m_wndListVacantTran.DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<(int)m_VancantTranArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nRow+1);	m_wndListVacantTran.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListVacantTran.SetItemText(nRow, nCol++, PGGetTableDesp(PG_POWERTRANSFORMER));
		m_wndListVacantTran.SetItemText(nRow, nCol++, g_pPGBlock->m_PowerTransformerArray[nDev].szSub);
		nCol++;
		m_wndListVacantTran.SetItemText(nRow, nCol++, g_pPGBlock->m_PowerTransformerArray[nDev].szName);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDeviceColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListVacantTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListVacantTran.GetColumnWidth(nCol);
		m_wndListVacantTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListVacantTran.GetColumnWidth(nCol);

		m_wndListVacantTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CPGUtilityUIDlg::RefreshVacantWind()
{
	int		nDev, nRow, nCol;
	char	szBuf[260];

	UpdateData();

	m_wndListVacantWind.DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<(int)m_VancantWindArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nRow+1);	m_wndListVacantWind.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListVacantWind.SetItemText(nRow, nCol++, PGGetTableDesp(PG_TRANSFORMERWINDING));
		m_wndListVacantWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[m_VancantWindArray[nDev]].szSub);
		nCol++;
		m_wndListVacantWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[m_VancantWindArray[nDev]].szName);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDeviceColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListVacantWind.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListVacantWind.GetColumnWidth(nCol);
		m_wndListVacantWind.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListVacantWind.GetColumnWidth(nCol);

		m_wndListVacantWind.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::RefreshRingLineList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListRingLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (!g_PGUtility.m_bRingedLineArray[i])
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListRingLine.InsertItem(nRow, szBuf);		m_wndListRingLine.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s(%s)", g_pPGBlock->m_ACLineSegmentArray[i].szName, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
		m_wndListRingLine.SetItemText(nRow, nCol++, szBuf);
		m_wndListRingLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
		m_wndListRingLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubJ);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszRingColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRingLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRingLine.GetColumnWidth(nCol);
		m_wndListRingLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRingLine.GetColumnWidth(nCol);

		m_wndListRingLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::RefreshRingTranList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListRingTran.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (!g_PGUtility.m_bRingedTranArray[i])
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListRingTran.InsertItem(nRow, szBuf);		m_wndListRingTran.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s.%s", g_pPGBlock->m_TransformerWindingArray[i].szSub, g_pPGBlock->m_TransformerWindingArray[i].szName);
		m_wndListRingTran.SetItemText(nRow, nCol++,	szBuf);
		m_wndListRingTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltI);
		m_wndListRingTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltI);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszRingColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRingTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRingTran.GetColumnWidth(nCol);
		m_wndListRingTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRingTran.GetColumnWidth(nCol);

		m_wndListRingTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::RefreshBoundLineList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListBoundLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PGUtility.m_BoundLineArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	m_wndListBoundLine.InsertItem(nRow, szBuf);		m_wndListBoundLine.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s(%s)", g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_BoundLineArray[i].nBoundDevice].szName, g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_BoundLineArray[i].nBoundDevice].szVoltI);
		m_wndListBoundLine.SetItemText(nRow, nCol++, szBuf);
		m_wndListBoundLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_BoundLineArray[i].nBoundDevice].szSubI);
		m_wndListBoundLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_BoundLineArray[i].nBoundDevice].szSubJ);

		sprintf(szBuf, "%.2f", g_PGUtility.m_BoundLineArray[i].fP);	m_wndListBoundLine.SetItemText(nRow, nCol++,	szBuf);
		sprintf(szBuf, "%.2f", g_PGUtility.m_BoundLineArray[i].fQ);	m_wndListBoundLine.SetItemText(nRow, nCol++,	szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBoundColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBoundLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBoundLine.GetColumnWidth(nCol);
		m_wndListBoundLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBoundLine.GetColumnWidth(nCol);

		m_wndListBoundLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::RefreshBoundTranList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListBoundTran.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PGUtility.m_BoundTranArray.size(); i++)
	{
		sprintf(szBuf, "%d", nRow+1);	m_wndListBoundTran.InsertItem(nRow, szBuf);		m_wndListBoundTran.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s.%s", g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_BoundTranArray[i].nBoundDevice].szSub, g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_BoundTranArray[i].nBoundDevice].szName);
		m_wndListBoundTran.SetItemText(nRow, nCol++,	szBuf);
		m_wndListBoundTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_BoundTranArray[i].nBoundDevice].szVoltI);
		m_wndListBoundTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_BoundTranArray[i].nBoundDevice].szVoltI);

		sprintf(szBuf, "%.2f", g_PGUtility.m_BoundTranArray[i].fP);	m_wndListBoundTran.SetItemText(nRow, nCol++,	szBuf);
		sprintf(szBuf, "%.2f", g_PGUtility.m_BoundTranArray[i].fQ);	m_wndListBoundTran.SetItemText(nRow, nCol++,	szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBoundColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBoundTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBoundTran.GetColumnWidth(nCol);
		m_wndListBoundTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBoundTran.GetColumnWidth(nCol);

		m_wndListBoundTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::RefreshRadiateList()
{
	register int	i;
	int		nGroup, nRow, nCol;
	char	szBuf[260];

	m_wndListRadiate.DeleteAllItems();

	nRow=0;
	for (nGroup=0; nGroup<(int)g_PGUtility.m_RadiateArray.size(); nGroup++)
	{
		sprintf(szBuf, "%d %.2f (%d, %d, %d)", nGroup+1, g_PGUtility.m_RadiateArray[nGroup].fLoadP, g_PGUtility.m_RadiateArray[nGroup].nBoundBusArray.size(), g_PGUtility.m_RadiateArray[nGroup].nLineArray.size(), g_PGUtility.m_RadiateArray[nGroup].nTranArray.size());	m_wndListRadiate.InsertItem(nRow++, szBuf);		m_wndListRadiate.SetItemData(nRow, nRow);

		for (i=0; i<(int)g_PGUtility.m_RadiateArray[nGroup].nBoundBusArray.size(); i++)
		{
			m_wndListRadiate.InsertItem(nRow, "");	m_wndListRadiate.SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf, "%d", g_PGUtility.m_RadiateArray[nGroup].nBoundBusArray[i]);
			m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}

		for (i=0; i<(int)g_PGUtility.m_RadiateArray[nGroup].nLineArray.size(); i++)
		{
			m_wndListRadiate.InsertItem(nRow, "");	m_wndListRadiate.SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf, "%s(%s)", g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_RadiateArray[nGroup].nLineArray[i]].szName, g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_RadiateArray[nGroup].nLineArray[i]].szVoltI);
			m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			m_wndListRadiate.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_RadiateArray[nGroup].nLineArray[i]].szSubI);
			m_wndListRadiate.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[g_PGUtility.m_RadiateArray[nGroup].nLineArray[i]].szSubJ);
			nRow++;
		}
		for (i=0; i<(int)g_PGUtility.m_RadiateArray[nGroup].nTranArray.size(); i++)
		{
			m_wndListRadiate.InsertItem(nRow, "");	m_wndListRadiate.SetItemData(nRow, nRow);
			nCol=1;
			sprintf(szBuf, "%s(%s)", g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_RadiateArray[nGroup].nTranArray[i]].szSub, g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_RadiateArray[nGroup].nTranArray[i]].szName);
			m_wndListRadiate.SetItemText(nRow, nCol++, szBuf);
			m_wndListRadiate.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_RadiateArray[nGroup].nTranArray[i]].szVoltI);
			m_wndListRadiate.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[g_PGUtility.m_RadiateArray[nGroup].nTranArray[i]].szVoltJ);
			nRow++;
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<6; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRadiate.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRadiate.GetColumnWidth(nCol);
		m_wndListRadiate.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRadiate.GetColumnWidth(nCol);

		m_wndListRadiate.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::RefreshDCFlowBusList()
{
	int		nRow, nCol;
	char	szBuf[260];
	double	fTotalGen, fTotalLoad;

	m_wndListFlowBus.DeleteAllItems();

	fTotalGen=fTotalLoad=0;

	nRow=0;

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDCFlowBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListFlowBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListFlowBus.GetColumnWidth(nCol);
		m_wndListFlowBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListFlowBus.GetColumnWidth(nCol);

		m_wndListFlowBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	sprintf(szBuf, "%.2f", fTotalGen);	GetDlgItem(IDC_TOTALGEN)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", fTotalLoad);	GetDlgItem(IDC_TOTALLOAD)->SetWindowText(szBuf);
}

void CPGUtilityUIDlg::RefreshDCFlowBranchList()
{
	int		nRow, nCol;

	m_wndListFlowBranch.DeleteAllItems();

	nRow=0;

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszDCFlowBranchColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListFlowBranch.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListFlowBranch.GetColumnWidth(nCol);
		m_wndListFlowBranch.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListFlowBranch.GetColumnWidth(nCol);

		m_wndListFlowBranch.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGUtilityUIDlg::OnBnClickedDcflowTrip()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CTripDevSelectDialog	dlg;
	if (dlg.DoModal() != IDOK)
		return;

	if (dlg.m_nDeviceType < 0)
		return;
	if (dlg.m_strDeviceName.GetLength() <= 0)
		return;

	//g_DCFlow.DCTrip(g_pPRBlock, dlg.m_nDeviceType, dlg.m_strDeviceName);
}
