//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PGUtilityUI.rc
//
#define IDD_PGUTILITYUI_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDR_UTILITY_MENU                129
#define IDD_TRIPDEV_DIALOG              130
#define IDC_LOWV_GEN2LOAD               1000
#define IDC_GENLOWV_THRESHOLD           1001
#define IDC_MESG_LIST                   1002
#define IDC_REMOVE_VACANT_TRAN          1003
#define IDC_REMOVE_LOWVSHUNTCAP         1004
#define IDC_SHUNTCAPLOWV_THRESHOLD      1005
#define IDC_REMOVE_VACANT_WIND          1006
#define IDC_LOWV_THRESHOLD              1007
#define IDC_LOWV_LINE2LOAD              1008
#define IDC_REMOVE_LOWV_NET             1009
#define IDC_TAB                         1010
#define IDC_UTILITY                     1011
#define IDC_CLEAR_MESG                  1012
#define IDC_TOTALGEN                    1013
#define IDC_TOTALLOAD                   1014
#define IDC_DEVTYPE_COMBO               1014
#define IDC_DEVICE_LIST                 1015
#define IDC_DEVSUB_COMBO                1016
#define IDC_DECOMPOSE                   1017
#define IDC_DCFLOW                      1018
#define IDC_DCFLOW_TRIP                 1019
#define ID_VACANT_TRAN                  32773
#define ID_VACANT_WIND                  32774
#define ID_LOWV_NET                     32776
#define ID_REFRESH                      32778
#define ID_SAME_BREAKER_LINE            32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
