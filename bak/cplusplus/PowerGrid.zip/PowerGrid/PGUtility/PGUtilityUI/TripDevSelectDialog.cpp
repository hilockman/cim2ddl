// TripDevSelectDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGUtilityUI.h"
#include "TripDevSelectDialog.h"


// CTripDevSelectDialog �Ի���

IMPLEMENT_DYNAMIC(CTripDevSelectDialog, CDialog)

CTripDevSelectDialog::CTripDevSelectDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTripDevSelectDialog::IDD, pParent)
{
	m_nDeviceType=-1;
	m_strDeviceName=_T("");
}

CTripDevSelectDialog::~CTripDevSelectDialog()
{
}

void CTripDevSelectDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CTripDevSelectDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CTripDevSelectDialog::OnCbnSelchangeDevtypeCombo)
	ON_CBN_SELCHANGE(IDC_DEVSUB_COMBO, &CTripDevSelectDialog::OnCbnSelchangeDevsubCombo)
	ON_BN_CLICKED(IDOK, &CTripDevSelectDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CTripDevSelectDialog ��Ϣ��������

BOOL CTripDevSelectDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_DEVICE_LIST);
	pListBox->ResetContent();

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DEVSUB_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pCombo->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("��·");
	pCombo->AddString("��ѹ��");
	pCombo->SetCurSel(m_nDeviceType);

	RefreshDeviceList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CTripDevSelectDialog::RefreshDeviceList()
{
	//CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	//int	nType=pCombo->GetCurSel();
	//if (nType == CB_ERR)
	//	return;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_DEVICE_LIST);
	pListBox->ResetContent();

	if (m_nDeviceType < 0)
		return;

	char	szSub[MDB_CHARLEN];
	memset(szSub, 0, MDB_CHARLEN);
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DEVSUB_COMBO);
	int		nSub=pCombo->GetCurSel();
	if (nSub != CB_ERR)
		pCombo->GetLBText(nSub, szSub);

	register int	i;
	std::string	strName;
	if (m_nDeviceType == 0)
	{
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (strlen(szSub) > 0)
			{
				if (stricmp(g_pPGBlock->m_ACLineSegmentArray[i].szSubI, szSub) != 0 && stricmp(g_pPGBlock->m_ACLineSegmentArray[i].szSubJ, szSub) != 0)
					continue;
			}
			strName=g_pPGBlock->m_ACLineSegmentArray[i].szName;
			strName.append("(").append(g_pPGBlock->m_ACLineSegmentArray[i].szSubI).append("<->").append(g_pPGBlock->m_ACLineSegmentArray[i].szSubJ).append(")");
			pListBox->AddString(strName.c_str());
		}
	}
	else
	{
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		{
			if (strlen(szSub) > 0)
			{
				if (stricmp(g_pPGBlock->m_TransformerWindingArray[i].szSub, szSub) != 0)
					continue;
			}
			strName=g_pPGBlock->m_TransformerWindingArray[i].szSub;
			strName.append(g_pPGBlock->m_TransformerWindingArray[i].szName);
			strName.append("(").append(g_pPGBlock->m_TransformerWindingArray[i].szVoltI).append("<->").append(g_pPGBlock->m_TransformerWindingArray[i].szVoltJ).append(")");
			pListBox->AddString(strName.c_str());
		}
	}
}
void CTripDevSelectDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	m_nDeviceType=pCombo->GetCurSel();

	RefreshDeviceList();
}

void CTripDevSelectDialog::OnCbnSelchangeDevsubCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CTripDevSelectDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pCombo;

	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	m_nDeviceType=pCombo->GetCurSel();
	if (m_nDeviceType < 0)
		return;

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_DEVICE_LIST);
	int			nDev=pListBox->GetCurSel();
	if (nDev == LB_ERR)
		return;

	pListBox->GetText(nDev, m_strDeviceName);

	OnOK();
}
