#pragma once


// CTripDevSelectDialog �Ի���

class CTripDevSelectDialog : public CDialog
{
	DECLARE_DYNAMIC(CTripDevSelectDialog)

public:
	CTripDevSelectDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CTripDevSelectDialog();

// �Ի�������
	enum { IDD = IDD_TRIPDEV_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeDevtypeCombo();
	afx_msg void OnCbnSelchangeDevsubCombo();
	afx_msg void OnBnClickedOk();

	DECLARE_MESSAGE_MAP()
private:
	void	RefreshDeviceList();
public:
	int		m_nDeviceType;
	CString	m_strDeviceName;
};
