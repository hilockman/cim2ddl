#include "StdAfx.h"
#include "PGUtility.h"

CPGUtility::CPGUtility(void)
{
}

CPGUtility::~CPGUtility(void)
{
}
