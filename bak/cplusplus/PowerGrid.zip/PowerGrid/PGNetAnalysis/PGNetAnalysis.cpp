//#include "StdAfx.h"
#include "PGNetAnalysis.h"

extern	void	Log(char* pformat, ...);
extern	char*	FormatVoltageLevelName(const char* lpszInVoltName);

CPGNetAnalysis::CPGNetAnalysis(void)
{
	m_fMinimalVoltage=200;
	m_bRingedLineArray.clear();
	m_bRingedTranArray.clear();
	m_bRingedBoundBusArray.clear();
}

CPGNetAnalysis::~CPGNetAnalysis(void)
{
}

void CPGNetAnalysis::Trim(char* lpszTrim)
{
	register int	i;
	char	szChar[MDB_CHARLEN_LONG];
	int		nChar;

	nChar=0;
	for (i=0; i<(int)strlen(lpszTrim); i++)
	{
		if (lpszTrim[i] != ' ' && lpszTrim[i] != '\t')
			szChar[nChar++]=lpszTrim[i];
	}
	szChar[nChar++]='\0';

	strcpy(lpszTrim, szChar);
}

int	CPGNetAnalysis::PGGetParallelLine(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nLine, std::vector<int>& nParallelLineArray)
{
	nParallelLineArray.clear();

	register int	i, j;
	int		nNodeINum, nNodeIArray[1000];
	int		nNodeJNum, nNodeJArray[1000];
	int		nNodeI=pBlock->m_ACLineSegmentArray[nLine].nNodeI;
	int		nNodeJ=pBlock->m_ACLineSegmentArray[nLine].nNodeJ;

	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;

	PGTraverseVolt(pBlock, nNodeI, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeINum, nNodeIArray);
	PGTraverseVolt(pBlock, nNodeJ, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeJNum, nNodeJArray);

	for (nNodeI=0; nNodeI<nNodeINum; nNodeI++)
	{
		for (i=pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]+1].nACLineSegmentRange; i++)
		{
			for (nNodeJ=0; nNodeJ<nNodeJNum; nNodeJ++)
			{
				for (j=pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]+1].nACLineSegmentRange; j++)
				{
					if (pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment == pBlock->m_EdgeACLineSegmentArray[j].nACLineSegment)
						nParallelLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment);
				}
			}
		}
	}

	return 0;
}

int	CPGNetAnalysis::PGGetParallel2WTran(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nTran, std::vector<int>& nParallelTranArray)
{
	nParallelTranArray.clear();

	register int	i, j;
	int		nNodeINum, nNodeIArray[1000];
	int		nNodeJNum, nNodeJArray[1000];
	int		nNodeI=pBlock->m_TransformerWindingArray[nTran].nNodeI;
	int		nNodeJ=pBlock->m_TransformerWindingArray[nTran].nNodeJ;

	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;

	PGTraverseVolt(pBlock, nNodeI, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeINum, nNodeIArray);
	PGTraverseVolt(pBlock, nNodeJ, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeJNum, nNodeJArray);

	for (nNodeI=0; nNodeI<nNodeINum; nNodeI++)
	{
		for (i=pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]].nTransformerWindingRange; i<pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]+1].nTransformerWindingRange; i++)
		{
			for (nNodeJ=0; nNodeJ<nNodeJNum; nNodeJ++)
			{
				for (j=pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]].nTransformerWindingRange; j<pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]+1].nTransformerWindingRange; j++)
				{
					if (pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding == pBlock->m_EdgeTransformerWindingArray[j].nTransformerWinding)
						nParallelTranArray.push_back(pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nTran);
				}
			}
		}
	}

	return 0;
}

int	CPGNetAnalysis::PGGetParallel3WTran(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nFrNode, const int nToNode, std::vector<int>& nParallelTranArray)
{
	nParallelTranArray.clear();

	register int	i, j;
	int		nNodeI, nNodeINum, nNodeIArray[1000];
	int		nNodeJ, nNodeJNum, nNodeJArray[1000];
	std::vector<unsigned char>	bTranProcArray;

	bTranProcArray.resize(pBlock->m_nRecordNum[PG_POWERTRANSFORMER], 0);

	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;

	PGTraverseVolt(pBlock, nFrNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeINum, nNodeIArray);
	PGTraverseVolt(pBlock, nToNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeJNum, nNodeJArray);

	for (nNodeI=0; nNodeI<nNodeINum; nNodeI++)
	{
		for (i=pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]].nTransformerWindingRange; i<pBlock->m_ConnectivityNodeArray[nNodeIArray[nNodeI]+1].nTransformerWindingRange; i++)
		{
			if (bTranProcArray[pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nTran])
				continue;

			for (nNodeJ=0; nNodeJ<nNodeJNum; nNodeJ++)
			{
				for (j=pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]].nTransformerWindingRange; j<pBlock->m_ConnectivityNodeArray[nNodeJArray[nNodeJ]+1].nTransformerWindingRange; j++)
				{
					if (bTranProcArray[pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[j].nTransformerWinding].nTran])
						continue;

					if (pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nTran == pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[j].nTransformerWinding].nTran)
						nParallelTranArray.push_back(pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nTran);
				}
			}
		}
	}

	return 0;
}

int CPGNetAnalysis::PGDecompose(tagPGBlock* pBlock, const float fMinVolt)
{
	register int	i, j;
	int		nSub, nVolt, nNode, nDev, nONode;
	int		nLoopIndex, nLoopDevNum, nMaxLoopDev, nMainLoop;
	unsigned char	bRinged, bSourced, bFlaged;
	int		nTran, nTranNum, nTranCoilArray[10], nTranNodeArray[10];
	std::vector<unsigned char>	bNodeProcArray;

	std::vector<int>			nParallelLineArray;

	int		nNodeNum;
	int*	nNodeArray;

	m_fMinimalVoltage=fMinVolt;
	m_bRingedLineArray.clear();
	m_bRingedTranArray.clear();
	m_bRingedBoundBusArray.clear();

	for (i=0; i<pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pBlock->m_SubstationArray[i].bHub=0;

	nNodeArray=(int*)malloc(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (nNodeArray == NULL)
		return -1;

	//	0����ʼ����Ϣ
	bNodeProcArray.resize(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE], 0);
	m_bRingedLineArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT], 0);
	m_bRingedTranArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING], 0);
	m_bRingedBoundBusArray.resize(pBlock->m_nRecordNum[PG_BUSBARSECTION], 0);

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage >= fMinVolt)
				continue;

			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (i=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; i++)
				{
					pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment].bOpen=1;
				}
			}
		}
	}

	//	1���ڸ�����ѹ�ȼ��������ϣ����������������ҵ�������ͨ�豸�õ������磨�豸������ͨ����)
	nMaxLoopDev=0;
	nLoopIndex=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fMinVolt)
				continue;

			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				if (bNodeProcArray[nNode])
					continue;

				PGTraverseNet(pBlock, nNode, N_CheckStatus, fMinVolt, nNodeNum, nNodeArray);

				nLoopDevNum=0;
				nLoopIndex++;
				for (i=0; i<nNodeNum; i++)
				{
					bNodeProcArray[nNodeArray[i]]=1;
					for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; nDev++)
					{
						if (m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment])
							continue;

						nONode=(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].nNodeI == nNodeArray[i]) ?
							pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].nNodeJ : pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].nNodeI;
						for (j=0; j<nNodeNum; j++)
						{
							if (nONode == nNodeArray[j])
							{
								m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment]=nLoopIndex;
								nLoopDevNum++;
							}
						}
					}
					for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nTransformerWindingRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nTransformerWindingRange; nDev++)
					{
						if (m_bRingedTranArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding])
							continue;

						PGGetTranCoil(pBlock, pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding, nTranNum, nTranCoilArray, nTranNodeArray);
						if (nTranNum == 1)
						{
							nONode=(pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding].nNodeI == nNodeArray[i]) ?
								pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding].nNodeI;
							if (IsNodeConnectingGenerator(pBlock, 0, 0, nONode))
							{
								m_bRingedTranArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding]=nLoopIndex;
								nLoopDevNum++;
							}
						}
						else
						{
							for (nTran=0; nTran<nTranNum; nTran++)
							{
								if (nTranNodeArray[nTran] == nNodeArray[i])
									continue;

								if (IsNodeConnectingGenerator(pBlock, 0, 0, nTranNodeArray[nTran]))
								{
									m_bRingedTranArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding]=nLoopIndex;
									m_bRingedTranArray[nTranCoilArray[nTran]]=nLoopIndex;
									nLoopDevNum++;
								}
								else
								{
									for (j=0; j<nNodeNum; j++)
									{
										if (nTranNodeArray[nTran] == nNodeArray[j])
										{
											m_bRingedTranArray[pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding]=nLoopIndex;
											m_bRingedTranArray[nTranCoilArray[nTran]]=nLoopIndex;
											nLoopDevNum++;
										}
									}
								}
							}
						}
					}
				}

				if (nMaxLoopDev < nLoopDevNum)
				{
					nMaxLoopDev=nLoopDevNum;
					nMainLoop=nLoopIndex;
				}
			}
		}
	}

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (m_bRingedLineArray[i] != nMainLoop)
			m_bRingedLineArray[i]=0;
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (m_bRingedTranArray[i] != nMainLoop)
			m_bRingedTranArray[i]=0;
	}

	//	2���ж���·�Ƿ�ɻ�
	//		2.1������˫����·��˫�����жϱ�׼ͨ����վ�жϣ�����������������
	//		2.2������·��������ڵ����ͨ�������ͨ��Ϊ������·������ͨ���жϵ�Դ
	//				������е�Դ������·�������е�ԴΪ������·���������д��ڵ�Դ��
	//	��ѹ�������ɻ��жϡ�
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < fMinVolt)
				continue;

			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
				{
					if (m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment] != nMainLoop)
						continue;

					PGGetParallelLine(pBlock, 0, 0, pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment, nParallelLineArray);
					for (i=0; i<(int)nParallelLineArray.size(); i++)
						pBlock->m_ACLineSegmentArray[nParallelLineArray[i]].bOpen=1;

					nONode=(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].nNodeI == nNode) ?
						pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].nNodeJ : pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].nNodeI;

					bRinged=0;
					PGTraverseNet(pBlock, nNode, N_CheckStatus, fMinVolt, nNodeNum, nNodeArray);
					for (i=0; i<nNodeNum; i++)
					{
						if (nNodeArray[i] == nONode)
						{
							bRinged=1;
							break;
						}
					}
					if (!bRinged)
					{
						//m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[nDev].iRln]=0;
						bSourced=0;
						for (i=0; i<nNodeNum; i++)
						{
							bFlaged=0;
							for (j=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nVoltageLevelPtr].nSynchronousMachineRange; j<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nVoltageLevelPtr+1].nSynchronousMachineRange; j++)
							{
								if (pBlock->m_SynchronousMachineArray[j].nNode == nNodeArray[i])
								{
									bSourced++;
									bFlaged=1;
									break;
								}
							}
							if (bFlaged)
								break;
						}

						PGTraverseNet(pBlock, nONode, N_CheckStatus, fMinVolt, nNodeNum, nNodeArray);
						for (i=0; i<nNodeNum; i++)
						{
							bFlaged=0;
							for (j=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nVoltageLevelPtr].nSynchronousMachineRange; j<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nVoltageLevelPtr+1].nSynchronousMachineRange; j++)
							{
								if (pBlock->m_SynchronousMachineArray[j].nNode == nNodeArray[i])
								{
									bSourced++;
									bFlaged=1;
									break;
								}
							}
							if (bFlaged)
								break;
						}
						if (bSourced < 2)
							m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment]=0;
					}

					for (i=0; i<(int)nParallelLineArray.size(); i++)
						pBlock->m_ACLineSegmentArray[nParallelLineArray[i]].bOpen=0;
				}
			}
		}
	}

	//	3���γɳɻ�ĸ��
	//		3.1�������зǻ�����·�ͷǻ�����ѹ��
	//		3.2�������ڻ����ڵ�ĸ����Ϊ����ĸ��
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (m_bRingedLineArray[i] != nMainLoop)
			pBlock->m_ACLineSegmentArray[i].bOpen=1;
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (m_bRingedTranArray[i] != nMainLoop)
			pBlock->m_TransformerWindingArray[i].bOpen=1;
	}
	nONode=-1;
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (m_bRingedLineArray[i] != nMainLoop)
			continue;

		nONode=pBlock->m_ACLineSegmentArray[i].nNodeI;
		break;
	}
	if (nONode >= 0)
	{
		PGTraverseNet(pBlock, nONode, N_CheckStatus, fMinVolt, nNodeNum, nNodeArray);
		for (i=0; i<nNodeNum; i++)
		{
			if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
				m_bRingedBoundBusArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=nMainLoop;
		}

		for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			pBlock->m_SubstationArray[nSub].bHub=0;
			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
				{
					if (m_bRingedBoundBusArray[nDev])
					{
						pBlock->m_SubstationArray[nSub].bHub=1;
						break;
					}
				}
				if (pBlock->m_SubstationArray[nSub].bHub)
					break;
			}
		}

		for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
			pBlock->m_ACLineSegmentArray[i].bOpen=0;
		for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
			pBlock->m_TransformerWindingArray[i].bOpen=0;
		for (i=0; i<pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
			pBlock->m_ConnectivityNodeArray[i].bOpen=0;

		//	�������ڵ�ĸ�ߴӱ߽�ĸ����ɾ��
		for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
				{
					if (!m_bRingedBoundBusArray[nDev])
						continue;
					if (pBlock->m_BusbarSectionArray[nDev].nNode < 0)
						continue;

					bRinged=1;
					PGTraverseVolt(pBlock, pBlock->m_BusbarSectionArray[nDev].nNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
					for (nNode=0; nNode<nNodeNum; nNode++)
					{
						if (bRinged)
						{
							for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
							{
								if (!m_bRingedLineArray[pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment])
								{
									bRinged=0;
									break;
								}
							}
						}
						if (bRinged)
						{
							for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; i++)
							{
								if (!m_bRingedTranArray[pBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding])
								{
									bRinged=0;
									break;
								}
							}
						}
					}
					if (bRinged)
						m_bRingedBoundBusArray[nDev]=0;
				}
			}
		}
	}
	free(nNodeArray);

	return nMainLoop;
}

void CPGNetAnalysis::PrevTraverseRadiant(tagPGBlock* pBlock)
{
	register int	i;
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (m_bRingedLineArray[i])
			pBlock->m_ACLineSegmentArray[i].bOpen=1;
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (m_bRingedTranArray[i])
			pBlock->m_TransformerWindingArray[i].bOpen=1;
	}
}

void CPGNetAnalysis::PostTraverseRadiant(tagPGBlock* pBlock)
{
	register int	i;
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pBlock->m_ACLineSegmentArray[i].bOpen=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		pBlock->m_TransformerWindingArray[i].bOpen=0;
}


int CPGNetAnalysis::TraverseRadiant(tagPGBlock* pBlock, const int nCheckStatus)
{
	register int	i;
	int	nSub, nVolt, nBus, nNode, nDev;
	unsigned char	bExist;
	tagPGRadiant	rBuf;

	std::vector<unsigned char>	bBusProcArray;
	int		nNodeNum;
	int*	nNodeArray=(int*)malloc(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!nNodeArray)
		return 0;

	PrevTraverseRadiant(pBlock);

	bBusProcArray.resize(pBlock->m_nRecordNum[PG_BUSBARSECTION], 0);

	m_RadiantArray.clear();
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < m_fMinimalVoltage)
				continue;

			for (nBus=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nBus<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nBus++)
			{
				if (!m_bRingedBoundBusArray[nBus])
					continue;
				if (bBusProcArray[nBus])
					continue;
				bBusProcArray[nBus]=1;

				if (pBlock->m_BusbarSectionArray[nBus].nNode <= 0)
					continue;

				rBuf.nSourceBusArray.clear();
				rBuf.nRadiantLineArray.clear();
				rBuf.nRadiantTranArray.clear();
				rBuf.nLoadBusArray.clear();
				if (nCheckStatus)
					PGTraverseNet(pBlock, pBlock->m_BusbarSectionArray[nBus].nNode, Y_CheckStatus, 0, nNodeNum, nNodeArray);
				else
					PGTraverseNet(pBlock, pBlock->m_BusbarSectionArray[nBus].nNode, N_CheckStatus, 0, nNodeNum, nNodeArray);

				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					if (pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr >= 0)
					{
						bBusProcArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr]=1;
						if (m_bRingedBoundBusArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr])
							rBuf.nSourceBusArray.push_back(pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr);
						else
							rBuf.nLoadBusArray.push_back(pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr);
					}
					for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; nDev++)
					{
						bExist=0;
						for (i=0; i<(int)rBuf.nRadiantLineArray.size(); i++)
						{
							if (rBuf.nRadiantLineArray[i] == pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment)
							{
								bExist=1;
								break;
							}
						}
						if (!bExist)
							rBuf.nRadiantLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment);
					}
					for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; nDev++)
					{
						bExist=0;
						for (i=0; i<(int)rBuf.nRadiantTranArray.size(); i++)
						{
							if (rBuf.nRadiantTranArray[i] == pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding)
							{
								bExist=1;
								break;
							}
						}
						if (!bExist)
							rBuf.nRadiantTranArray.push_back(pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding);
					}
				}
				m_RadiantArray.push_back(rBuf);
			}
		}
	}

	free(nNodeArray);

	PostTraverseRadiant(pBlock);
	return 1;
}

int CPGNetAnalysis::TraceSource(tagPGBlock* pBlock, const int bCheckBreakerOpen, const int bCheckDisconnectorOpen, const int nStartNode)
{
	register int	i;
	int		nDeep;

	m_TraceBranArray.clear();

	m_bNodeProcArray.resize(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	m_bLineProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	m_bTranProcArray.resize(pBlock->m_nRecordNum[PG_POWERTRANSFORMER]);

	for (i=0; i<pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_bNodeProcArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		m_bLineProcArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_POWERTRANSFORMER]; i++)
		m_bTranProcArray[i]=0;

	nDeep=0;
	TraceJoint(pBlock, bCheckBreakerOpen, bCheckDisconnectorOpen, nStartNode, nDeep);

 	i=0;
 	while (i < (int)m_TraceBranArray.size())
 	{
 		if (!m_TraceBranArray[i].bMarked)
 		{
 			m_TraceBranArray.erase(m_TraceBranArray.begin()+i);
 		}
 		else
 			i++;
 	}

	for (i=0; i<(int)m_TraceBranArray.size(); i++)
	{
		if (IsHubStationNode(pBlock, m_TraceBranArray[i].nToNode))
		{
			AddHubTran(pBlock, bCheckBreakerOpen, bCheckDisconnectorOpen, m_TraceBranArray[i].nToNode, m_TraceBranArray[i].nHubTranArray);
		}
	}
	return 0;
}

int	CPGNetAnalysis::IsNodeConnectingGenerator(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nJudgeNode)
{
	register int	i;
	int		nNode, nNodeNum, nNodeArray[1000];
	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;
	PGTraverseVolt(pBlock, nJudgeNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
		{
			if (pBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
				return 1;
		}
	}

	return 0;
}

int	CPGNetAnalysis::IsHubStationNode(tagPGBlock* pBlock, const int nJudgeNode)
{
	int	nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nJudgeNode].szSub);
	if (nSub >= 0)
	{
		return pBlock->m_SubstationArray[nSub].bHub;
	}
	return 0;
}

void CPGNetAnalysis::AddHubTran(tagPGBlock* pPGBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nHubNode, std::vector<int>& nHubTranArray)
{
	register int	i, j;
	int		nVoltI, nVoltZ;
	int		nTran, nNode, nNodeNum, nNodeArray[1000];
	unsigned char	bExist, bCanAdded;
	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;

	nHubTranArray.clear();
	PGTraverseVolt(pPGBlock, nHubNode, bCheckBreaker, bCheckDisconnector, N_CheckStatus, N_BreakerBound, nNodeNum, nNodeArray);
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; i++)
		{
			bCanAdded=0;

			nTran=pPGBlock->m_TransformerWindingArray[pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nTran;
			if (pPGBlock->m_PowerTransformerArray[nTran].nWindNum == 1)
			{
				nVoltI=pPGBlock->m_TransformerWindingArray[pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nVoltI;
				nVoltZ=pPGBlock->m_TransformerWindingArray[pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nVoltJ;
				if (nNodeArray[nNode] == pPGBlock->m_TransformerWindingArray[pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding].nNodeI)
				{
					if (pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage > pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage)
					{
						bCanAdded=1;
					}
				}
				else
					if (pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage)
					{
						bCanAdded=1;
					}
			}
			else
			{
				if (pPGBlock->m_PowerTransformerArray[nTran].nWindH != pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding)
				{
					bCanAdded=1;
				}
			}
			if (bCanAdded)
			{
				bExist=0;
				for (j=0; j<(int)nHubTranArray.size(); j++)
				{
					if (nHubTranArray[j] == nTran)
					{
						bExist=1;
						break;
					}
				}
				if (!bExist)
					nHubTranArray.push_back(nTran);
			}
		}
	}
}

void CPGNetAnalysis::SetRecursivePower(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus)
{
	register int	i, j;
	int		bFrLinked, bToLinked, nPrevDeep, nPrevBran;
	std::vector<int>	nPrevFrNodeArray;
	int		nFrNodeNum, nFrNodeArray[1000];
	int		nToNodeNum, nToNodeArray[1000];

	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;

	//bCheckBreaker=N_CheckStatus;
	//bCheckDisconnector=N_CheckStatus;

	Log("    SetRecursivePower(TraceLineNum=%d)\n", m_TraceBranArray.size());
	nPrevFrNodeArray.clear();
	nPrevDeep=m_TraceBranArray[m_TraceBranArray.size()-1].nDeep;
	nPrevBran=(int)m_TraceBranArray.size()-1;
	PGTraverseVolt(pBlock, m_TraceBranArray[nPrevBran].nFrNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nFrNodeNum, nFrNodeArray);
	PGTraverseVolt(pBlock, m_TraceBranArray[nPrevBran].nToNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);

	for (i=(int)m_TraceBranArray.size()-1; i>=0; i--)
	{
		if (m_TraceBranArray[i].bMarked)
			break;

		if (m_TraceBranArray[i].nBranType == PG_ACLINESEGMENT)
		{
			Log("CheckTraceLine[%d] FrNode=%s.%s %s.%s\n", i, pBlock->m_ACLineSegmentArray[m_TraceBranArray[i].nBranIndex].szName, 
				pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nFrNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nFrNode].szName, 
				pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
		}
		else
		{
			Log("CheckTraceTran[%d] FrNode=%s.%s %s.%s\n", i, pBlock->m_PowerTransformerArray[m_TraceBranArray[i].nBranIndex].szName, 
				pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nFrNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nFrNode].szName, 
				pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
		}

		if (m_TraceBranArray[i].nDeep == nPrevDeep)
		{
			bFrLinked=bToLinked=0;
			for (j=0; j<nFrNodeNum; j++)
			{
				if (m_TraceBranArray[i].nFrNode == nFrNodeArray[j])
				{
					bFrLinked=1;
					break;
				}
			}
			for (j=0; j<nToNodeNum; j++)
			{
				if (m_TraceBranArray[i].nToNode == nToNodeArray[j])
				{
					bToLinked=1;
					break;
				}
			}
			if (bFrLinked && bToLinked)
			{
				m_TraceBranArray[i].bMarked=1;
				Log("            Pal (Bran=%s FrNode=%s.%sToNode=%s.%s)\n", pBlock->m_ACLineSegmentArray[m_TraceBranArray[i].nBranIndex].szName, 
					pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nFrNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nFrNode].szName, 
					pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
			}
		}
		else if (m_TraceBranArray[i].nDeep == nPrevDeep-1)
		{
			PGTraverseVolt(pBlock, m_TraceBranArray[nPrevBran].nFrNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nFrNodeNum, nFrNodeArray);
			bToLinked=0;
			for (j=0; j<nFrNodeNum; j++)
			{
				if (m_TraceBranArray[i].nToNode == nFrNodeArray[j])
				{
					bToLinked=1;
					break;
				}
			}

			for (j=0; j<(int)nPrevFrNodeArray.size(); j++)
			{
				Log("                    PrevFrNode[%d]=%s.%s\n", j, pBlock->m_ConnectivityNodeArray[nPrevFrNodeArray[j]].szSub, pBlock->m_ConnectivityNodeArray[nPrevFrNodeArray[j]].szName);
			}
			if (bToLinked)
			{
				m_TraceBranArray[i].bMarked=1;

				nPrevDeep--;
				nPrevBran=i;
				PGTraverseVolt(pBlock, m_TraceBranArray[nPrevBran].nFrNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nFrNodeNum, nFrNodeArray);
				PGTraverseVolt(pBlock, m_TraceBranArray[nPrevBran].nToNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nToNodeNum, nToNodeArray);
				if (m_TraceBranArray[i].nBranType == PG_ACLINESEGMENT)
					Log("            Linked(Bran=%s ToNode=%s.%s)\n", pBlock->m_ACLineSegmentArray[m_TraceBranArray[i].nBranIndex].szName, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
				else
					Log("            Linked(Bran=%s ToNode=%s.%s)\n", pBlock->m_PowerTransformerArray[m_TraceBranArray[i].nBranIndex].szName, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
			}
			else
			{
				if (m_TraceBranArray[i].nBranType == PG_ACLINESEGMENT)
					Log("            NoLink(Bran=%s ToNode=%s.%s)\n", pBlock->m_ACLineSegmentArray[m_TraceBranArray[i].nBranIndex].szName, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
				else
					Log("            NoLink(Bran=%s ToNode=%s.%s)\n", pBlock->m_PowerTransformerArray[m_TraceBranArray[i].nBranIndex].szName, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szSub, pBlock->m_ConnectivityNodeArray[m_TraceBranArray[i].nToNode].szName);
			}
		}
	}
}


void CPGNetAnalysis::TraceJoint(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nIniNode, int nDeep)
{
	register int	i, j;
	int		nNode, nOppNode, nDev, nBran;
	int		nVoltI, nVoltJ;
	int		nNodeNum, nNodeArray[1000];
	int		nOppNodeNum, nOppNodeArray[1000];
	int		nBusNodeNum, nBusNodeArray[1000];
	int		nTranMidNode;
	tagPGRecursiveChain	dChain;
	std::vector<int>	nParallelBranArray;

	unsigned char	bCheckBreaker=(bCheckBreakerStatus) ? Y_CheckStatus : N_CheckStatus;
	unsigned char	bCheckDisconnector=(bCheckDisconnectorStatus) ? Y_CheckStatus : N_CheckStatus;

	if (m_bNodeProcArray[nIniNode])
		return;

	m_bNodeProcArray[nIniNode]=1;

	//Log("TraceJoint(Deep=%d): IniNode=%s.%s.%s\n", nDeep, pBlock->m_ConnectivityNodeArray[nIniNode].szSub, pBlock->m_ConnectivityNodeArray[nIniNode].szVolt, pBlock->m_ConnectivityNodeArray[nIniNode].szName);
	if (IsHubStationNode(pBlock, nIniNode) && nDeep > 0)
	{
		//Log("        IsHubStationNode\n");
		SetRecursivePower(pBlock, 0, 0);
		return;
	}

	nVoltI=pBlock->m_ConnectivityNodeArray[nIniNode].nVoltageLevelPtr;
	PGTraverseVolt(pBlock, nIniNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);

	for (i=0; i<nNodeNum; i++)
	{
		//Log("        JointNode=%s.%s.%s\n", pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szSub, pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szVolt, pBlock->m_ConnectivityNodeArray[nNodeArray[i]].szName);
		m_bNodeProcArray[nNodeArray[i]]=1;
	}

	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBreakerRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nBreakerRange; i++)
			Log("    Breaker[%s %s %s] %d\n", pBlock->m_BreakerArray[pBlock->m_EdgeBreakerArray[i].nBreaker].szSub, pBlock->m_BreakerArray[pBlock->m_EdgeBreakerArray[i].nBreaker].szVolt, pBlock->m_BreakerArray[pBlock->m_EdgeBreakerArray[i].nBreaker].szName, pBlock->m_BreakerArray[pBlock->m_EdgeBreakerArray[i].nBreaker].nStatus);
	}

	//	�����Ӻ���
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; nDev++)
		{
			nBran=pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment;
			if (m_bLineProcArray[nBran])
				continue;

			nOppNode=(nNodeArray[nNode] == pBlock->m_ACLineSegmentArray[nBran].nNodeI) ? pBlock->m_ACLineSegmentArray[nBran].nNodeJ : pBlock->m_ACLineSegmentArray[nBran].nNodeI;
			if (m_bNodeProcArray[nOppNode])
				continue;

			PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
			PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);

			dChain.bMarked=dChain.bTraced=0;
			dChain.nToBusArray.clear();
			dChain.nDeep=nDeep;
			dChain.nBranType=PG_ACLINESEGMENT;
			dChain.nFrNode=nIniNode;
			dChain.nToNode=nOppNode;
			dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
			dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);

			for (j=0; j<nBusNodeNum; j++)
			{
				if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
					dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
			}

			PGGetParallelLine(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nBran, nParallelBranArray);
			for (i=0; i<(int)nParallelBranArray.size(); i++)
			{
				dChain.nBranIndex=nParallelBranArray[i];
				m_TraceBranArray.push_back(dChain);
				m_bLineProcArray[nParallelBranArray[i]]=1;
			}
			Log("    JointLine=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_ACLineSegmentArray[dChain.nBranIndex].szName, 
				pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
				pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
			TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
		}

		for (nDev=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; nDev<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; nDev++)
		{
			nBran=pBlock->m_EdgeTransformerWindingArray[nDev].nTransformerWinding;
			if (pBlock->m_TransformerWindingArray[nBran].nTran < 0)
				continue;

			if (m_bTranProcArray[pBlock->m_TransformerWindingArray[nBran].nTran])
				continue;

			if (pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindNum == 1)
			{
				nOppNode=(nNodeArray[nNode] == pBlock->m_TransformerWindingArray[nBran].nNodeI) ? pBlock->m_TransformerWindingArray[nBran].nNodeJ : pBlock->m_TransformerWindingArray[nBran].nNodeI;
				if (nOppNode < 0)
					continue;
				if (m_bNodeProcArray[nOppNode] != 0)
					continue;

				nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
				if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
				{
					dChain.bMarked=dChain.bTraced=0;
					dChain.nToBusArray.clear();
					dChain.nDeep=nDeep;
					dChain.nBranType=PG_POWERTRANSFORMER;
					dChain.nFrNode=nIniNode;
					dChain.nToNode=nOppNode;
					dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
					dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
					PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
					PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
					for (j=0; j<nBusNodeNum; j++)
					{
						if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
							dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
					}
					PGGetParallel2WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nBran, nParallelBranArray);
					for (i=0; i<(int)nParallelBranArray.size(); i++)
					{
						dChain.nBranIndex=nParallelBranArray[i];
						m_TraceBranArray.push_back(dChain);
						m_bTranProcArray[nParallelBranArray[i]]=1;
					}
					Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
						pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
						pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
					TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
				}
			}
			else
			{
				nTranMidNode=-1;
				if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeI ||
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeJ)
					nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI;
				else
					nTranMidNode=pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeJ;

				if (nBran == pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH)
				{
					nOppNode=(nTranMidNode == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM].nNodeI) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM].nNodeI;
					if (!m_bNodeProcArray[nOppNode])
					{
						nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
						if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
						{
							dChain.bMarked=dChain.bTraced=0;
							dChain.nToBusArray.clear();
							dChain.nDeep=nDeep;
							dChain.nBranType=PG_POWERTRANSFORMER;
							dChain.nFrNode=nIniNode;
							dChain.nToNode=nOppNode;
							dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
							dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
							for (j=0; j<nBusNodeNum; j++)
							{
								if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
									dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
							}
							PGGetParallel3WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nIniNode, nOppNode, nParallelBranArray);
							for (i=0; i<(int)nParallelBranArray.size(); i++)
							{
								dChain.nBranIndex=nParallelBranArray[i];
								m_TraceBranArray.push_back(dChain);
								m_bTranProcArray[nParallelBranArray[i]]=1;
							}
							Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
							TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
						}
					}

					nOppNode=(nTranMidNode == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeI) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeI;
					if (!m_bNodeProcArray[nOppNode])
					{
						nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
						if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
						{
							dChain.bMarked=dChain.bTraced=0;
							dChain.nToBusArray.clear();
							dChain.nDeep=nDeep;
							dChain.nBranType=PG_POWERTRANSFORMER;
							dChain.nFrNode=nIniNode;
							dChain.nToNode=nOppNode;
							dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
							dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
							for (j=0; j<nBusNodeNum; j++)
							{
								if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
									dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
							}
							PGGetParallel3WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nIniNode, nOppNode, nParallelBranArray);
							for (i=0; i<(int)nParallelBranArray.size(); i++)
							{
								dChain.nBranIndex=nParallelBranArray[i];
								m_TraceBranArray.push_back(dChain);
								m_bTranProcArray[nParallelBranArray[i]]=1;
							}
							Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
							TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
						}
					}
				}
				if (nBran == pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM)
				{
					nOppNode=(nTranMidNode == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI;
					if (!m_bNodeProcArray[nOppNode])
					{
						nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
						if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
						{
							dChain.bMarked=dChain.bTraced=0;
							dChain.nToBusArray.clear();
							dChain.nDeep=nDeep;
							dChain.nBranType=PG_POWERTRANSFORMER;
							dChain.nFrNode=nIniNode;
							dChain.nToNode=nOppNode;
							dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
							dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
							for (j=0; j<nBusNodeNum; j++)
							{
								if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
									dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
							}
							PGGetParallel3WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nIniNode, nOppNode, nParallelBranArray);
							for (i=0; i<(int)nParallelBranArray.size(); i++)
							{
								dChain.nBranIndex=nParallelBranArray[i];
								m_TraceBranArray.push_back(dChain);
								m_bTranProcArray[nParallelBranArray[i]]=1;
							}
							Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
							TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
						}
					}

					nOppNode=(nTranMidNode == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeI) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL].nNodeI;
					if (!m_bNodeProcArray[nOppNode])
					{
						nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
						if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
						{
							dChain.bMarked=dChain.bTraced=0;
							dChain.nToBusArray.clear();
							dChain.nDeep=nDeep;
							dChain.nBranType=PG_POWERTRANSFORMER;
							dChain.nFrNode=nIniNode;
							dChain.nToNode=nOppNode;
							dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
							dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
							for (j=0; j<nBusNodeNum; j++)
							{
								if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
									dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
							}
							PGGetParallel3WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nIniNode, nOppNode, nParallelBranArray);
							for (i=0; i<(int)nParallelBranArray.size(); i++)
							{
								dChain.nBranIndex=nParallelBranArray[i];
								m_TraceBranArray.push_back(dChain);
								m_bTranProcArray[nParallelBranArray[i]]=1;
							}
							Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
							TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
						}
					}
				}

				if (nBran == pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindL)
				{
					nOppNode=(nTranMidNode == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindH].nNodeI;
					if (!m_bNodeProcArray[nOppNode])
					{
						nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
						if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
						{
							dChain.bMarked=dChain.bTraced=0;
							dChain.nToBusArray.clear();
							dChain.nDeep=nDeep;
							dChain.nBranType=PG_POWERTRANSFORMER;
							dChain.nFrNode=nIniNode;
							dChain.nToNode=nOppNode;
							dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
							dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
							for (j=0; j<nBusNodeNum; j++)
							{
								if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
									dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
							}
							PGGetParallel3WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nIniNode, nOppNode, nParallelBranArray);
							for (i=0; i<(int)nParallelBranArray.size(); i++)
							{
								dChain.nBranIndex=nParallelBranArray[i];
								m_TraceBranArray.push_back(dChain);
								m_bTranProcArray[nParallelBranArray[i]]=1;
							}
							Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
							TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
						}
					}

					nOppNode=(nTranMidNode == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM].nNodeI) ?
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM].nNodeJ : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nBran].nTran].nWindM].nNodeI;
					if (!m_bNodeProcArray[nOppNode])
					{
						nVoltJ=pBlock->m_ConnectivityNodeArray[nOppNode].nVoltageLevelPtr;
						if (pBlock->m_VoltageLevelArray[nVoltI].nominalVoltage < pBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage)
						{
							dChain.bMarked=dChain.bTraced=0;
							dChain.nToBusArray.clear();
							dChain.nDeep=nDeep;
							dChain.nBranType=PG_POWERTRANSFORMER;
							dChain.nFrNode=nIniNode;
							dChain.nToNode=nOppNode;
							dChain.nFrSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nIniNode].szSub);
							dChain.nToSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ConnectivityNodeArray[nOppNode].szSub);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, N_BusBound, N_BreakerBound, nOppNodeNum, nOppNodeArray);
							PGTraverseVolt(pBlock, nOppNode, bCheckBreaker, bCheckDisconnector, Y_BusBound, N_BreakerBound, nBusNodeNum, nBusNodeArray);
							for (j=0; j<nBusNodeNum; j++)
							{
								if (pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr >= 0)
									dChain.nToBusArray.push_back(pBlock->m_ConnectivityNodeArray[nBusNodeArray[j]].nBusbarSectionPtr);
							}
							PGGetParallel3WTran(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nIniNode, nOppNode, nParallelBranArray);
							for (i=0; i<(int)nParallelBranArray.size(); i++)
							{
								dChain.nBranIndex=nParallelBranArray[i];
								m_TraceBranArray.push_back(dChain);
								m_bTranProcArray[nParallelBranArray[i]]=1;
							}
							Log("    JointTran=%s FrNode=%s.%s.%s ToNode=%s.%s.%s\n", pBlock->m_PowerTransformerArray[dChain.nBranIndex].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nFrNode].szName, 
								pBlock->m_ConnectivityNodeArray[dChain.nToNode].szSub, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szVolt, pBlock->m_ConnectivityNodeArray[dChain.nToNode].szName);
							TraceJoint(pBlock, bCheckBreakerStatus, bCheckDisconnectorStatus, nOppNode, nDeep+1);
						}
					}
				}
			}
		}
	}
}
//	��TraceJoint��·���Ƚ������ҵ�������·����˫���ߴ���ʮ�ָ��ӣ������в�������˫���ߣ�ͬʱ�ж�˫���ߵļ���������

void	CPGNetAnalysis::FormSameBreakerLine(tagPGBlock* pBlock)
{
	register int	i;
	int		nNode, nBreaker;
	tagPGSameBreakerLine	dBuf;
	int		nILineNum, nINodeNum, nINodeArray[1000];
	int		nZLineNum, nZNodeNum, nZNodeArray[1000];
	m_SameBreakerLineArray.clear();

	std::vector<unsigned char>	bBreakerOpenArray;
	std::vector<unsigned char>	bDisconnectorOpenArray;
	bBreakerOpenArray.resize(pBlock->m_nRecordNum[PG_BREAKER]);
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
	{
		bBreakerOpenArray[i]=pBlock->m_BreakerArray[i].nStatus;
		pBlock->m_BreakerArray[i].nStatus=0;
	}
	bDisconnectorOpenArray.resize(pBlock->m_nRecordNum[PG_DISCONNECTOR]);
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
	{
		bDisconnectorOpenArray[i]=pBlock->m_DisconnectorArray[i].nStatus;
		pBlock->m_DisconnectorArray[i].nStatus=0;
	}

	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (pBlock->m_BusbarSectionArray[i].bBypass == 0)
			continue;

		nNode=pBlock->m_BusbarSectionArray[i].nNode;
		if (nNode < 0)
			continue;

		for (nBreaker=pBlock->m_ConnectivityNodeArray[nNode].nDisconnectorRange; nBreaker<pBlock->m_ConnectivityNodeArray[nNode+1].nDisconnectorRange; nBreaker++)
			pBlock->m_DisconnectorArray[pBlock->m_EdgeDisconnectorArray[nBreaker].nDisconnector].nStatus=1;
		for (nBreaker=pBlock->m_ConnectivityNodeArray[nNode].nBreakerRange; nBreaker<pBlock->m_ConnectivityNodeArray[nNode+1].nBreakerRange; nBreaker++)
			pBlock->m_BreakerArray[pBlock->m_EdgeBreakerArray[nBreaker].nBreaker].nStatus=1;
	}
	for (nBreaker=0; nBreaker<pBlock->m_nRecordNum[PG_BREAKER]; nBreaker++)
	{
		dBuf.nBreaker=nBreaker;
		dBuf.nLineArray.clear();
		PGTraverseVolt(pBlock, pBlock->m_BreakerArray[nBreaker].nNodeI, Y_CheckStatus, Y_CheckStatus, Y_BusBound, Y_BreakerBound, nINodeNum, nINodeArray);
		PGTraverseVolt(pBlock, pBlock->m_BreakerArray[nBreaker].nNodeJ, Y_CheckStatus, Y_CheckStatus, Y_BusBound, Y_BreakerBound, nZNodeNum, nZNodeArray);

		nILineNum=0;
		for (nNode=0; nNode<nINodeNum; nNode++)
		{
			for (i=pBlock->m_ConnectivityNodeArray[nINodeArray[nNode]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nINodeArray[nNode]+1].nACLineSegmentRange; i++)
			{
				dBuf.nLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment);
				nILineNum++;
			}
		}

		nZLineNum=0;
		for (nNode=0; nNode<nZNodeNum; nNode++)
		{
			for (i=pBlock->m_ConnectivityNodeArray[nZNodeArray[nNode]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nZNodeArray[nNode]+1].nACLineSegmentRange; i++)
			{
				dBuf.nLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment);
				nZLineNum++;
			}
		}

		if (nILineNum <= 0 && nZLineNum > 1 || nILineNum > 1 && nZLineNum <= 0)
		{
			m_SameBreakerLineArray.push_back(dBuf);
		}
	}

	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
		pBlock->m_BreakerArray[i].nStatus=bBreakerOpenArray[i];
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
		pBlock->m_DisconnectorArray[i].nStatus=bDisconnectorOpenArray[i];
}

void CPGNetAnalysis::GetAllTLine(tagPGBlock* pBlock, const int nTLine, std::vector<int>& nTLineArray)
{
	register int	i, j;
	int	nLine, nDev, nMidL, nMidH;
	unsigned char	bIIsT, bZIsT;
	int	nNodeNum, nNodeArray[1000];

	std::vector<unsigned char>	bLineProcArray;
	bLineProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	nTLineArray.clear();

	nTLineArray.push_back(nTLine);
	bLineProcArray[nTLine]=1;

	nMidL=0;
	nMidH=(int)nTLineArray.size();
	while (1)
	{
		for (nLine=nMidL; nLine<nMidH; nLine++)
		{
			if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeI))
			{
				PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeI, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				for (i=0; i<nNodeNum; i++)
				{
					for (j=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; j++)
					{
						nDev=pBlock->m_EdgeACLineSegmentArray[j].nACLineSegment;
						bIIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI);
						bZIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ);
						//TRACE("TLine=%s %d %d %d\n", pBlock->m_ACLineSegmentArray[nDev].szName, bLineProcArray[nDev], bIIsT, bZIsT);
						if (!bLineProcArray[nDev] && (bIIsT || bZIsT))
						{
							nTLineArray.push_back(nDev);
							bLineProcArray[nDev]=1;
						}
					}
				}
			}
			if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeJ))
			{
				PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].nNodeJ, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				for (i=0; i<nNodeNum; i++)
				{
					for (j=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; j++)
					{
						nDev=pBlock->m_EdgeACLineSegmentArray[j].nACLineSegment;
						bIIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI);
						bZIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ);
						//TRACE("TLine=%s %d %d %d\n", pBlock->m_ACLineSegmentArray[nDev].szName, bLineProcArray[nDev], bIIsT, bZIsT);
						if (!bLineProcArray[nDev] && (bIIsT || bZIsT))
						{
							nTLineArray.push_back(nDev);
							bLineProcArray[nDev]=1;
						}
					}
				}
			}
		}
		if (nMidH == nTLineArray.size())
			break;
		nMidL=nMidH;
		nMidH=(int)nTLineArray.size();
	}

// 	nLine=0;
// 	while (nLine < (int)nTLineArray.size())
// 	{
// 		bIIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].iRnd);
// 		bZIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[nLine]].zRnd);
// 		if (bIIsT && bZIsT)
// 		{
// 			nTLineArray.erase(nTLineArray.begin()+nLine);
// 		}
// 		else
// 		{
// 			nLine++;
// 		}
// 	}
// 	for (i=0; i<(int)nTLineArray.size(); i++)
// 	{
// 		bIIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[i]].iRnd);
// 		bZIsT=PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nTLineArray[i]].zRnd);
// 
// 		if (!bIIsT)
// 			nNonTNodeArray.push_back(pBlock->m_ACLineSegmentArray[nTLineArray[i]].iRnd);
// 		else if (!bZIsT)
// 			nNonTNodeArray.push_back(pBlock->m_ACLineSegmentArray[nTLineArray[i]].zRnd);
// 	}
}


void	CPGNetAnalysis::FormTLine(tagPGBlock* pBlock)
{
	register int	i;
	int			nLine;
	tagPGTLine	lBuf;
	std::vector<unsigned char>	bLineProcArray;
	std::vector<int>			nTLineArray;

	bLineProcArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	m_TLineArray.clear();
	for (nLine=0; nLine<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		if (bLineProcArray[nLine])
			continue;
		bLineProcArray[nLine]=1;

		if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nLine].nNodeI) || PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[nLine].nNodeJ))
		{
			GetAllTLine(pBlock, nLine, nTLineArray);
			for (i=0; i<(int)nTLineArray.size(); i++)
				bLineProcArray[nTLineArray[i]]=1;

			lBuf.nLineArray.clear();
			for (i=0; i<(int)nTLineArray.size(); i++)
			{
				lBuf.nLineArray.push_back(nTLineArray[i]);
			}
			m_TLineArray.push_back(lBuf);
		}
	}
}


void	CPGNetAnalysis::FormPsedoTLine(tagPGBlock* pBlock)
{
	register int	i, j, k;
	int			nLine, nSub, nVolt, nNode;
	int			nFind;
	unsigned char	bFlag;
	tagPGTLine	lBuf;
	int			nNodeNum, nNodeArray[1000];
	std::vector<unsigned char>	bLineProcArray;
	std::vector<int>			nTLineArray;

	std::vector<unsigned char>	bBreakerStatusArray;
	std::vector<unsigned char>	bDisconnectorStatusArray;

	bLineProcArray.resize(pBlock->m_nRecordNum[PG_EDGEACLINESEGMENT]);
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	bBreakerStatusArray.resize(pBlock->m_nRecordNum[PG_BREAKER]);
	bDisconnectorStatusArray.resize(pBlock->m_nRecordNum[PG_DISCONNECTOR]);

	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
	{
		bBreakerStatusArray[i]=pBlock->m_BreakerArray[i].nStatus;
		pBlock->m_BreakerArray[i].nStatus=0;
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
	{
		bDisconnectorStatusArray[i]=pBlock->m_DisconnectorArray[i].nStatus;
		pBlock->m_DisconnectorArray[i].nStatus=0;
	}

	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (pBlock->m_BusbarSectionArray[i].bBypass == 0)
			continue;

		for (j=pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[i].nNode].nDisconnectorRange; j<pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[i].nNode+1].nDisconnectorRange; j++)
			pBlock->m_DisconnectorArray[pBlock->m_EdgeDisconnectorArray[j].nDisconnector].nStatus=1;
	}

	m_PsedoTLineArray.clear();
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		//if (strcmp(pBlock->m_SubstationArray[nSub].szName, "ֱ��.��ֱ��") == 0)
		//	i=0;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nLine=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nLine<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nLine++)
				{
					if (bLineProcArray[nLine])
						continue;
					bLineProcArray[nLine]=1;

					if (!PGIsTConnection(pBlock, nNode))
					{
						lBuf.nLineArray.clear();
						PGTraverseVolt(pBlock, nNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
						for (i=0; i<nNodeNum; i++)
						{
							//if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].iRBus > 0)
							//	continue;
							for (j=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nACLineSegmentRange; j<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nACLineSegmentRange; j++)
							{
								lBuf.nLineArray.push_back(j);
							}
						}
						if (lBuf.nLineArray.size() > 1)
						{
							nFind=-1;
							for (i=0; i<(int)lBuf.nLineArray.size(); i++)
							{
								bLineProcArray[lBuf.nLineArray[i]]=1;

								for (j=0; j<(int)m_PsedoTLineArray.size(); j++)
								{
									for (k=0; k<(int)m_PsedoTLineArray[j].nLineArray.size(); k++)
									{
										if (strcmp(pBlock->m_EdgeACLineSegmentArray[m_PsedoTLineArray[j].nLineArray[k]].szName, pBlock->m_EdgeACLineSegmentArray[lBuf.nLineArray[i]].szName) == 0)
										{
											nFind=j;
											goto _OUT_;
										}
									}
								}
							}
_OUT_:	;
							if (nFind < 0)
							{
								m_PsedoTLineArray.push_back(lBuf);
							}
							else
							{
								for (i=0; i<(int)lBuf.nLineArray.size(); i++)
								{
									bFlag=0;
									for (j=0; j<(int)m_PsedoTLineArray[nFind].nLineArray.size(); j++)
									{
										if (strcmp(pBlock->m_EdgeACLineSegmentArray[lBuf.nLineArray[i]].szName, pBlock->m_EdgeACLineSegmentArray[m_PsedoTLineArray[nFind].nLineArray[j]].szName) == 0)
										{
											bFlag=1;
											break;
										}
									}
									if (!bFlag)
									{
										m_PsedoTLineArray[nFind].nLineArray.push_back(lBuf.nLineArray[i]);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
	{
		pBlock->m_BreakerArray[i].nStatus=bBreakerStatusArray[i];
	}
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
	{
		pBlock->m_DisconnectorArray[i].nStatus=bDisconnectorStatusArray[i];
	}
}


int	CPGNetAnalysis::AffectBus_ResolveSrcNode(tagPGBlock* pBlock)
{
	register int	i;
	int		nSub, nVolt, nDev, nNode;
	int		nNodeVolt, nIsland;
	int		nJointNodeNum, *pnJointNodeArray;
	double	fBuffer;
	std::vector<double>	fIslandUnitPArray;
	std::vector<unsigned char>	bBusProcArray;

	pnJointNodeArray=(int*)malloc(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnJointNodeArray)
		return -1;

	m_nBusStatusArray.resize(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	bBusProcArray.resize(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		m_nBusStatusArray[i]=-1;
		bBusProcArray[i]=0;
	}

	fIslandUnitPArray.clear();

	nIsland=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				if (pBlock->m_BusbarSectionArray[nDev].nNode < 0)
					continue;
				if (bBusProcArray[nDev])
					continue;

				bBusProcArray[nDev]=1;

				nJointNodeNum=0;
				PGTraverseNet(pBlock, pBlock->m_BusbarSectionArray[nDev].nNode, Y_CheckStatus, 0, nJointNodeNum, pnJointNodeArray);

				fBuffer=0;
				for (nNode=0; nNode<nJointNodeNum; nNode++)
				{
					nNodeVolt=pBlock->m_ConnectivityNodeArray[pnJointNodeArray[nNode]].nVoltageLevelPtr;
					for (i=pBlock->m_VoltageLevelArray[nNodeVolt].nBusbarSectionRange; i<pBlock->m_VoltageLevelArray[nNodeVolt+1].nBusbarSectionRange; i++)
					{
						if (pBlock->m_BusbarSectionArray[i].nNode == pnJointNodeArray[nNode])
						{
							bBusProcArray[i]=1;
							m_nBusStatusArray[i]=nIsland;
						}
					}
					for (i=pBlock->m_VoltageLevelArray[nNodeVolt].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[nNodeVolt+1].nSynchronousMachineRange; i++)
					{
						if (pBlock->m_SynchronousMachineArray[i].nNode == pnJointNodeArray[nNode])
							fBuffer += pBlock->m_SynchronousMachineArray[i].fPMax;
					}
				}

				fIslandUnitPArray.push_back(fBuffer);
				nIsland++;
			}
		}
	}

	free(pnJointNodeArray);

	fBuffer=0;
	nDev=-1;
	for (i=0; i<(int)fIslandUnitPArray.size(); i++)
	{
		if (fBuffer < fIslandUnitPArray[i])
		{
			fBuffer=fIslandUnitPArray[i];
			nDev=i;
		}
	}
	if (nDev >= 0)
	{
		for (i=0; i<(int)m_nBusStatusArray.size(); i++)
		{
			if (m_nBusStatusArray[i] != nDev)
				m_nBusStatusArray[i]=0;
			else
				m_nBusStatusArray[i]=1;
		}
	}
	else
		return -1;

	nDev=-1;
	fBuffer=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (fBuffer < pBlock->m_VoltageLevelArray[nVolt].nominalVoltage)
			{
				fBuffer=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

				for (i=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; i++)
				{
					if (pBlock->m_BusbarSectionArray[i].nNode < 0)
						continue;

					if (m_nBusStatusArray[i])
					{
						nDev=pBlock->m_BusbarSectionArray[i].nNode;
					}
				}
			}
		}
	}
	return nDev;
}

void	CPGNetAnalysis::AffectBus_Traverse(tagPGBlock* pBlock, const int nSourceNode)
{
	register int	i;
	int		nDev, nAffect;
	unsigned char	bInRun;
	int		nJointNodeNum;
	int*	pnJointNodeArray;

	pnJointNodeArray=(int*)malloc(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]*sizeof(int));
	if (!pnJointNodeArray)
		return;

	for (nAffect=0; nAffect<(int)m_AffectBusArray.size(); nAffect++)
	{
		m_AffectBusArray[nAffect].nAffectBusOutageArray.clear();
		for (i=0; i<(int)m_AffectBusArray[nAffect].AffectBusDeviceArray.size(); i++)
		{
			if (m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord < 0)
				continue;
			switch (m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nTable)
			{
			case PG_ACLINESEGMENT:
				pBlock->m_ACLineSegmentArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].bOpen=1;
				break;
			case PG_TRANSFORMERWINDING:
				pBlock->m_TransformerWindingArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].bOpen=1;
				break;
			case PG_POWERTRANSFORMER:
				if (pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindNum == 1)
				{
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindH].bOpen=1;
				}
				else
				{
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindH].bOpen=1;
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindM].bOpen=1;
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindL].bOpen=1;
				}
				break;
			case PG_BREAKER:
				pBlock->m_BreakerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nStatus=1;
				break;
			case PG_DISCONNECTOR:
				pBlock->m_DisconnectorArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nStatus=1;
				break;
			case PG_BUSBARSECTION:
				if (pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nNode >= 0)
					pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nNode].bOpen=1;
				break;
			}
		}

		PGTraverseNet(pBlock, nSourceNode, Y_CheckStatus, 0, nJointNodeNum, pnJointNodeArray);

		for (nDev=0; nDev<pBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
		{
			if (!m_nBusStatusArray[nDev])
				continue;

			bInRun=0;
			for (i=0; i<nJointNodeNum; i++)
			{
				if (pBlock->m_BusbarSectionArray[nDev].nNode == pnJointNodeArray[i])
				{
					bInRun=1;
					break;
				}
			}
			if (!bInRun)
			{
				m_AffectBusArray[nAffect].nAffectBusOutageArray.push_back(nDev);
				Log("    ���ĸ�� [%s.%s.%s] ͣ��\n", pBlock->m_BusbarSectionArray[nDev].szSub, pBlock->m_BusbarSectionArray[nDev].szVolt, pBlock->m_BusbarSectionArray[nDev].szName);
			}
		}

		for (i=0; i<(int)m_AffectBusArray[nAffect].AffectBusDeviceArray.size(); i++)
		{
			if (m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord < 0)
				continue;
			switch (m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nTable)
			{
			case PG_ACLINESEGMENT:
				pBlock->m_ACLineSegmentArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].bOpen=0;
				break;
			case PG_TRANSFORMERWINDING:
				pBlock->m_TransformerWindingArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].bOpen=0;
				break;
			case PG_POWERTRANSFORMER:
				if (pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindNum == 1)
				{
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindH].bOpen=0;
				}
				else
				{
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindH].bOpen=0;
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindM].bOpen=0;
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nWindL].bOpen=0;
				}
				break;
			case PG_BREAKER:
				pBlock->m_BreakerArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nStatus=0;
				break;
			case PG_DISCONNECTOR:
				pBlock->m_DisconnectorArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nStatus=0;
				break;
			case PG_BUSBARSECTION:
				if (pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nNode >= 0)
					pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord].nNode].bOpen=0;
				break;
			}
		}
	}

	free(pnJointNodeArray);
}

int		CPGNetAnalysis::ReadFaultDeviceFile(tagPGBlock* pBlock, const char* lpszFileName)
{
	FILE*	fp=fopen(lpszFileName, "r");
	if (fp == NULL)
		return 0;

	register int	i;
	unsigned char	bReadFlag=0;
	char	szLine[1024], szIdent[MDB_CHARLEN_LONG];
	char*	lpszToken;
	std::vector<std::string>	strEleArray;
	tagAffectBusFaultDevice	dBuf;
	tagAffectBus			busBuffer;

	m_AffectBusArray.clear();
	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);
		if (strlen(szLine) <= 0)
			continue;

		strcpy(szIdent, szLine);
		if (strstr(strlwr(szIdent), "[inputdev-start]") != NULL)
		{
			busBuffer.AffectBusDeviceArray.clear();
			bReadFlag=1;
			continue;
		}
		if (strstr(strlwr(szIdent), "[inputdev-end]") != NULL)
		{
			m_AffectBusArray.push_back(busBuffer);
			bReadFlag=0;
			continue;
		}
		if (bReadFlag == 1)
		{

			strEleArray.clear();
			lpszToken=strtok(szLine, " \t\n, ");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL, " \t\n, ");
			}

			if (strEleArray.size() >= 2)
			{
				memset(&dBuf, 0, sizeof(tagAffectBusFaultDevice));
				strcpy(dBuf.szTable, strEleArray[0].c_str());
				strcpy(dBuf.szKey, strEleArray[1].c_str());
				dBuf.nTable=dBuf.nRecord=-1;

				dBuf.nTable=PGGetTableIndex(dBuf.szTable);
				if (dBuf.nTable >= 0)
				{
					switch (dBuf.nTable)
					{
					case PG_ACLINESEGMENT:
						for (i=0; i<pBlock->m_nRecordNum[dBuf.nTable]; i++)
						{
							if (stricmp(pBlock->m_ACLineSegmentArray[i].szName, dBuf.szKey) == 0)
							{
								dBuf.nRecord=i;
								break;
							}
						}
						break;
					case PG_TRANSFORMERWINDING:
						for (i=0; i<pBlock->m_nRecordNum[dBuf.nTable]; i++)
						{
							sprintf(szIdent, "%s.%s", pBlock->m_TransformerWindingArray[i].szSub, pBlock->m_TransformerWindingArray[i].szName);
							if (stricmp(szIdent, dBuf.szKey) == 0)
							{
								dBuf.nRecord=i;
								break;
							}
						}
						break;
					case PG_POWERTRANSFORMER:
						for (i=0; i<pBlock->m_nRecordNum[dBuf.nTable]; i++)
						{
							sprintf(szIdent, "%s.%s", pBlock->m_PowerTransformerArray[i].szSub, pBlock->m_PowerTransformerArray[i].szName);
							if (stricmp(szIdent, dBuf.szKey) == 0)
							{
								dBuf.nRecord=i;
								break;
							}
						}
						break;
					case PG_BREAKER:
						for (i=0; i<pBlock->m_nRecordNum[dBuf.nTable]; i++)
						{
							sprintf(szIdent, "%s.%s.%s", pBlock->m_BreakerArray[i].szSub, FormatVoltageLevelName(pBlock->m_BreakerArray[i].szVolt), pBlock->m_BreakerArray[i].szName);
							if (stricmp(szIdent, dBuf.szKey) == 0)
							{
								dBuf.nRecord=i;
								break;
							}
						}
						break;
					case PG_DISCONNECTOR:
						for (i=0; i<pBlock->m_nRecordNum[dBuf.nTable]; i++)
						{
							sprintf(szIdent, "%s.%s.%s", pBlock->m_DisconnectorArray[i].szSub, FormatVoltageLevelName(pBlock->m_DisconnectorArray[i].szVolt), pBlock->m_DisconnectorArray[i].szName);
							if (stricmp(szIdent, dBuf.szKey) == 0)
							{
								dBuf.nRecord=i;
								break;
							}
						}
						break;
					case PG_BUSBARSECTION:
						for (i=0; i<pBlock->m_nRecordNum[dBuf.nTable]; i++)
						{
							sprintf(szIdent, "%s.%s.%s", pBlock->m_BusbarSectionArray[i].szSub, FormatVoltageLevelName(pBlock->m_BusbarSectionArray[i].szVolt), pBlock->m_BusbarSectionArray[i].szName);
							if (stricmp(szIdent, dBuf.szKey) == 0)
							{
								dBuf.nRecord=i;
								break;
							}
						}
						break;
					}
				}

				busBuffer.AffectBusDeviceArray.push_back(dBuf);
			}
		}
	}

	fclose(fp);

	return 1;
}

void	CPGNetAnalysis::SaveAffectBusFile(tagPGBlock* pBlock, const char* lpszFileName)
{
	FILE*	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	register int	i;
	int				nAffect;
	for (nAffect=0; nAffect<(int)m_AffectBusArray.size(); nAffect++)
	{
		fprintf(fp, "[outputdev-start]\n");
		fprintf(fp, "    [inputdev-start]\n");
		for (i=0; i<(int)m_AffectBusArray[nAffect].AffectBusDeviceArray.size(); i++)
		{
			fprintf(fp, "        %s, %s\n", m_AffectBusArray[nAffect].AffectBusDeviceArray[i].szTable, m_AffectBusArray[nAffect].AffectBusDeviceArray[i].szKey);
		}
		fprintf(fp, "    [inputdev-end]\n");

		fprintf(fp, "    [outdev-list-start]\n");

		for (i=0; i<(int)m_AffectBusArray[nAffect].nAffectBusOutageArray.size(); i++)
		{
			fprintf(fp, "        %s.%s.%s\n", 
				pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szSub, 
				FormatVoltageLevelName(pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szVolt), 
				pBlock->m_BusbarSectionArray[m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szName);
		}
		fprintf(fp, "    [outdev-list-end]\n");
		fprintf(fp, "[outputdev-end]\n");
	}

	fflush(fp);
	fclose(fp);
}