#include "../../PGNetAnalysis/PGNetAnalysis.h"

#include "../../../MemDB/PGMemDB/PGMemDB.h"
#pragma comment(lib, "../../../lib/PGMemDB.lib")
using	namespace	PGMemDB;

#include <vector>
#include <stack>
using namespace	std;


tagPGBlock*		g_pBlock;
CPGNetAnalysis	m_PGAna;
const	double	m_fMinimalVoltage=200;
static	char*	lpszLogFileName="FormBusRouter.log";

static	char	m_szRunDir[260];


void ClearLog()
{
	char	szTempPath[260],szFileName[260];

#ifdef	WIN32
	GetTempPath(260,szTempPath);
#else
	strcpy(szTempPath,"/tmp");
#endif

	sprintf(szFileName,"%s/%s",szTempPath,lpszLogFileName);
	unlink(szFileName);
}


void Log(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szTempPath[260],szFileName[260];
	FILE*	fp;

#ifdef	WIN32
	GetTempPath(260,szTempPath);
#else
	strcpy(szTempPath,"/tmp");
#endif

	sprintf(szFileName,"%s/%s",szTempPath,lpszLogFileName);
	fp=fopen(szFileName,"a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}

char* FormatVoltageLevelName(const char* lpszInVoltName)
{
	static	char	szFormatedVoltName[MDB_CHARLEN_SHORT];
	char*	lpszToken;
	char	szBuf[MDB_CHARLEN_LONG];
	std::vector<std::string>	strEleArray;

	strEleArray.clear();
	strcpy(szBuf, lpszInVoltName);
	lpszToken=strtok(szBuf,". \t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL,". \t\n");
	}
	strcpy(szFormatedVoltName,strEleArray[strEleArray.size()-1].c_str());
	return szFormatedVoltName;
}

int main(int argc, char** argv)
{
	register int	i;

	clock_t	dBeg,dEnd;
	int		nDur;

	char	szFileName[260];
	char	szBusName[260],szDevName[260],szTimeStamp[260];;
	char	szDirName[260];
	int		nYear,nMonth,nDay,nHour,nMinute;
	unsigned char	bFormRing,bRunRouter;

	int		nRow,nDev;

	GetCurrentDirectory(260,m_szRunDir);

	ClearLog();

	if (argc < 8)
	{
		Log("��ȷ�ĺ����÷���: FormBusRouter BusName(Sub.Volt.Name) FormRing RunRouter DestDir Year Month Day Hour Minute\n");
		return 0;
	}

	dBeg=clock();

	nYear=nMonth=nDay=nHour=nMinute=0;
	bFormRing=bRunRouter=1;

	i=1;
	if (argc > i)	strcpy(szBusName,argv[i++]);	Log("BusName=%s\n",szBusName);
	if (argc > i)	bFormRing=atoi(argv[i++]);		Log("FormRing=%d\n",bFormRing);
	if (argc > i)	bRunRouter=atoi(argv[i++]);		Log("RunRouter=%d\n",bRunRouter);
	if (argc > i)	strcpy(szDirName,argv[i++]);	Log("DestDir=%s\n",szDirName);
	if (argc > i)	nYear=atoi(argv[i++]);			Log("Year=%d\n",nYear);
	if (argc > i)	nMonth=atoi(argv[i++]);			Log("Month=%d\n",nMonth);
	if (argc > i)	nDay=atoi(argv[i++]);			Log("Day=%d\n",nDay);
	if (argc > i)	nHour=atoi(argv[i++]);			Log("Hour=%d\n",nHour);
	if (argc > i)	nMinute=atoi(argv[i++]);		Log("Minute=%d\n",nMinute);

	g_pBlock=(tagPGBlock*)Init_PGBlock();
	if (!g_pBlock)
	{
		Log("��ȡ�ڴ�����\n");
		return 0;
	}

	sprintf(szFileName,"%s/PASSWAY-%.4d%.2d%.2d%.2d%.2d.txt",szDirName, nYear, nMonth, nDay, nHour, nMinute);
	FILE*	fp=fopen(szFileName,"w");
	if (fp == NULL)
	{
		Log("���ļ�����\n");
		return 0;
	}

	int	nStartBus=-1;
	for (nDev=0; nDev<g_pBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
	{
		sprintf(szDevName,"%s.%s.%s",g_pBlock->m_BusbarSectionArray[nDev].szSub,FormatVoltageLevelName(g_pBlock->m_BusbarSectionArray[nDev].szVolt),g_pBlock->m_BusbarSectionArray[nDev].szName);
		if (strcmp(szDevName,szBusName) == 0)
		{
			nStartBus=nDev;
			break;
		}
	}
	if (nStartBus < 0)
	{
		Log("ĸ�߲����豸�б���\n");
		return 0;
	}
	if (g_pBlock->m_BusbarSectionArray[nStartBus].iRnd < 0)
	{
		Log("ĸ�߲���������\n");
		return 0;
	}

	if (bFormRing)
		m_PGAna.PGDecompose(g_pBlock, m_fMinimalVoltage);

	sprintf(szTimeStamp,"%.4d%.2d%.2d %.2d:%.2d\n",nYear,nMonth,nDay,nHour,nMinute);	//yyyyMMddHH(24):mm:ss
	m_PGAna.FormWayFile(g_pBlock, bRunRouter, nStartBus, szFileName, szTimeStamp);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	printf("�����ļ�������ϣ���ʱ%d����\n",nDur);

	return 1;
}