//#include "stdafx.h"
//#include "PGNetAnalysisApp.h"
#include "PGNetAnalysis.h"
#include <vector>
using namespace std;

#include "../../MemDB/PGMemDB/PGMemDB.h"
using namespace PGMemDB;

extern	void Log(char* pformat, ...);

const	double	m_fMinimalVoltage=200;

char* FormatVoltageLevelName(const char* lpszInVoltName)
{
	static	char	szFormatedVoltName[MDB_CHARLEN_SHORT];
	char*	lpszToken;
	char	szBuf[MDB_CHARLEN_LONG];
	std::vector<std::string>	strEleArray;

	strcpy(szFormatedVoltName, lpszInVoltName);

	strEleArray.clear();
	strcpy(szBuf, lpszInVoltName);
	lpszToken=strtok(szBuf, ". \t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, ". \t\n");
	}
	if (!strEleArray.empty())
		strcpy(szFormatedVoltName, strEleArray[strEleArray.size()-1].c_str());
	return szFormatedVoltName;
}

void FormBusRouter(tagPGBlock* pBlock, 
				   CPGNetAnalysis* pPGNetAnalysis, 
				   const char* lpszDestDir, 
				   const int nYear, 
				   const int nMonth, 
				   const int nDay, 
				   const int nHour, 
				   const int nMinute, 
				   const std::vector<std::string> strRouterBusbarsectionArray, 
				   const std::vector<std::string> strBuslinkBreakerArray)
{
	register int	i, j;
	int		nSub, nVolt, nDev, nBus;
	int		nWayRow, nAllWayRow, nBusRow;
	unsigned char	bExist;
	int		nHubSub;
	std::vector<int>	nHubSubArray;
	char	szBusName[MDB_CHARLEN_LONG], szFileName[260];
	char	szBuf[260];
	char*	lpszToken;
	std::vector<std::string>	strEleArray;
	std::vector<unsigned char>	nBuslinkBreakerStatusArray;


	sprintf(szFileName, "%s/PASSWAY-%.4d%.2d%.2d%.2d%.2d.txt", lpszDestDir, nYear, nMonth, nDay, nHour, nMinute);
	FILE*	fp=fopen(szFileName, "w");
	if (fp == NULL)
	{
		Log("���ļ�����\n");
		return;
	}

	if (!strBuslinkBreakerArray.empty())
	{
		nBuslinkBreakerStatusArray.resize(strBuslinkBreakerArray.size());
		for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
				{
					sprintf(szBuf, "%s.%s.%s", pBlock->m_BreakerArray[nDev].szSub, FormatVoltageLevelName(pBlock->m_BreakerArray[nDev].szVolt), pBlock->m_BreakerArray[nDev].szName);
					for (i=0; i<(int)strBuslinkBreakerArray.size(); i++)
					{
						if (strcmp(strBuslinkBreakerArray[i].c_str(), szBuf) == 0)
						{
							nBuslinkBreakerStatusArray[i]=pBlock->m_BreakerArray[nDev].nStatus;
							pBlock->m_BreakerArray[nDev].nStatus=1;
							Log("����ĸ��������Ϣ: %s\n", szBuf);
							break;
						}
					}
				}
			}
		}
	}

	fprintf(fp, "[file-start]\n");

	fprintf(fp, "\t[timestamp-start]\n");
	fprintf(fp, "\t\t%.4d%.2d%.2d %.2d:%.2d\n", nYear, nMonth, nDay, nHour, nMinute);	//yyyyMMddHH(24):mm:ss
	fprintf(fp, "\t[timestamp-end]\n");

	nWayRow=nAllWayRow=nBusRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 40)
				continue;

			for (nBus=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nBus<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nBus++)
			{
				if (pBlock->m_BusbarSectionArray[nBus].nNode < 0)
					continue;
				if (!strRouterBusbarsectionArray.empty())
				{
					strEleArray.clear();
					strcpy(szBuf, pBlock->m_VoltageLevelArray[nVolt].szName);
					lpszToken=strtok(szBuf, ".\t\n");
					while (lpszToken != NULL)
					{
						strEleArray.push_back(lpszToken);
						lpszToken = strtok(NULL, ".\t\n");
					}

					sprintf(szBusName, "%s.%s.%s", pBlock->m_SubstationArray[nSub].szName, strEleArray[strEleArray.size()-1].c_str(), pBlock->m_BusbarSectionArray[nBus].szName);
					bExist=0;
					for (i=0; i<(int)strRouterBusbarsectionArray.size(); i++)
					{
						if (stricmp(strRouterBusbarsectionArray[i].c_str(), szBusName) == 0)
						{
							bExist=1;
							break;
						}
					}
					if (!bExist)
						continue;
				}
				//if (pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[nBus].iRnd].nIsland <= 0)
				//	continue;

				//Log("׷��: %s %s %s\n", pBlock->m_BusbarSectionArray[nBus].szSub, FormatVoltageLevelName(pBlock->m_BusbarSectionArray[nBus].szVolt), pBlock->m_BusbarSectionArray[nBus].szName);
				pPGNetAnalysis->TraceSource(pBlock, 1, 1, pBlock->m_BusbarSectionArray[nBus].nNode);
				nHubSubArray.clear();
				fprintf(fp, "\t[passwayinfo-start]\n");
				for (nDev=0; nDev<(int)pPGNetAnalysis->m_TraceBranArray.size(); nDev++)
				{
					//if (pPGNetAnalysis->m_TraceBranArray[nDev].nDeep == 0)
					//	continue;

					fprintf(fp, "\t\t%d, ", ++nWayRow);
					fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nBus].szSub);
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_BusbarSectionArray[nBus].szVolt));
					fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nBus].szName);

					fprintf(fp, "%d, ", pPGNetAnalysis->m_TraceBranArray[nDev].nDeep);
					fprintf(fp, "%s, ", PGGetTableName(pPGNetAnalysis->m_TraceBranArray[nDev].nBranType));
					if (pPGNetAnalysis->m_TraceBranArray[nDev].nBranType == PG_ACLINESEGMENT)
						fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TraceBranArray[nDev].nBranIndex].szName);
					else
						fprintf(fp, "%s, ", pBlock->m_PowerTransformerArray[pPGNetAnalysis->m_TraceBranArray[nDev].nBranIndex].szName);
					fprintf(fp, "%s, ", pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nFrNode].szSub);
					fprintf(fp, "%s, ", pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToNode].szSub);
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nFrNode].szVolt));
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToNode].szVolt));

					fprintf(fp, "%d, ", pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray.size());
					for (i=0; i<(int)pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray.size(); i++)
						fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray[i]].szName);

					fprintf(fp, "%d, ", pPGNetAnalysis->m_TraceBranArray[nDev].nHubTranArray.size());
					for (i=0; i<(int)pPGNetAnalysis->m_TraceBranArray[nDev].nHubTranArray.size(); i++)
						fprintf(fp, "%s, ", pBlock->m_PowerTransformerArray[pPGNetAnalysis->m_TraceBranArray[nDev].nHubTranArray[i]].szName);
					fprintf(fp, "\n");

					for (i=0; i<(int)pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray.size(); i++)
					{
						nHubSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_BusbarSectionArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray[i]].szSub);
						if (pBlock->m_SubstationArray[nHubSub].bHub)
						{
							bExist=0;
							for (j=0; j<(int)nHubSubArray.size(); j++)
							{
								if (nHubSubArray[j] == nHubSub)
								{
									bExist=1;
									break;
								}
							}
							if (!bExist)
								nHubSubArray.push_back(nHubSub);
						}
					}
				}
				fprintf(fp, "\t[passwayinfo-end]\n");

				pPGNetAnalysis->TraceSource(pBlock, 0, 0, pBlock->m_BusbarSectionArray[nBus].nNode);
				fprintf(fp, "\t[passallwayinfo-start]\n");
				for (nDev=0; nDev<(int)pPGNetAnalysis->m_TraceBranArray.size(); nDev++)
				{
					if (pPGNetAnalysis->m_TraceBranArray[nDev].nDeep == 0)
						continue;

					fprintf(fp, "\t\t%d, ", ++nAllWayRow);
					fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nBus].szSub);
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_BusbarSectionArray[nBus].szVolt));
					fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nBus].szName);

					fprintf(fp, "%d, ", pPGNetAnalysis->m_TraceBranArray[nDev].nDeep);
					fprintf(fp, "%s, ", PGGetTableName(pPGNetAnalysis->m_TraceBranArray[nDev].nBranType));
					if (pPGNetAnalysis->m_TraceBranArray[nDev].nBranType == PG_ACLINESEGMENT)
						fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TraceBranArray[nDev].nBranIndex].szName);
					else
						fprintf(fp, "%s, ", pBlock->m_PowerTransformerArray[pPGNetAnalysis->m_TraceBranArray[nDev].nBranIndex].szName);
					fprintf(fp, "%s, ", pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nFrNode].szSub);
					fprintf(fp, "%s, ", pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToNode].szSub);
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nFrNode].szVolt));
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_ConnectivityNodeArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToNode].szVolt));

					fprintf(fp, "%d, ", pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray.size());
					for (i=0; i<(int)pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray.size(); i++)
						fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[pPGNetAnalysis->m_TraceBranArray[nDev].nToBusArray[i]].szName);

					fprintf(fp, "%d, ", pPGNetAnalysis->m_TraceBranArray[nDev].nHubTranArray.size());
					for (i=0; i<(int)pPGNetAnalysis->m_TraceBranArray[nDev].nHubTranArray.size(); i++)
						fprintf(fp, "%s, ", pBlock->m_PowerTransformerArray[pPGNetAnalysis->m_TraceBranArray[nDev].nHubTranArray[i]].szName);
					fprintf(fp, "\n");
				}
				fprintf(fp, "\t[passallwayinfo-end]\n");

				fprintf(fp, "\t[bussourceinfo-start]\n");
				fprintf(fp, "\t\t%d, ", ++nBusRow);
				fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nBus].szSub);
				fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_BusbarSectionArray[nBus].szVolt));
				fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nBus].szName);
				for (i=0; i<(int)nHubSubArray.size(); i++)
					fprintf(fp, "%s, ", pBlock->m_SubstationArray[nHubSubArray[i]].szName);
				fprintf(fp, "\n");
				fprintf(fp, "\t[bussourceinfo-end]\n");
			}
		}
	}
	fprintf(fp, "[file-end]\n");

	fflush(fp);
	fclose(fp);

	if (!strBuslinkBreakerArray.empty())
	{
		nBuslinkBreakerStatusArray.resize(strBuslinkBreakerArray.size());
		for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
				{
					sprintf(szBuf, "%s.%s.%s", pBlock->m_BreakerArray[nDev].szSub, FormatVoltageLevelName(pBlock->m_BreakerArray[nDev].szVolt), pBlock->m_BreakerArray[nDev].szName);
					for (i=0; i<(int)strBuslinkBreakerArray.size(); i++)
					{
						if (strcmp(strBuslinkBreakerArray[i].c_str(), szBuf) == 0)
						{
							pBlock->m_BreakerArray[nDev].nStatus=nBuslinkBreakerStatusArray[i];
							Log("    �ָ�ĸ��������Ϣ: %s\n", szBuf);
							break;
						}
					}
				}
			}
		}
	}
}

void FormBaseTxt(tagPGBlock* pBlock, CPGNetAnalysis* pPGNetAnalysis, const char* lpszDestDir, const int nYear, const int nMonth, const int nDay, const int nHour, const int nMinute, const std::vector<std::string> strFilterSubontrolAreaArray)
{

	register int	i;
	int		nRow, nSub, nVolt, nDev;
	unsigned char	bFiltered, bFlag;
	int		nDevNum, nTranNum, nTranCoil[10];
	int		nNodeNum, nNodeArray[200];
	std::vector<int>	nDevArray;
	std::vector<unsigned char>	bProcArray;
	double	fMaxVolt;
	int		nMaxVolt;
	char	szFileName[260];

	sprintf(szFileName, "%s/PG-%.4d%.2d%.2d%.2d%.2d.txt", lpszDestDir, nYear, nMonth, nDay, nHour, nMinute);
	FILE*	fp=fopen(szFileName, "w");
	if (fp == NULL)
		return;

	pPGNetAnalysis->FormSameBreakerLine(pBlock);
	pPGNetAnalysis->FormTLine(pBlock);
	pPGNetAnalysis->FormPsedoTLine(pBlock);

	fprintf(fp, "[file-start]\n");

	fprintf(fp, "\t[timestamp-start]\n");
	fprintf(fp, "\t\t%.4d%.2d%.2d %.2d:%.2d\n", nYear, nMonth, nDay, nHour, nMinute);	//yyyyMMddHH(24):mm:ss
	fprintf(fp, "\t[timestamp-end]\n");

	fprintf(fp, "\t[base-aclinesegment-start]\n");
	nRow=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (nVolt < 0)
			continue;

		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ACLineSegmentArray[nDev].szSubI);
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
			{
				nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ACLineSegmentArray[nDev].szSubJ);
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		fprintf(fp, "\t\t");
		fprintf(fp, "%d, ", ++nRow);
		fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nDev].szName);
		fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nDev].szSubI);
		fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nDev].szSubJ);
		fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_ACLineSegmentArray[nDev].szVoltI));
		fprintf(fp, "%f, ", pBlock->m_VoltageLevelArray[nVolt].nominalVoltage);

		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fRatedCur);
		fprintf(fp, "%f, ", 1.732*pBlock->m_ACLineSegmentArray[nDev].fRatedCur*pBlock->m_VoltageLevelArray[nVolt].nominalVoltage/1000.0);

		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fPi);
		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fQi);
		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fPz);
		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fQz);
		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fA);
		fprintf(fp, "%f, ", pBlock->m_ACLineSegmentArray[nDev].fA);


		PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeI, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
		nDevNum=0;
		for (i=0; i<nNodeNum; i++)
		{
			if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
			{
				nDevNum++;
			}
		}
		fprintf(fp, "%d, ", nDevNum);
		for (i=0; i<nNodeNum; i++)
		{
			if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
			{
				fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
			}
		}

		PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nDev].nNodeJ, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
		nDevNum=0;
		for (i=0; i<nNodeNum; i++)
		{
			if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
			{
				nDevNum++;
			}
		}
		fprintf(fp, "%d, ", nDevNum);
		for (i=0; i<nNodeNum; i++)
		{
			if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
			{
				fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
			}
		}

		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[base-aclinesegment-end]\n");

	fprintf(fp, "\t[base-transformerwinding-start]\n");
	nRow=0;
	bProcArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING], 0);
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nDev=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			if (bProcArray[nDev])
				continue;
			bProcArray[nDev]=1;

			if (pBlock->m_TransformerWindingArray[nDev].nTran < 0)
				continue;

			nTranNum=0;
			if (pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].nWindNum == 1)
			{
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindH, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
			}
			else
			{
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindH, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindM, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindL, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
			}

			for (i=0; i<nTranNum; i++)
				bProcArray[nTranCoil[i]]=1;
			fprintf(fp, "\t\t");
			fprintf(fp, "%d, ", ++nRow);
			fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
			fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nDev].szPowerTransformer);

			if (nTranNum == 1)
			{
				fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fRatedMva);
				fprintf(fp, ", ");
				fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fRatedMva);

				fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nDev].szName);
				fprintf(fp, ", ");
				fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nDev].szName);
				if (pBlock->m_VoltageLevelArray[pBlock->m_TransformerWindingArray[nDev].nVoltI].nominalVoltage > pBlock->m_VoltageLevelArray[pBlock->m_TransformerWindingArray[nDev].nVoltJ].nominalVoltage)
				{
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_TransformerWindingArray[nDev].szVoltI));
					fprintf(fp, ", ");
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_TransformerWindingArray[nDev].szVoltJ));

					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fPi);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fQi);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fAi);

					fprintf(fp, ", ");
					fprintf(fp, ", ");
					fprintf(fp, ", ");

					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fPz);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fQz);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fAz);
				}
				else
				{
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_TransformerWindingArray[nDev].szVoltJ));
					fprintf(fp, ", ");
					fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_TransformerWindingArray[nDev].szVoltI));

					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fPz);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fQz);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fAz);

					fprintf(fp, ", ");
					fprintf(fp, ", ");
					fprintf(fp, ", ");

					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fPi);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fQi);
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nDev].fAi);
				}
			}
			else
			{
				for (i=0; i<nTranNum; i++)
					fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fRatedMva);

				for (i=0; i<nTranNum; i++)
					fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].szName);

				for (i=0; i<nTranNum; i++)
				{
					if (pBlock->m_TransformerWindingArray[nTranCoil[i]].bTranMidSide != 1)
						fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_TransformerWindingArray[nTranCoil[i]].szVoltI));
					else
						fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_TransformerWindingArray[nTranCoil[i]].szVoltJ));
				}
				for (i=0; i<nTranNum; i++)
				{
					if (pBlock->m_TransformerWindingArray[nTranCoil[i]].bTranMidSide != 1)
					{
						fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fPi);
						fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fQi);
						fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fAi);
					}
					else
					{
						fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fPz);
						fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fQz);
						fprintf(fp, "%f, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].fAz);
					}
				}
			}

			fprintf(fp, "\n");
		}
	}
	fprintf(fp, "\t[base-transformerwinding-end]\n");

	fprintf(fp, "\t[base-breaker-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
			{
				fprintf(fp, "\t\t");
				fprintf(fp, "%d, ", ++nRow);
				fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
				fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));
				fprintf(fp, "%s, ", pBlock->m_BreakerArray[nDev].szName);
				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "\t[base-breaker-end]\n");

	fprintf(fp, "\t[base-disconnector-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
			{
				fprintf(fp, "\t\t");
				fprintf(fp, "%d, ", ++nRow);
				fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
				fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));
				fprintf(fp, "%s, ", pBlock->m_DisconnectorArray[nDev].szName);
				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "\t[base-disconnector-end]\n");

	fprintf(fp, "\t[base-voltagelevel-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			fprintf(fp, "\t\t");
			fprintf(fp, "%d, ", ++nRow);
			fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
			fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));
			fprintf(fp, "\n");
		}
	}
	fprintf(fp, "\t[base-voltagelevel-end]\n");

	fprintf(fp, "\t[base-substation-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		fprintf(fp, "\t\t");
		fprintf(fp, "%d, ", ++nRow);
		fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szSubcontrolArea);
		fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);



		fMaxVolt=-10000;
		nMaxVolt=-1;
		for (i=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; i<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; i++)
		{
			if (pBlock->m_VoltageLevelArray[i].nConnecivityNodeRange < pBlock->m_VoltageLevelArray[i+1].nConnecivityNodeRange)
			{
				if (fMaxVolt < pBlock->m_VoltageLevelArray[i].nominalVoltage)
				{
					fMaxVolt=pBlock->m_VoltageLevelArray[i].nominalVoltage;
					nMaxVolt=i;
				}
			}
		}
		if (nMaxVolt >= 0)
			fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nMaxVolt].szName));
		else
			fprintf(fp, "0, ");
		fprintf(fp, "%d, ", pBlock->m_SubstationArray[nSub].bHub);

		fprintf(fp, "%d, ", PGIsTConnection(pBlock, pBlock->m_VoltageLevelArray[nMaxVolt].nConnecivityNodeRange));

		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[base-substation-end]\n");

	fprintf(fp, "\t[base-busbarsection-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				fprintf(fp, "\t\t");
				fprintf(fp, "%d, ", ++nRow);
				fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
				fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));
				fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[nDev].szName);
				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "\t[base-busbarsection-end]\n");

	fprintf(fp, "\t[T-line-start]\n");
	for (nDev=0; nDev<(int)pPGNetAnalysis->m_TLineArray.size(); nDev++)
	{
		fprintf(fp, "\t\t%d, ", nDev+1);
		for (i=0; i<(int)pPGNetAnalysis->m_TLineArray[nDev].nLineArray.size(); i++)
		{
			bFlag = 0;
			if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].nNodeI))
				bFlag += 1;
			if (PGIsTConnection(pBlock, pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].nNodeJ))
				bFlag += 2;

			if (bFlag == 1 || bFlag == 2)
			{
				fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].szName);
				if (bFlag == 1)
				{
					fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].szSubJ);
					fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].szSubI);
				}
				else
				{
					fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].szSubI);
					fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_TLineArray[nDev].nLineArray[i]].szSubJ);
				}
			}
		}
		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[T-line-end]\n");

	fprintf(fp, "\t[PsedoT-line-start]\n");
	for (nDev=0; nDev<(int)pPGNetAnalysis->m_PsedoTLineArray.size(); nDev++)
	{
		fprintf(fp, "\t\t%d, ", nDev+1);
		for (i=0; i<(int)pPGNetAnalysis->m_PsedoTLineArray[nDev].nLineArray.size(); i++)
		{
			fprintf(fp, "%s, ", pBlock->m_EdgeACLineSegmentArray[pPGNetAnalysis->m_PsedoTLineArray[nDev].nLineArray[i]].szSub);
			fprintf(fp, "%s, ", pBlock->m_EdgeACLineSegmentArray[pPGNetAnalysis->m_PsedoTLineArray[nDev].nLineArray[i]].szName);
		}
		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[PsedoT-line-end]\n");

	fprintf(fp, "\t[same-breaker-line-start]\n");
	nRow=0;
	for (nDev=0; nDev<(int)pPGNetAnalysis->m_SameBreakerLineArray.size(); nDev++)
	{
		fprintf(fp, "\t\t%d, ", ++nRow);
		fprintf(fp, "%s, %s, %s, ", pBlock->m_BreakerArray[pPGNetAnalysis->m_SameBreakerLineArray[nDev].nBreaker].szSub, 
			FormatVoltageLevelName(pBlock->m_BreakerArray[pPGNetAnalysis->m_SameBreakerLineArray[nDev].nBreaker].szVolt), 
			pBlock->m_BreakerArray[pPGNetAnalysis->m_SameBreakerLineArray[nDev].nBreaker].szName);
		for (i=0; i<(int)pPGNetAnalysis->m_SameBreakerLineArray[nDev].nLineArray.size(); i++)
		{
			fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[pPGNetAnalysis->m_SameBreakerLineArray[nDev].nLineArray[i]].szName);
		}
		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[same-breaker-line-end]\n");

	fprintf(fp, "\t[base-energyconsumer-start]\n");
	nRow=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		if (pBlock->m_EnergyConsumerArray[nDev].nNode < 0)
			continue;

		fprintf(fp, "\t\t%d, ", ++nRow);
		fprintf(fp, "%s, ", pBlock->m_EnergyConsumerArray[nDev].szSub);
		fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_EnergyConsumerArray[nDev].szVolt));
		fprintf(fp, "%s, ", pBlock->m_EnergyConsumerArray[nDev].szName);

		if (pBlock->m_ConnectivityNodeArray[pBlock->m_EnergyConsumerArray[nDev].nNode].nBusbarSectionPtr < 0)
		{
			PGTraverseVolt(pBlock, pBlock->m_EnergyConsumerArray[nDev].nNode, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
			nDevNum=0;
			for (i=0; i<nNodeNum; i++)
			{
				if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
				{
					nDevNum++;
				}
			}
			fprintf(fp, "%d, ", nDevNum);
			for (i=0; i<nNodeNum; i++)
			{
				if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
				{
					fprintf(fp, "%s, ", pBlock->m_BusbarSectionArray[pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
				}
			}
		}
		else
		{
			fprintf(fp, "1, %s, ", pBlock->m_BusbarSectionArray[pBlock->m_ConnectivityNodeArray[pBlock->m_EnergyConsumerArray[nDev].nNode].nBusbarSectionPtr].szName);
		}

		nDevArray.clear();
		if (pBlock->m_ConnectivityNodeArray[pBlock->m_EnergyConsumerArray[nDev].nNode].nBusbarSectionPtr < 0)
		{
			for (i=0; i<nNodeNum; i++)
			{
				for (int j=pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBreakerRange; j<pBlock->m_ConnectivityNodeArray[nNodeArray[i]+1].nBreakerRange; j++)
				{
					if (pBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0)
						continue;

					bFlag=0;
					for (int k=0; k<(int)nDevArray.size(); k++)
					{
						if (nDevArray[k] == pBlock->m_EdgeBreakerArray[j].nBreaker)
						{
							bFlag=1;
							break;
						}
					}
					if (!bFlag)
						nDevArray.push_back(pBlock->m_EdgeBreakerArray[j].nBreaker);
				}
			}
		}
		fprintf(fp, "%d, ", nDevArray.size());
		for (i=0; i<(int)nDevArray.size(); i++)
		{
			fprintf(fp, "%s, ", pBlock->m_BreakerArray[nDevArray[i]].szName);
		}
		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[base-energyconsumer-end]\n");

	fprintf(fp, "[file-end]\n");

	fflush(fp);
	fclose(fp);
}

int	isRunNode(tagPGBlock* pBlock, int nNodeNum, int* pnNodeArray)
{
	register int	i;
	int		nNode;
	for (nNode=0; nNode<nNodeNum; nNode++)
	{
		for (i=pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr].nSynchronousMachineRange; i<pBlock->m_VoltageLevelArray[pBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].nVoltageLevelPtr+1].nSynchronousMachineRange; i++)
		{
			if (pBlock->m_SynchronousMachineArray[i].fPlanP > 0)
			{
				return 1;
			}
		}
	}
	return 0;
}

void FormStatus(tagPGBlock* pBlock, const char* lpszDestDir, const int nYear, const int nMonth, const int nDay, const int nHour, const int nMinute, const std::vector<std::string> strFilterSubontrolAreaArray)
{
	register int	i;
	int		nRow, nSub, nVolt, nDev;
	unsigned char	bFiltered;
	int		nTranNum, nTranCoil[10];
	char	szFileName[260];
	std::vector<int>	nDevArray;
	std::vector<unsigned char>	bProcArray;

	sprintf(szFileName, "%s/PGStatus-%.4d%.2d%.2d%.2d%.2d.txt", lpszDestDir, nYear, nMonth, nDay, nHour, nMinute);
	FILE*	fp=fopen(szFileName, "w");
	if (fp == NULL)
		return;

 	PGMemDBTopo(pBlock);
 	PGMemDBStatus(pBlock, 0);

	fprintf(fp, "[file-start]\n");

	fprintf(fp, "\t[timestamp-start]\n");
	fprintf(fp, "\t\t%.4d%.2d%.2d %.2d:%.2d\n", nYear, nMonth, nDay, nHour, nMinute);	//yyyyMMddHH(24):mm:ss
	fprintf(fp, "\t[timestamp-end]\n");

	fprintf(fp, "\t[base-aclinesegment-start]\n");
	nRow=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ACLineSegmentArray[nDev].szSubI);
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
			{
				nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ACLineSegmentArray[nDev].szSubJ);
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

// 		nStatus=0;
// 		if (pBlock->m_ACLineSegmentArray[nDev].remove != 0)
// 		{
// 			nStatus=3;
// 		}
// 		else
// 		{
// 			pBlock->m_ACLineSegmentArray[nDev].bOpen=1;
// 			PGTraverseNet(pBlock, pBlock->m_ACLineSegmentArray[nDev].iRnd, Y_CheckStatus, 0, nAllNodeNum, pnAllNodeArray);
// 			if (isRunNode(pBlock, nAllNodeNum, pnAllNodeArray))	nStatus += 1;
// 			PGTraverseNet(pBlock, pBlock->m_ACLineSegmentArray[nDev].zRnd, Y_CheckStatus, 0, nAllNodeNum, pnAllNodeArray);
// 			if (isRunNode(pBlock, nAllNodeNum, pnAllNodeArray))	nStatus += 2;
// 			pBlock->m_ACLineSegmentArray[nDev].bOpen=0;
// 		}

		fprintf(fp, "\t\t");
		fprintf(fp, "%d, ", ++nRow);
		fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nDev].szName);
		fprintf(fp, "%d, ", pBlock->m_ACLineSegmentArray[nDev].bOutage);

		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[base-aclinesegment-end]\n");

	fprintf(fp, "\t[base-transformerwinding-start]\n");
	nRow=0;
	bProcArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING], 0);
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nDev=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			if (bProcArray[nDev])
				continue;
			bProcArray[nDev]=1;

			if (pBlock->m_TransformerWindingArray[nDev].nTran < 0)
				continue;

			nTranNum=0;
			if (pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].nWindNum == 1)
			{
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindH, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
			}
			else
			{
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindH, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindM, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
				for (i=pBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
				{
					if (strcmp(pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nDev].nTran].szWindL, pBlock->m_TransformerWindingArray[i].szName) == 0)
					{
						nTranCoil[nTranNum++]=i;
						break;
					}
				}
			}

			for (i=0; i<nTranNum; i++)
				bProcArray[nTranCoil[i]]=1;
			fprintf(fp, "\t\t");
			fprintf(fp, "%d, ", ++nRow);
			fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
			fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nDev].szPowerTransformer);

			if (nTranNum == 1)
			{
				fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nDev].szName);
				fprintf(fp, ", ");
				fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nDev].szName);

				fprintf(fp, "%d, ", pBlock->m_TransformerWindingArray[nDev].bOutage);
				fprintf(fp, ", ");
				fprintf(fp, "%d, ", pBlock->m_TransformerWindingArray[nDev].bOutage);
			}
			else
			{
				for (i=0; i<nTranNum; i++)
					fprintf(fp, "%s, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].szName);

				for (i=0; i<nTranNum; i++)
					fprintf(fp, "%d, ", pBlock->m_TransformerWindingArray[nTranCoil[i]].bOutage);
			}

			fprintf(fp, "\n");
		}
	}
	fprintf(fp, "\t[base-transformerwinding-end]\n");

	fprintf(fp, "\t[base-breaker-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
			{
				fprintf(fp, "\t\t");
				fprintf(fp, "%d, ", ++nRow);
				fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
				fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));
				fprintf(fp, "%s, ", pBlock->m_BreakerArray[nDev].szName);
				fprintf(fp, "%d, ", pBlock->m_BreakerArray[nDev].nStatus);
				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "\t[base-breaker-end]\n");

	fprintf(fp, "\t[base-disconnector-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (!strFilterSubontrolAreaArray.empty())
		{
			bFiltered=0;
			if (!bFiltered)
			{
				for (i=0; i<(int)strFilterSubontrolAreaArray.size(); i++)
				{
					if (strcmp(strFilterSubontrolAreaArray[i].c_str(), pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
					{
						bFiltered=1;
						break;
					}
				}
			}
			if (!bFiltered)
				continue;
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
			{
				fprintf(fp, "\t\t");
				fprintf(fp, "%d, ", ++nRow);
				fprintf(fp, "%s, ", pBlock->m_SubstationArray[nSub].szName);
				fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));
				fprintf(fp, "%s, ", pBlock->m_DisconnectorArray[nDev].szName);
				fprintf(fp, "%d, ", pBlock->m_DisconnectorArray[nDev].nStatus);
				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "\t[base-disconnector-end]\n");

	fprintf(fp, "\t[base-energyconsumer-start]\n");
	nRow=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		if (pBlock->m_EnergyConsumerArray[nDev].nNode < 0)
			continue;

		fprintf(fp, "\t\t%d, ", ++nRow);
		fprintf(fp, "%s, ", pBlock->m_EnergyConsumerArray[nDev].szSub);
		fprintf(fp, "%s, ", FormatVoltageLevelName(pBlock->m_EnergyConsumerArray[nDev].szVolt));
		fprintf(fp, "%s, ", pBlock->m_EnergyConsumerArray[nDev].szName);
		fprintf(fp, "%d, ", pBlock->m_EnergyConsumerArray[nDev].bOutage);

		fprintf(fp, "\n");
	}
	fprintf(fp, "\t[base-energyconsumer-end]\n");

	fprintf(fp, "[file-end]\n");

	fflush(fp);
	fclose(fp);
}


void FormLineAffectBus(tagPGBlock* pBlock, CPGNetAnalysis* pPGNetAnalysis, const char* lpszFileName, const std::vector<std::string> strAffectLineArray)
{
	register int	i;
	int		nLine, nVolt, nAffect;
	unsigned char	bInCheck;
	FILE*	fp;
	std::vector<int>	nBusOutageArray;
	tagAffectBusFaultDevice	dBuf;
	tagAffectBus			busBuffer;

	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	int	nSrcNode=pPGNetAnalysis->AffectBus_ResolveSrcNode(pBlock);
	if (nSrcNode < 0)
		return;
	for (nLine=0; nLine<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nLine].szSubI, pBlock->m_ACLineSegmentArray[nLine].szVoltI);
		if (nVolt < 0)
			continue;
		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 400 || pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 100)
			continue;

		bInCheck=1;
		if (!strAffectLineArray.empty())
		{
			bInCheck=0;
			for (i=0; i<(int)strAffectLineArray.size(); i++)
			{
				if (strcmp(pBlock->m_ACLineSegmentArray[nLine].szName, strAffectLineArray[i].c_str()) == 0)
				{
					bInCheck=1;
					break;
				}
			}
		}
		if (!bInCheck)
			continue;

		fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nLine].szName);
		nBusOutageArray.clear();

		pPGNetAnalysis->m_AffectBusArray.clear();
		busBuffer.AffectBusDeviceArray.clear();
		busBuffer.nAffectBusOutageArray.clear();

		strcpy(dBuf.szTable, PGGetTableName(PG_ACLINESEGMENT));
		strcpy(dBuf.szKey, pBlock->m_ACLineSegmentArray[nLine].szName);
		dBuf.nTable=PG_ACLINESEGMENT;
		dBuf.nRecord=nLine;
		busBuffer.AffectBusDeviceArray.push_back(dBuf);

		pPGNetAnalysis->m_AffectBusArray.push_back(busBuffer);
		pPGNetAnalysis->AffectBus_Traverse(pBlock, nSrcNode);

		for (nAffect=0; nAffect<(int)pPGNetAnalysis->m_AffectBusArray.size(); nAffect++)
		{
			for (i=0; i<(int)pPGNetAnalysis->m_AffectBusArray[nAffect].nAffectBusOutageArray.size(); i++)
			{
				fprintf(fp, "%s.%s.%s, ", 
					pBlock->m_BusbarSectionArray[pPGNetAnalysis->m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szSub, 
					FormatVoltageLevelName(pBlock->m_BusbarSectionArray[pPGNetAnalysis->m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szVolt), 
					pBlock->m_BusbarSectionArray[pPGNetAnalysis->m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szName);
			}
		}
		fprintf(fp, "\n");
	}

	fflush(fp);
	fclose(fp);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    LineAffectBus����ʱ%d����\n", nDur);
}

void FormBuslinkBreaker(tagPGBlock* pBlock, const char* lpszFileName)
{
	register int	i;
	int		nRow;

	FILE*	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	PGMemDBType(pBlock);

	nRow=1;
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
	{
		if (pBlock->m_BreakerArray[i].nInnerType == PGEnum_BreakerInnerType_BrBus || pBlock->m_BreakerArray[i].nInnerType == PGEnum_BreakerInnerType_BrBypass || pBlock->m_BreakerArray[i].nInnerType == PGEnum_BreakerInnerType_BrBusBypass)
		{
			fprintf(fp, "%d, %s.%s.%s, %d\n", nRow++, pBlock->m_BreakerArray[i].szSub, FormatVoltageLevelName(pBlock->m_BreakerArray[i].szVolt), pBlock->m_BreakerArray[i].szName, pBlock->m_BreakerArray[i].nStatus);
		}
	}

	fflush(fp);
	fclose(fp);
}


void FormBus2LineRelation(tagPGBlock* pBlock, const char* lpszFileName)
{
	register int	i;
	int		nSub, nVolt, nBus, nNode, nRow;
	int		nNodeNum, nNodeArray[1000];

	FILE*	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	std::vector<unsigned char>	bBusProcArray;
	std::vector<int>	nBusArray;
	std::vector<int>	nLineArray;

	bBusProcArray.resize(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	for (i=0; i<(int)bBusProcArray.size(); i++)
		bBusProcArray[i]=0;

	fprintf(fp, "[SubstationBusbarSection2Line-start]\n");
	nRow=1;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nBus=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nBus<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nBus++)
			{
				if (pBlock->m_BusbarSectionArray[nBus].bBypass != 0)
					continue;

				if (bBusProcArray[nBus])
					continue;
				bBusProcArray[nBus]=1;
				if (pBlock->m_BusbarSectionArray[nBus].nNode < 0)
					continue;

				//PGTraverseVolt(pBlock, pBlock->m_BusbarSectionArray[nBus].iRnd, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				PGTraverseSub(pBlock, pBlock->m_BusbarSectionArray[nBus].nNode, Y_CheckStatus, nNodeNum, nNodeArray);

				nBusArray.clear();
				nLineArray.clear();
				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					if (pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr >= 0)
					{
						if (pBlock->m_BusbarSectionArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr].bBypass == 0)
							nBusArray.push_back(pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr);
					}
					for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
					{
						nLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment);
					}
				}

				for (i=0; i<(int)nBusArray.size(); i++)
					bBusProcArray[nBusArray[i]]=1;

				fprintf(fp, "%d, %s, ", nRow++, pBlock->m_SubstationArray[nSub].szName);

				fprintf(fp, "%d, ", nBusArray.size());
				for (i=0; i<(int)nBusArray.size(); i++)
					fprintf(fp, "%s.%s.%s, ", pBlock->m_BusbarSectionArray[nBusArray[i]].szSub, 
						FormatVoltageLevelName(pBlock->m_BusbarSectionArray[nBusArray[i]].szVolt), 
						pBlock->m_BusbarSectionArray[nBusArray[i]].szName);
				fprintf(fp, "%d, ", nLineArray.size());
				for (i=0; i<(int)nLineArray.size(); i++)
					fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nLineArray[i]].szName);

				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "[SubstationBusbarSection2Line-end]\n");

	for (i=0; i<(int)bBusProcArray.size(); i++)
		bBusProcArray[i]=0;
	fprintf(fp, "[VoltageLevelBusbarSection2Line-start]\n");
	nRow=0;
	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nBus=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nBus<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nBus++)
			{
				if (pBlock->m_BusbarSectionArray[nBus].bBypass != 0)
					continue;

				if (bBusProcArray[nBus])
					continue;
				bBusProcArray[nBus]=1;
				if (pBlock->m_BusbarSectionArray[nBus].nNode < 0)
					continue;

				PGTraverseVolt(pBlock, pBlock->m_BusbarSectionArray[nBus].nNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				//PGTraverseSub(pBlock, pBlock->m_BusbarSectionArray[nBus].iRnd, Y_CheckStatus, nNodeNum, nNodeArray);

				nBusArray.clear();
				nLineArray.clear();
				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					if (pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr >= 0)
					{
						if (pBlock->m_BusbarSectionArray[pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr].bBypass == 0)
							nBusArray.push_back(pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr);
					}
					for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
					{
						nLineArray.push_back(pBlock->m_EdgeACLineSegmentArray[i].nACLineSegment);
					}
				}

				for (i=0; i<(int)nBusArray.size(); i++)
					bBusProcArray[nBusArray[i]]=1;

				fprintf(fp, "%d, %s, %s, ", nRow++, pBlock->m_SubstationArray[nSub].szName, FormatVoltageLevelName(pBlock->m_VoltageLevelArray[nVolt].szName));

				fprintf(fp, "%d, ", nBusArray.size());
				for (i=0; i<(int)nBusArray.size(); i++)
					fprintf(fp, "%s.%s.%s, ", pBlock->m_BusbarSectionArray[nBusArray[i]].szSub, 
					FormatVoltageLevelName(pBlock->m_BusbarSectionArray[nBusArray[i]].szVolt), 
					pBlock->m_BusbarSectionArray[nBusArray[i]].szName);
				fprintf(fp, "%d, ", nLineArray.size());
				for (i=0; i<(int)nLineArray.size(); i++)
					fprintf(fp, "%s, ", pBlock->m_ACLineSegmentArray[nLineArray[i]].szName);

				fprintf(fp, "\n");
			}
		}
	}
	fprintf(fp, "[VoltageLevelBusbarSection2Line-end]\n");

	fflush(fp);
	fclose(fp);
}


int	PGNetAnalysisModule(tagPGBlock* pBlock, CPGNetAnalysis* pPGNetAnalysis, int argc, char** argv)
{
	int		nArg;
	char	szFlag[260], szDestDir[260], szFileName[260], szOutputFileName[260];
	int	nYear, nMonth, nDay, nHour, nMinute;

	int		nRouterBusbarsectionNum;
	int		nBuslinkBreakerNum;
	std::vector<std::string>	strFilterSubontrolAreaArray;
	std::vector<std::string>	strRouterBusbarsectionArray;
	std::vector<std::string>	strBuslinkBreakerArray;
	std::vector<std::string>	strAffectLineArray;

	nYear=nMonth=nDay=nHour=nMinute=0;
	strFilterSubontrolAreaArray.clear();
	strRouterBusbarsectionArray.clear();
	strBuslinkBreakerArray.clear();
	strAffectLineArray.clear();

	nArg=1;
	if (argc > nArg)	{	strcpy(szFlag, argv[nArg++]);		Log("Flag=%s\n", szFlag);		}	else	return 0;
	if (stricmp(szFlag, "BaseTxt") == 0 || stricmp(szFlag, "BusRouter") == 0 || stricmp(szFlag, "Status") == 0)
	{
		if (argc > nArg)	{	strcpy(szDestDir, argv[nArg++]);	Log("DestDir=%s\n", szDestDir);	}	else	return 0;
		if (argc > nArg)	{	nYear=atoi(argv[nArg++]);		Log("Year=%d\n", nYear);			}	else	return 0;
		if (argc > nArg)	{	nMonth=atoi(argv[nArg++]);		Log("Month=%d\n", nYear);		}	else	return 0;
		if (argc > nArg)	{	nDay=atoi(argv[nArg++]);		Log("Day=%d\n", nYear);			}	else	return 0;
		if (argc > nArg)	{	nHour=atoi(argv[nArg++]);		Log("Hour=%d\n", nYear);			}	else	return 0;
		if (argc > nArg)	{	nMinute=atoi(argv[nArg++]);		Log("Minute=%d\n", nYear);		}	else	return 0;
		if (stricmp(szFlag, "BaseTxt") == 0 || stricmp(szFlag, "Status") == 0)
		{
			while (argc > nArg)
				strFilterSubontrolAreaArray.push_back(argv[nArg++]);
		}
		else
		{
			if (argc > nArg)	{	nRouterBusbarsectionNum=atoi(argv[nArg++]);		Log("RouterBusbarsectionNum=%d\n", nRouterBusbarsectionNum);		}	else	return 0;
			while (argc > nArg && (int)strRouterBusbarsectionArray.size() < nRouterBusbarsectionNum)
				strRouterBusbarsectionArray.push_back(argv[nArg++]);

			if (argc > nArg)	{	nBuslinkBreakerNum=atoi(argv[nArg++]);		Log("BuslinkBreakerNum=%d\n", nBuslinkBreakerNum);		}	else	return 0;
			while (argc > nArg && (int)strBuslinkBreakerArray.size() < nBuslinkBreakerNum)
				strBuslinkBreakerArray.push_back(argv[nArg++]);
		}
	}
	else if (stricmp(szFlag, "LineAffectBus") == 0)
	{
		if (argc > nArg)	{	strcpy(szFileName, argv[nArg++]);	Log("FileName=%s\n", szFileName);	}	else	return 0;
		while (argc > nArg)
			strAffectLineArray.push_back(argv[nArg++]);
	}
	else if (stricmp(szFlag, "FaultAffectBus") == 0)
	{
		if (argc > nArg)	{	strcpy(szFileName, argv[nArg++]);	Log("FileName=%s\n", szFileName);	}	else	return 0;
		if (argc > nArg)	{	strcpy(szOutputFileName, argv[nArg++]);	Log("OutputFileName=%s\n", szOutputFileName);	}	else	return 0;
	}
	else if (stricmp(szFlag, "BuslinkBreaker") == 0 || stricmp(szFlag, "Bus2LineRelation") == 0)
	{
		if (argc > nArg)	{	strcpy(szFileName, argv[nArg++]);	Log("FileName=%s\n", szFileName);	}	else	return 0;
	}
	else
		return 0;

	clock_t	dBeg, dEnd;
	int		nDur;

	dBeg=clock();

	if (STRICMP(szFlag, "BaseTxt") == 0)
	{
		//int nMainLoop=pPGNetAnalysis->PGDecompose(pBlock, m_fMinimalVoltage);
		FormBaseTxt(pBlock, pPGNetAnalysis, szDestDir, nYear, nMonth, nDay, nHour, nMinute, strFilterSubontrolAreaArray);
	}
	else if (STRICMP(szFlag, "BusRouter") == 0)
	{
		FormBusRouter(pBlock, pPGNetAnalysis, szDestDir, nYear, nMonth, nDay, nHour, nMinute, strRouterBusbarsectionArray, strBuslinkBreakerArray);
	}
	else if (STRICMP(szFlag, "LineAffectBus") == 0)
	{
		FormLineAffectBus(pBlock, pPGNetAnalysis, szFileName, strAffectLineArray);
	}
	else if (STRICMP(szFlag, "FaultAffectBus") == 0)
	{
		pPGNetAnalysis->ReadFaultDeviceFile(pBlock, szFileName);
		int	nSrcNode=pPGNetAnalysis->AffectBus_ResolveSrcNode(pBlock);
		if (nSrcNode >= 0)
		{
			pPGNetAnalysis->AffectBus_Traverse(pBlock, nSrcNode);
			pPGNetAnalysis->SaveAffectBusFile(pBlock, szOutputFileName);
		}
	}
	else if (STRICMP(szFlag, "Status") == 0)
	{
		FormStatus(pBlock, szDestDir, nYear, nMonth, nDay, nHour, nMinute, strRouterBusbarsectionArray);
	}
	else if (STRICMP(szFlag, "Decompose") == 0)
	{
		pPGNetAnalysis->PGDecompose(pBlock, (float)m_fMinimalVoltage);
	}
	else if (STRICMP(szFlag, "BuslinkBreaker") == 0)
	{
		FormBuslinkBreaker(pBlock, szFileName);
	}
	else if (STRICMP(szFlag, "Bus2LineRelation") == 0)
	{
		FormBus2LineRelation(pBlock, szFileName);
	}
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("������ϣ���ʱ%d����\n", nDur);

	return 1;
}
