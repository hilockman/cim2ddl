#include <Windows.h>
#include <io.h>
#include <float.h>


#include "../../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif
using namespace PGMemDB;

#include "../PGNetAnalysis.h"

tagPGBlock*			g_pBlock;
CPGNetAnalysis*		g_pPGAnalysis;

extern	void	Log(char* pformat, ...);
extern	void	ClearLog();
extern	int		PGNetAnalysisModule(tagPGBlock* pBlock, CPGNetAnalysis* pPGNetAnalysis, int argc, char** argv);

const	double	m_fMinimalVoltage=200;
int main(int argc, char** argv)
{
	if (argc < 3)
		return 0;

	ClearLog();

	g_pBlock=(tagPGBlock*)Init_PGBlock();
	if (!g_pBlock)
		return 0;

	g_pPGAnalysis=new CPGNetAnalysis();
	if (!g_pPGAnalysis)
		return 0;

	PGNetAnalysisModule(g_pBlock, g_pPGAnalysis, argc, argv);

	delete g_pPGAnalysis;

	return 1;
}


static	char*	lpszLogFile="PGNetAnalysisModule.log";
void Log(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	//#ifndef DEBUG
	char	szTempPath[260], szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/%s", szTempPath, lpszLogFile);
	fp=fopen(szFileName, "a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}
	//#endif

	va_end(args);
}

void ClearLog()
{
	char	szTempPath[260], szFileName[260];

	GetTempPath(260, szTempPath);
	sprintf(szFileName, "%s/%s", szTempPath, lpszLogFile);

	FILE* fp=fopen(szFileName, "w");
	fflush(fp);
	fclose(fp);
}
