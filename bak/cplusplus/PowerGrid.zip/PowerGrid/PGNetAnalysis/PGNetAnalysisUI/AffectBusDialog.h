#pragma once


// CAffectBusDialog �Ի���

class CAffectBusDialog : public CDialog
{
	DECLARE_DYNAMIC(CAffectBusDialog)

public:
	CAffectBusDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CAffectBusDialog();

// �Ի�������
	enum { IDD = IDD_AFFECTBUS_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedReadFaultdev();
	afx_msg void OnBnClickedAnalysisAffectbus();
	afx_msg void OnBnClickedOutputAffectbus();
	DECLARE_MESSAGE_MAP()
public:

private:
	void	RefreshFaultDevList();
	void	RefreshAffectBusList();
};
