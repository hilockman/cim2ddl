
// PGNetAnalysisDlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"
//#include "../../DFMeasurement/DFMeasurement.h"
#include "../../../Common/MFCControls/MFCListCtrlEx.h"

// CPGNetAnalysisDlg �Ի���
class CPGNetAnalysisDlg : public CDialog
{
// ����
public:
	CPGNetAnalysisDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PGNETANALYSIS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedFormRing();
	afx_msg void OnBnClickedFormRadiant();
	afx_msg void OnBnClickedRefreshButton();
	afx_msg void OnBnClickedTraceButton();
	afx_msg void OnCbnSelchangeDivfilterCombo();
	afx_msg void OnCbnSelchangeSubfilterCombo();
	afx_msg void OnBnClickedGetRtdata();
	afx_msg void OnBnClickedShowBusResult();
	afx_msg void OnBnClickedFormSamebreakerLine();
	afx_msg void OnBnClickedFormTline();
	afx_msg void OnBnClickedFormTxt();
	afx_msg void OnBnClickedHub();
	afx_msg void OnBnClickedLineBusRelation();
	afx_msg void OnBnClickedDevaffectbusAnalysis();
	afx_msg void OnBnClickedBuslinkBreaker();
	afx_msg void OnBnClicked32volt();
	afx_msg void OnBnClickedBuspassBreaker();
	afx_msg void OnBnClickedBypassBreaker();
	afx_msg void OnBnClickedPangbus();
	DECLARE_MESSAGE_MAP()
private:
	char	m_szFilterSub[MDB_CHARLEN];

private:
	CMFCTabCtrl			m_wndTab;
	CMFCListCtrlEx		m_wndListRingLine, m_wndListRingTran, m_wndListBoundBus;
	CMFCListCtrlEx		m_wndListRadiant;
	CMFCListCtrlEx		m_wndListSameBreakerLine;
	CMFCListCtrlEx		m_wndListTLine;
	CMFCListCtrlEx		m_wndList32Volt, m_wndListBybus, m_wndListBreaker;

	CListBox			m_wndListHubSub;
	CTreeCtrl			m_wndTreeCtrl;

private:
	void	RefreshRingedLineList(const int nMainLoop);
	void	RefreshRingedTranList(const int nMainLoop);
	void	RefreshRingedBoundBusList(const int nMainLoop);
	void	RefreshRadiantList();
	void	RefreshLowVBusList(tagPGBlock* pBlock);

	void	RefreshSameBreakerLineList();
	void	RefreshTLineList();
	void	RefreshPivotSubList();
	void	Refresh32VoltList();
	void	RefreshBybusList();
	void	RefreshBreakerList(const int nBreakerType);

	void	FillTrace(HTREEITEM hItem);
	void	FillTraceByDeep(const int nIniDev, const int nIniDeep, HTREEITEM hDeep, const unsigned char bShowBusResult=1);

private:
	//CDFMeasurement	m_DFMeasurement;
public:
};
