//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PGNetAnalysis.rc
//
#define IDD_PGNETANALYSIS_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDD_HUBSTATION_DIALOG           129
#define IDD_AFFECTBUS_DIALOG            130
#define IDC_MINIMAL_VOLTAGE             1000
#define IDC_FORM_RING                   1001
#define IDC_RINGTAB                     1002
#define IDC_FORM_RADIANT                1003
#define IDC_GET_RTDATA                  1004
#define IDC_MESG                        1005
#define IDC_CHECK_BREAKER_STATUS        1006
#define IDC_TRACE_TREE                  1007
#define IDC_CHECK_STATUS2               1008
#define IDC_CHECK_DISCONNECTOR_STATUS   1008
#define IDC_SHOW_BUS_RESULT             1009
#define IDC_TRACE_BUTTON                1010
#define IDC_LOWVBUS_LIST                1011
#define IDC_SUBFILTER_COMBO             1012
#define IDC_REFRESH_BUTTON              1013
#define IDC_DIVFILTER_COMBO             1014
#define IDC_FORM_SAMEBREAKER_LINE       1015
#define IDC_FORM_TLINE                  1016
#define IDC_FORM_TLINE2                 1017
#define IDC_FORM_TXT                    1017
#define IDC_HUB                         1018
#define IDC_ALLSUB_LIST                 1019
#define IDC_BUSLINK_BREAKER             1019
#define IDC_HUBSUB_LIST                 1020
#define IDC_32VOLT                      1020
#define IDC_ADD_BUTTON                  1021
#define IDC_BUSPASS_BREAKER             1021
#define IDC_DEL_BUTTON                  1022
#define IDC_LINE_BUS_RELATION           1022
#define IDC_FAULTDEV_LIST               1023
#define IDC_DEVAFFECTBUS_ANALYSIS       1023
#define IDC_AFFECTBUS_LIST              1024
#define IDC_BYPASS_BREAKER              1024
#define IDC_READ_FAULTDEV               1025
#define IDC_32VOLT2                     1025
#define IDC_PANGBUS                     1025
#define IDC_ANALYSIS_AFFECTBUS          1026
#define IDC_OUTPUT_AFFECTBUS            1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
