// AffectBusDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGNetAnalysisApp.h"
#include "AffectBusDialog.h"


// CAffectBusDialog �Ի���

static	char*	lpszFaultDevColumn[]=
{
	"���", 
	"���", 
	"�豸����", 
	"�豸����", 
	"PG��", 
	"PG��¼", 
};

static	char*	lpszAffectBusColumn[]=
{
	"���", 
	"���", 
	"ĸ�߳�վ", 
	"ĸ�ߵ�ѹ", 
	"ĸ������", 
};

IMPLEMENT_DYNAMIC(CAffectBusDialog, CDialog)

CAffectBusDialog::CAffectBusDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CAffectBusDialog::IDD, pParent)
{

}

CAffectBusDialog::~CAffectBusDialog()
{
}

void CAffectBusDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAffectBusDialog, CDialog)
	ON_BN_CLICKED(IDC_READ_FAULTDEV, &CAffectBusDialog::OnBnClickedReadFaultdev)
	ON_BN_CLICKED(IDC_ANALYSIS_AFFECTBUS, &CAffectBusDialog::OnBnClickedAnalysisAffectbus)
	ON_BN_CLICKED(IDC_OUTPUT_AFFECTBUS, &CAffectBusDialog::OnBnClickedOutputAffectbus)
END_MESSAGE_MAP()


// CAffectBusDialog ��Ϣ��������

BOOL CAffectBusDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int		nColumn;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FAULTDEV_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (nColumn=0; nColumn<sizeof(lpszFaultDevColumn)/sizeof(char*); nColumn++)
		pListCtrl->InsertColumn(nColumn, lpszFaultDevColumn[nColumn],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_AFFECTBUS_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (nColumn=0; nColumn<sizeof(lpszAffectBusColumn)/sizeof(char*); nColumn++)
		pListCtrl->InsertColumn(nColumn, lpszAffectBusColumn[nColumn],	LVCFMT_LEFT,	100);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CAffectBusDialog::OnBnClickedReadFaultdev()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.txt)|*.txt;*.TXT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PGAnalysis.ReadFaultDeviceFile(g_pBlock, dlg.GetPathName());

	RefreshFaultDevList();
}

void CAffectBusDialog::OnBnClickedAnalysisAffectbus()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	int	nSrcNode=g_PGAnalysis.AffectBus_ResolveSrcNode(g_pBlock);

	g_PGAnalysis.AffectBus_Traverse(g_pBlock, nSrcNode);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    AffectBus����ʱ%d����\n", nDur);

	RefreshAffectBusList();
}

void CAffectBusDialog::OnBnClickedOutputAffectbus()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.txt)|*.txt;*.TXT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PGAnalysis.SaveAffectBusFile(g_pBlock, dlg.GetPathName());
}

void	CAffectBusDialog::RefreshFaultDevList()
{
	register int	i;
	int		nAffect;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FAULTDEV_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nAffect=0; nAffect<(int)g_PGAnalysis.m_AffectBusArray.size(); nAffect++)
	{
		for (i=0; i<(int)g_PGAnalysis.m_AffectBusArray[nAffect].AffectBusDeviceArray.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf, "%d", nAffect+1);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PGAnalysis.m_AffectBusArray[nAffect].AffectBusDeviceArray[i].szTable);
			pListCtrl->SetItemText(nRow, nCol++, g_PGAnalysis.m_AffectBusArray[nAffect].AffectBusDeviceArray[i].szKey);
			sprintf(szBuf, "%d", g_PGAnalysis.m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nTable);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%d", g_PGAnalysis.m_AffectBusArray[nAffect].AffectBusDeviceArray[i].nRecord);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszFaultDevColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CAffectBusDialog::RefreshAffectBusList()
{
	register int	i;
	int		nAffect;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_AFFECTBUS_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nAffect=0; nAffect<(int)g_PGAnalysis.m_AffectBusArray.size(); nAffect++)
	{
		for (i=0; i<(int)g_PGAnalysis.m_AffectBusArray[nAffect].nAffectBusOutageArray.size(); i++)
		{
			sprintf(szBuf, "%d", nRow+1);	pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

			nCol=1;
			sprintf(szBuf, "%d", nAffect+1);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szSub);
			pListCtrl->SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_AffectBusArray[nAffect].nAffectBusOutageArray[i]].szName);

			nRow++;
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszAffectBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}
