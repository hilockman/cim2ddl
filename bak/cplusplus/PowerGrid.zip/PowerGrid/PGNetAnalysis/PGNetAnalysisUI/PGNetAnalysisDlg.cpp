
// PGNetAnalysisDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGNetAnalysisApp.h"
#include "PGNetAnalysisDlg.h"
#include "HubSubConfigDialog.h"

#include "AffectBusDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPGNetAnalysisDlg �Ի���


extern	int	StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);


CPGNetAnalysisDlg::CPGNetAnalysisDlg(CWnd* pParent /*=NULL*/)
: CDialog(CPGNetAnalysisDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPGNetAnalysisDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TRACE_TREE, m_wndTreeCtrl);
}

BEGIN_MESSAGE_MAP(CPGNetAnalysisDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_FORM_RING, &CPGNetAnalysisDlg::OnBnClickedFormRing)
	ON_BN_CLICKED(IDC_FORM_RADIANT, &CPGNetAnalysisDlg::OnBnClickedFormRadiant)
	ON_BN_CLICKED(IDC_REFRESH_BUTTON, &CPGNetAnalysisDlg::OnBnClickedRefreshButton)
	ON_BN_CLICKED(IDC_TRACE_BUTTON, &CPGNetAnalysisDlg::OnBnClickedTraceButton)
	ON_CBN_SELCHANGE(IDC_DIVFILTER_COMBO, &CPGNetAnalysisDlg::OnCbnSelchangeDivfilterCombo)
	ON_CBN_SELCHANGE(IDC_SUBFILTER_COMBO, &CPGNetAnalysisDlg::OnCbnSelchangeSubfilterCombo)
	ON_BN_CLICKED(IDC_GET_RTDATA, &CPGNetAnalysisDlg::OnBnClickedGetRtdata)
	ON_BN_CLICKED(IDC_SHOW_BUS_RESULT, &CPGNetAnalysisDlg::OnBnClickedShowBusResult)
	ON_BN_CLICKED(IDC_FORM_SAMEBREAKER_LINE, &CPGNetAnalysisDlg::OnBnClickedFormSamebreakerLine)
	ON_BN_CLICKED(IDC_FORM_TLINE, &CPGNetAnalysisDlg::OnBnClickedFormTline)
	ON_BN_CLICKED(IDC_FORM_TXT, &CPGNetAnalysisDlg::OnBnClickedFormTxt)
	ON_BN_CLICKED(IDC_HUB, &CPGNetAnalysisDlg::OnBnClickedHub)
	ON_BN_CLICKED(IDC_LINE_BUS_RELATION, &CPGNetAnalysisDlg::OnBnClickedLineBusRelation)
	ON_BN_CLICKED(IDC_DEVAFFECTBUS_ANALYSIS, &CPGNetAnalysisDlg::OnBnClickedDevaffectbusAnalysis)
	ON_BN_CLICKED(IDC_BUSLINK_BREAKER, &CPGNetAnalysisDlg::OnBnClickedBuslinkBreaker)
	ON_BN_CLICKED(IDC_32VOLT, &CPGNetAnalysisDlg::OnBnClicked32volt)
	ON_BN_CLICKED(IDC_BUSPASS_BREAKER, &CPGNetAnalysisDlg::OnBnClickedBuspassBreaker)
	ON_BN_CLICKED(IDC_BYPASS_BREAKER, &CPGNetAnalysisDlg::OnBnClickedBypassBreaker)
	ON_BN_CLICKED(IDC_PANGBUS, &CPGNetAnalysisDlg::OnBnClickedPangbus)
END_MESSAGE_MAP()


// CPGNetAnalysisDlg ��Ϣ��������

static	char*	lpszRingLine[]=
{
	"���", 
	"��վ", 
	"�ճ�վ", 
	"��ѹ�ȼ�", 
	"����", 
	"��·��", 
};

static	char*	lpszRingTran[]=
{
	"���", 
	"��վ", 
	"���ѹ�ȼ�", 
	"���ѹ�ȼ�", 
	"����", 
	"��·��", 
};

static	char*	lpszBoundBus[]=
{
	"���", 
	"��վ", 
	"��ѹ�ȼ�", 
	"����", 
	"��·��", 
};

static	char*	lpszRadiant[]=
{
	"���", 
	"��Դ/����ĸ��", 
	"�����豸", 
};

static	char*	lpszSameBreakerLine[]=
{
	"���", 
	"��վ", 
	"��ѹ�ȼ�", 
	"��·��", 
	"��·", 
	"��·", 
	"��·", 
	"��·", 
	"��·", 
};

static	char*	lpszTLine[]=
{
	"���", 
	"��ѹ�ȼ�", 
	"��·����վ", 
	"��·����վ", 
	"��·����վ", 
	"��·����վ", 
	"��·����վ", 
	"��·����վ", 
	"��·����վ", 
	"��·����վ", 
};

static	char*	lpszBreaker[]=
{
	"���", 
	"��վ", 
	"��ѹ�ȼ�", 
	"����", 
	"��·������", 
};

static	char*	lpsz32Volt[]=
{
	"���", 
	"��վ", 
	"��ѹ�ȼ�", 
};

static	char*	lpszBybus[]=
{
	"���", 
	"��վ", 
	"��ѹ�ȼ�", 
	"��ѹĸ��", 
};

BOOL CPGNetAnalysisDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	int		nColumn;
	CRect	rectBuf;

	GetDlgItem(IDC_RINGTAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListRingLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 11))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRingLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRingLine.SetExtendedStyle(m_wndListRingLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRingLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRingLine)/sizeof(char*); nColumn++)
		m_wndListRingLine.InsertColumn(nColumn, lpszRingLine[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListRingTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 12))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRingTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRingTran.SetExtendedStyle(m_wndListRingTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRingTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRingTran)/sizeof(char*); nColumn++)
		m_wndListRingTran.InsertColumn(nColumn, lpszRingTran[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBoundBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 13))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBoundBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBoundBus.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBoundBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszBoundBus)/sizeof(char*); nColumn++)
		m_wndListBoundBus.InsertColumn(nColumn, lpszBoundBus[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListRadiant.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 21))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListRadiant.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListRadiant.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListRadiant.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszRadiant)/sizeof(char*); nColumn++)
		m_wndListBoundBus.InsertColumn(nColumn, lpszRadiant[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListSameBreakerLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 22))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListSameBreakerLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListSameBreakerLine.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListSameBreakerLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszSameBreakerLine)/sizeof(char*); nColumn++)
		m_wndListSameBreakerLine.InsertColumn(nColumn, lpszSameBreakerLine[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListTLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 23))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListTLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListTLine.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListTLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszTLine)/sizeof(char*); nColumn++)
		m_wndListTLine.InsertColumn(nColumn, lpszTLine[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListHubSub.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, 24))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListHubSub.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	if (!m_wndList32Volt.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, 24))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndList32Volt.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndList32Volt.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndList32Volt.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpsz32Volt)/sizeof(char*); nColumn++)
		m_wndList32Volt.InsertColumn(nColumn, lpsz32Volt[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBybus.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, 24))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBybus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBybus.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBybus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszBybus)/sizeof(char*); nColumn++)
		m_wndListBybus.InsertColumn(nColumn, lpszBybus[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBreaker.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, 24))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBreaker.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBreaker.SetExtendedStyle(m_wndListBoundBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBreaker.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszBreaker)/sizeof(char*); nColumn++)
		m_wndListBreaker.InsertColumn(nColumn, lpszBreaker[nColumn],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndListRingLine, _T("������·"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListRingTran, _T("������ѹ��"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListHubSub, _T("��Ŧ���վ"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListBoundBus, _T("�߽�ĸ��"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListRadiant, _T("��������"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListSameBreakerLine, _T("ͬ��·����·"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListTLine, _T("T����·"), -1, FALSE);
	m_wndTab.AddTab (&m_wndList32Volt, _T("3/2����"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListBybus, _T("��ĸ"), -1, FALSE);
	m_wndTab.AddTab (&m_wndListBreaker, _T("����"), -1, FALSE);

	GetDlgItem(IDC_MESG)->SetWindowText("");

	char	szBuf[260];
	sprintf(szBuf, "%.1f", g_PGAnalysis.m_fMinimalVoltage);
	GetDlgItem(IDC_MINIMAL_VOLTAGE)->SetWindowText(szBuf);

	OnBnClickedRefreshButton();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CPGNetAnalysisDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CPGNetAnalysisDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CPGNetAnalysisDlg::OnBnClickedFormRing()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char	szVolt[260];
	GetDlgItem(IDC_MINIMAL_VOLTAGE)->GetWindowText(szVolt, 260);
	double	fMinimalVoltage=atof(szVolt);

	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	int nMainLoop=g_PGAnalysis.PGDecompose(g_pBlock, (float)fMinimalVoltage);

	register int	i;
	g_strHubSubArray.clear();
	for (i=0; i<g_pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		if (g_pBlock->m_SubstationArray[i].bHub)
			g_strHubSubArray.push_back(g_pBlock->m_SubstationArray[i].szName);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	char	szBuf[260];
	sprintf(szBuf, "    Decompose����ʱ%d����\n", nDur);
	GetDlgItem(IDC_MESG)->SetWindowText(szBuf);

	if (nMainLoop >= 0)
	{
		RefreshRingedLineList(nMainLoop);
		RefreshRingedTranList(nMainLoop);
		RefreshRingedBoundBusList(nMainLoop);
		RefreshPivotSubList();
	}
}

void CPGNetAnalysisDlg::OnBnClickedFormRadiant()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	//CButton*	pButton=(CButton*)GetDlgItem(IDC_CHECK_BREAKER_STATUS);
	//int		nCheckStatus=pButton->GetCheck();

	g_PGAnalysis.TraverseRadiant(g_pBlock, 1);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	char	szBuf[260];
	sprintf(szBuf, "    TraverseRadiant����ʱ%d����\n", nDur);
	GetDlgItem(IDC_MESG)->SetWindowText(szBuf);

	RefreshRadiantList();
}

void CPGNetAnalysisDlg::RefreshRingedLineList(const int nMainLoop)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListRingLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (g_PGAnalysis.m_bRingedLineArray[i] != nMainLoop)
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListRingLine.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListRingLine.SetItemText(nRow, nCol++, g_pBlock->m_ACLineSegmentArray[i].szSubI);
		m_wndListRingLine.SetItemText(nRow, nCol++, g_pBlock->m_ACLineSegmentArray[i].szSubJ);
		m_wndListRingLine.SetItemText(nRow, nCol++, g_pBlock->m_ACLineSegmentArray[i].szVoltI);
		m_wndListRingLine.SetItemText(nRow, nCol++, g_pBlock->m_ACLineSegmentArray[i].szName);
		sprintf(szBuf, "%d", g_PGAnalysis.m_bRingedLineArray[i]);	m_wndListRingLine.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszRingLine)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRingLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRingLine.GetColumnWidth(nCol);
		m_wndListRingLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRingLine.GetColumnWidth(nCol);

		m_wndListRingLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshRingedTranList(const int nMainLoop)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListRingTran.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (g_PGAnalysis.m_bRingedTranArray[i] != nMainLoop)
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListRingTran.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListRingTran.SetItemText(nRow, nCol++, g_pBlock->m_TransformerWindingArray[i].szSub);
		m_wndListRingTran.SetItemText(nRow, nCol++, g_pBlock->m_TransformerWindingArray[i].szVoltI);
		m_wndListRingTran.SetItemText(nRow, nCol++, g_pBlock->m_TransformerWindingArray[i].szVoltJ);
		m_wndListRingTran.SetItemText(nRow, nCol++, g_pBlock->m_TransformerWindingArray[i].szName);
		sprintf(szBuf, "%d", g_PGAnalysis.m_bRingedTranArray[i]);	m_wndListRingTran.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszRingTran)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRingTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRingTran.GetColumnWidth(nCol);
		m_wndListRingTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRingTran.GetColumnWidth(nCol);

		m_wndListRingTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshRingedBoundBusList(const int nMainLoop)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListBoundBus.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (g_PGAnalysis.m_bRingedBoundBusArray[i] != nMainLoop)
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListBoundBus.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListBoundBus.SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[i].szSub);
		m_wndListBoundBus.SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[i].szVolt);
		m_wndListBoundBus.SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[i].szName);
		sprintf(szBuf, "%d", g_PGAnalysis.m_bRingedBoundBusArray[i]);	m_wndListBoundBus.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBoundBus)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBoundBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBoundBus.GetColumnWidth(nCol);
		m_wndListBoundBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBoundBus.GetColumnWidth(nCol);

		m_wndListBoundBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshTLineList()
{
	register int	i, j;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListTLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PGAnalysis.m_PsedoTLineArray.size(); i++)
	{
		if (g_PGAnalysis.m_PsedoTLineArray.empty())
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListTLine.InsertItem(nRow, szBuf);		m_wndListTLine.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListTLine.SetItemText(nRow, nCol++, g_pBlock->m_EdgeACLineSegmentArray[g_PGAnalysis.m_PsedoTLineArray[i].nLineArray[0]].szVolt);
		for (j=0; j<(int)g_PGAnalysis.m_PsedoTLineArray[i].nLineArray.size(); j++)
		{
			sprintf(szBuf, "%s(%s)", g_pBlock->m_EdgeACLineSegmentArray[g_PGAnalysis.m_PsedoTLineArray[i].nLineArray[j]].szName, 
				g_pBlock->m_EdgeACLineSegmentArray[g_PGAnalysis.m_PsedoTLineArray[i].nLineArray[j]].szSub);
			m_wndListTLine.SetItemText(nRow, nCol++, szBuf);
		}
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszTLine)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListTLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListTLine.GetColumnWidth(nCol);
		m_wndListTLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListTLine.GetColumnWidth(nCol);

		m_wndListTLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshBreakerList(const int nBreakerType)
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListBreaker.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pBlock->m_nRecordNum[PG_BREAKER]; i++)
	{
		if (g_pBlock->m_BreakerArray[i].nInnerType != nBreakerType)
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListBreaker.InsertItem(nRow, szBuf);		m_wndListBreaker.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListBreaker.SetItemText(nRow, nCol++, g_pBlock->m_BreakerArray[i].szSub);
		m_wndListBreaker.SetItemText(nRow, nCol++, g_pBlock->m_BreakerArray[i].szVolt);
		m_wndListBreaker.SetItemText(nRow, nCol++, g_pBlock->m_BreakerArray[i].szName);
		sprintf(szBuf, "%d", g_pBlock->m_BreakerArray[i].nInnerType);	m_wndListBreaker.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBreaker)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBreaker.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBreaker.GetColumnWidth(nCol);
		m_wndListBreaker.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBreaker.GetColumnWidth(nCol);

		m_wndListBreaker.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::Refresh32VoltList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndList32Volt.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pBlock->m_nRecordNum[PG_VOLTAGELEVEL]; i++)
	{
		if (!PGIsVolt32(g_pBlock, i))
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndList32Volt.InsertItem(nRow, szBuf);		m_wndList32Volt.SetItemData(nRow, nRow);

		nCol=1;
		m_wndList32Volt.SetItemText(nRow, nCol++, g_pBlock->m_VoltageLevelArray[i].szSub);
		m_wndList32Volt.SetItemText(nRow, nCol++, g_pBlock->m_VoltageLevelArray[i].szName);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpsz32Volt)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndList32Volt.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndList32Volt.GetColumnWidth(nCol);
		m_wndList32Volt.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndList32Volt.GetColumnWidth(nCol);

		m_wndList32Volt.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshBybusList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListBybus.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (g_pBlock->m_BusbarSectionArray[i].bBypass == 0)
			continue;

		sprintf(szBuf, "%d", nRow+1);	m_wndListBybus.InsertItem(nRow, szBuf);		m_wndListBybus.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListBybus.SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[i].szSub);
		m_wndListBybus.SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[i].szVolt);
		m_wndListBybus.SetItemText(nRow, nCol++, g_pBlock->m_BusbarSectionArray[i].szName);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBybus)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBybus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBybus.GetColumnWidth(nCol);
		m_wndListBybus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBybus.GetColumnWidth(nCol);

		m_wndListBybus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshPivotSubList()
{
	register int	i;
	m_wndListHubSub.ResetContent();
	for (i=0; i<(int)g_strHubSubArray.size(); i++)
	{
		m_wndListHubSub.AddString(g_strHubSubArray[i].c_str());
	}
}

void CPGNetAnalysisDlg::RefreshRadiantList()
{
	register int	i, j;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListRadiant.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PGAnalysis.m_RadiantArray.size(); i++)
	{
		sprintf(szBuf, "%d", i+1);	m_wndListRadiant.InsertItem(nRow, szBuf);	nRow++;
		for (j=0; j<(int)g_PGAnalysis.m_RadiantArray[i].nSourceBusArray.size(); j++)
		{
			m_wndListRadiant.InsertItem(nRow, "");
			nCol=1;
			sprintf(szBuf, "%s.%s.%s", 
				g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_RadiantArray[i].nSourceBusArray[j]].szSub, 
				g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_RadiantArray[i].nSourceBusArray[j]].szVolt, 
				g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_RadiantArray[i].nSourceBusArray[j]].szName);
			m_wndListRadiant.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}

		for (j=0; j<(int)g_PGAnalysis.m_RadiantArray[i].nRadiantLineArray.size(); j++)
		{
			m_wndListRadiant.InsertItem(nRow, "");
			nCol=2;
			sprintf(szBuf, "%s(%s <-> %s)", 
				g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_RadiantArray[i].nRadiantLineArray[j]].szName, 
				g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_RadiantArray[i].nRadiantLineArray[j]].szSubI, 
				g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_RadiantArray[i].nRadiantLineArray[j]].szSubJ);
			m_wndListRadiant.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}

		for (j=0; j<(int)g_PGAnalysis.m_RadiantArray[i].nRadiantTranArray.size(); j++)
		{
			m_wndListRadiant.InsertItem(nRow, "");
			nCol=2;
			sprintf(szBuf, "%s.%s(%s <-> %s)", 
				g_pBlock->m_TransformerWindingArray[g_PGAnalysis.m_RadiantArray[i].nRadiantTranArray[j]].szSub, 
				g_pBlock->m_TransformerWindingArray[g_PGAnalysis.m_RadiantArray[i].nRadiantTranArray[j]].szName, 
				g_pBlock->m_TransformerWindingArray[g_PGAnalysis.m_RadiantArray[i].nRadiantTranArray[j]].szVoltI, 
				g_pBlock->m_TransformerWindingArray[g_PGAnalysis.m_RadiantArray[i].nRadiantTranArray[j]].szVoltJ);
			m_wndListRadiant.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}

		for (j=0; j<(int)g_PGAnalysis.m_RadiantArray[i].nLoadBusArray.size(); j++)
		{
			m_wndListRadiant.InsertItem(nRow, "");
			nCol=1;
			sprintf(szBuf, "%s.%s.%s", 
				g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_RadiantArray[i].nLoadBusArray[j]].szSub, 
				g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_RadiantArray[i].nLoadBusArray[j]].szVolt, 
				g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_RadiantArray[i].nLoadBusArray[j]].szName);
			m_wndListRadiant.SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszRadiant)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListRadiant.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListRadiant.GetColumnWidth(nCol);
		m_wndListRadiant.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListRadiant.GetColumnWidth(nCol);

		m_wndListRadiant.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::RefreshSameBreakerLineList()
{
	register int	i, j;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListSameBreakerLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PGAnalysis.m_SameBreakerLineArray.size(); i++)
	{
		sprintf(szBuf, "%d", i+1);	m_wndListSameBreakerLine.InsertItem(nRow, szBuf);	m_wndListSameBreakerLine.SetItemData(nRow, nRow);
		nCol=1;

		TRACE("Breaker=%d\n", g_PGAnalysis.m_SameBreakerLineArray[i].nBreaker);
		m_wndListSameBreakerLine.SetItemText(nRow, nCol++, g_pBlock->m_BreakerArray[g_PGAnalysis.m_SameBreakerLineArray[i].nBreaker].szSub);
		m_wndListSameBreakerLine.SetItemText(nRow, nCol++, g_pBlock->m_BreakerArray[g_PGAnalysis.m_SameBreakerLineArray[i].nBreaker].szVolt);
		m_wndListSameBreakerLine.SetItemText(nRow, nCol++, g_pBlock->m_BreakerArray[g_PGAnalysis.m_SameBreakerLineArray[i].nBreaker].szName);

		for (j=0; j<(int)g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray.size(); j++)
		{
			memset(szBuf, 0, 260);
			if (strcmp(g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szSubI, g_pBlock->m_BreakerArray[g_PGAnalysis.m_SameBreakerLineArray[i].nBreaker].szSub) == 0)
			{
				sprintf(szBuf, "%s (%s <-> %s)", g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szName, 
					g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szSubI, g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szSubJ);
			}
			else
			{
				sprintf(szBuf, "%s (%s <-> %s)", g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szName, 
					g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szSubJ, g_pBlock->m_ACLineSegmentArray[g_PGAnalysis.m_SameBreakerLineArray[i].nLineArray[j]].szSubI);
			}
			m_wndListSameBreakerLine.SetItemText(nRow, nCol++, szBuf);
		}

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszSameBreakerLine)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListSameBreakerLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListSameBreakerLine.GetColumnWidth(nCol);
		m_wndListSameBreakerLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListSameBreakerLine.GetColumnWidth(nCol);

		m_wndListSameBreakerLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGNetAnalysisDlg::OnBnClickedRefreshButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CComboBox*	pCombo;
	pCombo=(CComboBox*)GetDlgItem(IDC_DIVFILTER_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");

	for (i=0; i<g_pBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pCombo->AddString(g_pBlock->m_SubcontrolAreaArray[i].szName);
	pCombo->SetCurSel(0);

	RefreshLowVBusList(g_pBlock);

	// 	pCombo=(CComboBox*)GetDlgItem(IDC_SUBFILTER_COMBO);
	// 	pCombo->ResetContent();
	// 	pCombo->AddString("");
}

void CPGNetAnalysisDlg::OnCbnSelchangeDivfilterCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CComboBox*	pCombo;
	char	szSubcontrolArea[MDB_CHARLEN];

	memset(m_szFilterSub, 0, MDB_CHARLEN);
	pCombo=(CComboBox*)GetDlgItem(IDC_DIVFILTER_COMBO);
	int	nDiv=pCombo->GetCurSel();
	if (nDiv == CB_ERR)
		return;
	pCombo->GetLBText(nDiv, szSubcontrolArea);

	pCombo=(CComboBox*)GetDlgItem(IDC_SUBFILTER_COMBO);
	pCombo->ResetContent();
	if (strlen(szSubcontrolArea) <= 0)
	{
		pCombo->AddString("");
		for (i=0; i<g_pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
			pCombo->AddString(g_pBlock->m_SubstationArray[i].szName);
	}
	else
	{
		for (i=0; i<g_pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(szSubcontrolArea, g_pBlock->m_SubstationArray[i].szSubcontrolArea) != 0)
				continue;
			pCombo->AddString(g_pBlock->m_SubstationArray[i].szName);
		}
	}
	pCombo->SetCurSel(0);
	RefreshLowVBusList(g_pBlock);
}

void CPGNetAnalysisDlg::OnCbnSelchangeSubfilterCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshLowVBusList(g_pBlock);
}

void CPGNetAnalysisDlg::RefreshLowVBusList(tagPGBlock* pBlock)
{
	register int	i;
	int		nSub, nVolt;
	char	szSub[MDB_CHARLEN_SHORT], szDev[MDB_CHARLEN_LONG];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_LOWVBUS_LIST);
	pListBox->ResetContent();

	memset(szSub, 0, MDB_CHARLEN_SHORT);
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_SUBFILTER_COMBO);
	nSub=pCombo->GetCurSel();
	if (nSub != CB_ERR)
		pCombo->GetLBText(nSub, szSub);

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 50)
				continue;

			for (i=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; i<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; i++)
			{
				if (pBlock->m_BusbarSectionArray[i].nNode < 0)
					continue;
				// 				if (pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[i].iRnd].nIsland <= 0)
				// 					continue;

				if (strlen(szSub) > 0)
				{
					if (strcmp(pBlock->m_BusbarSectionArray[i].szSub, szSub) != 0)
						continue;
				}

				sprintf(szDev, "%s.%s.%s", pBlock->m_BusbarSectionArray[i].szSub, pBlock->m_BusbarSectionArray[i].szVolt, pBlock->m_BusbarSectionArray[i].szName);
				pListBox->AddString(szDev);
			}
		}
	}
}

void CPGNetAnalysisDlg::OnBnClickedGetRtdata()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt *.dat)|*.txt;*.TXT;*.dat;*.DAT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("���ı��ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg, dEnd;
	int		nDur;

	unsigned char	bLowToMid=0;
	char	szBuf[260];
	//bLowToMid=(AfxMessageBox("�Ƿ񽫵�ѹ�ฺ�ɺϲ�����ѹ��", MB_YESNO|MB_SYSTEMMODAL) == IDYES) ? 1 : 0;
	//char	szExec[260];

	// 	dBeg=clock();
	// 	sprintf(szExec, "%s/ReadDFMeasurement %s", g_szRunDir, dlg.GetPathName());
	// 	StartProcess(szExec, g_szRunDir, SW_HIDE);
	// 	dEnd=clock();
	// 	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	// 	PrintMessage("�������ļ���ϣ���ʱ%d����\n", nDur);

// 	dBeg=clock();
// 	m_DFMeasurement.ReadFile(dlg.GetPathName());
// 	dEnd=clock();
// 	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 	sprintf(szBuf, "�������ļ�����ʱ%d����\n", nDur);
// 	GetDlgItem(IDC_MESG)->SetWindowText(szBuf);
// 
// 	dBeg=clock();
// 	m_DFMeasurement.InputPGBlock(g_pBlock, 1, 1, bLowToMid);
// 	dEnd=clock();
// 	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 	sprintf(szBuf, "������⣬��ʱ%d����\n", nDur);
// 	GetDlgItem(IDC_MESG)->SetWindowText(szBuf);
}

void CPGNetAnalysisDlg::OnBnClickedTraceButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	TV_INSERTSTRUCT itemTree;
	HTREEITEM		hItem;
	char			szBus[260], szBuf[260];

	m_wndTreeCtrl.DeleteAllItems();

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_LOWVBUS_LIST);
	int			nBus=pListBox->GetCurSel();
	if (nBus == LB_ERR)
		return;

	pListBox->GetText(nBus, szBus);

	nBus=-1;
	for (i=0; i<g_pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		sprintf(szBuf, "%s.%s.%s", g_pBlock->m_BusbarSectionArray[i].szSub, g_pBlock->m_BusbarSectionArray[i].szVolt, g_pBlock->m_BusbarSectionArray[i].szName);
		if (strcmp(szBus , szBuf) == 0)
		{
			nBus=i;
			break;
		}
	}
	if (nBus < 0)
		return;

	if (g_pBlock->m_BusbarSectionArray[nBus].nNode < 0)
		return;

	itemTree.hParent=TVI_ROOT;
	itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
	itemTree.item.pszText=szBus;
	itemTree.item.cchTextMax=260;
	itemTree.item.lParam=0;
	itemTree.item.state=TVIS_EXPANDED;
	itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
	hItem=m_wndTreeCtrl.InsertItem(&itemTree);

	CButton*	pButton;
	int			nCheckBreakerStatus, nCheckDisconnectorStatus;

	pButton=(CButton*)GetDlgItem(IDC_CHECK_BREAKER_STATUS);
	nCheckBreakerStatus=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_CHECK_DISCONNECTOR_STATUS);
	nCheckDisconnectorStatus=pButton->GetCheck();
	g_PGAnalysis.TraceSource(g_pBlock, nCheckBreakerStatus, nCheckDisconnectorStatus, g_pBlock->m_BusbarSectionArray[nBus].nNode);
	if (!g_PGAnalysis.m_TraceBranArray.empty())
		FillTrace(hItem);
}

void CPGNetAnalysisDlg::FillTrace(HTREEITEM hItem)
{
	int			nDev;
	for (nDev=0; nDev<(int)g_PGAnalysis.m_TraceBranArray.size(); nDev++)
		g_PGAnalysis.m_TraceBranArray[nDev].bTraced=0;

	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOW_BUS_RESULT);
	FillTraceByDeep(0, g_PGAnalysis.m_TraceBranArray[0].nDeep, hItem, pButton->GetCheck());
}

void CPGNetAnalysisDlg::FillTraceByDeep(const int nIniDev, const int nIniDeep, HTREEITEM hDeep, const unsigned char bShowBusResult)
{
	TV_INSERTSTRUCT itemTree;
	register int	i;
	int			nDev, nBran;
	HTREEITEM	hItem;
	char		szBuf[260];

	nBran=g_PGAnalysis.m_TraceBranArray[nIniDev].nBranIndex;

	hItem=hDeep;
	for (nDev=nIniDev; nDev<(int)g_PGAnalysis.m_TraceBranArray.size(); nDev++)
	{
		if (g_PGAnalysis.m_TraceBranArray[nDev].bTraced)
			continue;
		if (g_PGAnalysis.m_TraceBranArray[nDev].nDeep < nIniDeep)
			return;

		if (g_PGAnalysis.m_TraceBranArray[nDev].nDeep == nIniDeep)
		{
			g_PGAnalysis.m_TraceBranArray[nDev].bTraced=1;

			nBran=g_PGAnalysis.m_TraceBranArray[nDev].nBranIndex;
			if (g_PGAnalysis.m_TraceBranArray[nDev].nBranType == PG_ACLINESEGMENT)
			{
				sprintf(szBuf, "%s %s [%s-%s], %s", g_pBlock->m_ACLineSegmentArray[nBran].szVoltI, PGGetTableDesp(g_PGAnalysis.m_TraceBranArray[nDev].nBranType), 
					g_pBlock->m_ConnectivityNodeArray[g_PGAnalysis.m_TraceBranArray[nDev].nFrNode].szSub, g_pBlock->m_ConnectivityNodeArray[g_PGAnalysis.m_TraceBranArray[nDev].nToNode].szSub, g_pBlock->m_ACLineSegmentArray[nBran].szName);
			}
			else
			{
				sprintf(szBuf, "%s %s [%s-%s], %s", g_pBlock->m_PowerTransformerArray[nBran].szSub, PGGetTableDesp(g_PGAnalysis.m_TraceBranArray[nDev].nBranType), 
					g_pBlock->m_ConnectivityNodeArray[g_PGAnalysis.m_TraceBranArray[nDev].nFrNode].szVolt, g_pBlock->m_ConnectivityNodeArray[g_PGAnalysis.m_TraceBranArray[nDev].nToNode].szVolt, 
					g_pBlock->m_PowerTransformerArray[nBran].szName);
			}

			itemTree.hParent=hDeep;
			itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
			itemTree.item.pszText=szBuf;
			itemTree.item.cchTextMax=260;
			itemTree.item.lParam=0;
			itemTree.item.state=TVIS_EXPANDED;
			itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
			hItem=m_wndTreeCtrl.InsertItem(&itemTree);

			if (bShowBusResult)
			{
				for (i=0; i<(int)g_PGAnalysis.m_TraceBranArray[nDev].nToBusArray.size(); i++)
				{
					sprintf(szBuf, "ĸ�� (%s, %s, %s)", g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_TraceBranArray[nDev].nToBusArray[i]].szSub, 
						g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_TraceBranArray[nDev].nToBusArray[i]].szVolt, g_pBlock->m_BusbarSectionArray[g_PGAnalysis.m_TraceBranArray[nDev].nToBusArray[i]].szName);

					itemTree.hParent=hDeep;
					itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
					itemTree.item.pszText=szBuf;
					itemTree.item.cchTextMax=260;
					itemTree.item.lParam=0;
					itemTree.item.state=TVIS_EXPANDED;
					itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
					hItem=m_wndTreeCtrl.InsertItem(&itemTree);
				}
				for (i=0; i<(int)g_PGAnalysis.m_TraceBranArray[nDev].nHubTranArray.size(); i++)
				{
					sprintf(szBuf, "��Ŧվ���� (%s, %s)", g_pBlock->m_PowerTransformerArray[g_PGAnalysis.m_TraceBranArray[nDev].nHubTranArray[i]].szSub, 
						g_pBlock->m_PowerTransformerArray[g_PGAnalysis.m_TraceBranArray[nDev].nHubTranArray[i]].szName);

					itemTree.hParent=hDeep;
					itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
					itemTree.item.pszText=szBuf;
					itemTree.item.cchTextMax=260;
					itemTree.item.lParam=0;
					itemTree.item.state=TVIS_EXPANDED;
					itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
					hItem=m_wndTreeCtrl.InsertItem(&itemTree);
				}
			}
		}
		else if (g_PGAnalysis.m_TraceBranArray[nDev].nDeep > nIniDeep)
		{
			FillTraceByDeep(nDev, g_PGAnalysis.m_TraceBranArray[nDev].nDeep, hItem, bShowBusResult);
		}
	}
}

void CPGNetAnalysisDlg::OnBnClickedShowBusResult()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnBnClickedTraceButton();
}

void CPGNetAnalysisDlg::OnBnClickedFormSamebreakerLine()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PGAnalysis.FormSameBreakerLine(g_pBlock);
	RefreshSameBreakerLineList();
}

void CPGNetAnalysisDlg::OnBnClickedFormTline()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PGAnalysis.FormPsedoTLine(g_pBlock);
	RefreshTLineList();
}

void CPGNetAnalysisDlg::OnBnClickedFormTxt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	// 	CString	fileExt="txt";
	// 	CString	defaultFileName=_T("");
	// 	CString	fileFilter="�ı��ļ�(*.txt *.dat)|*.txt;*.TXT;*.dat;*.DAT|�����ļ�(*.*)|*.*||";
	// 	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
	//
	// 	CFileDialog	dlg(FALSE, fileExt, 
	// 		defaultFileName, 
	// 		dwFlags, 
	// 		fileFilter, 
	// 		NULL);
	//
	// 	dlg.m_ofn.lpstrTitle=_T("�����ļ�");
	// 	dlg.m_ofn.lpstrInitialDir=_T("");
	// 	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);
	//
	// 	if (dlg.DoModal() == IDCANCEL)
	// 		return;

	clock_t	dBeg, dEnd;
	int		nDur;

	int		nSub, nVolt, nBus;
	dBeg=clock();

	char	szBuf[260];
	GetDlgItem(IDC_MINIMAL_VOLTAGE)->GetWindowText(szBuf, 260);
	double	fMinimalVoltage=atof(szBuf);

	for (nSub=0; nSub<g_pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (g_pBlock->m_SubstationArray[nSub].bHub)
			continue;
		for (nVolt=g_pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (g_pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 40)
				continue;
			for (nBus=g_pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nBus<g_pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nBus++)
			{
				if (g_pBlock->m_BusbarSectionArray[nBus].nNode < 0)
					continue;
				TRACE("TraceSource [%d/%d]=%s.%s.%s\n", nBus, g_pBlock->m_nRecordNum[PG_BUSBARSECTION], g_pBlock->m_BusbarSectionArray[nBus].szSub, g_pBlock->m_BusbarSectionArray[nBus].szVolt, g_pBlock->m_BusbarSectionArray[nBus].szName);
				g_PGAnalysis.TraceSource(g_pBlock, 1, 1, g_pBlock->m_BusbarSectionArray[nBus].nNode);
			}
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	sprintf(szBuf, "�γ���Ϣ�ļ���ɣ���ʱ %d ����", nDur);
	GetDlgItem(IDC_MESG)->SetWindowText(szBuf);
}

void CPGNetAnalysisDlg::OnBnClickedHub()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CHubSubConfigDialog	dlg;
	if (dlg.DoModal() == IDOK)
	{
		register int	i;
		int		nSub;
		for (i=0; i<g_pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
			g_pBlock->m_SubstationArray[i].bHub=0;

		for (i=0; i<(int)g_strHubSubArray.size(); i++)
		{
			nSub=PGFindRecordbyKey(g_pBlock, PG_SUBSTATION, g_strHubSubArray[i].c_str());
			if (nSub >= 0)
				g_pBlock->m_SubstationArray[nSub].bHub=1;
		}
	}

	RefreshPivotSubList();
}

void CPGNetAnalysisDlg::OnBnClickedLineBusRelation()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int	nSrcNode, nVolt;
	std::vector<int>	nBusOutageArray;
	tagAffectBusFaultDevice	dBuf;
	tagAffectBus			busBuffer;

	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();

	nSrcNode=g_PGAnalysis.AffectBus_ResolveSrcNode(g_pBlock);

	for (i=0; i<g_pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		nVolt=PGFindRecordbyKey(g_pBlock, PG_VOLTAGELEVEL, g_pBlock->m_ACLineSegmentArray[i].szSubI, g_pBlock->m_ACLineSegmentArray[i].szVoltI);
		if (nVolt < 0)
			continue;
		if (g_pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 100 || g_pBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 300)
			continue;

		nBusOutageArray.clear();

		g_PGAnalysis.m_AffectBusArray.clear();

		busBuffer.AffectBusDeviceArray.clear();
		busBuffer.nAffectBusOutageArray.clear();

		strcpy(dBuf.szTable, PGGetTableName(PG_ACLINESEGMENT));
		strcpy(dBuf.szKey, g_pBlock->m_ACLineSegmentArray[i].szName);
		dBuf.nTable=PG_ACLINESEGMENT;
		dBuf.nRecord=i;

		busBuffer.AffectBusDeviceArray.push_back(dBuf);

		g_PGAnalysis.m_AffectBusArray.push_back(busBuffer);

		g_PGAnalysis.AffectBus_Traverse(g_pBlock, nSrcNode);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    LineAffectBus����ʱ%d����\n", nDur);
}

void CPGNetAnalysisDlg::OnBnClickedDevaffectbusAnalysis()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CAffectBusDialog	dlg;
	dlg.DoModal();
}

void CPGNetAnalysisDlg::OnBnClicked32volt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Refresh32VoltList();
}

void CPGNetAnalysisDlg::OnBnClickedPangbus()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshBybusList();
}

void CPGNetAnalysisDlg::OnBnClickedBuslinkBreaker()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	PGMemDBType(g_pBlock);
	RefreshBreakerList(PGEnum_BreakerInnerType_BrBus);
}

void CPGNetAnalysisDlg::OnBnClickedBuspassBreaker()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	PGMemDBType(g_pBlock);
	RefreshBreakerList(PGEnum_BreakerInnerType_BrBusBypass);
}

void CPGNetAnalysisDlg::OnBnClickedBypassBreaker()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	PGMemDBType(g_pBlock);
	RefreshBreakerList(PGEnum_BreakerInnerType_BrBypass);
}
