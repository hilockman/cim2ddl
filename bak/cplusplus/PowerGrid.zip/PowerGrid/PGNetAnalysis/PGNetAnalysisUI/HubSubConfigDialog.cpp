// HubSubConfigDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGNetAnalysisApp.h"
#include "HubSubConfigDialog.h"


// CHubSubConfigDialog �Ի���

IMPLEMENT_DYNAMIC(CHubSubConfigDialog, CDialog)

CHubSubConfigDialog::CHubSubConfigDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CHubSubConfigDialog::IDD, pParent)
{

}

CHubSubConfigDialog::~CHubSubConfigDialog()
{
}

void CHubSubConfigDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CHubSubConfigDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD_BUTTON, &CHubSubConfigDialog::OnBnClickedAddButton)
	ON_BN_CLICKED(IDC_DEL_BUTTON, &CHubSubConfigDialog::OnBnClickedDelButton)
	ON_BN_CLICKED(IDOK, &CHubSubConfigDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CHubSubConfigDialog ��Ϣ��������

BOOL CHubSubConfigDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox;

	pListBox=(CListBox*)GetDlgItem(IDC_ALLSUB_LIST);
	pListBox->ResetContent();
	for (i=0; i<g_pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pListBox->AddString(g_pBlock->m_SubstationArray[i].szName);

	RefreshHubstation();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CHubSubConfigDialog::OnBnClickedAddButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	int			nSelArray[5000];
	char		szSub[MDB_CHARLEN_LONG];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_ALLSUB_LIST);
	int			nSelNum=pListBox->GetSelItems(5000, nSelArray);
	if (nSelNum <= 0)
		return;

	for (int nSub=0; nSub<nSelNum; nSub++)
	{
		pListBox->GetText(nSelArray[nSub], szSub);

		bExist=0;
		for (i=0; i<(int)g_strHubSubArray.size(); i++)
		{
			if (strcmp(g_strHubSubArray[i].c_str(), szSub) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			g_strHubSubArray.push_back(szSub);
		}
	}

	RefreshHubstation();
}

void CHubSubConfigDialog::OnBnClickedDelButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nSelArray[5000];
	char		szSub[MDB_CHARLEN_LONG];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_HUBSUB_LIST);
	int			nSelNum=pListBox->GetSelItems(5000, nSelArray);
	if (nSelNum <= 0)
		return;

	for (int nDiv=0; nDiv<nSelNum; nDiv++)
	{
		pListBox->GetText(nSelArray[nDiv], szSub);
		for (i=0; i<(int)g_strHubSubArray.size(); i++)
		{
			if (strcmp(g_strHubSubArray[i].c_str(), szSub) == 0)
			{
				g_strHubSubArray.erase(g_strHubSubArray.begin()+i);
				break;
			}
		}
	}

	RefreshHubstation();
}

void CHubSubConfigDialog::RefreshHubstation(void)
{
	register int	i;
	CListBox*	pListBox;
	pListBox=(CListBox*)GetDlgItem(IDC_HUBSUB_LIST);
	pListBox->ResetContent();

	for (i=0; i<(int)g_strHubSubArray.size(); i++)
		pListBox->AddString(g_strHubSubArray[i].c_str());
}

void CHubSubConfigDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SaveIni();
	OnOK();
}
