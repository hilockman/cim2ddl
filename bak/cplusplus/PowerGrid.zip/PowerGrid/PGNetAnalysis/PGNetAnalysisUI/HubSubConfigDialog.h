#pragma once


// CHubSubConfigDialog �Ի���

class CHubSubConfigDialog : public CDialog
{
	DECLARE_DYNAMIC(CHubSubConfigDialog)

public:
	CHubSubConfigDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CHubSubConfigDialog();

// �Ի�������
	enum { IDD = IDD_HUBSTATION_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedAddButton();
	afx_msg void OnBnClickedDelButton();
	afx_msg void OnBnClickedOk();
private:
	void RefreshHubstation(void);
};
