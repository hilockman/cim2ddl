#pragma once

#include "../../MemDB/PGMemDB/PGMemDB.h"
using namespace PGMemDB;

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

typedef	struct	_PGRecursiveChain_
{
	unsigned char	bMarked;
	unsigned char	bTraced;
	int		nDeep;
	int		nBranType;
	int		nBranIndex;
	int		nFrNode;
	int		nToNode;
	int		nFrSub;
	int		nToSub;
	std::vector<int>	nToBusArray;
	std::vector<int>	nHubTranArray;
}	tagPGRecursiveChain;

typedef	struct _PGRadiant
{
	std::vector<int>	nSourceBusArray;
	std::vector<int>	nRadiantLineArray;
	std::vector<int>	nRadiantTranArray;
	std::vector<int>	nLoadBusArray;
}	tagPGRadiant;

//	��Ϣ����������
//		1��ͼ�����㷨���ṩ��FrNode��ToNode�����е���Ϣ��ToNodeΪ����������
//		2��������Ϣ��������ToNode���Bus��Line��Tran�����ڴ˻�����������վ��Ϣ��������Ҫ����T����·
//		3������ת���������Ǹ�������ͨ����Bus������һ������
//		4������220kV��Ϣʱ���֣�A���Ƿ���Ŧ��B����ѹ�ȼ�

typedef	struct _PGSameBreakerLine
{
	int		nBreaker;
	std::vector<int>	nLineArray;
}	tagPGSameBreakerLine;

typedef	struct _PGTLine
{
	std::vector<int>	nLineArray;
}	tagPGTLine;

typedef	struct _PGPivotSub
{
	std::vector<int>	nLineArray;
	std::vector<int>	nSubArray;
}	tagPGPivotSub;

typedef	struct _AffectBusFaultDevice
{
	char	szTable[MDB_CHARLEN_SHORT];
	char	szKey[MDB_CHARLEN_LONG];
	int		nTable;
	int		nRecord;
}	tagAffectBusFaultDevice;

typedef	struct _AffectBus
{
	std::vector<tagAffectBusFaultDevice>	AffectBusDeviceArray;
	std::vector<int>						nAffectBusOutageArray;
}	tagAffectBus;

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(fPower)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif

class CPGNetAnalysis
{
public:
	CPGNetAnalysis(void);
	~CPGNetAnalysis(void);

public:
	int		TraceSource(tagPGBlock* pBlock, const int bCheckBreakerOpen, const int bCheckDisconnectorOpen, const int nStartNode);	//	��Դ׷˷

	int		PGDecompose(tagPGBlock* pBlock, const float fMinVolt);			//	�γ�������
	int		TraverseRadiant(tagPGBlock* pBlock, const int nCheckStatus);	//	�γɷ�������

	void	FormSameBreakerLine(tagPGBlock* pBlock);
	void	FormTLine(tagPGBlock* pBlock);
	void	FormPsedoTLine(tagPGBlock* pBlock);

private:
	int		IsNodeConnectingGenerator(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nJudgeNode);		//	�ڵ��Ƿ����ӷ����
	int		IsHubStationNode(tagPGBlock* pBlock, const int nJudgeNode);
	void	SetRecursivePower(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus);
	void	TraceJoint(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nIniNode, int nDeep);
	void	PrevTraverseRadiant(tagPGBlock* pBlock);
	void	PostTraverseRadiant(tagPGBlock* pBlock);

	int		PGGetParallelLine(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nLine, std::vector<int>& nParallelLineArray);
	int		PGGetParallel2WTran(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nTran, std::vector<int>& nParallelTranArray);
	int		PGGetParallel3WTran(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nFrNode, const int nToNode, std::vector<int>& nParallelTranArray);

	void	GetAllTLine(tagPGBlock* pBlock, const int nTLine, std::vector<int>& nTLineArray);
	void	AddHubTran(tagPGBlock* pBlock, const int bCheckBreakerStatus, const int bCheckDisconnectorStatus, const int nHubNode, std::vector<int>& nHubTranArray);

public:
	double	m_fMinimalVoltage;
	std::vector<unsigned char>			m_bRingedLineArray;
	std::vector<unsigned char>			m_bRingedTranArray;
	std::vector<unsigned char>			m_bRingedBoundBusArray;

	std::vector<tagPGRadiant>			m_RadiantArray;
	std::vector<tagPGRecursiveChain>	m_TraceBranArray;

	std::vector<tagPGSameBreakerLine>	m_SameBreakerLineArray;
	std::vector<tagPGTLine>				m_TLineArray;
	std::vector<tagPGTLine>				m_PsedoTLineArray;

private:
	std::vector<unsigned char>	m_bNodeProcArray;
	std::vector<unsigned char>	m_bLineProcArray;
	std::vector<unsigned char>	m_bTranProcArray;

public:
	int		ReadFaultDeviceFile(tagPGBlock* pBlock, const char* lpszFileName);
	void	SaveAffectBusFile(tagPGBlock* pBlock, const char* lpszFileName);
	int		AffectBus_ResolveSrcNode(tagPGBlock* pBlock);
	void	AffectBus_Traverse(tagPGBlock* pBlock, const int nSourceNode);
private:
	std::vector<short>				m_nBusStatusArray;

public:
	std::vector<tagAffectBus>		m_AffectBusArray;
	
private:
	void Trim(char* lpszTrim);
};
