#include "stdafx.h"
#include <float.h>
#include "PGEconomyIndex.h"

extern	tagPGBlock*		pPGBlock;

//	������
static	double	m_fInvest;		// Ͷ���ܶ����Ͷ��ȫ������
static	double	m_fLossP;		// ������ MW=1000kW

//	�����������
//	������
static	double	m_fPrice_Sale;		// ������˾��ÿ�ȵ������(Ԫ/ǧ��ʱ)
static	double	m_fPrice_Purse;		// ������˾�������(Ԫ/ǧ��ʱ)

//	������أ�ʵ�������������������������
static	double	m_fIRate_Year;	// ����������(%)
static	int		m_nICycle;		// ��Ϣ����
static	int		m_nTime_Loan;	// ���д���ʱ��(��)
static	int		m_nTime_Const;	// ���̽�����(��)

//	�۾���أ�Ϊ��������۾ɷ���
static	int		m_nTime_Deprec;	// �۾���(��)
static	double	m_fResidual;	// ������ֵ(%)

static	double	m_fTaxRate;		// ����˰˰��
static	double	m_fRepairFee;	// �̶��ʲ���ά�޷�ռ��Ͷ�ʶ�(%)
static	double	m_fInsureFee;	// �̶��ʲ��걣�շ�ռ��Ͷ��(%)


//----------������---------------//
// static	double  m_fCost_Loss;	// ����ɱ�
// static	double  m_fCost_Reli;	// �ɿ��Գɱ� ��Ԫ
// static	double	m_fRCoef;		// ��СͶ�ʻر�ϵ��
// static	double  m_fCost_Fund;	// �ʽ�ɱ�
// static	double  m_fIncome;		// ������Ŀ��Ͷ������������С����

void	InitParam(void)	//��ʼ�������������
{
	m_fPrice_Sale=0.5;			// ������˾��ÿ�ȵ������(Ԫ/ǧ��ʱ)
	m_fPrice_Sale=0.3;			// ������˾�������(Ԫ/ǧ��ʱ)
	m_nTime_Loan=10;			// ���д���ʱ��(��)
	m_nTime_Const=1;			// ���̽�����(��)
	m_nTime_Deprec=14;			// �۾���(��)
	m_fIRate_Year=0.0621;		// ����������(%)
	m_nICycle=4;				// ��Ϣ����
	m_fResidual=0.03;			// ������ֵ(%)
	m_fTaxRate=0.33;			// ����˰˰��
	m_fRepairFee=0.002;			// �̶��ʲ���ά�޷�ռ��Ͷ�ʶ�(%)
	m_fInsureFee=0.0013;		// �̶��ʲ��걣�շ�ռ��Ͷ��(%)
}

void DPlanEcon_Calculate(tagPGBlock* pPGBlock)
{
	//----------�����м����-----------//
	double	fRIRate;		// ʵ��������(%)
	double	fRecip;			// �ʽ�ر���(%)
	double	fApportLoan;	// ��Ҫ��Ͷ���������ڷ�̯�Ĵ������
	double	fEndVLoan;		// �ʽ��ڴ����ڵ���ֵ
	double	fDeprecY;		// �����豸�����۾ɷ�
	double	fDeprecT;		// ����豸��Ͷ�������ڵ����۾ɶ�
	double	fEndVEquip;		// ���������̶��ʲ���Ͷ�������ڽ���ʱ�ļ�ֵ
	double	fEValue;		// �ڻ���ʱͶ�ʵı����ͼ�ȥ�豸�����ֵ��Ͷ�������ڵĵ���ֵ

	//1.��ÿɿ��Գɱ�=ENS*Price_Sale, ���ǵ�λ����
	pPGBlock->m_System.eo_relicost = (float)(1000*pPGBlock->m_System.ro_ens*m_fPrice_Sale/10000);							//��Ԫ

	//2.�������ɱ�=����*�������
	pPGBlock->m_System.eo_losscost = (float)(8760*1000*m_fLossP*m_fPrice_Sale/10000);					//��Ԫ

	//3.���ʽ�ɱ�
	fRIRate=pow(1+m_fIRate_Year/m_nICycle, m_nICycle)-1;						//�����д���ʵ�������� RateΪ�������ʣ� CycleΪ��Ϣ����
	fRecip=fRIRate*(1-m_fTaxRate);												//���ʽ�ر���
	fDeprecY = m_fInvest*(1-m_fResidual)/m_nTime_Deprec;						//������豸�����۾ɷ�fDeprecY//����豸����ֱ�߷��۾ɣ���N�������ֵX�������۾ɷ�����N���̯
	fEndVLoan= pow(1+fRecip, m_nTime_Loan)*m_fInvest;							//���ʽ��ڴ�����ĩ����ֵfEndVLoan
	fDeprecT= (m_nTime_Loan-m_nTime_Const)*fDeprecY;							//����豸��Ͷ�������ڵ����۾ɶ�
	fEndVEquip = m_fInvest-fDeprecT;											//����̶��ʲ���Ͷ�������ڽ���ʱ�ļ�ֵ
	fApportLoan=fEndVLoan-fEndVEquip;											//��Ҫ��Ͷ���������ڷ�̯�Ĵ������
	fEValue=fApportLoan*fRecip/(pow(1+fRecip, m_nTime_Loan-m_nTime_Const)-1);	//�����ֵfEValue

	pPGBlock->m_System.eo_rcoef = (float)(((fEValue-m_fTaxRate*fDeprecY)/(1-m_fTaxRate)+(m_fRepairFee+m_fInsureFee)*m_fInvest)/m_fInvest) ;	// ��СͶ�ʻر�ϵ��
	pPGBlock->m_System.eo_fundcost = (float)(pPGBlock->m_System.eo_rcoef*m_fInvest);

	//4.������С����
	pPGBlock->m_System.eo_income= pPGBlock->m_System.eo_relicost + pPGBlock->m_System.eo_fundcost + pPGBlock->m_System.eo_losscost;

	register int	i;

	pPGBlock->m_System.eo_elesupply = (float)(1000*8760*(pPGBlock->m_System.fTotalLoadP+pPGBlock->m_System.fLossP)/10000);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
		pPGBlock->m_CompanyArray[i].eo_elesupply = (float)(1000*8760*(pPGBlock->m_CompanyArray[i].fTotalLoadP+pPGBlock->m_CompanyArray[i].fLossP)/10000);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pPGBlock->m_SubcontrolAreaArray[i].eo_elesupply = (float)(1000*8760*(pPGBlock->m_SubcontrolAreaArray[i].fTotalLoadP+pPGBlock->m_SubcontrolAreaArray[i].fLossP)/10000);

	pPGBlock->m_System.eo_elecost = (float)(1000*8760*(pPGBlock->m_System.fTotalLoadP+pPGBlock->m_System.fLossP)*m_fPrice_Purse/10000);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
		pPGBlock->m_CompanyArray[i].eo_elecost = (float)(1000*8760*(pPGBlock->m_CompanyArray[i].fTotalLoadP+pPGBlock->m_CompanyArray[i].fLossP)*m_fPrice_Purse/10000);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pPGBlock->m_SubcontrolAreaArray[i].eo_elecost = (float)(1000*8760*(pPGBlock->m_SubcontrolAreaArray[i].fTotalLoadP+pPGBlock->m_SubcontrolAreaArray[i].fLossP)*m_fPrice_Purse/10000);

	pPGBlock->m_System.eo_eleincome = (float)(1000*(8760*pPGBlock->m_System.fTotalLoadP-pPGBlock->m_System.ro_ens)*m_fPrice_Sale/10000);
	pPGBlock->m_System.eo_eleincome -= pPGBlock->m_System.eo_elecost;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
	{
		pPGBlock->m_CompanyArray[i].eo_eleincome = (float)(1000*(8760*pPGBlock->m_CompanyArray[i].fTotalLoadP-pPGBlock->m_CompanyArray[i].ro_ens)*m_fPrice_Sale/10000);
		pPGBlock->m_CompanyArray[i].eo_eleincome -= pPGBlock->m_CompanyArray[i].eo_elecost;
	}
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
	{
		pPGBlock->m_SubcontrolAreaArray[i].eo_eleincome = (float)(1000*(8760*pPGBlock->m_SubcontrolAreaArray[i].fTotalLoadP-pPGBlock->m_SubcontrolAreaArray[i].ro_ens)*m_fPrice_Sale/10000);
		pPGBlock->m_SubcontrolAreaArray[i].eo_eleincome -= pPGBlock->m_SubcontrolAreaArray[i].eo_elecost;
	}
}

void DPlanEcon_EVCalculate(tagPGBlock* pPGBlock)
{
	//g_pBlock->m_System.eo_rcoef	= (float)m_fRCoef;		//	��С�ر�ϵ��
	//g_pBlock->m_System.eo_relicost= (float)m_fCost_Reli;	//	�ɿ��Գɱ�				��λ����Ԫ
	//g_pBlock->m_System.eo_losscost= (float)m_fCost_Loss;	//	����ɱ�				��λ����Ԫ
	//g_pBlock->m_System.eo_fundcost= (float)m_fCost_Fund;	//	�ʽ�ɱ�				��λ����Ԫ
	//g_pBlock->m_System.eo_income	= (float)m_fIncome;		//	��Ͷ�������ڣ�����С���뵥λ����Ԫ
	int	nLoad;

	pPGBlock->m_System.eo_evrelicost=0;
	for (nLoad=0; nLoad<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nLoad++)
	{
		pPGBlock->m_EnergyConsumerArray[nLoad].eo_loss  =(pPGBlock->m_EnergyConsumerArray[nLoad].ei_ConstLoss*pPGBlock->m_EnergyConsumerArray[nLoad].ro_r +1000*pPGBlock->m_EnergyConsumerArray[nLoad].ro_ens  *pPGBlock->m_EnergyConsumerArray[nLoad].ei_EvalRatio)/10000;
		pPGBlock->m_EnergyConsumerArray[nLoad].eo_f_loss=(pPGBlock->m_EnergyConsumerArray[nLoad].ei_ConstLoss*pPGBlock->m_EnergyConsumerArray[nLoad].ro_fr+1000*pPGBlock->m_EnergyConsumerArray[nLoad].ro_f_ens*pPGBlock->m_EnergyConsumerArray[nLoad].ei_EvalRatio)/10000;
		pPGBlock->m_EnergyConsumerArray[nLoad].eo_a_loss=(pPGBlock->m_EnergyConsumerArray[nLoad].ei_ConstLoss*pPGBlock->m_EnergyConsumerArray[nLoad].ro_ar+1000*pPGBlock->m_EnergyConsumerArray[nLoad].ro_a_ens*pPGBlock->m_EnergyConsumerArray[nLoad].ei_EvalRatio)/10000;
		pPGBlock->m_System.eo_evrelicost += pPGBlock->m_EnergyConsumerArray[nLoad].eo_loss;
	}

	pPGBlock->m_System.eo_evincome = pPGBlock->m_System.eo_income - pPGBlock->m_System.eo_relicost;
	pPGBlock->m_System.eo_evincome += pPGBlock->m_System.eo_evrelicost;
}

void FormLoad(tagPGBlock* pPGBlock)
{
	register int	i;
	int		nDiv, nSub, nVolt, nDev;

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nDev++)
		pPGBlock->m_SubstationArray[nDev].fTotalLoadP=0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDev++)
		pPGBlock->m_SubcontrolAreaArray[nDev].fTotalLoadP=0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_COMPANY]; nDev++)
		pPGBlock->m_CompanyArray[nDev].fTotalLoadP=0;

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;

				pPGBlock->m_SubstationArray[nSub].fTotalLoadP += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
			}
		}
	}

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nDiv=0; nDiv<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDiv++)
		{
			if (strcmp(pPGBlock->m_SubcontrolAreaArray[nDiv].szName, pPGBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
			{
				pPGBlock->m_SubcontrolAreaArray[nDiv].fTotalLoadP	+=pPGBlock->m_SubstationArray[nSub].fTotalLoadP;
				break;
			}
		}
	}
	for (nDiv=0; nDiv<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDiv++)
	{
		for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
		{
			if (strcmp(pPGBlock->m_CompanyArray[i].szName, pPGBlock->m_SubcontrolAreaArray[nDiv].szCompany) == 0)
			{
				pPGBlock->m_CompanyArray[i].fTotalLoadP	+=pPGBlock->m_SubcontrolAreaArray[nDiv].fTotalLoadP;
				break;
			}
		}
	}

	pPGBlock->m_System.fTotalLoadP=0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
			continue;
		if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland <= 0)
			continue;
		pPGBlock->m_System.fTotalLoadP += pPGBlock->m_EnergyConsumerArray[nDiv].fPlanP;
	}
}

int FormInvest(tagPGBlock* pPGBlock)
{
	register int	i, j;
	int		nSub, nVolt, nDev, nNode;

	pPGBlock->m_System.ei_Invest=0;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pPGBlock->m_SubstationArray[i].ei_Invest=0;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pPGBlock->m_SubcontrolAreaArray[i].ei_Invest=0;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
		pPGBlock->m_CompanyArray[i].ei_Invest=0;

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SUBSTATIONENTITY]; nDev++)
	{
		nSub=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationEntityArray[nDev].szResID, pPGBlock->m_SubstationArray[i].szResID) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub >= 0)
		{
			pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_SubstationEntityArray[nDev].ei_Invest;
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					pPGBlock->m_SubcontrolAreaArray[i].ei_Invest += pPGBlock->m_SubstationEntityArray[nDev].ei_Invest;
					break;
				}
			}
		}
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONSWITCH]; nDev++)
	{
		nSub=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_DistributionSwitchArray[nDev].szResID, pPGBlock->m_SubstationArray[i].szResID) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub >= 0)
		{
			pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_DistributionSwitchArray[nDev].ei_Invest;
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					pPGBlock->m_SubcontrolAreaArray[i].ei_Invest += pPGBlock->m_DistributionSwitchArray[nDev].ei_Invest;
					break;
				}
			}
		}
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONDOT]; nDev++)
	{
		nSub=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_DistributionDotArray[nDev].szResID, pPGBlock->m_SubstationArray[i].szResID) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub >= 0)
		{
			pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_DistributionDotArray[nDev].ei_Invest;
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					pPGBlock->m_SubcontrolAreaArray[i].ei_Invest += pPGBlock->m_DistributionDotArray[nDev].ei_Invest;
					break;
				}
			}
		}
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONLOAD]; nDev++)
	{
		nSub=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_DistributionLoadArray[nDev].szResID, pPGBlock->m_SubstationArray[i].szResID) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub >= 0)
		{
			pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_DistributionLoadArray[nDev].ei_Invest;
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					pPGBlock->m_SubcontrolAreaArray[i].ei_Invest += pPGBlock->m_DistributionLoadArray[nDev].ei_Invest;
					break;
				}
			}
		}
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONBREAKER]; nDev++)
	{
		nSub=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_DistributionBreakerArray[nDev].szResID, pPGBlock->m_SubstationArray[i].szResID) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub >= 0)
		{
			pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_DistributionBreakerArray[nDev].ei_Invest;
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					pPGBlock->m_SubcontrolAreaArray[i].ei_Invest += pPGBlock->m_DistributionBreakerArray[nDev].ei_Invest;
					break;
				}
			}
		}
	}

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (i=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
		{
			pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_TransformerWindingArray[i].ei_Invest;
			for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[j].szName) == 0)
				{
					pPGBlock->m_SubcontrolAreaArray[j].ei_Invest += pPGBlock->m_TransformerWindingArray[i].ei_Invest;
					break;
				}
			}
		}
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (i=pPGBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; i++)
				{
					pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment].ei_Invest/2;
					for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
					{
						if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[j].szName) == 0)
						{
							pPGBlock->m_SubcontrolAreaArray[j].ei_Invest += pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment].ei_Invest/2;
							break;
						}
					}
				}
			}
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; i++)
			{
				if (pPGBlock->m_BusbarSectionArray[i].nNode < 0)
					continue;

				pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_BusbarSectionArray[i].ei_Invest;
				for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
				{
					if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[j].szName) == 0)
					{
						pPGBlock->m_SubcontrolAreaArray[j].ei_Invest += pPGBlock->m_BusbarSectionArray[i].ei_Invest;
						break;
					}
				}
			}
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
			{
				if (pPGBlock->m_SynchronousMachineArray[i].nNode < 0)
					continue;

				pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_SynchronousMachineArray[i].ei_Invest;
				for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
				{
					if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[j].szName) == 0)
					{
						pPGBlock->m_SubcontrolAreaArray[j].ei_Invest += pPGBlock->m_SynchronousMachineArray[i].ei_Invest;
						break;
					}
				}
			}
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
			{
				if (pPGBlock->m_EnergyConsumerArray[i].nNode < 0)
					continue;

				pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_EnergyConsumerArray[i].ei_Invest;
				for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
				{
					if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[j].szName) == 0)
					{
						pPGBlock->m_SubcontrolAreaArray[j].ei_Invest += pPGBlock->m_EnergyConsumerArray[i].ei_Invest;
						break;
					}
				}
			}
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; i++)
			{
				if (pPGBlock->m_ShuntCompensatorArray[i].nNode < 0)
					continue;

				pPGBlock->m_SubstationArray[nSub].ei_Invest += pPGBlock->m_ShuntCompensatorArray[i].ei_Invest;
				for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
				{
					if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[j].szName) == 0)
					{
						pPGBlock->m_SubcontrolAreaArray[j].ei_Invest += pPGBlock->m_ShuntCompensatorArray[i].ei_Invest;
						break;
					}
				}
			}
		}
	}

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		pPGBlock->m_System.ei_Invest	+=pPGBlock->m_SubstationArray[nSub].ei_Invest;

		for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
		{
			if (strcmp(pPGBlock->m_CompanyArray[i].szName, pPGBlock->m_SubstationArray[nSub].szCompany) == 0)
			{
				pPGBlock->m_CompanyArray[i].ei_Invest	+=pPGBlock->m_SubstationArray[nSub].ei_Invest;
				break;
			}
		}
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		{
			if (strcmp(pPGBlock->m_SubcontrolAreaArray[i].szName, pPGBlock->m_SubstationArray[nSub].szCompany) == 0)
			{
				pPGBlock->m_SubcontrolAreaArray[i].ei_Invest	+=pPGBlock->m_SubstationArray[nSub].ei_Invest;
				break;
			}
		}
	}

	return 1;
}

void FormLoss(tagPGBlock* pPGBlock)
{
	register int	i;
	int		nDev, nSub, nDiv, nDivI, nDivJ;

	pPGBlock->m_System.fLossP = 0;
	pPGBlock->m_System.fLossQ = 0;
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nDev++)
	{
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDev++)
	{
		pPGBlock->m_SubcontrolAreaArray[nDev].fLossP=pPGBlock->m_SubcontrolAreaArray[nDev].fLossQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_COMPANY]; nDev++)
	{
		pPGBlock->m_CompanyArray[nDev].fLossP=pPGBlock->m_CompanyArray[nDev].fLossQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
// 		if (pPGBlock->m_ACLineSegmentArray[nDev].remove != 0)
// 			continue;

		pPGBlock->m_System.fLossP += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossP;
		pPGBlock->m_System.fLossQ += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossQ;

		nDivI=nDivJ=-1;
		nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ACLineSegmentArray[nDev].szSubI);
		if (nSub >= 0)
		{
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubcontrolAreaArray[i].szName, pPGBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
				{
					nDivI=i;
					break;
				}
			}
		}

		nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ);
		if (nSub >= 0)
		{
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubcontrolAreaArray[i].szName, pPGBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
				{
					nDivJ=i;
					break;
				}
			}
		}

		if (nDivI >= 0 && nDivJ >= 0)
		{
			if (nDivI != nDivJ)
			{
				pPGBlock->m_SubcontrolAreaArray[nDivI].fLossP += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossP/2;
				pPGBlock->m_SubcontrolAreaArray[nDivI].fLossQ += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossQ/2;
				pPGBlock->m_SubcontrolAreaArray[nDivJ].fLossP += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossP/2;
				pPGBlock->m_SubcontrolAreaArray[nDivJ].fLossQ += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossQ/2;
			}
			else
			{
				pPGBlock->m_SubcontrolAreaArray[nDivI].fLossP += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossP;
				pPGBlock->m_SubcontrolAreaArray[nDivI].fLossQ += (float)pPGBlock->m_ACLineSegmentArray[nDev].fLossQ;
			}
		}
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
// 		if (pPGBlock->m_TransformerWindingArray[nDev].remove != 0)
// 			continue;

		pPGBlock->m_System.fLossP += (float)pPGBlock->m_TransformerWindingArray[nDev].fLossP;
		pPGBlock->m_System.fLossQ += (float)pPGBlock->m_TransformerWindingArray[nDev].fLossQ;

		nDiv=nSub=-1;
		nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_TransformerWindingArray[nDev].szSub);
		if (nSub >= 0)
		{
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubcontrolAreaArray[i].szName, pPGBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
				{
					nDiv=i;
					break;
				}
			}
		}
		if (nDiv >= 0)
		{
			pPGBlock->m_SubcontrolAreaArray[nDiv].fLossP += (float)pPGBlock->m_TransformerWindingArray[nDev].fLossP;
			pPGBlock->m_SubcontrolAreaArray[nDiv].fLossQ += (float)pPGBlock->m_TransformerWindingArray[nDev].fLossQ;
		}
	}
	for (i=0; i<pPGBlock->m_nRecordNum[PG_COMPANY]; i++)
	{
		for (nDiv=0; nDiv<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDiv++)
		{
			if (strcmp(pPGBlock->m_SubcontrolAreaArray[nDiv].szCompany, pPGBlock->m_CompanyArray[i].szName) == 0)
			{
				pPGBlock->m_CompanyArray[i].fLossP += pPGBlock->m_SubcontrolAreaArray[nDiv].fLossP;
				pPGBlock->m_CompanyArray[i].fLossQ += pPGBlock->m_SubcontrolAreaArray[nDiv].fLossQ;
			}
		}
	}
}

int DPlanEcon_InputData(tagPGBlock* pPGBlock)
{
	FormInvest(pPGBlock);
	FormLoad(pPGBlock);
	FormLoss(pPGBlock);
	InitParam();

	if (pPGBlock->m_System.ei_Invest > FLT_MIN)		m_fInvest		=pPGBlock->m_System.ei_Invest;
	if (pPGBlock->m_System.fLossP > FLT_MIN)		m_fLossP		=pPGBlock->m_System.fLossP;

	if (pPGBlock->m_System.ei_sprice > FLT_MIN)		m_fPrice_Sale	=pPGBlock->m_System.ei_sprice;
	if (pPGBlock->m_System.ei_pprice > FLT_MIN)		m_fPrice_Purse	=pPGBlock->m_System.ei_pprice;
	if (pPGBlock->m_System.ei_iyrate > FLT_MIN)		m_fIRate_Year	=pPGBlock->m_System.ei_iyrate;
	if (pPGBlock->m_System.ei_icycle > FLT_MIN)		m_nICycle		=pPGBlock->m_System.ei_icycle;
	if (pPGBlock->m_System.ei_credtime > FLT_MIN)	m_nTime_Loan	=pPGBlock->m_System.ei_credtime;
	if (pPGBlock->m_System.ei_constime > FLT_MIN)	m_nTime_Const	=pPGBlock->m_System.ei_constime;
	if (pPGBlock->m_System.ei_deprectime > FLT_MIN)	m_nTime_Deprec	=pPGBlock->m_System.ei_deprectime;
	if (pPGBlock->m_System.ei_residual > FLT_MIN)	m_fResidual		=pPGBlock->m_System.ei_residual;
	if (pPGBlock->m_System.ei_taxrate > FLT_MIN)	m_fTaxRate		=pPGBlock->m_System.ei_taxrate;
	if (pPGBlock->m_System.ei_repairfee > FLT_MIN)	m_fRepairFee	=pPGBlock->m_System.ei_repairfee;
	if (pPGBlock->m_System.ei_insurefee > FLT_MIN)	m_fInsureFee	=pPGBlock->m_System.ei_insurefee;


	return 1;
}
