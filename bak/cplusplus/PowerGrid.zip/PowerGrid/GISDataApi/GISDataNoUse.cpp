#include "StdAfx.h"

//////////////////////////////////////////////////////////////////////////
//	.h

//private:
//	void	SetGISData(const int nGISTable, char* pGISData, const char* lpszElementName, const char* lpszElementValue);
//	void SetGISDataValue(const int nGISTable, char* pGISData, const char* lpszElementName, const char* lpszElementValue);

//public:
//	int			GetGISRecordValue(char* pDataPtr, const int nTable, const int nField, char* lpszRetValue);
//	const int	GetGISTableRecordLen(const int nTable);
//	char*		GetGISRecordPtr(const int nTable, const int nRecord);
//	const int	GetGISTableFieldType(const int nTable, const int nField);
//	const int	GetGISTableFieldLen(const int nTable, const int nField);


//////////////////////////////////////////////////////////////////////////
//	.cpp

// void	CGISXmlParser::SetGISData(const int nGISTable, char* pGISData, const char* lpszElementName, const char* lpszElementValue)
// {
// 	register int	i;
// 	int		nDeviate;
// 	unsigned char	bSymbolCoordinate;
// 
// 	bSymbolCoordinate=0;
// 	if (stricmp(lpszElementName, "rdf:ID") == 0)
// 	{
// 		m_GraphicBuf.strResourceId=lpszElementValue;
// 	}
// 	else if (stricmp(lpszElementName, "cim:IdentifiedObject.Coordinate") == 0)
// 	{
// 		bSymbolCoordinate=1;
// 		m_GraphicBuf.strCoordinate=lpszElementValue;
// 	}
// 	else if (stricmp(lpszElementName, "cim:IdentifiedObject.SymbolSize") == 0)
// 	{
// 		bSymbolCoordinate=1;
// 		m_GraphicBuf.fSymbolSize=(float)atof(lpszElementValue);
// 	}
// 	else if (stricmp(lpszElementName, "cim:IdentifiedObject.SymbolAngle") == 0)
// 	{
// 		bSymbolCoordinate=1;
// 		m_GraphicBuf.fSymbolAngle=(float)atof(lpszElementValue);
// 	}
// 	else if (stricmp(lpszElementName, "cim:IdentifiedObject.SymbolID") == 0)
// 	{
// 		bSymbolCoordinate=1;
// 		m_GraphicBuf.strSymbolID=lpszElementValue;
// 	}
// 	if (bSymbolCoordinate)
// 		return;
// 
// 	nDeviate=0;
// 	for (i=0; i<GetGISTableFieldNum(nGISTable); i++)
// 	{
// 		if (stricmp(GetGISTableFieldTag(nGISTable, i), lpszElementName) == 0)
// 		{
// 			if (GetGISTableFieldEnumNum(nGISTable, i) != 0)
// 			{
// 				int	nEnumValue=GetGISTableFieldEnumValue(nGISTable, i, lpszElementValue);;
// 				switch (GetGISTableFieldType(nGISTable, i))
// 				{
// 				case	MDB_INT:
// 					*(int*)(pGISData+nDeviate)=nEnumValue;
// 					break;
// 				case	MDB_SHORT:
// 					*(short*)(pGISData+nDeviate)=nEnumValue;
// 					break;
// 				case	MDB_BIT:
// 					*(unsigned char*)(pGISData+nDeviate)=nEnumValue;
// 					break;
// 				}
// 			}
// 			else
// 			{
// 				switch (GetGISTableFieldType(nGISTable, i))
// 				{
// 				case	MDB_STRING:
// 					if ((int)strlen(lpszElementValue) < GetGISTableFieldLen(nGISTable, i))
// 						strcpy(pGISData+nDeviate, lpszElementValue);
// 					else
// 						strncpy(pGISData+nDeviate, lpszElementValue, GetGISTableFieldLen(nGISTable, i)-2);
// 					break;
// 				case	MDB_DOUBLE:
// 					*(double*)(pGISData+nDeviate)=atof(lpszElementValue);
// 					break;
// 				case	MDB_FLOAT:
// 					*(float*)(pGISData+nDeviate)=(float)atof(lpszElementValue);
// 					break;
// 				case	MDB_INT:
// 					*(int*)(pGISData+nDeviate)=atoi(lpszElementValue);
// 					break;
// 				case	MDB_SHORT:
// 					*(short*)(pGISData+nDeviate)=atoi(lpszElementValue);
// 					break;
// 				case	MDB_BIT:
// 					*(unsigned char*)(pGISData+nDeviate)=atoi(lpszElementValue);
// 					break;
// 				}
// 			}
// 			break;
// 		}
// 		nDeviate += GetGISTableFieldLen(nGISTable, i);
// 	}
// }

// 
// int	CGISXmlParser::GetGISRecordValue(char* pDataPtr, const int nTable, const int nField, char* lpszRetValue)
// {
// 	if (nTable < 0 || nTable >= GetGISTableNum())
// 		return 0;
// 	if (nField < 0 || nField >= g_GISTableArray[nTable].nFieldNum)
// 		return 0;
// 
// 	register int	i;
// 	int				nDeviate;
// 
// 	nDeviate=0;
// 	for (i=0; i<nField; i++)
// 		nDeviate += GetGISTableFieldLen(nTable, i);
// 
// 	switch (GetGISTableFieldType(nTable, nField))
// 	{
// 	case	MDB_STRING:
// 		strcpy(lpszRetValue, pDataPtr+nDeviate);
// 		break;
// 	case	MDB_DOUBLE:
// 		sprintf(lpszRetValue, "%f", *(double*)(pDataPtr+nDeviate));
// 		break;
// 	case	MDB_FLOAT:
// 		sprintf(lpszRetValue, "%f", *(float*)(pDataPtr+nDeviate));
// 		break;
// 	case	MDB_INT:
// 		sprintf(lpszRetValue, "%d", *(int*)(pDataPtr+nDeviate));
// 		break;
// 	case	MDB_SHORT:
// 		sprintf(lpszRetValue, "%d", *(short*)(pDataPtr+nDeviate));
// 		break;
// 	case	MDB_BIT:
// 		sprintf(lpszRetValue, "%d", *(unsigned char*)(pDataPtr+nDeviate));
// 		break;
// 	}
// 	return 1;
// }

// 
// const int	CGISXmlParser::GetGISTableRecordLen(const int nTable)
// {
// 	switch (nTable)
// 	{
// 	case GIS_RDF:						return (int)sizeof(tagGISRDF					);	break;
// 	case GIS_GeographicalRegion:		return (int)sizeof(tagGISGeographicalRegion		);	break;
// 	case GIS_SubGeographicalRegion:		return (int)sizeof(tagGISSubGeographicalRegion	);	break;
// 	case GIS_BaseVoltage:				return (int)sizeof(tagGISBaseVoltage			);	break;
// 	case GIS_Substation:				return (int)sizeof(tagGISSubstation				);	break;
// 	case GIS_Feeder:					return (int)sizeof(tagGISFeeder					);	break;
// 	case GIS_CompositeSwitch:			return (int)sizeof(tagGISCompositeSwitch		);	break;
// 	case GIS_Breaker:					return (int)sizeof(tagGISBreaker				);	break;
// 	case GIS_Disconnector:				return (int)sizeof(tagGISDisconnector			);	break;
// 	case GIS_GroundDisconnector:		return (int)sizeof(tagGISGroundDisconnector		);	break;
// 	case GIS_LoadBreakSwitch:			return (int)sizeof(tagGISLoadBreakSwitch		);	break;
// 	case GIS_Fuse:						return (int)sizeof(tagGISFuse					);	break;
// 	case GIS_BusbarSection:				return (int)sizeof(tagGISBusbarSection			);	break;
// 	case GIS_Pole:						return (int)sizeof(tagGISPole					);	break;
// 	case GIS_Junction:					return (int)sizeof(tagGISJunction				);	break;
// 	case GIS_ACLineSegment:				return (int)sizeof(tagGISACLineSegment			);	break;
// 	case GIS_PowerTransformer:			return (int)sizeof(tagGISPowerTransformer		);	break;
// 	case GIS_ConnLine:					return (int)sizeof(tagGISConnLine				);	break;
// 	case GIS_EnergyConsumer:			return (int)sizeof(tagGISEnergyConsumer			);	break;
// 	case GIS_Compensator:				return (int)sizeof(tagGISCompensator			);	break;
// 	case GIS_Capacitor:					return (int)sizeof(tagGISCapacitor				);	break;
// 	case GIS_Terminal:					return (int)sizeof(tagGISTerminal				);	break;
// 	case GIS_ConnectivityNode:			return (int)sizeof(tagGISConnectivityNode		);	break;
// 	case GIS_Pipe:						return (int)sizeof(tagGISPipe					);	break;
// 	case GIS_PSRType:					return (int)sizeof(tagGISPSRType				);	break;
// 	case GIS_PT:						return (int)sizeof(tagGISPT						);	break;
// 	case GIS_CT:						return (int)sizeof(tagGISCT						);	break;
// 	case GIS_BLQ:						return (int)sizeof(tagGISBLQ					);	break;
// 	case GIS_FaultIndicator:			return (int)sizeof(tagGISFaultIndicator			);	break;
// 	case GIS_PTCab:						return (int)sizeof(tagGISPTCab					);	break;
// 	case GIS_Ground:					return (int)sizeof(tagGISGround					);	break;
// 	case GIS_PTCABU:					return (int)sizeof(tagGISPTCABU					);	break;
// 	case GIS_KWGXB:						return (int)sizeof(tagGISKWGXB					);	break;
// 	case GIS_PFWELL:					return (int)sizeof(tagGISPFWELL					);	break;
// 	case GIS_PFTUNN:					return (int)sizeof(tagGISPFTUNN					);	break;
// 	case GIS_Other:						return (int)sizeof(tagGISOther					);	break;
// 	case GIS_ZJ:						return (int)sizeof(tagGISZJ						);	break;
// 	default:	break;
// 	}
// 	return 0;
// }


// char*	CGISXmlParser::GetGISRecordPtr(const int nTable, const int nRecord)
// {
// 	switch (nTable)
// 	{
// 	case GIS_RDF:						if (nRecord >= 0 && nRecord < (int)m_RDFArray.size())					return (char*)&m_RDFArray[nRecord]						;	break;
// 	case GIS_GeographicalRegion:		if (nRecord >= 0 && nRecord < (int)m_GeographicalRegionArray.size())	return (char*)&m_GeographicalRegionArray[nRecord]		;	break;
// 	case GIS_SubGeographicalRegion:		if (nRecord >= 0 && nRecord < (int)m_SubGeographicalRegionArray.size())	return (char*)&m_SubGeographicalRegionArray[nRecord]	;	break;
// 	case GIS_BaseVoltage:				if (nRecord >= 0 && nRecord < (int)m_BaseVoltageArray.size())			return (char*)&m_BaseVoltageArray[nRecord]				;	break;
// 	case GIS_Substation:				if (nRecord >= 0 && nRecord < (int)m_SubstationArray.size())			return (char*)&m_SubstationArray[nRecord]				;	break;
// 	case GIS_Feeder:					if (nRecord >= 0 && nRecord < (int)m_FeederArray.size())				return (char*)&m_FeederArray[nRecord]					;	break;
// 	case GIS_CompositeSwitch:			if (nRecord >= 0 && nRecord < (int)m_CompositeSwitchArray.size())		return (char*)&m_CompositeSwitchArray[nRecord]			;	break;
// 	case GIS_Breaker:					if (nRecord >= 0 && nRecord < (int)m_BreakerArray.size())				return (char*)&m_BreakerArray[nRecord]					;	break;
// 	case GIS_Disconnector:				if (nRecord >= 0 && nRecord < (int)m_DisconnectorArray.size())			return (char*)&m_DisconnectorArray[nRecord]				;	break;
// 	case GIS_GroundDisconnector:		if (nRecord >= 0 && nRecord < (int)m_GroundDisconnectorArray.size())	return (char*)&m_GroundDisconnectorArray[nRecord]		;	break;
// 	case GIS_LoadBreakSwitch:			if (nRecord >= 0 && nRecord < (int)m_LoadBreakSwitchArray.size())		return (char*)&m_LoadBreakSwitchArray[nRecord]			;	break;
// 	case GIS_Fuse:						if (nRecord >= 0 && nRecord < (int)m_FuseArray.size())					return (char*)&m_FuseArray[nRecord]						;	break;
// 	case GIS_BusbarSection:				if (nRecord >= 0 && nRecord < (int)m_BusbarSectionArray.size())			return (char*)&m_BusbarSectionArray[nRecord]			;	break;
// 	case GIS_Pole:						if (nRecord >= 0 && nRecord < (int)m_PoleArray.size())					return (char*)&m_PoleArray[nRecord]						;	break;
// 	case GIS_Junction:					if (nRecord >= 0 && nRecord < (int)m_JunctionArray.size())				return (char*)&m_JunctionArray[nRecord]					;	break;
// 	case GIS_ACLineSegment:				if (nRecord >= 0 && nRecord < (int)m_ACLineSegmentArray.size())			return (char*)&m_ACLineSegmentArray[nRecord]			;	break;
// 	case GIS_PowerTransformer:			if (nRecord >= 0 && nRecord < (int)m_PowerTransformerArray.size())		return (char*)&m_PowerTransformerArray[nRecord]			;	break;
// 	case GIS_ConnLine:					if (nRecord >= 0 && nRecord < (int)m_ConnLineArray.size())				return (char*)&m_ConnLineArray[nRecord]					;	break;
// 	case GIS_EnergyConsumer:			if (nRecord >= 0 && nRecord < (int)m_EnergyConsumerArray.size())		return (char*)&m_EnergyConsumerArray[nRecord]			;	break;
// 	case GIS_Compensator:				if (nRecord >= 0 && nRecord < (int)m_CompensatorArray.size())			return (char*)&m_CompensatorArray[nRecord]				;	break;
// 	case GIS_Capacitor:					if (nRecord >= 0 && nRecord < (int)m_CapacitorArray.size())				return (char*)&m_CapacitorArray[nRecord]				;	break;
// 	case GIS_Terminal:					if (nRecord >= 0 && nRecord < (int)m_TerminalArray.size())				return (char*)&m_TerminalArray[nRecord]					;	break;
// 	case GIS_ConnectivityNode:			if (nRecord >= 0 && nRecord < (int)m_ConnectivityNodeArray.size())		return (char*)&m_ConnectivityNodeArray[nRecord]			;	break;
// 	case GIS_Pipe:						if (nRecord >= 0 && nRecord < (int)m_PipeArray.size())					return (char*)&m_PipeArray[nRecord]						;	break;
// 	case GIS_PSRType:					if (nRecord >= 0 && nRecord < (int)m_PSRTypeArray.size())				return (char*)&m_PSRTypeArray[nRecord]					;	break;
// 	case GIS_PT:						if (nRecord >= 0 && nRecord < (int)m_PTArray.size())					return (char*)&m_PTArray[nRecord]						;	break;
// 	case GIS_CT:						if (nRecord >= 0 && nRecord < (int)m_CTArray.size())					return (char*)&m_CTArray[nRecord]						;	break;
// 	case GIS_BLQ:						if (nRecord >= 0 && nRecord < (int)m_BLQArray.size())					return (char*)&m_BLQArray[nRecord]						;	break;
// 	case GIS_FaultIndicator:			if (nRecord >= 0 && nRecord < (int)m_FaultIndicatorArray.size())		return (char*)&m_FaultIndicatorArray[nRecord]			;	break;
// 	case GIS_PTCab:						if (nRecord >= 0 && nRecord < (int)m_PTCabArray.size())					return (char*)&m_PTCabArray[nRecord]					;	break;
// 	case GIS_Ground:					if (nRecord >= 0 && nRecord < (int)m_GroundArray.size())				return (char*)&m_GroundArray[nRecord]					;	break;
// 	case GIS_Other:						if (nRecord >= 0 && nRecord < (int)m_OtherArray.size())					return (char*)&m_OtherArray[nRecord]					;	break;
// 	case GIS_PTCABU:					if (nRecord >= 0 && nRecord < (int)m_PTCABUArray.size())				return (char*)&m_PTCABUArray[nRecord]					;	break;
// 	case GIS_KWGXB:						if (nRecord >= 0 && nRecord < (int)m_KWGXBArray.size())					return (char*)&m_KWGXBArray[nRecord]					;	break;
// 	case GIS_PFWELL:					if (nRecord >= 0 && nRecord < (int)m_PFWELLArray.size())				return (char*)&m_PFWELLArray[nRecord]					;	break;
// 	case GIS_PFTUNN:					if (nRecord >= 0 && nRecord < (int)m_PFTUNNArray.size())				return (char*)&m_PFTUNNArray[nRecord]					;	break;
// 	case GIS_ZJ:						if (nRecord >= 0 && nRecord < (int)m_ZJArray.size())					return (char*)&m_ZJArray[nRecord]						;	break;
// 	default:	break;
// 	}
// 	return NULL;
// }

// int		CGISXmlParser::FillElement(const int nCimSection, const char* lpszElementName, const char* lpszElementValue)
// {
// 	//Log("    SAX[%s] FillElement %s = %s\n",g_GISTableArray[nCimSection].szDesp,lpszElementName,lpszElementValue);
// 	int	nField=GetGISTableFieldIndex(nCimSection, lpszElementName);
// 	if (nField < 0)
// 		return 0;
// 	switch (nCimSection)
// 	{
// 	case GIS_RDF:						SetGISData	(nCimSection,	(char*)&m_RDFBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_BaseVoltage:				SetGISData	(nCimSection,	(char*)&m_BaseVoltageBuf,			lpszElementName, lpszElementValue);	break;
// 	case GIS_PSRType:					SetGISData	(nCimSection,	(char*)&m_PSRTypeBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_GeographicalRegion:		SetGISData	(nCimSection,	(char*)&m_GeographicalRegionBuf,	lpszElementName, lpszElementValue);	break;
// 	case GIS_SubGeographicalRegion:		SetGISData	(nCimSection,	(char*)&m_SubGeographicalRegionBuf,	lpszElementName, lpszElementValue);	break;
// 	case GIS_Substation:				SetGISData	(nCimSection,	(char*)&m_SubstationBuf,			lpszElementName, lpszElementValue);	break;
// 	case GIS_Feeder:					SetGISData	(nCimSection,	(char*)&m_FeederBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_CompositeSwitch:			SetGISData	(nCimSection,	(char*)&m_CompositeSwitchBuf,		lpszElementName, lpszElementValue);	break;
// 	case GIS_Breaker:					SetGISData	(nCimSection,	(char*)&m_BreakerBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_Disconnector:				SetGISData	(nCimSection,	(char*)&m_DisconnectorBuf,			lpszElementName, lpszElementValue);	break;
// 	case GIS_GroundDisconnector:		SetGISData	(nCimSection,	(char*)&m_GroundDisconnectorBuf,	lpszElementName, lpszElementValue);	break;
// 	case GIS_LoadBreakSwitch:			SetGISData	(nCimSection,	(char*)&m_LoadBreakSwitchBuf,		lpszElementName, lpszElementValue);	break;
// 	case GIS_Fuse:						SetGISData	(nCimSection,	(char*)&m_FuseBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_ACLineSegment:				SetGISData	(nCimSection,	(char*)&m_ACLineSegmentBuf,			lpszElementName, lpszElementValue);	break;
// 	case GIS_PowerTransformer:			SetGISData	(nCimSection,	(char*)&m_PowerTransformerBuf,		lpszElementName, lpszElementValue);	break;
// 	case GIS_ConnLine:					SetGISData	(nCimSection,	(char*)&m_ConnLineBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_BusbarSection:				SetGISData	(nCimSection,	(char*)&m_BusbarSectionBuf,			lpszElementName, lpszElementValue);	break;
// 	case GIS_Pole:						SetGISData	(nCimSection,	(char*)&m_PoleBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_Junction:					SetGISData	(nCimSection,	(char*)&m_JunctionBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_EnergyConsumer:			SetGISData	(nCimSection,	(char*)&m_EnergyConsumerBuf,		lpszElementName, lpszElementValue);	break;
// 	case GIS_Compensator:				SetGISData	(nCimSection,	(char*)&m_CompensatorBuf,			lpszElementName, lpszElementValue);	break;
// 	case GIS_Capacitor:					SetGISData	(nCimSection,	(char*)&m_CapacitorBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_Terminal:					SetGISData	(nCimSection,	(char*)&m_TerminalBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_ConnectivityNode:			SetGISData	(nCimSection,	(char*)&m_ConnectivityNodeBuf,		lpszElementName, lpszElementValue);	break;
// 	case GIS_Pipe:						SetGISData	(nCimSection,	(char*)&m_PipeBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_PT:						SetGISData	(nCimSection,	(char*)&m_PTBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_CT:						SetGISData	(nCimSection,	(char*)&m_CTBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_BLQ:						SetGISData	(nCimSection,	(char*)&m_BLQBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_FaultIndicator:			SetGISData	(nCimSection,	(char*)&m_FaultIndicatorBuf,		lpszElementName, lpszElementValue);	break;
// 	case GIS_PTCab:						SetGISData	(nCimSection,	(char*)&m_PTCabBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_Ground:					SetGISData	(nCimSection,	(char*)&m_GroundBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_Other:						SetGISData	(nCimSection,	(char*)&m_OtherBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_PTCABU:					SetGISData	(nCimSection,	(char*)&m_PTCABUBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_KWGXB:						SetGISData	(nCimSection,	(char*)&m_KWGXBBuf,					lpszElementName, lpszElementValue);	break;
// 	case GIS_PFWELL:					SetGISData	(nCimSection,	(char*)&m_PFWELLBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_PFTUNN:					SetGISData	(nCimSection,	(char*)&m_PFTUNNBuf,				lpszElementName, lpszElementValue);	break;
// 	case GIS_ZJ:						SetGISData	(nCimSection,	(char*)&m_ZJBuf,					lpszElementName, lpszElementValue);	break;
// 	default:
// 		return 0;
// 		break;
// 	}
// 	return 1;
// }

// 
// void	CGISXmlParser::SetGISDataValue(const int nGISTable, char* pGISData, const char* lpszElementName, const char* lpszElementValue)
// {
// 	register int	i;
// 	int		nDeviate;
// 
// 	nDeviate=0;
// 	for (i=0; i<GetGISTableFieldNum(nGISTable); i++)
// 	{
// 		if (stricmp(GetGISTableFieldDesp(nGISTable, i), lpszElementName) == 0)
// 		{
// 			switch (GetGISTableFieldType(nGISTable, i))
// 			{
// 			case	MDB_STRING:
// 				if ((int)strlen(lpszElementValue) < GetGISTableFieldLen(nGISTable, i))
// 					strcpy(pGISData+nDeviate, lpszElementValue);
// 				else
// 					strncpy(pGISData+nDeviate, lpszElementValue, GetGISTableFieldLen(nGISTable, i)-2);
// 				break;
// 			case	MDB_DOUBLE:
// 				*(double*)(pGISData+nDeviate)=atof(lpszElementValue);
// 				break;
// 			case	MDB_FLOAT:
// 				*(float*)(pGISData+nDeviate)=(float)atof(lpszElementValue);
// 				break;
// 			case	MDB_INT:
// 				*(int*)(pGISData+nDeviate)=atoi(lpszElementValue);
// 				break;
// 			case	MDB_SHORT:
// 				*(short*)(pGISData+nDeviate)=atoi(lpszElementValue);
// 				break;
// 			case	MDB_BIT:
// 				*(unsigned char*)(pGISData+nDeviate)=atoi(lpszElementValue);
// 				break;
// 			}
// 			break;
// 		}
// 		nDeviate += GetGISTableFieldLen(nGISTable, i);
// 	}
// }

// const	int	CGISXmlParser::GetGISTableFieldType(const int nTable, const int nField)
// {
// 	if (nTable >= 0 && nTable < GetGISTableNum())
// 	{
// 		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
// 			return g_GISTableArray[nTable].pFieldArray[nField].nFieldType;
// 	}
// 	return 0;
// }
// 
// const	int	CGISXmlParser::GetGISTableFieldLen(const int nTable, const int nField)
// {
// 	if (nTable >= 0 && nTable < GetGISTableNum())
// 	{
// 		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
// 			return g_GISTableArray[nTable].pFieldArray[nField].nFieldLen;
// 	}
// 	return 0;
// }
