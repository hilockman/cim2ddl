#include "stdafx.h"
#include "GISData.h"

void	CGISData::Sort()
{
	sortPSRTypeByResID(0, (int)m_PSRTypeArray.size()-1);
	sortBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1);
	sortSubstationByResID(0, (int)m_SubstationArray.size()-1);
	sortBusbarSectionByResID(0, (int)m_BusbarSectionArray.size()-1);
	sortPowerTransformerByResID(0, (int)m_PowerTransformerArray.size()-1);
	sortEnergyConsumerByResID(0, (int)m_EnergyConsumerArray.size()-1);
	sortPoleByResID(0, (int)m_PoleArray.size()-1);
	sortJunctionByResID(0, (int)m_JunctionArray.size()-1);
	sortFeederByResID(0, (int)m_FeederArray.size()-1);
	sortTerminalByParentTag(0, (int)m_TerminalArray.size()-1);
	sortConnectivityNodeByResID(m_ConnectivityNodeArray, 0, (int)m_ConnectivityNodeArray.size()-1);
	sortACLineSegmentByResID(0, (int)m_ACLineSegmentArray.size()-1);
	sortConnLineByResID(0, (int)m_ConnLineArray.size()-1);
	sortBreakerByResID(0, (int)m_BreakerArray.size()-1);
	sortDisconnectorByResID(0, (int)m_DisconnectorArray.size()-1);
	sortLoadBreakSwitchByResID(0, (int)m_LoadBreakSwitchArray.size()-1);
	sortFuseByResID(0, (int)m_FuseArray.size()-1);
	sortCompensatorByResID(0, (int)m_CompensatorArray.size()-1);
	sortPTByResID(0, (int)m_PTArray.size()-1);
	sortCTByResID(0, (int)m_CTArray.size()-1);
	sortZJByResID(0, (int)m_ZJArray.size()-1);
	sortBLQByResID(0, (int)m_BLQArray.size()-1);

	Check();
}

void CGISData::sortString(std::vector<std::string>& strArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strBuf=strArray[(nDn0+nUp0)/2];
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(strArray[nDn].c_str(), strBuf.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(strArray[nUp].c_str(), strBuf.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(strArray[nDn], strArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strBuf.clear();

	if (nDn0 < nUp)
		sortString(strArray, nDn0, nUp);

	if (nDn < nUp0 )
		sortString(strArray, nDn, nUp0);
}

void CGISData::sortInteger(std::vector<int>& nArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nBuf=nArray[(nDn0+nUp0)/2];
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && nArray[nDn] < nBuf)
			++nDn;
		while (nUp > nDn0 && nArray[nUp] > nBuf)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(nArray[nDn], nArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortInteger(nArray, nDn0, nUp);

	if (nDn < nUp0 )
		sortInteger(nArray, nDn, nUp0);
}

void CGISData::sortPSRTypeByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_PSRTypeArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PSRTypeArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PSRTypeArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PSRTypeArray[nDn], m_PSRTypeArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortPSRTypeByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortPSRTypeByResID(nDn, nUp0);
}

void CGISData::sortBaseVoltageByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_BaseVoltageArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BaseVoltageArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BaseVoltageArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BaseVoltageArray[nDn], m_BaseVoltageArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBaseVoltageByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortBaseVoltageByResID(nDn, nUp0);
}

void CGISData::sortTerminalByParentTag(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strTag=m_TerminalArray[(nDn0+nUp0)/2].strParentTag;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_TerminalArray[nDn].strParentTag.c_str(), strTag.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_TerminalArray[nUp].strParentTag.c_str(), strTag.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_TerminalArray[nDn], m_TerminalArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strTag.clear();

	if (nDn0 < nUp)
		sortTerminalByParentTag(nDn0, nUp);

	if (nDn < nUp0 )
		sortTerminalByParentTag(nDn, nUp0);
}

void CGISData::sortConnectivityNodeByResID(std::vector<tagGISConnectivityNode>& nodeArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=nodeArray[(nDn0+nUp0)/2].strResourceID;
	std::string	strVolt=nodeArray[(nDn0+nUp0)/2].strBaseVoltageTag;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && (strcmp(nodeArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0 || strcmp(nodeArray[nDn].strResourceID.c_str(), strResId.c_str()) == 0 && strcmp(nodeArray[nDn].strBaseVoltageTag.c_str(), strVolt.c_str()) > 0))
		//while (nDn < nUp0 && (strcmp(nodeArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0))
			++nDn;
		while (nUp > nDn0 && (strcmp(nodeArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0 || strcmp(nodeArray[nUp].strResourceID.c_str(), strResId.c_str()) == 0 && strcmp(nodeArray[nUp].strBaseVoltageTag.c_str(), strVolt.c_str()) < 0))
		//while (nUp > nDn0 && (strcmp(nodeArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0))
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(nodeArray[nDn], nodeArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortConnectivityNodeByResID(nodeArray, nDn0, nUp);

	if (nDn < nUp0 )
		sortConnectivityNodeByResID(nodeArray, nDn, nUp0);
}

void CGISData::sortSubstationByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_SubstationArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_SubstationArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_SubstationArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_SubstationArray[nDn], m_SubstationArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortSubstationByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortSubstationByResID(nDn, nUp0);
}

void CGISData::sortBusbarSectionByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_BusbarSectionArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BusbarSectionArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BusbarSectionArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BusbarSectionArray[nDn], m_BusbarSectionArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortBusbarSectionByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortBusbarSectionByResID(nDn, nUp0);
}

void CGISData::sortPowerTransformerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_PowerTransformerArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PowerTransformerArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PowerTransformerArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PowerTransformerArray[nDn], m_PowerTransformerArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortPowerTransformerByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortPowerTransformerByResID(nDn, nUp0);
}

void	CGISData::sortPowerTransformerByParentID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strParent=m_PowerTransformerArray[(nDn0+nUp0)/2].strParentTag;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PowerTransformerArray[nDn].strParentTag.c_str(), strParent.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PowerTransformerArray[nUp].strParentTag.c_str(), strParent.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PowerTransformerArray[nDn], m_PowerTransformerArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strParent.clear();

	if (nDn0 < nUp)
		sortPowerTransformerByParentID(nDn0, nUp);

	if (nDn < nUp0 )
		sortPowerTransformerByParentID(nDn, nUp0);
}

void CGISData::sortEnergyConsumerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_EnergyConsumerArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_EnergyConsumerArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_EnergyConsumerArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_EnergyConsumerArray[nDn], m_EnergyConsumerArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortEnergyConsumerByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortEnergyConsumerByResID(nDn, nUp0);
}

void CGISData::sortPoleByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_PoleArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PoleArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PoleArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PoleArray[nDn], m_PoleArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortPoleByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortPoleByResID(nDn, nUp0);
}

void CGISData::sortJunctionByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_JunctionArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_JunctionArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_JunctionArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_JunctionArray[nDn], m_JunctionArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortJunctionByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortJunctionByResID(nDn, nUp0);
}

void CGISData::sortFeederByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_FeederArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_FeederArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_FeederArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_FeederArray[nDn], m_FeederArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortFeederByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortFeederByResID(nDn, nUp0);
}

void CGISData::sortACLineSegmentByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_ACLineSegmentArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_ACLineSegmentArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_ACLineSegmentArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_ACLineSegmentArray[nDn], m_ACLineSegmentArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortACLineSegmentByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortACLineSegmentByResID(nDn, nUp0);
}

void CGISData::sortConnLineByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_ConnLineArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_ConnLineArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_ConnLineArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_ConnLineArray[nDn], m_ConnLineArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortConnLineByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortConnLineByResID(nDn, nUp0);
}

void CGISData::sortBreakerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_BreakerArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BreakerArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BreakerArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BreakerArray[nDn], m_BreakerArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortBreakerByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortBreakerByResID(nDn, nUp0);
}

void CGISData::sortDisconnectorByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_DisconnectorArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_DisconnectorArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_DisconnectorArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_DisconnectorArray[nDn], m_DisconnectorArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortDisconnectorByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortDisconnectorByResID(nDn, nUp0);
}

void CGISData::sortLoadBreakSwitchByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_LoadBreakSwitchArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_LoadBreakSwitchArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_LoadBreakSwitchArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_LoadBreakSwitchArray[nDn], m_LoadBreakSwitchArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortLoadBreakSwitchByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortLoadBreakSwitchByResID(nDn, nUp0);
}

void CGISData::sortFuseByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_FuseArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_FuseArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_FuseArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_FuseArray[nDn], m_FuseArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortFuseByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortFuseByResID(nDn, nUp0);
}

void CGISData::sortCompensatorByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_CompensatorArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_CompensatorArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_CompensatorArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_CompensatorArray[nDn], m_CompensatorArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortCompensatorByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortCompensatorByResID(nDn, nUp0);
}

void CGISData::sortPTByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_PTArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PTArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PTArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PTArray[nDn], m_PTArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortPTByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortPTByResID(nDn, nUp0);
}

void CGISData::sortCTByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_CTArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_CTArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_CTArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_CTArray[nDn], m_CTArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortCTByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortCTByResID(nDn, nUp0);
}

void CGISData::sortZJByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_ZJArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_ZJArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_ZJArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_ZJArray[nDn], m_ZJArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortZJByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortZJByResID(nDn, nUp0);
}

void CGISData::sortBLQByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_BLQArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BLQArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BLQArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BLQArray[nDn], m_BLQArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBLQByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortBLQByResID(nDn, nUp0);
}

void CGISData::sortPipeByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_PipeArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PipeArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PipeArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PipeArray[nDn], m_PipeArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortPipeByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortPipeByResID(nDn, nUp0);
}
