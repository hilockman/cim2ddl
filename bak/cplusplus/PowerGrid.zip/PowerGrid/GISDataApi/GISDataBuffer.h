#pragma once

#include "GISDataDefine.h"

class GISDATAAPI_API CGISDataBuffer
{
public:
	CGISDataBuffer(void);
	~CGISDataBuffer(void);

public:
	tagGISPSRType					m_PSRTypeBuf				;
	tagGISRDF						m_RDFBuf					;
	tagGISGeographicalRegion		m_GeographicalRegionBuf		;
	tagGISSubGeographicalRegion		m_SubGeographicalRegionBuf	;
	tagGISBaseVoltage				m_BaseVoltageBuf			;
	tagGISSubstation				m_SubstationBuf				;
	tagGISFeeder					m_FeederBuf					;
	tagGISCompositeSwitch			m_CompositeSwitchBuf		;
	tagGISBreaker					m_BreakerBuf				;
	tagGISDisconnector				m_DisconnectorBuf			;
	tagGISGroundDisconnector		m_GroundDisconnectorBuf		;
	tagGISLoadBreakSwitch			m_LoadBreakSwitchBuf		;
	tagGISFuse						m_FuseBuf					;
	tagGISACLineSegment				m_ACLineSegmentBuf			;
	tagGISPowerTransformer			m_PowerTransformerBuf		;
	tagGISConnLine					m_ConnLineBuf				;
	tagGISBusbarSection				m_BusbarSectionBuf			;
	tagGISPole						m_PoleBuf					;
	tagGISJunction					m_JunctionBuf				;
	tagGISEnergyConsumer			m_EnergyConsumerBuf			;
	tagGISCompensator				m_CompensatorBuf			;
	tagGISCapacitor					m_CapacitorBuf				;
	tagGISTerminal					m_TerminalBuf				;
	tagGISConnectivityNode			m_ConnectivityNodeBuf		;
	tagGISPipe						m_PipeBuf					;
	tagGISPT						m_PTBuf						;
	tagGISCT						m_CTBuf						;
	tagGISBLQ						m_BLQBuf					;
	tagGISFaultIndicator			m_FaultIndicatorBuf			;
	tagGISPTCab						m_PTCabBuf					;
	tagGISGround					m_GroundBuf					;
	tagGISOther						m_OtherBuf					;
	tagGISPTCABU					m_PTCABUBuf					;
	tagGISKWGXB						m_KWGXBBuf					;
	tagGISPFWELL					m_PFWELLBuf					;
	tagGISPFTUNN					m_PFTUNNBuf					;
	tagGISZJ						m_ZJBuf						;

public:
	void	Init(const int nGisTable);
	int		Fill(const int nGisTable, const int nField, const char* lpszElementValue);

public:
	const	std::string GetGISPSRType(tagGISPSRType& gData, const int nField);
	void	SetGISPSRType(tagGISPSRType& gData, const int nField, const	std::string strValue);

	const	std::string GetGISRDF(tagGISRDF& gData, const int nField);
	void	SetGISRDF(tagGISRDF& gData, const int nField, const	std::string strValue);

	const	std::string GetGISGeographicalRegion(tagGISGeographicalRegion& gData, const int nField);
	void	SetGISGeographicalRegion(tagGISGeographicalRegion& gData, const int nField, const	std::string strValue);

	const	std::string GetGISSubGeographicalRegion(tagGISSubGeographicalRegion& gData, const int nField);
	void	SetGISSubGeographicalRegion(tagGISSubGeographicalRegion& gData, const int nField, const	std::string strValue);

	const	std::string GetGISBaseVoltage(tagGISBaseVoltage& gData, const int nField);
	void	SetGISBaseVoltage(tagGISBaseVoltage& gData, const int nField, const	std::string strValue);

	const	std::string GetGISSubstation(tagGISSubstation& gData, const int nField);
	void	SetGISSubstation(tagGISSubstation& gData, const int nField, const	std::string strValue);

	const	std::string GetGISFeeder(tagGISFeeder& gData, const int nField);
	void	SetGISFeeder(tagGISFeeder& gData, const int nField, const	std::string strValue);

	const	std::string GetGISCompositeSwitch(tagGISCompositeSwitch& gData, const int nField);
	void	SetGISCompositeSwitch(tagGISCompositeSwitch& gData, const int nField, const	std::string strValue);

	const	std::string GetGISBreaker(tagGISBreaker& gData, const int nField);
	void	SetGISBreaker(tagGISBreaker& gData, const int nField, const	std::string strValue);

	const	std::string GetGISDisconnector(tagGISDisconnector& gData, const int nField);
	void	SetGISDisconnector(tagGISDisconnector& gData, const int nField, const	std::string strValue);

	const	std::string GetGISGroundDisconnector(tagGISGroundDisconnector& gData, const int nField);
	void	SetGISGroundDisconnector(tagGISGroundDisconnector& gData, const int nField, const	std::string strValue);

	const	std::string GetGISLoadBreakSwitch(tagGISLoadBreakSwitch& gData, const int nField);
	void	SetGISLoadBreakSwitch(tagGISLoadBreakSwitch& gData, const int nField, const	std::string strValue);

	const	std::string GetGISFuse(tagGISFuse& gData, const int nField);
	void	SetGISFuse(tagGISFuse& gData, const int nField, const	std::string strValue);

	const	std::string GetGISACLineSegment(tagGISACLineSegment& gData, const int nField);
	void	SetGISACLineSegment(tagGISACLineSegment& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPowerTransformer(tagGISPowerTransformer& gData, const int nField);
	void	SetGISPowerTransformer(tagGISPowerTransformer& gData, const int nField, const	std::string strValue);

	const	std::string GetGISConnLine(tagGISConnLine& gData, const int nField);
	void	SetGISConnLine(tagGISConnLine& gData, const int nField, const	std::string strValue);

	const	std::string GetGISBusbarSection(tagGISBusbarSection& gData, const int nField);
	void	SetGISBusbarSection(tagGISBusbarSection& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPole(tagGISPole& gData, const int nField);
	void	SetGISPole(tagGISPole& gData, const int nField, const	std::string strValue);

	const	std::string GetGISJunction(tagGISJunction& gData, const int nField);
	void	SetGISJunction(tagGISJunction& gData, const int nField, const	std::string strValue);

	const	std::string GetGISEnergyConsumer(tagGISEnergyConsumer& gData, const int nField);
	void	SetGISEnergyConsumer(tagGISEnergyConsumer& gData, const int nField, const	std::string strValue);

	const	std::string GetGISCompensator(tagGISCompensator& gData, const int nField);
	void	SetGISCompensator(tagGISCompensator& gData, const int nField, const	std::string strValue);

	const	std::string GetGISCapacitor(tagGISCapacitor& gData, const int nField);
	void	SetGISCapacitor(tagGISCapacitor& gData, const int nField, const	std::string strValue);

	const	std::string GetGISTerminal(tagGISTerminal& gData, const int nField);
	void	SetGISTerminal(tagGISTerminal& gData, const int nField, const	std::string strValue);

	const	std::string GetGISConnectivityNode(tagGISConnectivityNode& gData, const int nField);
	void	SetGISConnectivityNode(tagGISConnectivityNode& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPipe(tagGISPipe& gData, const int nField);
	void	SetGISPipe(tagGISPipe& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPT(tagGISPT& gData, const int nField);
	void	SetGISPT(tagGISPT& gData, const int nField, const	std::string strValue);

	const	std::string GetGISCT(tagGISCT& gData, const int nField);
	void	SetGISCT(tagGISCT& gData, const int nField, const	std::string strValue);

	const	std::string GetGISBLQ(tagGISBLQ& gData, const int nField);
	void	SetGISBLQ(tagGISBLQ& gData, const int nField, const	std::string strValue);

	const	std::string GetGISFaultIndicator(tagGISFaultIndicator& gData, const int nField);
	void	SetGISFaultIndicator(tagGISFaultIndicator& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPTCab(tagGISPTCab& gData, const int nField);
	void	SetGISPTCab(tagGISPTCab& gData, const int nField, const	std::string strValue);

	const	std::string GetGISGround(tagGISGround& gData, const int nField);
	void	SetGISGround(tagGISGround& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPTCABU(tagGISPTCABU& gData, const int nField);
	void	SetGISPTCABU(tagGISPTCABU& gData, const int nField, const	std::string strValue);

	const	std::string GetGISKWGXB(tagGISKWGXB& gData, const int nField);
	void	SetGISKWGXB(tagGISKWGXB& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPFWELL(tagGISPFWELL& gData, const int nField);
	void	SetGISPFWELL(tagGISPFWELL& gData, const int nField, const	std::string strValue);

	const	std::string GetGISPFTUNN(tagGISPFTUNN& gData, const int nField);
	void	SetGISPFTUNN(tagGISPFTUNN& gData, const int nField, const	std::string strValue);

	const	std::string GetGISOther(tagGISOther& gData, const int nField);
	void	SetGISOther(tagGISOther& gData, const int nField, const	std::string strValue);

	const	std::string GetGISZJ(tagGISZJ& gData, const int nField);
	void	SetGISZJ(tagGISZJ& gData, const int nField, const	std::string strValue);

public:
	void	InitializePSRType				(tagGISPSRType				& dBuf);
	void	InitializeRDF					(tagGISRDF					& dBuf);
	void	InitializeGeographicalRegion	(tagGISGeographicalRegion	& dBuf);
	void	InitializeSubGeographicalRegion	(tagGISSubGeographicalRegion& dBuf);
	void	InitializeBaseVoltage			(tagGISBaseVoltage			& dBuf);
	void	InitializeSubstation			(tagGISSubstation			& dBuf);
	void	InitializeFeeder				(tagGISFeeder				& dBuf);
	void	InitializeCompositeSwitch		(tagGISCompositeSwitch		& dBuf);
	void	InitializeBreaker				(tagGISBreaker				& dBuf);
	void	InitializeDisconnector			(tagGISDisconnector			& dBuf);
	void	InitializeLoadBreakSwitch		(tagGISLoadBreakSwitch		& dBuf);
	void	InitializeFuse					(tagGISFuse					& dBuf);
	void	InitializeGroundDisconnector	(tagGISGroundDisconnector	& dBuf);
	void	InitializeBusbarSection			(tagGISBusbarSection		& dBuf);
	void	InitializePole					(tagGISPole					& dBuf);
	void	InitializeJunction				(tagGISJunction				& dBuf);
	void	InitializeACLineSegment			(tagGISACLineSegment		& dBuf);
	void	InitializePowerTransformer		(tagGISPowerTransformer		& dBuf);
	void	InitializeConnLine				(tagGISConnLine				& dBuf);
	void	InitializeEnergyConsumer		(tagGISEnergyConsumer		& dBuf);
	void	InitializeCompensator			(tagGISCompensator			& dBuf);
	void	InitializeCapacitor				(tagGISCapacitor			& dBuf);
	void	InitializeTerminal				(tagGISTerminal				& dBuf);
	void	InitializeConnectivityNode		(tagGISConnectivityNode		& dBuf);
	void	InitializePipe					(tagGISPipe					& dBuf);
	void	InitializePT					(tagGISPT					& dBuf);
	void	InitializeCT					(tagGISCT					& dBuf);
	void	InitializeBLQ					(tagGISBLQ					& dBuf);
	void	InitializeFaultIndicator		(tagGISFaultIndicator		& dBuf);
	void	InitializePTCab					(tagGISPTCab				& dBuf);
	void	InitializeGround				(tagGISGround				& dBuf);
	void	InitializeOther					(tagGISOther				& dBuf);
	void	InitializePTCABU				(tagGISPTCABU				& dBuf);
	void	InitializeKWGXB					(tagGISKWGXB				& dBuf);
	void	InitializePFWELL				(tagGISPFWELL				& dBuf);
	void	InitializePFTUNN				(tagGISPFTUNN				& dBuf);

	void	InitializeZJ(tagGISZJ& dBuf);
	void	InitializeGraphic(tagGISGraphic& dBuf);

private:
	std::string	toString(tagGISVertex& ptVert);
	std::string	toString(const	std::string& strBuf);
	std::string	toString(const char* lpszBuf);
	std::string	toString(const double fBuf);
	std::string	toString(const float fBuf);
	std::string	toString(const int nBuf);
	std::string	toString(const short nBuf);
	std::string	toString(const unsigned char bBuf);

	void	toValue(tagGISVertex& ptVert, const char* lpszValue);
	void	toValue(std::string& strValue, const char* lpszValue);
	void	toValue(char* lpszRetValue, const char* lpszInValue);
	void	toValue(double& fValue, const char* lpszValue);
	void	toValue(float& fValue, const char* lpszValue);
	void	toValue(int& nValue, const char* lpszValue);
	void	toValue(short& nValue, const char* lpszValue);
	void	toValue(unsigned char& bValue, const char* lpszValue);
};
