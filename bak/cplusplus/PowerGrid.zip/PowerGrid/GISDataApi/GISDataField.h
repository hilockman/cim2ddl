#pragma  once

#include "GISDataDefine.h"
#include "../../MemDB/PGMemDB/PGMemDBDefine.h"
#include "../../MemDB/PGMemDB/PGMemDBEnum.h"

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#endif

#if !defined(__GNUG__) && !defined(__GNUC__)
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

static	tagGISField	g_GISRDFField[]=
{
	{	GISRDF_XmlnsRDF,		"xmlns:rdf",	"rdf",	0,	0,	},
	{	GISRDF_XmlnsCIM,		"xmlns:cim",	"cim",	0,	0,	},
};

static	tagGISField	g_GISPSRTypeField[]=
{
	{	GISPSRType_ResourceID,	"rdf:ID",							"ResID",		0,	0,	},
	{	GISPSRType_ObjectID,	"cim:IdentifiedObject.mRID",		"mRID",			0,	0,	},
	{	GISPSRType_Name,		"cim:IdentifiedObject.name",		"name",			0,	0,	},
	{	GISPSRType_Alias,		"cim:IdentifiedObject.aliasname",	"aliasname",	0,	0,	},
};

static	tagGISField	g_GISGeographicalRegionField[]=
{
	{	GISGeographicalRegion_ResourceID,	"rdf:ID",						"ResID",	0,	0,	},
	{	GISGeographicalRegion_ObjectID,		"cim:IdentifiedObject.mRID",	"mRID",		0,	0,	},
	{	GISGeographicalRegion_Name,			"cim:IdentifiedObject.name",	"name",		0,	0,	},
};

static	tagGISField	g_GISSubGeographicalRegionField[]=
{
	{	GISSubGeographicalRegion_ResourceID,	"rdf:ID",							"ResID",	0,	0,	},
	{	GISSubGeographicalRegion_ObjectID,		"cim:IdentifiedObject.mRID",		"mRID",		0,	0,	},
	{	GISSubGeographicalRegion_Name,			"cim:IdentifiedObject.name",		"name",		0,	0,	},
	{	GISSubGeographicalRegion_ParentTag,		"cim:SubGeographicalRegion.Region",	"Region",	0,	0,	},
	//{	GISSubGeographicalRegion_Parent,		"Parent",							"",			0,	0,	},
};

static	tagGISField	g_GISBaseVoltageField[]=
{
	{	GISBaseVoltage_ResourceID,		"rdf:ID",							"ResID",			0,	0,	},
	{	GISBaseVoltage_ObjectID,		"cim:IdentifiedObject.mRID",		"mRID",				0,	0,	},
	{	GISBaseVoltage_Name,			"cim:IdentifiedObject.name",		"name",				0,	0,	},
	{	GISBaseVoltage_DC,				"cim:BaseVoltage.isDC",				"isDC",				0,	0,	},
	{	GISBaseVoltage_NominalVoltage,	"cim:BaseVoltage.nominalVoltage",	"nominalVoltage",	0,	0,	},
};

static	tagGISField	g_GISSubstationField[]=
{
	{	GISSubstation_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISSubstation_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISSubstation_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISSubstation_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISSubstation_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISSubstation_ParentTag,		"cim:Substation.Region",				"Region",				0,	0,	},
	{	GISSubstation_Alias1,			"cim:Substation.AliasName",				"AliasName",			0,	0,	},
	{	GISSubstation_Alias2,			"cim:Substation.AliasName1",			"AliasName1",			0,	0,	},
	{	GISSubstation_HighVoltage,		"cim:Substation.HighVoltageLevel",		"HighVoltageLevel",		0,	0,	},
	{	GISSubstation_Component,		"cim:Substation.Component",				"Component",			0,	0,	},
	{	GISSubstation_SubstationType,	"cim:Substation.SubstationType",		"SubstationType",		0,	0,	},
	{	GISSubstation_Model,			"cim:Substation.Model",					"Model",				0,	0,	},
	{	GISSubstation_MvaCapacity,		"cim:Substation.MvaCapacity",			"MvaCapacity",			0,	0,	},
	{	GISSubstation_PlanCharacter,	"cim:Substation.PlanCharacter",			"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),	g_PGEnumDPlanCharacter,	},
	{	GISSubstation_Public,			"cim:Substation.isPublic",				"isPublic",				sizeof(g_PGEnumNoYes)/sizeof(tagMemDBEnumPair),				g_PGEnumNoYes,			},
	{	GISSubstation_BuildDate,		"cim:Substation.BuildDate",				"BuildDate",			0,	0,	},
	{	GISSubstation_RebuildDate,		"cim:Substation.RebuildDate",			"RebuildDate",			0,	0,	},
	{	GISSubstation_OutageDate,		"cim:Substation.OutageDate",			"OutageDate",			0,	0,	},
	{	GISSubstation_RunTimeSpan,		"cim:Substation.RunTimeSpan",			"RunTimeSpan",			0,	0,	},
	{	GISSubstation_TotalBay,			"cim:Substation.TotalBay",				"TotalBay",				0,	0,	},
	{	GISSubstation_FreeBay,			"cim:Substation.FreeBay",				"FreeBay",				0,	0,	},
	{	GISSubstation_TotalOutline,		"cim:Substation.TotalOutline",			"TotalOutline",			0,	0,	},
	{	GISSubstation_InuseOutline,		"cim:Substation.InuseOutline",			"InuseOutline",			0,	0,	},
	{	GISSubstation_EqX,				"cim:Substation.EqX",					"EqX",					0,	0,	},
	{	GISSubstation_ri_rerr,			"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISSubstation_ri_trep,			"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISSubstation_ri_rchk,			"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISSubstation_ri_tchk,			"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISSubstation_ri_tfloc,			"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISSubstation_ri_customer,		"cim:Conductor.ri_customer",			"ri_customer",			0,	0,	},
	{	GISSubstation_ri_load_rerr,		"cim:Conductor.ri_load_rerr",			"ri_load_rerr",			0,	0,	},
	{	GISSubstation_ri_load_trep,		"cim:Conductor.ri_load_trep",			"ri_load_trep",			0,	0,	},
	{	GISSubstation_ri_load_rchk,		"cim:Conductor.ri_load_rchk",			"ri_load_rchk",			0,	0,	},
	{	GISSubstation_ri_load_tchk,		"cim:Conductor.ri_load_tchk",			"ri_load_tchk",			0,	0,	},
	{	GISSubstation_ei_invest,		"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISSubstation_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISSubstation_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISSubstation_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISSubstation_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISSubstation_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISSubstation_Location,			"",										"Location",				0,	0,	},
	{	GISSubstation_Valid,			"",										"Valid",				0,	0,	},
};

static	tagGISField	g_GISFeederField[]=
{
	{	GISFeeder_ResourceID,		"rdf:ID",							"ResID",				0,	0,	},
	{	GISFeeder_PSRTypeTag,		"cim:PowerSystemResource.PSRType",	"PSRTypeTag",			0,	0,	},
	{	GISFeeder_ObjectID,			"cim:IdentifiedObject.mRID",		"mRID",					0,	0,	},
	{	GISFeeder_Name,				"cim:IdentifiedObject.name",		"name",					0,	0,	},
	{	GISFeeder_Desp,				"cim:IdentifiedObject.description",	"description",			0,	0,	},
	{	GISFeeder_ParentTag,		"cim:Feeder.BelongtoHVSubstation",	"BelongtoHVSubstation",	0,	0,	},
	{	GISFeeder_V,				"cim:Feeder.V",						"V",					0,	0,	},
	{	GISFeeder_P,				"cim:Feeder.P",						"P",					0,	0,	},
	{	GISFeeder_Q,				"cim:Feeder.Q",						"Q",					0,	0,	},
	{	GISFeeder_I,				"cim:Feeder.I",						"I",					0,	0,	},
	{	GISFeeder_Factor,			"cim:Feeder.Factor",				"Factor",				0,	0,	},
};

static	tagGISField	g_GISCompositeSwitchField[]=
{
	{	GISCompositeSwitch_ResourceID,			"rdf:ID",									"ResID",				0,	0,	},
	{	GISCompositeSwitch_PSRTypeTag,			"cim:PowerSystemResource.PSRType",			"PSRTypeTag",			0,	0,	},
	{	GISCompositeSwitch_ObjectID,			"cim:IdentifiedObject.mRID",				"mRID",					0,	0,	},
	{	GISCompositeSwitch_Name,				"cim:IdentifiedObject.name",				"name",					0,	0,	},
	{	GISCompositeSwitch_CompositeSwitchType,	"cim:CompositeSwitch.CompositeSwitchType",	"CompositeSwitchType",	0,	0,	},
	{	GISCompositeSwitch_ParentTag,			"cim:Equipment.EquipmentContainer",			"EquipmentContainer",	0,	0,	},
};

static	tagGISField	g_GISBreakerField[]=
{
	{	GISBreaker_ResourceID,			"rdf:ID",								"ResID",				0,	0,	},
	{	GISBreaker_PSRTypeTag,			"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISBreaker_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISBreaker_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISBreaker_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISBreaker_Usage,				"cim:Switch.usage",						"usage",				0,	0,	},
	{	GISBreaker_NormalOpen,			"cim:Switch.normalOpen",				"normalOpen",			sizeof(g_PGEnumTrueFalse)/sizeof(tagMemDBEnumPair),				g_PGEnumTrueFalse,				},
	{	GISBreaker_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISBreaker_BaseVoltageTag,		"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISBreaker_Status,				"cim:Breaker.Status",					"Status",				sizeof(g_PGEnumCloseOpenStatus)/sizeof(tagMemDBEnumPair),		g_PGEnumCloseOpenStatus,		},
	{	GISBreaker_Model,				"cim:Breaker.Model",					"Model",				0,	0,	},
	{	GISBreaker_BreakerType,			"cim:Breaker.Type",						"Type",					sizeof(g_PGEnumBreaker_BreakerType)/sizeof(tagMemDBEnumPair),	g_PGEnumBreaker_BreakerType,	},
	{	GISBreaker_ri_rerr,				"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISBreaker_ri_trep,				"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISBreaker_ri_rchk,				"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISBreaker_ri_tchk,				"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISBreaker_ri_tfloc,			"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISBreaker_ri_rswitch,			"cim:Conductor.ri_rswitch",				"ri_rswitch",			0,	0,	},
	{	GISBreaker_ri_tswitch,			"cim:Conductor.ri_tswitch",				"ri_tswitch",			0,	0,	},
	{	GISBreaker_ei_invest,			"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISBreaker_RTLevel,				"cim:Breaker.RTLevel",					"RTLevel",				sizeof(g_PGEnumDRTLevelType)/sizeof(tagMemDBEnumPair),			g_PGEnumDRTLevelType,			},
	{	GISBreaker_CommMode,			"cim:Breaker.CommMode",					"CommMode",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),			g_PGEnumDCommModeType,			},
	{	GISBreaker_PlanCharacter,		"cim:Breaker.PlanCharacter",			"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),		g_PGEnumDPlanCharacter,			},
	{	GISBreaker_BuildDate,			"cim:Breaker.BuildDate",				"BuildDate",			0,	0,	},
	{	GISBreaker_ReBuildDate,			"cim:Breaker.RebuildDate",				"RebuildDate",			0,	0,	},
	{	GISBreaker_OutageDate,			"cim:Breaker.OutageDate",				"OutageDate",			0,	0,	},
	{	GISBreaker_RunTimeSpan,			"cim:Breaker.RunTimeSpan",				"RunTimeSpan",			0,	0,	},
	{	GISBreaker_Parent,				"",										"Parent",				0,	0,	},
	{	GISBreaker_INode,				"",										"NodeI",				0,	0,	},
	{	GISBreaker_ZNode,				"",										"NodeZ",				0,	0,	},
	{	GISBreaker_SubIdx,				"",										"SubIdx",				0,	0,	},
	{	GISBreaker_INodeIdx,			"",										"INodeIdx",				0,	0,	},
	{	GISBreaker_ZNodeIdx,			"",										"ZNodeIdx",				0,	0,	},
	{	GISBreaker_Coordinate,			"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISBreaker_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISBreaker_SymbolSize,			"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISBreaker_SymbolAngle,			"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISBreaker_GraphPath,			"",										"GraphPath",			0,	0,	},
	{	GISBreaker_Location,			"",										"Location",				0,	0,	},
	{	GISBreaker_GraphSize,			"",										"GraphSize",			0,	0,	},
	{	GISBreaker_InSubstation,		"",										"InSubstation",			0,	0,	},
};

static	tagGISField	g_GISDisconnectorField[]=
{
	{	GISDisconnector_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISDisconnector_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISDisconnector_ObjectID,		"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISDisconnector_Name,			"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISDisconnector_Unit,			"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISDisconnector_NormalOpen,		"cim:Switch.normalOpen",				"normalOpen",			sizeof(g_PGEnumTrueFalse)/sizeof(tagMemDBEnumPair),						g_PGEnumTrueFalse,						},
	{	GISDisconnector_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISDisconnector_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISDisconnector_Status,			"cim:Disconnector.Status",				"Status",				sizeof(g_PGEnumCloseOpenStatus)/sizeof(tagMemDBEnumPair),				g_PGEnumCloseOpenStatus,				},
	{	GISDisconnector_Model,			"cim:Disconnector.Model",				"Model",				0,	0,	},
	{	GISDisconnector_BreakerType,	"cim:Disconnector.Type",				"Type",					sizeof(g_PGEnumDisconnector_Disconnectortype)/sizeof(tagMemDBEnumPair),	g_PGEnumDisconnector_Disconnectortype,	},
	{	GISDisconnector_ri_rerr,		"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISDisconnector_ri_trep,		"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISDisconnector_ri_rchk,		"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISDisconnector_ri_tchk,		"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISDisconnector_ri_tfloc,		"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISDisconnector_ri_rswitch,		"cim:Conductor.ri_rswitch",				"ri_rswitch",			0,	0,	},
	{	GISDisconnector_ri_tswitch,		"cim:Conductor.ri_tswitch",				"ri_tswitch",			0,	0,	},
	{	GISDisconnector_ei_invest,		"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISDisconnector_RTLevel,		"cim:Disconnector.RTLevel",				"RTLevel",				sizeof(g_PGEnumDRTLevelType)/sizeof(tagMemDBEnumPair),					g_PGEnumDRTLevelType,					},
	{	GISDisconnector_CommMode,		"cim:Disconnector.CommMode",			"CommMode",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),					g_PGEnumDCommModeType,					},
	{	GISDisconnector_PlanCharacter,	"cim:Disconnector.PlanCharacter",		"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISDisconnector_BuildDate,		"cim:Disconnector.RebuildDate",			"RebuildDate",			0,	0,	},
	{	GISDisconnector_ReBuildDate,	"cim:Disconnector.OutageDate",			"OutageDate",			0,	0,	},
	{	GISDisconnector_OutageDate,		"cim:Disconnector.RunTimeSpan",			"RunTimeSpan",			0,	0,	},
	{	GISDisconnector_RunTimeSpan,	"cim:Disconnector.BuildDate",			"BuildDate",			0,	0,	},
	{	GISDisconnector_Parent,			"",										"Parent",				0,	0,	},
	{	GISDisconnector_INode,			"",										"NodeI",				0,	0,	},
	{	GISDisconnector_ZNode,			"",										"NodeZ",				0,	0,	},
	{	GISDisconnector_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISDisconnector_INodeIdx,		"",										"INodeIdx",				0,	0,	},
	{	GISDisconnector_ZNodeIdx,		"",										"ZNodeIdx",				0,	0,	},
	{	GISDisconnector_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISDisconnector_SymbolID,		"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISDisconnector_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISDisconnector_SymbolAngle,	"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISDisconnector_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISDisconnector_Location,		"",										"Location",				0,	0,	},
	{	GISDisconnector_GraphSize,		"",										"GraphSize",			0,	0,	},
	{	GISDisconnector_InSubstation,	"",										"InSubstation",			0,	0,	},
};

static	tagGISField	g_GISGroundDisconnectorField[]=
{
	{	GISGroundDisconnector_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISGroundDisconnector_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISGroundDisconnector_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISGroundDisconnector_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISGroundDisconnector_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISGroundDisconnector_NormalOpen,		"cim:Switch.normalOpen",				"normalOpen",			sizeof(g_PGEnumTrueFalse)/sizeof(tagMemDBEnumPair),						g_PGEnumTrueFalse,						},
	{	GISGroundDisconnector_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISGroundDisconnector_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISGroundDisconnector_Model,			"cim:GroundDisconnector.Model",			"Model",				0,	0,	},
	{	GISGroundDisconnector_RTLevel,			"cim:GroundDisconnector.RTLevel",		"RTLevel",				sizeof(g_PGEnumDRTLevelType)/sizeof(tagMemDBEnumPair),					g_PGEnumDRTLevelType,					},
	{	GISGroundDisconnector_CommMode,			"cim:GroundDisconnector.CommMode",		"CommMode",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),					g_PGEnumDCommModeType,					},
	{	GISGroundDisconnector_PlanCharacter,	"cim:GroundDisconnector.PlanCharacter",	"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISGroundDisconnector_BuildDate,		"cim:GroundDisconnector.RebuildDate",	"RebuildDate",			0,	0,	},
	{	GISGroundDisconnector_ReBuildDate,		"cim:GroundDisconnector.OutageDate",	"OutageDate",			0,	0,	},
	{	GISGroundDisconnector_OutageDate,		"cim:GroundDisconnector.RunTimeSpan",	"RunTimeSpan",			0,	0,	},
	{	GISGroundDisconnector_RunTimeSpan,		"cim:GroundDisconnector.BuildDate",		"BuildDate",			0,	0,	},
	{	GISGroundDisconnector_Parent,			"",										"Parent",				0,	0,	},
	{	GISGroundDisconnector_Node,				"",										"Node",					0,	0,	},
	{	GISGroundDisconnector_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISGroundDisconnector_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISGroundDisconnector_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISGroundDisconnector_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISGroundDisconnector_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISGroundDisconnector_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISGroundDisconnector_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISGroundDisconnector_Location,			"",										"Location",				0,	0,	},
	{	GISGroundDisconnector_GraphSize,		"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISLoadBreakSwitchField[]=
{
	{	GISLoadBreakSwitch_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISLoadBreakSwitch_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISLoadBreakSwitch_ObjectID,		"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISLoadBreakSwitch_Name,			"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISLoadBreakSwitch_Unit,			"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISLoadBreakSwitch_NormalOpen,		"cim:Switch.normalOpen",				"normalOpen",			sizeof(g_PGEnumTrueFalse)/sizeof(tagMemDBEnumPair),						g_PGEnumTrueFalse,						},
	{	GISLoadBreakSwitch_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISLoadBreakSwitch_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISLoadBreakSwitch_Status,			"cim:LoadBreakSwitch.Status",			"Status",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),					g_PGEnumDCommModeType,					},
	{	GISLoadBreakSwitch_Model,			"cim:LoadBreakSwitch.Model",			"Model",				0,	0,	},
	{	GISLoadBreakSwitch_BreakerType,		"cim:LoadBreakSwitch.Type",				"Type",					sizeof(g_PGEnumDRTLevelType)/sizeof(tagMemDBEnumPair),					g_PGEnumDRTLevelType,					},
	{	GISLoadBreakSwitch_ri_rerr,			"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISLoadBreakSwitch_ri_trep,			"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISLoadBreakSwitch_ri_rchk,			"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISLoadBreakSwitch_ri_tchk,			"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISLoadBreakSwitch_ri_tfloc,		"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISLoadBreakSwitch_ri_rswitch,		"cim:Conductor.ri_rswitch",				"ri_rswitch",			0,	0,	},
	{	GISLoadBreakSwitch_ri_tswitch,		"cim:Conductor.ri_tswitch",				"ri_tswitch",			0,	0,	},
	{	GISLoadBreakSwitch_ei_invest,		"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISLoadBreakSwitch_RTLevel,			"cim:LoadBreakSwitch.RTLevel",			"RTLevel",				sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISLoadBreakSwitch_CommMode,		"cim:LoadBreakSwitch.CommMode",			"CommMode",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),					g_PGEnumDCommModeType,					},
	{	GISLoadBreakSwitch_PlanCharacter,	"cim:LoadBreakSwitch.PlanCharacter",	"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISLoadBreakSwitch_BuildDate,		"cim:LoadBreakSwitch.BuildDate",		"BuildDate",			0,	0,	},
	{	GISLoadBreakSwitch_ReBuildDate,		"cim:LoadBreakSwitch.RebuildDate",		"RebuildDate",			0,	0,	},
	{	GISLoadBreakSwitch_OutageDate,		"cim:LoadBreakSwitch.OutageDate",		"OutageDate",			0,	0,	},
	{	GISLoadBreakSwitch_RunTimeSpan,		"cim:LoadBreakSwitch.RunTimeSpan",		"RunTimeSpan",			0,	0,	},
	{	GISLoadBreakSwitch_Parent,			"",										"Parent",				0,	0,	},
	{	GISLoadBreakSwitch_INode,			"",										"NodeI",				0,	0,	},
	{	GISLoadBreakSwitch_ZNode,			"",										"NodeZ",				0,	0,	},
	{	GISLoadBreakSwitch_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISLoadBreakSwitch_INodeIdx,		"",										"INodeIdx",				0,	0,	},
	{	GISLoadBreakSwitch_ZNodeIdx,		"",										"ZNodeIdx",				0,	0,	},
	{	GISLoadBreakSwitch_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISLoadBreakSwitch_SymbolID,		"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISLoadBreakSwitch_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISLoadBreakSwitch_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISLoadBreakSwitch_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISLoadBreakSwitch_Location,		"",										"Location",				0,	0,	},
	{	GISLoadBreakSwitch_GraphSize,		"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISFuseField[]=
{
	{	GISFuse_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISFuse_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISFuse_ObjectID,		"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISFuse_Name,			"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISFuse_Unit,			"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISFuse_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISFuse_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISFuse_Status,			"cim:Fuse.Status",						"Status",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),		g_PGEnumDCommModeType,					},
	{	GISFuse_Model,			"cim:Fuse.Model",						"Model",				0,	0,	},
	{	GISFuse_BreakerType,	"cim:Fuse.Type",						"Type",					sizeof(g_PGEnumDRTLevelType)/sizeof(tagMemDBEnumPair),		g_PGEnumDRTLevelType,					},
	{	GISFuse_ri_rerr,		"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISFuse_ri_trep,		"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISFuse_ri_rchk,		"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISFuse_ri_tchk,		"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISFuse_ri_tfloc,		"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISFuse_ri_rswitch,		"cim:Conductor.ri_rswitch",				"ri_rswitch",			0,	0,	},
	{	GISFuse_ri_tswitch,		"cim:Conductor.ri_tswitch",				"ri_tswitch",			0,	0,	},
	{	GISFuse_ei_invest,		"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISFuse_RTLevel,		"cim:Fuse.RTLevel",						"RTLevel",				sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),	g_PGEnumDPlanCharacter,					},
	{	GISFuse_CommMode,		"cim:Fuse.CommMode",					"CommMode",				sizeof(g_PGEnumDCommModeType)/sizeof(tagMemDBEnumPair),		g_PGEnumDCommModeType,					},
	{	GISFuse_PlanCharacter,	"cim:Fuse.PlanCharacter",				"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),	g_PGEnumDPlanCharacter,					},
	{	GISFuse_BuildDate,		"cim:Fuse.BuildDate",					"BuildDate",			0,	0,	},
	{	GISFuse_ReBuildDate,	"cim:Fuse.RebuildDate",					"RebuildDate",			0,	0,	},
	{	GISFuse_OutageDate,		"cim:Fuse.OutageDate",					"OutageDate",			0,	0,	},
	{	GISFuse_RunTimeSpan,	"cim:Fuse.RunTimeSpan",					"RunTimeSpan",			0,	0,	},
	{	GISFuse_Parent,			"",										"Parent",				0,	0,	},
	{	GISFuse_INode,			"",										"NodeI",				0,	0,	},
	{	GISFuse_ZNode,			"",										"NodeZ",				0,	0,	},
	{	GISFuse_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISFuse_INodeIdx,		"",										"INodeIdx",				0,	0,	},
	{	GISFuse_ZNodeIdx,		"",										"ZNodeIdx",				0,	0,	},
	{	GISFuse_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISFuse_SymbolID,		"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISFuse_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISFuse_SymbolAngle,	"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISFuse_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISFuse_Location,		"",										"Location",				0,	0,	},
	{	GISFuse_GraphSize,		"",										"GraphSize",			0,	0,	},
};

//{	GISACLineSegment_AssetModel,		"cim:IdentifiedObject.MODEL",			"AssetModel",			0,	0,	},
	//{	GISACLineSegment_Length,			"cim:IdentifiedObject.LENGTH",			"Length",				0,	0,	},
static	tagGISField	g_GISACLineSegmentField[]=
{
	{	GISACLineSegment_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISACLineSegment_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISACLineSegment_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISACLineSegment_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISACLineSegment_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISACLineSegment_AssetModel,		"cim:Conductor.AssetModel",				"AssetModel",			0,	0,	},
	{	GISACLineSegment_LineType,			"cim:IdentifiedObject.DWID",			"DWID",					0,	0,	},
	{	GISACLineSegment_AutoLength,		"cim:Conductor.autolength",				"autolength",			sizeof(g_PGEnumACLineSegment_AutoLength)/sizeof(tagMemDBEnumPair),	g_PGEnumACLineSegment_AutoLength,		},
	{	GISACLineSegment_Length,			"cim:Conductor.length",					"length",				0,	0,	},
	{	GISACLineSegment_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISACLineSegment_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISACLineSegment_LineTag,			"cim:ACLineSegment.MemberOf_Line",		"MemberOf_Line",		0,	0,	},
	{	GISACLineSegment_Type,				"cim:ACLineSegment.Type",				"Type",					sizeof(g_PGEnumACLineSegment_LineType)/sizeof(tagMemDBEnumPair),	g_PGEnumACLineSegment_LineType,			},
	{	GISACLineSegment_PlanCharacter,		"cim:ACLineSegment.PlanCharacter",		"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),			g_PGEnumDPlanCharacter,		},
	{	GISACLineSegment_RunStatus,			"cim:ACLineSegment.RunStatus",			"RunStatus",			sizeof(g_PGEnumCloseOpenStatus)/sizeof(tagMemDBEnumPair),			g_PGEnumCloseOpenStatus,	},
	{	GISACLineSegment_AreaCategory,		"cim:ACLineSegment.AreaCategory",		"AreaCategory",			sizeof(g_PGEnumAreaCategory)/sizeof(tagMemDBEnumPair),				g_PGEnumAreaCategory,		},
	{	GISACLineSegment_LineLoadP,			"cim:ACLineSegment.LineLoadP",			"LineLoadP",			0,	0,	},
	{	GISACLineSegment_LineLoadFactor,	"cim:ACLineSegment.LineLoadFactor",		"LineLoadFactor",		0,	0,	},
	{	GISACLineSegment_LineCapacitor,		"cim:ACLineSegment.LineCapacitor",		"LineCapacitor",		0,	0,	},
	{	GISACLineSegment_r,					"cim:Conductor.r",						"r",					0,	0,	},
	{	GISACLineSegment_x,					"cim:Conductor.x",						"x",					0,	0,	},
	{	GISACLineSegment_g,					"cim:Conductor.gch",					"gch",					0,	0,	},
	{	GISACLineSegment_b,					"cim:Conductor.bch",					"bch",					0,	0,	},
	{	GISACLineSegment_ri_unitrerr,		"cim:Conductor.ri_unitrerr",			"ri_unitrerr",			0,	0,	},
	{	GISACLineSegment_ri_unittrep,		"cim:Conductor.ri_unittrep",			"ri_unittrep",			0,	0,	},
	{	GISACLineSegment_ri_unitrchk,		"cim:Conductor.ri_unitrchk",			"ri_unitrchk",			0,	0,	},
	{	GISACLineSegment_ri_unittchk,		"cim:Conductor.ri_unittchk",			"ri_unittchk",			0,	0,	},
	{	GISACLineSegment_ei_unitinvest,		"cim:Conductor.ei_unitinvest",			"ei_unitinvest",		0,	0,	},
	{	GISACLineSegment_ri_rerr,			"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISACLineSegment_ri_trep,			"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISACLineSegment_ri_rchk,			"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISACLineSegment_ri_tchk,			"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISACLineSegment_ri_tfloc,			"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISACLineSegment_ri_rswitch,		"cim:Conductor.ri_rswitch",				"ri_rswitch",			0,	0,	},
	{	GISACLineSegment_ri_tswitch,		"cim:Conductor.ri_tswitch",				"ri_tswitch",			0,	0,	},
	{	GISACLineSegment_ri_tdelay,			"cim:Conductor.ri_tdelay",				"ri_tdelay",			0,	0,	},
	{	GISACLineSegment_ri_customer,		"cim:Conductor.ri_customer",			"ri_customer",			0,	0,	},
	{	GISACLineSegment_ri_load_rerr,		"cim:Conductor.ri_load_rerr",			"ri_load_rerr",			0,	0,	},
	{	GISACLineSegment_ri_load_trep,		"cim:Conductor.ri_load_trep",			"ri_load_trep",			0,	0,	},
	{	GISACLineSegment_ri_load_rchk,		"cim:Conductor.ri_load_rchk",			"ri_load_rchk",			0,	0,	},
	{	GISACLineSegment_ri_load_tchk,		"cim:Conductor.ri_load_tchk",			"ri_load_tchk",			0,	0,	},
	{	GISACLineSegment_ei_invest,			"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISACLineSegment_BuildDate,			"cim:ACLineSegment.BuildDate",			"BuildDate",			0,	0,	},
	{	GISACLineSegment_ReBuildDate,		"cim:ACLineSegment.RebuildDate",		"RebuildDate",			0,	0,	},
	{	GISACLineSegment_OutageDate,		"cim:ACLineSegment.OutageDate",			"OutageDate",			0,	0,	},
	{	GISACLineSegment_RunTimeSpan,		"cim:ACLineSegment.RunTimeSpan",		"RunTimeSpan",			0,	0,	},
	{	GISACLineSegment_iStatus,			"cim:ACLineSegment.iStatus",			"iStatus",				sizeof(g_PGEnumCloseOpenStatus)/sizeof(tagMemDBEnumPair),			g_PGEnumCloseOpenStatus,	},
	{	GISACLineSegment_zStatus,			"cim:ACLineSegment.zStatus",			"zStatus",				sizeof(g_PGEnumCloseOpenStatus)/sizeof(tagMemDBEnumPair),			g_PGEnumCloseOpenStatus,	},
	{	GISACLineSegment_Feeder,			"",										"Feeder",				0,	0,	},
	{	GISACLineSegment_INode,				"",										"NodeI",				0,	0,	},
	{	GISACLineSegment_ZNode,				"",										"NodeZ",				0,	0,	},
	{	GISACLineSegment_SubITag,			"",										"SubITag",				0,	0,	},
	{	GISACLineSegment_SubZTag,			"",										"SubZTag",				0,	0,	},
	{	GISACLineSegment_JointEquipmentIType,"",									"EntityIType",			0,	0,	},
	{	GISACLineSegment_JointEquipmentZType,"",									"EntityZType",			0,	0,	},
	{	GISACLineSegment_JointEquipmentI,	"",										"EntityI",				0,	0,	},
	{	GISACLineSegment_JointEquipmentZ,	"",										"EntityZ",				0,	0,	},
	{	GISACLineSegment_ContainerIdx,		"",										"ContainerIdx",			0,	0,	},
	{	GISACLineSegment_SubIIdx,			"",										"SubIIdx",				0,	0,	},
	{	GISACLineSegment_SubZIdx,			"",										"SubZIdx",				0,	0,	},
	{	GISACLineSegment_INodeIdx,			"",										"INodeIdx",				0,	0,	},
	{	GISACLineSegment_ZNodeIdx,			"",										"ZNodeIdx",				0,	0,	},
	{	GISACLineSegment_Flag,				"",										"Flag",					0,	0,	},
	{	GISACLineSegment_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISACLineSegment_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISACLineSegment_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISACLineSegment_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISACLineSegment_GraphPath,			"",										"GraphPath",			0,	0,	},
};

static	tagGISField	g_GISPowerTransformerField[]=
{
	{	GISPowerTransformer_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISPowerTransformer_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISPowerTransformer_ObjectID,		"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISPowerTransformer_Name,			"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISPowerTransformer_Unit,			"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISPowerTransformer_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISPowerTransformer_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISPowerTransformer_RatedCapacity,	"cim:IdentifiedObject.RATEDCAPACITY",	"RatedCapacity",		0,	0,	},
	{	GISPowerTransformer_Model,			"cim:PowerTransformer.Model",			"Model",				0,	0,	},
	{	GISPowerTransformer_PlanCharacter,	"cim:PowerTransformer.PlanCharacter",	"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),	g_PGEnumDPlanCharacter,	},
	{	GISPowerTransformer_Distribution,	"cim:PowerTransformer.isDistribution",	"isDistribution",		sizeof(g_PGEnumNoYes)/sizeof(tagMemDBEnumPair),				g_PGEnumNoYes,			},
	{	GISPowerTransformer_Public,			"cim:PowerTransformer.isPublic",		"isPublic",				sizeof(g_PGEnumNoYes)/sizeof(tagMemDBEnumPair),				g_PGEnumNoYes,			},
	{	GISPowerTransformer_BuildDate,		"cim:PowerTransformer.BuildDate",		"BuildDate",			0,	0,	},
	{	GISPowerTransformer_ReBuildDate,	"cim:PowerTransformer.RebuildDate",		"RebuildDate",			0,	0,	},
	{	GISPowerTransformer_OutageDate,		"cim:PowerTransformer.OutageDate",		"OutageDate",			0,	0,	},
	{	GISPowerTransformer_RunTimeSpan,	"cim:PowerTransformer.RunTimeSpan",		"RunTimeSpan",			0,	0,	},
	{	GISPowerTransformer_ManuDate,		"cim:PowerTransformer.ManuDate",		"ManuDate",				0,	0,	},
	{	GISPowerTransformer_ConstructDate,	"cim:PowerTransformer.ConstructDate",	"ConstructDate",		0,	0,	},
	{	GISPowerTransformer_Parent,			"",										"Parent",				0,	0,	},
	{	GISPowerTransformer_NodeH,			"",										"NodeH",				0,	0,	},
	{	GISPowerTransformer_NodeM,			"",										"NodeM",				0,	0,	},
	{	GISPowerTransformer_NodeL,			"",										"NodeL",				0,	0,	},
	{	GISPowerTransformer_VoltH,			"",										"VoltH",				0,	0,	},
	{	GISPowerTransformer_VoltM,			"",										"VoltM",				0,	0,	},
	{	GISPowerTransformer_VoltL,			"",										"VoltL",				0,	0,	},
	{	GISPowerTransformer_ri_rerr,		"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISPowerTransformer_ri_trep,		"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISPowerTransformer_ri_rchk,		"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISPowerTransformer_ri_tchk,		"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISPowerTransformer_ri_tfloc,		"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISPowerTransformer_ri_rswitch,		"cim:Conductor.ri_rswitch",				"ri_rswitch",			0,	0,	},
	{	GISPowerTransformer_ri_tswitch,		"cim:Conductor.ri_tswitch",				"ri_tswitch",			0,	0,	},
	{	GISPowerTransformer_ri_customer,	"cim:Conductor.ri_customer",			"ri_customer",			0,	0,	},
	{	GISPowerTransformer_ri_load_rerr,	"cim:Conductor.ri_load_rerr",			"ri_load_rerr",			0,	0,	},
	{	GISPowerTransformer_ri_load_trep,	"cim:Conductor.ri_load_trep",			"ri_load_trep",			0,	0,	},
	{	GISPowerTransformer_ri_load_rchk,	"cim:Conductor.ri_load_rchk",			"ri_load_rchk",			0,	0,	},
	{	GISPowerTransformer_ri_load_tchk,	"cim:Conductor.ri_load_tchk",			"ri_load_tchk",			0,	0,	},
	{	GISPowerTransformer_ei_invest,		"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISPowerTransformer_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISPowerTransformer_NodeHIdx,		"",										"NodeHIdx",				0,	0,	},
	{	GISPowerTransformer_NodeMIdx,		"",										"NodeMIdx",				0,	0,	},
	{	GISPowerTransformer_NodeLIdx,		"",										"NodeLIdx",				0,	0,	},
	{	GISPowerTransformer_WindNum,		"",										"WindNum",				0,	0,	},
	{	GISPowerTransformer_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISPowerTransformer_SymbolID,		"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISPowerTransformer_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISPowerTransformer_SymbolAngle,	"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISPowerTransformer_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISPowerTransformer_Location,		"",										"Location",				0,	0,	},
	{	GISPowerTransformer_VertexH,		"",										"VertexH",				0,	0,	},
	{	GISPowerTransformer_VertexM,		"",										"VertexM",				0,	0,	},
	{	GISPowerTransformer_VertexL,		"",										"VertexL",				0,	0,	},
	{	GISPowerTransformer_GraphSize,		"",										"GraphSize",			0,	0,	},
	{	GISPowerTransformer_P,				"",										"P",					0,	0,	},
	{	GISPowerTransformer_Q,				"",										"Q",					0,	0,	},
};

static	tagGISField	g_GISConnLineField[]=
{
	{	GISConnLine_ResourceID,			"rdf:ID",								"ResID",				0,	0,	},
	{	GISConnLine_PSRTypeTag,			"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISConnLine_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISConnLine_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISConnLine_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISConnLine_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISConnLine_BaseVoltageTag,		"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISConnLine_Parent,				"",										"Parent",				0,	0,	},
	{	GISConnLine_NodeI,				"",										"NodeI",				0,	0,	},
	{	GISConnLine_NodeZ,				"",										"NodeZ",				0,	0,	},
	{	GISConnLine_SubIdx,				"",										"SubIdx",				0,	0,	},
	{	GISConnLine_INodeIdx,			"",										"INodeIdx",				0,	0,	},
	{	GISConnLine_ZNodeIdx,			"",										"ZNodeIdx",				0,	0,	},
	{	GISConnLine_Coordinate,			"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISConnLine_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISConnLine_SymbolSize,			"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISConnLine_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISConnLine_GraphPath,			"",										"GraphPath",			0,	0,	},
};

static	tagGISField	g_GISBusbarSectionField[]=
{
	{	GISBusbarSection_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISBusbarSection_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISBusbarSection_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISBusbarSection_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISBusbarSection_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISBusbarSection_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISBusbarSection_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISBusbarSection_Parent,			"",										"Parent",				0,	0,	},
	{	GISBusbarSection_Node,				"",										"Node",					0,	0,	},
	{	GISBusbarSection_ri_rerr,			"cim:Conductor.ri_rerr",				"ri_rerr",				0,	0,	},
	{	GISBusbarSection_ri_trep,			"cim:Conductor.ri_trep",				"ri_trep",				0,	0,	},
	{	GISBusbarSection_ri_rchk,			"cim:Conductor.ri_rchk",				"ri_rchk",				0,	0,	},
	{	GISBusbarSection_ri_tchk,			"cim:Conductor.ri_tchk",				"ri_tchk",				0,	0,	},
	{	GISBusbarSection_ri_tfloc,			"cim:Conductor.ri_tfloc",				"ri_tfloc",				0,	0,	},
	{	GISBusbarSection_ri_customer,		"cim:Conductor.ri_customer",			"ri_customer",			0,	0,	},
	{	GISBusbarSection_ri_load_rerr,		"cim:Conductor.ri_load_rerr",			"ri_load_rerr",			0,	0,	},
	{	GISBusbarSection_ri_load_trep,		"cim:Conductor.ri_load_trep",			"ri_load_trep",			0,	0,	},
	{	GISBusbarSection_ri_load_rchk,		"cim:Conductor.ri_load_rchk",			"ri_load_rchk",			0,	0,	},
	{	GISBusbarSection_ri_load_tchk,		"cim:Conductor.ri_load_tchk",			"ri_load_tchk",			0,	0,	},
	{	GISBusbarSection_ei_invest,			"cim:Conductor.ei_invest",				"ei_invest",			0,	0,	},
	{	GISBusbarSection_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISBusbarSection_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISBusbarSection_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISBusbarSection_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISBusbarSection_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISBusbarSection_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISBusbarSection_GraphPath,			"",										"GraphPath",			0,	0,	},
};

static	tagGISField	g_GISPoleField[]=
{
	{	GISPole_ResourceID,			"rdf:ID",								"ResID",				0,	0,	},
	{	GISPole_PSRTypeTag,			"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISPole_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISPole_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISPole_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISPole_aliasName,			"cim:IdentifiedObject.aliasName",		"aliasName",			0,	0,	},
	{	GISPole_description,		"cim:IdentifiedObject.description",		"description",			0,	0,	},
	{	GISPole_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISPole_BaseVoltageTag,		"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISPole_BuildDate,			"cim:Pole.BuildDate",					"BuildDate",			0,	0,	},
	{	GISPole_ReBuildDate,		"cim:Pole.RebuildDate",					"RebuildDate",			0,	0,	},
	{	GISPole_OutageDate,			"cim:Pole.OutageDate",					"OutageDate",			0,	0,	},
	{	GISPole_RunTimeSpan,		"cim:Pole.RunTimeSpan",					"RunTimeSpan",			0,	0,	},
	{	GISPole_PlanCharacter,		"cim:Pole.PlanCharacter",				"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISPole_Parent,				"",										"Parent",				0,	0,	},
	{	GISPole_Node,				"",										"Node",					0,	0,	},
	{	GISPole_SubIdx,				"",										"SubIdx",				0,	0,	},
	{	GISPole_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISPole_Coordinate,			"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISPole_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISPole_SymbolSize,			"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISPole_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISPole_GraphPath,			"",										"GraphPath",			0,	0,	},
	{	GISPole_Location,			"",										"Location",				0,	0,	},
	{	GISPole_GraphSize,			"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISJunctionField[]=
{
	{	GISJunction_ResourceID,			"rdf:ID",								"ResID",				0,	0,	},
	{	GISJunction_PSRTypeTag,			"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISJunction_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISJunction_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISJunction_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISJunction_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISJunction_BaseVoltageTag,		"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISJunction_BuildDate,			"cim:Junction.BuildDate",				"BuildDate",			0,	0,	},
	{	GISJunction_ReBuildDate,		"cim:Junction.RebuildDate",				"RebuildDate",			0,	0,	},
	{	GISJunction_OutageDate,			"cim:Junction.OutageDate",				"OutageDate",			0,	0,	},
	{	GISJunction_RunTimeSpan,		"cim:Junction.RunTimeSpan",				"RunTimeSpan",			0,	0,	},
	{	GISJunction_PlanCharacter,		"cim:Junction.PlanCharacter",			"PlanCharacter",		sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISJunction_Parent,				"",										"Parent",				0,	0,	},
	{	GISJunction_Node,				"",										"Node",					0,	0,	},
	{	GISJunction_SubIdx,				"",										"SubIdx",				0,	0,	},
	{	GISJunction_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISJunction_Coordinate,			"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISJunction_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISJunction_SymbolSize,			"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISJunction_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISJunction_GraphPath,			"",										"GraphPath",			0,	0,	},
	{	GISJunction_Location,			"",										"Location",				0,	0,	},
	{	GISJunction_GraphSize,			"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISEnergyConsumerField[]=
{
	{	GISEnergyConsumer_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISEnergyConsumer_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISEnergyConsumer_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISEnergyConsumer_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISEnergyConsumer_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISEnergyConsumer_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISEnergyConsumer_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISEnergyConsumer_BelongPSRTag,		"cim:EnergyConsumer.MemberOf_PSR",		"MemberOf_PSR",			0,	0,	},
	{	GISEnergyConsumer_Public,			"cim:EnergyConsumer.isPublic",			"Public",				sizeof(g_PGEnumNoYes)/sizeof(tagMemDBEnumPair),				g_PGEnumNoYes,			},
	{	GISEnergyConsumer_P,				"cim:EnergyConsumer.P",					"P",					0,	0,	},
	{	GISEnergyConsumer_Q,				"cim:EnergyConsumer.Q",					"Q",					0,	0,	},
	{	GISEnergyConsumer_CustumerNum,		"cim:EnergyConsumer.CustumerNum",		"CustumerNum",			0,	0,	},
	{	GISEnergyConsumer_Parent,			"",										"Parent",				0,	0,	},
	{	GISEnergyConsumer_Node,				"",										"Node",					0,	0,	},
	{	GISEnergyConsumer_BelongPSRType,	"",										"BelongPSRType",		0,	0,	},
	{	GISEnergyConsumer_BelongPSRName,	"",										"BelongPSRName",		0,	0,	},
	{	GISEnergyConsumer_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISEnergyConsumer_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISEnergyConsumer_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISEnergyConsumer_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISEnergyConsumer_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISEnergyConsumer_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISEnergyConsumer_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISEnergyConsumer_Location,			"",										"Location",				0,	0,	},
	{	GISEnergyConsumer_GraphSize,		"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISCompensatorField[]=
{
	{	GISCompensator_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISCompensator_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISCompensator_ObjectID,		"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISCompensator_Name,			"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISCompensator_Unit,			"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISCompensator_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISCompensator_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISCompensator_Parent,			"",										"Parent",				0,	0,	},
	{	GISCompensator_Node,			"",										"Node",					0,	0,	},
	{	GISCompensator_SeriesNode,		"",										"NodeZ",				0,	0,	},
	{	GISCompensator_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISCompensator_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISCompensator_SeriesNodeIdx,	"",										"SeriesNodeHIdx",		0,	0,	},
	{	GISCompensator_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISCompensator_SymbolID,		"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISCompensator_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISCompensator_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISCompensator_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISCompensator_Location,		"",										"Location",				0,	0,	},
	{	GISCompensator_GraphSize,		"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISCapacitorField[]=
{
	{	GISCapacitor_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISCapacitor_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRTypeTag",			0,	0,	},
	{	GISCapacitor_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISCapacitor_Name,				"cim:IdentifiedObject.name",			"name",					0,	0,	},
	{	GISCapacitor_Unit,				"cim:IdentifiedObject.UNIT",			"UNIT",					0,	0,	},
	{	GISCapacitor_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISCapacitor_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISCapacitor_Parent,			"",										"Parent",				0,	0,	},
	{	GISCapacitor_Node,				"",										"Node",					0,	0,	},
	{	GISCapacitor_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISCapacitor_NodeIdx,			"",										"NodeIdx",				0,	0,	},
	{	GISCapacitor_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISCapacitor_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISCapacitor_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISCapacitor_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISCapacitor_GraphPath,			"",										"GraphPath",			0,	0,	},
	{	GISCapacitor_Location,			"",										"Location",				0,	0,	},
	{	GISCapacitor_GraphSize,			"",										"GraphSize",			0,	0,	},
};

static	tagGISField	g_GISTerminalField[]=
{
	{	GISTerminal_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISTerminal_ParentTag,		"cim:Terminal.ConductingEquipment",		"ConductingEquipment",	0,	0,	},
	{	GISTerminal_NodeTag,		"cim:Terminal.ConnectivityNode",		"ConnectivityNode",		0,	0,	},
	{	GISTerminal_NodeIdx,		"",										"Node",					0,	0,	},
};

static	tagGISField	g_GISConnectivityNodeField[]=
{
	{	GISConnectivityNode_ResourceID,		"rdf:ID",	"ResID",		0,	0,	},
	{	GISConnectivityNode_VoltageLevel,	"",			"VoltageLevel",	0,	0,	},
	//{	GISConnectivityNode_Vertex,			"",			"Vertex",	0,	0,	},
};

static	tagGISField	g_GISPipeField[]=
{
	{	GISPipe_ResourceID,		"rdf:ID",							"ResID",			0,	0,	},
	{	GISPipe_PSRTypeTag,		"cim:PowerSystemResource.PSRType",	"PSRTypeTag",		0,	0,	},
	{	GISPipe_ObjectID,		"cim:IdentifiedObject.mRID",		"mRID",				0,	0,	},
	{	GISPipe_Name,			"cim:IdentifiedObject.name",		"name",				0,	0,	},
	{	GISPipe_Model,			"cim:Pipe.Model",					"Model",			0,	0,	},
	{	GISPipe_BuildDate,		"cim:Pipe.BuildDate",				"BuildDate",		0,	0,	},
	{	GISPipe_RebuildDate,	"cim:Pipe.RebuildDate",				"RebuildDate",		0,	0,	},
	{	GISPipe_OutageDate,		"cim:Pipe.OutageDate",				"OutageDate",		0,	0,	},
	{	GISPipe_RunTimeSpan,	"cim:Pipe.RunTimeSpan",				"RunTimeSpan",		0,	0,	},
	{	GISPipe_PlanCharacter,	"cim:Pipe.PlanCharacter",			"PlanCharacter",	sizeof(g_PGEnumDPlanCharacter)/sizeof(tagMemDBEnumPair),				g_PGEnumDPlanCharacter,					},
	{	GISPipe_MaxHVCableNum,	"cim:Pipe.MaxHVCableNum",			"MaxHVCable",		0,	0,	},
	{	GISPipe_MaxMVCableNum,	"cim:Pipe.MaxMVCableNum",			"MaxMVCable",		0,	0,	},
	{	GISPipe_MaxLVCableNum,	"cim:Pipe.MaxLVCableNum",			"MaxLVCable",		0,	0,	},
	{	GISPipe_HVCableNum,		"",									"HVCableNum",		0,	0,	},
	{	GISPipe_MVCableNum,		"",									"MVCableNum",		0,	0,	},
	{	GISPipe_LVCableNum,		"",									"LVCableNum",		0,	0,	},
	{	GISPipe_HVCable1,		"cim:Pipe.HVCable1",				"HVCable1",			0,	0,	},
	{	GISPipe_HVCable2,		"cim:Pipe.HVCable2",				"HVCable2",			0,	0,	},
	{	GISPipe_HVCable3,		"cim:Pipe.HVCable3",				"HVCable3",			0,	0,	},
	{	GISPipe_HVCable4,		"cim:Pipe.HVCable4",				"HVCable4",			0,	0,	},
	{	GISPipe_MVCable1,		"cim:Pipe.MVCable1",				"MVCable1",			0,	0,	},
	{	GISPipe_MVCable2,		"cim:Pipe.MVCable2",				"MVCable2",			0,	0,	},
	{	GISPipe_MVCable3,		"cim:Pipe.MVCable3",				"MVCable3",			0,	0,	},
	{	GISPipe_MVCable4,		"cim:Pipe.MVCable4",				"MVCable4",			0,	0,	},
	{	GISPipe_MVCable5,		"cim:Pipe.MVCable5",				"MVCable5",			0,	0,	},
	{	GISPipe_MVCable6,		"cim:Pipe.MVCable6",				"MVCable6",			0,	0,	},
	{	GISPipe_MVCable7,		"cim:Pipe.MVCable7",				"MVCable7",			0,	0,	},
	{	GISPipe_MVCable8,		"cim:Pipe.MVCable8",				"MVCable8",			0,	0,	},
	{	GISPipe_LVCable01,		"cim:Pipe.LVCable01",				"LVCable01",		0,	0,	},
	{	GISPipe_LVCable02,		"cim:Pipe.LVCable02",				"LVCable02",		0,	0,	},
	{	GISPipe_LVCable03,		"cim:Pipe.LVCable03",				"LVCable03",		0,	0,	},
	{	GISPipe_LVCable04,		"cim:Pipe.LVCable04",				"LVCable04",		0,	0,	},
	{	GISPipe_LVCable05,		"cim:Pipe.LVCable05",				"LVCable05",		0,	0,	},
	{	GISPipe_LVCable06,		"cim:Pipe.LVCable06",				"LVCable06",		0,	0,	},
	{	GISPipe_LVCable07,		"cim:Pipe.LVCable07",				"LVCable07",		0,	0,	},
	{	GISPipe_LVCable08,		"cim:Pipe.LVCable08",				"LVCable08",		0,	0,	},
	{	GISPipe_LVCable09,		"cim:Pipe.LVCable09",				"LVCable09",		0,	0,	},
	{	GISPipe_LVCable10,		"cim:Pipe.LVCable10",				"LVCable10",		0,	0,	},
	{	GISPipe_LVCable11,		"cim:Pipe.LVCable11",				"LVCable11",		0,	0,	},
	{	GISPipe_LVCable12,		"cim:Pipe.LVCable12",				"LVCable12",		0,	0,	},
	{	GISPipe_LVCable13,		"cim:Pipe.LVCable13",				"LVCable13",		0,	0,	},
	{	GISPipe_LVCable14,		"cim:Pipe.LVCable14",				"LVCable14",		0,	0,	},
	{	GISPipe_LVCable15,		"cim:Pipe.LVCable15",				"LVCable15",		0,	0,	},
	{	GISPipe_LVCable16,		"cim:Pipe.LVCable16",				"LVCable16",		0,	0,	},
	{	GISPipe_LVCable17,		"cim:Pipe.LVCable17",				"LVCable17",		0,	0,	},
	{	GISPipe_LVCable18,		"cim:Pipe.LVCable18",				"LVCable18",		0,	0,	},
	{	GISPipe_LVCable19,		"cim:Pipe.LVCable19",				"LVCable19",		0,	0,	},
	{	GISPipe_LVCable20,		"cim:Pipe.LVCable20",				"LVCable20",		0,	0,	},
	{	GISPipe_LVCable21,		"cim:Pipe.LVCable21",				"LVCable21",		0,	0,	},
	{	GISPipe_LVCable22,		"cim:Pipe.LVCable22",				"LVCable22",		0,	0,	},
	{	GISPipe_LVCable23,		"cim:Pipe.LVCable23",				"LVCable23",		0,	0,	},
	{	GISPipe_LVCable24,		"cim:Pipe.LVCable24",				"LVCable24",		0,	0,	},
	{	GISPipe_LVCable25,		"cim:Pipe.LVCable25",				"LVCable25",		0,	0,	},
	{	GISPipe_LVCable26,		"cim:Pipe.LVCable26",				"LVCable26",		0,	0,	},
	{	GISPipe_LVCable27,		"cim:Pipe.LVCable27",				"LVCable27",		0,	0,	},
	{	GISPipe_LVCable28,		"cim:Pipe.LVCable28",				"LVCable28",		0,	0,	},
	{	GISPipe_LVCable29,		"cim:Pipe.LVCable29",				"LVCable29",		0,	0,	},
	{	GISPipe_LVCable30,		"cim:Pipe.LVCable30",				"LVCable30",		0,	0,	},
	{	GISPipe_LVCable31,		"cim:Pipe.LVCable31",				"LVCable31",		0,	0,	},
	{	GISPipe_LVCable32,		"cim:Pipe.LVCable32",				"LVCable32",		0,	0,	},
};

static	tagGISField	g_GISPTField[]=
{
	{	GISPT_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISPT_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISPT_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
	{	GISPT_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",	0,	0,	},
};

static	tagGISField	g_GISCTField[]=
{
	{	GISCT_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISCT_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISCT_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
	{	GISCT_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",	0,	0,	},
};

static	tagGISField	g_GISBLQField[]=
{
	{	GISBLQ_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISBLQ_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISBLQ_ObjectID,		"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
	{	GISBLQ_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",	0,	0,	},
};

static	tagGISField	g_GISFaultIndicatorField[]=
{
	{	GISFaultIndicator_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISFaultIndicator_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",				0,	0,	},
	{	GISFaultIndicator_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISFaultIndicator_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISFaultIndicator_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
};

static	tagGISField	g_GISPTCabField[]=
{
	{	GISPTCab_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISPTCab_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISPTCab_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
	{	GISPTCab_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",	0,	0,	},
};

static	tagGISField	g_GISPTCABUField[]=
{
	{	GISPTCABU_ResourceID,		"rdf:ID",								"ResID",	0,	0,	},
	{	GISPTCABU_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",	0,	0,	},
	{	GISPTCABU_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",		0,	0,	},
};

static	tagGISField	g_GISKWGXBField[]=
{
	{	GISKWGXB_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISKWGXB_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISKWGXB_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
};

static	tagGISField	g_GISPFWELLField[]=
{
	{	GISPFWELL_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISPFWELL_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISPFWELL_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
};

static	tagGISField	g_GISPFTUNNField[]=
{
	{	GISPFTUNN_ResourceID,		"rdf:ID",								"ResID",		0,	0,	},
	{	GISPFTUNN_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",		0,	0,	},
	{	GISPFTUNN_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",			0,	0,	},
};

static	tagGISField	g_GISOtherField[]=
{
	{	GISOther_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISOther_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",				0,	0,	},
	{	GISOther_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISOther_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISOther_ParentTag,			"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
};

static	tagGISField	g_GISGroundField[]=
{
	{	GISGround_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISGround_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",				0,	0,	},
	{	GISGround_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISGround_BaseVoltageTag,	"cim:ConductingEquipment.BaseVoltage",	"BaseVoltage",			0,	0,	},
	{	GISGround_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
};

static	tagGISField	g_GISZJField[]=
{
	{	GISZJ_ResourceID,		"rdf:ID",								"ResID",				0,	0,	},
	{	GISZJ_PSRTypeTag,		"cim:PowerSystemResource.PSRType",		"PSRType",				0,	0,	},
	{	GISZJ_ObjectID,			"cim:IdentifiedObject.mRID",			"mRID",					0,	0,	},
	{	GISZJ_TextHeight,		"cim:IdentifiedObject.TextHeight",		"TextHeight",			0,	0,	},
	{	GISZJ_Name,				"cim:IdentifiedObject.name",			"Name",					0,	0,	},
	{	GISZJ_ParentTag,		"cim:Equipment.EquipmentContainer",		"EquipmentContainer",	0,	0,	},
	{	GISZJ_Parent,			"",										"Parent",				0,	0,	},
	{	GISZJ_SubIdx,			"",										"SubIdx",				0,	0,	},
	{	GISZJ_Coordinate,		"cim:IdentifiedObject.Coordinate",		"Coordinate",			0,	0,	},
	{	GISZJ_SymbolID,			"cim:IdentifiedObject.SymbolID",		"SymbolID",				0,	0,	},
	{	GISZJ_SymbolSize,		"cim:IdentifiedObject.SymbolSize",		"SymbolSize",			0,	0,	},
	{	GISZJ_SymbolAngle,		"cim:IdentifiedObject.SymbolAngle",		"SymbolAngle",			0,	0,	},
	{	GISZJ_GraphPath,		"",										"GraphPath",			0,	0,	},
	{	GISZJ_Location,			"",										"Location",				0,	0,	},
};


#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(fPower)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
