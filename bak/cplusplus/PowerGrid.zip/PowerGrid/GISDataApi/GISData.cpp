// GISData.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#include "stdafx.h"
#include "GISData.h"
#include "GISDataTable.h"


// ���ǵ���������һ��ʾ��

const	char*	g_lpszLogFile="GISData.log";
extern	void	ClearLog(const char* lpszLogFile);

// �����ѵ�����Ĺ��캯����
// �й��ඨ�����Ϣ������� GISData.h
CGISData::CGISData()
{
	ClearLog(g_lpszLogFile);
	Release();
	return;
}

const	int	CGISData::GetGISTableNum()
{
	return sizeof(g_GISTableArray)/sizeof(tagGISTable);
}

const int	CGISData::GetGISTableID(const int nTable)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
		return g_GISTableArray[nTable].nTableID;
	return -1;
}

const char*	CGISData::GetGISTableTag(const int nTable)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
		return g_GISTableArray[nTable].szTableTag;
	return "";
}

const char*	CGISData::GetGISTableDesp(const int nTable)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
		return g_GISTableArray[nTable].szTableDesp;
	return "";
}

const	int	CGISData::GetGISTableFieldNum(const int nTable)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
		return g_GISTableArray[nTable].nFieldNum;
	return 0;
}

const	int	CGISData::GetGISTableFieldIndex(const int nTable, const char* lpszField)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
	{
		register int	i;
		for (i=0; i<GetGISTableFieldNum(nTable); i++)
		{
			if (stricmp(GetGISTableFieldTag(nTable, i), lpszField) == 0)
			{
				return i;
			}
			if (stricmp(GetGISTableFieldDesp(nTable, i), lpszField) == 0)
			{
				return i;
			}
		}
	}
	return -1;
}

const char*	CGISData::GetGISTableFieldTag(const int nTable, const int nField)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
	{
		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
			return g_GISTableArray[nTable].pFieldArray[nField].szFieldTag;
	}
	return "";
}

const char*	CGISData::GetGISTableFieldDesp(const int nTable, const int nField)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
	{
		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
			return g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp;
	}
	return "";
}

const int	CGISData::GetGISTableFieldEnumNum(const int nTable, const int nField)
{
	if (nTable >= 0 && nTable < GetGISTableNum())
	{
		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
			return g_GISTableArray[nTable].pFieldArray[nField].nEnumNum;
	}
	return 0;
}

const char*	CGISData::GetGISTableFieldEnumName(const int nTable, const int nField, const int nEnumValue)
{
	register int	i;
	if (nTable >= 0 && nTable < GetGISTableNum())
	{
		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
		{
			for (i=0; i<GetGISTableFieldEnumNum(nTable, nField); i++)
			{
				if (g_GISTableArray[nTable].pFieldArray[nField].pEnumArray[i].nEnumValue == nEnumValue)
					return g_GISTableArray[nTable].pFieldArray[nField].pEnumArray[i].lpszEnumString;
			}
		}
	}
	return "";
}

const int	CGISData::GetGISTableFieldEnumValue(const int nTable, const int nField, const char* lpszEnumName)
{
	register int	i;
	if (nTable >= 0 && nTable < GetGISTableNum())
	{
		if (nField >= 0 && nField < g_GISTableArray[nTable].nFieldNum)
		{
			for (i=0; i<GetGISTableFieldEnumNum(nTable, nField); i++)
			{
				if (stricmp(g_GISTableArray[nTable].pFieldArray[nField].pEnumArray[i].lpszEnumString, lpszEnumName) == 0)
					return g_GISTableArray[nTable].pFieldArray[nField].pEnumArray[i].nEnumValue;
			}
		}
	}
	return -1;
}


void CGISData::CheckValidate()
{
	register int	i;
	int		nTable, nField;
	//	int	nTableLen;

	for (nTable=0; nTable<sizeof(g_GISTableArray)/sizeof(tagGISTable); nTable++)
	{
		for (nField=0; nField<g_GISTableArray[nTable].nFieldNum; nField++)
		{
			if (strlen(g_GISTableArray[nTable].pFieldArray[nField].szFieldTag) <= 0)
				continue;
			for (i=nField+1; i<g_GISTableArray[nTable].nFieldNum; i++)
			{
				if (stricmp(g_GISTableArray[nTable].pFieldArray[nField].szFieldTag, g_GISTableArray[nTable].pFieldArray[i].szFieldTag) == 0)
					Log(g_lpszLogFile, "          ����%s���������, �ֶζ�����ͬ %d, %d\n", g_GISTableArray[nTable].szTableDesp, nField, i);
				if (stricmp(g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp, g_GISTableArray[nTable].pFieldArray[i].szFieldDesp) == 0)
					Log(g_lpszLogFile, "          ����%s���������, �ֶ�������ͬ %d, %d\n", g_GISTableArray[nTable].szTableDesp, nField, i);
			}
		}
		if (nTable != g_GISTableArray[nTable].nTableID)
			Log(g_lpszLogFile, "          ����%s���������, ��ʵ����ţ�%d ��������ţ�%d\n", g_GISTableArray[nTable].szTableDesp, nTable, g_GISTableArray[nTable].nTableID);
		for (nField=0; nField<g_GISTableArray[nTable].nFieldNum; nField++)
		{
			if (nField != g_GISTableArray[nTable].pFieldArray[nField].nFieldID)
				Log(g_lpszLogFile, "          ����%s���ֶζ������, �ֶ�ʵ����ţ�%d �ֶζ�����ţ�%d\n", g_GISTableArray[nTable].szTableDesp, nField, g_GISTableArray[nTable].pFieldArray[nField].nFieldID);
		}
	}

	// 	for (nTable=0; nTable<sizeof(g_GISTableArray)/sizeof(tagGISTable); nTable++)
	// 	{
	// 		nTableLen=0;
	// 		for (i=0; i<g_GISTableArray[nTable].nFieldNum; i++)
	// 			nTableLen += g_GISTableArray[nTable].pFieldArray[i].nFieldLen;
	// 		nTableLen += g_GISTableArray[nTable].nLocLen;
	// 
	// 		if (nTableLen != GetGISTableRecordLen(nTable))
	// 			Log(g_lpszLogFile, "          ����%s�����ȴ���, ���峤��=%d ʵ�ʳ���=%d LocLen=%d\n", g_GISTableArray[nTable].szTableDesp, GetGISTableRecordLen(nTable), nTableLen, g_GISTableArray[nTable].nLocLen);
	// 		else
	// 			Log(g_lpszLogFile, "����%s��������ȷ, ���峤��=%d ʵ�ʳ���=%d\n", g_GISTableArray[nTable].szTableDesp, GetGISTableRecordLen(nTable), nTableLen);
	// 
	// 		for (nField=0; nField<g_GISTableArray[nTable].nFieldNum; nField++)
	// 		{
	// 			switch (g_GISTableArray[nTable].pFieldArray[nField].nFieldType)
	// 			{
	// 			case	MDB_STRING:
	// 				break;
	// 			case	MDB_DOUBLE:
	// 				if (g_GISTableArray[nTable].pFieldArray[nField].nFieldLen != sizeof(double))
	// 					Log(g_lpszLogFile, "          ����%s�� �ֶΡ�%s�� ���ȴ��� %d [Ӧ=%d]\n", g_GISTableArray[nTable].szTableDesp, g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp, g_GISTableArray[nTable].pFieldArray[nField].nFieldLen, sizeof(double));
	// 				break;
	// 			case	MDB_FLOAT:
	// 				if (g_GISTableArray[nTable].pFieldArray[nField].nFieldLen != sizeof(float))
	// 					Log(g_lpszLogFile, "          ����%s�� �ֶΡ�%s�� ���ȴ��� %d [Ӧ=%d]\n", g_GISTableArray[nTable].szTableDesp, g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp, g_GISTableArray[nTable].pFieldArray[nField].nFieldLen, sizeof(float));
	// 				break;
	// 			case	MDB_INT:
	// 				if (g_GISTableArray[nTable].pFieldArray[nField].nFieldLen != sizeof(int))
	// 					Log(g_lpszLogFile, "          ����%s�� �ֶΡ�%s�� ���ȴ��� %d [Ӧ=%d]\n", g_GISTableArray[nTable].szTableDesp, g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp, g_GISTableArray[nTable].pFieldArray[nField].nFieldLen, sizeof(int));
	// 				break;
	// 			case	MDB_SHORT:
	// 				if (g_GISTableArray[nTable].pFieldArray[nField].nFieldLen != sizeof(short))
	// 					Log(g_lpszLogFile, "          ����%s�� �ֶΡ�%s�� ���ȴ��� %d [Ӧ=%d]\n", g_GISTableArray[nTable].szTableDesp, g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp, g_GISTableArray[nTable].pFieldArray[nField].nFieldLen, sizeof(short));
	// 				break;
	// 			case	MDB_BIT:
	// 				if (g_GISTableArray[nTable].pFieldArray[nField].nFieldLen != sizeof(unsigned char))
	// 					Log(g_lpszLogFile, "          ����%s�� �ֶΡ�%s�� ���ȴ��� %d [Ӧ=%d]\n", g_GISTableArray[nTable].szTableDesp, g_GISTableArray[nTable].pFieldArray[nField].szFieldDesp, g_GISTableArray[nTable].pFieldArray[nField].nFieldLen, sizeof(unsigned char));
	// 				break;
	// 			}
	// 		}
	// 	}
}

const int	CGISData::GetGISTableRecordNum(const int nTable)
{
	switch (nTable)
	{
	case GIS_RDF:						return (int)m_RDFArray.size()					;	break;
	case GIS_GeographicalRegion:		return (int)m_GeographicalRegionArray.size()	;	break;
	case GIS_SubGeographicalRegion:		return (int)m_SubGeographicalRegionArray.size()	;	break;
	case GIS_BaseVoltage:				return (int)m_BaseVoltageArray.size()			;	break;
	case GIS_Substation:				return (int)m_SubstationArray.size()			;	break;
	case GIS_Feeder:					return (int)m_FeederArray.size()				;	break;
	case GIS_CompositeSwitch:			return (int)m_CompositeSwitchArray.size()		;	break;
	case GIS_Breaker:					return (int)m_BreakerArray.size()				;	break;
	case GIS_Disconnector:				return (int)m_DisconnectorArray.size()			;	break;
	case GIS_GroundDisconnector:		return (int)m_GroundDisconnectorArray.size()	;	break;
	case GIS_LoadBreakSwitch:			return (int)m_LoadBreakSwitchArray.size()		;	break;
	case GIS_Fuse:						return (int)m_FuseArray.size()					;	break;
	case GIS_BusbarSection:				return (int)m_BusbarSectionArray.size()			;	break;
	case GIS_Pole:						return (int)m_PoleArray.size()					;	break;
	case GIS_Junction:					return (int)m_JunctionArray.size()				;	break;
	case GIS_ACLineSegment:				return (int)m_ACLineSegmentArray.size()			;	break;
	case GIS_PowerTransformer:			return (int)m_PowerTransformerArray.size()		;	break;
	case GIS_ConnLine:					return (int)m_ConnLineArray.size()				;	break;
	case GIS_EnergyConsumer:			return (int)m_EnergyConsumerArray.size()		;	break;
	case GIS_Compensator:				return (int)m_CompensatorArray.size()			;	break;
	case GIS_Capacitor:					return (int)m_CapacitorArray.size()				;	break;
	case GIS_Terminal:					return (int)m_TerminalArray.size()				;	break;
	case GIS_ConnectivityNode:			return (int)m_ConnectivityNodeArray.size()		;	break;
	case GIS_Pipe:						return (int)m_PipeArray.size()					;	break;
	case GIS_PSRType:					return (int)m_PSRTypeArray.size()				;	break;
	case GIS_PT:						return (int)m_PTArray.size()					;	break;
	case GIS_CT:						return (int)m_CTArray.size()					;	break;
	case GIS_BLQ:						return (int)m_BLQArray.size()					;	break;
	case GIS_FaultIndicator:			return (int)m_FaultIndicatorArray.size()		;	break;
	case GIS_PTCab:						return (int)m_PTCabArray.size()					;	break;
	case GIS_Ground:					return (int)m_GroundArray.size()				;	break;
	case GIS_Other:						return (int)m_OtherArray.size()					;	break;
	case GIS_PTCABU:					return (int)m_PTCABUArray.size()				;	break;
	case GIS_KWGXB:						return (int)m_KWGXBArray.size()					;	break;
	case GIS_PFWELL:					return (int)m_PFWELLArray.size()				;	break;
	case GIS_PFTUNN:					return (int)m_PFTUNNArray.size()				;	break;
	case GIS_ZJ:						return (int)m_ZJArray.size()					;	break;
	default:	break;
	}
	return 0;
}

const std::string	CGISData::GetGISRecordValue(const int nTable, const int nField, const int nRecord)
{
	if (nTable < 0 || nTable >= GetGISTableNum())
		return "";
	if (nField < 0 || nField >= g_GISTableArray[nTable].nFieldNum)
		return "";
	if (nRecord < 0 || nRecord >= GetGISTableRecordNum(nTable))
		return "";

	switch (nTable)
	{
	case GIS_PSRType:					return	m_GISBuffer.GetGISPSRType				(	m_PSRTypeArray[nRecord],				nField	);
	case GIS_RDF:						return	m_GISBuffer.GetGISRDF					(	m_RDFArray[nRecord],					nField	);
	case GIS_GeographicalRegion:		return	m_GISBuffer.GetGISGeographicalRegion	(	m_GeographicalRegionArray[nRecord],		nField	);
	case GIS_SubGeographicalRegion:		return	m_GISBuffer.GetGISSubGeographicalRegion	(	m_SubGeographicalRegionArray[nRecord],	nField	);
	case GIS_BaseVoltage:				return	m_GISBuffer.GetGISBaseVoltage			(	m_BaseVoltageArray[nRecord],			nField	);
	case GIS_Substation:				return	m_GISBuffer.GetGISSubstation			(	m_SubstationArray[nRecord],				nField	);
	case GIS_Feeder:					return	m_GISBuffer.GetGISFeeder				(	m_FeederArray[nRecord],					nField	);
	case GIS_CompositeSwitch:			return	m_GISBuffer.GetGISCompositeSwitch		(	m_CompositeSwitchArray[nRecord],		nField	);
	case GIS_Breaker:					return	m_GISBuffer.GetGISBreaker				(	m_BreakerArray[nRecord],				nField	);
	case GIS_Disconnector:				return	m_GISBuffer.GetGISDisconnector			(	m_DisconnectorArray[nRecord],			nField	);
	case GIS_GroundDisconnector:		return	m_GISBuffer.GetGISGroundDisconnector	(	m_GroundDisconnectorArray[nRecord],		nField	);
	case GIS_LoadBreakSwitch:			return	m_GISBuffer.GetGISLoadBreakSwitch		(	m_LoadBreakSwitchArray[nRecord],		nField	);
	case GIS_Fuse:						return	m_GISBuffer.GetGISFuse					(	m_FuseArray[nRecord],					nField	);
	case GIS_ACLineSegment:				return	m_GISBuffer.GetGISACLineSegment			(	m_ACLineSegmentArray[nRecord],			nField	);
	case GIS_PowerTransformer:			return	m_GISBuffer.GetGISPowerTransformer		(	m_PowerTransformerArray[nRecord],		nField	);
	case GIS_ConnLine:					return	m_GISBuffer.GetGISConnLine				(	m_ConnLineArray[nRecord],				nField	);
	case GIS_BusbarSection:				return	m_GISBuffer.GetGISBusbarSection			(	m_BusbarSectionArray[nRecord],			nField	);
	case GIS_Pole:						return	m_GISBuffer.GetGISPole					(	m_PoleArray[nRecord],					nField	);
	case GIS_Junction:					return	m_GISBuffer.GetGISJunction				(	m_JunctionArray[nRecord],				nField	);
	case GIS_EnergyConsumer:			return	m_GISBuffer.GetGISEnergyConsumer		(	m_EnergyConsumerArray[nRecord],			nField	);
	case GIS_Compensator:				return	m_GISBuffer.GetGISCompensator			(	m_CompensatorArray[nRecord],			nField	);
	case GIS_Capacitor:					return	m_GISBuffer.GetGISCapacitor				(	m_CapacitorArray[nRecord],				nField	);
	case GIS_Terminal:					return	m_GISBuffer.GetGISTerminal				(	m_TerminalArray[nRecord],				nField	);
	case GIS_ConnectivityNode:			return	m_GISBuffer.GetGISConnectivityNode		(	m_ConnectivityNodeArray[nRecord],		nField	);
	case GIS_Pipe:						return	m_GISBuffer.GetGISPipe					(	m_PipeArray[nRecord],					nField	);
	case GIS_PT:						return	m_GISBuffer.GetGISPT					(	m_PTArray[nRecord],						nField	);
	case GIS_CT:						return	m_GISBuffer.GetGISCT					(	m_CTArray[nRecord],						nField	);
	case GIS_BLQ:						return	m_GISBuffer.GetGISBLQ					(	m_BLQArray[nRecord],					nField	);
	case GIS_FaultIndicator:			return	m_GISBuffer.GetGISFaultIndicator		(	m_FaultIndicatorArray[nRecord],			nField	);
	case GIS_PTCab:						return	m_GISBuffer.GetGISPTCab					(	m_PTCabArray[nRecord],					nField	);
	case GIS_Ground:					return	m_GISBuffer.GetGISGround				(	m_GroundArray[nRecord],					nField	);
	case GIS_Other:						return	m_GISBuffer.GetGISOther					(	m_OtherArray[nRecord],					nField	);
	case GIS_PTCABU:					return	m_GISBuffer.GetGISPTCABU				(	m_PTCABUArray[nRecord],					nField	);
	case GIS_KWGXB:						return	m_GISBuffer.GetGISKWGXB					(	m_KWGXBArray[nRecord],					nField	);
	case GIS_PFWELL:					return	m_GISBuffer.GetGISPFWELL				(	m_PFWELLArray[nRecord],					nField	);
	case GIS_PFTUNN:					return	m_GISBuffer.GetGISPFTUNN				(	m_PFTUNNArray[nRecord],					nField	);
	case GIS_ZJ:						return	m_GISBuffer.GetGISZJ					(	m_ZJArray[nRecord],						nField	);
	}
	return "";
}

void CGISData::Release()
{
	if (!m_RDFArray.empty())					m_RDFArray.clear();
	if (!m_GeographicalRegionArray.empty())		m_GeographicalRegionArray.clear();
	if (!m_SubGeographicalRegionArray.empty())	m_SubGeographicalRegionArray.clear();
	if (!m_BaseVoltageArray.empty())			m_BaseVoltageArray.clear();
	if (!m_SubstationArray.empty())				m_SubstationArray.clear();
	if (!m_FeederArray.empty())					m_FeederArray.clear();
	if (!m_CompositeSwitchArray.empty())		m_CompositeSwitchArray.clear();

	if (!m_BreakerArray.empty())				m_BreakerArray.clear();
	if (!m_DisconnectorArray.empty())			m_DisconnectorArray.clear();
	if (!m_GroundDisconnectorArray.empty())		m_GroundDisconnectorArray.clear();
	if (!m_LoadBreakSwitchArray.empty())		m_LoadBreakSwitchArray.clear();
	if (!m_FuseArray.empty())					m_FuseArray.clear();

	if (!m_ACLineSegmentArray.empty())			m_ACLineSegmentArray.clear();
	if (!m_PowerTransformerArray.empty())		m_PowerTransformerArray.clear();
	if (!m_ConnLineArray.empty())				m_ConnLineArray.clear();

	if (!m_BusbarSectionArray.empty())			m_BusbarSectionArray.clear();
	if (!m_PoleArray.empty())					m_PoleArray.clear();
	if (!m_JunctionArray.empty())				m_JunctionArray.clear();

	if (!m_EnergyConsumerArray.empty())			m_EnergyConsumerArray.clear();
	if (!m_CompensatorArray.empty())			m_CompensatorArray.clear();
	if (!m_CapacitorArray.empty())				m_CapacitorArray.clear();
	if (!m_TerminalArray.empty())				m_TerminalArray.clear();
	if (!m_ConnectivityNodeArray.empty())		m_ConnectivityNodeArray.clear();

	if (!m_PipeArray.empty())					m_PipeArray.clear();

	if (!m_PSRTypeArray.empty())				m_PSRTypeArray.clear();
	if (!m_PTArray.empty())						m_PTArray.clear();
	if (!m_CTArray.empty())						m_CTArray.clear();
	if (!m_BLQArray.empty())					m_BLQArray.clear();
	if (!m_PTCabArray.empty())					m_PTCabArray.clear();
	if (!m_OtherArray.empty())					m_OtherArray.clear();
	if (!m_PTCABUArray.empty())					m_PTCABUArray.clear();
	if (!m_KWGXBArray.empty())					m_KWGXBArray.clear();
	if (!m_PFWELLArray.empty())					m_PFWELLArray.clear();
	if (!m_PFTUNNArray.empty())					m_PFTUNNArray.clear();
	if (!m_ZJArray.empty())						m_ZJArray.clear();

	m_Sub2EquipmentArray.clear();
	m_Node2EquipmentArray.clear();
	m_Node2TerminalArray.clear();
}

void	CGISData::InitData(const int nGisTable)
{
	m_GISBuffer.Init(nGisTable);
}

int		CGISData::FillData(const int nGisTable, const char* lpszElementName, const char* lpszElementValue)
{
	int	nField=GetGISTableFieldIndex(nGisTable, lpszElementName);
	if (nField < 0)
		return 0;

	if (GetGISTableFieldEnumNum(nGisTable, nField) > 0)
	{
		int	nEnumValue=GetGISTableFieldEnumValue(nGisTable, nField, lpszElementValue);
		if (nEnumValue >= 0)
		{
			char	szBuf[260];
			sprintf(szBuf, "%d", nEnumValue);
			return m_GISBuffer.Fill(nGisTable, nField, szBuf);
		}
	}
	return m_GISBuffer.Fill(nGisTable, nField, lpszElementValue);
}

int		CGISData::FillData(const int nGisTable, const int nField, const char* lpszElementValue)
{
	return m_GISBuffer.Fill(nGisTable, nField, lpszElementValue);
}

int		CGISData::AppendData(const int nGisTable, const std::string strPathName)
{
	register int	i;
	unsigned char	bExist;

	FillData(nGisTable, "GraphPath", strPathName.c_str());

	bExist=0;
	switch (nGisTable)
	{
	case GIS_RDF:
		break;
	case GIS_GeographicalRegion:
		if (!m_GISBuffer.m_GeographicalRegionBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_GeographicalRegionBuf.strName.empty())
				m_GISBuffer.m_GeographicalRegionBuf.strName=m_GISBuffer.m_GeographicalRegionBuf.strResourceID;

			for (i=0; i<(int)m_GeographicalRegionArray.size(); i++)
			{
				if (stricmp(m_GeographicalRegionArray[i].strResourceID.c_str(), m_GISBuffer.m_GeographicalRegionBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				m_GeographicalRegionArray.push_back(m_GISBuffer.m_GeographicalRegionBuf);
		}
		break;
	case GIS_SubGeographicalRegion:
		if (!m_GISBuffer.m_SubGeographicalRegionBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_SubGeographicalRegionBuf.strName.empty())
				m_GISBuffer.m_SubGeographicalRegionBuf.strName=m_GISBuffer.m_SubGeographicalRegionBuf.strResourceID;
			for (i=0; i<(int)m_SubGeographicalRegionArray.size(); i++)
			{
				if (stricmp(m_SubGeographicalRegionArray[i].strResourceID.c_str(), m_GISBuffer.m_SubGeographicalRegionBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				m_SubGeographicalRegionArray.push_back(m_GISBuffer.m_SubGeographicalRegionBuf);
		}
		break;
	case GIS_BaseVoltage:
		if (!m_GISBuffer.m_BaseVoltageBuf.strResourceID.empty())
		{
			for (i=0; i<(int)m_BaseVoltageArray.size(); i++)
			{
				if (stricmp(m_BaseVoltageArray[i].strResourceID.c_str(), m_GISBuffer.m_BaseVoltageBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				m_BaseVoltageArray.push_back(m_GISBuffer.m_BaseVoltageBuf);
		}
		break;
	case GIS_PSRType:
		if (!m_GISBuffer.m_PSRTypeBuf.strResourceID.empty())
		{
			bExist=0;
			for (i=0; i<(int)m_PSRTypeArray.size(); i++)
			{
				if (stricmp(m_PSRTypeArray[i].strResourceID.c_str(), m_GISBuffer.m_PSRTypeBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				m_PSRTypeArray.push_back(m_GISBuffer.m_PSRTypeBuf);
		}
		break;
	case GIS_Substation:
		if (!m_GISBuffer.m_SubstationBuf.strResourceID.empty())
		{
			for (i=0; i<(int)m_SubstationArray.size(); i++)
			{
				if (stricmp(m_SubstationArray[i].strResourceID.c_str(), m_GISBuffer.m_SubstationBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
			{
				if (m_GISBuffer.m_SubstationBuf.strName.empty())
					m_GISBuffer.m_SubstationBuf.strName=m_GISBuffer.m_SubstationBuf.strResourceID;
				m_SubstationArray.push_back(m_GISBuffer.m_SubstationBuf);
			}
		}
		break;
	case GIS_Feeder:
		if (!m_GISBuffer.m_FeederBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_FeederBuf.strName.empty())
				m_GISBuffer.m_FeederBuf.strName=m_GISBuffer.m_FeederBuf.strResourceID;
			for (i=0; i<(int)m_FeederArray.size(); i++)
			{
				if (stricmp(m_FeederArray[i].strResourceID.c_str(), m_GISBuffer.m_FeederBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				m_FeederArray.push_back(m_GISBuffer.m_FeederBuf);
		}
		break;
	case GIS_CompositeSwitch:
		if (!m_GISBuffer.m_CompositeSwitchBuf.strResourceID.empty())
		{
			for (i=0; i<(int)m_CompositeSwitchArray.size(); i++)
			{
				if (stricmp(m_CompositeSwitchArray[i].strResourceID.c_str(), m_GISBuffer.m_CompositeSwitchBuf.strResourceID.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				m_CompositeSwitchArray.push_back(m_GISBuffer.m_CompositeSwitchBuf);
		}
		break;
	case GIS_Breaker:
		if (!m_GISBuffer.m_BreakerBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_BreakerBuf.strName.empty())
				m_GISBuffer.m_BreakerBuf.strName=m_GISBuffer.m_BreakerBuf.strResourceID;
			m_BreakerArray.push_back(m_GISBuffer.m_BreakerBuf);
		}
		break;
	case GIS_Disconnector:
		if (!m_GISBuffer.m_DisconnectorBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_DisconnectorBuf.strName.empty())
				m_GISBuffer.m_DisconnectorBuf.strName=m_GISBuffer.m_DisconnectorBuf.strResourceID;
			m_DisconnectorArray.push_back(m_GISBuffer.m_DisconnectorBuf);
		}
		break;
	case GIS_GroundDisconnector:
		if (!m_GISBuffer.m_GroundDisconnectorBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_GroundDisconnectorBuf.strName.empty())
				m_GISBuffer.m_GroundDisconnectorBuf.strName=m_GISBuffer.m_GroundDisconnectorBuf.strResourceID;
			m_GroundDisconnectorArray.push_back(m_GISBuffer.m_GroundDisconnectorBuf);
		}
		break;
	case GIS_LoadBreakSwitch:
		if (!m_GISBuffer.m_LoadBreakSwitchBuf.strResourceID.empty())
		{
			if (stricmp(m_GISBuffer.m_LoadBreakSwitchBuf.gData.strSymbolID.c_str(), "2021-0") == 0 ||
				stricmp(m_GISBuffer.m_LoadBreakSwitchBuf.gData.strSymbolID.c_str(), "2021-1") == 0 ||
				stricmp(m_GISBuffer.m_LoadBreakSwitchBuf.gData.strSymbolID.c_str(), "2112-0") == 0)
				m_GISBuffer.m_LoadBreakSwitchBuf.gData.fSymbolAngle += 90;
			if (m_GISBuffer.m_LoadBreakSwitchBuf.strName.empty())
				m_GISBuffer.m_LoadBreakSwitchBuf.strName=m_GISBuffer.m_LoadBreakSwitchBuf.strResourceID;
			m_LoadBreakSwitchArray.push_back(m_GISBuffer.m_LoadBreakSwitchBuf);
		}
		break;
	case GIS_Fuse:
		if (!m_GISBuffer.m_FuseBuf.strResourceID.empty())
		{
			if (stricmp(m_GISBuffer.m_FuseBuf.gData.strSymbolID.c_str(), "2022-0") == 0 ||
				stricmp(m_GISBuffer.m_FuseBuf.gData.strSymbolID.c_str(), "2022-1") == 0 ||
				stricmp(m_GISBuffer.m_FuseBuf.gData.strSymbolID.c_str(), "2112-0") == 0)
				m_GISBuffer.m_FuseBuf.gData.fSymbolAngle += 90;
			if (m_GISBuffer.m_FuseBuf.strName.empty())
				m_GISBuffer.m_FuseBuf.strName=m_GISBuffer.m_FuseBuf.strResourceID;
			m_FuseArray.push_back(m_GISBuffer.m_FuseBuf);
		}
		break;
	case GIS_ACLineSegment:
		if (!m_GISBuffer.m_ACLineSegmentBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_ACLineSegmentBuf.strName.empty())
				m_GISBuffer.m_ACLineSegmentBuf.strName=m_GISBuffer.m_ACLineSegmentBuf.strResourceID;
			m_ACLineSegmentArray.push_back(m_GISBuffer.m_ACLineSegmentBuf);
		}
		else
		{
			Log(g_lpszLogFile, "ACLineSegment ResourceId Empty\n");
		}
		break;
	case GIS_PowerTransformer:
		if (!m_GISBuffer.m_PowerTransformerBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_PowerTransformerBuf.strName.empty())
			{
				if (!m_GISBuffer.m_PowerTransformerBuf.strObjectID.empty())			m_GISBuffer.m_PowerTransformerBuf.strName=m_GISBuffer.m_PowerTransformerBuf.strObjectID;
				else if (!m_GISBuffer.m_PowerTransformerBuf.strResourceID.empty())	m_GISBuffer.m_PowerTransformerBuf.strName=m_GISBuffer.m_PowerTransformerBuf.strResourceID;
			}
			m_PowerTransformerArray.push_back(m_GISBuffer.m_PowerTransformerBuf);
		}
		break;
	case GIS_ConnLine:
		if (!m_GISBuffer.m_ConnLineBuf.strResourceID.empty())
			m_ConnLineArray.push_back(m_GISBuffer.m_ConnLineBuf);
		break;

	case GIS_BusbarSection:
		if (!m_GISBuffer.m_BusbarSectionBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_BusbarSectionBuf.strName.empty())
				m_GISBuffer.m_BusbarSectionBuf.strName=m_GISBuffer.m_BusbarSectionBuf.strResourceID;
			m_BusbarSectionArray.push_back(m_GISBuffer.m_BusbarSectionBuf);
		}
		break;
	case GIS_Pole:
		if (!m_GISBuffer.m_PoleBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_PoleBuf.strName.empty())
				m_GISBuffer.m_PoleBuf.strName=m_GISBuffer.m_PoleBuf.strResourceID;
			m_PoleArray.push_back(m_GISBuffer.m_PoleBuf);
		}
		break;
	case GIS_Junction:
		if (!m_GISBuffer.m_JunctionBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_JunctionBuf.strName.empty())
				m_GISBuffer.m_JunctionBuf.strName=m_GISBuffer.m_JunctionBuf.strResourceID;
			m_JunctionArray.push_back(m_GISBuffer.m_JunctionBuf);
		}
		break;

	case GIS_EnergyConsumer:
		if (!m_GISBuffer.m_EnergyConsumerBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_EnergyConsumerBuf.strName.empty())
				m_GISBuffer.m_EnergyConsumerBuf.strName=m_GISBuffer.m_EnergyConsumerBuf.strResourceID;
			m_EnergyConsumerArray.push_back(m_GISBuffer.m_EnergyConsumerBuf);
		}
		break;
	case GIS_Compensator:
		if (!m_GISBuffer.m_CompensatorBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_CompensatorBuf.strName.empty())
				m_GISBuffer.m_CompensatorBuf.strName=m_GISBuffer.m_CompensatorBuf.strResourceID;
			m_CompensatorArray.push_back(m_GISBuffer.m_CompensatorBuf);
		}
		break;
	case GIS_Capacitor:
		if (!m_GISBuffer.m_CapacitorBuf.strResourceID.empty())
		{
			if (m_GISBuffer.m_CapacitorBuf.strName.empty())
				m_GISBuffer.m_CapacitorBuf.strName=m_GISBuffer.m_CapacitorBuf.strResourceID;
			m_CapacitorArray.push_back(m_GISBuffer.m_CapacitorBuf);
		}
		break;
	case GIS_Terminal:
		m_TerminalArray.push_back(m_GISBuffer.m_TerminalBuf);
		break;
	case GIS_ConnectivityNode:
		m_ConnectivityNodeArray.push_back(m_GISBuffer.m_ConnectivityNodeBuf);
		break;
	case GIS_Pipe:
		m_PipeArray.push_back(m_GISBuffer.m_PipeBuf);
		break;
	case GIS_PT:
		//m_PTArray.push_back(m_GISBuffer.m_PTBuf);
		break;
	case GIS_CT:
		//m_CTArray.push_back(m_GISBuffer.m_CTBuf);
		break;
	case GIS_BLQ:
		//m_BLQArray.push_back(m_GISBuffer.m_BLQBuf);
		break;
	case GIS_FaultIndicator:
		//m_FaultIndicatorArray.push_back(m_FaultIndicatorBuf);
		break;
	case GIS_PTCab:
		//m_PTCabArray.push_back(m_GISBuffer.m_PTCabBuf);
		break;
	case GIS_Ground:
		//m_GroundArray.push_back(m_GISBuffer.m_GroundBuf);
		break;
	case GIS_Other:
		//m_OtherArray.push_back(m_GISBuffer.m_OtherBuf);
		break;
	case GIS_PTCABU:
		//m_PTCABUArray.push_back(m_GISBuffer.m_PTCABUBuf);
		break;
	case GIS_KWGXB:
		//m_KWGXBArray.push_back(m_GISBuffer.m_KWGXBBuf);
		break;
	case GIS_PFWELL:
		//m_PFWELLArray.push_back(m_GISBuffer.m_PFWELLBuf);
		break;
	case GIS_PFTUNN:
		//m_PFTUNNArray.push_back(m_GISBuffer.m_PFTUNNBuf);
		break;
	case GIS_ZJ:
		if (!m_GISBuffer.m_ZJBuf.strName.empty())
			m_ZJArray.push_back(m_GISBuffer.m_ZJBuf);
		break;
	default:
		return 0;
		break;
	}
	return 1;
}
