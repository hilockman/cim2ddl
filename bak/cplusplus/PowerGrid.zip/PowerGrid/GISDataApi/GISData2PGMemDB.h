#pragma once

#include "../../MemDB/PGMemDB/PGMemDB.h"
using namespace PGMemDB;

#include "GISData.h"

class GISDATAAPI_API CGISData2PGMemDB
{
public:
	CGISData2PGMemDB(void);
	~CGISData2PGMemDB(void);

public:
	int		FillMemDB(tagPGBlock* pBlock, CGISData* pGData, const int bClearMDB);

public:
	int		ResolveSubstationEntityField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveACLineSegmentField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveDistributionTransformerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveTransformerWindingField(CGISData* pGData, const int nRecord, const int nWind, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveDistributionDisconnectorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolvePipeField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);

	int		ResolvePoleField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveJunctionField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);

	int		ResolveDistributionBreakerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveLoadBreakSwitchField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveFuseField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);

	int		ResolveShuntCapacitorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolvePowerTransformerAsEnergyConsumerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveShuntCompensatorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveSeriesCompensatorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveBreakerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveDisconnectorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveGroundDisconnectorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveConnLineField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);
	int		ResolveBusbarSectionField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG]);

private:
	void	ClearMemDB(tagPGBlock* pBlock);
	void	InsertDefault(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertSubstation(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertBusbarSection(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertCompensator(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertACLineSegment(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertPowerTransformer(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertBreakDisconnector(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertPole(tagPGBlock* pBlock, CGISData* pGData);
	void	InsertPipe(tagPGBlock* pBlock, CGISData* pGData);
	int		PostFillMemDB(tagPGBlock* pBlock, CGISData* pGData);

private:
	const char*	GetVoltageName(CGISData* pGData, const char* lpszBaseVolt);
	float	GetVoltageNorminal(CGISData* pGData, const char* lpszBaseVolt);
	void	ReviseACLineSegmentName(const char* lpszNameIn, char* lpszNameOut);
private:
	//CParamSetting	m_ParamSetting;
};

extern	void		Log(const char* lpszLogFile, char* pformat, ...);
extern	const		char*	g_lpszLogFile;
