#pragma  once

#include "GISDataDefine.h"
#include "GISDataField.h"

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#endif

#if !defined(__GNUG__) && !defined(__GNUC__)
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

static	tagGISTable	g_GISTableArray[]=
{
	{	GIS_RDF,					"rdf:RDF",						"CIM���",			sizeof(g_GISRDFField)					/sizeof(tagGISField),	g_GISRDFField,						0,	},
	{	GIS_PSRType,				"cim:PSRType",					"������Դ",			sizeof(g_GISPSRTypeField)				/sizeof(tagGISField),	g_GISPSRTypeField,					0,	},
	{	GIS_GeographicalRegion,		"cim:GeographicalRegion",		"����ͼ������",		sizeof(g_GISGeographicalRegionField)	/sizeof(tagGISField),	g_GISGeographicalRegionField,		0,	},
	{	GIS_SubGeographicalRegion,	"cim:SubGeographicalRegion",	"�ӵ���ͼ������",	sizeof(g_GISSubGeographicalRegionField)	/sizeof(tagGISField),	g_GISSubGeographicalRegionField,	0,	},
	{	GIS_BaseVoltage,			"cim:BaseVoltage",				"��׼��ѹ",			sizeof(g_GISBaseVoltageField)			/sizeof(tagGISField),	g_GISBaseVoltageField,				0,	},
	{	GIS_Substation,				"cim:Substation",				"��վ",				sizeof(g_GISSubstationField)			/sizeof(tagGISField),	g_GISSubstationField,				sizeof(tagGISVertex),	},
	{	GIS_Feeder,					"cim:Feeder",					"����",				sizeof(g_GISFeederField)				/sizeof(tagGISField),	g_GISFeederField,					0,	},
	{	GIS_CompositeSwitch,		"cim:CompositeSwitch",			"��Ͽ���",			sizeof(g_GISCompositeSwitchField)		/sizeof(tagGISField),	g_GISCompositeSwitchField,			0,	},
	{	GIS_Breaker,				"cim:Breaker",					"��·��",			sizeof(g_GISBreakerField)				/sizeof(tagGISField),	g_GISBreakerField,					sizeof(tagGISVertex)+sizeof(double),	},
	{	GIS_Disconnector,			"cim:Disconnector",				"���뿪��",			sizeof(g_GISDisconnectorField)			/sizeof(tagGISField),	g_GISDisconnectorField,				sizeof(tagGISVertex)+sizeof(double),	},
	{	GIS_GroundDisconnector,		"cim:GroundDisconnector",		"�ӵص�բ",			sizeof(g_GISGroundDisconnectorField)	/sizeof(tagGISField),	g_GISGroundDisconnectorField,		sizeof(tagGISVertex)+sizeof(double)+sizeof(unsigned char),	},
	{	GIS_LoadBreakSwitch,		"cim:LoadBreakSwitch",			"���ɿ���",			sizeof(g_GISLoadBreakSwitchField)		/sizeof(tagGISField),	g_GISLoadBreakSwitchField,			sizeof(tagGISVertex)+sizeof(double),	},
	{	GIS_Fuse,					"cim:Fuse",						"�۶���",			sizeof(g_GISFuseField)					/sizeof(tagGISField),	g_GISFuseField,						sizeof(tagGISVertex)+sizeof(double),	},
	{	GIS_ACLineSegment,			"cim:ACLineSegment",			"���߶�",			sizeof(g_GISACLineSegmentField)			/sizeof(tagGISField),	g_GISACLineSegmentField,			sizeof(unsigned char),	},
	{	GIS_PowerTransformer,		"cim:PowerTransformer",			"������ѹ��",		sizeof(g_GISPowerTransformerField)		/sizeof(tagGISField),	g_GISPowerTransformerField,			4*sizeof(tagGISVertex)+sizeof(double)+2*sizeof(float)+sizeof(unsigned char),	},
	{	GIS_ConnLine,				"cim:ConnLine",					"������",			sizeof(g_GISConnLineField)				/sizeof(tagGISField),	g_GISConnLineField,					2*sizeof(unsigned char),	},
	{	GIS_BusbarSection,			"cim:BusbarSection",			"ĸ�߶�",			sizeof(g_GISBusbarSectionField)			/sizeof(tagGISField),	g_GISBusbarSectionField,			0,	},
	{	GIS_Pole,					"cim:Pole",						"����",				sizeof(g_GISPoleField)					/sizeof(tagGISField),	g_GISPoleField,						sizeof(tagGISVertex)+sizeof(double)+sizeof(unsigned char),		},
	{	GIS_Junction,				"cim:Junction",					"�����ն�",			sizeof(g_GISJunctionField)				/sizeof(tagGISField),	g_GISJunctionField,					sizeof(tagGISVertex)+sizeof(double)+sizeof(unsigned char),		},
	{	GIS_EnergyConsumer,			"cim:EnergyConsumer",			"�����û�",			sizeof(g_GISEnergyConsumerField)		/sizeof(tagGISField),	g_GISEnergyConsumerField,			sizeof(tagGISVertex)+sizeof(double),		},
	{	GIS_Compensator,			"cim:Compensator",				"������",			sizeof(g_GISCompensatorField)			/sizeof(tagGISField),	g_GISCompensatorField,				sizeof(tagGISVertex)+sizeof(double),	},
	//{	GIS_Resistor,				"cim:Resistor",					"������",			sizeof(g_GISResistorField)				/sizeof(tagGISField),	g_GISResistorField,					0,	},
	//{	GIS_Reactor,				"cim:Reactor",					"�翹��",			sizeof(g_GISReactorField)				/sizeof(tagGISField),	g_GISReactorField,					0,	},
	{	GIS_Capacitor,				"cim:Capacitor",				"������",			sizeof(g_GISCapacitorField)				/sizeof(tagGISField),	g_GISCapacitorField,				sizeof(tagGISVertex)+sizeof(double),		},
	{	GIS_Terminal,				"cim:Terminal",					"�˵�",				sizeof(g_GISTerminalField)				/sizeof(tagGISField),	g_GISTerminalField,					sizeof(unsigned char),	},
	{	GIS_ConnectivityNode,		"cim:ConnectivityNode",			"�ڵ�",				sizeof(g_GISConnectivityNodeField)		/sizeof(tagGISField),	g_GISConnectivityNodeField,			sizeof(unsigned char),	},
	{	GIS_Pipe,					"cim:Pipe",						"���¹ܹ�",			sizeof(g_GISPipeField)					/sizeof(tagGISField),	g_GISPipeField,						3*sizeof(short)+45*MDB_CHARLEN,	},
	{	GIS_PT,						"cim:PT",						"��ѹ������",		sizeof(g_GISPTField)					/sizeof(tagGISField),	g_GISPTField,						0,	},
	{	GIS_CT,						"cim:CT",						"����������",		sizeof(g_GISCTField)					/sizeof(tagGISField),	g_GISCTField,						0,	},
	{	GIS_BLQ,					"cim:BLQ",						"������",			sizeof(g_GISBLQField)					/sizeof(tagGISField),	g_GISBLQField,						0,	},
	{	GIS_FaultIndicator,			"cim:FaultIndicator",			"����ָʾ��",		sizeof(g_GISFaultIndicatorField)		/sizeof(tagGISField),	g_GISFaultIndicatorField,			0,	},
	{	GIS_PTCab,					"cim:PTCab",					"PT����",			sizeof(g_GISPTCabField)					/sizeof(tagGISField),	g_GISPTCabField,					0,	},
	{	GIS_Ground,					"cim:Ground",					"�ӵص�",			sizeof(g_GISGroundField)				/sizeof(tagGISField),	g_GISGroundField,					0,	},
	{	GIS_Other,					"cim:Other",					"����(�����·)",	sizeof(g_GISOtherField)					/sizeof(tagGISField),	g_GISOtherField,					0,	},
	{	GIS_PTCABU,					"cim:PTCABU",					"�ܾ�",				sizeof(g_GISPTCABUField)				/sizeof(tagGISField),	g_GISPTCABUField,					0,	},
	{	GIS_KWGXB,					"cim:KWGXB",					"��λ��ϵ��",		sizeof(g_GISKWGXBField)					/sizeof(tagGISField),	g_GISKWGXBField,					0,	},
	{	GIS_PFWELL,					"cim:PFWELL",					"���¾�(��龮)",	sizeof(g_GISPFWELLField)				/sizeof(tagGISField),	g_GISPFWELLField,					0,	},
	{	GIS_PFTUNN,					"cim:PFTUNN",					"����",				sizeof(g_GISPFTUNNField)				/sizeof(tagGISField),	g_GISPFTUNNField,					0,	},
	{	GIS_ZJ,						"cim:ZJ",						"ע������",			sizeof(g_GISZJField)					/sizeof(tagGISField),	g_GISZJField,						0,	},
};

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(fPower)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
