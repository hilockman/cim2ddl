#include "stdafx.h"
#include "GISData.h"

void	CGISData::Check()
{
	register int	i, j;
	int	nNullmRID;

	nNullmRID=0;
	for (i=0; i<(int)m_SubstationArray.size(); i++)
	{
		if (m_SubstationArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Substation NullmRID(%d/%d)\n", nNullmRID, m_SubstationArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_FeederArray.size(); i++)
	{
		if (m_FeederArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Feeder NullmRID(%d/%d)\n", nNullmRID, m_FeederArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		if (m_BreakerArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Breaker NullmRID(%d/%d)\n", nNullmRID, m_BreakerArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		if (m_DisconnectorArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Disconnector NullmRID(%d/%d)\n", nNullmRID, m_DisconnectorArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
	{
		if (m_LoadBreakSwitchArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            LoadBreakSwitch NullmRID(%d/%d)\n", nNullmRID, m_LoadBreakSwitchArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_FuseArray.size(); i++)
	{
		if (m_FuseArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Fuse NullmRID(%d/%d)\n", nNullmRID, m_FuseArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_GroundDisconnectorArray.size(); i++)
	{
		if (m_GroundDisconnectorArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            GroundDisconnector NullmRID(%d/%d)\n", nNullmRID, m_GroundDisconnectorArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		if (m_ACLineSegmentArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            ACLineSegment NullmRID(%d/%d)\n", nNullmRID, m_ACLineSegmentArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_PowerTransformerArray.size(); i++)
	{
		if (m_PowerTransformerArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            PowerTransformer NullmRID(%d/%d)\n", nNullmRID, m_PowerTransformerArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
	{
		if (m_ConnLineArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            ConnLine NullmRID(%d/%d)\n", nNullmRID, m_ConnLineArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_BusbarSectionArray.size(); i++)
	{
		if (m_BusbarSectionArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            BusbarSection NullmRID(%d/%d)\n", nNullmRID, m_BusbarSectionArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_PoleArray.size(); i++)
	{
		if (m_PoleArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Pole NullmRID(%d/%d)\n", nNullmRID, m_PoleArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_JunctionArray.size(); i++)
	{
		if (m_JunctionArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Junction NullmRID(%d/%d)\n", nNullmRID, m_JunctionArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_CompensatorArray.size(); i++)
	{
		if (m_CompensatorArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Compensator NullmRID(%d/%d)\n", nNullmRID, m_CompensatorArray.size());

	nNullmRID=0;
	for (i=0; i<(int)m_CapacitorArray.size(); i++)
	{
		if (m_CapacitorArray[i].strObjectID.empty())
		{
			nNullmRID++;
		}
	}
	Log(g_lpszLogFile, "            Capacitor NullmRID(%d/%d)\n", nNullmRID, m_CapacitorArray.size());

	Log(g_lpszLogFile, "    PrevCheck ACLineSegment@1=%d\n", m_ACLineSegmentArray.size());

	std::vector<tagGISPSRType>					PSRTypeArray;
	PSRTypeArray.clear();
	i=0;
	while (i < (int)m_PSRTypeArray.size())
	{
		j=i+1;
		while (j < (int)m_PSRTypeArray.size())
		{
			if (strcmp(m_PSRTypeArray[i].strResourceID.c_str(),	m_PSRTypeArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PSRTypeArray.push_back(m_PSRTypeArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check PSRType=%d <-> %d\n", m_PSRTypeArray.size(), PSRTypeArray.size());
	m_PSRTypeArray.assign(PSRTypeArray.begin(), PSRTypeArray.end());
	PSRTypeArray.clear();

	std::vector<tagGISRDF>						RDFArray;
	RDFArray.clear();
	i=0;
	while (i < (int)m_RDFArray.size())
	{
		j=i+1;
		while (j < (int)m_RDFArray.size())
		{
			if (strcmp(m_RDFArray[i].strRdf.c_str(),	m_RDFArray[j].strRdf.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		RDFArray.push_back(m_RDFArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check RDF=%d <-> %d\n", m_RDFArray.size(), RDFArray.size());
	m_RDFArray.assign(RDFArray.begin(), RDFArray.end());
	RDFArray.clear();

	std::vector<tagGISGeographicalRegion>		GeographicalRegionArray;
	GeographicalRegionArray.clear();
	i=0;
	while (i < (int)m_GeographicalRegionArray.size())
	{
		j=i+1;
		while (j < (int)m_GeographicalRegionArray.size())
		{
			if (strcmp(m_GeographicalRegionArray[i].strResourceID.c_str(),	m_GeographicalRegionArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		GeographicalRegionArray.push_back(m_GeographicalRegionArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check GeographicalRegion=%d <-> %d\n", m_GeographicalRegionArray.size(), GeographicalRegionArray.size());
	m_GeographicalRegionArray.assign(GeographicalRegionArray.begin(), GeographicalRegionArray.end());
	GeographicalRegionArray.clear();

	std::vector<tagGISSubGeographicalRegion>	SubGeographicalRegionArray;
	SubGeographicalRegionArray.clear();
	i=0;
	while (i < (int)m_SubGeographicalRegionArray.size())
	{
		j=i+1;
		while (j < (int)m_SubGeographicalRegionArray.size())
		{
			if (strcmp(m_SubGeographicalRegionArray[i].strResourceID.c_str(),	m_SubGeographicalRegionArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		SubGeographicalRegionArray.push_back(m_SubGeographicalRegionArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check SubGeographicalRegion=%d <-> %d\n", m_SubGeographicalRegionArray.size(), SubGeographicalRegionArray.size());
	m_SubGeographicalRegionArray.assign(SubGeographicalRegionArray.begin(), SubGeographicalRegionArray.end());
	SubGeographicalRegionArray.clear();

	std::vector<tagGISBaseVoltage>				BaseVoltageArray;
	BaseVoltageArray.clear();
	i=0;
	while (i < (int)m_BaseVoltageArray.size())
	{
		j=i+1;
		while (j < (int)m_BaseVoltageArray.size())
		{
			if (strcmp(m_BaseVoltageArray[i].strResourceID.c_str(),	m_BaseVoltageArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		BaseVoltageArray.push_back(m_BaseVoltageArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check BaseVoltage=%d <-> %d\n", m_BaseVoltageArray.size(), BaseVoltageArray.size());
	m_BaseVoltageArray.assign(BaseVoltageArray.begin(), BaseVoltageArray.end());
	BaseVoltageArray.clear();

	std::vector<tagGISSubstation>				SubstationArray;
	SubstationArray.clear();
	i=0;
	while (i < (int)m_SubstationArray.size())
	{
		j=i+1;
		while (j < (int)m_SubstationArray.size())
		{
			if (strcmp(m_SubstationArray[i].strResourceID.c_str(),	m_SubstationArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		SubstationArray.push_back(m_SubstationArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Substation=%d <-> %d\n", m_SubstationArray.size(), SubstationArray.size());
	m_SubstationArray.assign(SubstationArray.begin(), SubstationArray.end());
	SubstationArray.clear();

	std::vector<tagGISFeeder>					FeederArray;
	FeederArray.clear();
	i=0;
	while (i < (int)m_FeederArray.size())
	{
		j=i+1;
		while (j < (int)m_FeederArray.size())
		{
			if (strcmp(m_FeederArray[i].strResourceID.c_str(),	m_FeederArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		FeederArray.push_back(m_FeederArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Feeder=%d <-> %d\n", m_FeederArray.size(), FeederArray.size());
	m_FeederArray.assign(FeederArray.begin(), FeederArray.end());
	FeederArray.clear();

	std::vector<tagGISCompositeSwitch>			CompositeSwitchArray;
	CompositeSwitchArray.clear();
	i=0;
	while (i < (int)m_CompositeSwitchArray.size())
	{
		j=i+1;
		while (j < (int)m_CompositeSwitchArray.size())
		{
			if (strcmp(m_CompositeSwitchArray[i].strResourceID.c_str(),	m_CompositeSwitchArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		CompositeSwitchArray.push_back(m_CompositeSwitchArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check CompositeSwitch=%d <-> %d\n", m_CompositeSwitchArray.size(), CompositeSwitchArray.size());
	m_CompositeSwitchArray.assign(CompositeSwitchArray.begin(), CompositeSwitchArray.end());
	CompositeSwitchArray.clear();

	std::vector<tagGISBreaker>					BreakerArray;
	BreakerArray.clear();
	i=0;
	while (i < (int)m_BreakerArray.size())
	{
		j=i+1;
		while (j < (int)m_BreakerArray.size())
		{
			if (strcmp(m_BreakerArray[i].strResourceID.c_str(),	m_BreakerArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		BreakerArray.push_back(m_BreakerArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Breaker=%d <-> %d\n", m_BreakerArray.size(), BreakerArray.size());
	m_BreakerArray.assign(BreakerArray.begin(), BreakerArray.end());
	BreakerArray.clear();

	std::vector<tagGISDisconnector>				DisconnectorArray;
	DisconnectorArray.clear();
	i=0;
	while (i < (int)m_DisconnectorArray.size())
	{
		j=i+1;
		while (j < (int)m_DisconnectorArray.size())
		{
			if (strcmp(m_DisconnectorArray[i].strResourceID.c_str(),	m_DisconnectorArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_DisconnectorArray[i].strResourceID.c_str()) >= 0)
			DisconnectorArray.push_back(m_DisconnectorArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Disconnector=%d <-> %d\n", m_DisconnectorArray.size(), DisconnectorArray.size());
	m_DisconnectorArray.assign(DisconnectorArray.begin(), DisconnectorArray.end());
	DisconnectorArray.clear();

	std::vector<tagGISLoadBreakSwitch>			LoadBreakSwitchArray;
	LoadBreakSwitchArray.clear();
	i=0;
	while (i < (int)m_LoadBreakSwitchArray.size())
	{
		j=i+1;
		while (j < (int)m_LoadBreakSwitchArray.size())
		{
			if (strcmp(m_LoadBreakSwitchArray[i].strResourceID.c_str(),	m_LoadBreakSwitchArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		LoadBreakSwitchArray.push_back(m_LoadBreakSwitchArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check LoadBreakSwitch=%d <-> %d\n", m_LoadBreakSwitchArray.size(), LoadBreakSwitchArray.size());
	m_LoadBreakSwitchArray.assign(LoadBreakSwitchArray.begin(), LoadBreakSwitchArray.end());
	LoadBreakSwitchArray.clear();

	std::vector<tagGISFuse>						FuseArray;
	FuseArray.clear();
	i=0;
	while (i < (int)m_FuseArray.size())
	{
		j=i+1;
		while (j < (int)m_FuseArray.size())
		{
			if (strcmp(m_FuseArray[i].strResourceID.c_str(),	m_FuseArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		FuseArray.push_back(m_FuseArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Fuse=%d <-> %d\n", m_FuseArray.size(), FuseArray.size());
	m_FuseArray.assign(FuseArray.begin(), FuseArray.end());
	FuseArray.clear();

	std::vector<tagGISGroundDisconnector>		GroundDisconnectorArray;
	GroundDisconnectorArray.clear();
	i=0;
	while (i < (int)m_GroundDisconnectorArray.size())
	{
		j=i+1;
		while (j < (int)m_GroundDisconnectorArray.size())
		{
			if (strcmp(m_GroundDisconnectorArray[i].strResourceID.c_str(),	m_GroundDisconnectorArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_GroundDisconnectorArray[i].strResourceID.c_str()) >= 0)
			GroundDisconnectorArray.push_back(m_GroundDisconnectorArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check GroundDisconnector=%d <-> %d\n", m_GroundDisconnectorArray.size(), GroundDisconnectorArray.size());
	m_GroundDisconnectorArray.assign(GroundDisconnectorArray.begin(), GroundDisconnectorArray.end());
	GroundDisconnectorArray.clear();

	std::vector<tagGISACLineSegment>			ACLineSegmentArray;
	ACLineSegmentArray.clear();
	i=0;
	while (i < (int)m_ACLineSegmentArray.size())
	{
		j=i+1;
		while (j < (int)m_ACLineSegmentArray.size())
		{
			if (strcmp(m_ACLineSegmentArray[i].strResourceID.c_str(),	m_ACLineSegmentArray[j].strResourceID.c_str()) == 0)
			{
#ifdef	_DEBUG
				Log(g_lpszLogFile, "            Same ACLineSegment ID=%s\n", m_ACLineSegmentArray[i].strResourceID.c_str());
#endif
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		ACLineSegmentArray.push_back(m_ACLineSegmentArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check ACLineSegment=%d <-> %d\n", m_ACLineSegmentArray.size(), ACLineSegmentArray.size());
	m_ACLineSegmentArray.assign(ACLineSegmentArray.begin(), ACLineSegmentArray.end());
	ACLineSegmentArray.clear();

	std::vector<tagGISPowerTransformer>			PowerTransformerArray;
	PowerTransformerArray.clear();
	i=0;
	while (i < (int)m_PowerTransformerArray.size())
	{
		j=i+1;
		while (j < (int)m_PowerTransformerArray.size())
		{
			if (strcmp(m_PowerTransformerArray[i].strResourceID.c_str(),	m_PowerTransformerArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PowerTransformerArray.push_back(m_PowerTransformerArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check PowerTransformer=%d <-> %d\n", m_PowerTransformerArray.size(), PowerTransformerArray.size());
	m_PowerTransformerArray.assign(PowerTransformerArray.begin(), PowerTransformerArray.end());
	PowerTransformerArray.clear();

	std::vector<tagGISConnLine>					ConnLineArray;
	ConnLineArray.clear();
	i=0;
	while (i < (int)m_ConnLineArray.size())
	{
		j=i+1;
		while (j < (int)m_ConnLineArray.size())
		{
			if (strcmp(m_ConnLineArray[i].strResourceID.c_str(),	m_ConnLineArray[j].strResourceID.c_str()) == 0)
			{
#ifdef	_DEBUG
				Log(g_lpszLogFile, "            Same ConnLine ID=%s\n", m_ConnLineArray[i].strResourceID.c_str());
#endif
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		ConnLineArray.push_back(m_ConnLineArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check ConnLine=%d <-> %d\n", m_ConnLineArray.size(), ConnLineArray.size());
	m_ConnLineArray.assign(ConnLineArray.begin(), ConnLineArray.end());
	ConnLineArray.clear();

	std::vector<tagGISBusbarSection>			BusbarSectionArray;
	BusbarSectionArray.clear();
	i=0;
	while (i < (int)m_BusbarSectionArray.size())
	{
		j=i+1;
		while (j < (int)m_BusbarSectionArray.size())
		{
			if (strcmp(m_BusbarSectionArray[i].strResourceID.c_str(),	m_BusbarSectionArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}

		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_BusbarSectionArray[i].strResourceID.c_str()) >= 0)
			BusbarSectionArray.push_back(m_BusbarSectionArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check BusbarSection=%d <-> %d\n", m_BusbarSectionArray.size(), BusbarSectionArray.size());
	m_BusbarSectionArray.assign(BusbarSectionArray.begin(), BusbarSectionArray.end());
	BusbarSectionArray.clear();

	std::vector<tagGISPole>						PoleArray;
	PoleArray.clear();
	i=0;
	while (i < (int)m_PoleArray.size())
	{
		j=i+1;
		while (j < (int)m_PoleArray.size())
		{
			if (strcmp(m_PoleArray[i].strResourceID.c_str(),	m_PoleArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_PoleArray[i].strResourceID.c_str()) >= 0)
			PoleArray.push_back(m_PoleArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Pole=%d <-> %d\n", m_PoleArray.size(), PoleArray.size());
	m_PoleArray.assign(PoleArray.begin(), PoleArray.end());
	PoleArray.clear();

	std::vector<tagGISJunction>					JunctionArray;
	JunctionArray.clear();
	i=0;
	while (i < (int)m_JunctionArray.size())
	{
		j=i+1;
		while (j < (int)m_JunctionArray.size())
		{
			if (strcmp(m_JunctionArray[i].strResourceID.c_str(),	m_JunctionArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_JunctionArray[i].strResourceID.c_str()) >= 0)
			JunctionArray.push_back(m_JunctionArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Junction=%d <-> %d\n", m_JunctionArray.size(), JunctionArray.size());
	m_JunctionArray.assign(JunctionArray.begin(), JunctionArray.end());
	JunctionArray.clear();

	std::vector<tagGISEnergyConsumer>			EnergyConsumerArray;
	EnergyConsumerArray.clear();
	i=0;
	while (i < (int)m_EnergyConsumerArray.size())
	{
		j=i+1;
		while (j < (int)m_EnergyConsumerArray.size())
		{
			if (strcmp(m_EnergyConsumerArray[i].strResourceID.c_str(),	m_EnergyConsumerArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_EnergyConsumerArray[i].strResourceID.c_str()) >= 0)
			EnergyConsumerArray.push_back(m_EnergyConsumerArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check EnergyConsumer=%d <-> %d\n", m_EnergyConsumerArray.size(), EnergyConsumerArray.size());
	m_EnergyConsumerArray.assign(EnergyConsumerArray.begin(), EnergyConsumerArray.end());
	EnergyConsumerArray.clear();

	std::vector<tagGISCompensator>				CompensatorArray;
	CompensatorArray.clear();
	i=0;
	while (i < (int)m_CompensatorArray.size())
	{
		j=i+1;
		while (j < (int)m_CompensatorArray.size())
		{
			if (strcmp(m_CompensatorArray[i].strResourceID.c_str(),	m_CompensatorArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		CompensatorArray.push_back(m_CompensatorArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Compensator=%d <-> %d\n", m_CompensatorArray.size(), CompensatorArray.size());
	m_CompensatorArray.assign(CompensatorArray.begin(), CompensatorArray.end());
	CompensatorArray.clear();

	std::vector<tagGISCapacitor>				CapacitorArray;
	CapacitorArray.clear();
	i=0;
	while (i < (int)m_CapacitorArray.size())
	{
		j=i+1;
		while (j < (int)m_CapacitorArray.size())
		{
			if (strcmp(m_CapacitorArray[i].strResourceID.c_str(),	m_CapacitorArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		if (findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_CapacitorArray[i].strResourceID.c_str()) >= 0)
			CapacitorArray.push_back(m_CapacitorArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Capacitor=%d <-> %d\n", m_CapacitorArray.size(), CapacitorArray.size());
	m_CapacitorArray.assign(CapacitorArray.begin(), CapacitorArray.end());
	CapacitorArray.clear();

	std::vector<tagGISTerminal>					TerminalArray;
	TerminalArray.clear();
	i=0;
	while (i < (int)m_TerminalArray.size())
	{
		j=i+1;
		while (j < (int)m_TerminalArray.size())
		{
			if (strcmp(m_TerminalArray[i].strResourceID.c_str(),	m_TerminalArray[j].strResourceID.c_str()) == 0)
			{
#ifdef	_DEBUG
				Log(g_lpszLogFile, "            Same Terminal ID=%s\n", m_TerminalArray[i].strResourceID.c_str());
#endif
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		TerminalArray.push_back(m_TerminalArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check Terminal=%d <-> %d\n", m_TerminalArray.size(), TerminalArray.size());
	m_TerminalArray.assign(TerminalArray.begin(), TerminalArray.end());
	TerminalArray.clear();

	std::vector<tagGISConnectivityNode>			ConnectivityNodeArray;
	ConnectivityNodeArray.clear();
	i=0;
	while (i < (int)m_ConnectivityNodeArray.size())
	{
		j=i+1;
		while (j < (int)m_ConnectivityNodeArray.size())
		{
			if (strcmp(m_ConnectivityNodeArray[i].strResourceID.c_str(),	m_ConnectivityNodeArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		ConnectivityNodeArray.push_back(m_ConnectivityNodeArray[i]);
		i++;
	}
	Log(g_lpszLogFile, "        Check ConnectivityNode=%d <-> %d\n", m_ConnectivityNodeArray.size(), ConnectivityNodeArray.size());
	m_ConnectivityNodeArray.assign(ConnectivityNodeArray.begin(), ConnectivityNodeArray.end());
	ConnectivityNodeArray.clear();

	std::vector<tagGISPipe>						PipeArray;
	PipeArray.clear();
	i=0;
	while (i < (int)m_PipeArray.size())
	{
		j=i+1;
		while (j < (int)m_PipeArray.size())
		{
			if (strcmp(m_PipeArray[i].strResourceID.c_str(),	m_PipeArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PipeArray.push_back(m_PipeArray[i]);
		i++;
	}
	m_PipeArray.assign(PipeArray.begin(), PipeArray.end());
	PipeArray.clear();

	std::vector<tagGISPT>						PTArray;
	PTArray.clear();
	i=0;
	while (i < (int)m_PTArray.size())
	{
		j=i+1;
		while (j < (int)m_PTArray.size())
		{
			if (strcmp(m_PTArray[i].strResourceID.c_str(),	m_PTArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PTArray.push_back(m_PTArray[i]);
		i++;
	}
	m_PTArray.assign(PTArray.begin(), PTArray.end());
	PTArray.clear();

	std::vector<tagGISCT>						CTArray;
	CTArray.clear();
	i=0;
	while (i < (int)m_CTArray.size())
	{
		j=i+1;
		while (j < (int)m_CTArray.size())
		{
			if (strcmp(m_CTArray[i].strResourceID.c_str(),	m_CTArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		CTArray.push_back(m_CTArray[i]);
		i++;
	}
	m_CTArray.assign(CTArray.begin(), CTArray.end());
	CTArray.clear();

	std::vector<tagGISBLQ>						BLQArray;
	BLQArray.clear();
	i=0;
	while (i < (int)m_BLQArray.size())
	{
		j=i+1;
		while (j < (int)m_BLQArray.size())
		{
			if (strcmp(m_BLQArray[i].strResourceID.c_str(),	m_BLQArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		BLQArray.push_back(m_BLQArray[i]);
		i++;
	}
	m_BLQArray.assign(BLQArray.begin(), BLQArray.end());
	BLQArray.clear();

	std::vector<tagGISFaultIndicator>			FaultIndicatorArray;
	FaultIndicatorArray.clear();
	i=0;
	while (i < (int)m_FaultIndicatorArray.size())
	{
		j=i+1;
		while (j < (int)m_FaultIndicatorArray.size())
		{
			if (strcmp(m_FaultIndicatorArray[i].strResourceID.c_str(),	m_FaultIndicatorArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		FaultIndicatorArray.push_back(m_FaultIndicatorArray[i]);
		i++;
	}
	m_FaultIndicatorArray.assign(FaultIndicatorArray.begin(), FaultIndicatorArray.end());
	FaultIndicatorArray.clear();

	std::vector<tagGISPTCab>					PTCabArray;
	PTCabArray.clear();
	i=0;
	while (i < (int)m_PTCabArray.size())
	{
		j=i+1;
		while (j < (int)m_PTCabArray.size())
		{
			if (strcmp(m_PTCabArray[i].strResourceID.c_str(),	m_PTCabArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PTCabArray.push_back(m_PTCabArray[i]);
		i++;
	}
	m_PTCabArray.assign(PTCabArray.begin(), PTCabArray.end());
	PTCabArray.clear();

	std::vector<tagGISGround>					GroundArray;
	GroundArray.clear();
	i=0;
	while (i < (int)m_GroundArray.size())
	{
		j=i+1;
		while (j < (int)m_GroundArray.size())
		{
			if (strcmp(m_GroundArray[i].strResourceID.c_str(),	m_GroundArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		GroundArray.push_back(m_GroundArray[i]);
		i++;
	}
	m_GroundArray.assign(GroundArray.begin(), GroundArray.end());
	GroundArray.clear();

	std::vector<tagGISOther>					OtherArray;
	OtherArray.clear();
	i=0;
	while (i < (int)m_OtherArray.size())
	{
		j=i+1;
		while (j < (int)m_OtherArray.size())
		{
			if (strcmp(m_OtherArray[i].strResourceID.c_str(),	m_OtherArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		OtherArray.push_back(m_OtherArray[i]);
		i++;
	}
	m_OtherArray.assign(OtherArray.begin(), OtherArray.end());
	OtherArray.clear();

	std::vector<tagGISPTCABU>					PTCABUArray;
	PTCABUArray.clear();
	i=0;
	while (i < (int)m_PTCABUArray.size())
	{
		j=i+1;
		while (j < (int)m_PTCABUArray.size())
		{
			if (strcmp(m_PTCABUArray[i].strResourceID.c_str(),	m_PTCABUArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PTCABUArray.push_back(m_PTCABUArray[i]);
		i++;
	}
	m_PTCABUArray.assign(PTCABUArray.begin(), PTCABUArray.end());
	PTCABUArray.clear();

	std::vector<tagGISKWGXB>					KWGXBArray;
	KWGXBArray.clear();
	i=0;
	while (i < (int)m_KWGXBArray.size())
	{
		j=i+1;
		while (j < (int)m_KWGXBArray.size())
		{
			if (strcmp(m_KWGXBArray[i].strResourceID.c_str(),	m_KWGXBArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		KWGXBArray.push_back(m_KWGXBArray[i]);
		i++;
	}
	m_KWGXBArray.assign(KWGXBArray.begin(), KWGXBArray.end());
	KWGXBArray.clear();

	std::vector<tagGISPFWELL>					PFWELLArray;
	PFWELLArray.clear();
	i=0;
	while (i < (int)m_PFWELLArray.size())
	{
		j=i+1;
		while (j < (int)m_PFWELLArray.size())
		{
			if (strcmp(m_PFWELLArray[i].strResourceID.c_str(),	m_PFWELLArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PFWELLArray.push_back(m_PFWELLArray[i]);
		i++;
	}
	m_PFWELLArray.assign(PFWELLArray.begin(), PFWELLArray.end());
	PFWELLArray.clear();

	std::vector<tagGISPFTUNN>					PFTUNNArray;
	PFTUNNArray.clear();
	i=0;
	while (i < (int)m_PFTUNNArray.size())
	{
		j=i+1;
		while (j < (int)m_PFTUNNArray.size())
		{
			if (strcmp(m_PFTUNNArray[i].strResourceID.c_str(),	m_PFTUNNArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		PFTUNNArray.push_back(m_PFTUNNArray[i]);
		i++;
	}
	m_PFTUNNArray.assign(PFTUNNArray.begin(), PFTUNNArray.end());
	PFTUNNArray.clear();

	std::vector<tagGISZJ>						ZJArray;
	ZJArray.clear();
	i=0;
	while (i < (int)m_ZJArray.size())
	{
		j=i+1;
		while (j < (int)m_ZJArray.size())
		{
			if (strcmp(m_ZJArray[i].strResourceID.c_str(),	m_ZJArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		ZJArray.push_back(m_ZJArray[i]);
		i++;
	}
	m_ZJArray.assign(ZJArray.begin(), ZJArray.end());
	ZJArray.clear();

	Log(g_lpszLogFile, "    PostCheck ACLineSegment@1=%d\n", m_ACLineSegmentArray.size());
}


void	CGISData::RemoveNoTopoDevice()
{
	register int	i;

	std::vector<tagGISBreaker>					BreakerArray;
	BreakerArray.clear();
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		if (!m_BreakerArray[i].strNodeI.empty() && !m_BreakerArray[i].strNodeZ.empty())
			BreakerArray.push_back(m_BreakerArray[i]);
	}
	m_BreakerArray.assign(BreakerArray.begin(), BreakerArray.end());
	BreakerArray.clear();

	std::vector<tagGISDisconnector>				DisconnectorArray;
	DisconnectorArray.clear();
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		if (!m_DisconnectorArray[i].strNodeI.empty() && !m_DisconnectorArray[i].strNodeZ.empty())
			DisconnectorArray.push_back(m_DisconnectorArray[i]);
	}
	m_DisconnectorArray.assign(DisconnectorArray.begin(), DisconnectorArray.end());
	DisconnectorArray.clear();

	std::vector<tagGISLoadBreakSwitch>			LoadBreakSwitchArray;
	LoadBreakSwitchArray.clear();
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
	{
		if (!m_LoadBreakSwitchArray[i].strNodeI.empty() && !m_LoadBreakSwitchArray[i].strNodeZ.empty())
			LoadBreakSwitchArray.push_back(m_LoadBreakSwitchArray[i]);
	}
	m_LoadBreakSwitchArray.assign(LoadBreakSwitchArray.begin(), LoadBreakSwitchArray.end());
	LoadBreakSwitchArray.clear();

	std::vector<tagGISFuse>						FuseArray;
	FuseArray.clear();
	for (i=0; i<(int)m_FuseArray.size(); i++)
	{
		if (!m_FuseArray[i].strNodeI.empty() && !m_FuseArray[i].strNodeZ.empty())
			FuseArray.push_back(m_FuseArray[i]);
	}
	m_FuseArray.assign(FuseArray.begin(), FuseArray.end());
	FuseArray.clear();

	std::vector<tagGISGroundDisconnector>		GroundDisconnectorArray;
	GroundDisconnectorArray.clear();
	for (i=0; i<(int)m_GroundDisconnectorArray.size(); i++)
	{
		if (!m_GroundDisconnectorArray[i].strNode.empty())
			GroundDisconnectorArray.push_back(m_GroundDisconnectorArray[i]);
	}
	m_GroundDisconnectorArray.assign(GroundDisconnectorArray.begin(), GroundDisconnectorArray.end());
	GroundDisconnectorArray.clear();

	std::vector<tagGISACLineSegment>			ACLineSegmentArray;
	ACLineSegmentArray.clear();
	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		if (!m_ACLineSegmentArray[i].strNodeI.empty() && !m_ACLineSegmentArray[i].strNodeZ.empty())
			ACLineSegmentArray.push_back(m_ACLineSegmentArray[i]);
	}
	m_ACLineSegmentArray.assign(ACLineSegmentArray.begin(), ACLineSegmentArray.end());
	ACLineSegmentArray.clear();

	std::vector<tagGISPowerTransformer>			PowerTransformerArray;
	PowerTransformerArray.clear();
	for (i=0; i<(int)m_PowerTransformerArray.size(); i++)
	{
		if (!m_PowerTransformerArray[i].strNodeArray[0].empty() || !m_PowerTransformerArray[i].strNodeArray[1].empty() || !m_PowerTransformerArray[i].strNodeArray[2].empty())
			PowerTransformerArray.push_back(m_PowerTransformerArray[i]);
	}
	m_PowerTransformerArray.assign(PowerTransformerArray.begin(), PowerTransformerArray.end());
	PowerTransformerArray.clear();

	std::vector<tagGISConnLine>					ConnLineArray;
	ConnLineArray.clear();
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
	{
		if (!m_ConnLineArray[i].strNodeI.empty() && !m_ConnLineArray[i].strNodeZ.empty())
			ConnLineArray.push_back(m_ConnLineArray[i]);
	}
	m_ConnLineArray.assign(ConnLineArray.begin(), ConnLineArray.end());
	ConnLineArray.clear();

	std::vector<tagGISBusbarSection>			BusbarSectionArray;
	BusbarSectionArray.clear();
	for (i=0; i<(int)m_BusbarSectionArray.size(); i++)
	{
		if (!m_BusbarSectionArray[i].strNode.empty())
			BusbarSectionArray.push_back(m_BusbarSectionArray[i]);
	}
	m_BusbarSectionArray.assign(BusbarSectionArray.begin(), BusbarSectionArray.end());
	BusbarSectionArray.clear();

	std::vector<tagGISPole>						PoleArray;
	PoleArray.clear();
	for (i=0; i<(int)m_PoleArray.size(); i++)
	{
		if (!m_PoleArray[i].strNode.empty())
			PoleArray.push_back(m_PoleArray[i]);
	}
	m_PoleArray.assign(PoleArray.begin(), PoleArray.end());
	PoleArray.clear();

	std::vector<tagGISJunction>					JunctionArray;
	JunctionArray.clear();
	for (i=0; i<(int)m_JunctionArray.size(); i++)
	{
		if (!m_JunctionArray[i].strNode.empty())
			JunctionArray.push_back(m_JunctionArray[i]);
	}
	m_JunctionArray.assign(JunctionArray.begin(), JunctionArray.end());
	JunctionArray.clear();

	std::vector<tagGISEnergyConsumer>			EnergyConsumerArray;
	EnergyConsumerArray.clear();
	for (i=0; i<(int)m_EnergyConsumerArray.size(); i++)
	{
		if (!m_EnergyConsumerArray[i].strNode.empty())
			EnergyConsumerArray.push_back(m_EnergyConsumerArray[i]);
	}
	m_EnergyConsumerArray.assign(EnergyConsumerArray.begin(), EnergyConsumerArray.end());
	EnergyConsumerArray.clear();

	std::vector<tagGISCompensator>				CompensatorArray;
	CompensatorArray.clear();
	for (i=0; i<(int)m_CompensatorArray.size(); i++)
	{
		if (!m_CompensatorArray[i].strNode.empty())
			CompensatorArray.push_back(m_CompensatorArray[i]);
	}
	m_CompensatorArray.assign(CompensatorArray.begin(), CompensatorArray.end());
	CompensatorArray.clear();

	std::vector<tagGISCapacitor>				CapacitorArray;
	CapacitorArray.clear();
	for (i=0; i<(int)m_CapacitorArray.size(); i++)
	{
		if (!m_CapacitorArray[i].strNode.empty())
			CapacitorArray.push_back(m_CapacitorArray[i]);
	}
	m_CapacitorArray.assign(CapacitorArray.begin(), CapacitorArray.end());
	CapacitorArray.clear();
}

int		CGISData::CheckNodeGroupValidate(std::vector<int>& nNodeArray)
{
	register int	i;
	int		nNode;
	unsigned char	bExist;
	std::vector<std::string>	strSubstationArray;

	strSubstationArray.clear();
	for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
	{
		for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
		{
			if (!m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParent.empty())
			{
				bExist=0;
				for (i=0; i<(int)strSubstationArray.size(); i++)
				{
					if (strcmp(strSubstationArray[i].c_str(), m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParent.c_str()) == 0)
					{
						bExist=1;
						break;
					}
				}
				if (!bExist)
					strSubstationArray.push_back(m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParent);
			}
		}
	}
	if (strSubstationArray.size() == 1)
		return 1;

	for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
	{
		for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
		{
			if (!m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParent.empty())
			{
				bExist=0;
				for (i=0; i<(int)strSubstationArray.size(); i++)
				{
					if (strcmp(strSubstationArray[i].c_str(), m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParent.c_str()) == 0)
					{
						bExist=1;
						break;
					}
				}
				if (!bExist)
					strSubstationArray.push_back(m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParent);
			}
		}
	}
	for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
	{
		for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
		{
			if (!m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParent.empty())
			{
				bExist=0;
				for (i=0; i<(int)strSubstationArray.size(); i++)
				{
					if (strcmp(strSubstationArray[i].c_str(), m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParent.c_str()) == 0)
					{
						bExist=1;
						break;
					}
				}
				if (!bExist)
					strSubstationArray.push_back(m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParent);
			}
		}
	}
	if (strSubstationArray.size() == 1)
		return 1;
	return 0;
}

void	CGISData::RemoveNouse_Substation()
{
	int	nSub;

	FormSub2Equipment();

	std::vector<tagGISSubstation>	SubArray;
	SubArray.clear();
	for (nSub=0; nSub<(int)m_SubstationArray.size(); nSub++)
	{
		if (m_Sub2EquipmentArray[nSub].strVoltTagArray.empty() &&
		m_Sub2EquipmentArray[nSub].nFeederArray.empty() &&
		m_Sub2EquipmentArray[nSub].nBreakerArray.empty() &&
		m_Sub2EquipmentArray[nSub].nDisconnectorArray.empty() &&
		m_Sub2EquipmentArray[nSub].nLoadBreakSwitchArray.empty() &&
		m_Sub2EquipmentArray[nSub].nFuseArray.empty() &&
		m_Sub2EquipmentArray[nSub].nACLineSegmentArray.empty() &&
		m_Sub2EquipmentArray[nSub].nConnLineArray.empty() &&
		m_Sub2EquipmentArray[nSub].nBusbarSectionArray.empty() &&
		m_Sub2EquipmentArray[nSub].nPowerTransformerArray.empty() &&
		m_Sub2EquipmentArray[nSub].nGroundDisconnectorArray.empty() &&
		m_Sub2EquipmentArray[nSub].nCompensatorArray.empty() &&
		m_Sub2EquipmentArray[nSub].nCapacitorArray.empty() &&
		m_Sub2EquipmentArray[nSub].nPoleArray.empty() &&
		m_Sub2EquipmentArray[nSub].nJunctionArray.empty())
		continue;

		SubArray.push_back(m_SubstationArray[nSub]);
	}
	m_SubstationArray.assign(SubArray.begin(), SubArray.end());
	SubArray.clear();

	FormSub2Equipment();
}

void	CGISData::RemoveNouse_Pole()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<tagGISPole>			PoleArray;
	std::vector<int>	nNodeArray;

	PoleArray.clear();
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		if (m_PoleArray[nDev].strNode.empty() || m_PoleArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_PoleArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}
		if (nBranNum > 0)
			PoleArray.push_back(m_PoleArray[nDev]);
	}
	m_PoleArray.assign(PoleArray.begin(), PoleArray.end());
	PoleArray.clear();
}

void	CGISData::RemoveNouse_Junction()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<tagGISJunction>		JunctionArray;
	std::vector<int>	nNodeArray;

	JunctionArray.clear();
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].strNode.empty() || m_JunctionArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_JunctionArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}
		if (nBranNum > 0)
			JunctionArray.push_back(m_JunctionArray[nDev]);
	}
	m_JunctionArray.assign(JunctionArray.begin(), JunctionArray.end());
	JunctionArray.clear();
}

void	CGISData::RemoveNouse_BusbarSection()
{
	register int	i;
	int		nDev;
	std::vector<tagGISBusbarSection>		BusbarSectionArray;
	int		nBranNum;
	std::vector<int>	nNodeArray;

	BusbarSectionArray.clear();
	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		if (m_BusbarSectionArray[nDev].strNode.empty() || m_BusbarSectionArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_BusbarSectionArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}
		if (nBranNum > 0)
			BusbarSectionArray.push_back(m_BusbarSectionArray[nDev]);
	}
	m_BusbarSectionArray.assign(BusbarSectionArray.begin(), BusbarSectionArray.end());
	BusbarSectionArray.clear();
}

void	CGISData::RemoveNouse_Compensator()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		if (m_CompensatorArray[nDev].strNode.empty() || m_CompensatorArray[nDev].nNode < 0)
			continue;

		if (m_CompensatorArray[nDev].strSeriesNode.empty() || m_CompensatorArray[nDev].nSeriesNode < 0)
		{
			nBranNum=0;
			TraverseNode(m_CompensatorArray[nDev].nNode, nNodeArray);
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
			}
			if (nBranNum > 1)
				m_CompensatorArray[nDev].bFlag=1;
		}
		else
		{
			nBranNum=0;
			TraverseNode(m_CompensatorArray[nDev].nNode, nNodeArray);
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
				nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
			}

			if (nBranNum > 2)
				m_CompensatorArray[nDev].bFlag=1;
		}
	}
}

void	CGISData::RemoveNouse_Capacitor()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<tagGISCapacitor>		CapacitorArray;
	std::vector<int>	nNodeArray;

	CapacitorArray.clear();
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		if (m_CapacitorArray[nDev].strNode.empty() || m_CapacitorArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_CapacitorArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}
		if (nBranNum > 1)
			CapacitorArray.push_back(m_CapacitorArray[nDev]);
	}
	m_CapacitorArray.assign(CapacitorArray.begin(), CapacitorArray.end());
	CapacitorArray.clear();
}

void	CGISData::RemoveNouse_GroundDisconnector()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<tagGISGroundDisconnector>		GroundDisconnectorArray;
	std::vector<int>	nNodeArray;

	GroundDisconnectorArray.clear();
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		if (m_GroundDisconnectorArray[nDev].strNode.empty() || m_GroundDisconnectorArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_GroundDisconnectorArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}

		if (nBranNum > 0)
			GroundDisconnectorArray.push_back(m_GroundDisconnectorArray[nDev]);
	}
	m_GroundDisconnectorArray.assign(GroundDisconnectorArray.begin(), GroundDisconnectorArray.end());
	GroundDisconnectorArray.clear();
}

void	CGISData::RemoveNouse_Breaker()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (m_BreakerArray[nDev].strNodeI.empty() || m_BreakerArray[nDev].strNodeZ.empty())
			continue;
		if (m_BreakerArray[nDev].nNodeI < 0 || m_BreakerArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_BreakerArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}

		if (nBranNum > 2)
			m_BreakerArray[nDev].bFlag=1;
	}
}

void	CGISData::RemoveNouse_Disconnector()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (m_DisconnectorArray[nDev].strNodeI.empty() || m_DisconnectorArray[nDev].strNodeZ.empty())
			continue;
		if (m_DisconnectorArray[nDev].nNodeI < 0 || m_DisconnectorArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_DisconnectorArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}

		if (nBranNum > 2)
			m_DisconnectorArray[nDev].bFlag=1;
	}
}

void	CGISData::RemoveNouse_LoadBreakSwitch()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		if (m_LoadBreakSwitchArray[nDev].strNodeI.empty() || m_LoadBreakSwitchArray[nDev].strNodeZ.empty())
			continue;
		if (m_LoadBreakSwitchArray[nDev].nNodeI < 0 || m_LoadBreakSwitchArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_LoadBreakSwitchArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}

		if (nBranNum > 2)
			m_LoadBreakSwitchArray[nDev].bFlag=1;
	}
}

void	CGISData::RemoveNouse_Fuse()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		if (m_FuseArray[nDev].strNodeI.empty() || m_FuseArray[nDev].strNodeZ.empty())
			continue;
		if (m_FuseArray[nDev].nNodeI < 0 || m_FuseArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_FuseArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}

		if (nBranNum > 2)
			m_FuseArray[nDev].bFlag=1;
	}
}

void	CGISData::RemoveNouse_ConnLine()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		if (m_ConnLineArray[nDev].strNodeI.empty() && m_ConnLineArray[nDev].strNodeZ.empty())
			continue;
		if (m_ConnLineArray[nDev].nNodeI < 0)
			continue;

		nBranNum=0;
		TraverseNode(m_ConnLineArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nEnergyConsumerArray.size();
		}
		if (nBranNum > 0)
			m_ConnLineArray[nDev].bFlag=1;
	}
}

void	CGISData::RemoveNouse_ACLineSegment()
{
	register int	i;
	std::vector<tagGISACLineSegment>		acLineSegmentArray;
	acLineSegmentArray.clear();
	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		if (m_ACLineSegmentArray[i].strNodeI.empty() || m_ACLineSegmentArray[i].strNodeZ.empty())
			continue;
		if (m_ACLineSegmentArray[i].nNodeI < 0 || m_ACLineSegmentArray[i].nNodeZ < 0)
			continue;
		acLineSegmentArray.push_back(m_ACLineSegmentArray[i]);
	}
	m_ACLineSegmentArray.assign(acLineSegmentArray.begin(), acLineSegmentArray.end());
	acLineSegmentArray.clear();
}

void	CGISData::RemoveNouse_PowerTransformer()
{
	register int	i;
	std::vector<tagGISPowerTransformer>		powerTransformerArray;
	powerTransformerArray.clear();
	for (i=0; i<(int)m_PowerTransformerArray.size(); i++)
	{
		if (m_PowerTransformerArray[i].strNodeArray[0].empty() && m_PowerTransformerArray[i].strNodeArray[1].empty() && m_PowerTransformerArray[i].strNodeArray[2].empty())
			continue;
		if (m_PowerTransformerArray[i].strVoltTagArray[0].empty() && m_PowerTransformerArray[i].strVoltTagArray[1].empty() && m_PowerTransformerArray[i].strVoltTagArray[2].empty())
			continue;
		powerTransformerArray.push_back(m_PowerTransformerArray[i]);
	}
	m_PowerTransformerArray.assign(powerTransformerArray.begin(), powerTransformerArray.end());
	powerTransformerArray.clear();
}

void	CGISData::RemoveNouseDevice()
{
	register int	i;
	std::vector<tagGISBreaker>			breakerArray;
	std::vector<tagGISDisconnector>		disconnectorArray;
	std::vector<tagGISLoadBreakSwitch>	loadBreakSwitchArray;
	std::vector<tagGISFuse>				fuseArray;
	std::vector<tagGISConnLine>			connLineArray;
	std::vector<tagGISCompensator>		compensatorArray;

	for (i=0; i<(int)m_BreakerArray.size(); i++)
		m_BreakerArray[i].bFlag=0;
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
		m_DisconnectorArray[i].bFlag=0;
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
		m_LoadBreakSwitchArray[i].bFlag=0;
	for (i=0; i<(int)m_FuseArray.size(); i++)
		m_FuseArray[i].bFlag=0;
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
		m_ConnLineArray[i].bFlag=0;
	for (i=0; i<(int)m_CompensatorArray.size(); i++)
		m_CompensatorArray[i].bFlag=0;

	RemoveNouse_Substation();			Log(g_lpszLogFile, "RemoveNouse_Substation\n");
	RemoveNouse_Pole();					Log(g_lpszLogFile, "RemoveNouse_Pole\n");
	RemoveNouse_Junction();				Log(g_lpszLogFile, "RemoveNouse_Junction\n");
	RemoveNouse_BusbarSection();		Log(g_lpszLogFile, "RemoveNouse_BusbarSection\n");
	RemoveNouse_Compensator();			Log(g_lpszLogFile, "RemoveNouse_Compensator\n");
	RemoveNouse_Capacitor();			Log(g_lpszLogFile, "RemoveNouse_Capacitor\n");
	RemoveNouse_GroundDisconnector();	Log(g_lpszLogFile, "RemoveNouse_GroundDisconnector\n");
	RemoveNouse_Breaker();				Log(g_lpszLogFile, "RemoveNouse_Breaker\n");
	RemoveNouse_Disconnector();			Log(g_lpszLogFile, "RemoveNouse_Disconnector\n");
	RemoveNouse_LoadBreakSwitch();		Log(g_lpszLogFile, "RemoveNouse_LoadBreakSwitch\n");
	RemoveNouse_Fuse();					Log(g_lpszLogFile, "RemoveNouse_Fuse\n");

	RemoveNouse_ConnLine();				Log(g_lpszLogFile, "RemoveNouse_ConnLine\n");

	RemoveNouse_ACLineSegment();		Log(g_lpszLogFile, "RemoveNouse_ACLineSegment\n");
	RemoveNouse_PowerTransformer();		Log(g_lpszLogFile, "RemoveNouse_PowerTransformer\n");

	//	��ֹ��Ϊɾ���豸������˵Ĵ���
	breakerArray.clear();
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		if (m_BreakerArray[i].bFlag)
			breakerArray.push_back(m_BreakerArray[i]);
	}
	m_BreakerArray.assign(breakerArray.begin(), breakerArray.end());
	breakerArray.clear();

	disconnectorArray.clear();
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		if (m_DisconnectorArray[i].bFlag)
			disconnectorArray.push_back(m_DisconnectorArray[i]);
	}
	m_DisconnectorArray.assign(disconnectorArray.begin(), disconnectorArray.end());
	disconnectorArray.clear();

	loadBreakSwitchArray.clear();
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
	{
		if (m_LoadBreakSwitchArray[i].bFlag)
			loadBreakSwitchArray.push_back(m_LoadBreakSwitchArray[i]);
	}
	m_LoadBreakSwitchArray.assign(loadBreakSwitchArray.begin(), loadBreakSwitchArray.end());
	loadBreakSwitchArray.clear();

	fuseArray.clear();
	for (i=0; i<(int)m_FuseArray.size(); i++)
	{
		if (m_FuseArray[i].bFlag)
			fuseArray.push_back(m_FuseArray[i]);
	}
	m_FuseArray.assign(fuseArray.begin(), fuseArray.end());
	fuseArray.clear();

	connLineArray.clear();
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
	{
		if (m_ConnLineArray[i].bFlag)
			connLineArray.push_back(m_ConnLineArray[i]);
	}
	m_ConnLineArray.assign(connLineArray.begin(), connLineArray.end());
	connLineArray.clear();

	compensatorArray.clear();
	for (i=0; i<(int)m_CompensatorArray.size(); i++)
	{
		if (m_CompensatorArray[i].bFlag)
			compensatorArray.push_back(m_CompensatorArray[i]);
	}
	m_CompensatorArray.assign(compensatorArray.begin(), compensatorArray.end());
	compensatorArray.clear();
}

void	CGISData::RemoveNoJointDevice()
{
	register int	i;
	int		nDev, nBranNum;
	std::vector<int>	nNodeArray;

	std::vector<tagGISBreaker>			breakerArray;
	std::vector<tagGISDisconnector>		disconnectorArray;
	std::vector<tagGISLoadBreakSwitch>	loadBreakSwitchArray;
	std::vector<tagGISFuse>				fuseArray;
	std::vector<tagGISConnLine>			connLineArray;
	std::vector<tagGISCompensator>		compensatorArray;
	std::vector<tagGISPowerTransformer>		powerTransformerArray;

	for (i=0; i<(int)m_BreakerArray.size(); i++)
		m_BreakerArray[i].bFlag=0;
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
		m_DisconnectorArray[i].bFlag=0;
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
		m_LoadBreakSwitchArray[i].bFlag=0;
	for (i=0; i<(int)m_FuseArray.size(); i++)
		m_FuseArray[i].bFlag=0;
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
		m_ConnLineArray[i].bFlag=0;
	for (i=0; i<(int)m_CompensatorArray.size(); i++)
		m_CompensatorArray[i].bFlag=0;
	for (i=0; i<(int)m_PowerTransformerArray.size(); i++)
		m_PowerTransformerArray[i].bFlag=0;

	FormSub2Equipment();
	std::vector<tagGISSubstation>	SubArray;
	SubArray.clear();
	for (nDev=0; nDev<(int)m_SubstationArray.size(); nDev++)
	{
		if (m_Sub2EquipmentArray[nDev].nACLineSegmentArray.empty())
			continue;
		SubArray.push_back(m_SubstationArray[nDev]);
	}
	m_SubstationArray.assign(SubArray.begin(), SubArray.end());
	SubArray.clear();
	FormSub2Equipment();
	Log(g_lpszLogFile, "RemoveNoJoint_Substation\n");

	std::vector<tagGISPole>			PoleArray;
	PoleArray.clear();
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		if (m_PoleArray[nDev].strNode.empty() || m_PoleArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_PoleArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			PoleArray.push_back(m_PoleArray[nDev]);
	}
	m_PoleArray.assign(PoleArray.begin(), PoleArray.end());
	PoleArray.clear();
	Log(g_lpszLogFile, "RemoveNoJoint_Pole\n");

	std::vector<tagGISJunction>		JunctionArray;
	JunctionArray.clear();
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].strNode.empty() || m_JunctionArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_JunctionArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			JunctionArray.push_back(m_JunctionArray[nDev]);
	}
	m_JunctionArray.assign(JunctionArray.begin(), JunctionArray.end());
	JunctionArray.clear();
	Log(g_lpszLogFile, "RemoveNoJoint_Junction\n");

	std::vector<tagGISBusbarSection>		BusbarSectionArray;
	BusbarSectionArray.clear();
	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		if (m_BusbarSectionArray[nDev].strNode.empty() || m_BusbarSectionArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_BusbarSectionArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			BusbarSectionArray.push_back(m_BusbarSectionArray[nDev]);
	}
	m_BusbarSectionArray.assign(BusbarSectionArray.begin(), BusbarSectionArray.end());
	BusbarSectionArray.clear();
	Log(g_lpszLogFile, "RemoveNoJoint_BusbarSection\n");

	std::vector<tagGISCapacitor>		CapacitorArray;
	CapacitorArray.clear();
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		if (m_CapacitorArray[nDev].strNode.empty() || m_CapacitorArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_CapacitorArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			CapacitorArray.push_back(m_CapacitorArray[nDev]);
	}
	m_CapacitorArray.assign(CapacitorArray.begin(), CapacitorArray.end());
	CapacitorArray.clear();
	Log(g_lpszLogFile, "RemoveNoJoint_Capacitor\n");

	std::vector<tagGISGroundDisconnector>		GroundDisconnectorArray;
	GroundDisconnectorArray.clear();
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		if (m_GroundDisconnectorArray[nDev].strNode.empty() || m_GroundDisconnectorArray[nDev].nNode < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_GroundDisconnectorArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();

		if (nBranNum > 0)
			GroundDisconnectorArray.push_back(m_GroundDisconnectorArray[nDev]);
	}
	m_GroundDisconnectorArray.assign(GroundDisconnectorArray.begin(), GroundDisconnectorArray.end());
	GroundDisconnectorArray.clear();
	Log(g_lpszLogFile, "RemoveNoJoint_GroundDisconnector\n");

	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		if (m_CompensatorArray[nDev].strNode.empty() || m_CompensatorArray[nDev].nNode < 0)
			continue;
		nBranNum=0;
		TraverseSubstation(m_CompensatorArray[nDev].nNode, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			m_CompensatorArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_Compensator\n");

	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (m_BreakerArray[nDev].strNodeI.empty() || m_BreakerArray[nDev].strNodeZ.empty())
			continue;
		if (m_BreakerArray[nDev].nNodeI < 0 || m_BreakerArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_BreakerArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			m_BreakerArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_Breaker\n");

	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (m_DisconnectorArray[nDev].strNodeI.empty() || m_DisconnectorArray[nDev].strNodeZ.empty())
			continue;
		if (m_DisconnectorArray[nDev].nNodeI < 0 || m_DisconnectorArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_DisconnectorArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			m_DisconnectorArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_Disconnector\n");

	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		if (m_LoadBreakSwitchArray[nDev].strNodeI.empty() || m_LoadBreakSwitchArray[nDev].strNodeZ.empty())
			continue;
		if (m_LoadBreakSwitchArray[nDev].nNodeI < 0 || m_LoadBreakSwitchArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_LoadBreakSwitchArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();

		if (nBranNum > 0)
			m_LoadBreakSwitchArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_LoadBreakSwitch\n");

	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		if (m_FuseArray[nDev].strNodeI.empty() || m_FuseArray[nDev].strNodeZ.empty())
			continue;
		if (m_FuseArray[nDev].nNodeI < 0 || m_FuseArray[nDev].nNodeZ < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_FuseArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			m_FuseArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_Fuse\n");

	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		if (m_ConnLineArray[nDev].strNodeI.empty() && m_ConnLineArray[nDev].strNodeZ.empty())
			continue;
		if (m_ConnLineArray[nDev].nNodeI < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_ConnLineArray[nDev].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			m_ConnLineArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_Conn\n");

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		nBranNum=0;
		if (m_PowerTransformerArray[nDev].strNodeArray[0].empty() && m_PowerTransformerArray[nDev].strNodeArray[1].empty() && m_PowerTransformerArray[nDev].strNodeArray[2].empty())
			continue;
		if (m_PowerTransformerArray[nDev].strVoltTagArray[0].empty() && m_PowerTransformerArray[nDev].strVoltTagArray[1].empty() && m_PowerTransformerArray[nDev].strVoltTagArray[2].empty())
			continue;
		if (m_PowerTransformerArray[nDev].nNodeArray[0] < 0)
			continue;

		nBranNum=0;
		TraverseSubstation(m_PowerTransformerArray[nDev].nNodeArray[0], nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
			nBranNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
		if (nBranNum > 0)
			m_PowerTransformerArray[nDev].bFlag=1;
	}
	Log(g_lpszLogFile, "RemoveNoJoint_PowerTransformer\n");

	//	��ֹ��Ϊɾ���豸������˵Ĵ���
	breakerArray.clear();
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		if (m_BreakerArray[i].bFlag)
			breakerArray.push_back(m_BreakerArray[i]);
	}
	m_BreakerArray.assign(breakerArray.begin(), breakerArray.end());
	breakerArray.clear();

	disconnectorArray.clear();
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		if (m_DisconnectorArray[i].bFlag)
			disconnectorArray.push_back(m_DisconnectorArray[i]);
	}
	m_DisconnectorArray.assign(disconnectorArray.begin(), disconnectorArray.end());
	disconnectorArray.clear();

	loadBreakSwitchArray.clear();
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
	{
		if (m_LoadBreakSwitchArray[i].bFlag)
			loadBreakSwitchArray.push_back(m_LoadBreakSwitchArray[i]);
	}
	m_LoadBreakSwitchArray.assign(loadBreakSwitchArray.begin(), loadBreakSwitchArray.end());
	loadBreakSwitchArray.clear();

	fuseArray.clear();
	for (i=0; i<(int)m_FuseArray.size(); i++)
	{
		if (m_FuseArray[i].bFlag)
			fuseArray.push_back(m_FuseArray[i]);
	}
	m_FuseArray.assign(fuseArray.begin(), fuseArray.end());
	fuseArray.clear();

	connLineArray.clear();
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
	{
		if (m_ConnLineArray[i].bFlag)
			connLineArray.push_back(m_ConnLineArray[i]);
	}
	m_ConnLineArray.assign(connLineArray.begin(), connLineArray.end());
	connLineArray.clear();

	compensatorArray.clear();
	for (i=0; i<(int)m_CompensatorArray.size(); i++)
	{
		if (m_CompensatorArray[i].bFlag)
			compensatorArray.push_back(m_CompensatorArray[i]);
	}
	m_CompensatorArray.assign(compensatorArray.begin(), compensatorArray.end());
	compensatorArray.clear();

	powerTransformerArray.clear();
	for (i=0; i<(int)m_PowerTransformerArray.size(); i++)
	{
		if (m_PowerTransformerArray[i].bFlag)
			powerTransformerArray.push_back(m_PowerTransformerArray[i]);
	}
	m_PowerTransformerArray.assign(powerTransformerArray.begin(), powerTransformerArray.end());
	powerTransformerArray.clear();
}