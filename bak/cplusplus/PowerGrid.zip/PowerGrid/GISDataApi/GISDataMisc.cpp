#include "stdafx.h"
#include "GISData.h"

void	CGISData::FormNode2Equipment()
{
	register int	i;
	int		nDev;

	m_Node2EquipmentArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)m_Node2EquipmentArray.size(); i++)
	{
		m_Node2EquipmentArray[i].nBreakerArray.clear();
		m_Node2EquipmentArray[i].nDisconnectorArray.clear();
		m_Node2EquipmentArray[i].nLoadBreakSwitchArray.clear();
		m_Node2EquipmentArray[i].nFuseArray.clear();
		m_Node2EquipmentArray[i].nACLineSegmentArray.clear();
		m_Node2EquipmentArray[i].nConnLineArray.clear();
		m_Node2EquipmentArray[i].nBusbarSectionArray.clear();
		m_Node2EquipmentArray[i].nPowerTransformerArray.clear();
		m_Node2EquipmentArray[i].nGroundDisconnectorArray.clear();
		m_Node2EquipmentArray[i].nCompensatorArray.clear();
		m_Node2EquipmentArray[i].nCapacitorArray.clear();
		m_Node2EquipmentArray[i].nEnergyConsumerArray.clear();
		m_Node2EquipmentArray[i].nPoleArray.clear();
		m_Node2EquipmentArray[i].nJunctionArray.clear();
	}

	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		if (m_BusbarSectionArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_BusbarSectionArray[nDev].nNode].nBusbarSectionArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		if (m_PoleArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_PoleArray[nDev].nNode].nPoleArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nJunctionArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		if (m_EnergyConsumerArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_EnergyConsumerArray[nDev].nNode].nEnergyConsumerArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (m_BreakerArray[nDev].nNodeI >= 0)
			m_Node2EquipmentArray[m_BreakerArray[nDev].nNodeI].nBreakerArray.push_back(nDev);
		if (m_BreakerArray[nDev].nNodeZ >= 0)
			m_Node2EquipmentArray[m_BreakerArray[nDev].nNodeZ].nBreakerArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (m_DisconnectorArray[nDev].nNodeI >= 0)
			m_Node2EquipmentArray[m_DisconnectorArray[nDev].nNodeI].nDisconnectorArray.push_back(nDev);
		if (m_DisconnectorArray[nDev].nNodeZ >= 0)
			m_Node2EquipmentArray[m_DisconnectorArray[nDev].nNodeZ].nDisconnectorArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		if (m_LoadBreakSwitchArray[nDev].nNodeI >= 0)
			m_Node2EquipmentArray[m_LoadBreakSwitchArray[nDev].nNodeI].nLoadBreakSwitchArray.push_back(nDev);

		if (m_LoadBreakSwitchArray[nDev].nNodeZ >= 0)
			m_Node2EquipmentArray[m_LoadBreakSwitchArray[nDev].nNodeZ].nLoadBreakSwitchArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		if (m_FuseArray[nDev].nNodeI >= 0)
			m_Node2EquipmentArray[m_FuseArray[nDev].nNodeI].nFuseArray.push_back(nDev);

		if (m_FuseArray[nDev].nNodeZ >= 0)
			m_Node2EquipmentArray[m_FuseArray[nDev].nNodeZ].nFuseArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		if (m_GroundDisconnectorArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_GroundDisconnectorArray[nDev].nNode].nGroundDisconnectorArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		if (m_CompensatorArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_CompensatorArray[nDev].nNode].nCompensatorArray.push_back(nDev);
		if (m_CompensatorArray[nDev].nSeriesNode >= 0)
			m_Node2EquipmentArray[m_CompensatorArray[nDev].nSeriesNode].nCompensatorArray.push_back(nDev);
	}
	
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		if (m_CapacitorArray[nDev].nNode >= 0)
			m_Node2EquipmentArray[m_CapacitorArray[nDev].nNode].nCapacitorArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		if (m_ACLineSegmentArray[nDev].nNodeI >= 0)
			m_Node2EquipmentArray[m_ACLineSegmentArray[nDev].nNodeI].nACLineSegmentArray.push_back(nDev);

		if (m_ACLineSegmentArray[nDev].nNodeZ >= 0)
			m_Node2EquipmentArray[m_ACLineSegmentArray[nDev].nNodeZ].nACLineSegmentArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		if (m_ConnLineArray[nDev].nNodeI >= 0)
			m_Node2EquipmentArray[m_ConnLineArray[nDev].nNodeI].nConnLineArray.push_back(nDev);

		if (m_ConnLineArray[nDev].nNodeZ >= 0 && m_ConnLineArray[nDev].nNodeZ != m_ConnLineArray[nDev].nNodeI)
			m_Node2EquipmentArray[m_ConnLineArray[nDev].nNodeZ].nConnLineArray.push_back(nDev);
	}
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
		{
			if (m_PowerTransformerArray[nDev].nNodeArray[i] >= 0)
				m_Node2EquipmentArray[m_PowerTransformerArray[nDev].nNodeArray[i]].nPowerTransformerArray.push_back(nDev);
		}
	}
}

void	CGISData::FormNode2Terminal()
{
	register int	i;
	int		nDev;

	m_Node2TerminalArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)m_Node2TerminalArray.size(); i++)
		m_Node2TerminalArray[i].nTerminalArray.clear();

	for (nDev=0; nDev<(int)m_TerminalArray.size(); nDev++)
	{
		m_TerminalArray[nDev].nNode=-1;
		if (!m_TerminalArray[nDev].strNodeTag.empty())
		{
			m_TerminalArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_TerminalArray[nDev].strNodeTag.c_str());
			if (m_TerminalArray[nDev].nNode >= 0)
				m_Node2TerminalArray[m_TerminalArray[nDev].nNode].nTerminalArray.push_back(nDev);
		}
	}
}

void CGISData::FindTerminals(const char* lpszParentResId, std::vector<tagGISTerminal>& tTermArray)
{
	register int	i;
	int				nTem, nTermArrayLen;
	unsigned char	nTermFlag;
	std::vector<int>	nTermArray;

	tTermArray.clear();

	nTermArray.clear();
	nTermArray.push_back(-1);
	nTermArray.push_back((int)m_TerminalArray.size());

	nTermFlag=1;
	while (nTermFlag)
	{
		nTermFlag=0;
		nTermArrayLen=(int)nTermArray.size()-1;
		for (i=0; i<nTermArrayLen; i++)
		{
			nTem=findTerminalByParentTag(nTermArray[i]+1, nTermArray[i+1]-1, lpszParentResId);
			if (nTem >= 0)
			{
				nTermFlag=1;
				nTermArray.push_back(nTem);
				tTermArray.push_back(m_TerminalArray[nTem]);
			}
		}
		sortInteger(nTermArray, 0, (int)nTermArray.size()-1);
	}
}

void	CGISData::AddUniqueString(std::vector<std::string>& strUniqueStringArray, const char* lpszAddString)
{
	register int	i;
	unsigned char	bExist=0;
	for (i=0; i<(int)strUniqueStringArray.size(); i++)
	{
		if (stricmp(strUniqueStringArray[i].c_str(), lpszAddString) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		strUniqueStringArray.push_back(lpszAddString);
}

void	CGISData::FormSub2Equipment()
{
	register int	i;
	int		nDev, nFind;

	m_Sub2EquipmentArray.resize(m_SubstationArray.size());
	for (i=0; i<(int)m_Sub2EquipmentArray.size(); i++)
	{
		m_Sub2EquipmentArray[i].strVoltTagArray.clear();
		m_Sub2EquipmentArray[i].nFeederArray.clear();
		m_Sub2EquipmentArray[i].nBreakerArray.clear();
		m_Sub2EquipmentArray[i].nDisconnectorArray.clear();
		m_Sub2EquipmentArray[i].nLoadBreakSwitchArray.clear();
		m_Sub2EquipmentArray[i].nFuseArray.clear();
		m_Sub2EquipmentArray[i].nACLineSegmentArray.clear();
		m_Sub2EquipmentArray[i].nConnLineArray.clear();
		m_Sub2EquipmentArray[i].nBusbarSectionArray.clear();
		m_Sub2EquipmentArray[i].nPowerTransformerArray.clear();
		m_Sub2EquipmentArray[i].nGroundDisconnectorArray.clear();
		m_Sub2EquipmentArray[i].nCompensatorArray.clear();
		m_Sub2EquipmentArray[i].nCapacitorArray.clear();
		m_Sub2EquipmentArray[i].nPoleArray.clear();
		m_Sub2EquipmentArray[i].nJunctionArray.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Feeder\n");
#endif
	for (nDev=0; nDev<(int)m_FeederArray.size(); nDev++)
	{
		nFind=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_FeederArray[nDev].strParentTag.c_str());
		if (nFind >= 0)
		{
			//if (m_FeederArray[nDev].strObjectID.empty())
			//	m_FeederArray[nDev].strObjectID=m_SubstationArray[nFind].strObjectID;

			m_Sub2EquipmentArray[nFind].nFeederArray.push_back(nDev);
		}
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Breaker\n");
#endif
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		m_BreakerArray[nDev].strParent.clear();
		m_BreakerArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_BreakerArray[nDev].strParentTag.c_str());
		if (m_BreakerArray[nDev].nSubIdx >= 0)
		{
			//if (m_BreakerArray[nDev].strObjectID.empty())
			//	m_BreakerArray[nDev].strObjectID=m_SubstationArray[m_BreakerArray[nDev].nSubIdx].strObjectID;

			m_BreakerArray[nDev].strParent=m_SubstationArray[m_BreakerArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_BreakerArray[nDev].nSubIdx].nBreakerArray.push_back(nDev);
			if (!m_BreakerArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_BreakerArray[nDev].nSubIdx].strVoltTagArray, m_BreakerArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Breaker VoltEmpty : %s\n", m_BreakerArray[nDev].strResourceID.c_str());
		}
		else
		{
			m_BreakerArray[nDev].strParentTag.clear();
			m_BreakerArray[nDev].bInSubstation=0;
		}
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Disconnector\n");
#endif
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		m_DisconnectorArray[nDev].strParent.clear();
		m_DisconnectorArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_DisconnectorArray[nDev].strParentTag.c_str());
		if (m_DisconnectorArray[nDev].nSubIdx >= 0)
		{
			//if (m_DisconnectorArray[nDev].strObjectID.empty())
			//	m_DisconnectorArray[nDev].strObjectID=m_SubstationArray[m_DisconnectorArray[nDev].nSubIdx].strObjectID;

			m_DisconnectorArray[nDev].strParent=m_SubstationArray[m_DisconnectorArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_DisconnectorArray[nDev].nSubIdx].nDisconnectorArray.push_back(nDev);
			if (!m_DisconnectorArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_DisconnectorArray[nDev].nSubIdx].strVoltTagArray, m_DisconnectorArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Disconnector VoltEmpty : %s\n", m_DisconnectorArray[nDev].strResourceID.c_str());
		}
		else
		{
			m_DisconnectorArray[nDev].strParentTag.clear();
			m_DisconnectorArray[nDev].bInSubstation=0;
		}
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-GroundDisconnector\n");
#endif
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		m_GroundDisconnectorArray[nDev].strParent.clear();
		m_GroundDisconnectorArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_GroundDisconnectorArray[nDev].strParentTag.c_str());
		if (m_GroundDisconnectorArray[nDev].nSubIdx >= 0)
		{
			//if (m_GroundDisconnectorArray[nDev].strObjectID.empty())
			//	m_GroundDisconnectorArray[nDev].strObjectID=m_SubstationArray[m_GroundDisconnectorArray[nDev].nSubIdx].strObjectID;

			m_GroundDisconnectorArray[nDev].strParent=m_SubstationArray[m_GroundDisconnectorArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_GroundDisconnectorArray[nDev].nSubIdx].nGroundDisconnectorArray.push_back(nDev);
			if (!m_GroundDisconnectorArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_GroundDisconnectorArray[nDev].nSubIdx].strVoltTagArray, m_GroundDisconnectorArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "GroundDisconnector VoltEmpty : %s\n", m_GroundDisconnectorArray[nDev].strResourceID.c_str());
		}
		else
			m_GroundDisconnectorArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-LoadBreakSwitch\n");
#endif
	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		m_LoadBreakSwitchArray[nDev].strParent.clear();
		m_LoadBreakSwitchArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
		if (m_LoadBreakSwitchArray[nDev].nSubIdx >= 0)
		{
			//if (m_LoadBreakSwitchArray[nDev].strObjectID.empty())
			//	m_LoadBreakSwitchArray[nDev].strObjectID=m_SubstationArray[m_LoadBreakSwitchArray[nDev].nSubIdx].strObjectID;

			m_LoadBreakSwitchArray[nDev].strParent=m_SubstationArray[m_LoadBreakSwitchArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_LoadBreakSwitchArray[nDev].nSubIdx].nLoadBreakSwitchArray.push_back(nDev);
			if (!m_LoadBreakSwitchArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_LoadBreakSwitchArray[nDev].nSubIdx].strVoltTagArray, m_LoadBreakSwitchArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "LoadBreakSwitch VoltEmpty : %s\n", m_LoadBreakSwitchArray[nDev].strResourceID.c_str());
		}
		else
			m_LoadBreakSwitchArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Fuse\n");
#endif
	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		m_FuseArray[nDev].strParent.clear();
		m_FuseArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_FuseArray[nDev].strParentTag.c_str());
		if (m_FuseArray[nDev].nSubIdx >= 0)
		{
			//if (m_FuseArray[nDev].strObjectID.empty())
			//	m_FuseArray[nDev].strObjectID=m_SubstationArray[m_FuseArray[nDev].nSubIdx].strObjectID;

			m_FuseArray[nDev].strParent=m_SubstationArray[m_FuseArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_FuseArray[nDev].nSubIdx].nFuseArray.push_back(nDev);
			if (!m_FuseArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_FuseArray[nDev].nSubIdx].strVoltTagArray, m_FuseArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Fuse VoltEmpty : %s\n", m_FuseArray[nDev].strResourceID.c_str());
		}
		else
			m_FuseArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-BusbarSection\n");
#endif
	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		m_BusbarSectionArray[nDev].strParent.clear();
		m_BusbarSectionArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_BusbarSectionArray[nDev].strParentTag.c_str());
		if (m_BusbarSectionArray[nDev].nSubIdx >= 0)
		{
			//if (m_BusbarSectionArray[nDev].strObjectID.empty())
			//	m_BusbarSectionArray[nDev].strObjectID=m_SubstationArray[m_BusbarSectionArray[nDev].nSubIdx].strObjectID;

			m_BusbarSectionArray[nDev].strParent=m_SubstationArray[m_BusbarSectionArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_BusbarSectionArray[nDev].nSubIdx].nBusbarSectionArray.push_back(nDev);
			if (!m_BusbarSectionArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_BusbarSectionArray[nDev].nSubIdx].strVoltTagArray, m_BusbarSectionArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "BusbarSection VoltEmpty : %s\n", m_BusbarSectionArray[nDev].strResourceID.c_str());
		}
		else
			m_BusbarSectionArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Pole\n");
#endif
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		m_PoleArray[nDev].strParent.clear();
		m_PoleArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_PoleArray[nDev].strParentTag.c_str());
		if (m_PoleArray[nDev].nSubIdx >= 0)
		{
			//if (m_PoleArray[nDev].strObjectID.empty())
			//	m_PoleArray[nDev].strObjectID=m_SubstationArray[m_PoleArray[nDev].nSubIdx].strObjectID;

			m_PoleArray[nDev].strParent=m_SubstationArray[m_PoleArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_PoleArray[nDev].nSubIdx].nPoleArray.push_back(nDev);
			if (!m_PoleArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_PoleArray[nDev].nSubIdx].strVoltTagArray, m_PoleArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Pole VoltEmpty : %s\n", m_PoleArray[nDev].strResourceID.c_str());
		}
		else
			m_PoleArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Junction\n");
#endif
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		m_JunctionArray[nDev].strParent.clear();
		m_JunctionArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_JunctionArray[nDev].strParentTag.c_str());
		if (m_JunctionArray[nDev].nSubIdx >= 0)
		{
			//if (m_JunctionArray[nDev].strObjectID.empty())
			//	m_JunctionArray[nDev].strObjectID=m_SubstationArray[m_JunctionArray[nDev].nSubIdx].strObjectID;

			m_JunctionArray[nDev].strParent=m_SubstationArray[m_JunctionArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_JunctionArray[nDev].nSubIdx].nJunctionArray.push_back(nDev);
			if (!m_JunctionArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_JunctionArray[nDev].nSubIdx].strVoltTagArray, m_JunctionArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Junction VoltEmpty : %s\n", m_JunctionArray[nDev].strResourceID.c_str());
		}
		else
			m_JunctionArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-EnergyConsumer\n");
#endif
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		m_EnergyConsumerArray[nDev].strParent.clear();
		m_EnergyConsumerArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_EnergyConsumerArray[nDev].strParentTag.c_str());
		if (m_EnergyConsumerArray[nDev].nSubIdx >= 0)
		{
			//if (m_EnergyConsumerArray[nDev].strObjectID.empty())
			//	m_EnergyConsumerArray[nDev].strObjectID=m_SubstationArray[m_EnergyConsumerArray[nDev].nSubIdx].strObjectID;

			m_EnergyConsumerArray[nDev].strParent=m_SubstationArray[m_EnergyConsumerArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_EnergyConsumerArray[nDev].nSubIdx].nEnergyConsumerArray.push_back(nDev);
			if (!m_EnergyConsumerArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_EnergyConsumerArray[nDev].nSubIdx].strVoltTagArray, m_EnergyConsumerArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "EnergyConsumer VoltEmpty : %s\n", m_EnergyConsumerArray[nDev].strResourceID.c_str());
		}
		else
			m_EnergyConsumerArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Compensator\n");
#endif
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		m_CompensatorArray[nDev].strParent.clear();
		m_CompensatorArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_CompensatorArray[nDev].strParentTag.c_str());
		if (m_CompensatorArray[nDev].nSubIdx >= 0)
		{
			//if (m_CompensatorArray[nDev].strObjectID.empty())
			//	m_CompensatorArray[nDev].strObjectID=m_SubstationArray[m_CompensatorArray[nDev].nSubIdx].strObjectID;

			m_CompensatorArray[nDev].strParent=m_SubstationArray[m_CompensatorArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_CompensatorArray[nDev].nSubIdx].nCompensatorArray.push_back(nDev);
			if (!m_CompensatorArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_CompensatorArray[nDev].nSubIdx].strVoltTagArray, m_CompensatorArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Compensator VoltEmpty : %s\n", m_CompensatorArray[nDev].strResourceID.c_str());
		}
		else
			m_CompensatorArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-Capacitor\n");
#endif
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		m_CapacitorArray[nDev].strParent.clear();
		m_CapacitorArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_CapacitorArray[nDev].strParentTag.c_str());
		if (m_CapacitorArray[nDev].nSubIdx >= 0)
		{
			//if (m_CapacitorArray[nDev].strObjectID.empty())
			//	m_CapacitorArray[nDev].strObjectID=m_SubstationArray[m_CapacitorArray[nDev].nSubIdx].strObjectID;

			m_CapacitorArray[nDev].strParent=m_SubstationArray[m_CapacitorArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_CapacitorArray[nDev].nSubIdx].nCapacitorArray.push_back(nDev);
			if (!m_CapacitorArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_CapacitorArray[nDev].nSubIdx].strVoltTagArray, m_CapacitorArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "Capacitor VoltEmpty : %s\n", m_CapacitorArray[nDev].strResourceID.c_str());
		}
		else
			m_CapacitorArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-ACLineSegment\n");
#endif
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		if (!m_ACLineSegmentArray[nDev].strSubITag.empty())
		{
			m_ACLineSegmentArray[nDev].nSubI=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_ACLineSegmentArray[nDev].strSubITag.c_str());
			if (m_ACLineSegmentArray[nDev].nSubI >= 0)
			{
				m_Sub2EquipmentArray[m_ACLineSegmentArray[nDev].nSubI].nACLineSegmentArray.push_back(nDev);
				if (!m_ACLineSegmentArray[nDev].strBaseVoltageTag.empty())
					AddUniqueString(m_Sub2EquipmentArray[m_ACLineSegmentArray[nDev].nSubI].strVoltTagArray, m_ACLineSegmentArray[nDev].strBaseVoltageTag.c_str());
				else
					Log(g_lpszLogFile, "ACLineSegment SubIVoltEmpty : %s\n", m_ACLineSegmentArray[nDev].strResourceID.c_str());
			}
			else
				m_ACLineSegmentArray[nDev].strSubITag.clear();
		}
		if (!m_ACLineSegmentArray[nDev].strSubZTag.empty())
		{
			m_ACLineSegmentArray[nDev].nSubZ=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_ACLineSegmentArray[nDev].strSubZTag.c_str());
			if (m_ACLineSegmentArray[nDev].nSubZ >= 0)
			{
				m_Sub2EquipmentArray[m_ACLineSegmentArray[nDev].nSubZ].nACLineSegmentArray.push_back(nDev);
				if (!m_ACLineSegmentArray[nDev].strBaseVoltageTag.empty())
					AddUniqueString(m_Sub2EquipmentArray[m_ACLineSegmentArray[nDev].nSubZ].strVoltTagArray, m_ACLineSegmentArray[nDev].strBaseVoltageTag.c_str());
				else
					Log(g_lpszLogFile, "ACLineSegment SubZVoltEmpty : %s\n", m_ACLineSegmentArray[nDev].strResourceID.c_str());
			}
			else
				m_ACLineSegmentArray[nDev].strSubZTag.clear();
		}
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-PowerTransformer\n");
#endif
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		m_PowerTransformerArray[nDev].strParent.clear();
		m_PowerTransformerArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_PowerTransformerArray[nDev].strParentTag.c_str());
		if (m_PowerTransformerArray[nDev].nSubIdx >= 0)
		{
			//if (m_PowerTransformerArray[nDev].strObjectID.empty())
			//	m_PowerTransformerArray[nDev].strObjectID=m_SubstationArray[m_PowerTransformerArray[nDev].nSubIdx].strObjectID;

			m_PowerTransformerArray[nDev].strParent=m_SubstationArray[m_PowerTransformerArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_PowerTransformerArray[nDev].nSubIdx].nPowerTransformerArray.push_back(nDev);
			for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
			{
				if (!m_PowerTransformerArray[nDev].strVoltTagArray[i].empty())
					AddUniqueString(m_Sub2EquipmentArray[m_PowerTransformerArray[nDev].nSubIdx].strVoltTagArray, m_PowerTransformerArray[nDev].strVoltTagArray[i].c_str());
				else
					Log(g_lpszLogFile, "PowerTransformer Wind(%d)VoltEmpty : %s\n", i, m_PowerTransformerArray[nDev].strResourceID.c_str());
			}
		}
		else
			m_PowerTransformerArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-ConnLine\n");
#endif
	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		m_ConnLineArray[nDev].strParent.clear();
		m_ConnLineArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_ConnLineArray[nDev].strParentTag.c_str());
		if (m_ConnLineArray[nDev].nSubIdx >= 0)
		{
			//if (m_ConnLineArray[nDev].strObjectID.empty())
			//	m_ConnLineArray[nDev].strObjectID=m_SubstationArray[m_ConnLineArray[nDev].nSubIdx].strObjectID;

			m_ConnLineArray[nDev].strParent=m_SubstationArray[m_ConnLineArray[nDev].nSubIdx].strName;
			m_Sub2EquipmentArray[m_ConnLineArray[nDev].nSubIdx].nConnLineArray.push_back(nDev);
			if (!m_ConnLineArray[nDev].strBaseVoltageTag.empty())
				AddUniqueString(m_Sub2EquipmentArray[m_ConnLineArray[nDev].nSubIdx].strVoltTagArray, m_ConnLineArray[nDev].strBaseVoltageTag.c_str());
			else
				Log(g_lpszLogFile, "ConnLine VoltEmpty : %s\n", m_ConnLineArray[nDev].strResourceID.c_str());
		}
		else
			m_ConnLineArray[nDev].strParentTag.clear();
	}

#ifdef _DEBUG
	Log(g_lpszLogFile, "FormSub2Equipment-ZJ\n");
#endif
	for (nDev=0; nDev<(int)m_ZJArray.size(); nDev++)
	{
		m_ZJArray[nDev].strParent.clear();
		m_ZJArray[nDev].nSubIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_ZJArray[nDev].strParentTag.c_str());
		if (m_ZJArray[nDev].nSubIdx >= 0)
			m_ZJArray[nDev].strParent=m_SubstationArray[m_ZJArray[nDev].nSubIdx].strName;
	}
}

void	CGISData::FormConnectivityNodeByEquipment(const unsigned char bAllEquipment)
{
	register int	i, j;
	std::vector<tagGISConnectivityNode>	nodeArray;
	tagGISConnectivityNode	nBuf;

	//for (i=0; i<(int)m_TerminalArray.size(); i++)
	//{
	//	if (m_TerminalArray[i].strNodeTag.empty())
	//		Log(g_lpszLogFile, "    �˵� TermRes=%s �ڵ���ϢΪ��\n", m_TerminalArray[i].strResourceID.c_str());
	//}

	m_ConnectivityNodeArray.clear();
	nodeArray.clear();

	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		nBuf.strBaseVoltageTag=m_ACLineSegmentArray[i].strBaseVoltageTag;
		if (!m_ACLineSegmentArray[i].strNodeI.empty())
		{
			nBuf.strResourceID=m_ACLineSegmentArray[i].strNodeI;
			nodeArray.push_back(nBuf);
		}
		if (!m_ACLineSegmentArray[i].strNodeZ.empty())
		{
			nBuf.strResourceID=m_ACLineSegmentArray[i].strNodeZ;
			nodeArray.push_back(nBuf);
		}
	}
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		nBuf.strBaseVoltageTag=m_ConnLineArray[i].strBaseVoltageTag;
		if (!m_ConnLineArray[i].strNodeI.empty())
		{
			nBuf.strResourceID=m_ConnLineArray[i].strNodeI;
			nodeArray.push_back(nBuf);
		}
		if (!m_ConnLineArray[i].strNodeZ.empty())
		{
			nBuf.strResourceID=m_ConnLineArray[i].strNodeZ;
			nodeArray.push_back(nBuf);
		}
	}
	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		nBuf.strBaseVoltageTag=m_BreakerArray[i].strBaseVoltageTag;
		if (!m_BreakerArray[i].strNodeI.empty())
		{
			nBuf.strResourceID=m_BreakerArray[i].strNodeI;
			nodeArray.push_back(nBuf);
		}
		if (!m_BreakerArray[i].strNodeZ.empty())
		{
			nBuf.strResourceID=m_BreakerArray[i].strNodeZ;
			nodeArray.push_back(nBuf);
		}
	}
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		nBuf.strBaseVoltageTag=m_DisconnectorArray[i].strBaseVoltageTag;
		if (!m_DisconnectorArray[i].strNodeI.empty())
		{
			nBuf.strResourceID=m_DisconnectorArray[i].strNodeI;
			nodeArray.push_back(nBuf);
		}
		if (!m_DisconnectorArray[i].strNodeZ.empty())
		{
			nBuf.strResourceID=m_DisconnectorArray[i].strNodeZ;
			nodeArray.push_back(nBuf);
		}
	}
	for (i=0; i<(int)m_LoadBreakSwitchArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		nBuf.strBaseVoltageTag=m_LoadBreakSwitchArray[i].strBaseVoltageTag;
		if (!m_LoadBreakSwitchArray[i].strNodeI.empty())
		{
			nBuf.strResourceID=m_LoadBreakSwitchArray[i].strNodeI;
			nodeArray.push_back(nBuf);
		}
		if (!m_LoadBreakSwitchArray[i].strNodeZ.empty())
		{
			nBuf.strResourceID=m_LoadBreakSwitchArray[i].strNodeZ;
			nodeArray.push_back(nBuf);
		}
	}
	for (i=0; i<(int)m_FuseArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		nBuf.strBaseVoltageTag=m_FuseArray[i].strBaseVoltageTag;
		if (!m_FuseArray[i].strNodeI.empty())
		{
			nBuf.strResourceID=m_FuseArray[i].strNodeI;
			nodeArray.push_back(nBuf);
		}
		if (!m_FuseArray[i].strNodeZ.empty())
		{
			nBuf.strResourceID=m_FuseArray[i].strNodeZ;
			nodeArray.push_back(nBuf);
		}
	}
	if (bAllEquipment)
	{
		for (i=0; i<(int)m_PoleArray.size(); i++)
		{
			m_GISBuffer.InitializeConnectivityNode(nBuf);
			nBuf.strBaseVoltageTag=m_PoleArray[i].strBaseVoltageTag;
			if (!m_PoleArray[i].strNode.empty())
			{
				nBuf.strResourceID=m_PoleArray[i].strNode;
				nodeArray.push_back(nBuf);
			}
		}
		for (i=0; i<(int)m_JunctionArray.size(); i++)
		{
			m_GISBuffer.InitializeConnectivityNode(nBuf);
			nBuf.strBaseVoltageTag=m_JunctionArray[i].strBaseVoltageTag;
			if (!m_JunctionArray[i].strNode.empty())
			{
				nBuf.strResourceID=m_JunctionArray[i].strNode;
				nodeArray.push_back(nBuf);
			}
		}
		for (i=0; i<(int)m_CapacitorArray.size(); i++)
		{
			m_GISBuffer.InitializeConnectivityNode(nBuf);
			nBuf.strBaseVoltageTag=m_CapacitorArray[i].strBaseVoltageTag;
			if (!m_CapacitorArray[i].strNode.empty())
			{
				nBuf.strResourceID=m_CapacitorArray[i].strNode;
				nodeArray.push_back(nBuf);
			}
		}
		for (i=0; i<(int)m_CompensatorArray.size(); i++)
		{
			m_GISBuffer.InitializeConnectivityNode(nBuf);
			nBuf.strBaseVoltageTag=m_CompensatorArray[i].strBaseVoltageTag;
			if (!m_CompensatorArray[i].strNode.empty())
			{
				nBuf.strResourceID=m_CompensatorArray[i].strNode;
				nodeArray.push_back(nBuf);
			}
			if (!m_CompensatorArray[i].strSeriesNode.empty())
			{
				nBuf.strResourceID=m_CompensatorArray[i].strSeriesNode;
				nodeArray.push_back(nBuf);
			}
		}
		for (i=0; i<(int)m_BusbarSectionArray.size(); i++)
		{
			m_GISBuffer.InitializeConnectivityNode(nBuf);
			nBuf.strBaseVoltageTag=m_BusbarSectionArray[i].strBaseVoltageTag;
			if (!m_BusbarSectionArray[i].strNode.empty())
			{
				nBuf.strResourceID=m_BusbarSectionArray[i].strNode;
				nodeArray.push_back(nBuf);
			}
		}
		for (i=0; i<(int)m_GroundDisconnectorArray.size(); i++)
		{
			m_GISBuffer.InitializeConnectivityNode(nBuf);
			nBuf.strBaseVoltageTag=m_GroundDisconnectorArray[i].strBaseVoltageTag;
			if (!m_GroundDisconnectorArray[i].strNode.empty())
			{
				nBuf.strResourceID=m_GroundDisconnectorArray[i].strNode;
				nodeArray.push_back(nBuf);
			}
		}
	}

	for (i=0; i<(int)m_PowerTransformerArray.size(); i++)
	{
		m_GISBuffer.InitializeConnectivityNode(nBuf);
		for (j=0; j<3; j++)
		{
			if (!m_PowerTransformerArray[i].strNodeArray[j].empty())
			{
				nBuf.strResourceID=m_PowerTransformerArray[i].strNodeArray[j];
				if (!m_PowerTransformerArray[i].strVoltTagArray[j].empty())
					nBuf.strBaseVoltageTag=m_PowerTransformerArray[i].strVoltTagArray[j];
				nodeArray.push_back(nBuf);
			}
		}
	}
	sortConnectivityNodeByResID(nodeArray, 0, (int)nodeArray.size()-1);

	i=0;
	while (i < (int)nodeArray.size())
	{
		nBuf.strResourceID=nodeArray[i].strResourceID;
		nBuf.strBaseVoltageTag=nodeArray[i].strBaseVoltageTag;

		j=i+1;
		while (j < (int)nodeArray.size())
		{
			if (strcmp(nBuf.strResourceID.c_str(), nodeArray[j].strResourceID.c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		i++;

		m_ConnectivityNodeArray.push_back(nBuf);
	}
	nodeArray.clear();
}

void	CGISData::FormConnectivityNodeByTerminal()
{
	register int	i, j;
	std::vector<std::string>	strNodeArray;
	tagGISConnectivityNode	nBuf;

	Log(g_lpszLogFile, "    Prev FormConnectivityNodeByTerminal NodeNum=%d\n", m_ConnectivityNodeArray.size());
	m_ConnectivityNodeArray.clear();
	strNodeArray.clear();
	for (i=0; i<(int)m_TerminalArray.size(); i++)
	{
		if (m_TerminalArray[i].strNodeTag.empty())
			continue;

		strNodeArray.push_back(m_TerminalArray[i].strNodeTag);
	}
	sortString(strNodeArray, 0, (int)strNodeArray.size()-1);

	i=0;
	while (i < (int)strNodeArray.size())
	{
		nBuf.strResourceID=strNodeArray[i];

		j=i+1;
		while (j < (int)strNodeArray.size())
		{
			if (strcmp(nBuf.strResourceID.c_str(), strNodeArray[j].c_str()) == 0)
			{
				i++;
				j++;
			}
			else
			{
				break;
			}
		}
		i++;

		m_ConnectivityNodeArray.push_back(nBuf);
	}
	strNodeArray.clear();
	Log(g_lpszLogFile, "    Post FormConnectivityNodeByTerminal NodeNum=%d\n", m_ConnectivityNodeArray.size());
}

void CGISData::ParseptVertexArray(std::vector<tagGISVertex>& vtArray, const char* lpszCoordinate)
{
	register int	i;
	int		nChar;
	char	szChar[260];

	vtArray.clear();

	if (strlen(lpszCoordinate) <= 0)
		return;

	std::vector<std::string>	strEleArray;
	strEleArray.clear();
	nChar=0;
	memset(szChar, 0, 260);
	for (i=0; i<(int)strlen(lpszCoordinate); i++)
	{
		if (lpszCoordinate[i] == ' ' || lpszCoordinate[i] == '\t' || lpszCoordinate[i] == '\r' || lpszCoordinate[i] == '\n')
		{
			if (strlen(szChar) > 0)
			{
				szChar[nChar++]='\0';
				strEleArray.push_back(szChar);

				nChar=0;
				memset(szChar, 0, MDB_CHARLEN);
			}
			continue;
		}

		if (lpszCoordinate[i] == ',' || lpszCoordinate[i] == ';')
		{
			szChar[nChar++]='\0';
			strEleArray.push_back(szChar);

			nChar=0;
			memset(szChar, 0, MDB_CHARLEN);
		}
		else
		{
			szChar[nChar++]=lpszCoordinate[i];
		}
	}
	if (strlen(szChar) > 0)
	{
		szChar[nChar++]='\0';
		strEleArray.push_back(szChar);
	}

	tagGISVertex	vtBuf;
	memset(&vtBuf, 0, sizeof(tagGISVertex));

	i=0;
	while (i < (int)strEleArray.size()-1)
	{
		vtBuf.fX=atof(strEleArray[i+0].c_str());
		vtBuf.fY=atof(strEleArray[i+1].c_str());
		vtArray.push_back(vtBuf);

		i++;
		i++;
	}
}

int		CGISData::GetSubstationType(const char* lpszSubstationTag)
{
	int		nSub=findSubstationByResID(0, (int)m_SubstationArray.size()-1, lpszSubstationTag);
	if (nSub >= 0)
	{
		if (strcmp(GetPSRTypeName(m_SubstationArray[nSub].strPSRTypeTag.c_str()).c_str(), "���-���վ") == 0)
			return PG_SUBSTATIONENTITY;
		else
			return PG_DISTRIBUTIONSWITCH;
	}
	return -1;
}

int	CGISData::ResolveConnectivityNode(std::vector<int>& nNodeArray)
{
	register int	i;
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nPoleArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
		if (!m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray.empty())
		{
			return nNodeArray[i];
			break;
		}
	}
	//for (i=0; i<(int)nNodeArray.size(); i++)
	//{
	//	if (!m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.empty())
	//	{
	//		return nNodeArray[i];
	//		break;
	//	}
	//}

	return -1;
}

void	CGISData::SetConnConnectivityNode(const int nNode, std::vector<int>& nNodeArray)
{
	register int	i, j;
	int		nDev;
//	unsigned char	bLog;
	for (i=0; i<(int)nNodeArray.size(); i++)
	{
// 		if (stricmp(m_ConnectivityNodeArray[nNode].strResourceID.c_str(), "CN13-790101716-541a4e06-01") == 0 || stricmp(m_ConnectivityNodeArray[nNode].strResourceID.c_str(), "CN285-902850075-4a5155b2-02") == 0)
// 			bLog=1;
// 		else
// 			bLog=0;

		//Log(g_lpszLogFile, "    SetConnConnectivityNode@1\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray.size(); nDev++)
		{
			m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray[nDev]].strNode=m_ConnectivityNodeArray[nNode].strResourceID;
			m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray[nDev]].nNode=nNode;
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@2\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_ACLineSegmentArray[m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev]].nNodeI)
			{
				m_ACLineSegmentArray[m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev]].strNodeI=m_ConnectivityNodeArray[nNode].strResourceID;
				m_ACLineSegmentArray[m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev]].nNodeI=nNode;
			}
			else if (nNodeArray[i] == m_ACLineSegmentArray[m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev]].nNodeZ)
			{
				m_ACLineSegmentArray[m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev]].strNodeZ=m_ConnectivityNodeArray[nNode].strResourceID;
				m_ACLineSegmentArray[m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev]].nNodeZ=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@3\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size(); nDev++)
		{
			for (j=0; j<3; j++)
			{
				if (nNodeArray[i] == m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray[nDev]].nNodeArray[j])
				{
					m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray[nDev]].strNodeArray[j]=m_ConnectivityNodeArray[nNode].strResourceID;
					m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray[nDev]].nNodeArray[j]=nNode;
					break;
				}
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@4\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev]].nNode)
			{
				m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev]].strNode=m_ConnectivityNodeArray[nNode].strResourceID;
				m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev]].nNode=nNode;
			}
			else if (nNodeArray[i] == m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev]].nSeriesNode)
			{
				m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev]].strSeriesNode=m_ConnectivityNodeArray[nNode].strResourceID;
				m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev]].nSeriesNode=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@5\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size(); nDev++)
		{
			m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray[nDev]].strNode=m_ConnectivityNodeArray[nNode].strResourceID;
			m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray[nDev]].nNode=nNode;
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@6\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_BreakerArray[m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev]].nNodeI)
			{
				m_BreakerArray[m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev]].strNodeI=m_ConnectivityNodeArray[nNode].strResourceID;
				m_BreakerArray[m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev]].nNodeI=nNode;
			}
			else if (nNodeArray[i] == m_BreakerArray[m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev]].nNodeZ)
			{
				m_BreakerArray[m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev]].strNodeZ=m_ConnectivityNodeArray[nNode].strResourceID;
				m_BreakerArray[m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev]].nNodeZ=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@7\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].nNodeI)
			{
// 				if (bLog)
// 				{
// 					Log(g_lpszLogFile, "����Disconnector(%s) Node=%s -> %s\n", m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].strResourceID.c_str(), 
// 						m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].strNodeI.c_str(), m_ConnectivityNodeArray[nNode].strResourceID.c_str());
// 				}
				m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].strNodeI=m_ConnectivityNodeArray[nNode].strResourceID;
				m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].nNodeI=nNode;
			}
			else if (nNodeArray[i] == m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].nNodeZ)
			{
// 				if (bLog)
// 				{
// 					Log(g_lpszLogFile, "1����Disconnector(%s) Node=%s -> %s\n", m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].strResourceID.c_str(), 
// 						m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].strNodeZ.c_str(), m_ConnectivityNodeArray[nNode].strResourceID.c_str());
// 				}
				m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].strNodeZ=m_ConnectivityNodeArray[nNode].strResourceID;
				m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev]].nNodeZ=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@8\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev]].nNodeI)
			{
				m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev]].strNodeI=m_ConnectivityNodeArray[nNode].strResourceID;
				m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev]].nNodeI=nNode;
			}
			else if (nNodeArray[i] == m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev]].nNodeZ)
			{
				m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev]].strNodeZ=m_ConnectivityNodeArray[nNode].strResourceID;
				m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev]].nNodeZ=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@9\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_FuseArray[m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev]].nNodeI)
			{
				m_FuseArray[m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev]].strNodeI=m_ConnectivityNodeArray[nNode].strResourceID;
				m_FuseArray[m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev]].nNodeI=nNode;
			}
			else if (nNodeArray[i] == m_FuseArray[m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev]].nNodeZ)
			{
				m_FuseArray[m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev]].strNodeZ=m_ConnectivityNodeArray[nNode].strResourceID;
				m_FuseArray[m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev]].nNodeZ=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@10\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nGroundDisconnectorArray.size(); nDev++)
		{
			m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nGroundDisconnectorArray[nDev]].strNode=m_ConnectivityNodeArray[nNode].strResourceID;
			m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[i]].nGroundDisconnectorArray[nDev]].nNode=nNode;
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@11\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].nNodeI)
			{
// 				if (bLog)
// 				{
// 					Log(g_lpszLogFile, "����ConnLine(%s) Node=%s -> %s\n", m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].strResourceID.c_str(), 
// 							m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].strNodeI.c_str(), m_ConnectivityNodeArray[nNode].strResourceID.c_str());
// 				}
				m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].strNodeI=m_ConnectivityNodeArray[nNode].strResourceID;
				m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].nNodeI=nNode;

			}
			else if (nNodeArray[i] == m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].nNodeZ)
			{
// 				if (bLog)
// 				{
// 					Log(g_lpszLogFile, "����ConnLine(%s) Node=%s -> %s\n", m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].strResourceID.c_str(), 
// 							m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].strNodeI.c_str(), m_ConnectivityNodeArray[nNode].strResourceID.c_str());
// 				}
				m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].strNodeZ=m_ConnectivityNodeArray[nNode].strResourceID;
				m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev]].nNodeZ=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@12\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nPoleArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_PoleArray[m_Node2EquipmentArray[nNodeArray[i]].nPoleArray[nDev]].nNode)
			{
				m_PoleArray[m_Node2EquipmentArray[nNodeArray[i]].nPoleArray[nDev]].strNode=m_ConnectivityNodeArray[nNode].strResourceID;
				m_PoleArray[m_Node2EquipmentArray[nNodeArray[i]].nPoleArray[nDev]].nNode=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@13\n");
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray.size(); nDev++)
		{
			if (nNodeArray[i] == m_JunctionArray[m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray[nDev]].nNode)
			{
				m_JunctionArray[m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray[nDev]].strNode=m_ConnectivityNodeArray[nNode].strResourceID;
				m_JunctionArray[m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray[nDev]].nNode=nNode;
			}
		}
		//Log(g_lpszLogFile, "    SetConnConnectivityNode@14\n");
	}
}

void CGISData::JointACLineSegmentCoordinate(std::string& strCoordinate, const char* lpszCoordJoint)
{
	register int	i;
	double	fHLen, fVLen;
	std::vector<tagGISVertex>	vtCoordArray;
	std::vector<tagGISVertex>	vtJointArray;
	std::vector<tagGISVertex>	ptArray;

	if (strlen(lpszCoordJoint) <= 0)
		return;

	ptArray.clear();
	vtCoordArray.clear();
	vtJointArray.clear();
	ParseptVertexArray(vtCoordArray, strCoordinate.c_str());
	ParseptVertexArray(vtJointArray, lpszCoordJoint);

	if (vtCoordArray.empty() || vtJointArray.empty())
		return;

	fHLen=vtCoordArray[0].fX-vtJointArray[0].fX;
	fVLen=vtCoordArray[0].fY-vtJointArray[0].fY;
	double fDists1s2=sqrt(fHLen*fHLen+fVLen*fVLen);

	fHLen=vtCoordArray[0].fX-vtJointArray[vtJointArray.size()-1].fX;
	fVLen=vtCoordArray[0].fY-vtJointArray[vtJointArray.size()-1].fY;
	double fDists1e2=sqrt(fHLen*fHLen+fVLen*fVLen);

	fHLen=vtCoordArray[vtCoordArray.size()-1].fX-vtJointArray[0].fX;
	fVLen=vtCoordArray[vtCoordArray.size()-1].fY-vtJointArray[0].fY;
	double fDiste1s2=sqrt(fHLen*fHLen+fVLen*fVLen);

	fHLen=vtCoordArray[vtCoordArray.size()-1].fX-vtJointArray[vtJointArray.size()-1].fX;
	fVLen=vtCoordArray[vtCoordArray.size()-1].fY-vtJointArray[vtJointArray.size()-1].fY;
	double fDiste1e2=sqrt(fHLen*fHLen+fVLen*fVLen);

	if (fDists1s2 <= fDists1e2 && fDists1s2 <= fDiste1s2 && fDists1s2 <= fDiste1e2)
	{
		for (i=(int)vtCoordArray.size()-1; i>=0; i--)
			ptArray.push_back(vtCoordArray[i]);
		for (i=0; i<(int)vtJointArray.size(); i++)
			ptArray.push_back(vtJointArray[i]);
	}
	else if (fDists1e2 <= fDists1s2 && fDists1e2 <= fDiste1s2 && fDists1e2 <= fDiste1e2)
	{
		for (i=(int)vtCoordArray.size()-1; i>=0; i--)
			ptArray.push_back(vtCoordArray[i]);
		for (i=(int)vtJointArray.size()-1; i>=0; i--)
			ptArray.push_back(vtJointArray[i]);
	}
	else if (fDiste1s2 <= fDists1s2 && fDiste1s2 <= fDists1e2 && fDiste1s2 <= fDiste1e2)
	{
		for (i=0; i<(int)vtCoordArray.size(); i++)
			ptArray.push_back(vtCoordArray[i]);
		for (i=0; i<(int)vtJointArray.size(); i++)
			ptArray.push_back(vtJointArray[i]);
	}
	else if (fDiste1e2 <= fDists1s2 && fDiste1e2 <= fDists1e2 && fDiste1e2 <= fDiste1s2)
	{
		for (i=0; i<(int)vtCoordArray.size(); i++)
			ptArray.push_back(vtCoordArray[i]);
		for (i=(int)vtJointArray.size()-1; i>=0; i--)
			ptArray.push_back(vtJointArray[i]);
	}

	char	szBuf[260];
	strCoordinate.clear();
	for (i=0; i<(int)ptArray.size(); i++)
	{
		sprintf(szBuf, "%f", ptArray[i].fX);	strCoordinate.append(szBuf).append(", ");
		sprintf(szBuf, "%f", ptArray[i].fY);	strCoordinate.append(szBuf).append(";");
	}
}

void CGISData::AddPsedoPole(tagGISACLineSegment* pLine, const unsigned char nTerminal)
{
	tagGISPole	pole;
	m_GISBuffer.InitializePole(pole);

	pole.strResourceID=pLine->strResourceID;
	pole.strObjectID=pLine->strObjectID;
//	������ʱ	ReviseACLineSegmentName(pLine->strName, pole.szName);
	pole.strDesp="��·�ն������";
	pole.strBaseVoltageTag=pLine->strBaseVoltageTag;

	if (nTerminal == 0)
	{
		pole.nNode=pLine->nNodeI;
		pole.strNode=pLine->strNodeI;
		m_Node2EquipmentArray[pLine->nNodeI].nPoleArray.push_back((int)m_PoleArray.size());
	}
	else
	{
		pole.nNode=pLine->nNodeZ;
		pole.strNode=pLine->strNodeZ;
		m_Node2EquipmentArray[pLine->nNodeZ].nPoleArray.push_back((int)m_PoleArray.size());
	}
	m_PoleArray.push_back(pole);
}

int	CGISData::ParseTerminalFlag(const char* lpszSymbolID, const char* lpszTerminalResId)
{
	std::vector<std::string>	strEleArray;
	char	szResId[260];
	char*	lpszToken;

	strcpy(szResId, lpszTerminalResId);
	strEleArray.clear();
	lpszToken=strtok(szResId, " \t\n-");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " \t\n-");
	}

	if (strEleArray.empty())
		return 0;

	int		nTermID=atoi(strEleArray[strEleArray.size()-1].c_str());
	if (stricmp(lpszSymbolID, "2004-0") == 0 ||
		stricmp(lpszSymbolID, "2005-0") == 0 ||
		stricmp(lpszSymbolID, "2309-0") == 0 ||
		stricmp(lpszSymbolID, "2310-0") == 0 ||
		stricmp(lpszSymbolID, "2311-0") == 0 ||
		stricmp(lpszSymbolID, "2312-0") == 0 ||
		stricmp(lpszSymbolID, "2313-0") == 0 ||
		stricmp(lpszSymbolID, "2314-0") == 0 ||
		stricmp(lpszSymbolID, "2315-0") == 0 ||
		stricmp(lpszSymbolID, "2316-0") == 0)
		if (nTermID >= 3)	nTermID=0;
	return nTermID;
}

void	CGISData::AbstractACLineSegmentName(const char* lpszName1, const char* lpszName2, char* lpszNameOut)
{
	register int	i;
	int			nSplit;
	char		szBuf[260];
	char*		lpszToken;
	std::string	strBuf;
	std::vector<std::string>	strSplit1Array;
	std::vector<std::string>	strSplit2Array;
	std::vector<std::string>	strSameArray;

	strSplit1Array.clear();
	strSplit2Array.clear();

	strcpy(szBuf, lpszName1);
	lpszToken=strtok(szBuf, "-");
	while (lpszToken != NULL)
	{
		strSplit1Array.push_back(lpszToken);
		lpszToken=strtok(NULL, "-");
	}

	strcpy(szBuf, lpszName2);
	lpszToken=strtok(szBuf, "-");
	while (lpszToken != NULL)
	{
		strSplit2Array.push_back(lpszToken);
		lpszToken=strtok(NULL, "-");
	}

	strSameArray.clear();
	for (nSplit=0; nSplit<(int)strSplit1Array.size(); nSplit++)
	{
		for (i=0; i<(int)strSplit2Array.size(); i++)
		{
			if (stricmp(strSplit1Array[nSplit].c_str(), strSplit2Array[i].c_str()) == 0)
			{
				strSameArray.push_back(strSplit1Array[nSplit]);
				break;
			}
		}
	}
	if (strSameArray.empty())
		strcpy(lpszNameOut, lpszName1);

	for (nSplit=0; nSplit<(int)strSameArray.size(); nSplit++)
	{
		if (nSplit != 0)
			strBuf.append("-");
		strBuf.append(strSameArray[nSplit]);
	}
	strcpy(lpszNameOut, szBuf);
}

const std::string	CGISData::GetVoltageLevelName(const char* lpszVoltTag)
{
	int	nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, lpszVoltTag);
	if (nFind >= 0)
		return m_BaseVoltageArray[nFind].strName;
	return "";
}

const std::string	CGISData::GetPSRTypeName(const char* lpszPSRTypeTag)
{
	int	nFind=findPSRTypeByResID(0, (int)m_PSRTypeArray.size()-1, lpszPSRTypeTag);
	if (nFind >= 0)
		return m_PSRTypeArray[nFind].strName;
	return "";
}

const std::string	CGISData::GetFeederName(const char* lpszFeederTag)
{
	register int	i;
	for (i=0; i<(int)m_FeederArray.size(); i++)
	{
		if (strcmp(lpszFeederTag, m_FeederArray[i].strResourceID.c_str()) == 0)
			return m_FeederArray[i].strName;
	}
	return "";
}

const std::string	CGISData::GetGeographicalRegionName(const char* lpszGeographicalRegionTag)
{
	register int	i;
	for (i=0; i<(int)m_GeographicalRegionArray.size(); i++)
	{
		if (strcmp(lpszGeographicalRegionTag, m_GeographicalRegionArray[i].strResourceID.c_str()) == 0)
			return m_GeographicalRegionArray[i].strName;
	}
	return "";
}

const std::string	CGISData::GetSubGeographicalRegionName(const char* lpszSubGeographicalRegionTag)
{
	register int	i;
	for (i=0; i<(int)m_SubGeographicalRegionArray.size(); i++)
	{
		if (strcmp(lpszSubGeographicalRegionTag, m_SubGeographicalRegionArray[i].strResourceID.c_str()) == 0)
			return m_SubGeographicalRegionArray[i].strName;
	}
	return "";
}
