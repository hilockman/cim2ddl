#include "stdafx.h"
#include "GISData.h"

void	CGISData::ParseEquipmentSpatial()
{
	register int	i;
	int		nDev, nNode, nLine, nIdx;
	unsigned char	bFindSpatial, bFindReference;
	double	fNodeX, fNodeY, fRefX, fRefY, fDistIni, fDistEnd;
	double	fIniX, fIniY, fEndX, fEndY;
	tagGISVertex	ptVert;
	std::vector<tagGISVertex>	vtArray;

	for (nDev=0; nDev<(int)m_SubstationArray.size(); nDev++)
	{
		if (m_SubstationArray[nDev].gData.strCoordinate.empty())
			continue;
		ParseptVertexArray(vtArray, m_SubstationArray[nDev].gData.strCoordinate.c_str());
		if (vtArray.empty())
			continue;

		m_SubstationArray[nDev].ptLoc.fX=vtArray[0].fX;
		m_SubstationArray[nDev].ptLoc.fY=vtArray[0].fY;
	}
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		if (m_PoleArray[nDev].gData.strCoordinate.empty())
			continue;
		ParseptVertexArray(vtArray, m_PoleArray[nDev].gData.strCoordinate.c_str());
		if (vtArray.empty())
			continue;

		m_PoleArray[nDev].ptLoc.fX=vtArray[0].fX;
		m_PoleArray[nDev].ptLoc.fY=vtArray[0].fY;
	}
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].gData.strCoordinate.empty())
			continue;
		ParseptVertexArray(vtArray, m_JunctionArray[nDev].gData.strCoordinate.c_str());
		if (vtArray.empty())
			continue;

		m_JunctionArray[nDev].ptLoc.fX=vtArray[0].fX;
		m_JunctionArray[nDev].ptLoc.fY=vtArray[0].fY;
	}

	for (nDev=0; nDev<(int)m_ZJArray.size(); nDev++)
	{
		if (m_ZJArray[nDev].gData.strCoordinate.empty())
			continue;
		ParseptVertexArray(vtArray, m_ZJArray[nDev].gData.strCoordinate.c_str());
		if (vtArray.empty())
			continue;

		m_ZJArray[nDev].ptLoc.fX=vtArray[0].fX;
		m_ZJArray[nDev].ptLoc.fY=vtArray[0].fY;
	}
	//////////////////////////////////////////////////////////////////////////
	//	�����ǿ���ֱ�Ӷ�λ��
	//////////////////////////////////////////////////////////////////////////

	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		if (m_PoleArray[nDev].nNode < 0)
			continue;

		fNodeX=m_PoleArray[nDev].ptLoc.fX;
		fNodeY=m_PoleArray[nDev].ptLoc.fY;
		for (nLine=0; nLine<(int)m_Node2EquipmentArray[m_PoleArray[nDev].nNode].nConnLineArray.size(); nLine++)
		{
			nIdx=m_Node2EquipmentArray[m_PoleArray[nDev].nNode].nConnLineArray[nLine];

			ParseptVertexArray(vtArray, m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
			if (vtArray.size() < 2)
				continue;
			fIniX=vtArray[0].fX;
			fIniY=vtArray[0].fY;
			fEndX=vtArray[vtArray.size()-1].fX;
			fEndY=vtArray[vtArray.size()-1].fY;

			//Log(g_lpszLogFile, "Poleվ�������������� : %s Coord=%s\n", m_ConnLineArray[nIdx].strResourceID.c_str(), m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
			fDistIni=(fIniX-fNodeX)*(fIniX-fNodeX)+(fIniY-fNodeY)*(fIniY-fNodeY);
			fDistEnd=(fEndX-fNodeX)*(fEndX-fNodeX)+(fEndY-fNodeY)*(fEndY-fNodeY);
			ptVert.fX=fNodeX;
			ptVert.fY=fNodeY;
			if (fDistIni < fDistEnd)
				RelocateCoordinate(m_ConnLineArray[nIdx].gData.strCoordinate, 1, &ptVert);
			else
				RelocateCoordinate(m_ConnLineArray[nIdx].gData.strCoordinate, 2, &ptVert);
			//Log(g_lpszLogFile, "        Coord=%s\n", m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
		}
		for (nLine=0; nLine<(int)m_Node2EquipmentArray[m_PoleArray[nDev].nNode].nACLineSegmentArray.size(); nLine++)
		{
			nIdx=m_Node2EquipmentArray[m_PoleArray[nDev].nNode].nACLineSegmentArray[nLine];
			ParseptVertexArray(vtArray, m_ACLineSegmentArray[nIdx].gData.strCoordinate.c_str());
			if (vtArray.size() < 2)
				continue;

			//Log(g_lpszLogFile, "Pole���߶ζ�λ : %s Coord=%s\n", m_ACLineSegmentArray[nIdx].strResourceID.c_str(), m_ACLineSegmentArray[nIdx].gData.strCoordinate.c_str());
			fIniX=vtArray[0].fX;
			fIniY=vtArray[0].fY;
			fEndX=vtArray[vtArray.size()-1].fX;
			fEndY=vtArray[vtArray.size()-1].fY;
			fDistIni=(fIniX-fNodeX)*(fIniX-fNodeX)+(fIniY-fNodeY)*(fIniY-fNodeY);
			fDistEnd=(fEndX-fNodeX)*(fEndX-fNodeX)+(fEndY-fNodeY)*(fEndY-fNodeY);
			ptVert.fX=fNodeX;
			ptVert.fY=fNodeY;
			if (fDistIni < fDistEnd)
				RelocateCoordinate(m_ACLineSegmentArray[nIdx].gData.strCoordinate, 1, &ptVert);
			else
				RelocateCoordinate(m_ACLineSegmentArray[nIdx].gData.strCoordinate, 2, &ptVert);
			//Log(g_lpszLogFile, "        Coord=%s\n", m_ACLineSegmentArray[nIdx].gData.strCoordinate.c_str());
		}
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Junction\n");
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].nNode < 0)
			continue;

		fNodeX=m_JunctionArray[nDev].ptLoc.fX;
		fNodeY=m_JunctionArray[nDev].ptLoc.fY;
		for (nLine=0; nLine<(int)m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nConnLineArray.size(); nLine++)
		{
			nIdx=m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nConnLineArray[nLine];
			ParseptVertexArray(vtArray, m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
			if (vtArray.size() < 2)
				continue;

			fIniX=vtArray[0].fX;
			fIniY=vtArray[0].fY;
			fEndX=vtArray[vtArray.size()-1].fX;
			fEndY=vtArray[vtArray.size()-1].fY;

			//Log(g_lpszLogFile, "Junctionվ�������������� : %s Coord=%s\n", m_ConnLineArray[nIdx].strResourceID.c_str(), m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
			fDistIni=(fIniX-fNodeX)*(fIniX-fNodeX)+(fIniY-fNodeY)*(fIniY-fNodeY);
			fDistEnd=(fEndX-fNodeX)*(fEndX-fNodeX)+(fEndY-fNodeY)*(fEndY-fNodeY);
			ptVert.fX=fNodeX;
			ptVert.fY=fNodeY;
			if (fDistIni < fDistEnd)
				RelocateCoordinate(m_ConnLineArray[nIdx].gData.strCoordinate, 1, &ptVert);
			else
				RelocateCoordinate(m_ConnLineArray[nIdx].gData.strCoordinate, 2, &ptVert);
			//Log(g_lpszLogFile, "        Coord=%s\n", m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
		}
		for (nLine=0; nLine<(int)m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nACLineSegmentArray.size(); nLine++)
		{
			nIdx=m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nACLineSegmentArray[nLine];
			ParseptVertexArray(vtArray, m_ACLineSegmentArray[nIdx].gData.strCoordinate.c_str());
			if (vtArray.size() < 2)
				continue;

			//Log(g_lpszLogFile, "Junction���߶ζ�λ : %s Coord=%s\n", m_ACLineSegmentArray[nIdx].strResourceID.c_str(), m_ACLineSegmentArray[nIdx].gData.strCoordinate.c_str());
			fIniX=vtArray[0].fX;
			fIniY=vtArray[0].fY;
			fEndX=vtArray[vtArray.size()-1].fX;
			fEndY=vtArray[vtArray.size()-1].fY;
			fDistIni=(fIniX-fNodeX)*(fIniX-fNodeX)+(fIniY-fNodeY)*(fIniY-fNodeY);
			fDistEnd=(fEndX-fNodeX)*(fEndX-fNodeX)+(fEndY-fNodeY)*(fEndY-fNodeY);
			ptVert.fX=fNodeX;
			ptVert.fY=fNodeY;
			if (fDistIni < fDistEnd)
				RelocateCoordinate(m_ACLineSegmentArray[nIdx].gData.strCoordinate, 1, &ptVert);
			else
				RelocateCoordinate(m_ACLineSegmentArray[nIdx].gData.strCoordinate, 2, &ptVert);
			//Log(g_lpszLogFile, "        Coord=%s\n", m_ACLineSegmentArray[nIdx].gData.strCoordinate.c_str());
		}
	}
	//////////////////////////////////////////////////////////////////////////
	//	��ȷ����λ
	//////////////////////////////////////////////////////////////////////////

	for (nNode=0; nNode<(int)m_ConnectivityNodeArray.size(); nNode++)
	{
#ifdef _DEBUG
		if (!m_Node2EquipmentArray[nNode].nPowerTransformerArray.empty())
		{
			Log(g_lpszLogFile, "########��ѹ���ڵ� %s Volt=%s Wind=%d\n", m_ConnectivityNodeArray[nNode].strResourceID.c_str(), m_ConnectivityNodeArray[nNode].strBaseVoltageTag.c_str(), m_Node2EquipmentArray[nNode].nPowerTransformerArray.size());
			Log(g_lpszLogFile, "        ��ѹ����Ϣ Node=%d TranNode=%d %d %d\n", nNode, 
				m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[0]].nNodeArray[0], 
				m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[0]].nNodeArray[1], 
				m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[0]].nNodeArray[2]);

			if (m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[0]].nWindNum > 1)
				bFindSpatial=0;
		}
#endif // _DEBUG
		bFindSpatial=0;
		if (!bFindSpatial)
		{
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nPoleArray.size(); nDev++)
			{
				ParseptVertexArray(vtArray, m_PoleArray[m_Node2EquipmentArray[nNode].nPoleArray[nDev]].gData.strCoordinate.c_str());
				if (vtArray.empty())
					continue;

				fNodeX=vtArray[0].fX;
				fNodeY=vtArray[0].fY;
				bFindSpatial=1;
				break;
			}
		}

		if (!bFindSpatial)
		{
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nJunctionArray.size(); nDev++)
			{
				ParseptVertexArray(vtArray, m_JunctionArray[m_Node2EquipmentArray[nNode].nJunctionArray[nDev]].gData.strCoordinate.c_str());
				if (vtArray.empty())
					continue;

				fNodeX=vtArray[0].fX;
				fNodeY=vtArray[0].fY;
				bFindSpatial=1;
				break;
			}
		}

		if (!bFindSpatial)	//	�������ڵ��豸�����豸�ڵ���������·�������߶�
		{
			bFindReference=0;
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nBreakerArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_BreakerArray[m_Node2EquipmentArray[nNode].nBreakerArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nDisconnectorArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_DisconnectorArray[m_Node2EquipmentArray[nNode].nDisconnectorArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nFuseArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_FuseArray[m_Node2EquipmentArray[nNode].nFuseArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nGroundDisconnectorArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_GroundDisconnectorArray[m_Node2EquipmentArray[nNode].nGroundDisconnectorArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nCompensatorArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_CompensatorArray[m_Node2EquipmentArray[nNode].nCompensatorArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nCapacitorArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_CapacitorArray[m_Node2EquipmentArray[nNode].nCapacitorArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}
			if (!bFindReference)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nPowerTransformerArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fRefX=vtArray[0].fX;
					fRefY=vtArray[0].fY;
					bFindReference=1;
					break;
				}
			}

			if (!bFindReference)
			{
#ifdef _DEBUG
				if (!m_Node2EquipmentArray[nNode].nPowerTransformerArray.empty())
					Log(g_lpszLogFile, "��λ�ڵ� %s û���ҵ��ο���\n", m_ConnectivityNodeArray[nNode].strResourceID.c_str());
#endif // _DEBUG
				continue;
			}

			if (!bFindSpatial)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nACLineSegmentArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_ACLineSegmentArray[m_Node2EquipmentArray[nNode].nACLineSegmentArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fDistIni=(vtArray[0].fX-fRefX)*(vtArray[0].fX-fRefX)+(vtArray[0].fY-fRefY)*(vtArray[0].fY-fRefY);
					fDistEnd=(vtArray[vtArray.size()-1].fX-fRefX)*(vtArray[vtArray.size()-1].fX-fRefX)+(vtArray[vtArray.size()-1].fY-fRefY)*(vtArray[vtArray.size()-1].fY-fRefY);
					if (fDistIni > fDistEnd)
					{
						fNodeX=vtArray[vtArray.size()-1].fX;
						fNodeY=vtArray[vtArray.size()-1].fY;
					}
					else
					{
						fNodeX=vtArray[0].fX;
						fNodeY=vtArray[0].fY;
					}
					bFindSpatial=1;
					break;
				}
			}

			if (!bFindSpatial)
			{
				for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nConnLineArray.size(); nDev++)
				{
					ParseptVertexArray(vtArray, m_ConnLineArray[m_Node2EquipmentArray[nNode].nConnLineArray[nDev]].gData.strCoordinate.c_str());
					if (vtArray.empty())
						continue;

					fDistIni=(vtArray[0].fX-fRefX)*(vtArray[0].fX-fRefX)+(vtArray[0].fY-fRefY)*(vtArray[0].fY-fRefY);
					fDistEnd=(vtArray[vtArray.size()-1].fX-fRefX)*(vtArray[vtArray.size()-1].fX-fRefX)+(vtArray[vtArray.size()-1].fY-fRefY)*(vtArray[vtArray.size()-1].fY-fRefY);
					if (fDistIni > fDistEnd)
					{
						fNodeX=vtArray[vtArray.size()-1].fX;
						fNodeY=vtArray[vtArray.size()-1].fY;
					}
					else
					{
						fNodeX=vtArray[0].fX;
						fNodeY=vtArray[0].fY;
					}
					bFindSpatial=1;
					break;
				}
			}
		}
		if (!bFindSpatial)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "��λ�ڵ� %s û���ҵ���λ��\n", m_ConnectivityNodeArray[nNode].strResourceID.c_str());
#endif // _DEBUG
			continue;
		}

		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nBreakerArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_BreakerArray[m_Node2EquipmentArray[nNode].nBreakerArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_BreakerArray[m_Node2EquipmentArray[nNode].nBreakerArray[nDev]].ptLoc.fX=fRefX;
			m_BreakerArray[m_Node2EquipmentArray[nNode].nBreakerArray[nDev]].ptLoc.fY=fRefY;
			m_BreakerArray[m_Node2EquipmentArray[nNode].nBreakerArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nDisconnectorArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_DisconnectorArray[m_Node2EquipmentArray[nNode].nDisconnectorArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_DisconnectorArray[m_Node2EquipmentArray[nNode].nDisconnectorArray[nDev]].ptLoc.fX=fRefX;
			m_DisconnectorArray[m_Node2EquipmentArray[nNode].nDisconnectorArray[nDev]].ptLoc.fY=fRefY;
			m_DisconnectorArray[m_Node2EquipmentArray[nNode].nDisconnectorArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[nDev]].ptLoc.fX=fRefX;
			m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[nDev]].ptLoc.fY=fRefY;
			m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nFuseArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_FuseArray[m_Node2EquipmentArray[nNode].nFuseArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_FuseArray[m_Node2EquipmentArray[nNode].nFuseArray[nDev]].ptLoc.fX=fRefX;
			m_FuseArray[m_Node2EquipmentArray[nNode].nFuseArray[nDev]].ptLoc.fY=fRefY;
			m_FuseArray[m_Node2EquipmentArray[nNode].nFuseArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nGroundDisconnectorArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_GroundDisconnectorArray[m_Node2EquipmentArray[nNode].nGroundDisconnectorArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_GroundDisconnectorArray[m_Node2EquipmentArray[nNode].nGroundDisconnectorArray[nDev]].ptLoc.fX=fRefX;
			m_GroundDisconnectorArray[m_Node2EquipmentArray[nNode].nGroundDisconnectorArray[nDev]].ptLoc.fY=fRefY;
			m_GroundDisconnectorArray[m_Node2EquipmentArray[nNode].nGroundDisconnectorArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nCompensatorArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_CompensatorArray[m_Node2EquipmentArray[nNode].nCompensatorArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_CompensatorArray[m_Node2EquipmentArray[nNode].nCompensatorArray[nDev]].ptLoc.fX=fRefX;
			m_CompensatorArray[m_Node2EquipmentArray[nNode].nCompensatorArray[nDev]].ptLoc.fY=fRefY;
			m_CompensatorArray[m_Node2EquipmentArray[nNode].nCompensatorArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nCapacitorArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_CapacitorArray[m_Node2EquipmentArray[nNode].nCapacitorArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_CapacitorArray[m_Node2EquipmentArray[nNode].nCapacitorArray[nDev]].ptLoc.fX=fRefX;
			m_CapacitorArray[m_Node2EquipmentArray[nNode].nCapacitorArray[nDev]].ptLoc.fY=fRefY;
			m_CapacitorArray[m_Node2EquipmentArray[nNode].nCapacitorArray[nDev]].fSize=2*sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
		}
		for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNode].nPowerTransformerArray.size(); nDev++)
		{
			ParseptVertexArray(vtArray, m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].gData.strCoordinate.c_str());
			if (vtArray.empty())
				continue;

			fRefX=vtArray[0].fX;
			fRefY=vtArray[0].fY;

			m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].ptLoc.fX=fRefX;
			m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].ptLoc.fY=fRefY;

			for (i=0; i<m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].nWindNum; i++)
			{
				if (nNode == m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].nNodeArray[i])
				{
					m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].ptVertArray[i].fX=fNodeX;
					m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].ptVertArray[i].fY=fNodeY;
					fDistIni=sqrt((fNodeX-fRefX)*(fNodeX-fRefX)+(fNodeY-fRefY)*(fNodeY-fRefY));
#ifdef _DEBUG
					Log(g_lpszLogFile, "��ѹ�� [%s] ��λ [%d] ���� Size=%f\n", m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].strResourceID.c_str(), i, fDistIni);
#endif // _DEBUG
					if ((fDistIni > 0 && fDistIni < m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].fSize) || m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].fSize <= FLT_MIN)
						m_PowerTransformerArray[m_Node2EquipmentArray[nNode].nPowerTransformerArray[nDev]].fSize=fDistIni;
					break;
				}
			}
		}
	}

	if (!vtArray.empty())	vtArray.clear();
}

void	CGISData::RelocateEquipmentCoord()
{
	register int	i;
	int		nDev;
	std::vector<tagGISVertex>	vtArray;

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Breaker\n");
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (m_BreakerArray[nDev].nSubIdx < 0)
			continue;
		m_BreakerArray[nDev].ptLoc.fX += m_SubstationArray[m_BreakerArray[nDev].nSubIdx].ptLoc.fX;
		m_BreakerArray[nDev].ptLoc.fY += m_SubstationArray[m_BreakerArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Disconnector\n");
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (m_DisconnectorArray[nDev].nSubIdx < 0)
			continue;
		m_DisconnectorArray[nDev].ptLoc.fX += m_SubstationArray[m_DisconnectorArray[nDev].nSubIdx].ptLoc.fX;
		m_DisconnectorArray[nDev].ptLoc.fY += m_SubstationArray[m_DisconnectorArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@GroundDisconnector\n");
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		if (m_GroundDisconnectorArray[nDev].nSubIdx < 0)
			continue;
		m_GroundDisconnectorArray[nDev].ptLoc.fX += m_SubstationArray[m_GroundDisconnectorArray[nDev].nSubIdx].ptLoc.fX;
		m_GroundDisconnectorArray[nDev].ptLoc.fY += m_SubstationArray[m_GroundDisconnectorArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@LoadBreakSwitch\n");
	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		if (m_LoadBreakSwitchArray[nDev].nSubIdx < 0)
			continue;
		m_LoadBreakSwitchArray[nDev].ptLoc.fX += m_SubstationArray[m_LoadBreakSwitchArray[nDev].nSubIdx].ptLoc.fX;
		m_LoadBreakSwitchArray[nDev].ptLoc.fY += m_SubstationArray[m_LoadBreakSwitchArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Fuse\n");
	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		if (m_FuseArray[nDev].nSubIdx < 0)
			continue;
		m_FuseArray[nDev].ptLoc.fX += m_SubstationArray[m_FuseArray[nDev].nSubIdx].ptLoc.fX;
		m_FuseArray[nDev].ptLoc.fY += m_SubstationArray[m_FuseArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Pole\n");
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		if (m_PoleArray[nDev].nSubIdx < 0)
			continue;
		m_PoleArray[nDev].ptLoc.fX += m_SubstationArray[m_PoleArray[nDev].nSubIdx].ptLoc.fX;
		m_PoleArray[nDev].ptLoc.fY += m_SubstationArray[m_PoleArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Junction\n");
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].nSubIdx < 0)
			continue;
		m_JunctionArray[nDev].ptLoc.fX += m_SubstationArray[m_JunctionArray[nDev].nSubIdx].ptLoc.fX;
		m_JunctionArray[nDev].ptLoc.fY += m_SubstationArray[m_JunctionArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@EnergyConsumer\n");
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		if (m_EnergyConsumerArray[nDev].nSubIdx < 0)
			continue;
		m_EnergyConsumerArray[nDev].ptLoc.fX += m_SubstationArray[m_EnergyConsumerArray[nDev].nSubIdx].ptLoc.fX;
		m_EnergyConsumerArray[nDev].ptLoc.fY += m_SubstationArray[m_EnergyConsumerArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Compensator\n");
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		if (m_CompensatorArray[nDev].nSubIdx < 0)
			continue;
		m_CompensatorArray[nDev].ptLoc.fX += m_SubstationArray[m_CompensatorArray[nDev].nSubIdx].ptLoc.fX;
		m_CompensatorArray[nDev].ptLoc.fY += m_SubstationArray[m_CompensatorArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@Capacitor\n");
	//	Capacitor��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		if (m_CapacitorArray[nDev].nSubIdx < 0)
			continue;
		m_CapacitorArray[nDev].ptLoc.fX += m_SubstationArray[m_CapacitorArray[nDev].nSubIdx].ptLoc.fX;
		m_CapacitorArray[nDev].ptLoc.fY += m_SubstationArray[m_CapacitorArray[nDev].nSubIdx].ptLoc.fY;
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@BusbarSection\n");
	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		if (m_BusbarSectionArray[nDev].nSubIdx < 0)
			continue;
		//Log(g_lpszLogFile, "BusbarSectionƫ�� : %s Coord=%s\n", m_BusbarSectionArray[nDev].strResourceID.c_str(), m_GraphicArray[m_BusbarSectionArray[nDev].nGraphic].strCoordinate.c_str());
		ShiftCoordinate(m_BusbarSectionArray[nDev].gData.strCoordinate, &m_SubstationArray[m_BusbarSectionArray[nDev].nSubIdx].ptLoc);
		//Log(g_lpszLogFile, "                %s\n", m_GraphicArray[m_BusbarSectionArray[nDev].nGraphic].strCoordinate.c_str());
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@ACLineSegment\n");
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		if (m_ACLineSegmentArray[nDev].nContainerIdx < 0)
			continue;
		ShiftCoordinate(m_ACLineSegmentArray[nDev].gData.strCoordinate, &m_SubstationArray[m_ACLineSegmentArray[nDev].nContainerIdx].ptLoc);
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@ConnLine\n");
	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		if (m_ConnLineArray[nDev].nSubIdx < 0)
			continue;
		ShiftCoordinate(m_ConnLineArray[nDev].gData.strCoordinate, &m_SubstationArray[m_ConnLineArray[nDev].nSubIdx].ptLoc);
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@PowerTransformer\n");
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (m_PowerTransformerArray[nDev].nSubIdx < 0)
			continue;
		m_PowerTransformerArray[nDev].ptLoc.fX += m_SubstationArray[m_PowerTransformerArray[nDev].nSubIdx].ptLoc.fX;
		m_PowerTransformerArray[nDev].ptLoc.fY += m_SubstationArray[m_PowerTransformerArray[nDev].nSubIdx].ptLoc.fY;

		for (i=0; i<3; i++)
		{
			m_PowerTransformerArray[nDev].ptVertArray[i].fX += m_SubstationArray[m_PowerTransformerArray[nDev].nSubIdx].ptLoc.fX;
			m_PowerTransformerArray[nDev].ptVertArray[i].fY += m_SubstationArray[m_PowerTransformerArray[nDev].nSubIdx].ptLoc.fY;
		}
	}

	//Log(g_lpszLogFile, "    RelocateEquipmentCoord@15\n");
	//	ZJ��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_ZJArray.size(); nDev++)
	{
		if (m_ZJArray[nDev].nSubIdx < 0)
			continue;
		m_ZJArray[nDev].ptLoc.fX += m_SubstationArray[m_ZJArray[nDev].nSubIdx].ptLoc.fX;
		m_ZJArray[nDev].ptLoc.fY += m_SubstationArray[m_ZJArray[nDev].nSubIdx].ptLoc.fY;
	}

	int		nLine, nIdx;
	double	fNodeX, fNodeY, fDistIni, fDistEnd;
	double	fIniX, fIniY, fEndX, fEndY;
	tagGISVertex	ptVert;
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		if (m_JunctionArray[nDev].nNode < 0)
			continue;

		ParseptVertexArray(vtArray, m_JunctionArray[nDev].gData.strCoordinate.c_str());
		if (vtArray.empty())
			continue;

		fNodeX=vtArray[0].fX;
		fNodeY=vtArray[0].fY;
		for (nLine=0; nLine<(int)m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nConnLineArray.size(); nLine++)
		{
			nIdx=m_Node2EquipmentArray[m_JunctionArray[nDev].nNode].nConnLineArray[nLine];
			ParseptVertexArray(vtArray, m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
			if (vtArray.size() < 2)
				continue;

			fIniX=vtArray[0].fX;
			fIniY=vtArray[0].fY;
			fEndX=vtArray[vtArray.size()-1].fX;
			fEndY=vtArray[vtArray.size()-1].fY;
			if (sqrt((fIniX-fEndX)*(fIniX-fEndX)+(fIniY-fEndY)*(fIniY-fEndY)) < 100000)	//	վ����������
				continue;

			//Log(g_lpszLogFile, "Junctionվ�������������� : %s Coord=%s NodeXY=(%f, %f)\n", m_ConnLineArray[nIdx].strResourceID.c_str(), m_ConnLineArray[nIdx].gData.strCoordinate.c_str(), fNodeX, fNodeY);
			fDistIni=(fIniX-fNodeX)*(fIniX-fNodeX)+(fIniY-fNodeY)*(fIniY-fNodeY);
			fDistEnd=(fEndX-fNodeX)*(fEndX-fNodeX)+(fEndY-fNodeY)*(fEndY-fNodeY);
			ptVert.fX=m_JunctionArray[nDev].ptLoc.fX;
			ptVert.fY=m_JunctionArray[nDev].ptLoc.fY;
			if (fDistIni < fDistEnd)
				RelocateCoordinate(m_ConnLineArray[nIdx].gData.strCoordinate, 1, &ptVert);
			else
				RelocateCoordinate(m_ConnLineArray[nIdx].gData.strCoordinate, 2, &ptVert);
			//Log(g_lpszLogFile, "        Coord=%s\n", m_ConnLineArray[nIdx].gData.strCoordinate.c_str());
		}
	}
}
