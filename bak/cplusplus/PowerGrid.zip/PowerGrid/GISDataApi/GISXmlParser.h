#pragma once

#include "GISData.h"

class GISDATAAPI_API CGISXmlParser
{
public:
	CGISXmlParser(void);
	~CGISXmlParser(void);

public:
	int		Parse(CGISData& gData, std::vector<std::string>& strXmlFileArray, std::string& strFilterMark, std::vector<std::string>& strFilterKeyArray, const int bParseBySax=1, const unsigned char bCoordNormalize=1, const unsigned char bClearData=1, const unsigned char bDataWash=0, const unsigned char bJointReserve=0);
	int		Parse(CGISData& gData, const char* lpszFileName, std::string& strFilterMark, std::vector<std::string>& strFilterKeyArray, const int bParseBySax=1, const unsigned char bCoordNormalize=1);

private:
	int		ParseXmlBySax(CGISData& gData, const char* lpszFileName, std::string& strFilterMark, std::vector<std::string>& strFilterKeyArray);

private:
};

extern	void		Log(const char* lpszLogFile, char* pformat, ...);
extern	const		char*	g_lpszLogFile;
