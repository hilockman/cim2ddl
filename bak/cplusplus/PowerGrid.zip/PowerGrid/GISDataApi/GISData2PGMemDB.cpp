#include "StdAfx.h"
#include "GISData.h"
#include "GISData2PGMemDB.h"

#if (!defined(WIN64))
#	pragma comment(lib, "../../lib/PGMemDB.lib")
#	pragma message("GISDataApi Link LibX86 PGMemDB.lib")
#else
#	pragma comment(lib, "../../lib_x64/PGMemDB.lib")
#	pragma message("GISDataApi Link LibX64 PGMemDB.lib")
#endif

CGISData2PGMemDB::CGISData2PGMemDB(void)
{
}

CGISData2PGMemDB::~CGISData2PGMemDB(void)
{
}

const char*	CGISData2PGMemDB::GetVoltageName(CGISData* pGData, const char* lpszBaseVolt)
{
	register int	i;
	int	nVolt=-1;
	for (i=0; i<(int)pGData->m_BaseVoltageArray.size(); i++)
	{
		if (stricmp(lpszBaseVolt, pGData->m_BaseVoltageArray[i].strResourceID.c_str()) == 0 || stricmp(lpszBaseVolt, pGData->m_BaseVoltageArray[i].strName.c_str()) == 0)
		{
			nVolt=i;
			break;
		}
	}
	if (nVolt < 0)
		return "";

	return pGData->m_BaseVoltageArray[nVolt].strName.c_str();
}

float	CGISData2PGMemDB::GetVoltageNorminal(CGISData* pGData, const char* lpszBaseVolt)
{
	register int	i;
	int	nVolt=-1;
	for (i=0; i<(int)pGData->m_BaseVoltageArray.size(); i++)
	{
		if (stricmp(lpszBaseVolt, pGData->m_BaseVoltageArray[i].strResourceID.c_str()) == 0 || stricmp(lpszBaseVolt, pGData->m_BaseVoltageArray[i].strName.c_str()) == 0)
		{
			nVolt=i;
			break;
		}
	}
	if (nVolt < 0)
		return 0;

	return pGData->m_BaseVoltageArray[nVolt].fNominalVoltage;
}


void	CGISData2PGMemDB::ClearMemDB(tagPGBlock* pBlock)
{
	register int	i;
	for (i=0; i<MAXMDBTABLENUM; i++)
		pBlock->m_nRecordNum[i]=0;
	pBlock->m_nRecordNum[PG_SYSTEM]=1;
	pBlock->m_System.fBasePower=100;
}

int	CGISData2PGMemDB::FillMemDB(tagPGBlock* pBlock, CGISData* pGData, const int bClearMDB)
{
	//m_ParamSetting.Read();
	if (bClearMDB)
		ClearMemDB(pBlock);

	pBlock->m_System.fBasePower=100;
	InsertDefault(pBlock, pGData);				Log(g_lpszLogFile, "InsertDefault\n");
	InsertSubstation(pBlock, pGData);			Log(g_lpszLogFile, "InsertSubstation\n");
	InsertBusbarSection(pBlock, pGData);		Log(g_lpszLogFile, "InsertBusbarSection\n");
	InsertACLineSegment(pBlock, pGData);		Log(g_lpszLogFile, "InsertACLineSegment\n");
	InsertPowerTransformer(pBlock, pGData);		Log(g_lpszLogFile, "InsertPowerTransformer\n");
	InsertBreakDisconnector(pBlock, pGData);	Log(g_lpszLogFile, "InsertBreakDisconnector\n");
	InsertCompensator(pBlock, pGData);			Log(g_lpszLogFile, "InsertCompensator\n");
	//InsertPole(pBlock, pGData);				Log(g_lpszLogFile, "InsertPole\n");
	InsertPipe(pBlock, pGData);					Log(g_lpszLogFile, "InsertPipe\n");

	PostFillMemDB(pBlock, pGData);				Log(g_lpszLogFile, "PostFillMemDB\n");

	return 1;
}

int CGISData2PGMemDB::PostFillMemDB(tagPGBlock* pBlock, CGISData* pGData)
{
	PGMaint(pBlock);
	return 1;
}

void	CGISData2PGMemDB::InsertDefault(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i, j;


	for (i=0; i<(int)pGData->m_BaseVoltageArray.size(); i++)
	{
		memset(&pBlock->m_BaseVoltageArray[pBlock->m_nRecordNum[PG_BASEVOLTAGE]], 0, sizeof(tagPGBaseVoltage));
		strcpy(pBlock->m_BaseVoltageArray[pBlock->m_nRecordNum[PG_BASEVOLTAGE]].szName,			pGData->m_BaseVoltageArray[i].strName.c_str());
		strcpy(pBlock->m_BaseVoltageArray[pBlock->m_nRecordNum[PG_BASEVOLTAGE]].szResID,		pGData->m_BaseVoltageArray[i].strResourceID.c_str());
		pBlock->m_BaseVoltageArray[pBlock->m_nRecordNum[PG_BASEVOLTAGE]].nominalVoltage=pGData->m_BaseVoltageArray[i].fNominalVoltage;
		pBlock->m_nRecordNum[PG_BASEVOLTAGE]++;
	}

	for (i=0; i<(int)pGData->m_GeographicalRegionArray.size(); i++)
	{
		memset(&pBlock->m_CompanyArray[pBlock->m_nRecordNum[PG_COMPANY]], 0, sizeof(tagPGCompany));
		strcpy(pBlock->m_CompanyArray[pBlock->m_nRecordNum[PG_COMPANY]].szResID, pGData->m_GeographicalRegionArray[i].strResourceID.c_str());
		strcpy(pBlock->m_CompanyArray[pBlock->m_nRecordNum[PG_COMPANY]].szName, pGData->m_GeographicalRegionArray[i].strName.c_str());
		pBlock->m_nRecordNum[PG_COMPANY]++;
	}
	for (i=0; i<(int)pGData->m_SubGeographicalRegionArray.size(); i++)
	{
		memset(&pBlock->m_SubcontrolAreaArray[pBlock->m_nRecordNum[PG_SUBCONTROLAREA]], 0, sizeof(tagPGSubcontrolArea));
		strcpy(pBlock->m_SubcontrolAreaArray[pBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szResID, pGData->m_SubGeographicalRegionArray[i].strResourceID.c_str());
		strcpy(pBlock->m_SubcontrolAreaArray[pBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szName, pGData->m_SubGeographicalRegionArray[i].strName.c_str());
		for (j=0; j<(int)pGData->m_GeographicalRegionArray.size(); j++)
		{
			if (strcmp(pGData->m_GeographicalRegionArray[j].strResourceID.c_str(),	pGData->m_SubGeographicalRegionArray[i].strParentTag.c_str()) == 0)
			{
				strcpy(pBlock->m_SubcontrolAreaArray[pBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szCompany, pGData->m_GeographicalRegionArray[j].strName.c_str());
				break;
			}
		}
		pBlock->m_nRecordNum[PG_SUBCONTROLAREA]++;
	}

	memset(&pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]], 0, sizeof(tagPGTapChanger));
	strcpy(pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]].szName, "�ֽ�ͷ00");
	pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]].nTapMin=0;
	pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]].nTapMax=0;
	pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]].nTapNom=0;
	pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]].nTapNeu=0;
	pBlock->m_TapChangerArray[pBlock->m_nRecordNum[PG_TAPCHANGER]].fTapStep=0;
	pBlock->m_nRecordNum[PG_TAPCHANGER]++;
}

void CGISData2PGMemDB::InsertSubstation(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	int		nSub, nVolt;

	for (nSub=0; nSub<(int)pGData->m_SubstationArray.size(); nSub++)
	{
		memset(&pBlock->m_SubstationArray[pBlock->m_nRecordNum[PG_SUBSTATION]], 0, sizeof(tagPGSubstation));
		strcpy(pBlock->m_SubstationArray[pBlock->m_nRecordNum[PG_SUBSTATION]].szResID,		pGData->m_SubstationArray[nSub].strResourceID.c_str());
		strcpy(pBlock->m_SubstationArray[pBlock->m_nRecordNum[PG_SUBSTATION]].szName,		pGData->m_SubstationArray[nSub].strName.c_str());
		if (!pGData->m_SubstationArray[nSub].strParentTag.empty())
		{
			strcpy(pBlock->m_SubstationArray[pBlock->m_nRecordNum[PG_SUBSTATION]].szSubcontrolArea,	pGData->GetSubGeographicalRegionName(pGData->m_SubstationArray[nSub].strParentTag.c_str()).c_str());
			for (i=0; i<(int)pGData->m_SubGeographicalRegionArray.size(); i++)
			{
				if (strcmp(pGData->m_SubGeographicalRegionArray[i].strResourceID.c_str(),	pGData->m_SubstationArray[nSub].strParentTag.c_str()) == 0)
				{
					strcpy(pBlock->m_SubstationArray[pBlock->m_nRecordNum[PG_SUBSTATION]].szCompany,	pGData->GetGeographicalRegionName(pGData->m_SubGeographicalRegionArray[i].strParentTag.c_str()).c_str());
					break;
				}
			}
		}
		pBlock->m_nRecordNum[PG_SUBSTATION]++;

		for (nVolt=0; nVolt<(int)pGData->m_Sub2EquipmentArray[nSub].strVoltTagArray.size(); nVolt++)
		{
			memset(&pBlock->m_VoltageLevelArray[pBlock->m_nRecordNum[PG_VOLTAGELEVEL]], 0, sizeof(tagPGVoltageLevel));
			strcpy(pBlock->m_VoltageLevelArray[pBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szSub,	pGData->m_SubstationArray[nSub].strName.c_str());
			strcpy(pBlock->m_VoltageLevelArray[pBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szName,	GetVoltageName(pGData, pGData->m_Sub2EquipmentArray[nSub].strVoltTagArray[nVolt].c_str()));
// 			for (i=0; i<CADVoltageLevel::g_nCADVoltageLevelNum; i++)
// 			{
// 				if (stricmp(CADVoltageLevel::GetCADVoltageLevelName(i), pBlock->m_VoltageLevelArray[pBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szName) == 0)
// 				{
// 					pBlock->m_VoltageLevelArray[pBlock->m_nRecordNum[PG_VOLTAGELEVEL]].nominalVoltage=(float)CADVoltageLevel::GetCADVoltageLevelNorminal(i);
// 					break;
// 				}
// 			}
			pBlock->m_nRecordNum[PG_VOLTAGELEVEL]++;
		}
	}
}

void CGISData2PGMemDB::InsertBusbarSection(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	float	fVolt;
	int		nDev;
	for (nDev=0; nDev<(int)pGData->m_BusbarSectionArray.size(); nDev++)
	{
		memset(&pBlock->m_BusbarSectionArray[pBlock->m_nRecordNum[PG_BUSBARSECTION]], 0, sizeof(tagPGBusbarSection));
		strcpy(pBlock->m_BusbarSectionArray[pBlock->m_nRecordNum[PG_BUSBARSECTION]].szResID,	pGData->m_BusbarSectionArray[nDev].strResourceID.c_str());
		strcpy(pBlock->m_BusbarSectionArray[pBlock->m_nRecordNum[PG_BUSBARSECTION]].szSub,		pGData->m_BusbarSectionArray[nDev].strParent.c_str());
		strcpy(pBlock->m_BusbarSectionArray[pBlock->m_nRecordNum[PG_BUSBARSECTION]].szVolt,		GetVoltageName(pGData, pGData->m_BusbarSectionArray[nDev].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_BusbarSectionArray[pBlock->m_nRecordNum[PG_BUSBARSECTION]].szName,		pGData->m_BusbarSectionArray[nDev].strName.c_str());
		strcpy(pBlock->m_BusbarSectionArray[pBlock->m_nRecordNum[PG_BUSBARSECTION]].szNode,		pGData->m_BusbarSectionArray[nDev].strNode.c_str());
		pBlock->m_nRecordNum[PG_BUSBARSECTION]++;

		fVolt=0;
		for (i=0; i<(int)pGData->m_BaseVoltageArray.size(); i++)
		{
			if (stricmp(pGData->m_BaseVoltageArray[i].strResourceID.c_str(), pGData->m_BusbarSectionArray[nDev].strBaseVoltageTag.c_str()) == 0)
			{
				fVolt=pGData->m_BaseVoltageArray[i].fNominalVoltage;
				break;
			}
		}
		if (fVolt < 50)
		{
			memset(&pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGTransformerWinding));
			strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID,	pGData->m_BusbarSectionArray[nDev].strResourceID.c_str());
			strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName,	pGData->m_BusbarSectionArray[nDev].strName.c_str());
			strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub,	pGData->m_BusbarSectionArray[nDev].strParent.c_str());
			strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt,	GetVoltageName(pGData, pGData->m_BusbarSectionArray[nDev].strBaseVoltageTag.c_str()));
			strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode,	pGData->m_BusbarSectionArray[nDev].strNode.c_str());
			pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].fPlanP=0.1f;
			pBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;
		}
	}
}

void CGISData2PGMemDB::InsertCompensator(tagPGBlock* pBlock, CGISData* pGData)
{
	int		nDev;
	for (nDev=0; nDev<(int)pGData->m_CapacitorArray.size(); nDev++)
	{
		memset(&pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]], 0, sizeof(tagPGShuntCompensator));
		strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szResID,	pGData->m_CapacitorArray[nDev].strResourceID.c_str());
		strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szSub,	pGData->m_CapacitorArray[nDev].strParent.c_str());
		strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szVolt,	GetVoltageName(pGData, pGData->m_CapacitorArray[nDev].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName,	pGData->m_CapacitorArray[nDev].strName.c_str());
		strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szNode,	pGData->m_CapacitorArray[nDev].strNode.c_str());
		pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]++;
	}

	for (nDev=0; nDev<(int)pGData->m_CompensatorArray.size(); nDev++)
	{
		if (pGData->m_CompensatorArray[nDev].strSeriesNode.empty())
		{
			memset(&pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]], 0, sizeof(tagPGShuntCompensator));
			strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szResID,	pGData->m_CompensatorArray[nDev].strResourceID.c_str());
			strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szSub,	pGData->m_CompensatorArray[nDev].strParent.c_str());
			strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szVolt,	GetVoltageName(pGData, pGData->m_CompensatorArray[nDev].strBaseVoltageTag.c_str()));
			strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName,	pGData->m_CompensatorArray[nDev].strName.c_str());
			strcpy(pBlock->m_ShuntCompensatorArray[pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szNode,	pGData->m_CompensatorArray[nDev].strNode.c_str());
			pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]++;
		}
		else
		{
			memset(&pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]], 0, sizeof(tagPGSeriesCompensator));
			strcpy(pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szResID,	pGData->m_CompensatorArray[nDev].strResourceID.c_str());
			strcpy(pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szSub,		pGData->m_CompensatorArray[nDev].strParent.c_str());
			strcpy(pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szVolt,		GetVoltageName(pGData, pGData->m_CompensatorArray[nDev].strBaseVoltageTag.c_str()));
			strcpy(pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szName,		pGData->m_CompensatorArray[nDev].strName.c_str());
			strcpy(pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szNodeI,	pGData->m_CompensatorArray[nDev].strNode.c_str());
			strcpy(pBlock->m_SeriesCompensatorArray[pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szNodeJ,	pGData->m_CompensatorArray[nDev].strSeriesNode.c_str());
			pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]++;
		}
	}
}

void CGISData2PGMemDB::InsertACLineSegment(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	double	fVoltageLevel;
	double	fBase;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	for (i=0; i<(int)pGData->m_ACLineSegmentArray.size(); i++)
	{
		if (!ResolveACLineSegmentField(pGData, i, szField))
			continue;

		if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ACLINESEGMENT, szField))
			Log(g_lpszLogFile, "�޷�������·: (%s)\n", pGData->m_ACLineSegmentArray[i].strName.c_str());

		fVoltageLevel=GetVoltageNorminal(pGData, pGData->m_ACLineSegmentArray[i].strBaseVoltageTag.c_str());
		if (fVoltageLevel <= 0)
			continue;
		fBase=pBlock->m_System.fBasePower/(fVoltageLevel*fVoltageLevel);

		memset(&pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]], 0, sizeof(tagPGACLineSegment));
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szResID,	pGData->m_ACLineSegmentArray[i].strResourceID.c_str());
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szName,		pGData->m_ACLineSegmentArray[i].strName.c_str());
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubI,		pGData->m_SubstationArray[pGData->m_ACLineSegmentArray[i].nSubI].strName.c_str());
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubJ,		pGData->m_SubstationArray[pGData->m_ACLineSegmentArray[i].nSubZ].strName.c_str());
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltI,	GetVoltageName(pGData, pGData->m_ACLineSegmentArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltJ,	GetVoltageName(pGData, pGData->m_ACLineSegmentArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeI,	pGData->m_ACLineSegmentArray[i].strNodeI.c_str());
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeJ,	pGData->m_ACLineSegmentArray[i].strNodeZ.c_str());
		strcpy(pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].szLineModel, pGData->m_ACLineSegmentArray[i].strAssetModel.c_str());
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].fLength			=pGData->m_ACLineSegmentArray[i].fLength;
		if (pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].fLength < FLT_MIN)	pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].fLength=1;

		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_UnitRerr		=pGData->m_ACLineSegmentArray[i].ri_UnitRerr	;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_UnitTrep		=pGData->m_ACLineSegmentArray[i].ri_UnitTrep	;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_UnitRchk		=pGData->m_ACLineSegmentArray[i].ri_UnitRchk	;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_UnitTchk		=pGData->m_ACLineSegmentArray[i].ri_UnitTchk	;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ei_UnitInvest		=pGData->m_ACLineSegmentArray[i].ei_UnitInvest	;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Rerr			=pGData->m_ACLineSegmentArray[i].ri_Rerr		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Trep			=pGData->m_ACLineSegmentArray[i].ri_Trep		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Rchk			=pGData->m_ACLineSegmentArray[i].ri_Rchk		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Tchk			=pGData->m_ACLineSegmentArray[i].ri_Tchk		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Tfloc			=pGData->m_ACLineSegmentArray[i].ri_Tfloc		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_RSwitch			=pGData->m_ACLineSegmentArray[i].ri_RSwitch		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_TSwitch			=pGData->m_ACLineSegmentArray[i].ri_TSwitch		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_TDelay			=pGData->m_ACLineSegmentArray[i].ri_TDelay		;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ri_Customer		=pGData->m_ACLineSegmentArray[i].ri_Customer	;
		pBlock->m_ACLineSegmentArray[pBlock->m_nRecordNum[PG_ACLINESEGMENT]].ei_Invest			=pGData->m_ACLineSegmentArray[i].ei_Invest		;
		pBlock->m_nRecordNum[PG_ACLINESEGMENT]++;							 		
	}
}

void CGISData2PGMemDB::InsertPowerTransformer(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (i=0; i<(int)pGData->m_PowerTransformerArray.size(); i++)
	{
		if (pGData->m_PowerTransformerArray[i].nWindNum == 1)
		{
			if (!ResolveDistributionTransformerField(pGData, i, szField))
				continue;
			if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DISTRIBUTIONLOAD, szField))
			{
				Log(g_lpszLogFile, "�޷������ѹ��: (%s)\n", pGData->m_PowerTransformerArray[i].strName.c_str());
			}
			else
			{
				memset(&pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGTransformerWinding));
				strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID,	pGData->m_PowerTransformerArray[i].strResourceID.c_str());
				strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName,	pGData->m_PowerTransformerArray[i].strName.c_str());
				strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub,	pGData->m_PowerTransformerArray[i].strParent.c_str());
				strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[0].c_str()));
				strcpy(pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode,	pGData->m_PowerTransformerArray[i].strNodeArray[0].c_str());
				pBlock->m_EnergyConsumerArray[pBlock->m_nRecordNum[PG_ENERGYCONSUMER]].fPlanP=0.1f;

				pBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;
			}
		}
		else if (pGData->m_PowerTransformerArray[i].nWindNum == 2)
		{
			memset(&pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szResID,	pGData->m_PowerTransformerArray[i].strResourceID.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName,	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub,	pGData->m_PowerTransformerArray[i].strParent.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[0].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[1].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI,	pGData->m_PowerTransformerArray[i].strNodeArray[0].c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ,	pGData->m_PowerTransformerArray[i].strNodeArray[1].c_str());

			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Rerr				=pGData->m_PowerTransformerArray[i].ri_Rerr		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Trep				=pGData->m_PowerTransformerArray[i].ri_Trep		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Rchk				=pGData->m_PowerTransformerArray[i].ri_Rchk		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Tchk				=pGData->m_PowerTransformerArray[i].ri_Tchk		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Tfloc				=pGData->m_PowerTransformerArray[i].ri_Tfloc		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_RSwitch			=pGData->m_PowerTransformerArray[i].ri_RSwitch		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_TSwitch			=pGData->m_PowerTransformerArray[i].ri_TSwitch		;
			pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;
		}
		else if (pGData->m_PowerTransformerArray[i].nWindNum == 3)
		{
			memset(&pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szResID,	pGData->m_PowerTransformerArray[i].strResourceID.c_str());
			sprintf(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName, "%s_H",	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer,	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub,	pGData->m_PowerTransformerArray[i].strParent.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[0].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[2].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI,	pGData->m_PowerTransformerArray[i].strNodeArray[0].c_str());
			sprintf(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, "%s_T",	pGData->m_PowerTransformerArray[i].strName.c_str());
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Rerr			=pGData->m_PowerTransformerArray[i].ri_Rerr		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Trep			=pGData->m_PowerTransformerArray[i].ri_Trep		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Rchk			=pGData->m_PowerTransformerArray[i].ri_Rchk		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Tchk			=pGData->m_PowerTransformerArray[i].ri_Tchk		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_Tfloc			=pGData->m_PowerTransformerArray[i].ri_Tfloc		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_RSwitch		=pGData->m_PowerTransformerArray[i].ri_RSwitch		;
			pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].ri_TSwitch		=pGData->m_PowerTransformerArray[i].ri_TSwitch		;
			pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;

			memset(&pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szResID,	pGData->m_PowerTransformerArray[i].strResourceID.c_str());
			sprintf(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName, "%s_M",	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer,	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub,	pGData->m_PowerTransformerArray[i].strParent.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[1].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[2].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI,	pGData->m_PowerTransformerArray[i].strNodeArray[1].c_str());
			sprintf(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, "%s_T",	pGData->m_PowerTransformerArray[i].strName.c_str());
			pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;

			memset(&pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szResID,	pGData->m_PowerTransformerArray[i].strResourceID.c_str());
			sprintf(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName, "%s_L",	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer,	pGData->m_PowerTransformerArray[i].strName.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub,	pGData->m_PowerTransformerArray[i].strParent.c_str());
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[2].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ,	GetVoltageName(pGData, pGData->m_PowerTransformerArray[i].strVoltTagArray[2].c_str()));
			strcpy(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI,	pGData->m_PowerTransformerArray[i].strNodeArray[2].c_str());
			sprintf(pBlock->m_TransformerWindingArray[pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, "%s_T",	pGData->m_PowerTransformerArray[i].strName.c_str());
			pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;
		}
	}
}

void CGISData2PGMemDB::InsertBreakDisconnector(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<(int)pGData->m_BreakerArray.size(); i++)
	{
		memset(&pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]], 0, sizeof(tagPGBreaker));
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szResID,	pGData->m_BreakerArray[i].strResourceID.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szSub,		pGData->m_BreakerArray[i].strParent.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szVolt,		GetVoltageName(pGData, pGData->m_BreakerArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szName,		pGData->m_BreakerArray[i].strName.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szNodeI,	pGData->m_BreakerArray[i].strNodeI.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szNodeJ,	pGData->m_BreakerArray[i].strNodeZ.c_str());
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].nCategory=PGEnumBreakerType_Breaker;

		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Rerr	=pGData->m_BreakerArray[i].ri_Rerr;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Trep	=pGData->m_BreakerArray[i].ri_Trep;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Rchk	=pGData->m_BreakerArray[i].ri_Rchk;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Tchk	=pGData->m_BreakerArray[i].ri_Tchk;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Tfloc	=pGData->m_BreakerArray[i].ri_Tfloc;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_RSwitch	=pGData->m_BreakerArray[i].ri_RSwitch;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_TSwitch	=pGData->m_BreakerArray[i].ri_TSwitch;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ei_Invest	=pGData->m_BreakerArray[i].ei_Invest;

		pBlock->m_nRecordNum[PG_BREAKER]++;
	}

	for (i=0; i<(int)pGData->m_DisconnectorArray.size(); i++)
	{
		memset(&pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]], 0, sizeof(tagPGDisconnector));
		strcpy(pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].szResID,	pGData->m_DisconnectorArray[i].strResourceID.c_str());
		strcpy(pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].szSub,	pGData->m_DisconnectorArray[i].strParent.c_str());
		strcpy(pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].szVolt,	GetVoltageName(pGData, pGData->m_DisconnectorArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].szName,	pGData->m_DisconnectorArray[i].strName.c_str());
		strcpy(pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].szNodeI,	pGData->m_DisconnectorArray[i].strNodeI.c_str());
		strcpy(pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].szNodeJ,	pGData->m_DisconnectorArray[i].strNodeZ.c_str());
		pBlock->m_DisconnectorArray[pBlock->m_nRecordNum[PG_DISCONNECTOR]].nCategory=PGEnumDisconnectorType_Disconnector;
		pBlock->m_nRecordNum[PG_DISCONNECTOR]++;
	}

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	for (i=0; i<(int)pGData->m_LoadBreakSwitchArray.size(); i++)
	{
		if (!ResolveLoadBreakSwitchField(pGData, i, szField))
			continue;

		if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DISTRIBUTIONBREAKER, szField))
		{
			Log(g_lpszLogFile, "�޷����븺�ɿ���: (%s)\n", pGData->m_LoadBreakSwitchArray[i].strName.c_str());
			continue;
		}

		memset(&pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]], 0, sizeof(tagPGBreaker));
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szResID,	pGData->m_LoadBreakSwitchArray[i].strResourceID.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szSub,		pGData->m_LoadBreakSwitchArray[i].strParent.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szVolt,		GetVoltageName(pGData, pGData->m_LoadBreakSwitchArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szName,		pGData->m_LoadBreakSwitchArray[i].strName.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szNodeI,	pGData->m_LoadBreakSwitchArray[i].strNodeI.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szNodeJ,	pGData->m_LoadBreakSwitchArray[i].strNodeZ.c_str());
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].nCategory=PGEnumBreakerType_LoadBreakSwitch;

		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Rerr	=pGData->m_BreakerArray[i].ri_Rerr;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Trep	=pGData->m_BreakerArray[i].ri_Trep;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Rchk	=pGData->m_BreakerArray[i].ri_Rchk;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Tchk	=pGData->m_BreakerArray[i].ri_Tchk;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Tfloc	=pGData->m_BreakerArray[i].ri_Tfloc;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_RSwitch	=pGData->m_BreakerArray[i].ri_RSwitch;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_TSwitch	=pGData->m_BreakerArray[i].ri_TSwitch;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ei_Invest	=pGData->m_BreakerArray[i].ei_Invest;
		pBlock->m_nRecordNum[PG_BREAKER]++;
	}

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	for (i=0; i<(int)pGData->m_FuseArray.size(); i++)
	{
		if (!ResolveFuseField(pGData, i, szField))
			continue;

		if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DISTRIBUTIONBREAKER, szField))
		{
			Log(g_lpszLogFile, "�޷������۶���: (%s)\n", pGData->m_FuseArray[i].strName.c_str());
			continue;
		}

		memset(&pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]], 0, sizeof(tagPGBreaker));
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szResID,	pGData->m_FuseArray[i].strResourceID.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szSub,		pGData->m_FuseArray[i].strParent.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szVolt,		GetVoltageName(pGData, pGData->m_FuseArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szName,		pGData->m_FuseArray[i].strName.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szNodeI,	pGData->m_FuseArray[i].strNodeI.c_str());
		strcpy(pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].szNodeJ,	pGData->m_FuseArray[i].strNodeZ.c_str());
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].nCategory=PGEnumBreakerType_FuseBreaker;

		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Rerr	=pGData->m_BreakerArray[i].ri_Rerr;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Trep	=pGData->m_BreakerArray[i].ri_Trep;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Rchk	=pGData->m_BreakerArray[i].ri_Rchk;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Tchk	=pGData->m_BreakerArray[i].ri_Tchk;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_Tfloc	=pGData->m_BreakerArray[i].ri_Tfloc;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_RSwitch	=pGData->m_BreakerArray[i].ri_RSwitch;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ri_TSwitch	=pGData->m_BreakerArray[i].ri_TSwitch;
		pBlock->m_BreakerArray[pBlock->m_nRecordNum[PG_BREAKER]].ei_Invest	=pGData->m_BreakerArray[i].ei_Invest;
		pBlock->m_nRecordNum[PG_BREAKER]++;
	}

	for (i=0; i<(int)pGData->m_GroundDisconnectorArray.size(); i++)
	{
		memset(&pBlock->m_GroundDisconnectorArray[pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]], 0, sizeof(tagPGGroundDisconnector));
		strcpy(pBlock->m_GroundDisconnectorArray[pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szResID,	pGData->m_GroundDisconnectorArray[i].strResourceID.c_str());
		strcpy(pBlock->m_GroundDisconnectorArray[pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szSub,	pGData->m_GroundDisconnectorArray[i].strParent.c_str());
		strcpy(pBlock->m_GroundDisconnectorArray[pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szVolt,	GetVoltageName(pGData, pGData->m_GroundDisconnectorArray[i].strBaseVoltageTag.c_str()));
		strcpy(pBlock->m_GroundDisconnectorArray[pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szName,	pGData->m_GroundDisconnectorArray[i].strName.c_str());
		strcpy(pBlock->m_GroundDisconnectorArray[pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szNode,	pGData->m_GroundDisconnectorArray[i].strNode.c_str());
		pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]++;
	}
}

void CGISData2PGMemDB::InsertPole(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	for (i=0; i<(int)pGData->m_PoleArray.size(); i++)
	{
		if (!ResolvePoleField(pGData, i, szField))
			continue;

		if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DISTRIBUTIONDOT, szField))
			Log(g_lpszLogFile, "�޷��������: (%s)\n", pGData->m_PoleArray[i].strName.c_str());
	}

	for (i=0; i<(int)pGData->m_JunctionArray.size(); i++)
	{
		if (!ResolveJunctionField(pGData, i, szField))
			continue;

		if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DISTRIBUTIONDOT, szField))
			Log(g_lpszLogFile, "�޷���������ն�: (%s)\n", pGData->m_JunctionArray[i].strName.c_str());
	}
}

void CGISData2PGMemDB::InsertPipe(tagPGBlock* pBlock, CGISData* pGData)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	for (i=0; i<(int)pGData->m_PipeArray.size(); i++)
	{
		if (!ResolvePipeField(pGData, i, szField))
			continue;

		if (!PGAppendRecord(pBlock, MDB_NeedCheckData, PG_PIPE, szField))
			Log(g_lpszLogFile, "�޷�����ܹ�: (%s)\n", pGData->m_PipeArray[i].strName.c_str());
	}
}

void	CGISData2PGMemDB::ReviseACLineSegmentName(const char* lpszNameIn, char* lpszNameOut)
{
	register int	i;
	int			nSplit;
	char		szBuf[260];
	char*		lpszToken;
	std::string	strBuf;
	std::vector<std::string>	strSplitArray;

	strSplitArray.clear();
	strcpy(szBuf, lpszNameIn);
	lpszToken=strtok(szBuf, "-");
	while (lpszToken != NULL)
	{
		strSplitArray.push_back(lpszToken);
		lpszToken=strtok(NULL, "-");
	}

	if (strSplitArray.empty())
	{
		strcpy(lpszNameOut, lpszNameIn);
		return;
	}

	for (nSplit=1; nSplit<(int)strSplitArray.size(); nSplit++)
	{
		i=0;
		while (i < (int)strSplitArray[0].length() && !strSplitArray[nSplit].empty())
		{
			if (isascii(strSplitArray[0][i]))
			{
				if (strSplitArray[0][i] == strSplitArray[nSplit][0])
					strSplitArray[nSplit].erase(0, 1);
				else
					break;
				i++;
			}
			else
			{
				if (strSplitArray[0][i] == strSplitArray[nSplit][0] && strSplitArray[0][i+1] == strSplitArray[nSplit][1])
					strSplitArray[nSplit].erase(0, 2);
				else
					break;
				i += 2;
			}
		}
	}

	for (nSplit=0; nSplit<(int)strSplitArray.size(); nSplit++)
	{
		if (nSplit != 0)
			strBuf.append("-");
		strBuf.append(strSplitArray[nSplit]);
	}

	if (strBuf.length() >= MDB_CHARLEN-2)
		strncpy(lpszNameOut, strBuf.c_str(), MDB_CHARLEN-2);
	else
		strcpy(lpszNameOut, strBuf.c_str());
}

int CGISData2PGMemDB::ResolveSubstationEntityField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	register int	i;
	std::vector<int>	nSubBusArray;
	int			nLoad;
	float		fFactor, fLoadP, fLoadQ, fCustnumNum;

	nSubBusArray.clear();
	for (i=0; i<(int)pGData->m_BusbarSectionArray.size(); i++)
	{
		if (strcmp(pGData->m_BusbarSectionArray[i].strParentTag.c_str(), pGData->m_SubstationArray[nRecord].strResourceID.c_str()) == 0)
			nSubBusArray.push_back(i);
	}
	if (nSubBusArray.empty())
	{
		Log(g_lpszLogFile, "��վ����[%s]û��ĸ�ߣ��޷���������\n", pGData->m_SubstationArray[nRecord].strName.c_str());
		return 0;
	}

	fLoadP=fLoadQ=fCustnumNum=0;
	for (i=0; i<(int)nSubBusArray.size(); i++)
	{
		for (nLoad=0; nLoad<(int)pGData->m_EnergyConsumerArray.size(); nLoad++)
		{
			if (pGData->m_EnergyConsumerArray[nLoad].nBelongPSRType == GIS_BusbarSection && strcmp(pGData->m_EnergyConsumerArray[nLoad].strBelongPSRTag.c_str(), pGData->m_BusbarSectionArray[nSubBusArray[i]].strResourceID.c_str()) == 0)
			{
				fLoadP += pGData->m_EnergyConsumerArray[nLoad].fP;
				fLoadQ += pGData->m_EnergyConsumerArray[nLoad].fQ;
				fCustnumNum += pGData->m_EnergyConsumerArray[nLoad].fCustomNum;
			}
		}
	}
	fFactor=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
	if (fFactor > FLT_MIN)
		fFactor = fLoadP/fFactor;
	else
		fFactor=0.95f;

	if (strcmp(pGData->GetPSRTypeName(pGData->m_SubstationArray[nRecord].strPSRTypeTag.c_str()).c_str(), "���-���վ") == 0)
	{
		strcpy(szField[PG_SUBSTATIONENTITY_RESOURCEID],				pGData->m_SubstationArray[nRecord].strResourceID.c_str());
		strcpy(szField[PG_SUBSTATIONENTITY_NAME],					pGData->m_SubstationArray[nRecord].strName.c_str());
		strcpy(szField[PG_SUBSTATIONENTITY_VOLTAGELEVEL],			GetVoltageName(pGData, pGData->m_BusbarSectionArray[nSubBusArray[0]].strBaseVoltageTag.c_str()));

		sprintf(szField[PG_SUBSTATIONENTITY_SUBSTATIONTYPE], "%d",	(int)PGEnumst_type_Distribution);

		sprintf(szField[PG_SUBSTATIONENTITY_LOADP], "%f", fLoadP);
		sprintf(szField[PG_SUBSTATIONENTITY_LOADFACTOR], "%f", fFactor);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_CUSTOMER], "%f", fCustnumNum);

		strcpy(szField[PG_SUBSTATIONENTITY_COMPONENT], pGData->m_SubstationArray[nRecord].strComponent.c_str());
		strcpy(szField[PG_SUBSTATIONENTITY_HIGHVOLTAGELEVEL], GetVoltageName(pGData, pGData->m_SubstationArray[nRecord].strHighVoltage.c_str()));
		sprintf(szField[PG_SUBSTATIONENTITY_MVACAPACITY],	"%f",	pGData->m_SubstationArray[nRecord].fMvaCapacity);
		sprintf(szField[PG_SUBSTATIONENTITY_EQX1],			"%f",	pGData->m_SubstationArray[nRecord].fEqX);
		sprintf(szField[PG_SUBSTATIONENTITY_EQX0],			"%f",	pGData->m_SubstationArray[nRecord].fEqX			);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_RERR],		"%f",	pGData->m_SubstationArray[nRecord].ri_Rerr		);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_TREP],		"%f",	pGData->m_SubstationArray[nRecord].ri_Trep		);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_RCHK],		"%f",	pGData->m_SubstationArray[nRecord].ri_Rchk		);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_TCHK],		"%f",	pGData->m_SubstationArray[nRecord].ri_Tchk		);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_TFLOC],		"%f",	pGData->m_SubstationArray[nRecord].ri_Tfloc		);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_CUSTOMER],	"%f",	pGData->m_SubstationArray[nRecord].ri_Customer	);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_LOAD_RERR],	"%f",	pGData->m_SubstationArray[nRecord].ri_load_rerr	);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_LOAD_TREP],	"%f",	pGData->m_SubstationArray[nRecord].ri_load_trep	);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_LOAD_RCHK],	"%f",	pGData->m_SubstationArray[nRecord].ri_load_rchk	);
		sprintf(szField[PG_SUBSTATIONENTITY_RI_LOAD_TCHK],	"%f",	pGData->m_SubstationArray[nRecord].ri_load_tchk	);
		sprintf(szField[PG_SUBSTATIONENTITY_EI_INVEST],		"%f",	pGData->m_SubstationArray[nRecord].ei_Invest	);
		sprintf(szField[PG_SUBSTATIONENTITY_TOTALBAY],		"%d",	pGData->m_SubstationArray[nRecord].nTotalBay);
		sprintf(szField[PG_SUBSTATIONENTITY_FREEBAY],		"%d",	pGData->m_SubstationArray[nRecord].nFreeBay);
		sprintf(szField[PG_SUBSTATIONENTITY_TOTALOUTLINE],	"%d",	pGData->m_SubstationArray[nRecord].nTotalOutline);
		sprintf(szField[PG_SUBSTATIONENTITY_INUSEOUTLINE],	"%d",	pGData->m_SubstationArray[nRecord].nInuseOutline);

		strcpy(szField[PG_SUBSTATIONENTITY_CONNECTIVITYNODE],	pGData->m_BusbarSectionArray[nSubBusArray[0]].strNode.c_str());

		return PG_SUBSTATIONENTITY;
	}
	else
	{
// 		if (nSubBusArray.size() > 1)
// 		{
// 			sprintf(szField[PG_DISTRIBUTIONSWITCH_BUSBARMODE], "%d", PGEnumSwitch_BusbarmodeType_TwoBus);
// 			for (i=0; i<(int)pGData->m_BreakerArray.size(); i++)
// 			{
// 				if (stricmp(pGData->m_BreakerArray[i].strParentTag.c_str(), pGData->m_SubstationArray[nRecord].strResourceID.c_str()) == 0)
// 				{
// 					sprintf(szField[PG_DISTRIBUTIONSWITCH_BUSLINKSTATUS], "%d", pGData->m_BreakerArray[i].nStatus);
// 					break;
// 				}
// 			}
// 		}
// 		else
// 		{
// 			sprintf(szField[PG_DISTRIBUTIONSWITCH_BUSBARMODE], "%d", PGEnumSwitch_BusbarmodeType_OneBus);
// 		}
		strcpy(szField[PG_DISTRIBUTIONSWITCH_CONNECTIVITYNODE],	pGData->m_BusbarSectionArray[nSubBusArray[0]].strNode.c_str());

		strcpy(szField[PG_DISTRIBUTIONSWITCH_RESOURCEID],		pGData->m_SubstationArray[nRecord].strResourceID.c_str());
		strcpy(szField[PG_DISTRIBUTIONSWITCH_NAME],			pGData->m_SubstationArray[nRecord].strName.c_str());
		strcpy(szField[PG_DISTRIBUTIONSWITCH_VOLTAGELEVEL],	GetVoltageName(pGData, pGData->m_BusbarSectionArray[nSubBusArray[0]].strBaseVoltageTag.c_str()));

		sprintf(szField[PG_DISTRIBUTIONSWITCH_TYPE], "%d",	(int)PGEnumSwitchType_SwitchStation);
		if (strcmp(pGData->GetPSRTypeName(pGData->m_SubstationArray[nRecord].strPSRTypeTag.c_str()).c_str(), "���-������") == 0)
			sprintf(szField[PG_DISTRIBUTIONSWITCH_TYPE], "%d",	(int)PGEnumSwitchType_SwitchStation);
		else if (strcmp(pGData->GetPSRTypeName(pGData->m_SubstationArray[nRecord].strPSRTypeTag.c_str()).c_str(), "���-������") == 0)
			sprintf(szField[PG_DISTRIBUTIONSWITCH_TYPE], "%d",	(int)PGEnumSwitchType_SwitchGearCupBoard);
		else if (strcmp(pGData->GetPSRTypeName(pGData->m_SubstationArray[nRecord].strPSRTypeTag.c_str()).c_str(), "���-���·�֧��") == 0)
			sprintf(szField[PG_DISTRIBUTIONSWITCH_TYPE], "%d",	(int)PGEnumSwitchType_CableBranchBox);

		sprintf(szField[PG_DISTRIBUTIONSWITCH_LOADP], "%f", fLoadP);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_LOADFACTOR], "%f", fFactor);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_CUSTOMER], "%f", fCustnumNum);

		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_RERR],		"%f",	pGData->m_SubstationArray[nRecord].ri_Rerr		);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_TREP],		"%f",	pGData->m_SubstationArray[nRecord].ri_Trep		);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_RCHK],		"%f",	pGData->m_SubstationArray[nRecord].ri_Rchk		);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_TCHK],		"%f",	pGData->m_SubstationArray[nRecord].ri_Tchk		);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_TFLOC],	"%f",	pGData->m_SubstationArray[nRecord].ri_Tfloc		);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_CUSTOMER],	"%f",	pGData->m_SubstationArray[nRecord].ri_Customer	);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_LOAD_RERR], "%f",	pGData->m_SubstationArray[nRecord].ri_load_rerr	);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_LOAD_TREP], "%f",	pGData->m_SubstationArray[nRecord].ri_load_trep	);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_LOAD_RCHK], "%f",	pGData->m_SubstationArray[nRecord].ri_load_rchk	);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_RI_LOAD_TCHK], "%f",	pGData->m_SubstationArray[nRecord].ri_load_tchk	);
		sprintf(szField[PG_DISTRIBUTIONSWITCH_EI_INVEST],	"%f",	pGData->m_SubstationArray[nRecord].ei_Invest	);

		strcpy(szField[PG_DISTRIBUTIONSWITCH_MODEL], pGData->m_SubstationArray[nRecord].strModel.c_str());

		strcpy(szField[PG_DISTRIBUTIONSWITCH_CONNECTIVITYNODE],	pGData->m_BusbarSectionArray[nSubBusArray[0]].strNode.c_str());	//pGData->m_SubstationArray[nRecord].strNode.c_str());

		return PG_DISTRIBUTIONSWITCH;
	}
	return 0;
}

int CGISData2PGMemDB::ResolveACLineSegmentField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	register int	i;
	int			nNode;
	std::vector<int>	nNodeArray;
	unsigned char	bFind, nBusBarID, nStatus;
	std::vector<int>	nSubBusArray;

	if (pGData->m_ACLineSegmentArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�������·, �޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_ACLineSegmentArray[nRecord].strName.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeI.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_ACLineSegmentArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�������·, �޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_ACLineSegmentArray[nRecord].strName.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeI.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_ACLineSegmentArray[nRecord].nNodeI < 0)
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�������·, �޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_ACLineSegmentArray[nRecord].strName.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeI.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_ACLineSegmentArray[nRecord].nNodeZ < 0)
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�������·, �޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_ACLineSegmentArray[nRecord].strName.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeI.c_str(), pGData->m_ACLineSegmentArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}

	//fBase=fBasePower/(m_BaseVoltageArray[nVolt].fNominalVoltage*m_BaseVoltageArray[nVolt].fNominalVoltage);

	strcpy(szField[PG_ACLINESEGMENT_RESOURCEID],			pGData->m_ACLineSegmentArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_ACLINESEGMENT_DESC],					pGData->m_ACLineSegmentArray[nRecord].strObjectID.c_str());
	ReviseACLineSegmentName(pGData->m_ACLineSegmentArray[nRecord].strName.c_str(), szField[PG_ACLINESEGMENT_NAME]);
	strcpy(szField[PG_ACLINESEGMENT_IVOLTAGELEVEL],			GetVoltageName(pGData, pGData->m_ACLineSegmentArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_ACLINESEGMENT_JVOLTAGELEVEL],			GetVoltageName(pGData, pGData->m_ACLineSegmentArray[nRecord].strBaseVoltageTag.c_str()));
	if (!pGData->m_ACLineSegmentArray[nRecord].strFeeder.empty())	strcpy(szField[PG_ACLINESEGMENT_LINE],					pGData->m_ACLineSegmentArray[nRecord].strFeeder.c_str());

	strcpy(szField[PG_ACLINESEGMENT_ISUBSTATION],			pGData->m_SubstationArray[pGData->m_ACLineSegmentArray[nRecord].nSubI].strName.c_str());
	strcpy(szField[PG_ACLINESEGMENT_JSUBSTATION],			pGData->m_SubstationArray[pGData->m_ACLineSegmentArray[nRecord].nSubZ].strName.c_str());
	strcpy(szField[PG_ACLINESEGMENT_LINEMODEL],				pGData->m_ACLineSegmentArray[nRecord].strAssetModel.c_str());
	sprintf(szField[PG_ACLINESEGMENT_LENGTH], "%f",			pGData->m_ACLineSegmentArray[nRecord].fLength);
	sprintf(szField[PG_ACLINESEGMENT_AUTOLENGTH], "%d",		pGData->m_ACLineSegmentArray[nRecord].bAutoLength);

	strcpy(szField[PG_ACLINESEGMENT_CONNECTIVITYNODEI],		pGData->m_ACLineSegmentArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_ACLINESEGMENT_CONNECTIVITYNODEJ],		pGData->m_ACLineSegmentArray[nRecord].strNodeZ.c_str());

	sprintf(szField[PG_ACLINESEGMENT_RI_UNITRERR],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_UnitRerr	);
	sprintf(szField[PG_ACLINESEGMENT_RI_UNITTREP],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_UnitTrep	);
	sprintf(szField[PG_ACLINESEGMENT_RI_UNITRCHK],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_UnitRchk	);
	sprintf(szField[PG_ACLINESEGMENT_RI_UNITTCHK],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_UnitTchk	);
	sprintf(szField[PG_ACLINESEGMENT_EI_UNITINVEST],"%f",		pGData->m_ACLineSegmentArray[nRecord].ei_UnitInvest	);
	sprintf(szField[PG_ACLINESEGMENT_RI_RERR],		"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_Rerr		);
	sprintf(szField[PG_ACLINESEGMENT_RI_TREP],		"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_Trep		);
	sprintf(szField[PG_ACLINESEGMENT_RI_RCHK],		"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_Rchk		);
	sprintf(szField[PG_ACLINESEGMENT_RI_TCHK],		"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_Tchk		);
	sprintf(szField[PG_ACLINESEGMENT_RI_TFLOC],		"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_Tfloc		);
	sprintf(szField[PG_ACLINESEGMENT_RI_RSWITCH],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_RSwitch	);
	sprintf(szField[PG_ACLINESEGMENT_RI_TSWITCH],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_TSwitch	);
	sprintf(szField[PG_ACLINESEGMENT_RI_TDELAY],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_TDelay		);
	sprintf(szField[PG_ACLINESEGMENT_RI_CUSTOMER],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_Customer	);
	sprintf(szField[PG_ACLINESEGMENT_RI_LOAD_RERR],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_load_rerr	);
	sprintf(szField[PG_ACLINESEGMENT_RI_LOAD_TREP],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_load_trep	);
	sprintf(szField[PG_ACLINESEGMENT_RI_LOAD_RCHK],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_load_rchk	);
	sprintf(szField[PG_ACLINESEGMENT_RI_LOAD_TCHK],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ri_load_tchk	);
	sprintf(szField[PG_ACLINESEGMENT_EI_INVEST],	"%f",		pGData->m_ACLineSegmentArray[nRecord].ei_Invest	);

	pGData->TraverseNode(pGData->m_ACLineSegmentArray[nRecord].nNodeI, nNodeArray);
	if (pGData->m_ACLineSegmentArray[nRecord].nIJointEquipmentType == PG_SUBSTATIONENTITY || pGData->m_ACLineSegmentArray[nRecord].nIJointEquipmentType == PG_DISTRIBUTIONSWITCH)
	{
		nSubBusArray.clear();
		for (i=0; i<(int)pGData->m_BusbarSectionArray.size(); i++)
		{
			if (strcmp(pGData->m_BusbarSectionArray[i].strParentTag.c_str(), pGData->m_ACLineSegmentArray[nRecord].strIJointEquipmentTag.c_str()) == 0)
				nSubBusArray.push_back(i);
		}

		nBusBarID=nStatus=0;
		bFind=0;
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ISTATUS], "%d", pGData->m_BreakerArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ISTATUS], "%d", pGData->m_DisconnectorArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ISTATUS], "%d", pGData->m_LoadBreakSwitchArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ISTATUS], "%d", pGData->m_FuseArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}

		strcpy(szField[PG_ACLINESEGMENT_CONNECTIVITYNODEI],	pGData->m_ACLineSegmentArray[nRecord].strNodeI.c_str());
	}

	pGData->TraverseNode(pGData->m_ACLineSegmentArray[nRecord].nNodeZ, nNodeArray);
	if (pGData->m_ACLineSegmentArray[nRecord].nZJointEquipmentType == PG_SUBSTATIONENTITY || pGData->m_ACLineSegmentArray[nRecord].nZJointEquipmentType == PG_DISTRIBUTIONSWITCH)
	{
		nSubBusArray.clear();
		for (i=0; i<(int)pGData->m_BusbarSectionArray.size(); i++)
		{
			if (strcmp(pGData->m_BusbarSectionArray[i].strParentTag.c_str(), pGData->m_ACLineSegmentArray[nRecord].strZJointEquipmentTag.c_str()) == 0)
				nSubBusArray.push_back(i);
		}

		nBusBarID=0;

		bFind=0;
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ZSTATUS], "%d", pGData->m_BreakerArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ZSTATUS], "%d", pGData->m_DisconnectorArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ZSTATUS], "%d", pGData->m_LoadBreakSwitchArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}
		if (!bFind)
		{
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
				{
					sprintf(szField[PG_ACLINESEGMENT_ZSTATUS], "%d", pGData->m_FuseArray[pGData->m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].nStatus);
					bFind=1;
					break;
				}
				if (bFind)	break;
			}
		}

		strcpy(szField[PG_ACLINESEGMENT_CONNECTIVITYNODEJ],	pGData->m_ACLineSegmentArray[nRecord].strNodeZ.c_str());
	}

	sprintf(szField[PG_ACLINESEGMENT_LINETYPE], "%d", pGData->m_ACLineSegmentArray[nRecord].nLineType);
	if (!pGData->m_ACLineSegmentArray[nRecord].strLineType.empty())
	{
		if (stricmp(pGData->m_ACLineSegmentArray[nRecord].strLineType.c_str(), "����") == 0)
			sprintf(szField[PG_ACLINESEGMENT_LINETYPE], "%d", PGEnumLine_LineType_Cable);
		else
			sprintf(szField[PG_ACLINESEGMENT_LINETYPE], "%d", PGEnumLine_LineType_Overhead);
	}

	if (sqrt(pGData->m_ACLineSegmentArray[nRecord].r*pGData->m_ACLineSegmentArray[nRecord].r+pGData->m_ACLineSegmentArray[nRecord].x*pGData->m_ACLineSegmentArray[nRecord].x) > FLT_MIN)
	{
		sprintf(szField[PG_ACLINESEGMENT_R], "%f", pGData->m_ACLineSegmentArray[nRecord].r);
		sprintf(szField[PG_ACLINESEGMENT_X], "%f", pGData->m_ACLineSegmentArray[nRecord].x);
		sprintf(szField[PG_ACLINESEGMENT_G], "%f", pGData->m_ACLineSegmentArray[nRecord].g);
		sprintf(szField[PG_ACLINESEGMENT_B], "%f", pGData->m_ACLineSegmentArray[nRecord].b);
	}
	sprintf(szField[PG_ACLINESEGMENT_LINELOADP], "%f", pGData->m_ACLineSegmentArray[nRecord].fLineLoadP);
	sprintf(szField[PG_ACLINESEGMENT_LINELOADFACTOR], "%f", pGData->m_ACLineSegmentArray[nRecord].fLineLoadFactor);
	sprintf(szField[PG_ACLINESEGMENT_LINECAP], "%f", pGData->m_ACLineSegmentArray[nRecord].fLineCapacitor);

	return 1;
}

int CGISData2PGMemDB::ResolveDistributionTransformerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	int			nLoad;
	float		fFactor, fLoadP, fLoadQ, fCustnumNum;

	if (pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷������ѹ��, �޽ڵ���Ϣ: (%s)\n", pGData->m_PowerTransformerArray[nRecord].strName.c_str());
#endif
		return 0;
	}

	fLoadP=fLoadQ=fCustnumNum=0;
	for (nLoad=0; nLoad<(int)pGData->m_EnergyConsumerArray.size(); nLoad++)
	{
		if (pGData->m_EnergyConsumerArray[nLoad].nBelongPSRType == GIS_PowerTransformer && strcmp(pGData->m_EnergyConsumerArray[nLoad].strBelongPSRName.c_str(), pGData->m_PowerTransformerArray[nRecord].strName.c_str()) == 0)
		{
			fLoadP += pGData->m_EnergyConsumerArray[nLoad].fP;
			fLoadQ += pGData->m_EnergyConsumerArray[nLoad].fQ;
			fCustnumNum += pGData->m_EnergyConsumerArray[nLoad].fCustomNum;
		}
	}
	fFactor=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
	if (fFactor > FLT_MIN)
		fFactor = fLoadP/fFactor;
	else
		fFactor=0.95f;

	strcpy(szField[PG_DISTRIBUTIONLOAD_RESOURCEID],			pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());

	if (!pGData->m_PowerTransformerArray[nRecord].strName.empty())
		strcpy(szField[PG_DISTRIBUTIONLOAD_NAME],			pGData->m_PowerTransformerArray[nRecord].strName.c_str());
	else if (!pGData->m_PowerTransformerArray[nRecord].strObjectID.empty())
		strcpy(szField[PG_DISTRIBUTIONLOAD_NAME],			pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
	else
		strcpy(szField[PG_DISTRIBUTIONLOAD_NAME],			pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());

	strcpy(szField[PG_DISTRIBUTIONLOAD_SUBSTATIONENTITY],	pGData->m_PowerTransformerArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONLOAD_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[0].c_str()));
	strcpy(szField[PG_DISTRIBUTIONLOAD_CONNECTIVITYNODE],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].c_str());

	sprintf(szField[PG_DISTRIBUTIONLOAD_LOADP], "%f", fLoadP);
	sprintf(szField[PG_DISTRIBUTIONLOAD_LOADFACTOR], "%f", fFactor);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_CUSTOMER], "%f", fCustnumNum);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RATECAPACITY], "%f", pGData->m_PowerTransformerArray[nRecord].fRatedCapacity);
	if (pGData->m_PowerTransformerArray[nRecord].fP > FLT_MIN)
	{
		sprintf(szField[PG_DISTRIBUTIONLOAD_LOADP], "%f",		pGData->m_PowerTransformerArray[nRecord].fP);
		double	fBuf=sqrt(pGData->m_PowerTransformerArray[nRecord].fP*pGData->m_PowerTransformerArray[nRecord].fP+pGData->m_PowerTransformerArray[nRecord].fQ*pGData->m_PowerTransformerArray[nRecord].fQ);
		if (fBuf > FLT_MIN)
			sprintf(szField[PG_DISTRIBUTIONLOAD_LOADFACTOR], "%f",	pGData->m_PowerTransformerArray[nRecord].fP/fBuf);
		else
			strcpy(szField[PG_DISTRIBUTIONLOAD_LOADFACTOR], "0.95");
	}
	sprintf(szField[PG_DISTRIBUTIONLOAD_TYPE], "%d", PGEnumEnergyConsumerType_Transformer);

	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_RERR],		"%f",		pGData->m_PowerTransformerArray[nRecord].ri_Rerr		);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_TREP],		"%f",		pGData->m_PowerTransformerArray[nRecord].ri_Trep		);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_RCHK],		"%f",		pGData->m_PowerTransformerArray[nRecord].ri_Rchk		);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_TCHK],		"%f",		pGData->m_PowerTransformerArray[nRecord].ri_Tchk		);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_TFLOC],		"%f",		pGData->m_PowerTransformerArray[nRecord].ri_Tfloc		);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_CUSTOMER],	"%f",		pGData->m_PowerTransformerArray[nRecord].ri_Customer	);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_LOAD_RERR],	"%f",		pGData->m_PowerTransformerArray[nRecord].ri_load_rerr	);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_LOAD_TREP],	"%f",		pGData->m_PowerTransformerArray[nRecord].ri_load_trep	);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_LOAD_RCHK],	"%f",		pGData->m_PowerTransformerArray[nRecord].ri_load_rchk	);
	sprintf(szField[PG_DISTRIBUTIONLOAD_RI_LOAD_TCHK],	"%f",		pGData->m_PowerTransformerArray[nRecord].ri_load_tchk	);
	sprintf(szField[PG_DISTRIBUTIONLOAD_EI_INVEST],		"%f",		pGData->m_PowerTransformerArray[nRecord].ei_Invest		);

	return 1;
}

int CGISData2PGMemDB::ResolveTransformerWindingField(CGISData* pGData, const int nRecord, const int nWind, char szField[][MDB_CHARLEN_LONG])
{
	if (nWind == 0)	//	������
	{
		if (pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].empty())
		{
#ifdef	_DEBUG
			Log(g_lpszLogFile, "�޷������ѹ��, �޽ڵ�1��Ϣ: (%s)\n", pGData->m_PowerTransformerArray[nRecord].strName.c_str());
#endif
			return 0;
		}

		strcpy(szField[PG_TRANSFORMERWINDING_RESOURCEID],			pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());

		if (!pGData->m_PowerTransformerArray[nRecord].strName.empty())
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strName.c_str());
		}
		else if (!pGData->m_PowerTransformerArray[nRecord].strObjectID.empty())
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
		}
		else
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
		}
		strcpy(szField[PG_TRANSFORMERWINDING_SUBSTATION],			pGData->m_PowerTransformerArray[nRecord].strParent.c_str());
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELI],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[0].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEI],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].c_str());
		sprintf(szField[PG_TRANSFORMERWINDING_RATEMVA], "%f",		 pGData->m_PowerTransformerArray[nRecord].fRatedCapacity);

		sprintf(szField[PG_TRANSFORMERWINDING_WINDINGTYPE], "%d",	PGEnumTransformerWinding_WindConnectio_2WYD);

		if (!pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[1].empty())	strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[1].c_str()));
		if (!pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[2].empty())	strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[2].c_str()));
		if (!pGData->m_PowerTransformerArray[nRecord].strNodeArray[1].empty())		strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[1].c_str());
		if (!pGData->m_PowerTransformerArray[nRecord].strNodeArray[2].empty())		strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[2].c_str());
	}
	else if (nWind == 1)	//	�������ѹ��
	{
		if (pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].empty())
		{
#ifdef	_DEBUG
			Log(g_lpszLogFile, "�޷������ѹ��, �޽ڵ�H��Ϣ: (%s)\n", pGData->m_PowerTransformerArray[nRecord].strName.c_str());
#endif
			return 0;
		}

		strcpy(szField[PG_TRANSFORMERWINDING_RESOURCEID],				pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
		if (!pGData->m_PowerTransformerArray[nRecord].strName.empty())
		{
			sprintf(szField[PG_TRANSFORMERWINDING_NAME], "%s_H",		pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],		pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strName.c_str());
		}
		else if (!pGData->m_PowerTransformerArray[nRecord].strObjectID.empty())
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],					pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],		pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
		}
		else
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],					pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],		pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
		}
		sprintf(szField[PG_TRANSFORMERWINDING_RATEMVA], "%f",			 pGData->m_PowerTransformerArray[nRecord].fRatedCapacity);
		strcpy(szField[PG_TRANSFORMERWINDING_SUBSTATION],				pGData->m_PowerTransformerArray[nRecord].strParent.c_str());
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELI],			GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[0].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ],			GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[0].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEI],		pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].c_str());

		sprintf(szField[PG_TRANSFORMERWINDING_WINDINGTYPE], "%d",	PGEnumTransformerWinding_WindConnectio_3WY);
	}
	else if (nWind == 2)	//	��������ѹ��
	{
		if (pGData->m_PowerTransformerArray[nRecord].strNodeArray[1].empty())
		{
#ifdef	_DEBUG
			Log(g_lpszLogFile, "�޷������ѹ��, �޽ڵ�M��Ϣ: (%s)\n", pGData->m_PowerTransformerArray[nRecord].strName.c_str());
#endif
			return 0;
		}

		strcpy(szField[PG_TRANSFORMERWINDING_RESOURCEID],				pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());

		if (!pGData->m_PowerTransformerArray[nRecord].strName.empty())
		{
			sprintf(szField[PG_TRANSFORMERWINDING_NAME], "%s_M",		pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],		pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strName.c_str());
		}
		else if (!pGData->m_PowerTransformerArray[nRecord].strObjectID.empty())
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
		}
		else
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
		}
		sprintf(szField[PG_TRANSFORMERWINDING_RATEMVA], "%f",		pGData->m_PowerTransformerArray[nRecord].fRatedCapacity);
		strcpy(szField[PG_TRANSFORMERWINDING_SUBSTATION],			pGData->m_PowerTransformerArray[nRecord].strParent.c_str());
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELI],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[1].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[1].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEI],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[1].c_str());

		sprintf(szField[PG_TRANSFORMERWINDING_WINDINGTYPE], "%d",	PGEnumTransformerWinding_WindConnectio_3WY);
	}
	else if (nWind == 3)	//	�������ѹ��
	{
		if (pGData->m_PowerTransformerArray[nRecord].strNodeArray[2].empty())
		{
#ifdef	_DEBUG
			Log(g_lpszLogFile, "�޷������ѹ��, �޽ڵ�L��Ϣ: (%s)\n", pGData->m_PowerTransformerArray[nRecord].strName.c_str());
#endif
			return 0;
		}

		strcpy(szField[PG_TRANSFORMERWINDING_RESOURCEID],				pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
		if (!pGData->m_PowerTransformerArray[nRecord].strName.empty())
		{
			sprintf(szField[PG_TRANSFORMERWINDING_NAME], "%s_L",		pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],		pGData->m_PowerTransformerArray[nRecord].strName.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strName.c_str());
		}
		else if (!pGData->m_PowerTransformerArray[nRecord].strObjectID.empty())
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strObjectID.c_str());
		}
		else
		{
			strcpy(szField[PG_TRANSFORMERWINDING_NAME],				pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			strcpy(szField[PG_TRANSFORMERWINDING_POWERTRANSFORMER],	pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
			sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_T",	pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
		}
		strcpy(szField[PG_TRANSFORMERWINDING_SUBSTATION],			pGData->m_PowerTransformerArray[nRecord].strParent.c_str());
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELI],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[2].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[2].c_str()));
		strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEI],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[2].c_str());
		sprintf(szField[PG_TRANSFORMERWINDING_RATEMVA], "%f",		pGData->m_PowerTransformerArray[nRecord].fRatedCapacity);

		sprintf(szField[PG_TRANSFORMERWINDING_WINDINGTYPE], "%d",	PGEnumTransformerWinding_WindConnectio_3WD);
	}

	return 1;
}

int CGISData2PGMemDB::ResolveDistributionBreakerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_BreakerArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "��·���޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_BreakerArray[nRecord].strName.c_str(), pGData->m_BreakerArray[nRecord].strNodeI.c_str(), pGData->m_BreakerArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_BreakerArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "��·���޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_BreakerArray[nRecord].strName.c_str(), pGData->m_BreakerArray[nRecord].strNodeI.c_str(), pGData->m_BreakerArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_DISTRIBUTIONBREAKER_RESOURCEID],			pGData->m_BreakerArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_NAME],				pGData->m_BreakerArray[nRecord].strName.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_SUBSTATIONENTITY],	pGData->m_BreakerArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_BreakerArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEI],	pGData->m_BreakerArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEZ],	pGData->m_BreakerArray[nRecord].strNodeZ.c_str());
	sprintf(szField[PG_DISTRIBUTIONBREAKER_BREAKERTYPE], "%d",	(int)PGEnumBreakerType_Breaker);

	sprintf(szField[PG_DISTRIBUTIONBREAKER_STATUS], "%d",		pGData->m_BreakerArray[nRecord].nStatus);

	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RERR], "%f",		pGData->m_BreakerArray[nRecord].ri_Rerr);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TREP], "%f",		pGData->m_BreakerArray[nRecord].ri_Trep);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RCHK], "%f",		pGData->m_BreakerArray[nRecord].ri_Rchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TCHK], "%f",		pGData->m_BreakerArray[nRecord].ri_Tchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TFLOC], "%f",		pGData->m_BreakerArray[nRecord].ri_Tfloc);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RSWITCH], "%f",	pGData->m_BreakerArray[nRecord].ri_RSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TSWITCH], "%f",	pGData->m_BreakerArray[nRecord].ri_TSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_EI_INVEST], "%f",		pGData->m_BreakerArray[nRecord].ei_Invest);

	return 1;
}

int CGISData2PGMemDB::ResolveBreakerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_BreakerArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "��·���޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_BreakerArray[nRecord].strName.c_str(), pGData->m_BreakerArray[nRecord].strNodeI.c_str(), pGData->m_BreakerArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_BreakerArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "��·���޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_BreakerArray[nRecord].strName.c_str(), pGData->m_BreakerArray[nRecord].strNodeI.c_str(), pGData->m_BreakerArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_BREAKER_RESOURCEID],			pGData->m_BreakerArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_BREAKER_NAME],				pGData->m_BreakerArray[nRecord].strName.c_str());
	strcpy(szField[PG_BREAKER_SUBSTATION],			pGData->m_BreakerArray[nRecord].strParent.c_str());
	strcpy(szField[PG_BREAKER_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_BreakerArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_BREAKER_CONNECTIVITYNODEI],	pGData->m_BreakerArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_BREAKER_CONNECTIVITYNODEJ],	pGData->m_BreakerArray[nRecord].strNodeZ.c_str());
	sprintf(szField[PG_BREAKER_CATEGORY], "%d",		(int)PGEnumBreakerType_Breaker);

	sprintf(szField[PG_BREAKER_STATUS], "%d",		pGData->m_BreakerArray[nRecord].nStatus);

	return 1;
}

int CGISData2PGMemDB::ResolveDistributionDisconnectorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_DisconnectorArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "���뿪���޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_DisconnectorArray[nRecord].strName.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeI.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_DisconnectorArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "���뿪���޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_DisconnectorArray[nRecord].strName.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeI.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_DISTRIBUTIONBREAKER_RESOURCEID],			pGData->m_DisconnectorArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_NAME],				pGData->m_DisconnectorArray[nRecord].strName.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_SUBSTATIONENTITY],	pGData->m_DisconnectorArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_DisconnectorArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEI],	pGData->m_DisconnectorArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEZ],	pGData->m_DisconnectorArray[nRecord].strNodeZ.c_str());
	sprintf(szField[PG_DISTRIBUTIONBREAKER_BREAKERTYPE], "%d",	(int)PGEnumBreakerType_Disconnector);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_STATUS], "%d",		pGData->m_DisconnectorArray[nRecord].nStatus);

	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RERR], "%f",		pGData->m_DisconnectorArray[nRecord].ri_Rerr);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TREP], "%f",		pGData->m_DisconnectorArray[nRecord].ri_Trep);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RCHK], "%f",		pGData->m_DisconnectorArray[nRecord].ri_Rchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TCHK], "%f",		pGData->m_DisconnectorArray[nRecord].ri_Tchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TFLOC], "%f",		pGData->m_DisconnectorArray[nRecord].ri_Tfloc);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RSWITCH], "%f",	pGData->m_DisconnectorArray[nRecord].ri_RSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TSWITCH], "%f",	pGData->m_DisconnectorArray[nRecord].ri_TSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_EI_INVEST], "%f",		pGData->m_DisconnectorArray[nRecord].ei_Invest);

	return 1;
}

int CGISData2PGMemDB::ResolveDisconnectorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_DisconnectorArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "���뿪���޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_DisconnectorArray[nRecord].strName.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeI.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_DisconnectorArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "���뿪���޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_DisconnectorArray[nRecord].strName.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeI.c_str(), pGData->m_DisconnectorArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_DISCONNECTOR_RESOURCEID],			pGData->m_DisconnectorArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISCONNECTOR_NAME],				pGData->m_DisconnectorArray[nRecord].strName.c_str());
	strcpy(szField[PG_DISCONNECTOR_SUBSTATION],			pGData->m_DisconnectorArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISCONNECTOR_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_DisconnectorArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISCONNECTOR_CONNECTIVITYNODEI],	pGData->m_DisconnectorArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_DISCONNECTOR_CONNECTIVITYNODEJ],	pGData->m_DisconnectorArray[nRecord].strNodeZ.c_str());
	sprintf(szField[PG_DISCONNECTOR_STATUS], "%d",		pGData->m_DisconnectorArray[nRecord].nStatus);

	return 1;
}

int CGISData2PGMemDB::ResolveGroundDisconnectorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_GroundDisconnectorArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�ӵص�բ�޽ڵ���Ϣ: (%s) (%s)\n", pGData->m_GroundDisconnectorArray[nRecord].strName.c_str(), pGData->m_GroundDisconnectorArray[nRecord].strNode.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_GROUNDDISCONNECTOR_RESOURCEID],		pGData->m_GroundDisconnectorArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_GROUNDDISCONNECTOR_NAME],				pGData->m_GroundDisconnectorArray[nRecord].strName.c_str());
	strcpy(szField[PG_GROUNDDISCONNECTOR_SUBSTATION],		pGData->m_GroundDisconnectorArray[nRecord].strParent.c_str());
	strcpy(szField[PG_GROUNDDISCONNECTOR_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_GroundDisconnectorArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_GROUNDDISCONNECTOR_CONNECTIVITYNODE],	pGData->m_GroundDisconnectorArray[nRecord].strNode.c_str());
	sprintf(szField[PG_GROUNDDISCONNECTOR_STATUS], "%d",		pGData->m_GroundDisconnectorArray[nRecord].nStatus);

	return 1;
}

int CGISData2PGMemDB::ResolveLoadBreakSwitchField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_LoadBreakSwitchArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "���ɿ����޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_LoadBreakSwitchArray[nRecord].strName.c_str(), pGData->m_LoadBreakSwitchArray[nRecord].strNodeI.c_str(), pGData->m_LoadBreakSwitchArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_LoadBreakSwitchArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "���ɿ����޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_LoadBreakSwitchArray[nRecord].strName.c_str(), pGData->m_LoadBreakSwitchArray[nRecord].strNodeI.c_str(), pGData->m_LoadBreakSwitchArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_DISTRIBUTIONBREAKER_RESOURCEID],			pGData->m_LoadBreakSwitchArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_NAME],				pGData->m_LoadBreakSwitchArray[nRecord].strName.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_SUBSTATIONENTITY],	pGData->m_LoadBreakSwitchArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_LoadBreakSwitchArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEI],	pGData->m_LoadBreakSwitchArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEZ],	pGData->m_LoadBreakSwitchArray[nRecord].strNodeZ.c_str());
	sprintf(szField[PG_DISTRIBUTIONBREAKER_BREAKERTYPE], "%d",	(int)PGEnumBreakerType_LoadBreakSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_STATUS], "%d",		pGData->m_LoadBreakSwitchArray[nRecord].nStatus);

	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RERR], "%f",		pGData->m_LoadBreakSwitchArray[nRecord].ri_Rerr);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TREP], "%f",		pGData->m_LoadBreakSwitchArray[nRecord].ri_Trep);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RCHK], "%f",		pGData->m_LoadBreakSwitchArray[nRecord].ri_Rchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TCHK], "%f",		pGData->m_LoadBreakSwitchArray[nRecord].ri_Tchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TFLOC], "%f",		pGData->m_LoadBreakSwitchArray[nRecord].ri_Tfloc);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RSWITCH], "%f",	pGData->m_LoadBreakSwitchArray[nRecord].ri_RSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TSWITCH], "%f",	pGData->m_LoadBreakSwitchArray[nRecord].ri_TSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_EI_INVEST], "%f",		pGData->m_LoadBreakSwitchArray[nRecord].ei_Invest);

	return 1;
}

int CGISData2PGMemDB::ResolveFuseField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_FuseArray[nRecord].strNodeI.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�۶����޽ڵ�1��Ϣ: (%s) (%s) (%s)\n", pGData->m_FuseArray[nRecord].strName.c_str(), pGData->m_FuseArray[nRecord].strNodeI.c_str(), pGData->m_FuseArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	if (pGData->m_FuseArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�۶����޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", pGData->m_FuseArray[nRecord].strName.c_str(), pGData->m_FuseArray[nRecord].strNodeI.c_str(), pGData->m_FuseArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_DISTRIBUTIONBREAKER_RESOURCEID],			pGData->m_FuseArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_NAME],				pGData->m_FuseArray[nRecord].strName.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_SUBSTATIONENTITY],	pGData->m_FuseArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_FuseArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEI],	pGData->m_FuseArray[nRecord].strNodeI.c_str());
	strcpy(szField[PG_DISTRIBUTIONBREAKER_CONNECTIVITYNODEZ],	pGData->m_FuseArray[nRecord].strNodeZ.c_str());
	sprintf(szField[PG_DISTRIBUTIONBREAKER_BREAKERTYPE], "%d",	(int)PGEnumBreakerType_FuseBreaker);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_STATUS], "%d",		pGData->m_FuseArray[nRecord].nStatus);

	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RERR], "%f",		pGData->m_FuseArray[nRecord].ri_Rerr);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TREP], "%f",		pGData->m_FuseArray[nRecord].ri_Trep);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RCHK], "%f",		pGData->m_FuseArray[nRecord].ri_Rchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TCHK], "%f",		pGData->m_FuseArray[nRecord].ri_Tchk);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TFLOC], "%f",		pGData->m_FuseArray[nRecord].ri_Tfloc);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_RSWITCH], "%f",	pGData->m_FuseArray[nRecord].ri_RSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_RI_TSWITCH], "%f",	pGData->m_FuseArray[nRecord].ri_TSwitch);
	sprintf(szField[PG_DISTRIBUTIONBREAKER_EI_INVEST], "%f",		pGData->m_FuseArray[nRecord].ei_Invest);

	return 1;
}

int CGISData2PGMemDB::ResolvePoleField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	int			nLoad;
	float		fFactor, fLoadP, fLoadQ, fCustnumNum;

	if (pGData->m_PoleArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷��������, �޽ڵ���Ϣ: (%s)\n", pGData->m_PoleArray[nRecord].strName.c_str());
#endif
		return 0;
	}
	fLoadP=fLoadQ=fCustnumNum=0;
	for (nLoad=0; nLoad<(int)pGData->m_EnergyConsumerArray.size(); nLoad++)
	{
		if (pGData->m_EnergyConsumerArray[nLoad].nBelongPSRType == GIS_Pole &&
			strcmp(pGData->m_EnergyConsumerArray[nLoad].strBelongPSRName.c_str(), pGData->m_PoleArray[nRecord].strName.c_str()) == 0)
		{
			fLoadP += pGData->m_EnergyConsumerArray[nLoad].fP;
			fLoadQ += pGData->m_EnergyConsumerArray[nLoad].fQ;
			fCustnumNum += pGData->m_EnergyConsumerArray[nLoad].fCustomNum;
		}
	}
	fFactor=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
	if (fFactor > FLT_MIN)
		fFactor = fLoadP/fFactor;
	else
		fFactor=0.95f;

	strcpy(szField[PG_DISTRIBUTIONDOT_RESOURCEID],			pGData->m_PoleArray[nRecord].strResourceID.c_str());

	if (!pGData->m_PoleArray[nRecord].strName.empty())
		strcpy(szField[PG_DISTRIBUTIONDOT_NAME],			pGData->m_PoleArray[nRecord].strName.c_str());
	else
		strcpy(szField[PG_DISTRIBUTIONDOT_NAME],			pGData->m_PoleArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISTRIBUTIONDOT_SUBSTATIONENTITY],	pGData->m_PoleArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONDOT_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_PoleArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISTRIBUTIONDOT_CONNECTIVITYNODE],	pGData->m_PoleArray[nRecord].strNode.c_str());
	sprintf(szField[PG_DISTRIBUTIONDOT_TYPE], "%d",			(int)PGEnumJunctionPoleType_Pole);

	sprintf(szField[PG_DISTRIBUTIONDOT_LOADP], "%f", fLoadP);
	sprintf(szField[PG_DISTRIBUTIONDOT_LOADFACTOR], "%f", fFactor);
	sprintf(szField[PG_DISTRIBUTIONDOT_RI_CUSTOMER], "%f", fCustnumNum);

	return 1;
}

int CGISData2PGMemDB::ResolveJunctionField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	int			nLoad;
	float		fFactor, fLoadP, fLoadQ, fCustnumNum;

	if (pGData->m_JunctionArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷���������ն�, �޽ڵ���Ϣ: (%s)\n", pGData->m_JunctionArray[nRecord].strName.c_str());
#endif
		return 0;
	}
	fLoadP=fLoadQ=fCustnumNum=0;
	for (nLoad=0; nLoad<(int)pGData->m_EnergyConsumerArray.size(); nLoad++)
	{
		if (pGData->m_EnergyConsumerArray[nLoad].nBelongPSRType == GIS_Junction&&
			strcmp(pGData->m_EnergyConsumerArray[nLoad].strBelongPSRName.c_str(), pGData->m_PoleArray[nRecord].strName.c_str()) == 0)
		{
			fLoadP += pGData->m_EnergyConsumerArray[nLoad].fP;
			fLoadQ += pGData->m_EnergyConsumerArray[nLoad].fQ;
			fCustnumNum += pGData->m_EnergyConsumerArray[nLoad].fCustomNum;
		}
	}
	fFactor=sqrt(fLoadP*fLoadP+fLoadQ*fLoadQ);
	if (fFactor > FLT_MIN)
		fFactor = fLoadP/fFactor;
	else
		fFactor=0.95f;

	strcpy(szField[PG_DISTRIBUTIONDOT_RESOURCEID],			pGData->m_JunctionArray[nRecord].strResourceID.c_str());
	if (!pGData->m_JunctionArray[nRecord].strName.empty())
		strcpy(szField[PG_DISTRIBUTIONDOT_NAME],			pGData->m_JunctionArray[nRecord].strName.c_str());
	else
		strcpy(szField[PG_DISTRIBUTIONDOT_NAME],			pGData->m_JunctionArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_DISTRIBUTIONDOT_SUBSTATIONENTITY],	pGData->m_JunctionArray[nRecord].strParent.c_str());
	strcpy(szField[PG_DISTRIBUTIONDOT_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_JunctionArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_DISTRIBUTIONDOT_CONNECTIVITYNODE],	pGData->m_JunctionArray[nRecord].strNode.c_str());
	sprintf(szField[PG_DISTRIBUTIONDOT_TYPE], "%d",			(int)PGEnumJunctionPoleType_Junction);

	sprintf(szField[PG_DISTRIBUTIONDOT_LOADP], "%f", fLoadP);
	sprintf(szField[PG_DISTRIBUTIONDOT_LOADFACTOR], "%f", fFactor);
	sprintf(szField[PG_DISTRIBUTIONDOT_RI_CUSTOMER], "%f", fCustnumNum);

	return 1;
}

int CGISData2PGMemDB::ResolveShuntCapacitorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_CapacitorArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷����벢��������, �޽ڵ���Ϣ: (%s)\n", pGData->m_CapacitorArray[nRecord].strName.c_str());
#endif
		return 0;
	}

	strcpy(szField[PG_SHUNTCOMPENSATOR_RESOURCEID],			pGData->m_CapacitorArray[nRecord].strResourceID.c_str());
	if (!pGData->m_CapacitorArray[nRecord].strName.empty())
		strcpy(szField[PG_SHUNTCOMPENSATOR_NAME],			pGData->m_CapacitorArray[nRecord].strName.c_str());
	else
		strcpy(szField[PG_SHUNTCOMPENSATOR_NAME],			pGData->m_CapacitorArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_SHUNTCOMPENSATOR_SUBSTATION],			pGData->m_CapacitorArray[nRecord].strParent.c_str());
	strcpy(szField[PG_SHUNTCOMPENSATOR_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_CapacitorArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_SHUNTCOMPENSATOR_CONNECTIVITYNODE],	pGData->m_CapacitorArray[nRecord].strNode.c_str());

	strcpy(szField[PG_SHUNTCOMPENSATOR_CAP],				"0.01");
	return 1;
}

int CGISData2PGMemDB::ResolvePowerTransformerAsEnergyConsumerField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷����븺��, �޽ڵ���Ϣ: (%s)\n", pGData->m_PowerTransformerArray[nRecord].strName.c_str());
#endif
		return 0;
	}

	strcpy(szField[PG_ENERGYCONSUMER_RESOURCEID],		pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
	if (!pGData->m_PowerTransformerArray[nRecord].strName.empty())
		strcpy(szField[PG_ENERGYCONSUMER_NAME],			pGData->m_PowerTransformerArray[nRecord].strName.c_str());
	else
		strcpy(szField[PG_ENERGYCONSUMER_NAME],			pGData->m_PowerTransformerArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION],		pGData->m_PowerTransformerArray[nRecord].strParent.c_str());
	strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_PowerTransformerArray[nRecord].strVoltTagArray[0].c_str()));
	strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE],	pGData->m_PowerTransformerArray[nRecord].strNodeArray[0].c_str());
	return 1;
}

int CGISData2PGMemDB::ResolveShuntCompensatorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_CompensatorArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷����벢���翹��, �޽ڵ���Ϣ: (%s)\n", pGData->m_CompensatorArray[nRecord].strName.c_str());
#endif
		return 0;
	}

	strcpy(szField[PG_SHUNTCOMPENSATOR_RESOURCEID],			pGData->m_CompensatorArray[nRecord].strResourceID.c_str());
	if (!pGData->m_CompensatorArray[nRecord].strName.empty())
		strcpy(szField[PG_SHUNTCOMPENSATOR_NAME],			pGData->m_CompensatorArray[nRecord].strName.c_str());
	else
		strcpy(szField[PG_SHUNTCOMPENSATOR_NAME],			pGData->m_CompensatorArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_SHUNTCOMPENSATOR_SUBSTATION],			pGData->m_CompensatorArray[nRecord].strParent.c_str());
	strcpy(szField[PG_SHUNTCOMPENSATOR_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_CompensatorArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_SHUNTCOMPENSATOR_CONNECTIVITYNODE],	pGData->m_CompensatorArray[nRecord].strNode.c_str());
	strcpy(szField[PG_SHUNTCOMPENSATOR_CAP],				"-0.01");

	return 1;
}

int CGISData2PGMemDB::ResolveSeriesCompensatorField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_CompensatorArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷����봮���翹��, �޽ڵ���Ϣ: (%s)\n", pGData->m_CompensatorArray[nRecord].strName.c_str());
#endif
		return 0;
	}
	strcpy(szField[PG_SERIESCOMPENSATOR_RESOURCEID],		pGData->m_CompensatorArray[nRecord].strResourceID.c_str());

	if (!pGData->m_CompensatorArray[nRecord].strName.empty())
		strcpy(szField[PG_SERIESCOMPENSATOR_NAME],			pGData->m_CompensatorArray[nRecord].strName.c_str());
	else
		strcpy(szField[PG_SERIESCOMPENSATOR_NAME],			pGData->m_CompensatorArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_SERIESCOMPENSATOR_SUBSTATION],		pGData->m_CompensatorArray[nRecord].strParent.c_str());
	strcpy(szField[PG_SERIESCOMPENSATOR_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_CompensatorArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_SERIESCOMPENSATOR_CONNECTIVITYNODEI],	pGData->m_CompensatorArray[nRecord].strNode.c_str());
	strcpy(szField[PG_SERIESCOMPENSATOR_CONNECTIVITYNODEJ],	pGData->m_CompensatorArray[nRecord].strSeriesNode.c_str());
	strcpy(szField[PG_SERIESCOMPENSATOR_X],					"0.01");

	return 1;
}

int CGISData2PGMemDB::ResolveConnLineField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	std::vector<int>	nNodeArray;

	if (pGData->m_ConnLineArray[nRecord].strNodeI.empty() && pGData->m_ConnLineArray[nRecord].strNodeZ.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�����������, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", pGData->m_ConnLineArray[nRecord].strName.c_str(), pGData->m_ConnLineArray[nRecord].strNodeI.c_str(), pGData->m_ConnLineArray[nRecord].strNodeZ.c_str());
#endif
		return 0;
	}

	strcpy(szField[PG_CONNLINE_RESOURCEID],				pGData->m_ConnLineArray[nRecord].strResourceID.c_str());
	if (pGData->m_ConnLineArray[nRecord].strParent.empty())
		strcpy(szField[PG_CONNLINE_SUBSTATION],			pGData->m_ConnLineArray[nRecord].strResourceID.c_str());
	else
		strcpy(szField[PG_CONNLINE_SUBSTATION],			pGData->m_ConnLineArray[nRecord].strParent.c_str());
	strcpy(szField[PG_CONNLINE_VOLTAGELEVEL],			GetVoltageName(pGData, pGData->m_ConnLineArray[nRecord].strBaseVoltageTag.c_str()));
	strcpy(szField[PG_CONNLINE_CONNECTIVITYNODE],		pGData->m_ConnLineArray[nRecord].strNodeI.c_str());

	return 1;
}

int CGISData2PGMemDB::ResolveBusbarSectionField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	if (pGData->m_BusbarSectionArray[nRecord].strParent.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�����ĸ��, �޳�վ��Ϣ: (%s) (%s)\n", pGData->m_BusbarSectionArray[nRecord].strName.c_str(), pGData->m_BusbarSectionArray[nRecord].strNode);
#endif
		return 0;
	}
	if (pGData->m_BusbarSectionArray[nRecord].strNode.empty())
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�޷�����ĸ��, �޽ڵ���Ϣ: (%s) (%s)\n", pGData->m_BusbarSectionArray[nRecord].strName.c_str(), pGData->m_BusbarSectionArray[nRecord].strNode);
#endif
		return 0;
	}

	strcpy(szField[PG_BUSBARSECTION_RESOURCEID],		pGData->m_BusbarSectionArray[nRecord].strResourceID.c_str());
	strcpy(szField[PG_BUSBARSECTION_DESC],				pGData->m_BusbarSectionArray[nRecord].strObjectID.c_str());
	strcpy(szField[PG_BUSBARSECTION_NAME],				pGData->m_BusbarSectionArray[nRecord].strName.c_str());
	strcpy(szField[PG_BUSBARSECTION_CONNECTIVITYNODE],	pGData->m_BusbarSectionArray[nRecord].strNode.c_str());
	strcpy(szField[PG_BUSBARSECTION_SUBSTATION],		pGData->m_BusbarSectionArray[nRecord].strParent.c_str());
	strcpy(szField[PG_BUSBARSECTION_VOLTAGELEVEL],		GetVoltageName(pGData, pGData->m_BusbarSectionArray[nRecord].strBaseVoltageTag.c_str()));

	return 1;
}

int CGISData2PGMemDB::ResolvePipeField(CGISData* pGData, const int nRecord, char szField[][MDB_CHARLEN_LONG])
{
	register int	i;

	Log(g_lpszLogFile, "ResolvePipeField[%d/%d] CableNum=%d %d %d\n", nRecord, pGData->m_PipeArray.size(), pGData->m_PipeArray[nRecord].nHVCableNum, pGData->m_PipeArray[nRecord].nMVCableNum, pGData->m_PipeArray[nRecord].nLVCableNum);

	strcpy(szField[PG_PIPE_RESOURCEID],				pGData->m_PipeArray[nRecord].strResourceID.c_str());	Log(g_lpszLogFile, "ResolvePipeField@1\n");
	strcpy(szField[PG_PIPE_NAME],					pGData->m_PipeArray[nRecord].strName.c_str());			Log(g_lpszLogFile, "ResolvePipeField@2\n");
	strcpy(szField[PG_PIPE_MODEL],					pGData->m_PipeArray[nRecord].strModel.c_str());			Log(g_lpszLogFile, "ResolvePipeField@3\n");
	sprintf(szField[PG_PIPE_MAXHVCABLENUM], "%d",	pGData->m_PipeArray[nRecord].nMaxHVCableNum);			Log(g_lpszLogFile, "ResolvePipeField@4.1\n");
	sprintf(szField[PG_PIPE_MAXMVCABLENUM], "%d",	pGData->m_PipeArray[nRecord].nMaxMVCableNum);			Log(g_lpszLogFile, "ResolvePipeField@4.2\n");
	sprintf(szField[PG_PIPE_MAXLVCABLENUM], "%d",	pGData->m_PipeArray[nRecord].nMaxLVCableNum);			Log(g_lpszLogFile, "ResolvePipeField@4.3\n");

	sprintf(szField[PG_PIPE_PLANCHARACTER], "%d",	pGData->m_PipeArray[nRecord].nPlanCharacter);
	sprintf(szField[PG_PIPE_BUILDDATE], "%d",		pGData->m_PipeArray[nRecord].nBuildDate);
	sprintf(szField[PG_PIPE_REBUILDDATE], "%d",		pGData->m_PipeArray[nRecord].nReBuildDate);
	sprintf(szField[PG_PIPE_OUTAGEDATE], "%d",		pGData->m_PipeArray[nRecord].nOutageDate);
	sprintf(szField[PG_PIPE_RUNTIMESPAN], "%d",		pGData->m_PipeArray[nRecord].nRunTimeSpan);

	for (i=0; i<pGData->m_PipeArray[nRecord].nHVCableNum; i++)
	{
		strcpy(szField[PG_PIPE_HVCABLE1+i], pGData->m_PipeArray[nRecord].strHVCable[i].c_str());	Log(g_lpszLogFile, "ResolvePipeField@5.1 [%d=%s]\n", i, pGData->m_PipeArray[nRecord].strHVCable[i].c_str());
	}
	for (i=0; i<pGData->m_PipeArray[nRecord].nMVCableNum; i++)
	{
		strcpy(szField[PG_PIPE_MVCABLE1+i], pGData->m_PipeArray[nRecord].strMVCable[i].c_str());	Log(g_lpszLogFile, "ResolvePipeField@5.2 [%d=%s]\n", i, pGData->m_PipeArray[nRecord].strMVCable[i].c_str());
	}
	for (i=0; i<pGData->m_PipeArray[nRecord].nLVCableNum; i++)
	{
		strcpy(szField[PG_PIPE_LVCABLE1+i], pGData->m_PipeArray[nRecord].strLVCable[i].c_str());	Log(g_lpszLogFile, "ResolvePipeField@5.3 [%d=%s]\n", i, pGData->m_PipeArray[nRecord].strLVCable[i].c_str());
	}

	Log(g_lpszLogFile, "ResolvePipeField@6\n");

	return 1;
}
