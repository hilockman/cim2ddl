#include "stdafx.h"
#include "GISData.h"

void	CGISData::TraverseNode(const int nStartNode, std::vector<int>& nNodeArray)
{
	register int	i;
	std::vector<unsigned char>	bProcArray;
	int		nDev, nDevice, nOppNode, nNodeNumOfLayer;
	std::vector<int> nMidNodeArray;

	bProcArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nNodeArray.clear();
	nNodeArray.push_back(nStartNode);
	bProcArray[nStartNode]=1;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
		{
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev];
				if (m_BreakerArray[nDevice].nNodeZ < 0 || m_BreakerArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_BreakerArray[nDevice].nNodeI) ? m_BreakerArray[nDevice].nNodeZ : m_BreakerArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev];
				if (m_DisconnectorArray[nDevice].nNodeZ < 0 || m_DisconnectorArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_DisconnectorArray[nDevice].nNodeI) ? m_DisconnectorArray[nDevice].nNodeZ : m_DisconnectorArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev];
				if (m_LoadBreakSwitchArray[nDevice].nNodeZ < 0 || m_LoadBreakSwitchArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_LoadBreakSwitchArray[nDevice].nNodeI) ? m_LoadBreakSwitchArray[nDevice].nNodeZ : m_LoadBreakSwitchArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev];
				if (m_FuseArray[nDevice].nNodeZ < 0 || m_FuseArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_FuseArray[nDevice].nNodeI) ? m_FuseArray[nDevice].nNodeZ : m_FuseArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev];
				if (m_ConnLineArray[nDevice].nNodeZ < 0 || m_ConnLineArray[nDevice].nNodeI < 0)
					continue;
				if (strcmp(m_ConnLineArray[nDevice].strNodeZ.c_str(), m_ConnLineArray[nDevice].strNodeI.c_str()) == 0)
					continue;

				nOppNode=(nNodeArray[i] == m_ConnLineArray[nDevice].nNodeI) ? m_ConnLineArray[nDevice].nNodeZ : m_ConnLineArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev];
				if (m_CompensatorArray[nDevice].nSeriesNode < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_CompensatorArray[nDevice].nNode) ? m_CompensatorArray[nDevice].nSeriesNode : m_CompensatorArray[nDevice].nNode;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
		}

		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nNodeArray.push_back(nMidNodeArray[i]);
	}

	bProcArray.clear();
}

void	CGISData::TraverseSubstation(const int nStartNode, std::vector<int>& nNodeArray)
{
	register int	i, j;
	std::vector<unsigned char>	bProcArray;
	int		nDev, nDevice, nOppNode, nNodeNumOfLayer;
	std::vector<int> nMidNodeArray;

	bProcArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nNodeArray.clear();
	nNodeArray.push_back(nStartNode);
	bProcArray[nStartNode]=1;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
		{
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray[nDev];
				if (m_BreakerArray[nDevice].nNodeZ < 0 || m_BreakerArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_BreakerArray[nDevice].nNodeI) ? m_BreakerArray[nDevice].nNodeZ : m_BreakerArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray[nDev];
				if (m_DisconnectorArray[nDevice].nNodeZ < 0 || m_DisconnectorArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_DisconnectorArray[nDevice].nNodeI) ? m_DisconnectorArray[nDevice].nNodeZ : m_DisconnectorArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray[nDev];
				if (m_LoadBreakSwitchArray[nDevice].nNodeZ < 0 || m_LoadBreakSwitchArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_LoadBreakSwitchArray[nDevice].nNodeI) ? m_LoadBreakSwitchArray[nDevice].nNodeZ : m_LoadBreakSwitchArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nFuseArray[nDev];
				if (m_FuseArray[nDevice].nNodeZ < 0 || m_FuseArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_FuseArray[nDevice].nNodeI) ? m_FuseArray[nDevice].nNodeZ : m_FuseArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev];
				if (m_ConnLineArray[nDevice].nNodeZ < 0 || m_ConnLineArray[nDevice].nNodeI < 0)
					continue;
				if (strcmp(m_ConnLineArray[nDevice].strNodeZ.c_str(), m_ConnLineArray[nDevice].strNodeI.c_str()) == 0)
					continue;

				nOppNode=(nNodeArray[i] == m_ConnLineArray[nDevice].nNodeI) ? m_ConnLineArray[nDevice].nNodeZ : m_ConnLineArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray[nDev];
				if (m_CompensatorArray[nDevice].nSeriesNode < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_CompensatorArray[nDevice].nNode) ? m_CompensatorArray[nDevice].nSeriesNode : m_CompensatorArray[nDevice].nNode;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray[nDev];
				for (j=0; j<m_PowerTransformerArray[nDevice].nWindNum; j++)
				{
					if (m_PowerTransformerArray[nDevice].nNodeArray[j] < 0)
						continue;
					if (m_PowerTransformerArray[nDevice].nNodeArray[j] == nNodeArray[i])
						continue;
					if (!bProcArray[m_PowerTransformerArray[nDevice].nNodeArray[j]])
					{
						nMidNodeArray.push_back(m_PowerTransformerArray[nDevice].nNodeArray[j]);
						bProcArray[m_PowerTransformerArray[nDevice].nNodeArray[j]]=1;
					}
				}
			}
		}

		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nNodeArray.push_back(nMidNodeArray[i]);
	}

	bProcArray.clear();
}

void	CGISData::TraverseConnLine(const int nStartNode, std::vector<int>& nNodeArray)
{
	register int	i;
	std::vector<unsigned char>	bProcArray;
	int		nDev, nDevice, nOppNode, nNodeNumOfLayer;
	std::vector<int> nMidNodeArray;

	bProcArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nNodeArray.clear();
	nNodeArray.push_back(nStartNode);
	bProcArray[nStartNode]=1;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
		{
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[nDev];
				if (m_ConnLineArray[nDevice].nNodeZ < 0 || m_ConnLineArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_ConnLineArray[nDevice].nNodeI) ? m_ConnLineArray[nDevice].nNodeZ : m_ConnLineArray[nDevice].nNodeI;
				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
		}

		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nNodeArray.push_back(nMidNodeArray[i]);
	}

	nMidNodeArray.clear();
	bProcArray.clear();
}

void	CGISData::TraverseLineSegment(const int nStartNode, std::vector<int>& nNodeArray)
{
	register int	i;
	std::vector<unsigned char>	bProcArray;
	int		nDev, nDevice, nOppNode, nNodeNumOfLayer;
	std::vector<int> nMidNodeArray;

	nNodeArray.clear();
	if (!m_ConnectivityNodeArray[nStartNode].bFlaged)
		return;

	bProcArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nNodeArray.push_back(nStartNode);
	bProcArray[nStartNode]=1;
	nNodeNumOfLayer=0;
	while (1)
	{
		nMidNodeArray.clear();
		for (i=nNodeNumOfLayer; i<(int)nNodeArray.size(); i++)
		{
			for (nDev=0; nDev<(int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size(); nDev++)
			{
				nDevice=m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray[nDev];
				if (m_ACLineSegmentArray[nDevice].nNodeZ < 0 || m_ACLineSegmentArray[nDevice].nNodeI < 0)
					continue;

				nOppNode=(nNodeArray[i] == m_ACLineSegmentArray[nDevice].nNodeI) ? m_ACLineSegmentArray[nDevice].nNodeZ : m_ACLineSegmentArray[nDevice].nNodeI;
				if (!m_ConnectivityNodeArray[nOppNode].bFlaged)
					continue;

				if (!bProcArray[nOppNode])
				{
					nMidNodeArray.push_back(nOppNode);
					bProcArray[nOppNode]=1;
				}
			}
		}

		if (nMidNodeArray.empty())
			break;
		nNodeNumOfLayer=(int)nNodeArray.size();
		for (i=0; i<(int)nMidNodeArray.size(); i++)
			nNodeArray.push_back(nMidNodeArray[i]);
	}

	nMidNodeArray.clear();
	bProcArray.clear();
}
