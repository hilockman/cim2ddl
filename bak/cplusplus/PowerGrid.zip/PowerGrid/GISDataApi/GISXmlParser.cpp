#include "StdAfx.h"
#include "GISDataApi.h"
#include "GISXmlParser.h"

// #include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/PlatformUtils.hpp"
// #include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/TransService.hpp"
// #include "../../3rdParty/xerces-c-3.1.1/src/xercesc/parsers/SAXParser.hpp"
// #include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/OutOfMemoryException.hpp"
// #include "GISXml_SAXHandlers.hpp"

#if (!defined(WIN64))
#	pragma comment(lib, "../../lib/xerces-c_3.lib")
#else					 
#	pragma comment(lib, "../../lib_x64/xerces-c_3.lib")
#endif


CGISXmlParser::CGISXmlParser(void)
{
}

CGISXmlParser::~CGISXmlParser(void)
{
}

int	CGISXmlParser::Parse(CGISData& gData, std::vector<std::string>& strXmlFileArray, std::string& strFilterMark, std::vector<std::string>& strFilterKeyArray, const int bParseBySax, const unsigned char bCoordNormalize, const unsigned char bClearData, const unsigned char bDataWash, const unsigned char bJointReserve)
{
	clock_t	dBeg, dEnd;
	int		nDur;

	if (strXmlFileArray.empty())
	{
		Log(g_lpszLogFile, "XML�ļ�����Ϊ��\n");
		return 0;
	}

	if (bClearData)
	{
		gData.Release();
	}

	dBeg=clock();
	for (int i=0; i<(int)strXmlFileArray.size(); i++)
	{
		Log(g_lpszLogFile, "����XML�ļ�: %s\n", strXmlFileArray[i].c_str());
		if (!ParseXmlBySax(gData, strXmlFileArray[i].c_str(), strFilterMark, strFilterKeyArray))
			Log(g_lpszLogFile, "        ����XML�ļ�����: %s\n", strXmlFileArray[i].c_str());
	}
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "����XML�ļ���ɣ���ʱ%d����\n", nDur);

	gData.Parse(bCoordNormalize, bDataWash, bJointReserve);

	return 1;
}

int	CGISXmlParser::Parse(CGISData& gData, const char* lpszFileName, std::string& strFilterMark, std::vector<std::string>& strFilterKeyArray, const int bParseBySax, const unsigned char bCoordNormalize)
{
	gData.Release();
	ParseXmlBySax(gData, lpszFileName, strFilterMark, strFilterKeyArray);
	gData.Parse(bCoordNormalize);

	return 1;
}
