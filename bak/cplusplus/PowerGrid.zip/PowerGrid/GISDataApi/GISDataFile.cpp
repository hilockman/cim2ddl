#include "StdAfx.h"
#include "GISData.h"
#include "GISDataFile.h"
#include "../../Common/StringCommon.h"

CGISDataFile::CGISDataFile(void)
{
}

CGISDataFile::~CGISDataFile(void)
{
}


int CGISDataFile::isComment(const char* lpszParser)
{
	if (strncmp(lpszParser, "//", 2) == 0)
	{
		return 1;
	}

	return 0;
}

int CGISDataFile::isTable(const char* lpszParser)
{
	if (strncmp(lpszParser, "<!", 2) == 0)
	{
		return 1;
	}
	if (strncmp(lpszParser, "</", 2) == 0)
	{
		return 2;
	}

	return 0;
}

int CGISDataFile::isColumn(const char* lpszParser)
{
	if (strncmp(lpszParser, "@", 1) == 0)
	{
		return 1;
	}

	return 0;
}

int CGISDataFile::isData(const char* lpszParser)
{
	if (strncmp(lpszParser, "#", 1) == 0)
	{
		return 1;
	}

	return 0;
}

int		CGISDataFile::ReadGISFile(CGISData* pGData, const char* lpszFileName)
{
	register int	i;
	char	szLine[10240];
	char*	lpszToken;
	std::vector<int>			nFieldIdxArray;
	std::vector<std::string>	strEleArray;

	int		nTable, nField;

	FILE*	fp=fopen(lpszFileName, "r");
	if (fp == NULL)
		return 0;

	pGData->Release();

	nTable=-1;
	while (!feof(fp))
	{
		memset(szLine, 0, 10240);
		fgets(szLine, 10240, fp);
		TrimEnd(szLine);
		TrimLeft(szLine);
		TrimRight(szLine);
		if (strlen(szLine) <= 0)
			continue;

		if (isComment(szLine))
			continue;
		if (isTable(szLine))
		{
			nFieldIdxArray.clear();
			nTable=-1;

			lpszToken=strtok(szLine, "<!> :\t\n");
			if (lpszToken != NULL)
			{
				for (i=0; i<pGData->GetGISTableNum(); i++)
				{
					if (stricmp(pGData->GetGISTableDesp(i), lpszToken) == 0)
					{
						nTable=i;
						break;
					}
				}
			}

			continue;
		}

		if (nTable < 0)
			continue;

		if (isColumn(szLine))
		{
			strEleArray.clear();
			lpszToken=strtok(szLine+1, " \t, \n");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL, " \t, \n");
			}

			nFieldIdxArray.resize(strEleArray.size());
			for (i=0; i<(int)strEleArray.size(); i++)
			{
				nFieldIdxArray[i]=-1;
				for (nField=0; nField<pGData->GetGISTableFieldNum(nTable); nField++)
				{
					if (stricmp(strEleArray[i].c_str(), pGData->GetGISTableFieldDesp(nTable, nField)) == 0)
					{
						nFieldIdxArray[i]=nField;
						break;
					}
				}
			}
		}
		else if (isData(szLine))
		{
			if (nFieldIdxArray.empty())
				continue;

			strEleArray.clear();
			lpszToken=strtok(szLine+1, "\t, \n");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL, "\t, \n");
			}

			pGData->InitData(nTable);
			for (nField=0; nField<(int)nFieldIdxArray.size(); nField++)
				pGData->FillData(nTable, nFieldIdxArray[nField], strEleArray[nField].c_str());
			pGData->AppendData(nTable, lpszFileName);
		}
	}

	fclose(fp);

	return 1;
}

void	CGISDataFile::SaveGISFile(CGISData* pGData, const char* lpszFileName)
{
	FILE*	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	int		nTable, nField, nRecord;
	for (nTable=0; nTable<pGData->GetGISTableNum(); nTable++)
	{
		fprintf(fp, "<!%s>\n", pGData->GetGISTableDesp(nTable));

		fprintf(fp, "@ ");
		for (nField=0; nField<pGData->GetGISTableFieldNum(nTable); nField++)
			fprintf(fp, "%s, ", pGData->GetGISTableFieldDesp(nTable, nField));
		fprintf(fp, "\n");

		for (nRecord=0; nRecord<pGData->GetGISTableRecordNum(nTable); nRecord++)
		{
			fprintf(fp, "# ");
			for (nField=0; nField<pGData->GetGISTableFieldNum(nTable); nField++)
				fprintf(fp, "%s, ", pGData->GetGISRecordValue(nTable, nField, nRecord).c_str());
			fprintf(fp, "\n");
		}
		fprintf(fp, "</%s>\n", pGData->GetGISTableDesp(nTable));
	}

	fflush(fp);
	fclose(fp);
}
