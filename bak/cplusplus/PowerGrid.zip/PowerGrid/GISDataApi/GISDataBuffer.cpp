#include "StdAfx.h"
#include "GISData.h"

CGISDataBuffer::CGISDataBuffer(void)
{
}

CGISDataBuffer::~CGISDataBuffer(void)
{
}

void	CGISDataBuffer::Init(const int nGisTable)
{
	switch (nGisTable)
	{
	case GIS_PSRType:					InitializePSRType			(m_PSRTypeBuf				);	break;
	case GIS_RDF:						InitializeRDF				(m_RDFBuf					);	break;
	case GIS_GeographicalRegion:		InitializeGeographicalRegion(m_GeographicalRegionBuf	);	break;
	case GIS_SubGeographicalRegion:		InitializeSubGeographicalRegion(m_SubGeographicalRegionBuf);	break;
	case GIS_BaseVoltage:				InitializeBaseVoltage		(m_BaseVoltageBuf			);	break;
	case GIS_Substation:				InitializeSubstation		(m_SubstationBuf			);	break;
	case GIS_Feeder:					InitializeFeeder			(m_FeederBuf				);	break;
	case GIS_CompositeSwitch:			InitializeCompositeSwitch	(m_CompositeSwitchBuf		);	break;
	case GIS_Breaker:					InitializeBreaker			(m_BreakerBuf				);	break;
	case GIS_Disconnector:				InitializeDisconnector		(m_DisconnectorBuf			);	break;
	case GIS_GroundDisconnector:		InitializeGroundDisconnector(m_GroundDisconnectorBuf	);	break;
	case GIS_LoadBreakSwitch:			InitializeLoadBreakSwitch	(m_LoadBreakSwitchBuf		);	break;
	case GIS_Fuse:						InitializeFuse				(m_FuseBuf					);	break;
	case GIS_BusbarSection:				InitializeBusbarSection		(m_BusbarSectionBuf			);	break;
	case GIS_Pole:						InitializePole				(m_PoleBuf					);	break;
	case GIS_Junction:					InitializeJunction			(m_JunctionBuf				);	break;
	case GIS_ACLineSegment:				InitializeACLineSegment		(m_ACLineSegmentBuf			);	break;
	case GIS_PowerTransformer:			InitializePowerTransformer	(m_PowerTransformerBuf		);	break;
	case GIS_ConnLine:					InitializeConnLine			(m_ConnLineBuf				);	break;
	case GIS_EnergyConsumer:			InitializeEnergyConsumer	(m_EnergyConsumerBuf		);	break;
	case GIS_Compensator:				InitializeCompensator		(m_CompensatorBuf			);	break;
	case GIS_Capacitor:					InitializeCapacitor			(m_CapacitorBuf				);	break;
	case GIS_Terminal:					InitializeTerminal			(m_TerminalBuf				);	break;
	case GIS_ConnectivityNode:			InitializeConnectivityNode	(m_ConnectivityNodeBuf		);	break;
	case GIS_Pipe:						InitializePipe				(m_PipeBuf					);	break;
	case GIS_PT:						InitializePT				(m_PTBuf					);	break;
	case GIS_CT:						InitializeCT				(m_CTBuf					);	break;
	case GIS_BLQ:						InitializeBLQ				(m_BLQBuf					);	break;
	case GIS_FaultIndicator:			InitializeFaultIndicator	(m_FaultIndicatorBuf		);	break;
	case GIS_PTCab:						InitializePTCab				(m_PTCabBuf					);	break;
	case GIS_Ground:					InitializeGround			(m_GroundBuf				);	break;
	case GIS_Other:						InitializeOther				(m_OtherBuf					);	break;
	case GIS_PTCABU:					InitializePTCABU			(m_PTCABUBuf				);	break;
	case GIS_KWGXB:						InitializeKWGXB				(m_KWGXBBuf					);	break;
	case GIS_PFWELL:					InitializePFWELL			(m_PFWELLBuf				);	break;
	case GIS_PFTUNN:					InitializePFTUNN			(m_PFTUNNBuf				);	break;
	case GIS_ZJ:						InitializeZJ				(m_ZJBuf					);	break;
		break;
	default:
		break;
	}
}

void	CGISDataBuffer::InitializeGraphic(tagGISGraphic& dBuf)
{
	dBuf.strCoordinate.clear();
	dBuf.strSymbolID.clear();
	dBuf.fSymbolSize=0;
	dBuf.fSymbolAngle=0;
	dBuf.strPath.clear();
}

void	CGISDataBuffer::InitializePSRType(tagGISPSRType& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strAlias.clear();
}

void	CGISDataBuffer::InitializeRDF(tagGISRDF& dBuf)
{
	dBuf.strRdf.clear();
	dBuf.strCim.clear();
}

void	CGISDataBuffer::InitializeGeographicalRegion(tagGISGeographicalRegion& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strName.clear();
}

void	CGISDataBuffer::InitializeSubGeographicalRegion(tagGISSubGeographicalRegion& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strName.clear();
	dBuf.strParentTag.clear();
	//dBuf.strParent.clear();
}

void	CGISDataBuffer::InitializeBaseVoltage(tagGISBaseVoltage& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.bIsDC=0;
	dBuf.fNominalVoltage=0;
}

void	CGISDataBuffer::InitializeSubstation(tagGISSubstation& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strAlias1.clear();
	dBuf.strAlias2.clear();
	dBuf.strHighVoltage.clear();
	dBuf.strComponent.clear();
	dBuf.strSubstationType.clear();
	dBuf.strModel.clear();
	dBuf.fMvaCapacity=0;
	dBuf.nPlanCharacter=0;
	dBuf.bPublic=0;
	dBuf.nBuildDate=0;
	dBuf.nRebuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.nTotalBay=0;
	dBuf.nFreeBay=0;
	dBuf.nTotalOutline=0;
	dBuf.nInuseOutline=0;
	dBuf.fEqX=0.1f;
	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_Customer=0;
	dBuf.ri_load_rerr=0;
	dBuf.ri_load_trep=0;
	dBuf.ri_load_rchk=0;
	dBuf.ri_load_tchk=0;
	dBuf.ei_Invest=0;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.bValid=0;
	dBuf.bVirtual=0;
}

void	CGISDataBuffer::InitializeFeeder(tagGISFeeder& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strDesp.clear();
	dBuf.strParentTag.clear();

	dBuf.fV=0;			
	dBuf.fP=0;			
	dBuf.fQ=0;			
	dBuf.fI=0;			
	dBuf.fFactor=0;	

	//dBuf.strParent.clear();
}

void	CGISDataBuffer::InitializeCompositeSwitch(tagGISCompositeSwitch& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strCompositeSwitchType.clear();
	dBuf.strParentTag.clear();
}

void	CGISDataBuffer::InitializeBreaker(tagGISBreaker& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strUsage.clear();
	dBuf.bNormalOpen=0;
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.nStatus=0;
	dBuf.strModel.clear();
	dBuf.nBreakerType=0;
	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_RSwitch=0;
	dBuf.ri_TSwitch=0;
	dBuf.ei_Invest=0;
	dBuf.nRTLevel=0;
	dBuf.nCommMode=0;
	dBuf.nPlanCharacter=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.strParent.clear();
	dBuf.strNodeI.clear();
	dBuf.strNodeZ.clear();
	dBuf.nSubIdx=-1;
	dBuf.nNodeI=-1;
	dBuf.nNodeZ=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
	dBuf.bInSubstation=1;
}

void	CGISDataBuffer::InitializeDisconnector(tagGISDisconnector& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.bNormalOpen=0;
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.nStatus=0;
	dBuf.strModel.clear();
	dBuf.nBreakerType=0;
	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_RSwitch=0;
	dBuf.ri_TSwitch=0;
	dBuf.ei_Invest=0;
	dBuf.nRTLevel=0;
	dBuf.nCommMode=0;
	dBuf.nPlanCharacter=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.strParent.clear();
	dBuf.strNodeI.clear();
	dBuf.strNodeZ.clear();

	dBuf.nSubIdx=-1;
	dBuf.nNodeI=-1;
	dBuf.nNodeZ=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
	dBuf.bInSubstation=1;
}

void	CGISDataBuffer::InitializeLoadBreakSwitch		(tagGISLoadBreakSwitch		& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.bNormalOpen=0;
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.nStatus=0;	//ң��
	dBuf.strModel.clear();
	dBuf.nBreakerType=0;
	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_RSwitch=0;
	dBuf.ri_TSwitch=0;
	dBuf.ei_Invest=0;
	dBuf.nRTLevel=0;
	dBuf.nCommMode=0;
	dBuf.nPlanCharacter=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.strParent.clear();
	dBuf.strNodeI.clear();
	dBuf.strNodeZ.clear();
	dBuf.nSubIdx=-1;
	dBuf.nNodeI=-1;
	dBuf.nNodeZ=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
}

void	CGISDataBuffer::InitializeFuse					(tagGISFuse					& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.nStatus=0;	//ң��
	dBuf.strModel.clear();
	dBuf.nBreakerType=0;
	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_RSwitch=0;
	dBuf.ri_TSwitch=0;
	dBuf.ei_Invest=0;
	dBuf.nRTLevel=0;
	dBuf.nCommMode=0;
	dBuf.nPlanCharacter=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.strParent.clear();
	dBuf.strNodeI.clear();
	dBuf.strNodeZ.clear();
	dBuf.nSubIdx=-1;
	dBuf.nNodeI=-1;
	dBuf.nNodeZ=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
}

void	CGISDataBuffer::InitializeGroundDisconnector(tagGISGroundDisconnector& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.bNormalOpen=0;
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();

	dBuf.strModel.clear();
	dBuf.nRTLevel=0;
	dBuf.nCommMode=0;
	dBuf.nPlanCharacter=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.strParent.clear();
	dBuf.strNode.clear();

	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
	dBuf.nStatus=0;	//ң��
}

void	CGISDataBuffer::InitializeBusbarSection(tagGISBusbarSection& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strParent.clear();
	dBuf.strNode.clear();

	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_Customer=0;
	dBuf.ri_load_rerr=0;
	dBuf.ri_load_trep=0;
	dBuf.ri_load_rchk=0;
	dBuf.ri_load_tchk=0;
	dBuf.ei_Invest=0;

	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	InitializeGraphic(dBuf.gData);
}

void	CGISDataBuffer::InitializePole					(tagGISPole					& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strAlias.clear();
	dBuf.strDesp.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();

	//	��չ����
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.nPlanCharacter=0;

	dBuf.strParent.clear();
	dBuf.strNode.clear();

	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	//	�ڲ�����
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
	dBuf.bValid=0;
}

void	CGISDataBuffer::InitializeJunction(tagGISJunction& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.nPlanCharacter=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.strParent.clear();
	dBuf.strNode.clear();
	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
	dBuf.bValid=0;
}

void	CGISDataBuffer::InitializeACLineSegment(tagGISACLineSegment& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strAssetModel.clear();
	dBuf.fLength=0;
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strLineTag.clear();
	dBuf.nLineType=0;				
	dBuf.nPlanCharacter=0;
	dBuf.nRunStatus=0;
	dBuf.nAreaCategory=0;
	dBuf.r=0;					
	dBuf.x=0;					
	dBuf.g=0;					
	dBuf.b=0;					
	dBuf.ri_UnitRerr=0;
	dBuf.ri_UnitTrep=0;
	dBuf.ri_UnitRchk=0;
	dBuf.ri_UnitTchk=0;
	dBuf.ei_UnitInvest=0;
	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_RSwitch=0;
	dBuf.ri_TSwitch=0;
	dBuf.ri_TDelay=0;
	dBuf.ri_Customer=0;
	dBuf.ri_load_rerr=0;
	dBuf.ri_load_trep=0;
	dBuf.ri_load_rchk=0;
	dBuf.ri_load_tchk=0;
	dBuf.ei_Invest=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.iStatus=0;
	dBuf.zStatus=0;
	dBuf.strFeeder.clear();
	dBuf.strNodeI.clear();
	dBuf.strNodeZ.clear();
	dBuf.strSubITag.clear();
	dBuf.strSubZTag.clear();
	dBuf.nIJointEquipmentType=0;
	dBuf.nZJointEquipmentType=0;
	dBuf.strIJointEquipmentTag.clear();
	dBuf.strZJointEquipmentTag.clear();
	dBuf.nContainerIdx=-1;
	dBuf.nNodeI=-1;
	dBuf.nNodeZ=-1;
	dBuf.nSubI=-1;
	dBuf.nSubZ=-1;
	dBuf.bFlag=0;
	InitializeGraphic(dBuf.gData);
}

void	CGISDataBuffer::InitializePowerTransformer(tagGISPowerTransformer& dBuf)
{
	register int	i;
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();

	//	��չ��Ϣ
	dBuf.strModel.clear();
	dBuf.nPlanCharacter=0;
	dBuf.bDistribution=0;
	dBuf.bPublic=0;
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.nManuDate=0;
	dBuf.nConstructDate=0;

	dBuf.strParent.clear();
	for (i=0; i<3; i++)
	{
		dBuf.strNodeArray[i].clear();
		dBuf.strVoltTagArray[i].clear();
	}

	dBuf.ri_Rerr=0;
	dBuf.ri_Trep=0;
	dBuf.ri_Rchk=0;
	dBuf.ri_Tchk=0;
	dBuf.ri_Tfloc=0;
	dBuf.ri_RSwitch=0;
	dBuf.ri_TSwitch=0;
	dBuf.ri_Customer=0;
	dBuf.ri_load_rerr=0;
	dBuf.ri_load_trep=0;
	dBuf.ri_load_rchk=0;
	dBuf.ri_load_tchk=0;
	dBuf.ei_Invest=0;

	dBuf.nSubIdx=-1;
	for (i=0; i<3; i++)
		dBuf.nNodeArray[i]=-1;
	dBuf.nWindNum=0;

	//	�ڲ�����
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	for (i=0; i<3; i++)
		memset(&dBuf.ptVertArray[i], 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
	dBuf.fP=0;	
	dBuf.fQ=0;	
	dBuf.bFlag=0;
	InitializeGraphic(dBuf.gData);
}

void	CGISDataBuffer::InitializeConnLine(tagGISConnLine& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strParent.clear();
	dBuf.strNodeI.clear();
	dBuf.strNodeZ.clear();
	dBuf.nSubIdx=-1;
	dBuf.nNodeI=-1;
	dBuf.nNodeZ=-1;
	InitializeGraphic(dBuf.gData);
	dBuf.bFlag=0;
}

void	CGISDataBuffer::InitializeEnergyConsumer(tagGISEnergyConsumer& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();

	dBuf.strBelongPSRTag.clear();
	dBuf.bIsPublic=0;
	dBuf.fP=0;
	dBuf.fQ=0;
	dBuf.fCustomNum=0;

	dBuf.strParent.clear();			//	�洢��վ�����ڽ������Ʒ�װ
	dBuf.strNode.clear();

	dBuf.nBelongPSRType=0;
	dBuf.strBelongPSRName.clear();
	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
}

void	CGISDataBuffer::InitializeCompensator(tagGISCompensator& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strParent.clear();			//	�洢��վ�����ڽ������Ʒ�װ
	dBuf.strNode.clear();
	dBuf.strSeriesNode.clear();

	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	dBuf.nSeriesNode=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
}

void	CGISDataBuffer::InitializeCapacitor(tagGISCapacitor& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strUnit.clear();
	dBuf.strParentTag.clear();
	dBuf.strBaseVoltageTag.clear();

	dBuf.strParent.clear();			//	�洢��վ�����ڽ������Ʒ�װ
	dBuf.strNode.clear();

	dBuf.nSubIdx=-1;
	dBuf.nNode=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
	dBuf.fSize=0;
}

void	CGISDataBuffer::InitializeTerminal(tagGISTerminal& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strParentTag.clear();
	dBuf.strNodeTag.clear();
	dBuf.nNode=-1;
	dBuf.bFlag=0;
}

void	CGISDataBuffer::InitializeConnectivityNode(tagGISConnectivityNode& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strBaseVoltageTag.clear();
	//memset(&dBuf.ptVert, 0, sizeof(tagGISVertex));
	dBuf.bFlaged=0;
}

void	CGISDataBuffer::InitializePipe(tagGISPipe& dBuf)
{
	register int	i;
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strName.clear();
	dBuf.strModel.clear();
	dBuf.nBuildDate=0;
	dBuf.nReBuildDate=0;
	dBuf.nOutageDate=0;
	dBuf.nRunTimeSpan=0;
	dBuf.nPlanCharacter=0;
	dBuf.nMaxHVCableNum=0;
	dBuf.nMaxMVCableNum=0;
	dBuf.nMaxLVCableNum=0;

	dBuf.nHVCableNum=0;
	dBuf.nMVCableNum=0;
	dBuf.nLVCableNum=0;
	for (i=0; i<4; i++)
		dBuf.strHVCable[i].clear();
	for (i=0; i<8; i++)
		dBuf.strMVCable[i].clear();
	for (i=0; i<32; i++)
		dBuf.strLVCable[i].clear();
}

void	CGISDataBuffer::InitializePT					(tagGISPT					& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
}

void	CGISDataBuffer::InitializeCT					(tagGISCT					& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
}

void	CGISDataBuffer::InitializeBLQ					(tagGISBLQ					& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
}

void	CGISDataBuffer::InitializeFaultIndicator		(tagGISFaultIndicator		& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strParentTag.clear();
}

void	CGISDataBuffer::InitializePTCab					(tagGISPTCab				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
}

void	CGISDataBuffer::InitializeGround				(tagGISGround				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strParentTag.clear();
}

void	CGISDataBuffer::InitializeOther					(tagGISOther				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strParentTag.clear();
}

void	CGISDataBuffer::InitializePTCABU				(tagGISPTCABU				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
}

void	CGISDataBuffer::InitializeKWGXB					(tagGISKWGXB				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
}

void	CGISDataBuffer::InitializePFWELL				(tagGISPFWELL				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
}
void	CGISDataBuffer::InitializePFTUNN				(tagGISPFTUNN				& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
}

void	CGISDataBuffer::InitializeZJ(tagGISZJ& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strPSRTypeTag.clear();
	dBuf.strObjectID.clear();
	dBuf.fTextHeight=10;
	dBuf.strName.clear();
	dBuf.strParentTag.clear();
	dBuf.strParent.clear();
	dBuf.nSubIdx=-1;
	InitializeGraphic(dBuf.gData);
	memset(&dBuf.ptLoc, 0, sizeof(tagGISVertex));
}

int		CGISDataBuffer::Fill(const int nGisTable, const int nField, const char* lpszElementValue)
{
	if (nField < 0)
		return 0;
	switch (nGisTable)
	{
	case GIS_PSRType:					SetGISPSRType				(m_PSRTypeBuf,					nField, lpszElementValue);	break;
	case GIS_RDF:						SetGISRDF					(m_RDFBuf,						nField, lpszElementValue);	break;
	case GIS_GeographicalRegion:		SetGISGeographicalRegion	(m_GeographicalRegionBuf,		nField, lpszElementValue);	break;
	case GIS_SubGeographicalRegion:		SetGISSubGeographicalRegion	(m_SubGeographicalRegionBuf,	nField, lpszElementValue);	break;
	case GIS_BaseVoltage:				SetGISBaseVoltage			(m_BaseVoltageBuf,				nField, lpszElementValue);	break;
	case GIS_Substation:				SetGISSubstation			(m_SubstationBuf,				nField, lpszElementValue);	break;
	case GIS_Feeder:					SetGISFeeder				(m_FeederBuf,					nField, lpszElementValue);	break;
	case GIS_CompositeSwitch:			SetGISCompositeSwitch		(m_CompositeSwitchBuf,			nField, lpszElementValue);	break;
	case GIS_Breaker:					SetGISBreaker				(m_BreakerBuf,					nField, lpszElementValue);	break;
	case GIS_Disconnector:				SetGISDisconnector			(m_DisconnectorBuf,				nField, lpszElementValue);	break;
	case GIS_GroundDisconnector:		SetGISGroundDisconnector	(m_GroundDisconnectorBuf,		nField, lpszElementValue);	break;
	case GIS_LoadBreakSwitch:			SetGISLoadBreakSwitch		(m_LoadBreakSwitchBuf,			nField, lpszElementValue);	break;
	case GIS_Fuse:						SetGISFuse					(m_FuseBuf,						nField, lpszElementValue);	break;
	case GIS_ACLineSegment:				SetGISACLineSegment			(m_ACLineSegmentBuf,			nField, lpszElementValue);	break;
	case GIS_PowerTransformer:			SetGISPowerTransformer		(m_PowerTransformerBuf,			nField, lpszElementValue);	break;
	case GIS_ConnLine:					SetGISConnLine				(m_ConnLineBuf,					nField, lpszElementValue);	break;
	case GIS_BusbarSection:				SetGISBusbarSection			(m_BusbarSectionBuf,			nField, lpszElementValue);	break;
	case GIS_Pole:						SetGISPole					(m_PoleBuf,						nField, lpszElementValue);	break;
	case GIS_Junction:					SetGISJunction				(m_JunctionBuf,					nField, lpszElementValue);	break;
	case GIS_EnergyConsumer:			SetGISEnergyConsumer		(m_EnergyConsumerBuf,			nField, lpszElementValue);	break;
	case GIS_Compensator:				SetGISCompensator			(m_CompensatorBuf,				nField, lpszElementValue);	break;
	case GIS_Capacitor:					SetGISCapacitor				(m_CapacitorBuf,				nField, lpszElementValue);	break;
	case GIS_Terminal:					SetGISTerminal				(m_TerminalBuf,					nField, lpszElementValue);	break;
	case GIS_ConnectivityNode:			SetGISConnectivityNode		(m_ConnectivityNodeBuf,			nField, lpszElementValue);	break;
	case GIS_Pipe:						SetGISPipe					(m_PipeBuf,						nField, lpszElementValue);	break;
	case GIS_PT:						SetGISPT					(m_PTBuf,						nField, lpszElementValue);	break;
	case GIS_CT:						SetGISCT					(m_CTBuf,						nField, lpszElementValue);	break;
	case GIS_BLQ:						SetGISBLQ					(m_BLQBuf,						nField, lpszElementValue);	break;
	case GIS_FaultIndicator:			SetGISFaultIndicator		(m_FaultIndicatorBuf,			nField, lpszElementValue);	break;
	case GIS_PTCab:						SetGISPTCab					(m_PTCabBuf,					nField, lpszElementValue);	break;
	case GIS_Ground:					SetGISGround				(m_GroundBuf,					nField, lpszElementValue);	break;
	case GIS_Other:						SetGISOther					(m_OtherBuf,					nField, lpszElementValue);	break;
	case GIS_PTCABU:					SetGISPTCABU				(m_PTCABUBuf,					nField, lpszElementValue);	break;
	case GIS_KWGXB:						SetGISKWGXB					(m_KWGXBBuf,					nField, lpszElementValue);	break;
	case GIS_PFWELL:					SetGISPFWELL				(m_PFWELLBuf,					nField, lpszElementValue);	break;
	case GIS_PFTUNN:					SetGISPFTUNN				(m_PFTUNNBuf,					nField, lpszElementValue);	break;
	case GIS_ZJ:						SetGISZJ					(m_ZJBuf,						nField, lpszElementValue);	break;
	default:
		return 0;
		break;
	}
	return 1;
}

std::string	CGISDataBuffer::toString(tagGISVertex& ptVert)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);
	sprintf(szValue, "(%f, %f)", ptVert.fX, ptVert.fY);
	return szValue;
}

std::string	CGISDataBuffer::toString(const std::string& strBuf)
{
	return strBuf;
}

std::string	CGISDataBuffer::toString(const char* lpszBuf)
{
	return lpszBuf;
}

std::string	CGISDataBuffer::toString(const double fBuf)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);
	sprintf(szValue, "%f", fBuf);
	return szValue;
}

std::string	CGISDataBuffer::toString(const float fBuf)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);
	sprintf(szValue, "%f", fBuf);
	return szValue;
}

std::string	CGISDataBuffer::toString(const int nBuf)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);
	sprintf(szValue, "%d", nBuf);
	return szValue;
}

std::string	CGISDataBuffer::toString(const short nBuf)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);
	sprintf(szValue, "%d", nBuf);
	return szValue;
}

std::string	CGISDataBuffer::toString(const unsigned char bBuf)
{
	char	szValue[MDB_CHARLEN_LONG];
	memset(szValue, 0, MDB_CHARLEN_LONG);
	sprintf(szValue, "%d", bBuf);
	return szValue;
}

void	CGISDataBuffer::toValue(tagGISVertex& ptVert, const char* lpszValue)
{
	register int	i;
	char	szChar[MDB_CHARLEN_LONG];
	int		nChar;
	std::vector<std::string>	strEleArray;

	nChar=0;
	strEleArray.clear();
	for (i=0; i<(int)strlen(lpszValue); i++)
	{
		if (lpszValue[i] == ' ' || lpszValue[i] == ',' || lpszValue[i] == '(' || lpszValue[i] == ')')
		{
			if (nChar > 0)
			{
				szChar[nChar++]='\0';
				strEleArray.push_back(szChar);
				nChar=0;
			}
		}

		if (lpszValue[i] != ' ')
		{
			szChar[nChar++]=lpszValue[i];
		}
	}
	if (nChar > 0)
	{
		szChar[nChar++]='\0';
		strEleArray.push_back(szChar);
		nChar=0;
	}

	if (strEleArray.size() == 2)
	{
		nChar=0;
		ptVert.fX=atoi(strEleArray[nChar++].c_str());
		ptVert.fX=atoi(strEleArray[nChar++].c_str());
	}
}

void	CGISDataBuffer::toValue(std::string& strValue, const char* lpszValue)
{
	strValue=lpszValue;
}

void	CGISDataBuffer::toValue(char* lpszRetValue, const char* lpszInValue)
{
	strcpy(lpszRetValue, lpszInValue);
}

void	CGISDataBuffer::toValue(double& fValue, const char* lpszValue)
{
	fValue=atof(lpszValue);
}

void	CGISDataBuffer::toValue(float& fValue, const char* lpszValue)
{
	fValue=(float)atof(lpszValue);
}

void	CGISDataBuffer::toValue(int& nValue, const char* lpszValue)
{
	nValue=atoi(lpszValue);
}

void	CGISDataBuffer::toValue(short& nValue, const char* lpszValue)
{
	nValue=(short)atoi(lpszValue);
}

void	CGISDataBuffer::toValue(unsigned char& bValue, const char* lpszValue)
{
	bValue=(unsigned char)atoi(lpszValue);
}

const std::string CGISDataBuffer::GetGISPSRType(tagGISPSRType& gData, const int nField)
{
	switch (nField)
	{
	case		GISPSRType_ResourceID	:return toString(gData.strResourceID);	break;
	case		GISPSRType_ObjectID	:return toString(gData.strObjectID);		break;
	case		GISPSRType_Name		:return toString(gData.strName);			break;
	case		GISPSRType_Alias		:return toString(gData.strAlias);		break;
	}
	return "";
}

void CGISDataBuffer::SetGISPSRType(tagGISPSRType& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPSRType_ResourceID	:toValue(gData.strResourceID, strValue.c_str());	break;
	case	GISPSRType_ObjectID		:toValue(gData.strObjectID	, strValue.c_str());	break;
	case	GISPSRType_Name			:toValue(gData.strName		, strValue.c_str());	break;
	case	GISPSRType_Alias		:toValue(gData.strAlias		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISRDF(tagGISRDF& gData, const int nField)
{
	switch (nField)
	{
	case		GISRDF_XmlnsRDF	:return toString(gData.strRdf);	break;
	case		GISRDF_XmlnsCIM	:return toString(gData.strCim);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISRDF(tagGISRDF& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISRDF_XmlnsRDF	:toValue(gData.strRdf	, strValue.c_str());	break;
	case	GISRDF_XmlnsCIM	:toValue(gData.strCim	, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISGeographicalRegion(tagGISGeographicalRegion& gData, const int nField)
{
	switch (nField)
	{
	case	GISGeographicalRegion_ResourceID	:return toString(gData.strResourceID);	break;
	case	GISGeographicalRegion_Name			:return toString(gData.strName);			break;
	}
	return "";
}

void CGISDataBuffer::SetGISGeographicalRegion(tagGISGeographicalRegion& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISGeographicalRegion_ResourceID	:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISGeographicalRegion_Name			:toValue(gData.strName				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISSubGeographicalRegion(tagGISSubGeographicalRegion& gData, const int nField)
{
	switch (nField)
	{
	case	GISSubGeographicalRegion_ResourceID		:return toString(gData.strResourceID);	break;
	case	GISSubGeographicalRegion_Name			:return toString(gData.strName);			break;
	case	GISSubGeographicalRegion_ParentTag		:return toString(gData.strParentTag);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISSubGeographicalRegion(tagGISSubGeographicalRegion& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISSubGeographicalRegion_ResourceID		:toValue(gData.strResourceID	, strValue.c_str());	break;
	case	GISSubGeographicalRegion_Name			:toValue(gData.strName			, strValue.c_str());	break;
	case	GISSubGeographicalRegion_ParentTag		:toValue(gData.strParentTag		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISBaseVoltage(tagGISBaseVoltage& gData, const int nField)
{
	switch (nField)
	{
	case	GISBaseVoltage_ResourceID			:return toString(gData.strResourceID	);	break;
	case	GISBaseVoltage_ObjectID				:return toString(gData.strObjectID		);	break;
	case	GISBaseVoltage_Name					:return toString(gData.strName			);	break;
	case	GISBaseVoltage_DC:					return toString(gData.bIsDC				);	break;
	case	GISBaseVoltage_NominalVoltage		:return toString(gData.fNominalVoltage	);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISBaseVoltage(tagGISBaseVoltage& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISBaseVoltage_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISBaseVoltage_ObjectID				:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISBaseVoltage_Name					:toValue(gData.strName				, strValue.c_str());	break;
	case	GISBaseVoltage_DC					:toValue(gData.bIsDC				, strValue.c_str());	break;
	case	GISBaseVoltage_NominalVoltage		:toValue(gData.fNominalVoltage		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISSubstation(tagGISSubstation& gData, const int nField)
{
	switch (nField)
	{
	case	GISSubstation_ResourceID		:return toString(gData.strResourceID		);	break;
	case	GISSubstation_PSRTypeTag		:return toString(gData.strPSRTypeTag		);	break;
	case	GISSubstation_ObjectID			:return toString(gData.strObjectID			);	break;
	case	GISSubstation_Name				:return toString(gData.strName				);	break;
	case	GISSubstation_Unit				:return toString(gData.strUnit				);	break;
	case	GISSubstation_ParentTag			:return toString(gData.strParentTag			);	break;
	case	GISSubstation_Alias1			:return toString(gData.strAlias1			);	break;
	case	GISSubstation_Alias2			:return toString(gData.strAlias2			);	break;
	case	GISSubstation_HighVoltage		:return toString(gData.strHighVoltage		);	break;
	case	GISSubstation_Component			:return toString(gData.strComponent			);	break;
	case	GISSubstation_SubstationType	:return toString(gData.strSubstationType	);	break;
	case	GISSubstation_Model				:return toString(gData.strModel				);	break;
	case	GISSubstation_MvaCapacity		:return toString(gData.fMvaCapacity			);	break;
	case	GISSubstation_PlanCharacter		:return toString(gData.nPlanCharacter		);	break;
	case	GISSubstation_Public			:return toString(gData.bPublic				);	break;
	case	GISSubstation_BuildDate			:return toString(gData.nBuildDate			);	break;
	case	GISSubstation_RebuildDate		:return toString(gData.nRebuildDate			);	break;
	case	GISSubstation_OutageDate		:return toString(gData.nOutageDate			);	break;
	case	GISSubstation_RunTimeSpan		:return toString(gData.nRunTimeSpan			);	break;
	case	GISSubstation_TotalBay			:return toString(gData.nTotalBay			);	break;
	case	GISSubstation_FreeBay			:return toString(gData.nFreeBay				);	break;
	case	GISSubstation_TotalOutline		:return toString(gData.nTotalOutline		);	break;
	case	GISSubstation_InuseOutline		:return toString(gData.nInuseOutline		);	break;
	case	GISSubstation_EqX				:return toString(gData.fEqX					);	break;

	case	GISSubstation_ri_rerr			:return	toString(gData.ri_Rerr				);	break;
	case	GISSubstation_ri_trep			:return	toString(gData.ri_Trep				);	break;
	case	GISSubstation_ri_rchk			:return	toString(gData.ri_Rchk				);	break;
	case	GISSubstation_ri_tchk			:return	toString(gData.ri_Tchk				);	break;
	case	GISSubstation_ri_tfloc			:return	toString(gData.ri_Tfloc				);	break;
	case	GISSubstation_ri_customer		:return	toString(gData.ri_Customer			);	break;
	case	GISSubstation_ri_load_rerr		:return	toString(gData.ri_load_rerr			);	break;
	case	GISSubstation_ri_load_trep		:return	toString(gData.ri_load_trep			);	break;
	case	GISSubstation_ri_load_rchk		:return	toString(gData.ri_load_rchk			);	break;
	case	GISSubstation_ri_load_tchk		:return	toString(gData.ri_load_tchk			);	break;
	case	GISSubstation_ei_invest			:return	toString(gData.ei_Invest			);	break;

	case	GISSubstation_Coordinate		:return toString(gData.gData.strCoordinate	);	break;
	case	GISSubstation_SymbolID			:return toString(gData.gData.strSymbolID	);	break;
	case	GISSubstation_SymbolSize		:return toString(gData.gData.fSymbolSize	);	break;
	case	GISSubstation_SymbolAngle		:return toString(gData.gData.fSymbolAngle	);	break;
	case	GISSubstation_GraphPath			:return toString(gData.gData.strPath		);	break;
	case	GISSubstation_Location			:return toString(gData.ptLoc				);	break;
	case	GISSubstation_Valid				:return toString(gData.bValid				);	break;
	case	GISSubstation_Virtual			:return toString(gData.bVirtual				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISSubstation(tagGISSubstation& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISSubstation_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISSubstation_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISSubstation_ObjectID			:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISSubstation_Name				:toValue(gData.strName					, strValue.c_str());	break;
	case	GISSubstation_Unit				:toValue(gData.strUnit					, strValue.c_str());	break;
	case	GISSubstation_ParentTag			:toValue(gData.strParentTag				, strValue.c_str());	break;
	case	GISSubstation_Alias1			:toValue(gData.strAlias1				, strValue.c_str());	break;
	case	GISSubstation_Alias2			:toValue(gData.strAlias2				, strValue.c_str());	break;
	case	GISSubstation_HighVoltage		:toValue(gData.strHighVoltage			, strValue.c_str());	break;
	case	GISSubstation_Component			:toValue(gData.strComponent				, strValue.c_str());	break;
	case	GISSubstation_SubstationType	:toValue(gData.strSubstationType		, strValue.c_str());	break;
	case	GISSubstation_Model				:toValue(gData.strModel					, strValue.c_str());	break;
	case	GISSubstation_MvaCapacity		:toValue(gData.fMvaCapacity				, strValue.c_str());	break;
	case	GISSubstation_PlanCharacter		:toValue(gData.nPlanCharacter			, strValue.c_str());	break;
	case	GISSubstation_Public			:toValue(gData.bPublic					, strValue.c_str());	break;
	case	GISSubstation_BuildDate			:toValue(gData.nBuildDate				, strValue.c_str());	break;
	case	GISSubstation_RebuildDate		:toValue(gData.nRebuildDate				, strValue.c_str());	break;
	case	GISSubstation_OutageDate		:toValue(gData.nOutageDate				, strValue.c_str());	break;
	case	GISSubstation_RunTimeSpan		:toValue(gData.nRunTimeSpan				, strValue.c_str());	break;
	case	GISSubstation_TotalBay			:toValue(gData.nTotalBay				, strValue.c_str());	break;
	case	GISSubstation_FreeBay			:toValue(gData.nFreeBay					, strValue.c_str());	break;
	case	GISSubstation_TotalOutline		:toValue(gData.nTotalOutline			, strValue.c_str());	break;
	case	GISSubstation_InuseOutline		:toValue(gData.nInuseOutline			, strValue.c_str());	break;
	case	GISSubstation_EqX				:toValue(gData.fEqX						, strValue.c_str());	break;

	case	GISSubstation_ri_rerr			:toValue(gData.ri_Rerr					, strValue.c_str());	break;
	case	GISSubstation_ri_trep			:toValue(gData.ri_Trep					, strValue.c_str());	break;
	case	GISSubstation_ri_rchk			:toValue(gData.ri_Rchk					, strValue.c_str());	break;
	case	GISSubstation_ri_tchk			:toValue(gData.ri_Tchk					, strValue.c_str());	break;
	case	GISSubstation_ri_tfloc			:toValue(gData.ri_Tfloc					, strValue.c_str());	break;
	case	GISSubstation_ri_customer		:toValue(gData.ri_Customer				, strValue.c_str());	break;
	case	GISSubstation_ri_load_rerr		:toValue(gData.ri_load_rerr				, strValue.c_str());	break;
	case	GISSubstation_ri_load_trep		:toValue(gData.ri_load_trep				, strValue.c_str());	break;
	case	GISSubstation_ri_load_rchk		:toValue(gData.ri_load_rchk				, strValue.c_str());	break;
	case	GISSubstation_ri_load_tchk		:toValue(gData.ri_load_tchk				, strValue.c_str());	break;
	case	GISSubstation_ei_invest			:toValue(gData.ei_Invest				, strValue.c_str());	break;

	case	GISSubstation_Coordinate		:toValue(gData.gData.strCoordinate		, strValue.c_str());	break;
	case	GISSubstation_SymbolID			:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISSubstation_SymbolSize		:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISSubstation_SymbolAngle		:toValue(gData.gData.fSymbolAngle		, strValue.c_str());	break;
	case	GISSubstation_GraphPath			:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISSubstation_Location			:toValue(gData.ptLoc					, strValue.c_str());	break;
	case	GISSubstation_Valid				:toValue(gData.bValid					, strValue.c_str());	break;
	case	GISSubstation_Virtual			:toValue(gData.bVirtual					, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISFeeder(tagGISFeeder& gData, const int nField)
{
	switch (nField)
	{
	case	GISFeeder_ResourceID		:return toString(gData.strResourceID	);	break;
	case	GISFeeder_PSRTypeTag		:return toString(gData.strPSRTypeTag	);	break;
	case	GISFeeder_ObjectID			:return toString(gData.strObjectID		);	break;
	case	GISFeeder_Name				:return toString(gData.strName			);	break;
	case	GISFeeder_Desp				:return toString(gData.strDesp			);	break;
	case	GISFeeder_ParentTag			:return toString(gData.strParentTag		);	break;
	case	GISFeeder_V					:return toString(gData.fV				);	break;
	case	GISFeeder_P					:return toString(gData.fP				);	break;
	case	GISFeeder_Q					:return toString(gData.fQ				);	break;
	case	GISFeeder_I					:return toString(gData.fI				);	break;
	case	GISFeeder_Factor			:return toString(gData.fFactor			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISFeeder(tagGISFeeder& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISFeeder_ResourceID		:toValue(gData.strResourceID	, strValue.c_str());	break;
	case	GISFeeder_PSRTypeTag		:toValue(gData.strPSRTypeTag	, strValue.c_str());	break;
	case	GISFeeder_ObjectID			:toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISFeeder_Name				:toValue(gData.strName			, strValue.c_str());	break;
	case	GISFeeder_Desp				:toValue(gData.strDesp			, strValue.c_str());	break;
	case	GISFeeder_ParentTag			:toValue(gData.strParentTag		, strValue.c_str());	break;
	case	GISFeeder_V					:toValue(gData.fV				, strValue.c_str());	break;
	case	GISFeeder_P					:toValue(gData.fP				, strValue.c_str());	break;
	case	GISFeeder_Q					:toValue(gData.fQ				, strValue.c_str());	break;
	case	GISFeeder_I					:toValue(gData.fI				, strValue.c_str());	break;
	case	GISFeeder_Factor			:toValue(gData.fFactor			, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISCompositeSwitch(tagGISCompositeSwitch& gData, const int nField)
{
	switch (nField)
	{
	case	GISCompositeSwitch_ResourceID			:return toString(gData.strResourceID			);	break;
	case	GISCompositeSwitch_PSRTypeTag			:return toString(gData.strPSRTypeTag			);	break;
	case	GISCompositeSwitch_ObjectID				:return toString(gData.strObjectID				);	break;
	case	GISCompositeSwitch_Name					:return toString(gData.strName					);	break;
	case	GISCompositeSwitch_CompositeSwitchType	:return toString(gData.strCompositeSwitchType	);	break;
	case	GISCompositeSwitch_ParentTag			:return toString(gData.strParentTag				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISCompositeSwitch(tagGISCompositeSwitch& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISCompositeSwitch_ResourceID			:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISCompositeSwitch_PSRTypeTag			:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISCompositeSwitch_ObjectID				:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISCompositeSwitch_Name					:toValue(gData.strName					, strValue.c_str());	break;
	case	GISCompositeSwitch_CompositeSwitchType	:toValue(gData.strCompositeSwitchType	, strValue.c_str());	break;
	case	GISCompositeSwitch_ParentTag			:toValue(gData.strParentTag				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISBreaker(tagGISBreaker& gData, const int nField)
{
	switch (nField)
	{
	case	GISBreaker_ResourceID		:return toString(gData.strResourceID		);	break;
	case	GISBreaker_PSRTypeTag		:return toString(gData.strPSRTypeTag		);	break;
	case	GISBreaker_ObjectID			:return toString(gData.strObjectID			);	break;
	case	GISBreaker_Name				:return toString(gData.strName				);	break;
	case	GISBreaker_Unit				:return toString(gData.strUnit				);	break;
	case	GISBreaker_Usage			:return toString(gData.strUsage				);	break;
	case	GISBreaker_NormalOpen		:return toString(gData.bNormalOpen			);	break;
	case	GISBreaker_ParentTag		:return toString(gData.strParentTag			);	break;
	case	GISBreaker_BaseVoltageTag	:return toString(gData.strBaseVoltageTag	);	break;
	case	GISBreaker_Status			:return toString(gData.nStatus				);	break;
	case	GISBreaker_Model			:return toString(gData.strModel				);	break;
	case	GISBreaker_BreakerType		:return toString(gData.nBreakerType			);	break;

	case	GISBreaker_ri_rerr			:return	toString(gData.ri_Rerr				);	break;
	case	GISBreaker_ri_trep			:return	toString(gData.ri_Trep				);	break;
	case	GISBreaker_ri_rchk			:return	toString(gData.ri_Rchk				);	break;
	case	GISBreaker_ri_tchk			:return	toString(gData.ri_Tchk				);	break;
	case	GISBreaker_ri_tfloc			:return	toString(gData.ri_Tfloc				);	break;
	case	GISBreaker_ri_rswitch		:return	toString(gData.ri_RSwitch			);	break;
	case	GISBreaker_ri_tswitch		:return	toString(gData.ri_TSwitch			);	break;
	case	GISBreaker_ei_invest		:return	toString(gData.ei_Invest			);	break;

	case	GISBreaker_RTLevel			:return toString(gData.nRTLevel				);	break;
	case	GISBreaker_CommMode			:return toString(gData.nCommMode			);	break;
	case	GISBreaker_PlanCharacter	:return toString(gData.nPlanCharacter		);	break;
	case	GISBreaker_BuildDate		:return toString(gData.nBuildDate			);	break;
	case	GISBreaker_ReBuildDate		:return toString(gData.nReBuildDate			);	break;
	case	GISBreaker_OutageDate		:return toString(gData.nOutageDate			);	break;
	case	GISBreaker_RunTimeSpan		:return toString(gData.nRunTimeSpan			);	break;
	case	GISBreaker_Parent			:return toString(gData.strParent			);	break;
	case	GISBreaker_INode			:return toString(gData.strNodeI				);	break;
	case	GISBreaker_ZNode			:return toString(gData.strNodeZ				);	break;
	case	GISBreaker_SubIdx			:return toString(gData.nSubIdx				);	break;
	case	GISBreaker_INodeIdx			:return toString(gData.nNodeI				);	break;
	case	GISBreaker_ZNodeIdx			:return toString(gData.nNodeZ				);	break;
	case	GISBreaker_Coordinate		:return toString(gData.gData.strCoordinate	);	break;
	case	GISBreaker_SymbolID			:return toString(gData.gData.strSymbolID	);	break;
	case	GISBreaker_SymbolSize		:return toString(gData.gData.fSymbolSize	);	break;
	case	GISBreaker_SymbolAngle		:return toString(gData.gData.fSymbolAngle	);	break;
	case	GISBreaker_GraphPath		:return toString(gData.gData.strPath		);	break;
	case	GISBreaker_Location			:return toString(gData.ptLoc				);	break;
	case	GISBreaker_GraphSize		:return toString(gData.fSize				);	break;
	case	GISBreaker_InSubstation		:return toString(gData.bInSubstation		);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISBreaker(tagGISBreaker& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISBreaker_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());		break;
	case	GISBreaker_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());		break;
	case	GISBreaker_ObjectID			:toValue(gData.strObjectID				, strValue.c_str());		break;
	case	GISBreaker_Name				:toValue(gData.strName					, strValue.c_str());		break;
	case	GISBreaker_Unit				:toValue(gData.strUnit					, strValue.c_str());		break;
	case	GISBreaker_Usage			:toValue(gData.strUsage					, strValue.c_str());		break;
	case	GISBreaker_NormalOpen		:toValue(gData.bNormalOpen				, strValue.c_str());		break;
	case	GISBreaker_ParentTag		:toValue(gData.strParentTag				, strValue.c_str());		break;
	case	GISBreaker_BaseVoltageTag	:toValue(gData.strBaseVoltageTag		, strValue.c_str());		break;
	case	GISBreaker_Status			:toValue(gData.nStatus					, strValue.c_str());		break;
	case	GISBreaker_Model			:toValue(gData.strModel					, strValue.c_str());		break;
	case	GISBreaker_BreakerType		:toValue(gData.nBreakerType				, strValue.c_str());		break;

	case	GISBreaker_ri_rerr			:toValue(gData.ri_Rerr					, strValue.c_str());	break;
	case	GISBreaker_ri_trep			:toValue(gData.ri_Trep					, strValue.c_str());	break;
	case	GISBreaker_ri_rchk			:toValue(gData.ri_Rchk					, strValue.c_str());	break;
	case	GISBreaker_ri_tchk			:toValue(gData.ri_Tchk					, strValue.c_str());	break;
	case	GISBreaker_ri_tfloc			:toValue(gData.ri_Tfloc					, strValue.c_str());	break;
	case	GISBreaker_ri_rswitch		:toValue(gData.ri_RSwitch				, strValue.c_str());	break;
	case	GISBreaker_ri_tswitch		:toValue(gData.ri_TSwitch				, strValue.c_str());	break;
	case	GISBreaker_ei_invest		:toValue(gData.ei_Invest				, strValue.c_str());	break;

	case	GISBreaker_RTLevel			:toValue(gData.nRTLevel					, strValue.c_str());		break;
	case	GISBreaker_CommMode			:toValue(gData.nCommMode				, strValue.c_str());		break;
	case	GISBreaker_PlanCharacter	:toValue(gData.nPlanCharacter			, strValue.c_str());		break;
	case	GISBreaker_BuildDate		:toValue(gData.nBuildDate				, strValue.c_str());		break;
	case	GISBreaker_ReBuildDate		:toValue(gData.nReBuildDate				, strValue.c_str());		break;
	case	GISBreaker_OutageDate		:toValue(gData.nOutageDate				, strValue.c_str());		break;
	case	GISBreaker_RunTimeSpan		:toValue(gData.nRunTimeSpan				, strValue.c_str());		break;
	case	GISBreaker_Parent			:toValue(gData.strParent				, strValue.c_str());		break;
	case	GISBreaker_INode			:toValue(gData.strNodeI					, strValue.c_str());		break;
	case	GISBreaker_ZNode			:toValue(gData.strNodeZ					, strValue.c_str());		break;
	case	GISBreaker_SubIdx			:toValue(gData.nSubIdx					, strValue.c_str());		break;
	case	GISBreaker_INodeIdx			:toValue(gData.nNodeI					, strValue.c_str());		break;
	case	GISBreaker_ZNodeIdx			:toValue(gData.nNodeZ					, strValue.c_str());		break;
	case	GISBreaker_Coordinate		:toValue(gData.gData.strCoordinate		, strValue.c_str());		break;
	case	GISBreaker_SymbolID			:toValue(gData.gData.strSymbolID		, strValue.c_str());		break;
	case	GISBreaker_SymbolSize		:toValue(gData.gData.fSymbolSize		, strValue.c_str());		break;
	case	GISBreaker_SymbolAngle		:toValue(gData.gData.fSymbolAngle		, strValue.c_str());		break;
	case	GISBreaker_GraphPath		:toValue(gData.gData.strPath			, strValue.c_str());		break;
	case	GISBreaker_Location			:toValue(gData.ptLoc					, strValue.c_str());		break;
	case	GISBreaker_GraphSize		:toValue(gData.fSize					, strValue.c_str());		break;
	case	GISBreaker_InSubstation		:toValue(gData.bInSubstation			, strValue.c_str());		break;
	}
}

const std::string CGISDataBuffer::GetGISDisconnector(tagGISDisconnector& gData, const int nField)
{
	switch (nField)
	{
	case	GISDisconnector_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISDisconnector_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISDisconnector_ObjectID		:return	toString(gData.strObjectID			);	break;
	case	GISDisconnector_Name			:return	toString(gData.strName				);	break;
	case	GISDisconnector_Unit			:return	toString(gData.strUnit				);	break;
	case	GISDisconnector_NormalOpen		:return	toString(gData.bNormalOpen			);	break;
	case	GISDisconnector_ParentTag		:return	toString(gData.strParentTag			);	break;
	case	GISDisconnector_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISDisconnector_Status			:return	toString(gData.nStatus				);	break;
	case	GISDisconnector_Model			:return	toString(gData.strModel				);	break;
	case	GISDisconnector_BreakerType		:return	toString(gData.nBreakerType			);	break;

	case	GISDisconnector_ri_rerr			:return	toString(gData.ri_Rerr				);	break;
	case	GISDisconnector_ri_trep			:return	toString(gData.ri_Trep				);	break;
	case	GISDisconnector_ri_rchk			:return	toString(gData.ri_Rchk				);	break;
	case	GISDisconnector_ri_tchk			:return	toString(gData.ri_Tchk				);	break;
	case	GISDisconnector_ri_tfloc		:return	toString(gData.ri_Tfloc				);	break;
	case	GISDisconnector_ri_rswitch		:return	toString(gData.ri_RSwitch			);	break;
	case	GISDisconnector_ri_tswitch		:return	toString(gData.ri_TSwitch			);	break;
	case	GISDisconnector_ei_invest		:return	toString(gData.ei_Invest			);	break;

	case	GISDisconnector_RTLevel			:return	toString(gData.nRTLevel				);	break;
	case	GISDisconnector_CommMode		:return	toString(gData.nCommMode			);	break;
	case	GISDisconnector_PlanCharacter	:return	toString(gData.nPlanCharacter		);	break;
	case	GISDisconnector_BuildDate		:return	toString(gData.nBuildDate			);	break;
	case	GISDisconnector_ReBuildDate		:return	toString(gData.nReBuildDate			);	break;
	case	GISDisconnector_OutageDate		:return	toString(gData.nOutageDate			);	break;
	case	GISDisconnector_RunTimeSpan		:return	toString(gData.nRunTimeSpan			);	break;
	case	GISDisconnector_Parent			:return	toString(gData.strParent			);	break;
	case	GISDisconnector_INode			:return	toString(gData.strNodeI				);	break;
	case	GISDisconnector_ZNode			:return	toString(gData.strNodeZ				);	break;
	case	GISDisconnector_SubIdx			:return	toString(gData.nSubIdx				);	break;
	case	GISDisconnector_INodeIdx		:return	toString(gData.nNodeI				);	break;
	case	GISDisconnector_ZNodeIdx		:return	toString(gData.nNodeZ				);	break;
	case	GISDisconnector_Coordinate		:return	toString(gData.gData.strCoordinate	);	break;
	case	GISDisconnector_SymbolID		:return	toString(gData.gData.strSymbolID	);	break;
	case	GISDisconnector_SymbolSize		:return	toString(gData.gData.fSymbolSize	);	break;
	case	GISDisconnector_SymbolAngle		:return	toString(gData.gData.fSymbolAngle	);	break;
	case	GISDisconnector_GraphPath		:return	toString(gData.gData.strPath		);	break;
	case	GISDisconnector_Location		:return	toString(gData.ptLoc				);	break;
	case	GISDisconnector_GraphSize		:return	toString(gData.fSize				);	break;
	case	GISDisconnector_InSubstation	:return	toString(gData.bInSubstation		);	break;
	}
	return "";
}


void CGISDataBuffer::SetGISDisconnector(tagGISDisconnector& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISDisconnector_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISDisconnector_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISDisconnector_ObjectID		:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISDisconnector_Name			:toValue(gData.strName					, strValue.c_str());	break;
	case	GISDisconnector_Unit			:toValue(gData.strUnit					, strValue.c_str());	break;
	case	GISDisconnector_NormalOpen		:toValue(gData.bNormalOpen				, strValue.c_str());	break;
	case	GISDisconnector_ParentTag		:toValue(gData.strParentTag				, strValue.c_str());	break;
	case	GISDisconnector_BaseVoltageTag	:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISDisconnector_Status			:toValue(gData.nStatus					, strValue.c_str());	break;
	case	GISDisconnector_Model			:toValue(gData.strModel					, strValue.c_str());	break;
	case	GISDisconnector_BreakerType		:toValue(gData.nBreakerType				, strValue.c_str());	break;

	case	GISDisconnector_ri_rerr			:toValue(gData.ri_Rerr					, strValue.c_str());	break;
	case	GISDisconnector_ri_trep			:toValue(gData.ri_Trep					, strValue.c_str());	break;
	case	GISDisconnector_ri_rchk			:toValue(gData.ri_Rchk					, strValue.c_str());	break;
	case	GISDisconnector_ri_tchk			:toValue(gData.ri_Tchk					, strValue.c_str());	break;
	case	GISDisconnector_ri_tfloc		:toValue(gData.ri_Tfloc					, strValue.c_str());	break;
	case	GISDisconnector_ri_rswitch		:toValue(gData.ri_RSwitch				, strValue.c_str());	break;
	case	GISDisconnector_ri_tswitch		:toValue(gData.ri_TSwitch				, strValue.c_str());	break;
	case	GISDisconnector_ei_invest		:toValue(gData.ei_Invest				, strValue.c_str());	break;

	case	GISDisconnector_RTLevel			:toValue(gData.nRTLevel					, strValue.c_str());	break;
	case	GISDisconnector_CommMode		:toValue(gData.nCommMode				, strValue.c_str());	break;
	case	GISDisconnector_PlanCharacter	:toValue(gData.nPlanCharacter			, strValue.c_str());	break;
	case	GISDisconnector_BuildDate		:toValue(gData.nBuildDate				, strValue.c_str());	break;
	case	GISDisconnector_ReBuildDate		:toValue(gData.nReBuildDate				, strValue.c_str());	break;
	case	GISDisconnector_OutageDate		:toValue(gData.nOutageDate				, strValue.c_str());	break;
	case	GISDisconnector_RunTimeSpan		:toValue(gData.nRunTimeSpan				, strValue.c_str());	break;
	case	GISDisconnector_Parent			:toValue(gData.strParent				, strValue.c_str());	break;
	case	GISDisconnector_INode			:toValue(gData.strNodeI					, strValue.c_str());	break;
	case	GISDisconnector_ZNode			:toValue(gData.strNodeZ					, strValue.c_str());	break;
	case	GISDisconnector_SubIdx			:toValue(gData.nSubIdx					, strValue.c_str());	break;
	case	GISDisconnector_INodeIdx		:toValue(gData.nNodeI					, strValue.c_str());	break;
	case	GISDisconnector_ZNodeIdx		:toValue(gData.nNodeZ					, strValue.c_str());	break;
	case	GISDisconnector_Coordinate		:toValue(gData.gData.strCoordinate		, strValue.c_str());	break;
	case	GISDisconnector_SymbolID		:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISDisconnector_SymbolSize		:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISDisconnector_SymbolAngle		:toValue(gData.gData.fSymbolAngle		, strValue.c_str());	break;
	case	GISDisconnector_GraphPath		:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISDisconnector_Location		:toValue(gData.ptLoc					, strValue.c_str());	break;
	case	GISDisconnector_GraphSize		:toValue(gData.fSize					, strValue.c_str());	break;
	case	GISDisconnector_InSubstation	:toValue(gData.bInSubstation			, strValue.c_str());		break;
	}
}

const std::string CGISDataBuffer::GetGISGroundDisconnector(tagGISGroundDisconnector& gData, const int nField)
{
	switch (nField)
	{
	case	GISGroundDisconnector_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISGroundDisconnector_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISGroundDisconnector_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISGroundDisconnector_Name				:return	toString(gData.strName				);	break;
	case	GISGroundDisconnector_Unit				:return	toString(gData.strUnit				);	break;
	case	GISGroundDisconnector_NormalOpen		:return	toString(gData.bNormalOpen			);	break;
	case	GISGroundDisconnector_ParentTag			:return	toString(gData.strParentTag			);	break;
	case	GISGroundDisconnector_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISGroundDisconnector_Model				:return	toString(gData.strModel				);	break;
	case	GISGroundDisconnector_RTLevel			:return	toString(gData.nRTLevel				);	break;
	case	GISGroundDisconnector_CommMode			:return	toString(gData.nCommMode			);	break;
	case	GISGroundDisconnector_PlanCharacter		:return	toString(gData.nPlanCharacter		);	break;
	case	GISGroundDisconnector_BuildDate			:return	toString(gData.nBuildDate			);	break;
	case	GISGroundDisconnector_ReBuildDate		:return	toString(gData.nReBuildDate			);	break;
	case	GISGroundDisconnector_OutageDate		:return	toString(gData.nOutageDate			);	break;
	case	GISGroundDisconnector_RunTimeSpan		:return	toString(gData.nRunTimeSpan			);	break;
	case	GISGroundDisconnector_Parent			:return	toString(gData.strParent			);	break;
	case	GISGroundDisconnector_Node				:return	toString(gData.strNode				);	break;
	case	GISGroundDisconnector_SubIdx			:return	toString(gData.nSubIdx				);	break;
	case	GISGroundDisconnector_NodeIdx			:return	toString(gData.nNode				);	break;
	case	GISGroundDisconnector_Coordinate		:return	toString(gData.gData.strCoordinate	);	break;
	case	GISGroundDisconnector_SymbolID			:return	toString(gData.gData.strSymbolID	);	break;
	case	GISGroundDisconnector_SymbolSize		:return	toString(gData.gData.fSymbolSize	);	break;
	case	GISGroundDisconnector_SymbolAngle		:return	toString(gData.gData.fSymbolAngle	);	break;
	case	GISGroundDisconnector_GraphPath			:return	toString(gData.gData.strPath		);	break;
	case	GISGroundDisconnector_Location			:return	toString(gData.ptLoc				);	break;
	case	GISGroundDisconnector_GraphSize			:return	toString(gData.fSize				);	break;
	case	GISGroundDisconnector_Status			:return	toString(gData.nStatus				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISGroundDisconnector(tagGISGroundDisconnector& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISGroundDisconnector_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISGroundDisconnector_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISGroundDisconnector_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISGroundDisconnector_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISGroundDisconnector_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISGroundDisconnector_NormalOpen		:toValue(gData.bNormalOpen			, strValue.c_str());	break;
	case	GISGroundDisconnector_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISGroundDisconnector_BaseVoltageTag	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISGroundDisconnector_Model				:toValue(gData.strModel				, strValue.c_str());	break;
	case	GISGroundDisconnector_RTLevel			:toValue(gData.nRTLevel				, strValue.c_str());	break;
	case	GISGroundDisconnector_CommMode			:toValue(gData.nCommMode			, strValue.c_str());	break;
	case	GISGroundDisconnector_PlanCharacter		:toValue(gData.nPlanCharacter		, strValue.c_str());	break;
	case	GISGroundDisconnector_BuildDate			:toValue(gData.nBuildDate			, strValue.c_str());	break;
	case	GISGroundDisconnector_ReBuildDate		:toValue(gData.nReBuildDate			, strValue.c_str());	break;
	case	GISGroundDisconnector_OutageDate		:toValue(gData.nOutageDate			, strValue.c_str());	break;
	case	GISGroundDisconnector_RunTimeSpan		:toValue(gData.nRunTimeSpan			, strValue.c_str());	break;
	case	GISGroundDisconnector_Parent			:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISGroundDisconnector_Node				:toValue(gData.strNode				, strValue.c_str());	break;
	case	GISGroundDisconnector_SubIdx			:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISGroundDisconnector_NodeIdx			:toValue(gData.nNode				, strValue.c_str());	break;
	case	GISGroundDisconnector_Coordinate		:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISGroundDisconnector_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISGroundDisconnector_SymbolSize		:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISGroundDisconnector_SymbolAngle		:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISGroundDisconnector_GraphPath			:toValue(gData.gData.strPath		, strValue.c_str());	break;
	case	GISGroundDisconnector_Location			:toValue(gData.ptLoc				, strValue.c_str());	break;
	case	GISGroundDisconnector_GraphSize			:toValue(gData.fSize				, strValue.c_str());	break;
	case	GISGroundDisconnector_Status			:toValue(gData.nStatus				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISLoadBreakSwitch(tagGISLoadBreakSwitch& gData, const int nField)
{
	switch (nField)
	{
	case	GISLoadBreakSwitch_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISLoadBreakSwitch_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISLoadBreakSwitch_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISLoadBreakSwitch_Name				:return	toString(gData.strName				);	break;
	case	GISLoadBreakSwitch_Unit				:return	toString(gData.strUnit				);	break;
	case	GISLoadBreakSwitch_NormalOpen		:return	toString(gData.bNormalOpen			);	break;
	case	GISLoadBreakSwitch_ParentTag		:return	toString(gData.strParentTag			);	break;
	case	GISLoadBreakSwitch_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISLoadBreakSwitch_Status			:return	toString(gData.nStatus				);	break;
	case	GISLoadBreakSwitch_Model			:return	toString(gData.strModel				);	break;
	case	GISLoadBreakSwitch_BreakerType		:return	toString(gData.nBreakerType			);	break;

	case	GISLoadBreakSwitch_ri_rerr			:return	toString(gData.ri_Rerr				);	break;
	case	GISLoadBreakSwitch_ri_trep			:return	toString(gData.ri_Trep				);	break;
	case	GISLoadBreakSwitch_ri_rchk			:return	toString(gData.ri_Rchk				);	break;
	case	GISLoadBreakSwitch_ri_tchk			:return	toString(gData.ri_Tchk				);	break;
	case	GISLoadBreakSwitch_ri_tfloc			:return	toString(gData.ri_Tfloc				);	break;
	case	GISLoadBreakSwitch_ri_rswitch		:return	toString(gData.ri_RSwitch			);	break;
	case	GISLoadBreakSwitch_ri_tswitch		:return	toString(gData.ri_TSwitch			);	break;
	case	GISLoadBreakSwitch_ei_invest		:return	toString(gData.ei_Invest			);	break;

	case	GISLoadBreakSwitch_RTLevel			:return	toString(gData.nRTLevel				);	break;
	case	GISLoadBreakSwitch_CommMode			:return	toString(gData.nCommMode			);	break;
	case	GISLoadBreakSwitch_PlanCharacter	:return	toString(gData.nPlanCharacter		);	break;
	case	GISLoadBreakSwitch_BuildDate		:return	toString(gData.nBuildDate			);	break;
	case	GISLoadBreakSwitch_ReBuildDate		:return	toString(gData.nReBuildDate			);	break;
	case	GISLoadBreakSwitch_OutageDate		:return	toString(gData.nOutageDate			);	break;
	case	GISLoadBreakSwitch_RunTimeSpan		:return	toString(gData.nRunTimeSpan			);	break;
	case	GISLoadBreakSwitch_Parent			:return	toString(gData.strParent			);	break;
	case	GISLoadBreakSwitch_INode			:return	toString(gData.strNodeI				);	break;
	case	GISLoadBreakSwitch_ZNode			:return	toString(gData.strNodeZ				);	break;
	case	GISLoadBreakSwitch_SubIdx			:return	toString(gData.nSubIdx				);	break;
	case	GISLoadBreakSwitch_INodeIdx			:return	toString(gData.nNodeI				);	break;
	case	GISLoadBreakSwitch_ZNodeIdx			:return	toString(gData.nNodeZ				);	break;
	case	GISLoadBreakSwitch_Coordinate		:return	toString(gData.gData.strCoordinate	);	break;
	case	GISLoadBreakSwitch_SymbolID			:return	toString(gData.gData.strSymbolID	);	break;
	case	GISLoadBreakSwitch_SymbolSize		:return	toString(gData.gData.fSymbolSize	);	break;
	case	GISLoadBreakSwitch_SymbolAngle		:return	toString(gData.gData.fSymbolAngle	);	break;
	case	GISLoadBreakSwitch_GraphPath		:return	toString(gData.gData.strPath		);	break;
	case	GISLoadBreakSwitch_Location			:return	toString(gData.ptLoc				);	break;
	case	GISLoadBreakSwitch_GraphSize		:return	toString(gData.fSize				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISLoadBreakSwitch(tagGISLoadBreakSwitch& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISLoadBreakSwitch_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISLoadBreakSwitch_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_NormalOpen		:toValue(gData.bNormalOpen			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ParentTag		:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_BaseVoltageTag	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Status			:toValue(gData.nStatus				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Model			:toValue(gData.strModel				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_BreakerType		:toValue(gData.nBreakerType			, strValue.c_str());	break;

	case	GISLoadBreakSwitch_ri_rerr			:toValue(gData.ri_Rerr				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ri_trep			:toValue(gData.ri_Trep				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ri_rchk			:toValue(gData.ri_Rchk				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ri_tchk			:toValue(gData.ri_Tchk				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ri_tfloc			:toValue(gData.ri_Tfloc				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ri_rswitch		:toValue(gData.ri_RSwitch			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ri_tswitch		:toValue(gData.ri_TSwitch			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ei_invest		:toValue(gData.ei_Invest			, strValue.c_str());	break;

	case	GISLoadBreakSwitch_RTLevel			:toValue(gData.nRTLevel				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_CommMode			:toValue(gData.nCommMode			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_PlanCharacter	:toValue(gData.nPlanCharacter		, strValue.c_str());	break;
	case	GISLoadBreakSwitch_BuildDate		:toValue(gData.nBuildDate			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ReBuildDate		:toValue(gData.nReBuildDate			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_OutageDate		:toValue(gData.nOutageDate			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_RunTimeSpan		:toValue(gData.nRunTimeSpan			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Parent			:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISLoadBreakSwitch_INode			:toValue(gData.strNodeI				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ZNode			:toValue(gData.strNodeZ				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_SubIdx			:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_INodeIdx			:toValue(gData.nNodeI				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_ZNodeIdx			:toValue(gData.nNodeZ				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Coordinate		:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISLoadBreakSwitch_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISLoadBreakSwitch_SymbolSize		:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISLoadBreakSwitch_SymbolAngle		:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISLoadBreakSwitch_GraphPath		:toValue(gData.gData.strPath		, strValue.c_str());	break;
	case	GISLoadBreakSwitch_Location			:toValue(gData.ptLoc				, strValue.c_str());	break;
	case	GISLoadBreakSwitch_GraphSize		:toValue(gData.fSize				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISFuse(tagGISFuse& gData, const int nField)
{
	switch (nField)
	{
	case	GISFuse_ResourceID			:return	toString(gData.strResourceID		);	break;
	case	GISFuse_PSRTypeTag			:return	toString(gData.strPSRTypeTag		);	break;
	case	GISFuse_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISFuse_Name				:return	toString(gData.strName				);	break;
	case	GISFuse_Unit				:return	toString(gData.strUnit				);	break;
	case	GISFuse_ParentTag			:return	toString(gData.strParentTag			);	break;
	case	GISFuse_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISFuse_Status				:return	toString(gData.nStatus				);	break;
	case	GISFuse_Model				:return	toString(gData.strModel				);	break;
	case	GISFuse_BreakerType			:return	toString(gData.nBreakerType			);	break;

	case	GISFuse_ri_rerr				:return	toString(gData.ri_Rerr					);	break;
	case	GISFuse_ri_trep				:return	toString(gData.ri_Trep					);	break;
	case	GISFuse_ri_rchk				:return	toString(gData.ri_Rchk					);	break;
	case	GISFuse_ri_tchk				:return	toString(gData.ri_Tchk					);	break;
	case	GISFuse_ri_tfloc			:return	toString(gData.ri_Tfloc					);	break;
	case	GISFuse_ri_rswitch			:return	toString(gData.ri_RSwitch				);	break;
	case	GISFuse_ri_tswitch			:return	toString(gData.ri_TSwitch				);	break;
	case	GISFuse_ei_invest			:return	toString(gData.ei_Invest				);	break;

	case	GISFuse_RTLevel				:return	toString(gData.nRTLevel				);	break;
	case	GISFuse_CommMode			:return	toString(gData.nCommMode			);	break;
	case	GISFuse_PlanCharacter		:return	toString(gData.nPlanCharacter		);	break;
	case	GISFuse_BuildDate			:return	toString(gData.nBuildDate			);	break;
	case	GISFuse_ReBuildDate			:return	toString(gData.nReBuildDate			);	break;
	case	GISFuse_OutageDate			:return	toString(gData.nOutageDate			);	break;
	case	GISFuse_RunTimeSpan			:return	toString(gData.nRunTimeSpan			);	break;
	case	GISFuse_Parent				:return	toString(gData.strParent			);	break;
	case	GISFuse_INode				:return	toString(gData.strNodeI				);	break;
	case	GISFuse_ZNode				:return	toString(gData.strNodeZ				);	break;
	case	GISFuse_SubIdx				:return	toString(gData.nSubIdx				);	break;
	case	GISFuse_INodeIdx			:return	toString(gData.nNodeI				);	break;
	case	GISFuse_ZNodeIdx			:return	toString(gData.nNodeZ				);	break;
	case	GISFuse_Coordinate			:return	toString(gData.gData.strCoordinate	);	break;
	case	GISFuse_SymbolID			:return	toString(gData.gData.strSymbolID	);	break;
	case	GISFuse_SymbolSize			:return	toString(gData.gData.fSymbolSize	);	break;
	case	GISFuse_SymbolAngle			:return	toString(gData.gData.fSymbolAngle	);	break;
	case	GISFuse_GraphPath			:return	toString(gData.gData.strPath		);	break;
	case	GISFuse_Location			:return	toString(gData.ptLoc				);	break;
	case	GISFuse_GraphSize			:return	toString(gData.fSize				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISFuse(tagGISFuse& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISFuse_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISFuse_PSRTypeTag			:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISFuse_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISFuse_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISFuse_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISFuse_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISFuse_BaseVoltageTag		:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISFuse_Status				:toValue(gData.nStatus				, strValue.c_str());	break;
	case	GISFuse_Model				:toValue(gData.strModel				, strValue.c_str());	break;
	case	GISFuse_BreakerType			:toValue(gData.nBreakerType			, strValue.c_str());	break;

	case	GISFuse_ri_rerr				:toValue(gData.ri_Rerr				, strValue.c_str());	break;
	case	GISFuse_ri_trep				:toValue(gData.ri_Trep				, strValue.c_str());	break;
	case	GISFuse_ri_rchk				:toValue(gData.ri_Rchk				, strValue.c_str());	break;
	case	GISFuse_ri_tchk				:toValue(gData.ri_Tchk				, strValue.c_str());	break;
	case	GISFuse_ri_tfloc			:toValue(gData.ri_Tfloc				, strValue.c_str());	break;
	case	GISFuse_ri_rswitch			:toValue(gData.ri_RSwitch			, strValue.c_str());	break;
	case	GISFuse_ri_tswitch			:toValue(gData.ri_TSwitch			, strValue.c_str());	break;
	case	GISFuse_ei_invest			:toValue(gData.ei_Invest			, strValue.c_str());	break;

	case	GISFuse_RTLevel				:toValue(gData.nRTLevel				, strValue.c_str());	break;
	case	GISFuse_CommMode			:toValue(gData.nCommMode			, strValue.c_str());	break;
	case	GISFuse_PlanCharacter		:toValue(gData.nPlanCharacter		, strValue.c_str());	break;
	case	GISFuse_BuildDate			:toValue(gData.nBuildDate			, strValue.c_str());	break;
	case	GISFuse_ReBuildDate			:toValue(gData.nReBuildDate			, strValue.c_str());	break;
	case	GISFuse_OutageDate			:toValue(gData.nOutageDate			, strValue.c_str());	break;
	case	GISFuse_RunTimeSpan			:toValue(gData.nRunTimeSpan			, strValue.c_str());	break;
	case	GISFuse_Parent				:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISFuse_INode				:toValue(gData.strNodeI				, strValue.c_str());	break;
	case	GISFuse_ZNode				:toValue(gData.strNodeZ				, strValue.c_str());	break;
	case	GISFuse_SubIdx				:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISFuse_INodeIdx			:toValue(gData.nNodeI				, strValue.c_str());	break;
	case	GISFuse_ZNodeIdx			:toValue(gData.nNodeZ				, strValue.c_str());	break;
	case	GISFuse_Coordinate			:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISFuse_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISFuse_SymbolSize			:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISFuse_SymbolAngle			:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISFuse_GraphPath			:toValue(gData.gData.strPath		, strValue.c_str());	break;
	case	GISFuse_Location			:toValue(gData.ptLoc				, strValue.c_str());	break;
	case	GISFuse_GraphSize			:toValue(gData.fSize				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISACLineSegment(tagGISACLineSegment& gData, const int nField)
{
	switch (nField)
	{
	case	GISACLineSegment_ResourceID				:return	toString(gData.strResourceID			);	break;
	case	GISACLineSegment_PSRTypeTag				:return	toString(gData.strPSRTypeTag			);	break;
	case	GISACLineSegment_ObjectID				:return	toString(gData.strObjectID				);	break;
	case	GISACLineSegment_Name					:return	toString(gData.strName					);	break;
	case	GISACLineSegment_Unit					:return	toString(gData.strUnit					);	break;
	case	GISACLineSegment_AssetModel				:return	toString(gData.strAssetModel			);	break;
	case	GISACLineSegment_LineType				:return	toString(gData.strLineType				);	break;
	case	GISACLineSegment_AutoLength				:return	toString(gData.bAutoLength				);	break;
	case	GISACLineSegment_Length					:return	toString(gData.fLength					);	break;
	case	GISACLineSegment_ParentTag				:return	toString(gData.strParentTag				);	break;
	case	GISACLineSegment_BaseVoltageTag			:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISACLineSegment_LineTag				:return	toString(gData.strLineTag				);	break;
	case	GISACLineSegment_Type					:return	toString(gData.nLineType				);	break;
	case	GISACLineSegment_PlanCharacter			:return	toString(gData.nPlanCharacter			);	break;
	case	GISACLineSegment_RunStatus				:return	toString(gData.nRunStatus				);	break;
	case	GISACLineSegment_AreaCategory			:return	toString(gData.nAreaCategory			);	break;
	case	GISACLineSegment_LineLoadP				:return	toString(gData.fLineLoadP				);	break;
	case	GISACLineSegment_LineLoadFactor			:return	toString(gData.fLineLoadFactor			);	break;
	case	GISACLineSegment_LineCapacitor			:return	toString(gData.fLineCapacitor			);	break;
	case	GISACLineSegment_r						:return	toString(gData.r						);	break;
	case	GISACLineSegment_x						:return	toString(gData.x						);	break;
	case	GISACLineSegment_g						:return	toString(gData.g						);	break;
	case	GISACLineSegment_b						:return	toString(gData.b						);	break;

	case	GISACLineSegment_ri_unitrerr			:return	toString(gData.ri_UnitRerr				);	break;
	case	GISACLineSegment_ri_unittrep			:return	toString(gData.ri_UnitTrep				);	break;
	case	GISACLineSegment_ri_unitrchk			:return	toString(gData.ri_UnitRchk				);	break;
	case	GISACLineSegment_ri_unittchk			:return	toString(gData.ri_UnitTchk				);	break;
	case	GISACLineSegment_ei_unitinvest			:return	toString(gData.ei_UnitInvest			);	break;
	case	GISACLineSegment_ri_rerr				:return	toString(gData.ri_Rerr					);	break;
	case	GISACLineSegment_ri_trep				:return	toString(gData.ri_Trep					);	break;
	case	GISACLineSegment_ri_rchk				:return	toString(gData.ri_Rchk					);	break;
	case	GISACLineSegment_ri_tchk				:return	toString(gData.ri_Tchk					);	break;
	case	GISACLineSegment_ri_tfloc				:return	toString(gData.ri_Tfloc					);	break;
	case	GISACLineSegment_ri_rswitch				:return	toString(gData.ri_RSwitch				);	break;
	case	GISACLineSegment_ri_tswitch				:return	toString(gData.ri_TSwitch				);	break;
	case	GISACLineSegment_ri_tdelay				:return	toString(gData.ri_TDelay				);	break;
	case	GISACLineSegment_ri_customer			:return	toString(gData.ri_Customer				);	break;
	case	GISACLineSegment_ri_load_rerr			:return	toString(gData.ri_load_rerr				);	break;
	case	GISACLineSegment_ri_load_trep			:return	toString(gData.ri_load_trep				);	break;
	case	GISACLineSegment_ri_load_rchk			:return	toString(gData.ri_load_rchk				);	break;
	case	GISACLineSegment_ri_load_tchk			:return	toString(gData.ri_load_tchk				);	break;
	case	GISACLineSegment_ei_invest				:return	toString(gData.ei_Invest				);	break;

	case	GISACLineSegment_BuildDate				:return	toString(gData.nBuildDate				);	break;
	case	GISACLineSegment_ReBuildDate			:return	toString(gData.nReBuildDate				);	break;
	case	GISACLineSegment_OutageDate				:return	toString(gData.nOutageDate				);	break;
	case	GISACLineSegment_RunTimeSpan			:return	toString(gData.nRunTimeSpan				);	break;
	case	GISACLineSegment_iStatus				:return	toString(gData.iStatus					);	break;
	case	GISACLineSegment_zStatus				:return	toString(gData.zStatus					);	break;
	case	GISACLineSegment_Feeder					:return	toString(gData.strFeeder				);	break;
	case	GISACLineSegment_INode					:return	toString(gData.strNodeI					);	break;
	case	GISACLineSegment_ZNode					:return	toString(gData.strNodeZ					);	break;
	case	GISACLineSegment_SubITag				:return	toString(gData.strSubITag				);	break;
	case	GISACLineSegment_SubZTag				:return	toString(gData.strSubZTag				);	break;
	case	GISACLineSegment_JointEquipmentIType	:return	toString(gData.nIJointEquipmentType		);	break;
	case	GISACLineSegment_JointEquipmentZType	:return	toString(gData.nZJointEquipmentType		);	break;
	case	GISACLineSegment_JointEquipmentI		:return	toString(gData.strIJointEquipmentTag	);	break;
	case	GISACLineSegment_JointEquipmentZ		:return	toString(gData.strZJointEquipmentTag	);	break;
	case	GISACLineSegment_ContainerIdx			:return	toString(gData.nContainerIdx			);	break;
	case	GISACLineSegment_SubIIdx				:return	toString(gData.nSubI					);	break;
	case	GISACLineSegment_SubZIdx				:return	toString(gData.nSubZ					);	break;
	case	GISACLineSegment_INodeIdx				:return	toString(gData.nNodeI					);	break;
	case	GISACLineSegment_ZNodeIdx				:return	toString(gData.nNodeZ					);	break;
	case	GISACLineSegment_Flag					:return	toString(gData.bFlag					);	break;
	case	GISACLineSegment_Coordinate				:return	toString(gData.gData.strCoordinate		);	break;
	case	GISACLineSegment_SymbolID				:return	toString(gData.gData.strSymbolID		);	break;
	case	GISACLineSegment_SymbolSize				:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISACLineSegment_SymbolAngle			:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISACLineSegment_GraphPath				:return	toString(gData.gData.strPath			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISACLineSegment(tagGISACLineSegment& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISACLineSegment_ResourceID				:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISACLineSegment_PSRTypeTag				:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISACLineSegment_ObjectID				:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISACLineSegment_Name					:toValue(gData.strName					, strValue.c_str());	break;
	case	GISACLineSegment_Unit					:toValue(gData.strUnit					, strValue.c_str());	break;
	case	GISACLineSegment_AssetModel				:toValue(gData.strAssetModel			, strValue.c_str());	break;
	case	GISACLineSegment_LineType				:toValue(gData.strLineType				, strValue.c_str());	break;
	case	GISACLineSegment_AutoLength				:toValue(gData.bAutoLength				, strValue.c_str());	break;
	case	GISACLineSegment_Length					:toValue(gData.fLength					, strValue.c_str());	break;
	case	GISACLineSegment_ParentTag				:toValue(gData.strParentTag				, strValue.c_str());	break;
	case	GISACLineSegment_BaseVoltageTag			:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISACLineSegment_LineTag				:toValue(gData.strLineTag				, strValue.c_str());	break;
	case	GISACLineSegment_Type					:toValue(gData.nLineType				, strValue.c_str());	break;
	case	GISACLineSegment_PlanCharacter			:toValue(gData.nPlanCharacter			, strValue.c_str());	break;
	case	GISACLineSegment_RunStatus				:toValue(gData.nRunStatus				, strValue.c_str());	break;
	case	GISACLineSegment_AreaCategory			:toValue(gData.nAreaCategory			, strValue.c_str());	break;
	case	GISACLineSegment_LineLoadP				:toValue(gData.fLineLoadP				, strValue.c_str());	break;
	case	GISACLineSegment_LineLoadFactor			:toValue(gData.fLineLoadFactor			, strValue.c_str());	break;
	case	GISACLineSegment_LineCapacitor			:toValue(gData.fLineCapacitor			, strValue.c_str());	break;

	case	GISACLineSegment_r						:toValue(gData.r						, strValue.c_str());	break;
	case	GISACLineSegment_x						:toValue(gData.x						, strValue.c_str());	break;
	case	GISACLineSegment_g						:toValue(gData.g						, strValue.c_str());	break;
	case	GISACLineSegment_b						:toValue(gData.b						, strValue.c_str());	break;

	case	GISACLineSegment_ri_unitrerr			:toValue(gData.ri_UnitRerr				, strValue.c_str());	break;
	case	GISACLineSegment_ri_unittrep			:toValue(gData.ri_UnitTrep				, strValue.c_str());	break;
	case	GISACLineSegment_ri_unitrchk			:toValue(gData.ri_UnitRchk				, strValue.c_str());	break;
	case	GISACLineSegment_ri_unittchk			:toValue(gData.ri_UnitTchk				, strValue.c_str());	break;
	case	GISACLineSegment_ei_unitinvest			:toValue(gData.ei_UnitInvest			, strValue.c_str());	break;
	case	GISACLineSegment_ri_rerr				:toValue(gData.ri_Rerr					, strValue.c_str());	break;
	case	GISACLineSegment_ri_trep				:toValue(gData.ri_Trep					, strValue.c_str());	break;
	case	GISACLineSegment_ri_rchk				:toValue(gData.ri_Rchk					, strValue.c_str());	break;
	case	GISACLineSegment_ri_tchk				:toValue(gData.ri_Tchk					, strValue.c_str());	break;
	case	GISACLineSegment_ri_tfloc				:toValue(gData.ri_Tfloc					, strValue.c_str());	break;
	case	GISACLineSegment_ri_rswitch				:toValue(gData.ri_RSwitch				, strValue.c_str());	break;
	case	GISACLineSegment_ri_tswitch				:toValue(gData.ri_TSwitch				, strValue.c_str());	break;
	case	GISACLineSegment_ri_tdelay				:toValue(gData.ri_TDelay				, strValue.c_str());	break;
	case	GISACLineSegment_ri_customer			:toValue(gData.ri_Customer				, strValue.c_str());	break;
	case	GISACLineSegment_ri_load_rerr			:toValue(gData.ri_load_rerr				, strValue.c_str());	break;
	case	GISACLineSegment_ri_load_trep			:toValue(gData.ri_load_trep				, strValue.c_str());	break;
	case	GISACLineSegment_ri_load_rchk			:toValue(gData.ri_load_rchk				, strValue.c_str());	break;
	case	GISACLineSegment_ri_load_tchk			:toValue(gData.ri_load_tchk				, strValue.c_str());	break;
	case	GISACLineSegment_ei_invest				:toValue(gData.ei_Invest				, strValue.c_str());	break;

	case	GISACLineSegment_BuildDate				:toValue(gData.nBuildDate				, strValue.c_str());	break;
	case	GISACLineSegment_ReBuildDate			:toValue(gData.nReBuildDate				, strValue.c_str());	break;
	case	GISACLineSegment_OutageDate				:toValue(gData.nOutageDate				, strValue.c_str());	break;
	case	GISACLineSegment_RunTimeSpan			:toValue(gData.nRunTimeSpan				, strValue.c_str());	break;
	case	GISACLineSegment_iStatus				:toValue(gData.iStatus					, strValue.c_str());	break;
	case	GISACLineSegment_zStatus				:toValue(gData.zStatus					, strValue.c_str());	break;
	case	GISACLineSegment_Feeder					:toValue(gData.strFeeder				, strValue.c_str());	break;
	case	GISACLineSegment_INode					:toValue(gData.strNodeI					, strValue.c_str());	break;
	case	GISACLineSegment_ZNode					:toValue(gData.strNodeZ					, strValue.c_str());	break;
	case	GISACLineSegment_SubITag				:toValue(gData.strSubITag				, strValue.c_str());	break;
	case	GISACLineSegment_SubZTag				:toValue(gData.strSubZTag				, strValue.c_str());	break;
	case	GISACLineSegment_JointEquipmentIType	:toValue(gData.nIJointEquipmentType		, strValue.c_str());	break;
	case	GISACLineSegment_JointEquipmentZType	:toValue(gData.nZJointEquipmentType		, strValue.c_str());	break;
	case	GISACLineSegment_JointEquipmentI		:toValue(gData.strIJointEquipmentTag	, strValue.c_str());	break;
	case	GISACLineSegment_JointEquipmentZ		:toValue(gData.strZJointEquipmentTag	, strValue.c_str());	break;
	case	GISACLineSegment_ContainerIdx			:toValue(gData.nContainerIdx			, strValue.c_str());	break;
	case	GISACLineSegment_SubIIdx				:toValue(gData.nSubI					, strValue.c_str());	break;
	case	GISACLineSegment_SubZIdx				:toValue(gData.nSubZ					, strValue.c_str());	break;
	case	GISACLineSegment_INodeIdx				:toValue(gData.nNodeI					, strValue.c_str());	break;
	case	GISACLineSegment_ZNodeIdx				:toValue(gData.nNodeZ					, strValue.c_str());	break;
	case	GISACLineSegment_Flag					:toValue(gData.bFlag					, strValue.c_str());	break;
	case	GISACLineSegment_Coordinate				:toValue(gData.gData.strCoordinate		, strValue.c_str());	break;
	case	GISACLineSegment_SymbolID				:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISACLineSegment_SymbolSize				:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISACLineSegment_SymbolAngle			:toValue(gData.gData.fSymbolAngle		, strValue.c_str());	break;
	case	GISACLineSegment_GraphPath				:toValue(gData.gData.strPath			, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPowerTransformer(tagGISPowerTransformer& gData, const int nField)
{
	switch (nField)
	{
	case	GISPowerTransformer_ResourceID			:return	toString(gData.strResourceID			);	break;
	case	GISPowerTransformer_PSRTypeTag			:return	toString(gData.strPSRTypeTag			);	break;
	case	GISPowerTransformer_ObjectID			:return	toString(gData.strObjectID				);	break;
	case	GISPowerTransformer_Name				:return	toString(gData.strName					);	break;
	case	GISPowerTransformer_Unit				:return	toString(gData.strUnit					);	break;
	case	GISPowerTransformer_ParentTag			:return	toString(gData.strParentTag				);	break;
	case	GISPowerTransformer_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISPowerTransformer_RatedCapacity		:return	toString(gData.fRatedCapacity			);	break;
	case	GISPowerTransformer_Model				:return	toString(gData.strModel					);	break;
	case	GISPowerTransformer_PlanCharacter		:return	toString(gData.nPlanCharacter			);	break;
	case	GISPowerTransformer_Distribution		:return	toString(gData.bDistribution			);	break;
	case	GISPowerTransformer_Public				:return	toString(gData.bPublic					);	break;
	case	GISPowerTransformer_BuildDate			:return	toString(gData.nBuildDate				);	break;
	case	GISPowerTransformer_ReBuildDate			:return	toString(gData.nReBuildDate				);	break;
	case	GISPowerTransformer_OutageDate			:return	toString(gData.nOutageDate				);	break;
	case	GISPowerTransformer_RunTimeSpan			:return	toString(gData.nRunTimeSpan				);	break;
	case	GISPowerTransformer_ManuDate			:return	toString(gData.nManuDate				);	break;
	case	GISPowerTransformer_ConstructDate		:return	toString(gData.nConstructDate			);	break;
	case	GISPowerTransformer_Parent				:return	toString(gData.strParent				);	break;
	case	GISPowerTransformer_NodeH				:return	toString(gData.strNodeArray[0]			);	break;
	case	GISPowerTransformer_NodeM				:return	toString(gData.strNodeArray[1]			);	break;
	case	GISPowerTransformer_NodeL				:return	toString(gData.strNodeArray[2]			);	break;
	case	GISPowerTransformer_VoltH				:return	toString(gData.strVoltTagArray[0]		);	break;
	case	GISPowerTransformer_VoltM				:return	toString(gData.strVoltTagArray[1]		);	break;
	case	GISPowerTransformer_VoltL				:return	toString(gData.strVoltTagArray[2]		);	break;

	case	GISPowerTransformer_ri_rerr				:return	toString(gData.ri_Rerr					);	break;
	case	GISPowerTransformer_ri_trep				:return	toString(gData.ri_Trep					);	break;
	case	GISPowerTransformer_ri_rchk				:return	toString(gData.ri_Rchk					);	break;
	case	GISPowerTransformer_ri_tchk				:return	toString(gData.ri_Tchk					);	break;
	case	GISPowerTransformer_ri_tfloc			:return	toString(gData.ri_Tfloc					);	break;
	case	GISPowerTransformer_ri_rswitch			:return	toString(gData.ri_RSwitch				);	break;
	case	GISPowerTransformer_ri_tswitch			:return	toString(gData.ri_TSwitch				);	break;
	case	GISPowerTransformer_ri_customer			:return	toString(gData.ri_Customer				);	break;
	case	GISPowerTransformer_ri_load_rerr		:return	toString(gData.ri_load_rerr				);	break;
	case	GISPowerTransformer_ri_load_trep		:return	toString(gData.ri_load_trep				);	break;
	case	GISPowerTransformer_ri_load_rchk		:return	toString(gData.ri_load_rchk				);	break;
	case	GISPowerTransformer_ri_load_tchk		:return	toString(gData.ri_load_tchk				);	break;
	case	GISPowerTransformer_ei_invest			:return	toString(gData.ei_Invest				);	break;

	case	GISPowerTransformer_SubIdx				:return	toString(gData.nSubIdx					);	break;
	case	GISPowerTransformer_NodeHIdx			:return	toString(gData.nNodeArray[0]			);	break;
	case	GISPowerTransformer_NodeMIdx			:return	toString(gData.nNodeArray[1]			);	break;
	case	GISPowerTransformer_NodeLIdx			:return	toString(gData.nNodeArray[2]			);	break;
	case	GISPowerTransformer_WindNum				:return	toString(gData.nWindNum					);	break;
	case	GISPowerTransformer_Coordinate			:return	toString(gData.gData.strCoordinate		);	break;
	case	GISPowerTransformer_SymbolID			:return	toString(gData.gData.strSymbolID		);	break;
	case	GISPowerTransformer_SymbolSize			:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISPowerTransformer_SymbolAngle			:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISPowerTransformer_GraphPath			:return	toString(gData.gData.strPath			);	break;
	case	GISPowerTransformer_Location			:return	toString(gData.ptLoc					);	break;
	case	GISPowerTransformer_VertexH				:return	toString(gData.ptVertArray[0]			);	break;
	case	GISPowerTransformer_VertexM				:return	toString(gData.ptVertArray[1]			);	break;
	case	GISPowerTransformer_VertexL				:return	toString(gData.ptVertArray[2]			);	break;
	case	GISPowerTransformer_GraphSize			:return	toString(gData.fSize					);	break;
	case	GISPowerTransformer_P					:return	toString(gData.fP						);	break;
	case	GISPowerTransformer_Q					:return	toString(gData.fQ						);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPowerTransformer(tagGISPowerTransformer& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPowerTransformer_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPowerTransformer_PSRTypeTag			:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPowerTransformer_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISPowerTransformer_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISPowerTransformer_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISPowerTransformer_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISPowerTransformer_BaseVoltageTag		:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISPowerTransformer_RatedCapacity		:toValue(gData.fRatedCapacity		, strValue.c_str());	break;
	case	GISPowerTransformer_Model				:toValue(gData.strModel				, strValue.c_str());	break;
	case	GISPowerTransformer_PlanCharacter		:toValue(gData.nPlanCharacter		, strValue.c_str());	break;
	case	GISPowerTransformer_Distribution		:toValue(gData.bDistribution		, strValue.c_str());	break;
	case	GISPowerTransformer_Public				:toValue(gData.bPublic				, strValue.c_str());	break;
	case	GISPowerTransformer_BuildDate			:toValue(gData.nBuildDate			, strValue.c_str());	break;
	case	GISPowerTransformer_ReBuildDate			:toValue(gData.nReBuildDate			, strValue.c_str());	break;
	case	GISPowerTransformer_OutageDate			:toValue(gData.nOutageDate			, strValue.c_str());	break;
	case	GISPowerTransformer_RunTimeSpan			:toValue(gData.nRunTimeSpan			, strValue.c_str());	break;
	case	GISPowerTransformer_ManuDate			:toValue(gData.nManuDate			, strValue.c_str());	break;
	case	GISPowerTransformer_ConstructDate		:toValue(gData.nConstructDate		, strValue.c_str());	break;
	case	GISPowerTransformer_Parent				:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISPowerTransformer_NodeH				:toValue(gData.strNodeArray[0]		, strValue.c_str());	break;
	case	GISPowerTransformer_NodeM				:toValue(gData.strNodeArray[1]		, strValue.c_str());	break;
	case	GISPowerTransformer_NodeL				:toValue(gData.strNodeArray[2]		, strValue.c_str());	break;
	case	GISPowerTransformer_VoltH				:toValue(gData.strVoltTagArray[0]	, strValue.c_str());	break;
	case	GISPowerTransformer_VoltM				:toValue(gData.strVoltTagArray[1]	, strValue.c_str());	break;
	case	GISPowerTransformer_VoltL				:toValue(gData.strVoltTagArray[2]	, strValue.c_str());	break;

	case	GISPowerTransformer_ri_rerr				:toValue(gData.ri_Rerr				, strValue.c_str());	break;
	case	GISPowerTransformer_ri_trep				:toValue(gData.ri_Trep				, strValue.c_str());	break;
	case	GISPowerTransformer_ri_rchk				:toValue(gData.ri_Rchk				, strValue.c_str());	break;
	case	GISPowerTransformer_ri_tchk				:toValue(gData.ri_Tchk				, strValue.c_str());	break;
	case	GISPowerTransformer_ri_tfloc			:toValue(gData.ri_Tfloc				, strValue.c_str());	break;
	case	GISPowerTransformer_ri_rswitch			:toValue(gData.ri_RSwitch			, strValue.c_str());	break;
	case	GISPowerTransformer_ri_tswitch			:toValue(gData.ri_TSwitch			, strValue.c_str());	break;
	case	GISPowerTransformer_ri_customer			:toValue(gData.ri_Customer			, strValue.c_str());	break;
	case	GISPowerTransformer_ri_load_rerr		:toValue(gData.ri_load_rerr			, strValue.c_str());	break;
	case	GISPowerTransformer_ri_load_trep		:toValue(gData.ri_load_trep			, strValue.c_str());	break;
	case	GISPowerTransformer_ri_load_rchk		:toValue(gData.ri_load_rchk			, strValue.c_str());	break;
	case	GISPowerTransformer_ri_load_tchk		:toValue(gData.ri_load_tchk			, strValue.c_str());	break;
	case	GISPowerTransformer_ei_invest			:toValue(gData.ei_Invest			, strValue.c_str());	break;

	case	GISPowerTransformer_SubIdx				:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISPowerTransformer_NodeHIdx			:toValue(gData.nNodeArray[0]		, strValue.c_str());	break;
	case	GISPowerTransformer_NodeMIdx			:toValue(gData.nNodeArray[1]		, strValue.c_str());	break;
	case	GISPowerTransformer_NodeLIdx			:toValue(gData.nNodeArray[2]		, strValue.c_str());	break;
	case	GISPowerTransformer_WindNum				:toValue(gData.nWindNum				, strValue.c_str());	break;
	case	GISPowerTransformer_Coordinate			:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISPowerTransformer_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISPowerTransformer_SymbolSize			:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISPowerTransformer_SymbolAngle			:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISPowerTransformer_GraphPath			:toValue(gData.gData.strPath		, strValue.c_str());	break;
	case	GISPowerTransformer_Location			:toValue(gData.ptLoc				, strValue.c_str());	break;
	case	GISPowerTransformer_VertexH				:toValue(gData.ptVertArray[0]		, strValue.c_str());	break;
	case	GISPowerTransformer_VertexM				:toValue(gData.ptVertArray[1]		, strValue.c_str());	break;
	case	GISPowerTransformer_VertexL				:toValue(gData.ptVertArray[2]		, strValue.c_str());	break;
	case	GISPowerTransformer_GraphSize			:toValue(gData.fSize				, strValue.c_str());	break;
	case	GISPowerTransformer_P					:toValue(gData.fP					, strValue.c_str());	break;
	case	GISPowerTransformer_Q					:toValue(gData.fQ					, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISConnLine(tagGISConnLine& gData, const int nField)
{
	switch (nField)
	{
	case	GISConnLine_ResourceID		:return	toString(gData.strResourceID			);	break;
	case	GISConnLine_PSRTypeTag		:return	toString(gData.strPSRTypeTag			);	break;
	case	GISConnLine_ObjectID		:return	toString(gData.strObjectID				);	break;
	case	GISConnLine_Name			:return	toString(gData.strName					);	break;
	case	GISConnLine_Unit			:return	toString(gData.strUnit					);	break;
	case	GISConnLine_ParentTag		:return	toString(gData.strParentTag				);	break;
	case	GISConnLine_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISConnLine_Parent			:return	toString(gData.strParent				);	break;
	case	GISConnLine_NodeI			:return	toString(gData.strNodeI					);	break;
	case	GISConnLine_NodeZ			:return	toString(gData.strNodeZ					);	break;
	case	GISConnLine_SubIdx			:return	toString(gData.nSubIdx					);	break;
	case	GISConnLine_INodeIdx		:return	toString(gData.nNodeI					);	break;
	case	GISConnLine_ZNodeIdx		:return	toString(gData.nNodeZ					);	break;
	case	GISConnLine_Coordinate		:return	toString(gData.gData.strCoordinate		);	break;
	case	GISConnLine_SymbolID		:return	toString(gData.gData.strSymbolID		);	break;
	case	GISConnLine_SymbolSize		:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISConnLine_SymbolAngle		:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISConnLine_GraphPath		:return	toString(gData.gData.strPath			);	break;
	case	GISConnLine_Flag			:return	toString(gData.bFlag					);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISConnLine(tagGISConnLine& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISConnLine_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISConnLine_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISConnLine_ObjectID		:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISConnLine_Name			:toValue(gData.strName					, strValue.c_str());	break;
	case	GISConnLine_Unit			:toValue(gData.strUnit					, strValue.c_str());	break;
	case	GISConnLine_ParentTag		:toValue(gData.strParentTag				, strValue.c_str());	break;
	case	GISConnLine_BaseVoltageTag	:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISConnLine_Parent			:toValue(gData.strParent				, strValue.c_str());	break;
	case	GISConnLine_NodeI			:toValue(gData.strNodeI					, strValue.c_str());	break;
	case	GISConnLine_NodeZ			:toValue(gData.strNodeZ					, strValue.c_str());	break;
	case	GISConnLine_SubIdx			:toValue(gData.nSubIdx					, strValue.c_str());	break;
	case	GISConnLine_INodeIdx		:toValue(gData.nNodeI					, strValue.c_str());	break;
	case	GISConnLine_ZNodeIdx		:toValue(gData.nNodeZ					, strValue.c_str());	break;
	case	GISConnLine_Coordinate		:toValue(gData.gData.strCoordinate		, strValue.c_str());	break;
	case	GISConnLine_SymbolID		:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISConnLine_SymbolSize		:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISConnLine_SymbolAngle		:toValue(gData.gData.fSymbolAngle		, strValue.c_str());	break;
	case	GISConnLine_GraphPath		:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISConnLine_Flag			:toValue(gData.bFlag					, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISBusbarSection(tagGISBusbarSection& gData, const int nField)
{
	switch (nField)
	{
	case	GISBusbarSection_ResourceID			:return	toString(gData.strResourceID			);	break;
	case	GISBusbarSection_PSRTypeTag			:return	toString(gData.strPSRTypeTag			);	break;
	case	GISBusbarSection_ObjectID			:return	toString(gData.strObjectID				);	break;
	case	GISBusbarSection_Name				:return	toString(gData.strName					);	break;
	case	GISBusbarSection_Unit				:return	toString(gData.strUnit					);	break;
	case	GISBusbarSection_ParentTag			:return	toString(gData.strParentTag				);	break;
	case	GISBusbarSection_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISBusbarSection_Parent				:return	toString(gData.strParent				);	break;
	case	GISBusbarSection_Node				:return	toString(gData.strNode					);	break;

	case	GISBusbarSection_ri_rerr			:return	toString(gData.ri_Rerr					);	break;
	case	GISBusbarSection_ri_trep			:return	toString(gData.ri_Trep					);	break;
	case	GISBusbarSection_ri_rchk			:return	toString(gData.ri_Rchk					);	break;
	case	GISBusbarSection_ri_tchk			:return	toString(gData.ri_Tchk					);	break;
	case	GISBusbarSection_ri_tfloc			:return	toString(gData.ri_Tfloc					);	break;
	case	GISBusbarSection_ri_customer		:return	toString(gData.ri_Customer				);	break;
	case	GISBusbarSection_ri_load_rerr		:return	toString(gData.ri_load_rerr				);	break;
	case	GISBusbarSection_ri_load_trep		:return	toString(gData.ri_load_trep				);	break;
	case	GISBusbarSection_ri_load_rchk		:return	toString(gData.ri_load_rchk				);	break;
	case	GISBusbarSection_ri_load_tchk		:return	toString(gData.ri_load_tchk				);	break;
	case	GISBusbarSection_ei_invest			:return	toString(gData.ei_Invest				);	break;

	case	GISBusbarSection_SubIdx				:return	toString(gData.nSubIdx					);	break;
	case	GISBusbarSection_NodeIdx			:return	toString(gData.nNode					);	break;
	case	GISBusbarSection_Coordinate			:return	toString(gData.gData.strCoordinate		);	break;
	case	GISBusbarSection_SymbolID			:return	toString(gData.gData.strSymbolID		);	break;
	case	GISBusbarSection_SymbolSize			:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISBusbarSection_SymbolAngle		:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISBusbarSection_GraphPath			:return	toString(gData.gData.strPath			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISBusbarSection(tagGISBusbarSection& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISBusbarSection_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISBusbarSection_PSRTypeTag			:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISBusbarSection_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISBusbarSection_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISBusbarSection_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISBusbarSection_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISBusbarSection_BaseVoltageTag		:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISBusbarSection_Parent				:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISBusbarSection_Node				:toValue(gData.strNode				, strValue.c_str());	break;

	case	GISBusbarSection_ri_rerr			:toValue(gData.ri_Rerr				, strValue.c_str());	break;
	case	GISBusbarSection_ri_trep			:toValue(gData.ri_Trep				, strValue.c_str());	break;
	case	GISBusbarSection_ri_rchk			:toValue(gData.ri_Rchk				, strValue.c_str());	break;
	case	GISBusbarSection_ri_tchk			:toValue(gData.ri_Tchk				, strValue.c_str());	break;
	case	GISBusbarSection_ri_tfloc			:toValue(gData.ri_Tfloc				, strValue.c_str());	break;
	case	GISBusbarSection_ri_customer		:toValue(gData.ri_Customer			, strValue.c_str());	break;
	case	GISBusbarSection_ri_load_rerr		:toValue(gData.ri_load_rerr			, strValue.c_str());	break;
	case	GISBusbarSection_ri_load_trep		:toValue(gData.ri_load_trep			, strValue.c_str());	break;
	case	GISBusbarSection_ri_load_rchk		:toValue(gData.ri_load_rchk			, strValue.c_str());	break;
	case	GISBusbarSection_ri_load_tchk		:toValue(gData.ri_load_tchk			, strValue.c_str());	break;
	case	GISBusbarSection_ei_invest			:toValue(gData.ei_Invest			, strValue.c_str());	break;

	case	GISBusbarSection_SubIdx				:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISBusbarSection_NodeIdx			:toValue(gData.nNode				, strValue.c_str());	break;
	case	GISBusbarSection_Coordinate			:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISBusbarSection_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISBusbarSection_SymbolSize			:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISBusbarSection_SymbolAngle		:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISBusbarSection_GraphPath			:toValue(gData.gData.strPath		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPole(tagGISPole& gData, const int nField)
{
	switch (nField)
	{
	case	GISPole_ResourceID			:return	toString(gData.strResourceID			);	break;
	case	GISPole_PSRTypeTag			:return	toString(gData.strPSRTypeTag			);	break;
	case	GISPole_ObjectID			:return	toString(gData.strObjectID				);	break;
	case	GISPole_Name				:return	toString(gData.strName					);	break;
	case	GISPole_Unit				:return	toString(gData.strUnit					);	break;
	case	GISPole_aliasName			:return	toString(gData.strAlias					);	break;
	case	GISPole_description			:return	toString(gData.strDesp					);	break;
	case	GISPole_ParentTag			:return	toString(gData.strParentTag				);	break;
	case	GISPole_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISPole_BuildDate			:return	toString(gData.nBuildDate				);	break;
	case	GISPole_ReBuildDate			:return	toString(gData.nReBuildDate				);	break;
	case	GISPole_OutageDate			:return	toString(gData.nOutageDate				);	break;
	case	GISPole_RunTimeSpan			:return	toString(gData.nRunTimeSpan				);	break;
	case	GISPole_PlanCharacter		:return	toString(gData.nPlanCharacter			);	break;
	case	GISPole_Parent				:return	toString(gData.strParent				);	break;
	case	GISPole_Node				:return	toString(gData.strNode					);	break;
	case	GISPole_SubIdx				:return	toString(gData.nSubIdx					);	break;
	case	GISPole_NodeIdx				:return	toString(gData.nNode					);	break;
	case	GISPole_Coordinate			:return	toString(gData.gData.strCoordinate		);	break;
	case	GISPole_SymbolID			:return	toString(gData.gData.strSymbolID		);	break;
	case	GISPole_SymbolSize			:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISPole_SymbolAngle			:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISPole_GraphPath			:return	toString(gData.gData.strPath			);	break;
	case	GISPole_Location			:return	toString(gData.ptLoc					);	break;
	case	GISPole_GraphSize			:return	toString(gData.fSize					);	break;
	case	GISPole_Valid				:return	toString(gData.bValid					);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPole(tagGISPole& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPole_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPole_PSRTypeTag			:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPole_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISPole_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISPole_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISPole_aliasName			:toValue(gData.strAlias				, strValue.c_str());	break;
	case	GISPole_description			:toValue(gData.strDesp				, strValue.c_str());	break;
	case	GISPole_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISPole_BaseVoltageTag		:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISPole_BuildDate			:toValue(gData.nBuildDate			, strValue.c_str());	break;
	case	GISPole_ReBuildDate			:toValue(gData.nReBuildDate			, strValue.c_str());	break;
	case	GISPole_OutageDate			:toValue(gData.nOutageDate			, strValue.c_str());	break;
	case	GISPole_RunTimeSpan			:toValue(gData.nRunTimeSpan			, strValue.c_str());	break;
	case	GISPole_PlanCharacter		:toValue(gData.nPlanCharacter		, strValue.c_str());	break;
	case	GISPole_Parent				:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISPole_Node				:toValue(gData.strNode				, strValue.c_str());	break;
	case	GISPole_SubIdx				:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISPole_NodeIdx				:toValue(gData.nNode				, strValue.c_str());	break;
	case	GISPole_Coordinate			:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISPole_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISPole_SymbolSize			:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISPole_SymbolAngle			:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISPole_GraphPath			:toValue(gData.gData.strPath		, strValue.c_str());	break;
	case	GISPole_Location			:toValue(gData.ptLoc				, strValue.c_str());	break;
	case	GISPole_GraphSize			:toValue(gData.fSize				, strValue.c_str());	break;
	case	GISPole_Valid				:toValue(gData.bValid				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISJunction(tagGISJunction& gData, const int nField)
{
	switch (nField)
	{
	case	GISJunction_ResourceID			:return	toString(gData.strResourceID			);	break;
	case	GISJunction_PSRTypeTag			:return	toString(gData.strPSRTypeTag			);	break;
	case	GISJunction_ObjectID			:return	toString(gData.strObjectID				);	break;
	case	GISJunction_Name				:return	toString(gData.strName					);	break;
	case	GISJunction_Unit				:return	toString(gData.strUnit					);	break;
	case	GISJunction_ParentTag			:return	toString(gData.strParentTag				);	break;
	case	GISJunction_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISJunction_BuildDate			:return	toString(gData.nPlanCharacter			);	break;
	case	GISJunction_ReBuildDate			:return	toString(gData.nBuildDate				);	break;
	case	GISJunction_OutageDate			:return	toString(gData.nReBuildDate				);	break;
	case	GISJunction_RunTimeSpan			:return	toString(gData.nOutageDate				);	break;
	case	GISJunction_PlanCharacter		:return	toString(gData.nRunTimeSpan				);	break;
	case	GISJunction_Parent				:return	toString(gData.strParent				);	break;
	case	GISJunction_Node				:return	toString(gData.strNode					);	break;
	case	GISJunction_SubIdx				:return	toString(gData.nSubIdx					);	break;
	case	GISJunction_NodeIdx				:return	toString(gData.nNode					);	break;
	case	GISJunction_Coordinate			:return	toString(gData.gData.strCoordinate		);	break;
	case	GISJunction_SymbolID			:return	toString(gData.gData.strSymbolID		);	break;
	case	GISJunction_SymbolSize			:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISJunction_SymbolAngle			:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISJunction_GraphPath			:return	toString(gData.gData.strPath			);	break;
	case	GISJunction_Location			:return	toString(gData.ptLoc					);	break;
	case	GISJunction_GraphSize			:return	toString(gData.fSize					);	break;
	case	GISJunction_Valid				:return	toString(gData.bValid					);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISJunction(tagGISJunction& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISJunction_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISJunction_PSRTypeTag			:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISJunction_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISJunction_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISJunction_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISJunction_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISJunction_BaseVoltageTag		:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISJunction_BuildDate			:toValue(gData.nPlanCharacter		, strValue.c_str());	break;
	case	GISJunction_ReBuildDate			:toValue(gData.nBuildDate			, strValue.c_str());	break;
	case	GISJunction_OutageDate			:toValue(gData.nReBuildDate			, strValue.c_str());	break;
	case	GISJunction_RunTimeSpan			:toValue(gData.nOutageDate			, strValue.c_str());	break;
	case	GISJunction_PlanCharacter		:toValue(gData.nRunTimeSpan			, strValue.c_str());	break;
	case	GISJunction_Parent				:toValue(gData.strParent			, strValue.c_str());	break;
	case	GISJunction_Node				:toValue(gData.strNode				, strValue.c_str());	break;
	case	GISJunction_SubIdx				:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISJunction_NodeIdx				:toValue(gData.nNode				, strValue.c_str());	break;
	case	GISJunction_Coordinate			:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISJunction_SymbolID			:toValue(gData.gData.strSymbolID	, strValue.c_str());	break;
	case	GISJunction_SymbolSize			:toValue(gData.gData.fSymbolSize	, strValue.c_str());	break;
	case	GISJunction_SymbolAngle			:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISJunction_GraphPath			:toValue(gData.gData.strPath		, strValue.c_str());	break;
	case	GISJunction_Location			:toValue(gData.ptLoc				, strValue.c_str());	break;
	case	GISJunction_GraphSize			:toValue(gData.fSize				, strValue.c_str());	break;
	case	GISJunction_Valid				:toValue(gData.bValid				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISEnergyConsumer(tagGISEnergyConsumer& gData, const int nField)
{
	switch (nField)
	{
	case	GISEnergyConsumer_ResourceID		:return	toString(gData.strResourceID			);	break;
	case	GISEnergyConsumer_PSRTypeTag		:return	toString(gData.strPSRTypeTag			);	break;
	case	GISEnergyConsumer_ObjectID			:return	toString(gData.strObjectID				);	break;
	case	GISEnergyConsumer_Name				:return	toString(gData.strName					);	break;
	case	GISEnergyConsumer_Unit				:return	toString(gData.strUnit					);	break;
	case	GISEnergyConsumer_ParentTag			:return	toString(gData.strParentTag				);	break;
	case	GISEnergyConsumer_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag		);	break;
	case	GISEnergyConsumer_BelongPSRTag		:return	toString(gData.strBelongPSRTag			);	break;
	case	GISEnergyConsumer_Public			:return	toString(gData.bIsPublic				);	break;
	case	GISEnergyConsumer_P					:return	toString(gData.fP						);	break;
	case	GISEnergyConsumer_Q					:return	toString(gData.fQ						);	break;
	case	GISEnergyConsumer_CustumerNum		:return	toString(gData.fCustomNum				);	break;
	case	GISEnergyConsumer_Parent			:return	toString(gData.strParent				);	break;
	case	GISEnergyConsumer_Node				:return	toString(gData.strNode					);	break;
	case	GISEnergyConsumer_BelongPSRType		:return	toString(gData.nBelongPSRType			);	break;
	case	GISEnergyConsumer_BelongPSRName		:return	toString(gData.strBelongPSRName			);	break;
	case	GISEnergyConsumer_SubIdx			:return	toString(gData.nSubIdx					);	break;
	case	GISEnergyConsumer_NodeIdx			:return	toString(gData.nNode					);	break;
	case	GISEnergyConsumer_Coordinate		:return	toString(gData.gData.strCoordinate		);	break;
	case	GISEnergyConsumer_SymbolID			:return	toString(gData.gData.strSymbolID		);	break;
	case	GISEnergyConsumer_SymbolSize		:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISEnergyConsumer_SymbolAngle		:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISEnergyConsumer_GraphPath			:return	toString(gData.gData.strPath			);	break;
	case	GISEnergyConsumer_Location			:return	toString(gData.ptLoc					);	break;
	case	GISEnergyConsumer_GraphSize			:return	toString(gData.fSize					);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISEnergyConsumer(tagGISEnergyConsumer& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISEnergyConsumer_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISEnergyConsumer_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISEnergyConsumer_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISEnergyConsumer_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISEnergyConsumer_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISEnergyConsumer_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISEnergyConsumer_BaseVoltageTag	:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISEnergyConsumer_BelongPSRTag		:toValue(gData.strBelongPSRTag		, strValue.c_str());	break;
	case	GISEnergyConsumer_Public			:toValue(gData.bIsPublic				, strValue.c_str());	break;
	case	GISEnergyConsumer_P					:toValue(gData.fP					, strValue.c_str());	break;
	case	GISEnergyConsumer_Q					:toValue(gData.fQ					, strValue.c_str());	break;
	case	GISEnergyConsumer_CustumerNum		:toValue(gData.fCustomNum			, strValue.c_str());	break;
	case	GISEnergyConsumer_Parent			:toValue(gData.strParent				, strValue.c_str());	break;
	case	GISEnergyConsumer_Node				:toValue(gData.strNode				, strValue.c_str());	break;
	case	GISEnergyConsumer_BelongPSRType		:toValue(gData.nBelongPSRType		, strValue.c_str());	break;
	case	GISEnergyConsumer_BelongPSRName		:toValue(gData.strBelongPSRName		, strValue.c_str());	break;
	case	GISEnergyConsumer_SubIdx			:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISEnergyConsumer_NodeIdx			:toValue(gData.nNode					, strValue.c_str());	break;
	case	GISEnergyConsumer_Coordinate		:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISEnergyConsumer_SymbolID			:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISEnergyConsumer_SymbolSize		:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISEnergyConsumer_SymbolAngle		:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISEnergyConsumer_GraphPath			:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISEnergyConsumer_Location			:toValue(gData.ptLoc					, strValue.c_str());	break;
	case	GISEnergyConsumer_GraphSize			:toValue(gData.fSize					, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISCompensator(tagGISCompensator& gData, const int nField)
{
	switch (nField)
	{
	case	GISCompensator_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISCompensator_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISCompensator_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISCompensator_Name				:return	toString(gData.strName				);	break;
	case	GISCompensator_Unit				:return	toString(gData.strUnit				);	break;
	case	GISCompensator_ParentTag		:return	toString(gData.strParentTag			);	break;
	case	GISCompensator_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISCompensator_Parent			:return	toString(gData.strParent			);	break;
	case	GISCompensator_Node				:return	toString(gData.strNode				);	break;
	case	GISCompensator_SeriesNode		:return	toString(gData.strSeriesNode		);	break;
	case	GISCompensator_SubIdx			:return	toString(gData.nSubIdx				);	break;
	case	GISCompensator_NodeIdx			:return	toString(gData.nNode				);	break;
	case	GISCompensator_SeriesNodeIdx	:return	toString(gData.nSeriesNode			);	break;
	case	GISCompensator_Coordinate		:return	toString(gData.gData.strCoordinate	);	break;
	case	GISCompensator_SymbolID			:return	toString(gData.gData.strSymbolID	);	break;
	case	GISCompensator_SymbolSize		:return	toString(gData.gData.fSymbolSize	);	break;
	case	GISCompensator_SymbolAngle		:return	toString(gData.gData.fSymbolAngle	);	break;
	case	GISCompensator_GraphPath		:return	toString(gData.gData.strPath		);	break;
	case	GISCompensator_Location			:return	toString(gData.ptLoc				);	break;
	case	GISCompensator_GraphSize		:return	toString(gData.fSize				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISCompensator(tagGISCompensator& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISCompensator_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISCompensator_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISCompensator_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISCompensator_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISCompensator_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISCompensator_ParentTag		:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISCompensator_BaseVoltageTag	:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISCompensator_Parent			:toValue(gData.strParent				, strValue.c_str());	break;
	case	GISCompensator_Node				:toValue(gData.strNode				, strValue.c_str());	break;
	case	GISCompensator_SeriesNode		:toValue(gData.strSeriesNode			, strValue.c_str());	break;
	case	GISCompensator_SubIdx			:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISCompensator_NodeIdx			:toValue(gData.nNode					, strValue.c_str());	break;
	case	GISCompensator_SeriesNodeIdx	:toValue(gData.nSeriesNode			, strValue.c_str());	break;
	case	GISCompensator_Coordinate		:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISCompensator_SymbolID			:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISCompensator_SymbolSize		:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISCompensator_SymbolAngle		:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISCompensator_GraphPath		:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISCompensator_Location			:toValue(gData.ptLoc					, strValue.c_str());	break;
	case	GISCompensator_GraphSize		:toValue(gData.fSize					, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISCapacitor(tagGISCapacitor& gData, const int nField)
{
	switch (nField)
	{
	case	GISCapacitor_ResourceID			:return	toString(gData.strResourceID		);	break;
	case	GISCapacitor_PSRTypeTag			:return	toString(gData.strPSRTypeTag		);	break;
	case	GISCapacitor_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISCapacitor_Name				:return	toString(gData.strName				);	break;
	case	GISCapacitor_Unit				:return	toString(gData.strUnit				);	break;
	case	GISCapacitor_ParentTag			:return	toString(gData.strParentTag			);	break;
	case	GISCapacitor_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISCapacitor_Parent				:return	toString(gData.strParent			);	break;
	case	GISCapacitor_Node				:return	toString(gData.strNode				);	break;
	case	GISCapacitor_SubIdx				:return	toString(gData.nSubIdx				);	break;
	case	GISCapacitor_NodeIdx			:return	toString(gData.nNode				);	break;
	case	GISCapacitor_Coordinate			:return	toString(gData.gData.strCoordinate	);	break;
	case	GISCapacitor_SymbolID			:return	toString(gData.gData.strSymbolID	);	break;
	case	GISCapacitor_SymbolSize			:return	toString(gData.gData.fSymbolSize	);	break;
	case	GISCapacitor_SymbolAngle		:return	toString(gData.gData.fSymbolAngle	);	break;
	case	GISCapacitor_GraphPath			:return	toString(gData.gData.strPath		);	break;
	case	GISCapacitor_Location			:return	toString(gData.ptLoc				);	break;
	case	GISCapacitor_GraphSize			:return	toString(gData.fSize				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISCapacitor(tagGISCapacitor& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISCapacitor_ResourceID			:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISCapacitor_PSRTypeTag			:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISCapacitor_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISCapacitor_Name				:toValue(gData.strName				, strValue.c_str());	break;
	case	GISCapacitor_Unit				:toValue(gData.strUnit				, strValue.c_str());	break;
	case	GISCapacitor_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	case	GISCapacitor_BaseVoltageTag		:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISCapacitor_Parent				:toValue(gData.strParent				, strValue.c_str());	break;
	case	GISCapacitor_Node				:toValue(gData.strNode				, strValue.c_str());	break;
	case	GISCapacitor_SubIdx				:toValue(gData.nSubIdx				, strValue.c_str());	break;
	case	GISCapacitor_NodeIdx			:toValue(gData.nNode					, strValue.c_str());	break;
	case	GISCapacitor_Coordinate			:toValue(gData.gData.strCoordinate	, strValue.c_str());	break;
	case	GISCapacitor_SymbolID			:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISCapacitor_SymbolSize			:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISCapacitor_SymbolAngle		:toValue(gData.gData.fSymbolAngle	, strValue.c_str());	break;
	case	GISCapacitor_GraphPath			:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISCapacitor_Location			:toValue(gData.ptLoc					, strValue.c_str());	break;
	case	GISCapacitor_GraphSize			:toValue(gData.fSize					, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISTerminal(tagGISTerminal& gData, const int nField)
{
	switch (nField)
	{
	case	GISTerminal_ResourceID		:return toString(gData.strResourceID		);	break;
	case	GISTerminal_ParentTag		:return toString(gData.strParentTag		);	break;
	case	GISTerminal_NodeTag			:return toString(gData.strNodeTag		);	break;
	case	GISTerminal_NodeIdx			:return toString(gData.nNode				);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISTerminal(tagGISTerminal& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISTerminal_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISTerminal_ParentTag		:toValue(gData.strParentTag		, strValue.c_str());	break;
	case	GISTerminal_NodeTag			:toValue(gData.strNodeTag		, strValue.c_str());	break;
	case	GISTerminal_NodeIdx			:toValue(gData.nNode				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISConnectivityNode(tagGISConnectivityNode& gData, const int nField)
{
	switch (nField)
	{
	case	GISConnectivityNode_ResourceID		:return	toString(gData.strResourceID	);	break;
	case	GISConnectivityNode_VoltageLevel	:return	toString(gData.strBaseVoltageTag);	break;
	//case	GISConnectivityNode_Vertex			:return	toString(gData.ptVert			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISConnectivityNode(tagGISConnectivityNode& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISConnectivityNode_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISConnectivityNode_VoltageLevel	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	//case	GISConnectivityNode_Vertex			:toValue(gData.ptVert			, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPipe(tagGISPipe& gData, const int nField)
{
	switch (nField)
	{
	case	GISPipe_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISPipe_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISPipe_ObjectID		:return	toString(gData.strObjectID			);	break;
	case	GISPipe_Name			:return	toString(gData.strName				);	break;
	case	GISPipe_Model			:return	toString(gData.strModel				);	break;
	case	GISPipe_BuildDate		:return	toString(gData.nBuildDate			);	break;
	case	GISPipe_RebuildDate	:return	toString(gData.nReBuildDate			);	break;
	case	GISPipe_OutageDate		:return	toString(gData.nOutageDate			);	break;
	case	GISPipe_RunTimeSpan	:return	toString(gData.nRunTimeSpan			);	break;
	case	GISPipe_PlanCharacter	:return	toString(gData.nPlanCharacter		);	break;
	case	GISPipe_MaxHVCableNum	:return	toString(gData.nMaxHVCableNum		);	break;
	case	GISPipe_MaxMVCableNum	:return	toString(gData.nMaxMVCableNum		);	break;
	case	GISPipe_MaxLVCableNum	:return	toString(gData.nMaxLVCableNum		);	break;
	case	GISPipe_HVCableNum		:return	toString(gData.nHVCableNum			);	break;
	case	GISPipe_MVCableNum		:return	toString(gData.nMVCableNum			);	break;
	case	GISPipe_LVCableNum		:return	toString(gData.nLVCableNum			);	break;
	case	GISPipe_HVCable1		:return	toString(gData.strHVCable[0]		);	break;
	case	GISPipe_HVCable2		:return	toString(gData.strHVCable[1]		);	break;
	case	GISPipe_HVCable3		:return	toString(gData.strHVCable[2]		);	break;
	case	GISPipe_HVCable4		:return	toString(gData.strHVCable[3]		);	break;
	case	GISPipe_MVCable1		:return	toString(gData.strMVCable[0]		);	break;
	case	GISPipe_MVCable2		:return	toString(gData.strMVCable[1]		);	break;
	case	GISPipe_MVCable3		:return	toString(gData.strMVCable[2]		);	break;
	case	GISPipe_MVCable4		:return	toString(gData.strMVCable[3]		);	break;
	case	GISPipe_MVCable5		:return	toString(gData.strMVCable[4]		);	break;
	case	GISPipe_MVCable6		:return	toString(gData.strMVCable[5]		);	break;
	case	GISPipe_MVCable7		:return	toString(gData.strMVCable[6]		);	break;
	case	GISPipe_MVCable8		:return	toString(gData.strMVCable[7]		);	break;
	case	GISPipe_LVCable01		:return	toString(gData.strLVCable[0]		);	break;
	case	GISPipe_LVCable02		:return	toString(gData.strLVCable[1]		);	break;
	case	GISPipe_LVCable03		:return	toString(gData.strLVCable[2]		);	break;
	case	GISPipe_LVCable04		:return	toString(gData.strLVCable[3]		);	break;
	case	GISPipe_LVCable05		:return	toString(gData.strLVCable[4]		);	break;
	case	GISPipe_LVCable06		:return	toString(gData.strLVCable[5]		);	break;
	case	GISPipe_LVCable07		:return	toString(gData.strLVCable[6]		);	break;
	case	GISPipe_LVCable08		:return	toString(gData.strLVCable[7]		);	break;
	case	GISPipe_LVCable09		:return	toString(gData.strLVCable[8]		);	break;
	case	GISPipe_LVCable10		:return	toString(gData.strLVCable[9]		);	break;
	case	GISPipe_LVCable11		:return	toString(gData.strLVCable[10]		);	break;
	case	GISPipe_LVCable12		:return	toString(gData.strLVCable[11]		);	break;
	case	GISPipe_LVCable13		:return	toString(gData.strLVCable[12]		);	break;
	case	GISPipe_LVCable14		:return	toString(gData.strLVCable[13]		);	break;
	case	GISPipe_LVCable15		:return	toString(gData.strLVCable[14]		);	break;
	case	GISPipe_LVCable16		:return	toString(gData.strLVCable[15]		);	break;
	case	GISPipe_LVCable17		:return	toString(gData.strLVCable[16]		);	break;
	case	GISPipe_LVCable18		:return	toString(gData.strLVCable[17]		);	break;
	case	GISPipe_LVCable19		:return	toString(gData.strLVCable[18]		);	break;
	case	GISPipe_LVCable20		:return	toString(gData.strLVCable[19]		);	break;
	case	GISPipe_LVCable21		:return	toString(gData.strLVCable[20]		);	break;
	case	GISPipe_LVCable22		:return	toString(gData.strLVCable[21]		);	break;
	case	GISPipe_LVCable23		:return	toString(gData.strLVCable[22]		);	break;
	case	GISPipe_LVCable24		:return	toString(gData.strLVCable[23]		);	break;
	case	GISPipe_LVCable25		:return	toString(gData.strLVCable[24]		);	break;
	case	GISPipe_LVCable26		:return	toString(gData.strLVCable[25]		);	break;
	case	GISPipe_LVCable27		:return	toString(gData.strLVCable[26]		);	break;
	case	GISPipe_LVCable28		:return	toString(gData.strLVCable[27]		);	break;
	case	GISPipe_LVCable29		:return	toString(gData.strLVCable[28]		);	break;
	case	GISPipe_LVCable30		:return	toString(gData.strLVCable[29]		);	break;
	case	GISPipe_LVCable31		:return	toString(gData.strLVCable[30]		);	break;
	case	GISPipe_LVCable32		:return	toString(gData.strLVCable[31]		);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPipe(tagGISPipe& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPipe_ResourceID		:return	toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPipe_PSRTypeTag		:return	toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPipe_ObjectID		:return	toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISPipe_Name			:return	toValue(gData.strName			, strValue.c_str());	break;
	case	GISPipe_Model			:return	toValue(gData.strModel			, strValue.c_str());	break;
	case	GISPipe_BuildDate		:return	toValue(gData.nBuildDate		, strValue.c_str());	break;
	case	GISPipe_RebuildDate		:return	toValue(gData.nReBuildDate		, strValue.c_str());	break;
	case	GISPipe_OutageDate		:return	toValue(gData.nOutageDate		, strValue.c_str());	break;
	case	GISPipe_RunTimeSpan		:return	toValue(gData.nRunTimeSpan		, strValue.c_str());	break;
	case	GISPipe_PlanCharacter	:return	toValue(gData.nPlanCharacter	, strValue.c_str());	break;
	case	GISPipe_MaxHVCableNum	:return	toValue(gData.nMaxHVCableNum	, strValue.c_str());	break;
	case	GISPipe_MaxMVCableNum	:return	toValue(gData.nMaxMVCableNum	, strValue.c_str());	break;
	case	GISPipe_MaxLVCableNum	:return	toValue(gData.nMaxLVCableNum	, strValue.c_str());	break;
	case	GISPipe_HVCableNum		:return	toValue(gData.nHVCableNum		, strValue.c_str());	break;
	case	GISPipe_MVCableNum		:return	toValue(gData.nMVCableNum		, strValue.c_str());	break;
	case	GISPipe_LVCableNum		:return	toValue(gData.nLVCableNum		, strValue.c_str());	break;
	case	GISPipe_HVCable1		:return	toValue(gData.strHVCable[0]		, strValue.c_str());	break;
	case	GISPipe_HVCable2		:return	toValue(gData.strHVCable[1]		, strValue.c_str());	break;
	case	GISPipe_HVCable3		:return	toValue(gData.strHVCable[2]		, strValue.c_str());	break;
	case	GISPipe_HVCable4		:return	toValue(gData.strHVCable[3]		, strValue.c_str());	break;
	case	GISPipe_MVCable1		:return	toValue(gData.strMVCable[0]		, strValue.c_str());	break;
	case	GISPipe_MVCable2		:return	toValue(gData.strMVCable[1]		, strValue.c_str());	break;
	case	GISPipe_MVCable3		:return	toValue(gData.strMVCable[2]		, strValue.c_str());	break;
	case	GISPipe_MVCable4		:return	toValue(gData.strMVCable[3]		, strValue.c_str());	break;
	case	GISPipe_MVCable5		:return	toValue(gData.strMVCable[4]		, strValue.c_str());	break;
	case	GISPipe_MVCable6		:return	toValue(gData.strMVCable[5]		, strValue.c_str());	break;
	case	GISPipe_MVCable7		:return	toValue(gData.strMVCable[6]		, strValue.c_str());	break;
	case	GISPipe_MVCable8		:return	toValue(gData.strMVCable[7]		, strValue.c_str());	break;
	case	GISPipe_LVCable01		:return	toValue(gData.strLVCable[0]		, strValue.c_str());	break;
	case	GISPipe_LVCable02		:return	toValue(gData.strLVCable[1]		, strValue.c_str());	break;
	case	GISPipe_LVCable03		:return	toValue(gData.strLVCable[2]		, strValue.c_str());	break;
	case	GISPipe_LVCable04		:return	toValue(gData.strLVCable[3]		, strValue.c_str());	break;
	case	GISPipe_LVCable05		:return	toValue(gData.strLVCable[4]		, strValue.c_str());	break;
	case	GISPipe_LVCable06		:return	toValue(gData.strLVCable[5]		, strValue.c_str());	break;
	case	GISPipe_LVCable07		:return	toValue(gData.strLVCable[6]		, strValue.c_str());	break;
	case	GISPipe_LVCable08		:return	toValue(gData.strLVCable[7]		, strValue.c_str());	break;
	case	GISPipe_LVCable09		:return	toValue(gData.strLVCable[8]		, strValue.c_str());	break;
	case	GISPipe_LVCable10		:return	toValue(gData.strLVCable[9]		, strValue.c_str());	break;
	case	GISPipe_LVCable11		:return	toValue(gData.strLVCable[10]	, strValue.c_str());	break;
	case	GISPipe_LVCable12		:return	toValue(gData.strLVCable[11]	, strValue.c_str());	break;
	case	GISPipe_LVCable13		:return	toValue(gData.strLVCable[12]	, strValue.c_str());	break;
	case	GISPipe_LVCable14		:return	toValue(gData.strLVCable[13]	, strValue.c_str());	break;
	case	GISPipe_LVCable15		:return	toValue(gData.strLVCable[14]	, strValue.c_str());	break;
	case	GISPipe_LVCable16		:return	toValue(gData.strLVCable[15]	, strValue.c_str());	break;
	case	GISPipe_LVCable17		:return	toValue(gData.strLVCable[16]	, strValue.c_str());	break;
	case	GISPipe_LVCable18		:return	toValue(gData.strLVCable[17]	, strValue.c_str());	break;
	case	GISPipe_LVCable19		:return	toValue(gData.strLVCable[18]	, strValue.c_str());	break;
	case	GISPipe_LVCable20		:return	toValue(gData.strLVCable[19]	, strValue.c_str());	break;
	case	GISPipe_LVCable21		:return	toValue(gData.strLVCable[20]	, strValue.c_str());	break;
	case	GISPipe_LVCable22		:return	toValue(gData.strLVCable[21]	, strValue.c_str());	break;
	case	GISPipe_LVCable23		:return	toValue(gData.strLVCable[22]	, strValue.c_str());	break;
	case	GISPipe_LVCable24		:return	toValue(gData.strLVCable[23]	, strValue.c_str());	break;
	case	GISPipe_LVCable25		:return	toValue(gData.strLVCable[24]	, strValue.c_str());	break;
	case	GISPipe_LVCable26		:return	toValue(gData.strLVCable[25]	, strValue.c_str());	break;
	case	GISPipe_LVCable27		:return	toValue(gData.strLVCable[26]	, strValue.c_str());	break;
	case	GISPipe_LVCable28		:return	toValue(gData.strLVCable[27]	, strValue.c_str());	break;
	case	GISPipe_LVCable29		:return	toValue(gData.strLVCable[28]	, strValue.c_str());	break;
	case	GISPipe_LVCable30		:return	toValue(gData.strLVCable[29]	, strValue.c_str());	break;
	case	GISPipe_LVCable31		:return	toValue(gData.strLVCable[30]	, strValue.c_str());	break;
	case	GISPipe_LVCable32		:return	toValue(gData.strLVCable[31]	, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPT(tagGISPT& gData, const int nField)
{
	switch (nField)
	{
	case	GISCT_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISCT_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISCT_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISCT_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPT(tagGISPT& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISCT_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISCT_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISCT_ObjectID			:toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISCT_BaseVoltageTag	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISCT(tagGISCT& gData, const int nField)
{
	switch (nField)
	{
	case	GISPT_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISPT_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISPT_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISPT_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISCT(tagGISCT& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPT_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPT_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPT_ObjectID			:toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISPT_BaseVoltageTag	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISBLQ(tagGISBLQ& gData, const int nField)
{
	switch (nField)
	{
	case	GISBLQ_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISBLQ_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISBLQ_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISBLQ_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISBLQ(tagGISBLQ& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISBLQ_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISBLQ_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISBLQ_ObjectID			:toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISBLQ_BaseVoltageTag	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISFaultIndicator(tagGISFaultIndicator& gData, const int nField)
{
	switch (nField)
	{
	case	GISFaultIndicator_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISFaultIndicator_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISFaultIndicator_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISFaultIndicator_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISFaultIndicator_ParentTag			:return	toString(gData.strParentTag			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISFaultIndicator(tagGISFaultIndicator& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISFaultIndicator_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISFaultIndicator_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISFaultIndicator_ObjectID			:toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISFaultIndicator_BaseVoltageTag	:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	case	GISFaultIndicator_ParentTag			:toValue(gData.strParentTag		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPTCab(tagGISPTCab& gData, const int nField)
{
	switch (nField)
	{
	case	GISPTCab_ResourceID			:return	toString(gData.strResourceID		);	break;
	case	GISPTCab_PSRTypeTag			:return	toString(gData.strPSRTypeTag		);	break;
	case	GISPTCab_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISPTCab_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag	);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPTCab(tagGISPTCab& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPTCab_ResourceID			:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPTCab_PSRTypeTag			:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPTCab_ObjectID			:toValue(gData.strObjectID		, strValue.c_str());	break;
	case	GISPTCab_BaseVoltageTag		:toValue(gData.strBaseVoltageTag	, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISGround(tagGISGround& gData, const int nField)
{
	switch (nField)
	{
	case	GISGround_ResourceID		:return	toString(gData.strResourceID		);	break;
	case	GISGround_PSRTypeTag		:return	toString(gData.strPSRTypeTag		);	break;
	case	GISGround_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISGround_BaseVoltageTag	:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISGround_ParentTag			:return	toString(gData.strParentTag			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISGround(tagGISGround& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISGround_ResourceID		:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISGround_PSRTypeTag		:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISGround_ObjectID			:toValue(gData.strObjectID			, strValue.c_str());	break;
	case	GISGround_BaseVoltageTag	:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISGround_ParentTag			:toValue(gData.strParentTag			, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPTCABU(tagGISPTCABU& gData, const int nField)
{
	switch (nField)
	{
	case	GISPTCABU_ResourceID	:return	toString(gData.strResourceID	);	break;
	case	GISPTCABU_PSRTypeTag	:return	toString(gData.strPSRTypeTag	);	break;
	case	GISPTCABU_ObjectID		:return	toString(gData.strObjectID		);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPTCABU(tagGISPTCABU& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPTCABU_ResourceID	:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPTCABU_PSRTypeTag	:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPTCABU_ObjectID		:toValue(gData.strObjectID		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISKWGXB(tagGISKWGXB& gData, const int nField)
{
	switch (nField)
	{
	case	GISKWGXB_ResourceID		:return	toString(gData.strResourceID	);		break;
	case	GISKWGXB_PSRTypeTag		:return	toString(gData.strPSRTypeTag	);		break;
	case	GISKWGXB_ObjectID		:return	toString(gData.strObjectID		);		break;
	}
	return "";
}

void CGISDataBuffer::SetGISKWGXB(tagGISKWGXB& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISKWGXB_ResourceID		:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISKWGXB_PSRTypeTag		:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISKWGXB_ObjectID		:toValue(gData.strObjectID		, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPFWELL(tagGISPFWELL& gData, const int nField)
{
	switch (nField)
	{
	case	GISPFWELL_ResourceID	:return	toString(gData.strResourceID	);	break;
	case	GISPFWELL_PSRTypeTag	:return	toString(gData.strPSRTypeTag	);	break;
	case	GISPFWELL_ObjectID		:return	toString(gData.strObjectID		);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPFWELL(tagGISPFWELL& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPFWELL_ResourceID	:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISPFWELL_PSRTypeTag	:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISPFWELL_ObjectID		:toValue(gData.strObjectID			, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISPFTUNN(tagGISPFTUNN& gData, const int nField)
{
	switch (nField)
	{
	case	GISPFTUNN_ResourceID	:return	toString(gData.strResourceID	);	break;
	case	GISPFTUNN_PSRTypeTag	:return	toString(gData.strPSRTypeTag	);	break;
	case	GISPFTUNN_ObjectID		:return	toString(gData.strObjectID		);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISPFTUNN(tagGISPFTUNN& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISPFTUNN_ResourceID	:toValue(gData.strResourceID		, strValue.c_str());	break;
	case	GISPFTUNN_PSRTypeTag	:toValue(gData.strPSRTypeTag		, strValue.c_str());	break;
	case	GISPFTUNN_ObjectID		:toValue(gData.strObjectID			, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISOther(tagGISOther& gData, const int nField)
{
	switch (nField)
	{
	case	GISOther_ResourceID			:return	toString(gData.strResourceID		);	break;
	case	GISOther_PSRTypeTag			:return	toString(gData.strPSRTypeTag		);	break;
	case	GISOther_ObjectID			:return	toString(gData.strObjectID			);	break;
	case	GISOther_BaseVoltageTag		:return	toString(gData.strBaseVoltageTag	);	break;
	case	GISOther_ParentTag			:return	toString(gData.strParentTag			);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISOther(tagGISOther& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISOther_ResourceID			:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISOther_PSRTypeTag			:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISOther_ObjectID			:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISOther_BaseVoltageTag		:toValue(gData.strBaseVoltageTag		, strValue.c_str());	break;
	case	GISOther_ParentTag			:toValue(gData.strParentTag				, strValue.c_str());	break;
	}
}

const std::string CGISDataBuffer::GetGISZJ(tagGISZJ& gData, const int nField)
{
	switch (nField)
	{
	case	GISZJ_ResourceID	:return	toString(gData.strResourceID			);	break;
	case	GISZJ_PSRTypeTag	:return	toString(gData.strPSRTypeTag			);	break;
	case	GISZJ_ObjectID		:return	toString(gData.strObjectID				);	break;
	case	GISZJ_TextHeight	:return	toString(gData.fTextHeight				);	break;
	case	GISZJ_Name			:return	toString(gData.strName					);	break;
	case	GISZJ_ParentTag		:return	toString(gData.strParentTag				);	break;
	case	GISZJ_Parent		:return	toString(gData.strParent				);	break;
	case	GISZJ_SubIdx		:return	toString(gData.nSubIdx					);	break;
	case	GISZJ_Coordinate	:return	toString(gData.gData.strCoordinate		);	break;
	case	GISZJ_SymbolID		:return	toString(gData.gData.strSymbolID		);	break;
	case	GISZJ_SymbolSize	:return	toString(gData.gData.fSymbolSize		);	break;
	case	GISZJ_SymbolAngle	:return	toString(gData.gData.fSymbolAngle		);	break;
	case	GISZJ_GraphPath		:return	toString(gData.gData.strPath			);	break;
	case	GISZJ_Location		:return	toString(gData.ptLoc					);	break;
	}
	return "";
}

void CGISDataBuffer::SetGISZJ(tagGISZJ& gData, const int nField, const std::string strValue)
{
	switch (nField)
	{
	case	GISZJ_ResourceID	:toValue(gData.strResourceID			, strValue.c_str());	break;
	case	GISZJ_PSRTypeTag	:toValue(gData.strPSRTypeTag			, strValue.c_str());	break;
	case	GISZJ_ObjectID		:toValue(gData.strObjectID				, strValue.c_str());	break;
	case	GISZJ_TextHeight	:toValue(gData.fTextHeight				, strValue.c_str());	break;
	case	GISZJ_Name			:toValue(gData.strName					, strValue.c_str());	break;
	case	GISZJ_ParentTag		:toValue(gData.strParentTag				, strValue.c_str());	break;
	case	GISZJ_Parent		:toValue(gData.strParent				, strValue.c_str());	break;
	case	GISZJ_SubIdx		:toValue(gData.nSubIdx					, strValue.c_str());	break;
	case	GISZJ_Coordinate	:toValue(gData.gData.strCoordinate		, strValue.c_str());	break;
	case	GISZJ_SymbolID		:toValue(gData.gData.strSymbolID		, strValue.c_str());	break;
	case	GISZJ_SymbolSize	:toValue(gData.gData.fSymbolSize		, strValue.c_str());	break;
	case	GISZJ_SymbolAngle	:toValue(gData.gData.fSymbolAngle		, strValue.c_str());	break;
	case	GISZJ_GraphPath		:toValue(gData.gData.strPath			, strValue.c_str());	break;
	case	GISZJ_Location		:toValue(gData.ptLoc					, strValue.c_str());	break;
	}
}