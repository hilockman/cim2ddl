// GISData.cpp: implementation of the CGISXmlParser class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <ostream>
#include <string>
#include <sstream>
#include <iostream>
#include <fstream>
#include <io.h>
#include <vector>
using namespace std;
#include "GISXmlParser.h"

#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/PlatformUtils.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/TransService.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/parsers/SAXParser.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/OutOfMemoryException.hpp"
#include "GISXml_SAXHandlers.hpp"

static bool                     doNamespaces        = false;
static bool                     doSchema            = false;
static bool                     schemaFullChecking  = false;
static const char*              encodingName    = "LATIN1";
static XMLFormatter::UnRepFlags unRepFlags      = XMLFormatter::UnRep_CharRef;
static SAXParser::ValSchemes    valScheme       = SAXParser::Val_Auto;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int CGISXmlParser::ParseXmlBySax(CGISData& gData, const char* lpszFileName, std::string& strFilterMark, std::vector<std::string>& strFilterKeyArray)
{
	if (access(lpszFileName, 0) != 0)
	{
		Log(g_lpszLogFile, "        �ļ�: %s ������ : %s\n", lpszFileName);
		return 0;
	}

	try
	{
		XMLPlatformUtils::Initialize();
	}

	catch (const XMLException& toCatch)
	{
		char*	lpszMesg=XMLString::transcode(toCatch.getMessage());
		XERCES_STD_QUALIFIER cerr << "Error during initialization! :\n" << lpszMesg << XERCES_STD_QUALIFIER endl;
		XMLString::release(&lpszMesg);

		Log(g_lpszLogFile, "        Error during initialization! : %s\n", lpszMesg);
		return 0;
	}

	//xmlFile = lpszFileName;
	int errorCount = 0;
	//
	//  Create a SAX parser object. Then, according to what we were told on
	//  the command line, set it to validate or not.
	//
	SAXParser* parser = new SAXParser;
	parser->setValidationScheme(valScheme);
	parser->setDoNamespaces(doNamespaces);
	parser->setDoSchema(doSchema);
	parser->setHandleMultipleImports (true);
	parser->setValidationSchemaFullChecking(schemaFullChecking);

	//
	//  Create the handler object and install it as the document and error
	//  handler for the parser-> Then parse the file and catch any exceptions
	//  that propogate out
	//
	int errorCode = 0;
	try
	{
		GISXml_SAXHandlers handler(gData, encodingName, unRepFlags, strFilterMark, strFilterKeyArray, lpszFileName);
		parser->setDocumentHandler(&handler);
		parser->setErrorHandler(&handler);
		parser->parse(lpszFileName);
		errorCount = parser->getErrorCount();
	}
	catch (const OutOfMemoryException&)
	{
		XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
		errorCode = 5;
		Log(g_lpszLogFile, "        OutOfMemoryException\n");
	}
	catch (const XMLException& toCatch)
	{
		char*	lpszMesg=XMLString::transcode(toCatch.getMessage());
		XERCES_STD_QUALIFIER cerr << "\nAn error occurred\n  Error: " << lpszMesg << "\n" << XERCES_STD_QUALIFIER endl;
		XMLString::release(&lpszMesg);
		errorCode = 4;
		Log(g_lpszLogFile, "        An error occurred: %s\n", lpszMesg);
	}

	if(errorCode)
	{
		XMLPlatformUtils::Terminate();
		Log(g_lpszLogFile, "        An error occurred\n");
		return 0;
	}

	//
	//  Delete the parser itself.  Must be done prior to calling Terminate, below.
	//
	delete parser;

	// And call the termination method
	XMLPlatformUtils::Terminate();

	//if (errorCount > 0)
	//	return 0;
	//else
	//	return 1;
	return 1;
}
