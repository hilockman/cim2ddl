#pragma  once

#include "../../MemDB/include/MDBDefine.h"

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#endif

#if !defined(__GNUG__) && !defined(__GNUC__)
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

typedef	struct _GISFieldDesp_
{
	short	nFieldID;
	char*	szFieldTag;
	char*	szFieldDesp;
	short	nEnumNum;
	tagMemDBEnumPair*	pEnumArray;
}	tagGISField;

typedef	struct _GISNameDesp_
{
	short	nTableID;
	char*	szTableTag;
	char*	szTableDesp;
	short			nFieldNum;
	tagGISField*	pFieldArray;
	int		nLocLen;
}	tagGISTable;

typedef	struct _GISVertex_
{
	double	fX;
	double	fY;
}	tagGISVertex;

typedef	struct _GISGraphic_
{
	std::string		strCoordinate;
	std::string		strSymbolID;
	float			fSymbolSize;
	float			fSymbolAngle;
	std::string		strPath;
}	tagGISGraphic;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPSRType_Field_
{
	GISPSRType_ResourceID=0,
	GISPSRType_ObjectID,
	GISPSRType_Name,
	GISPSRType_Alias,
};
typedef	struct	_GISPSRType
{
	std::string	strResourceID;
	std::string	strObjectID;
	std::string	strName;
	std::string	strAlias;
}	DISALIGN	tagGISPSRType;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISRDF_Field_
{
	GISRDF_XmlnsRDF=0,
	GISRDF_XmlnsCIM,
};
typedef	struct	_GISRDF
{
	std::string	strRdf;
	std::string	strCim;
}	DISALIGN	tagGISRDF;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISGeographicalRegion_Field_
{
	GISGeographicalRegion_ResourceID=0,
	GISGeographicalRegion_ObjectID,
	GISGeographicalRegion_Name,
};
typedef	struct	_GISGeographicalRegion
{
	std::string	strResourceID;
	std::string	strObjectID;
	std::string	strName;
}	DISALIGN	tagGISGeographicalRegion;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISSubGeographicalRegion_Field_
{
	GISSubGeographicalRegion_ResourceID=0,
	GISSubGeographicalRegion_ObjectID,
	GISSubGeographicalRegion_Name,
	GISSubGeographicalRegion_ParentTag,
};
struct	_GISSubGeographicalRegion
{
	std::string	strResourceID;
	std::string	strObjectID;
	std::string	strName;
	std::string	strParentTag;
}	DISALIGN;
typedef	struct	_GISSubGeographicalRegion	tagGISSubGeographicalRegion;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISBaseVoltage_Field_
{
	GISBaseVoltage_ResourceID=0,
	GISBaseVoltage_ObjectID,
	GISBaseVoltage_Name,
	GISBaseVoltage_DC,
	GISBaseVoltage_NominalVoltage,
};
struct	_GISBaseVoltage
{
	std::string	strResourceID;
	std::string	strObjectID;
	std::string	strName;
	unsigned char	bIsDC;
	float	fNominalVoltage;
}	DISALIGN;
typedef	struct	_GISBaseVoltage	tagGISBaseVoltage;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISSubstation_Field_
{
	GISSubstation_ResourceID=0,
	GISSubstation_PSRTypeTag,
	GISSubstation_ObjectID,
	GISSubstation_Name,
	GISSubstation_Unit,
	GISSubstation_ParentTag,
	GISSubstation_Alias1,
	GISSubstation_Alias2,
	GISSubstation_HighVoltage,
	GISSubstation_Component,
	GISSubstation_SubstationType,
	GISSubstation_Model,
	GISSubstation_MvaCapacity,
	GISSubstation_PlanCharacter,
	GISSubstation_Public,
	GISSubstation_BuildDate,
	GISSubstation_RebuildDate,
	GISSubstation_OutageDate,
	GISSubstation_RunTimeSpan,
	GISSubstation_TotalBay,
	GISSubstation_FreeBay,
	GISSubstation_TotalOutline,
	GISSubstation_InuseOutline,
	GISSubstation_EqX,

	GISSubstation_ri_rerr,		
	GISSubstation_ri_trep,		
	GISSubstation_ri_rchk,		
	GISSubstation_ri_tchk,		
	GISSubstation_ri_tfloc,		
	GISSubstation_ri_customer,
	GISSubstation_ri_load_rerr,	
	GISSubstation_ri_load_trep,	
	GISSubstation_ri_load_rchk,	
	GISSubstation_ri_load_tchk,	
	GISSubstation_ei_invest,		

	GISSubstation_Coordinate,
	GISSubstation_SymbolID,
	GISSubstation_SymbolSize,
	GISSubstation_SymbolAngle,
	GISSubstation_GraphPath,
	GISSubstation_Location,
	GISSubstation_Valid,
	GISSubstation_Virtual,
};

struct	_GISSubstation
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strAlias1;
	std::string	strAlias2;
	std::string	strHighVoltage;
	std::string	strComponent;
	std::string	strSubstationType;
	std::string	strModel;
	float	fMvaCapacity;
	unsigned char	nPlanCharacter;
	unsigned char	bPublic;
	int		nBuildDate;
	int		nRebuildDate;
	int		nOutageDate;
	int		nRunTimeSpan;
	short	nTotalBay;
	short	nFreeBay;
	short	nTotalOutline;
	short	nInuseOutline;
	float	fEqX;

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_Customer;
	float	ri_load_rerr;
	float	ri_load_trep;
	float	ri_load_rchk;
	float	ri_load_tchk;
	float	ei_Invest;

	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	unsigned char	bValid;
	unsigned char	bVirtual;
}	DISALIGN;
typedef	struct	_GISSubstation		tagGISSubstation;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISFeeder_Field_
{
	GISFeeder_ResourceID=0,
	GISFeeder_PSRTypeTag,
	GISFeeder_ObjectID,
	GISFeeder_Name,
	GISFeeder_Desp,
	GISFeeder_ParentTag,
	GISFeeder_V,
	GISFeeder_P,
	GISFeeder_Q,
	GISFeeder_I,
	GISFeeder_Factor,
};
struct	_GISFeeder
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strDesp;
	std::string	strParentTag;

	//	������ϢΪ��չ��Ϣ
	float	fV;			//���ڵ�ѹ
	float	fP;			//�й�����
	float	fQ;			//�޹�����
	float	fI;			//���ڵ���
	float	fFactor;	//��������
}	DISALIGN;
typedef	struct	_GISFeeder	tagGISFeeder;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISCompositeSwitch_Field_
{
	GISCompositeSwitch_ResourceID=0,
	GISCompositeSwitch_PSRTypeTag,
	GISCompositeSwitch_ObjectID,
	GISCompositeSwitch_Name,
	GISCompositeSwitch_CompositeSwitchType,
	GISCompositeSwitch_ParentTag,
};
struct	_GISCompositeSwitch
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strCompositeSwitchType;
	std::string	strParentTag;
}	DISALIGN;;
typedef	struct	_GISCompositeSwitch	tagGISCompositeSwitch;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISBreaker_Field_
{
	GISBreaker_ResourceID=0,
	GISBreaker_PSRTypeTag,
	GISBreaker_ObjectID,
	GISBreaker_Name,
	GISBreaker_Unit,
	GISBreaker_Usage,
	GISBreaker_NormalOpen,
	GISBreaker_ParentTag,
	GISBreaker_BaseVoltageTag,
	GISBreaker_Status,
	GISBreaker_Model,
	GISBreaker_BreakerType,
	GISBreaker_ri_rerr,		
	GISBreaker_ri_trep,		
	GISBreaker_ri_rchk,		
	GISBreaker_ri_tchk,		
	GISBreaker_ri_tfloc,	
	GISBreaker_ri_rswitch,	
	GISBreaker_ri_tswitch,	
	GISBreaker_ei_invest,	
	GISBreaker_RTLevel,
	GISBreaker_CommMode,
	GISBreaker_PlanCharacter,
	GISBreaker_BuildDate,
	GISBreaker_ReBuildDate,
	GISBreaker_OutageDate,
	GISBreaker_RunTimeSpan,
	GISBreaker_Parent,
	GISBreaker_INode,
	GISBreaker_ZNode,
	GISBreaker_SubIdx,
	GISBreaker_INodeIdx,
	GISBreaker_ZNodeIdx,
	GISBreaker_Coordinate,
	GISBreaker_SymbolID,
	GISBreaker_SymbolSize,
	GISBreaker_SymbolAngle,
	GISBreaker_GraphPath,
	GISBreaker_Location,
	GISBreaker_GraphSize,
	GISBreaker_InSubstation,
};
struct	_GISBreaker
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strUsage;
	unsigned char bNormalOpen;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	unsigned char	nStatus;

	//	��չ����
	std::string	strModel;
	unsigned char	nBreakerType;

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_RSwitch;
	float	ri_TSwitch;
	float	ei_Invest;

	unsigned char	nRTLevel;
	unsigned char	nCommMode;
	unsigned char	nPlanCharacter;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;

	std::string	strParent;
	std::string	strNodeI;
	std::string	strNodeZ;

	int		nSubIdx;
	int		nNodeI;
	int		nNodeZ;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bInSubstation;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISBreaker	tagGISBreaker;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISDisconnector_Field_
{
	GISDisconnector_ResourceID=0,
	GISDisconnector_PSRTypeTag,
	GISDisconnector_ObjectID,
	GISDisconnector_Name,
	GISDisconnector_Unit,
	GISDisconnector_NormalOpen,
	GISDisconnector_ParentTag,
	GISDisconnector_BaseVoltageTag,
	GISDisconnector_Status,
	GISDisconnector_Model,
	GISDisconnector_BreakerType,
	GISDisconnector_ri_rerr,	
	GISDisconnector_ri_trep,	
	GISDisconnector_ri_rchk,	
	GISDisconnector_ri_tchk,	
	GISDisconnector_ri_tfloc,	
	GISDisconnector_ri_rswitch,	
	GISDisconnector_ri_tswitch,	
	GISDisconnector_ei_invest,	
	GISDisconnector_RTLevel,
	GISDisconnector_CommMode,
	GISDisconnector_PlanCharacter,
	GISDisconnector_BuildDate,
	GISDisconnector_ReBuildDate,
	GISDisconnector_OutageDate,
	GISDisconnector_RunTimeSpan,
	GISDisconnector_Parent,
	GISDisconnector_INode,
	GISDisconnector_ZNode,
	GISDisconnector_SubIdx,
	GISDisconnector_INodeIdx,
	GISDisconnector_ZNodeIdx,
	GISDisconnector_Coordinate,	
	GISDisconnector_SymbolID,	
	GISDisconnector_SymbolSize,	
	GISDisconnector_SymbolAngle,
	GISDisconnector_GraphPath,	
	GISDisconnector_Location,
	GISDisconnector_GraphSize,
	GISDisconnector_InSubstation,
};
struct	_GISDisconnector
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;

	unsigned char bNormalOpen;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	unsigned char	nStatus;

	//	��չ����
	std::string	strModel;
	unsigned char	nBreakerType;

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_RSwitch;
	float	ri_TSwitch;
	float	ei_Invest;

	unsigned char	nRTLevel;
	unsigned char	nCommMode;
	unsigned char	nPlanCharacter;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;

	std::string	strParent;
	std::string	strNodeI;
	std::string	strNodeZ;

	int		nSubIdx;
	int		nNodeI;
	int		nNodeZ;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bInSubstation;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISDisconnector	tagGISDisconnector;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISGroundDisconnector_Field_
{
	GISGroundDisconnector_ResourceID=0,
	GISGroundDisconnector_PSRTypeTag,
	GISGroundDisconnector_ObjectID,
	GISGroundDisconnector_Name,
	GISGroundDisconnector_Unit,
	GISGroundDisconnector_NormalOpen,
	GISGroundDisconnector_ParentTag,
	GISGroundDisconnector_BaseVoltageTag,
	GISGroundDisconnector_Model,
	GISGroundDisconnector_RTLevel,
	GISGroundDisconnector_CommMode,
	GISGroundDisconnector_PlanCharacter,
	GISGroundDisconnector_BuildDate,
	GISGroundDisconnector_ReBuildDate,
	GISGroundDisconnector_OutageDate,
	GISGroundDisconnector_RunTimeSpan,
	GISGroundDisconnector_Parent,
	GISGroundDisconnector_Node,
	GISGroundDisconnector_SubIdx,
	GISGroundDisconnector_NodeIdx,
	GISGroundDisconnector_Coordinate,	
	GISGroundDisconnector_SymbolID,		
	GISGroundDisconnector_SymbolSize,	
	GISGroundDisconnector_SymbolAngle,	
	GISGroundDisconnector_GraphPath,	
	GISGroundDisconnector_Location,
	GISGroundDisconnector_GraphSize,
	GISGroundDisconnector_Status,
};
struct	_GISGroundDisconnector
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	unsigned char bNormalOpen;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	//	��չ����
	std::string	strModel;
	unsigned char	nRTLevel;
	unsigned char	nCommMode;
	unsigned char	nPlanCharacter;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;
	std::string	strParent;
	std::string	strNode;

	int		nSubIdx;
	int		nNode;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	nStatus;	//ң��
}	DISALIGN;
typedef	struct	_GISGroundDisconnector	tagGISGroundDisconnector;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISLoadBreakSwitch_Field_
{
	GISLoadBreakSwitch_ResourceID=0,
	GISLoadBreakSwitch_PSRTypeTag,
	GISLoadBreakSwitch_ObjectID,
	GISLoadBreakSwitch_Name,
	GISLoadBreakSwitch_Unit,
	GISLoadBreakSwitch_NormalOpen,
	GISLoadBreakSwitch_ParentTag,
	GISLoadBreakSwitch_BaseVoltageTag,
	GISLoadBreakSwitch_Status,
	GISLoadBreakSwitch_Model,
	GISLoadBreakSwitch_BreakerType,
	GISLoadBreakSwitch_ri_rerr,		
	GISLoadBreakSwitch_ri_trep,		
	GISLoadBreakSwitch_ri_rchk,		
	GISLoadBreakSwitch_ri_tchk,		
	GISLoadBreakSwitch_ri_tfloc,	
	GISLoadBreakSwitch_ri_rswitch,	
	GISLoadBreakSwitch_ri_tswitch,	
	GISLoadBreakSwitch_ei_invest,	
	GISLoadBreakSwitch_RTLevel,
	GISLoadBreakSwitch_CommMode,
	GISLoadBreakSwitch_PlanCharacter,
	GISLoadBreakSwitch_BuildDate,
	GISLoadBreakSwitch_ReBuildDate,
	GISLoadBreakSwitch_OutageDate,
	GISLoadBreakSwitch_RunTimeSpan,
	GISLoadBreakSwitch_Parent,
	GISLoadBreakSwitch_INode,
	GISLoadBreakSwitch_ZNode,
	GISLoadBreakSwitch_SubIdx,
	GISLoadBreakSwitch_INodeIdx,
	GISLoadBreakSwitch_ZNodeIdx,
	GISLoadBreakSwitch_Coordinate,	
	GISLoadBreakSwitch_SymbolID,	
	GISLoadBreakSwitch_SymbolSize,	
	GISLoadBreakSwitch_SymbolAngle,	
	GISLoadBreakSwitch_GraphPath,	
	GISLoadBreakSwitch_Location,
	GISLoadBreakSwitch_GraphSize,
};
struct	_GISLoadBreakSwitch
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	unsigned char bNormalOpen;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	unsigned char	nStatus;	//ң��
	std::string	strModel;
	unsigned char	nBreakerType;

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_RSwitch;
	float	ri_TSwitch;
	float	ei_Invest;

	unsigned char	nRTLevel;
	unsigned char	nCommMode;
	unsigned char	nPlanCharacter;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;
	std::string	strParent;
	std::string	strNodeI;
	std::string	strNodeZ;

	int		nSubIdx;
	int		nNodeI;
	int		nNodeZ;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISLoadBreakSwitch	tagGISLoadBreakSwitch;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISFuse_Field_
{
	GISFuse_ResourceID=0,
	GISFuse_PSRTypeTag,
	GISFuse_ObjectID,
	GISFuse_Name,
	GISFuse_Unit,
	GISFuse_ParentTag,
	GISFuse_BaseVoltageTag,
	GISFuse_Status,
	GISFuse_Model,
	GISFuse_BreakerType,
	GISFuse_ri_rerr,
	GISFuse_ri_trep,
	GISFuse_ri_rchk,
	GISFuse_ri_tchk,
	GISFuse_ri_tfloc,
	GISFuse_ri_rswitch,
	GISFuse_ri_tswitch,
	GISFuse_ei_invest,
	GISFuse_RTLevel,
	GISFuse_CommMode,
	GISFuse_PlanCharacter,
	GISFuse_BuildDate,
	GISFuse_ReBuildDate,
	GISFuse_OutageDate,
	GISFuse_RunTimeSpan,
	GISFuse_Parent,
	GISFuse_INode,
	GISFuse_ZNode,
	GISFuse_SubIdx,
	GISFuse_INodeIdx,
	GISFuse_ZNodeIdx,
	GISFuse_Coordinate,	
	GISFuse_SymbolID,	
	GISFuse_SymbolSize,	
	GISFuse_SymbolAngle,
	GISFuse_GraphPath,	
	GISFuse_Location,
	GISFuse_GraphSize,
};
struct	_GISFuse
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	unsigned char	nStatus;	//ң��

	//	��չ����
	std::string	strModel;
	unsigned char	nBreakerType;

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_RSwitch;
	float	ri_TSwitch;
	float	ei_Invest;

	unsigned char	nRTLevel;
	unsigned char	nCommMode;
	unsigned char	nPlanCharacter;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;

	std::string	strParent;
	std::string	strNodeI;
	std::string	strNodeZ;

	int		nSubIdx;
	int		nNodeI,nNodeZ;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISFuse	tagGISFuse;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISACLineSegment_Field_
{
	GISACLineSegment_ResourceID=0,
	GISACLineSegment_PSRTypeTag,
	GISACLineSegment_ObjectID,
	GISACLineSegment_Name,
	GISACLineSegment_Unit,
	GISACLineSegment_AssetModel,
	GISACLineSegment_LineType,
	GISACLineSegment_AutoLength,
	GISACLineSegment_Length,
	GISACLineSegment_ParentTag,
	GISACLineSegment_BaseVoltageTag,
	GISACLineSegment_LineTag,
	GISACLineSegment_Type,
	GISACLineSegment_PlanCharacter,
	GISACLineSegment_RunStatus,
	GISACLineSegment_AreaCategory,
	GISACLineSegment_LineLoadP,
	GISACLineSegment_LineLoadFactor,
	GISACLineSegment_LineCapacitor,
	GISACLineSegment_r,
	GISACLineSegment_x,
	GISACLineSegment_g,
	GISACLineSegment_b,
	GISACLineSegment_ri_unitrerr,	
	GISACLineSegment_ri_unittrep,	
	GISACLineSegment_ri_unitrchk,	
	GISACLineSegment_ri_unittchk,	
	GISACLineSegment_ei_unitinvest,	
	GISACLineSegment_ri_rerr,		
	GISACLineSegment_ri_trep,		
	GISACLineSegment_ri_rchk,		
	GISACLineSegment_ri_tchk,		
	GISACLineSegment_ri_tfloc,		
	GISACLineSegment_ri_rswitch,	
	GISACLineSegment_ri_tswitch,	
	GISACLineSegment_ri_tdelay,		
	GISACLineSegment_ri_customer,
	GISACLineSegment_ri_load_rerr,	
	GISACLineSegment_ri_load_trep,	
	GISACLineSegment_ri_load_rchk,	
	GISACLineSegment_ri_load_tchk,	
	GISACLineSegment_ei_invest,		
	GISACLineSegment_BuildDate,
	GISACLineSegment_ReBuildDate,
	GISACLineSegment_OutageDate,
	GISACLineSegment_RunTimeSpan,
	GISACLineSegment_iStatus,
	GISACLineSegment_zStatus,
	GISACLineSegment_Feeder,
	GISACLineSegment_INode,
	GISACLineSegment_ZNode,
	GISACLineSegment_SubITag,
	GISACLineSegment_SubZTag,
	GISACLineSegment_JointEquipmentIType,
	GISACLineSegment_JointEquipmentZType,
	GISACLineSegment_JointEquipmentI,
	GISACLineSegment_JointEquipmentZ,
	GISACLineSegment_ContainerIdx,
	GISACLineSegment_SubIIdx,
	GISACLineSegment_SubZIdx,
	GISACLineSegment_INodeIdx,
	GISACLineSegment_ZNodeIdx,
	GISACLineSegment_Flag,
	GISACLineSegment_Coordinate,	
	GISACLineSegment_SymbolID,		
	GISACLineSegment_SymbolSize,	
	GISACLineSegment_SymbolAngle,	
	GISACLineSegment_GraphPath,	
};
struct	_GISACLineSegment
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strAssetModel;
	std::string	strLineType;
	unsigned char	bAutoLength;
	float	fLength;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	std::string	strLineTag;
	unsigned char	nLineType;				//	�ܿ��߻��ǵ���
	unsigned char	nPlanCharacter;
	unsigned char	nRunStatus;
	unsigned char	nAreaCategory;
	float	fLineLoadP;						
	float	fLineLoadFactor;				
	float	fLineCapacitor;								
	float	r;								//	����
	float	x;								//	�翹
	float	g;								//	�絼
	float	b;								//	����

	//	������չ���ɿ������
	float	ri_UnitRerr;
	float	ri_UnitTrep;
	float	ri_UnitRchk;
	float	ri_UnitTchk;
	float	ei_UnitInvest;
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_RSwitch;
	float	ri_TSwitch;
	float	ri_TDelay;
	float	ri_Customer;
	float	ri_load_rerr;
	float	ri_load_trep;
	float	ri_load_rchk;
	float	ri_load_tchk;
	float	ei_Invest;

	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;
	unsigned char	iStatus;
	unsigned char	zStatus;
	std::string	strFeeder;
	std::string	strNodeI;
	std::string	strNodeZ;
	std::string	strSubITag;
	std::string	strSubZTag;
	short	nIJointEquipmentType;				//	�����ĸ�������ĸ������Container����ֵ����Ϊ��Container������
	short	nZJointEquipmentType;				//	�����ĸ�������ĸ������Container����ֵ����Ϊ��Container������
	std::string	strIJointEquipmentTag;
	std::string	strZJointEquipmentTag;
	int		nContainerIdx;
	int		nSubI;
	int		nSubZ;
	int		nNodeI;
	int		nNodeZ;
	unsigned char	bFlag;
	tagGISGraphic	gData;
}	DISALIGN;
typedef	struct	_GISACLineSegment	tagGISACLineSegment;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPowerTransformer_Field_
{
	GISPowerTransformer_ResourceID=0,
	GISPowerTransformer_PSRTypeTag,
	GISPowerTransformer_ObjectID,
	GISPowerTransformer_Name,
	GISPowerTransformer_Unit,
	GISPowerTransformer_ParentTag,
	GISPowerTransformer_BaseVoltageTag,
	GISPowerTransformer_RatedCapacity,
	GISPowerTransformer_Model,
	GISPowerTransformer_PlanCharacter,
	GISPowerTransformer_Distribution,
	GISPowerTransformer_Public,
	GISPowerTransformer_BuildDate,
	GISPowerTransformer_ReBuildDate,
	GISPowerTransformer_OutageDate,
	GISPowerTransformer_RunTimeSpan,
	GISPowerTransformer_ManuDate,
	GISPowerTransformer_ConstructDate,
	GISPowerTransformer_Parent,
	GISPowerTransformer_NodeH,
	GISPowerTransformer_NodeM,
	GISPowerTransformer_NodeL,
	GISPowerTransformer_VoltH,
	GISPowerTransformer_VoltM,
	GISPowerTransformer_VoltL,

	GISPowerTransformer_ri_rerr,		
	GISPowerTransformer_ri_trep,		
	GISPowerTransformer_ri_rchk,		
	GISPowerTransformer_ri_tchk,		
	GISPowerTransformer_ri_tfloc,		
	GISPowerTransformer_ri_rswitch,	
	GISPowerTransformer_ri_tswitch,	
	GISPowerTransformer_ri_customer,
	GISPowerTransformer_ri_load_rerr,	
	GISPowerTransformer_ri_load_trep,	
	GISPowerTransformer_ri_load_rchk,	
	GISPowerTransformer_ri_load_tchk,	
	GISPowerTransformer_ei_invest,		

	GISPowerTransformer_SubIdx,
	GISPowerTransformer_NodeHIdx,
	GISPowerTransformer_NodeMIdx,
	GISPowerTransformer_NodeLIdx,
	GISPowerTransformer_WindNum,
	GISPowerTransformer_Coordinate,	
	GISPowerTransformer_SymbolID,	
	GISPowerTransformer_SymbolSize,	
	GISPowerTransformer_SymbolAngle,
	GISPowerTransformer_GraphPath,	
	GISPowerTransformer_Location,
	GISPowerTransformer_VertexH,
	GISPowerTransformer_VertexM,
	GISPowerTransformer_VertexL,
	GISPowerTransformer_GraphSize,
	GISPowerTransformer_P,
	GISPowerTransformer_Q,
	GISPowerTransformer_Flag,
};

struct	_GISPowerTransformer
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	float		fRatedCapacity;

	//	��չ��Ϣ
	std::string	strModel;
	unsigned char	nPlanCharacter;
	unsigned char	bDistribution;
	unsigned char	bPublic;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;
	short	int		nManuDate;
	short	int		nConstructDate;

	std::string	strParent;
	std::string	strNodeArray[3];
	std::string	strVoltTagArray[3];

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_RSwitch;
	float	ri_TSwitch;
	float	ri_Customer;
	float	ri_load_rerr;
	float	ri_load_trep;
	float	ri_load_rchk;
	float	ri_load_tchk;
	float	ei_Invest;

	int		nSubIdx;
	int		nNodeArray[3];
	short	nWindNum;

	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	tagGISVertex	ptVertArray[3];
	double			fSize;
	float	fP;	//ң��
	float	fQ;	//ң��
	unsigned char	bFlag;
}	DISALIGN;;
typedef	struct	_GISPowerTransformer	tagGISPowerTransformer;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISConnLine_Field_
{
	GISConnLine_ResourceID=0,
	GISConnLine_PSRTypeTag,
	GISConnLine_ObjectID,
	GISConnLine_Name,
	GISConnLine_Unit,
	GISConnLine_ParentTag,
	GISConnLine_BaseVoltageTag,
	GISConnLine_Parent,
	GISConnLine_NodeI,
	GISConnLine_NodeZ,
	GISConnLine_SubIdx,
	GISConnLine_INodeIdx,
	GISConnLine_ZNodeIdx,
	GISConnLine_Coordinate,	
	GISConnLine_SymbolID,	
	GISConnLine_SymbolSize,	
	GISConnLine_SymbolAngle,
	GISConnLine_GraphPath,	
	GISConnLine_Flag,
};
struct	_GISConnLine
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	std::string	strParent;
	std::string	strNodeI;
	std::string	strNodeZ;

	int		nSubIdx;
	int		nNodeI;
	int		nNodeZ;
	tagGISGraphic	gData;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISConnLine	tagGISConnLine;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISBusbarSection_Field_
{
	GISBusbarSection_ResourceID=0,
	GISBusbarSection_PSRTypeTag,
	GISBusbarSection_ObjectID,
	GISBusbarSection_Name,
	GISBusbarSection_Unit,
	GISBusbarSection_ParentTag,
	GISBusbarSection_BaseVoltageTag,
	GISBusbarSection_Parent,
	GISBusbarSection_Node,

	GISBusbarSection_ri_rerr,
	GISBusbarSection_ri_trep,
	GISBusbarSection_ri_rchk,
	GISBusbarSection_ri_tchk,
	GISBusbarSection_ri_tfloc,
	GISBusbarSection_ri_customer,
	GISBusbarSection_ri_load_rerr,	
	GISBusbarSection_ri_load_trep,	
	GISBusbarSection_ri_load_rchk,	
	GISBusbarSection_ri_load_tchk,	
	GISBusbarSection_ei_invest,		

	GISBusbarSection_SubIdx,
	GISBusbarSection_NodeIdx,
	GISBusbarSection_Coordinate,	
	GISBusbarSection_SymbolID,		
	GISBusbarSection_SymbolSize,	
	GISBusbarSection_SymbolAngle,	
	GISBusbarSection_GraphPath,		
};
struct	_GISBusbarSection
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	std::string	strParent;
	std::string	strNode;

	//	������չ���ɿ������
	float	ri_Rerr;
	float	ri_Trep;
	float	ri_Rchk;
	float	ri_Tchk;
	float	ri_Tfloc;
	float	ri_Customer;
	float	ri_load_rerr;
	float	ri_load_trep;
	float	ri_load_rchk;
	float	ri_load_tchk;
	float	ei_Invest;

	int		nSubIdx;
	int		nNode;
	tagGISGraphic	gData;
}	DISALIGN;
typedef	struct	_GISBusbarSection	tagGISBusbarSection;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPole_Field_
{
	GISPole_ResourceID=0,
	GISPole_PSRTypeTag,
	GISPole_ObjectID,
	GISPole_Name,
	GISPole_Unit,
	GISPole_aliasName,
	GISPole_description,
	GISPole_ParentTag,
	GISPole_BaseVoltageTag,
	GISPole_BuildDate,
	GISPole_ReBuildDate,
	GISPole_OutageDate,
	GISPole_RunTimeSpan,
	GISPole_PlanCharacter,
	GISPole_Parent,
	GISPole_Node,
	GISPole_SubIdx,
	GISPole_NodeIdx,
	GISPole_Coordinate,	
	GISPole_SymbolID,		
	GISPole_SymbolSize,	
	GISPole_SymbolAngle,	
	GISPole_GraphPath,		
	GISPole_Location,
	GISPole_GraphSize,
	GISPole_Valid,
};
struct	_GISPole
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strAlias;
	std::string	strDesp;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	//	��չ����
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;
	unsigned char	nPlanCharacter;

	std::string	strParent;
	std::string	strNode;

	int		nSubIdx;
	int		nNode;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bValid;
}	DISALIGN;
typedef	struct	_GISPole	tagGISPole;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISJunction_Field_
{
	GISJunction_ResourceID=0,
	GISJunction_PSRTypeTag,
	GISJunction_ObjectID,
	GISJunction_Name,
	GISJunction_Unit,
	GISJunction_ParentTag,
	GISJunction_BaseVoltageTag,
	GISJunction_BuildDate,
	GISJunction_ReBuildDate,
	GISJunction_OutageDate,
	GISJunction_RunTimeSpan,
	GISJunction_PlanCharacter,
	GISJunction_Parent,
	GISJunction_Node,
	GISJunction_SubIdx,
	GISJunction_NodeIdx,
	GISJunction_Coordinate,		
	GISJunction_SymbolID,		
	GISJunction_SymbolSize,		
	GISJunction_SymbolAngle,	
	GISJunction_GraphPath,		
	GISJunction_Location,
	GISJunction_GraphSize,
	GISJunction_Valid,
};
struct	_GISJunction
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	//	��չ����
	unsigned char	nPlanCharacter;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;

	std::string	strParent;
	std::string	strNode;

	int		nSubIdx;
	int		nNode;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bValid;
}	DISALIGN;
typedef	struct	_GISJunction	tagGISJunction;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISEnergyConsumer_Field_
{
	GISEnergyConsumer_ResourceID=0,
	GISEnergyConsumer_PSRTypeTag,
	GISEnergyConsumer_ObjectID,
	GISEnergyConsumer_Name,
	GISEnergyConsumer_Unit,
	GISEnergyConsumer_ParentTag,
	GISEnergyConsumer_BaseVoltageTag,
	GISEnergyConsumer_BelongPSRTag,
	GISEnergyConsumer_Public,
	GISEnergyConsumer_P,
	GISEnergyConsumer_Q,
	GISEnergyConsumer_CustumerNum,
	GISEnergyConsumer_Parent,
	GISEnergyConsumer_Node,
	GISEnergyConsumer_BelongPSRType,
	GISEnergyConsumer_BelongPSRName,
	GISEnergyConsumer_SubIdx,
	GISEnergyConsumer_NodeIdx,
	GISEnergyConsumer_Coordinate,	
	GISEnergyConsumer_SymbolID,		
	GISEnergyConsumer_SymbolSize,	
	GISEnergyConsumer_SymbolAngle,	
	GISEnergyConsumer_GraphPath,	
	GISEnergyConsumer_Location,
	GISEnergyConsumer_GraphSize,
};
struct	_GISEnergyConsumer
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	//	��չ����
	std::string	strBelongPSRTag;
	unsigned char	bIsPublic;
	float	fP;
	float	fQ;
	float	fCustomNum;

	std::string	strParent;			//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strNode;

	short	nBelongPSRType;
	std::string	strBelongPSRName;
	int		nSubIdx;
	int		nNode;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
}	DISALIGN;
typedef	struct	_GISEnergyConsumer	tagGISEnergyConsumer;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISCompensator_Field_
{
	GISCompensator_ResourceID=0,
	GISCompensator_PSRTypeTag,
	GISCompensator_ObjectID,
	GISCompensator_Name,
	GISCompensator_Unit,
	GISCompensator_ParentTag,
	GISCompensator_BaseVoltageTag,
	GISCompensator_Parent,
	GISCompensator_Node,
	GISCompensator_SeriesNode,
	GISCompensator_SubIdx,
	GISCompensator_NodeIdx,
	GISCompensator_SeriesNodeIdx,
	GISCompensator_Coordinate,	
	GISCompensator_SymbolID,	
	GISCompensator_SymbolSize,	
	GISCompensator_SymbolAngle,	
	GISCompensator_GraphPath,
	GISCompensator_Location,
	GISCompensator_GraphSize,
};
struct	_GISCompensator
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;
	std::string	strParent;			//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strNode;
	std::string	strSeriesNode;

	int		nSubIdx;
	int		nNode;
	int		nSeriesNode;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISCompensator	tagGISCompensator;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISCapacitor_Field_
{
	GISCapacitor_ResourceID=0,
	GISCapacitor_PSRTypeTag,
	GISCapacitor_ObjectID,
	GISCapacitor_Name,
	GISCapacitor_Unit,
	GISCapacitor_ParentTag,
	GISCapacitor_BaseVoltageTag,
	GISCapacitor_Parent,
	GISCapacitor_Node,
	GISCapacitor_SubIdx,
	GISCapacitor_NodeIdx,
	GISCapacitor_Coordinate,
	GISCapacitor_SymbolID,	
	GISCapacitor_SymbolSize,
	GISCapacitor_SymbolAngle,
	GISCapacitor_GraphPath,
	GISCapacitor_Location,
	GISCapacitor_GraphSize,
};
struct	_GISCapacitor
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strUnit;
	std::string	strParentTag;
	std::string	strBaseVoltageTag;

	std::string	strParent;			//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strNode;

	int		nSubIdx;
	int		nNode;
	//	�ڲ�����
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
	double			fSize;
}	DISALIGN;
typedef	struct	_GISCapacitor	tagGISCapacitor;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISTerminal_Field_
{
	GISTerminal_ResourceID=0,
	GISTerminal_ParentTag,
	GISTerminal_NodeTag,
	GISTerminal_NodeIdx,
};
struct	_GISTerminal
{
	std::string	strResourceID;
	std::string	strParentTag;
	std::string	strNodeTag;
	int		nNode;
	unsigned char	bFlag;
}	DISALIGN;
typedef	struct	_GISTerminal	tagGISTerminal;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISConnectivityNode_Field_
{
	GISConnectivityNode_ResourceID=0,
	GISConnectivityNode_VoltageLevel,
};
struct	_GISConnectivityNode
{
	std::string	strResourceID;
	std::string	strBaseVoltageTag;
	unsigned char	bFlaged;
}	DISALIGN;
typedef	struct	_GISConnectivityNode	tagGISConnectivityNode;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPipe_Field_
{
	GISPipe_ResourceID=0,
	GISPipe_PSRTypeTag,
	GISPipe_ObjectID,
	GISPipe_Name,
	GISPipe_Model,
	GISPipe_BuildDate,
	GISPipe_RebuildDate,
	GISPipe_OutageDate,
	GISPipe_RunTimeSpan,
	GISPipe_PlanCharacter,
	GISPipe_MaxHVCableNum,
	GISPipe_MaxMVCableNum,
	GISPipe_MaxLVCableNum,
	GISPipe_HVCableNum,
	GISPipe_MVCableNum,
	GISPipe_LVCableNum,
	GISPipe_HVCable1,
	GISPipe_HVCable2,
	GISPipe_HVCable3,
	GISPipe_HVCable4,
	GISPipe_MVCable1,
	GISPipe_MVCable2,
	GISPipe_MVCable3,
	GISPipe_MVCable4,
	GISPipe_MVCable5,
	GISPipe_MVCable6,
	GISPipe_MVCable7,
	GISPipe_MVCable8,
	GISPipe_LVCable01,
	GISPipe_LVCable02,
	GISPipe_LVCable03,
	GISPipe_LVCable04,
	GISPipe_LVCable05,
	GISPipe_LVCable06,
	GISPipe_LVCable07,
	GISPipe_LVCable08,
	GISPipe_LVCable09,
	GISPipe_LVCable10,
	GISPipe_LVCable11,
	GISPipe_LVCable12,
	GISPipe_LVCable13,
	GISPipe_LVCable14,
	GISPipe_LVCable15,
	GISPipe_LVCable16,
	GISPipe_LVCable17,
	GISPipe_LVCable18,
	GISPipe_LVCable19,
	GISPipe_LVCable20,
	GISPipe_LVCable21,
	GISPipe_LVCable22,
	GISPipe_LVCable23,
	GISPipe_LVCable24,
	GISPipe_LVCable25,
	GISPipe_LVCable26,
	GISPipe_LVCable27,
	GISPipe_LVCable28,
	GISPipe_LVCable29,
	GISPipe_LVCable30,
	GISPipe_LVCable31,
	GISPipe_LVCable32,
};
struct	_GISPipe
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strName;
	std::string	strModel;
	short	int		nBuildDate;
	short	int		nReBuildDate;
	short	int		nOutageDate;
	short	int		nRunTimeSpan;
	unsigned char	nPlanCharacter;
	short	nMaxHVCableNum;
	short	nMaxMVCableNum;
	short	nMaxLVCableNum;


	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	short	nHVCableNum;
	short	nMVCableNum;
	short	nLVCableNum;
	std::string	strHVCable[4];
	std::string	strMVCable[8];
	std::string	strLVCable[32];
}	DISALIGN;
typedef	struct	_GISPipe	tagGISPipe;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPT_Field_
{
	GISPT_ResourceID=0,
	GISPT_PSRTypeTag,
	GISPT_ObjectID,
	GISPT_BaseVoltageTag,
};
struct	_GISPT
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
}	DISALIGN;
typedef	struct	_GISPT	tagGISPT;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISCT_Field_
{
	GISCT_ResourceID=0,
	GISCT_PSRTypeTag,
	GISCT_ObjectID,
	GISCT_BaseVoltageTag,
};
struct	_GISCT
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
}	DISALIGN;
typedef	struct	_GISCT	tagGISCT;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISBLQ_Field_
{
	GISBLQ_ResourceID=0,
	GISBLQ_PSRTypeTag,
	GISBLQ_ObjectID,
	GISBLQ_BaseVoltageTag,
};
struct	_GISBLQ
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
}	DISALIGN;
typedef	struct	_GISBLQ	tagGISBLQ;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISFaultIndicator_Field_
{
	GISFaultIndicator_ResourceID=0,
	GISFaultIndicator_PSRTypeTag,
	GISFaultIndicator_ObjectID,
	GISFaultIndicator_BaseVoltageTag,
	GISFaultIndicator_ParentTag,
};
struct	_GISFaultIndicator
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
	std::string	strParentTag;
}	DISALIGN;
typedef	struct	_GISFaultIndicator	tagGISFaultIndicator;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPTCab_Field_
{
	GISPTCab_ResourceID=0,
	GISPTCab_PSRTypeTag,
	GISPTCab_ObjectID,
	GISPTCab_BaseVoltageTag,
};
struct	_GISPTCab
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
}	DISALIGN;
typedef	struct	_GISPTCab	tagGISPTCab;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISGround_Field_
{
	GISGround_ResourceID=0,
	GISGround_PSRTypeTag,
	GISGround_ObjectID,
	GISGround_BaseVoltageTag,
	GISGround_ParentTag,
};
struct	_GISGround
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
	std::string	strParentTag;
}	DISALIGN;
typedef	struct	_GISGround	tagGISGround;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPTCABU_Field_
{
	GISPTCABU_ResourceID=0,
	GISPTCABU_PSRTypeTag,
	GISPTCABU_ObjectID,
};
struct	_GISPTCABU
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
}	DISALIGN;
typedef	struct	_GISPTCABU	tagGISPTCABU;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISKWGXB_Field_
{
	GISKWGXB_ResourceID=0,
	GISKWGXB_PSRTypeTag,
	GISKWGXB_ObjectID,
};
struct	_GISKWGXB
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
}	DISALIGN;
typedef	struct	_GISKWGXB	tagGISKWGXB;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPFWELL_Field_
{
	GISPFWELL_ResourceID=0,
	GISPFWELL_PSRTypeTag,
	GISPFWELL_ObjectID,
};
struct	_GISPFWELL
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
}	DISALIGN;
typedef	struct	_GISPFWELL	tagGISPFWELL;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISPFTUNN_Field_
{
	GISPFTUNN_ResourceID=0,
	GISPFTUNN_PSRTypeTag,
	GISPFTUNN_ObjectID,
};
struct	_GISPFTUNN
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
}	DISALIGN;
typedef	struct	_GISPFTUNN	tagGISPFTUNN;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISOther_Field_
{
	GISOther_ResourceID=0,
	GISOther_PSRTypeTag,
	GISOther_ObjectID,
	GISOther_BaseVoltageTag,
	GISOther_ParentTag,
};
struct	_GISOther
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	std::string	strBaseVoltageTag;
	std::string	strParentTag;
}	DISALIGN;
typedef	struct	_GISOther	tagGISOther;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISZJ_Field_
{
	GISZJ_ResourceID=0,
	GISZJ_PSRTypeTag,
	GISZJ_ObjectID,
	GISZJ_TextHeight,
	GISZJ_Name,
	GISZJ_ParentTag,
	GISZJ_Parent,
	GISZJ_SubIdx,
	GISZJ_Coordinate,
	GISZJ_SymbolID,	
	GISZJ_SymbolSize,
	GISZJ_SymbolAngle,
	GISZJ_GraphPath,
	GISZJ_Location,
};
struct	_GISZJ
{
	std::string	strResourceID;
	std::string	strPSRTypeTag;
	std::string	strObjectID;
	float	fTextHeight;
	std::string	strName;
	std::string	strParentTag;
	std::string	strParent;
	int		nSubIdx;
	tagGISGraphic	gData;
	tagGISVertex	ptLoc;
}	DISALIGN;
typedef	struct	_GISZJ	tagGISZJ;

//////////////////////////////////////////////////////////////////////////
enum	_ENum_GISGraphic_Field_
{
	GISGraphic_GisTable=0,
	GISGraphic_ResourceID,
	GISGraphic_Coordinate,
	GISGraphic_SymbolID,
	GISGraphic_SymbolSize,
	GISGraphic_SymbolAngle,
	GISGraphic_Path,
};
typedef	struct _Graphic_
{
	short			nGisTable;
	std::string		strResourceId;
	std::string		strCoordinate;
	std::string		strSymbolID;
	float			fSymbolSize;
	float			fSymbolAngle;
	std::string		strPath;
}	tagGisGraphic;

const	float	g_fDefaultLoadFactor=0.95f;

enum	_ENum_GIS_Table_
{
	GIS_RDF=0,
	GIS_PSRType,
	GIS_GeographicalRegion,
	GIS_SubGeographicalRegion,
	GIS_BaseVoltage,
	GIS_Substation,
	GIS_Feeder,
	GIS_CompositeSwitch,
	GIS_Breaker,
	GIS_Disconnector,
	GIS_GroundDisconnector,
	GIS_LoadBreakSwitch,
	GIS_Fuse,
	GIS_ACLineSegment,
	GIS_PowerTransformer,
	GIS_ConnLine,
	GIS_BusbarSection,
	GIS_Pole,
	GIS_Junction,
	GIS_EnergyConsumer,
	GIS_Compensator,
	// 	GIS_Resistor,
	// 	GIS_Reactor,
	GIS_Capacitor,
	GIS_Terminal,
	GIS_ConnectivityNode,
	GIS_Pipe,
	GIS_PT,			//	��ѹ������
	GIS_CT,			//	����������
	GIS_BLQ,		//	������
	GIS_FaultIndicator,
	GIS_PTCab,
	GIS_Ground,
	GIS_Other,
	GIS_PTCABU,
	GIS_KWGXB,
	GIS_PFWELL,
	GIS_PFTUNN,
	GIS_ZJ,			//	���Ƿ�
};

typedef	struct	_Node2Equipment_
{
	std::vector<int>	nBusbarSectionArray;
	std::vector<int>	nGroundDisconnectorArray;
	std::vector<int>	nCapacitorArray;
	std::vector<int>	nEnergyConsumerArray;

	std::vector<int>	nACLineSegmentArray;
	std::vector<int>	nPowerTransformerArray;
	std::vector<int>	nCompensatorArray;
	std::vector<int>	nConnLineArray;

	std::vector<int>	nBreakerArray;
	std::vector<int>	nDisconnectorArray;
	std::vector<int>	nLoadBreakSwitchArray;
	std::vector<int>	nFuseArray;

	std::vector<int>	nPoleArray;
	std::vector<int>	nJunctionArray;
}	tagNode2Equipment;

typedef	struct	_Node2Terminal_
{
	std::vector<int>	nTerminalArray;
}	tagNode2Terminal;

typedef	struct	_Sub2Equipment_
{
	std::vector<std::string>	strVoltTagArray;
	std::vector<int>	nFeederArray;

	std::vector<int>	nBusbarSectionArray;
	std::vector<int>	nGroundDisconnectorArray;
	std::vector<int>	nCapacitorArray;
	std::vector<int>	nEnergyConsumerArray;

	std::vector<int>	nACLineSegmentArray;
	std::vector<int>	nPowerTransformerArray;
	std::vector<int>	nCompensatorArray;
	std::vector<int>	nConnLineArray;

	std::vector<int>	nBreakerArray;
	std::vector<int>	nDisconnectorArray;
	std::vector<int>	nLoadBreakSwitchArray;
	std::vector<int>	nFuseArray;

	std::vector<int>	nPoleArray;
	std::vector<int>	nJunctionArray;
}	tagSub2Equipment;

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(fPower)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
