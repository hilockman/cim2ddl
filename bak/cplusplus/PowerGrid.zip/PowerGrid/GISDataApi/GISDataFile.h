#pragma once

class GISDATAAPI_API CGISDataFile
{
public:
	CGISDataFile(void);
	~CGISDataFile(void);

public:
	int		ReadGISFile(CGISData* pGData, const char* lpszFileName);
	void	SaveGISFile(CGISData* pGData, const char* lpszFileName);

private:
	int isComment(const char* lpszParser);
	int isTable(const char* lpszParser);
	int isColumn(const char* lpszParser);
	int isData(const char* lpszParser);
};
