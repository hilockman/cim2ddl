#pragma once
#pragma warning( disable: 4251 )

#include "../../MemDB/PGMemDB/PGMemDB.h"
using namespace PGMemDB;

#include "GISDataBuffer.h"
#include "GISDataDefine.h"

// #ifndef EXPORT_STL_VECTOR
// #	define EXPORT_STL_VECTOR( dllmacro, vectype ) \
// 	template class dllmacro std::allocator< vectype >; \
// 	template class dllmacro std::vector<vectype, std::allocator< vectype > >; 
// #endif
//\
//	EXPIMP_TEMPLATE template class dllmacro std::vector<vectype>;


// �����Ǵ� GISData.dll ������
class GISDATAAPI_API CGISData
{
public:
	CGISData(void);
	// TODO: �ڴ��������ķ�����
public:
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPSRType)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISRDF)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISGeographicalRegion)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISSubGeographicalRegion)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISBaseVoltage)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISSubstation)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISFeeder)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISCompositeSwitch)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISBreaker)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISDisconnector)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISLoadBreakSwitch)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISFuse)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISGroundDisconnector)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISACLineSegment)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPowerTransformer)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISConnLine)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISBusbarSection)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPole)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISJunction)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISEnergyConsumer)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISCompensator)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISCapacitor)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISTerminal)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISConnectivityNode)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPipe)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPT)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISCT)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISBLQ)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISFaultIndicator)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPTCab)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISGround)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISOther)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPTCABU)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISKWGXB)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPFWELL)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISPFTUNN)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagGISZJ)
// 
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagNode2Equipment)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagNode2Terminal)
// 	EXPORT_STL_VECTOR(GISDATAAPI_API, tagSub2Equipment)

	std::vector<tagGISPSRType>					m_PSRTypeArray;
	std::vector<tagGISRDF>						m_RDFArray;
	std::vector<tagGISGeographicalRegion>		m_GeographicalRegionArray;
	std::vector<tagGISSubGeographicalRegion>	m_SubGeographicalRegionArray;
	std::vector<tagGISBaseVoltage>				m_BaseVoltageArray;
	std::vector<tagGISSubstation>				m_SubstationArray;
	std::vector<tagGISFeeder>					m_FeederArray;
	std::vector<tagGISCompositeSwitch>			m_CompositeSwitchArray;
	std::vector<tagGISBreaker>					m_BreakerArray;
	std::vector<tagGISDisconnector>				m_DisconnectorArray;
	std::vector<tagGISLoadBreakSwitch>			m_LoadBreakSwitchArray;
	std::vector<tagGISFuse>						m_FuseArray;
	std::vector<tagGISGroundDisconnector>		m_GroundDisconnectorArray;
	std::vector<tagGISACLineSegment>			m_ACLineSegmentArray;
	std::vector<tagGISPowerTransformer>			m_PowerTransformerArray;
	std::vector<tagGISConnLine>					m_ConnLineArray;
	std::vector<tagGISBusbarSection>			m_BusbarSectionArray;
	std::vector<tagGISPole>						m_PoleArray;
	std::vector<tagGISJunction>					m_JunctionArray;
	std::vector<tagGISEnergyConsumer>			m_EnergyConsumerArray;
	std::vector<tagGISCompensator>				m_CompensatorArray;
	std::vector<tagGISCapacitor>				m_CapacitorArray;
	std::vector<tagGISTerminal>					m_TerminalArray;
	std::vector<tagGISConnectivityNode>			m_ConnectivityNodeArray;
	std::vector<tagGISPipe>						m_PipeArray;
	std::vector<tagGISPT>						m_PTArray;
	std::vector<tagGISCT>						m_CTArray;
	std::vector<tagGISBLQ>						m_BLQArray;
	std::vector<tagGISFaultIndicator>			m_FaultIndicatorArray;
	std::vector<tagGISPTCab>					m_PTCabArray;
	std::vector<tagGISGround>					m_GroundArray;
	std::vector<tagGISOther>					m_OtherArray;
	std::vector<tagGISPTCABU>					m_PTCABUArray;
	std::vector<tagGISKWGXB>					m_KWGXBArray;
	std::vector<tagGISPFWELL>					m_PFWELLArray;
	std::vector<tagGISPFTUNN>					m_PFTUNNArray;
	std::vector<tagGISZJ>						m_ZJArray;

	std::vector<tagNode2Equipment>				m_Node2EquipmentArray;
	std::vector<tagNode2Terminal>				m_Node2TerminalArray;
	std::vector<tagSub2Equipment>				m_Sub2EquipmentArray;

public:
	void	Release();
	void	Sort();
	void	Parse(const unsigned char bCoordNormalize, const unsigned char bDataWash=0, const unsigned char bJointReserve=0);

	//	���ݱ�������
public:
	const int	GetGISTableNum();
	const int	GetGISTableID(const int nTable);
	const char*	GetGISTableTag(const int nTable);
	const char*	GetGISTableDesp(const int nTable);
	const int	GetGISTableFieldIndex(const int nTable, const char* lpszFieldTag);
	const char*	GetGISTableFieldTag(const int nTable, const int nField);
	const int	GetGISTableFieldEnumNum(const int nTable, const int nField);
	const char*	GetGISTableFieldEnumName(const int nTable, const int nField, const int nEnumValue);
	const int	GetGISTableFieldEnumValue(const int nTable, const int nField, const char* lpszEnumName);

public:
	void		CheckValidate();
	const int	GetGISTableFieldNum(const int nTable);
	const char*	GetGISTableFieldDesp(const int nTable, const int nField);
	const int	GetGISTableRecordNum(const int nTable);
	const std::string	GetGISRecordValue(const int nTable, const int nField, const int nRecord);

	//	XML����
public:
	void	InitData(const int nGisTable);
	int		FillData(const int nGisTable, const char* lpszElementName, const char* lpszElementValue);
	int		FillData(const int nGisTable, const int nField, const char* lpszElementValue);
	int		AppendData(const int nGisTable, const std::string strPathName);

private:
	CGISDataBuffer	m_GISBuffer;

	//	CAD����
public:
	int		FindEntityResourceId(const char* lpszResourceId, int& nGISTable, int& nTable, int& nRecord);
	int		FindLineResourceId(const char* lpszResourceId, int& nGISTable, int& nTable, int& nRecord);

private:
	void	FormNode2Equipment();
	void	FormNode2Terminal();
	void	FormSub2Equipment();

	void	FormConnectivityNodeByTerminal();
	void	FormConnectivityNodeByEquipment(const unsigned char bAllEquipment=0);

	void	ParseptVertexArray(std::vector<tagGISVertex>& vArray, const char* lpszCoordinate);
	int		ResolveConnectivityNode(std::vector<int>& nNodeArray);
	void	SetConnConnectivityNode(const int nNode, std::vector<int>& nNodeArray);
	void	JointACLineSegmentCoordinate(std::string& strCoordinate, const char* lpszCoordJoint);
	int		GetSubstationType(const char* lpszSubstationTag);
	void	AddPsedoPole(tagGISACLineSegment* pLine, const unsigned char nTerminal);
	int		ParseTerminalFlag(const char* lpszSymbolID, const char* lpszTerminalResId);
	int		CheckNodeGroupValidate(std::vector<int>& nNodeArray);
	void	AbstractACLineSegmentName(const char* lpszName1, const char* lpszName2, char* lpszNameOut);

private:
	void	RemoveNouseDevice();
	void	RemoveNouse_Substation();
	void	RemoveNouse_Pole();
	void	RemoveNouse_Junction();
	void	RemoveNouse_BusbarSection();
	void	RemoveNouse_Compensator();
	void	RemoveNouse_Capacitor();
	void	RemoveNouse_GroundDisconnector();

	void	RemoveNouse_Breaker();
	void	RemoveNouse_Disconnector();
	void	RemoveNouse_LoadBreakSwitch();
	void	RemoveNouse_Fuse();

	void	RemoveNouse_ConnLine();

	void	RemoveNouse_ACLineSegment();
	void	RemoveNouse_PowerTransformer();

private:
	void	RemoveNoJointDevice();

private:
	void	CheckLineParam(tagGISACLineSegment* pLine);

private:
	void	ParseEquipmentContainer();
	void	ParseEquipmentConnectivityNode(const unsigned char bDataWash=0);
	void	ParseEquipmentSpatial();
	void	RelocateEquipmentCoord();
	void	FormACLineSegmentSubstation();
	void	ACLineSegment2ConnLine();
	void	TransformerWinding2UserTransformer();
	void	RegularPowerTransformerWind();
	void	RegularLineConnection();
	void	RegularPSRType();
	void	fillACLinesgmentJointObject();

private:
	void	MergeTerminalDeviceNode();
	void	MergeConnLineNode();
	void	MergeACLineSegment();
	void	RelocateCoordinate(std::string& strCoord, const int nPoint, tagGISVertex* pPtRelocate);	//	����㸳ֵ
	void	ShiftCoordinate(std::string& strCoord, tagGISVertex* pPtShift);		//	�����ƫ��

	//	���˲���
public:
	void	TraverseNode(const int nStartNode, std::vector<int>& nNodeArray);
	void	TraverseSubstation(const int nStartNode, std::vector<int>& nNodeArray);
	void	TraverseConnLine(const int nStartNode, std::vector<int>& nNodeArray);
	void	TraverseLineSegment(const int nStartNode, std::vector<int>& nNodeArray);

private:
	void	FindTerminals(const char* lpszParentResId, std::vector<tagGISTerminal>& tTermArray);
	void	AddUniqueString(std::vector<std::string>& strUniqueStringArray, const char* lpszAddString);

	//	������������
public:
	const std::string	GetVoltageLevelName(const char* lpszVoltTag);
	const std::string	GetPSRTypeName(const char* lpszPSRTypeTag);
	const std::string	GetGeographicalRegionName(const char* lpszGeographicalRegionTag);
	const std::string	GetSubGeographicalRegionName(const char* lpszSubGeographicalRegionTag);
	const std::string	GetFeederName(const char* lpszFeederTag);

	//	���ݲ��������������
private:
	void	sortInteger(std::vector<int>& nArray, int nDn0, int nUp0);
	void	sortString(std::vector<std::string>& strArray, int nDn0, int nUp0);
	void	sortPSRTypeByResID(int nDn0, int nUp0);
	void	sortBaseVoltageByResID(int nDn0, int nUp0);
	void	sortSubstationByResID(int nDn0, int nUp0);
	void	sortBusbarSectionByResID(int nDn0, int nUp0);
	void	sortPowerTransformerByResID(int nDn0, int nUp0);
	void	sortEnergyConsumerByResID(int nDn0, int nUp0);
	void	sortPoleByResID(int nDn0, int nUp0);
	void	sortJunctionByResID(int nDn0, int nUp0);
	void	sortFeederByResID(int nDn0, int nUp0);
	void	sortTerminalByParentTag(int nDn0, int nUp0);
	void	sortConnectivityNodeByResID(std::vector<tagGISConnectivityNode>& nodeArray, int nDn0, int nUp0);
	void	sortACLineSegmentByResID(int nDn0, int nUp0);
	void	sortConnLineByResID(int nDn0, int nUp0);
	void	sortBreakerByResID(int nDn0, int nUp0);
	void	sortDisconnectorByResID(int nDn0, int nUp0);
	void	sortLoadBreakSwitchByResID(int nDn0, int nUp0);
	void	sortFuseByResID(int nDn0, int nUp0);
	void	sortCompensatorByResID(int nDn0, int nUp0);
	void	sortPipeByResID(int nDn0, int nUp0);
	void	sortPTByResID(int nDn0, int nUp0);
	void	sortCTByResID(int nDn0, int nUp0);
	void	sortZJByResID(int nDn0, int nUp0);
	void	sortBLQByResID(int nDn0, int nUp0);

	int		findPSRTypeByResID(int nLeft, int nRight, const char* lpszTag);
	int		findBaseVoltageByResID(int nLeft, int nRight, const char* lpszTag);
	int		findSubstationByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBusbarSectionByResID(int nLeft, int nRight, const char* lpszResID);
	int		findPowerTransformerByResID(int nLeft, int nRight, const char* lpszResID);
	int		findEnergyConsumerByResID(int nLeft, int nRight, const char* lpszResID);
	int		findPoleByResID(int nLeft, int nRight, const char* lpszResID);
	int		findJunctionByResID(int nLeft, int nRight, const char* lpszResID);
	int		findFeederByResID(int nLeft, int nRight, const char* lpszResID);
	int		findTerminalByParentTag(int nLeft, int nRight, const char* lpszTag);
	int		findConnectivityNodeByResID(int nLeft, int nRight, const char* lpszResID);
	int		findConnectivityNodeByResID(int nLeft, int nRight, const char* lpszResID, const char* lpszVolt);
	int		findACLineSegmentByResID(int nLeft, int nRight, const char* lpszResID);
	int		findConnLineByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBreakerByResID(int nLeft, int nRight, const char* lpszResID);
	int		findDisconnectorByResID(int nLeft, int nRight, const char* lpszResID);
	int		findLoadBreakSwitchByResID(int nLeft, int nRight, const char* lpszResID);
	int		findFuseByResID(int nLeft, int nRight, const char* lpszResID);
	int		findCompensatorByResID(int nLeft, int nRight, const char* lpszResID);
	int		findPipeByResID(int nLeft, int nRight, const char* lpszResID);
	int		findPTByResID(int nLeft, int nRight, const char* lpszResID);
	int		findCTByResID(int nLeft, int nRight, const char* lpszResID);
	int		findZJByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBLQByResID(int nLeft, int nRight, const char* lpszResID);

	void	RegularPowerTransformerName();
	void	sortPowerTransformerByParentID(int nDn0, int nUp0);

	void	Check();
	void	RemoveNoTopoDevice();
};

extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	const	char*	g_lpszLogFile;
