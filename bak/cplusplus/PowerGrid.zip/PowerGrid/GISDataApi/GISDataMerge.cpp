#include "stdafx.h"
#include "GISData.h"

void	CGISData::MergeTerminalDeviceNode()
{
	register int	i;
	unsigned char	nTermFlag;
	int		nDev, nTem, nNode, nTernArrayLen;
	std::vector<tagGISTerminal>	tTermArray;
	std::vector<int>	nNodeArray, nTermArray;
	std::string		strNode;

	FormNode2Terminal();
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		nNodeArray.clear();

		nTermArray.clear();
		nTermArray.push_back(-1);
		nTermArray.push_back((int)m_TerminalArray.size());

		nTermFlag=1;
		while (nTermFlag)
		{
			nTermFlag=0;
			nTernArrayLen=(int)nTermArray.size()-1;
			for (i=0; i<nTernArrayLen; i++)
			{
				nTem=findTerminalByParentTag(nTermArray[i]+1, nTermArray[i+1]-1, m_PoleArray[nDev].strResourceID.c_str());
				if (nTem >= 0)
				{
					nTermFlag=1;
					nTermArray.push_back(nTem);
				}
			}
			sortInteger(nTermArray, 0, (int)nTermArray.size()-1);
		}

		for (nTem=1; nTem<(int)nTermArray.size()-1; nTem++)
		{
			if (m_TerminalArray[nTermArray[nTem]].nNode < 0)
				continue;

			nTermFlag=0;
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (nNodeArray[i] == m_TerminalArray[nTermArray[nTem]].nNode)
				{
					nTermFlag=1;
					break;
				}
			}
			if (!nTermFlag)
				nNodeArray.push_back(m_TerminalArray[nTermArray[nTem]].nNode);
		}
		if (nNodeArray.size() <= 1)
			continue;

		strNode=m_ConnectivityNodeArray[nNodeArray[0]].strResourceID;

		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray.size(); i++)
				m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strNodeTag=strNode;
		}
	}
#ifdef _DEBUG
	Log(g_lpszLogFile, "MergeTerminalDeviceNode@ Pole\n");
#endif

	FormNode2Terminal();
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		nNodeArray.clear();

		nTermArray.clear();
		nTermArray.push_back(-1);
		nTermArray.push_back((int)m_TerminalArray.size());

		nTermFlag=1;
		while (nTermFlag)
		{
			nTermFlag=0;
			nTernArrayLen=(int)nTermArray.size()-1;
			for (i=0; i<nTernArrayLen; i++)
			{
				nTem=findTerminalByParentTag(nTermArray[i]+1, nTermArray[i+1]-1, m_JunctionArray[nDev].strResourceID.c_str());
				if (nTem >= 0)
				{
					nTermFlag=1;
					nTermArray.push_back(nTem);
				}
			}
			sortInteger(nTermArray, 0, (int)nTermArray.size()-1);
		}

		for (nTem=1; nTem<(int)nTermArray.size()-1; nTem++)
		{
			if (m_TerminalArray[nTermArray[nTem]].nNode < 0)
				continue;

			nTermFlag=0;
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (nNodeArray[i] == m_TerminalArray[nTermArray[nTem]].nNode)
				{
					nTermFlag=1;
					break;
				}
			}
			if (!nTermFlag)
				nNodeArray.push_back(m_TerminalArray[nTermArray[nTem]].nNode);
		}
		if (nNodeArray.size() <= 1)
			continue;

// 		Log(g_lpszLogFile, "�����ն� %s ���� %d ���˵㣺\n", m_JunctionArray[nDev].strResourceID.c_str(), nNodeArray.size());
		strNode=m_ConnectivityNodeArray[nNodeArray[0]].strResourceID;

		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray.size(); i++)
			{
// 				Log(g_lpszLogFile, "    �ڵ�%d ������%d �˵�(%s) �ڵ�=%s -> %s\n", nNode+1, 
// 					m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i], m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strResourceID.c_str(), 
// 					m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strNodeTag.c_str(), strNode.c_str());
				m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strNodeTag=strNode;
			}
		}
	}
#ifdef _DEBUG
	Log(g_lpszLogFile, "MergeTerminalDeviceNode@ Junction\n");
#endif

	FormNode2Terminal();
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		nNodeArray.clear();

		nTermArray.clear();
		nTermArray.push_back(-1);
		nTermArray.push_back((int)m_TerminalArray.size());

		nTermFlag=1;
		while (nTermFlag)
		{
			nTermFlag=0;
			nTernArrayLen=(int)nTermArray.size()-1;
			for (i=0; i<nTernArrayLen; i++)
			{
				nTem=findTerminalByParentTag(nTermArray[i]+1, nTermArray[i+1]-1, m_CapacitorArray[nDev].strResourceID.c_str());
				if (nTem >= 0)
				{
					nTermFlag=1;
					nTermArray.push_back(nTem);
				}
			}
			sortInteger(nTermArray, 0, (int)nTermArray.size()-1);
		}

		for (nTem=1; nTem<(int)nTermArray.size()-1; nTem++)
		{
			if (m_TerminalArray[nTermArray[nTem]].nNode < 0)
				continue;

			nTermFlag=0;
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (nNodeArray[i] == m_TerminalArray[nTermArray[nTem]].nNode)
				{
					nTermFlag=1;
					break;
				}
			}
			if (!nTermFlag)
				nNodeArray.push_back(m_TerminalArray[nTermArray[nTem]].nNode);
		}
		if (nNodeArray.empty())
			continue;

		strNode=m_ConnectivityNodeArray[nNodeArray[0]].strResourceID;

		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray.size(); i++)
				m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strNodeTag=strNode;
		}
	}
#ifdef _DEBUG
	Log(g_lpszLogFile, "MergeTerminalDeviceNode@ Capacitor\n");
#endif

	FormNode2Terminal();
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		nNodeArray.clear();

		nTermArray.clear();
		nTermArray.push_back(-1);
		nTermArray.push_back((int)m_TerminalArray.size());

		nTermFlag=1;
		while (nTermFlag)
		{
			nTermFlag=0;
			nTernArrayLen=(int)nTermArray.size()-1;
			for (i=0; i<nTernArrayLen; i++)
			{
				nTem=findTerminalByParentTag(nTermArray[i]+1, nTermArray[i+1]-1, m_EnergyConsumerArray[nDev].strResourceID.c_str());
				if (nTem >= 0)
				{
					nTermFlag=1;
					nTermArray.push_back(nTem);
				}
			}
			sortInteger(nTermArray, 0, (int)nTermArray.size()-1);
		}

		for (nTem=1; nTem<(int)nTermArray.size()-1; nTem++)
		{
			if (m_TerminalArray[nTermArray[nTem]].nNode < 0)
				continue;

			nTermFlag=0;
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (nNodeArray[i] == m_TerminalArray[nTermArray[nTem]].nNode)
				{
					nTermFlag=1;
					break;
				}
			}
			if (!nTermFlag)
				nNodeArray.push_back(m_TerminalArray[nTermArray[nTem]].nNode);
		}
		if (nNodeArray.empty())
			continue;

		strNode=m_ConnectivityNodeArray[nNodeArray[0]].strResourceID;

		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray.size(); i++)
				m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strNodeTag=strNode;
		}
	}
#ifdef _DEBUG
	Log(g_lpszLogFile, "MergeTerminalDeviceNode@ EnergyConsumer\n");
#endif

	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		nNodeArray.clear();

		nTermArray.clear();
		nTermArray.push_back(-1);
		nTermArray.push_back((int)m_TerminalArray.size());

		nTermFlag=1;
		while (nTermFlag)
		{
			nTermFlag=0;
			nTernArrayLen=(int)nTermArray.size()-1;
			for (i=0; i<nTernArrayLen; i++)
			{
				nTem=findTerminalByParentTag(nTermArray[i]+1, nTermArray[i+1]-1, m_BusbarSectionArray[nDev].strResourceID.c_str());
				if (nTem >= 0)
				{
					nTermFlag=1;
					nTermArray.push_back(nTem);
				}
			}
			sortInteger(nTermArray, 0, (int)nTermArray.size()-1);
		}

		for (nTem=1; nTem<(int)nTermArray.size()-1; nTem++)
		{
			if (m_TerminalArray[nTermArray[nTem]].nNode < 0)
				continue;

			nTermFlag=0;
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (nNodeArray[i] == m_TerminalArray[nTermArray[nTem]].nNode)
				{
					nTermFlag=1;
					break;
				}
			}
			if (!nTermFlag)
				nNodeArray.push_back(m_TerminalArray[nTermArray[nTem]].nNode);
		}
		if (nNodeArray.empty())
			continue;

		strNode=m_ConnectivityNodeArray[nNodeArray[0]].strResourceID;

		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray.size(); i++)
				m_TerminalArray[m_Node2TerminalArray[nNodeArray[nNode]].nTerminalArray[i]].strNodeTag=strNode;
		}
	}
#ifdef _DEBUG
	Log(g_lpszLogFile, "MergeTerminalDeviceNode@ BusbarSection\n");
#endif

	nNodeArray.clear();
	nTermArray.clear();
	m_Node2TerminalArray.clear();
}

void	CGISData::MergeConnLineNode()
{
	register int	i, j;
	int		nLine, nNode;
	std::vector<int>			nNodeArray;
	std::vector<unsigned char>	bConnProcArray;

	bConnProcArray.resize(m_ConnLineArray.size());
	for (i=0; i<(int)bConnProcArray.size(); i++)		bConnProcArray[i]=0;

	for (nLine=0; nLine<(int)m_ConnLineArray.size(); nLine++)
	{
		m_ConnLineArray[nLine].bFlag=0;
		if (m_ConnLineArray[nLine].nNodeI < 0 && m_ConnLineArray[nLine].nNodeZ < 0)
			m_ConnLineArray[nLine].bFlag=1;
	}

	//Log(g_lpszLogFile, "MergeConnLineNode@1\n");
	for (nLine=0; nLine<(int)m_ConnLineArray.size(); nLine++)
	{
		if (m_ConnLineArray[nLine].nNodeI < 0 || m_ConnLineArray[nLine].nNodeZ < 0)
			continue;
		if (bConnProcArray[nLine])
			continue;
		bConnProcArray[nLine]=1;

		//Log(g_lpszLogFile, "  MergeConnLineNode@1-1\n");
		TraverseConnLine(m_ConnLineArray[nLine].nNodeI, nNodeArray);
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.size(); j++)
				bConnProcArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[j]]=1;
		}

		//Log(g_lpszLogFile, "  MergeConnLineNode@1-2\n");
		nNode=ResolveConnectivityNode(nNodeArray);
		if (nNode < 0)
		{
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray.size(); j++)
					m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[i]].nConnLineArray[j]].bFlag=1;
			}
			//Log(g_lpszLogFile, "ResolveConnectivityNode Error %s\n", m_ConnLineArray[nLine].strResourceID.c_str());

			//Log(g_lpszLogFile, "        I�����������\n");
			//Log(g_lpszLogFile, "            BusbarSection=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nBusbarSectionArray.size());
			//Log(g_lpszLogFile, "            GroundDisconnector=	%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nGroundDisconnectorArray.size());
			//Log(g_lpszLogFile, "            Compensator=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nCompensatorArray.size());
			//Log(g_lpszLogFile, "            Capacitor=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nCapacitorArray.size());
			//Log(g_lpszLogFile, "            ACLineSegment=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nACLineSegmentArray.size());
			//Log(g_lpszLogFile, "            PowerTransformer=	%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nPowerTransformerArray.size());
			//Log(g_lpszLogFile, "            ConnLine=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nConnLineArray.size());
			//Log(g_lpszLogFile, "            Breaker=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nBreakerArray.size());
			//Log(g_lpszLogFile, "            Disconnector=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nDisconnectorArray.size());
			//Log(g_lpszLogFile, "            LoadBreakSwitch=	%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nLoadBreakSwitchArray.size());
			//Log(g_lpszLogFile, "            Fuse=				%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nFuseArray.size());
			//Log(g_lpszLogFile, "            Pole=				%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nPoleArray.size());
			//Log(g_lpszLogFile, "            Junction=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeI].nJunctionArray.size());

			//Log(g_lpszLogFile, "        Z�����������\n");
			//Log(g_lpszLogFile, "            BusbarSection=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nBusbarSectionArray.size());
			//Log(g_lpszLogFile, "            GroundDisconnector=	%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nGroundDisconnectorArray.size());
			//Log(g_lpszLogFile, "            Compensator=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nCompensatorArray.size());
			//Log(g_lpszLogFile, "            Capacitor=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nCapacitorArray.size());
			//Log(g_lpszLogFile, "            ACLineSegment=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nACLineSegmentArray.size());
			//Log(g_lpszLogFile, "            PowerTransformer=	%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nPowerTransformerArray.size());
			//Log(g_lpszLogFile, "            ConnLine=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nConnLineArray.size());
			//Log(g_lpszLogFile, "            Breaker=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nBreakerArray.size());
			//Log(g_lpszLogFile, "            Disconnector=		%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nDisconnectorArray.size());
			//Log(g_lpszLogFile, "            LoadBreakSwitch=	%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nLoadBreakSwitchArray.size());
			//Log(g_lpszLogFile, "            Fuse=				%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nFuseArray.size());
			//Log(g_lpszLogFile, "            Pole=				%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nPoleArray.size());
			//Log(g_lpszLogFile, "            Junction=			%d\n", m_Node2EquipmentArray[m_ConnLineArray[nLine].nNodeZ].nJunctionArray.size());
			continue;
		}

		SetConnConnectivityNode(nNode, nNodeArray);
	}

	for (nLine=0; nLine<(int)m_ConnLineArray.size(); nLine++)
	{
		if (m_ConnLineArray[nLine].strNodeI.empty() || m_ConnLineArray[nLine].strNodeZ.empty())
			continue;

#ifdef _DEBUG
		if (stricmp(m_ConnLineArray[nLine].strNodeI.c_str(), m_ConnLineArray[nLine].strNodeZ.c_str()) != 0)
			Log(g_lpszLogFile, "����������ڵ㲻ͬ��˵�������������ߣ����ӷǵ����豸 %s\n", m_ConnLineArray[nLine].strResourceID.c_str());
#endif
	}
	bConnProcArray.clear();

	std::vector<tagGISConnLine>	connLineArray;
	connLineArray.clear();
	for (i=0; i<(int)m_ConnLineArray.size(); i++)
	{
		if (!m_ConnLineArray[i].bFlag)
			connLineArray.push_back(m_ConnLineArray[i]);
	}
	m_ConnLineArray.assign(connLineArray.begin(), connLineArray.end());
	connLineArray.clear();
}


void	CGISData::MergeACLineSegment()
{
	register int	i, j;
	int		nNode, nLine;
	unsigned char	bExist;
	std::vector<int>	nNodeArray;
	std::vector<int>	nLineArray;
	std::vector<unsigned char>	bLineProcArray;

	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
		m_ACLineSegmentArray[i].bFlag=0;
	for (i=0; i<(int)m_ConnectivityNodeArray.size(); i++)
		m_ConnectivityNodeArray[i].bFlaged=0;
	for (i=0; i<(int)m_ConnectivityNodeArray.size(); i++)
	{
#ifdef	_DEBUG
		Log(g_lpszLogFile, "�ڵ���Ϣ�� %s Breaker=%d Disconnector=%d %d %d %d %d %d %d %d ACLineSegment=%d \n", m_ConnectivityNodeArray[i].strResourceID.c_str(), 
			m_Node2EquipmentArray[i].nBreakerArray.size(), 
			m_Node2EquipmentArray[i].nDisconnectorArray.size(), 
			m_Node2EquipmentArray[i].nLoadBreakSwitchArray.size(), 
			m_Node2EquipmentArray[i].nFuseArray.size(), 
			m_Node2EquipmentArray[i].nPowerTransformerArray.size(), 
			m_Node2EquipmentArray[i].nCompensatorArray.size(), 
			m_Node2EquipmentArray[i].nCapacitorArray.size(), 
			m_Node2EquipmentArray[i].nPoleArray.size(), 
			m_Node2EquipmentArray[i].nJunctionArray.size(), 
			m_Node2EquipmentArray[i].nACLineSegmentArray.size());
#endif
		if (m_Node2EquipmentArray[i].nBreakerArray.empty() &&
			m_Node2EquipmentArray[i].nDisconnectorArray.empty() &&
			m_Node2EquipmentArray[i].nLoadBreakSwitchArray.empty() &&
			m_Node2EquipmentArray[i].nFuseArray.empty() &&
			m_Node2EquipmentArray[i].nPowerTransformerArray.empty() &&
			m_Node2EquipmentArray[i].nCompensatorArray.empty() &&
			m_Node2EquipmentArray[i].nCapacitorArray.empty() &&
			(!m_Node2EquipmentArray[i].nPoleArray.empty() || !m_Node2EquipmentArray[i].nJunctionArray.empty()) &&
			m_Node2EquipmentArray[i].nACLineSegmentArray.size() == 2)
		{
			m_ConnectivityNodeArray[i].bFlaged=1;
		}
	}

	bLineProcArray.resize(m_ACLineSegmentArray.size());
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	for (nLine=0; nLine<(int)m_ACLineSegmentArray.size(); nLine++)
	{
		if (bLineProcArray[nLine])
			continue;
		bLineProcArray[nLine]=1;
		if (m_ACLineSegmentArray[nLine].nNodeI < 0 || m_ACLineSegmentArray[nLine].nNodeZ < 0)
			continue;

		if (m_ConnectivityNodeArray[m_ACLineSegmentArray[nLine].nNodeI].bFlaged == m_ConnectivityNodeArray[m_ACLineSegmentArray[nLine].nNodeZ].bFlaged)
			continue;

		nNode=(m_ConnectivityNodeArray[m_ACLineSegmentArray[nLine].nNodeI].bFlaged) ? m_ACLineSegmentArray[nLine].nNodeI : m_ACLineSegmentArray[nLine].nNodeZ;
		TraverseLineSegment(nNode, nNodeArray);

		nLineArray.clear();
		for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
		{
			for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nACLineSegmentArray.size(); i++)
			{
				bExist=0;
				for (j=0; j<(int)nLineArray.size(); j++)
				{
					if (m_Node2EquipmentArray[nNodeArray[nNode]].nACLineSegmentArray[i] == nLineArray[j])
					{
						bExist=1;
						break;
					}
				}
				if (!bExist)
					nLineArray.push_back(m_Node2EquipmentArray[nNodeArray[nNode]].nACLineSegmentArray[i]);
			}
		}
#ifdef	_DEBUG
		Log(g_lpszLogFile, "������·����: %s %s\n", m_ACLineSegmentArray[nLine].strResourceID.c_str(), m_ACLineSegmentArray[nLine].strName.c_str());
#endif
	nNodeArray.clear();
	for (i=0; i<(int)nLineArray.size(); i++)
	{
#ifdef	_DEBUG
			Log(g_lpszLogFile, "        %s %s\n", m_ACLineSegmentArray[nLineArray[i]].strResourceID.c_str(), m_ACLineSegmentArray[nLineArray[i]].strName.c_str());
#endif
			bLineProcArray[nLineArray[i]] = 1;
			//if (!m_ConnectivityNodeArray[m_ACLineSegmentArray[nLineArray[i]].nNodeI].bFlaged && !m_ConnectivityNodeArray[m_ACLineSegmentArray[nLineArray[i]].nNodeZ].bFlaged)
			//	ASSERT(FALSE);

			if (m_ConnectivityNodeArray[m_ACLineSegmentArray[nLineArray[i]].nNodeI].bFlaged == m_ConnectivityNodeArray[m_ACLineSegmentArray[nLineArray[i]].nNodeZ].bFlaged)
				continue;

			nNode=(m_ConnectivityNodeArray[m_ACLineSegmentArray[nLineArray[i]].nNodeI].bFlaged) ? m_ACLineSegmentArray[nLineArray[i]].nNodeZ : m_ACLineSegmentArray[nLineArray[i]].nNodeI;
			nNodeArray.push_back(nNode);
		}

		if (nNodeArray.size() != 2)
		{
			//ASSERT(FALSE);
			continue;
		}

		m_ACLineSegmentArray[nLine].strNodeI=m_ConnectivityNodeArray[nNodeArray[0]].strResourceID;
		m_ACLineSegmentArray[nLine].strNodeZ=m_ConnectivityNodeArray[nNodeArray[1]].strResourceID;
		m_ACLineSegmentArray[nLine].nNodeI=nNodeArray[0];
		m_ACLineSegmentArray[nLine].nNodeZ=nNodeArray[1];

		//Log(g_lpszLogFile, "\n//////////////////////////////////////////////////////////////////////////\n");
		//Log(g_lpszLogFile, "MergeLineCoord Len=%d\n", m_GraphicArray[m_ACLineSegmentArray[nLine].nGraphic].strCoordinate.length());
		for (i=0; i<(int)nLineArray.size(); i++)
		{
			if (nLineArray[i] == nLine)
				continue;

			m_ACLineSegmentArray[nLineArray[i]].bFlag=1;
			if (m_ACLineSegmentArray[nLineArray[i]].gData.strCoordinate.empty())
				continue;
			if (m_ACLineSegmentArray[nLine].gData.strCoordinate.empty())
			{
				m_ACLineSegmentArray[nLine].gData.strCoordinate=m_ACLineSegmentArray[nLineArray[i]].gData.strCoordinate;
				m_ACLineSegmentArray[nLineArray[i]].gData.strCoordinate.clear();
				continue;
			}


			//Log(g_lpszLogFile, "    MergeLineCoord [%d]%s [%d]%s\n", 
			//		m_ACLineSegmentArray[nLine].nGraphic, m_GraphicArray[m_ACLineSegmentArray[nLine].nGraphic].strCoordinate.c_str(), 
			//		m_ACLineSegmentArray[nLineArray[i]].nGraphic, m_GraphicArray[m_ACLineSegmentArray[nLineArray[i]].nGraphic].strCoordinate.c_str());
			JointACLineSegmentCoordinate(m_ACLineSegmentArray[nLine].gData.strCoordinate, m_ACLineSegmentArray[nLineArray[i]].gData.strCoordinate.c_str());
			//m_GraphicArray[m_ACLineSegmentArray[nLine].nGraphic].strCoordinate.append(m_GraphicArray[m_ACLineSegmentArray[nLineArray[i]].nGraphic].strCoordinate);
			m_ACLineSegmentArray[nLineArray[i]].gData.strCoordinate.clear();
			//Log(g_lpszLogFile, "        %s %s\n", m_GraphicArray[m_ACLineSegmentArray[nLine].nGraphic].strCoordinate.c_str(), m_GraphicArray[m_ACLineSegmentArray[nLineArray[i]].nGraphic].strCoordinate.c_str());
		}
		//Log(g_lpszLogFile, "MergeLineCoord Len=%d\n", m_GraphicArray[m_ACLineSegmentArray[nLine].nGraphic].strCoordinate.length());
	}
	bLineProcArray.clear();

	std::vector<tagGISACLineSegment>	lineArray;
	lineArray.clear();

	Log(g_lpszLogFile, "    PrevMerge ACLineSegment@1=%d\n", m_ACLineSegmentArray.size());
	for (nLine=0; nLine<(int)m_ACLineSegmentArray.size(); nLine++)
	{
		if (!m_ACLineSegmentArray[nLine].bFlag)
			lineArray.push_back(m_ACLineSegmentArray[nLine]);
	}
	m_ACLineSegmentArray.assign(lineArray.begin(), lineArray.end());
	lineArray.clear();
	Log(g_lpszLogFile, "    PostMerge ACLineSegment@1=%d\n", m_ACLineSegmentArray.size());
}

void	CGISData::RelocateCoordinate(std::string& strCoord, const int nPoint, tagGISVertex* pPtReloc)
{
	register int	i;
	char	szBuf[260];
	std::vector<tagGISVertex>	ptCoordArray;

	ParseptVertexArray(ptCoordArray, strCoord.c_str());
	if (ptCoordArray.empty())
		return;

	if (nPoint == 1)	//	��ʼ�㸳ֵ
	{
		ptCoordArray[0].fX=pPtReloc->fX;
		ptCoordArray[0].fY=pPtReloc->fY;
	}
	else if (nPoint == 2)	//	��ֹ�㸳ֵ
	{
		ptCoordArray[ptCoordArray.size()-1].fX=pPtReloc->fX;
		ptCoordArray[ptCoordArray.size()-1].fY=pPtReloc->fY;
	}
	else
		return;

	strCoord.clear();
	for (i=0; i<(int)ptCoordArray.size(); i++)
	{
		sprintf(szBuf, "%f", ptCoordArray[i].fX);	strCoord.append(szBuf);	strCoord.append(", ");
		sprintf(szBuf, "%f", ptCoordArray[i].fY);	strCoord.append(szBuf);	strCoord.append(";");
	}
}

void	CGISData::ShiftCoordinate(std::string& strCoord, tagGISVertex* pPtDeviate)
{
	register int	i;
	char	szBuf[260];
	std::vector<tagGISVertex>	ptCoordArray;

	ParseptVertexArray(ptCoordArray, strCoord.c_str());
	if (ptCoordArray.empty())
		return;

	for (i=0; i<(int)ptCoordArray.size(); i++)
	{
		ptCoordArray[i].fX += pPtDeviate->fX;
		ptCoordArray[i].fY += pPtDeviate->fY;
	}

	strCoord.clear();
	for (i=0; i<(int)ptCoordArray.size(); i++)
	{
		sprintf(szBuf, "%f", ptCoordArray[i].fX);	strCoord.append(szBuf);	strCoord.append(", ");
		sprintf(szBuf, "%f", ptCoordArray[i].fY);	strCoord.append(szBuf);	strCoord.append(";");
	}
}
