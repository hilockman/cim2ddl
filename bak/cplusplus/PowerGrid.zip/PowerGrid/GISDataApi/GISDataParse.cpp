#include "stdafx.h"
#include "GISData.h"
#include "GISPSRType.h"

void	CGISData::Parse(const unsigned char bCoordNormalize, const unsigned char bDataWash, const unsigned char bJointReserve)
{
	clock_t	dBeg, dEnd;
	int		nDur;

	Log(g_lpszLogFile, "    GISData Parse CoordNormalize=%d RemoveNoTopoDevice=%d\n", bCoordNormalize, bDataWash);

	Log(g_lpszLogFile, "    ACLineSegment@1=%d\n", m_ACLineSegmentArray.size());

	RegularPowerTransformerName();

	dBeg=clock();
		Sort();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    ����������ɣ���ʱ%d����\n", nDur);

	FormConnectivityNodeByTerminal();

	//////////////////////////////////////////////////////////////////////////
	//	���²���Ϊ���������Բ��������������豸������ResourceId֮��Ĺ�����Ϣ
	dBeg=clock();
	MergeTerminalDeviceNode();							//	��ֹ���ָ����������նˡ�ĸ�ߺ͸��ɶ�˵㣬ͨ����Terminal��Nodeֵ��ɡ�
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    MergeTerminalDeviceNode��ɣ���ʱ%d����\n", nDur);

	dBeg=clock();
	ParseEquipmentContainer();							//	ͨ��RESOURCEID������֮���ϵ
	FormSub2Equipment();								//	������վ��Ϣ
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    �����豸������Ϣ��ɣ���ʱ%d����\n", nDur);

	dBeg=clock();
	ParseEquipmentConnectivityNode(bDataWash);			//	��Terminal����ConnectivityNode���������ڵ���豸֮���ϵ
	RegularPowerTransformerWind();
	if (bDataWash)
	{
		RemoveNoTopoDevice();
		Log(g_lpszLogFile, "    ACLineSegment=%d\n", m_ACLineSegmentArray.size());
	}

	FormNode2Equipment();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    ParseEquipmentConnectivityNode����ʱ%d����\n", nDur);

	dBeg=clock();
	TransformerWinding2UserTransformer();
	RegularPowerTransformerWind();
	FormNode2Equipment();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    TransformerWinding2UserTransformer��ɣ���ʱ%d����\n", nDur);
	//////////////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////////////
	//	���²���Ϊ���ݵĿռ���Ϣ������������λ�ʹ�С
	dBeg=clock();
	ParseEquipmentSpatial();					//	�ɿռ���Ϣ��λ����ʹ�С����Ϊ��Ҫ�������˹�ϵ���Ա������γ��豸�ڵ���Ϣ�����
	if (bCoordNormalize)
		RelocateEquipmentCoord();				//	����������վ��Ϣ�����豸������Ϣ���ṩ�ο�������
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    �����豸�ռ���Ϣ��ɣ���ʱ%d����\n", nDur);
	//////////////////////////////////////////////////////////////////////////

	dBeg=clock();
	FormNode2Equipment();
	MergeACLineSegment();						//	����·�κϲ�
	FormNode2Equipment();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    MergeACLineSegment��ɣ���ʱ%d����\n", nDur);

	dBeg=clock();
	FormACLineSegmentSubstation();						//	�����豸�ĳ�վ��Ϣ
	ACLineSegment2ConnLine();
	FormNode2Equipment();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    ������·��վ��Ϣ��ɣ���ʱ%d����\n", nDur);

	dBeg=clock();
	MergeConnLineNode();						//	�������ߵĽڵ�ϲ�Ϊһ�����������߽ڵ��޷��ϲ�������������������⡣
	FormNode2Equipment();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    MergeConnLineNode��ɣ���ʱ%d����\n", nDur);

	dBeg=clock();
	RegularLineConnection();						//	������·�������
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    ��׼����·������ɣ���ʱ%d����\n", nDur);

	if (bDataWash)
	{
		dBeg=clock();
		RemoveNouseDevice();							//	ɾ�����ڴ��������˴���Ϊ�������豸
		FormNode2Equipment();
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		Log(g_lpszLogFile, "    �Ƴ���Ч�豸��ɣ���ʱ%d����\n", nDur);
	}

	if (bJointReserve)
	{
		dBeg=clock();
		RemoveNoJointDevice();
		FormNode2Equipment();
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		Log(g_lpszLogFile, "    �Ƴ�����ͨ�豸��ɣ���ʱ%d����\n", nDur);
	}


	dBeg=clock();
	fillACLinesgmentJointObject();
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    ������·�����豸��ϵ��ɣ���ʱ%d����\n", nDur);

	RegularPSRType();
}

void	CGISData::ParseEquipmentContainer()
{
	int		nDev, nFind;

	//	EnergyConsumer��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		m_EnergyConsumerArray[nDev].nBelongPSRType=0;
		m_EnergyConsumerArray[nDev].strBelongPSRName.clear();
		nFind=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_EnergyConsumerArray[nDev].strBelongPSRTag.c_str());
		if (nFind >= 0)
		{
			m_EnergyConsumerArray[nDev].nBelongPSRType=GIS_Substation;
			m_EnergyConsumerArray[nDev].strBelongPSRName=m_SubstationArray[nFind].strName;
		}
		else
		{
			nFind=findBusbarSectionByResID(0, (int)m_BusbarSectionArray.size()-1, m_EnergyConsumerArray[nDev].strBelongPSRTag.c_str());
			if (nFind >= 0)
			{
				m_EnergyConsumerArray[nDev].nBelongPSRType=GIS_BusbarSection;
				m_EnergyConsumerArray[nDev].strBelongPSRName=m_BusbarSectionArray[nFind].strName;
			}
			else
			{
				nFind=findPowerTransformerByResID(0, (int)m_PowerTransformerArray.size()-1, m_EnergyConsumerArray[nDev].strBelongPSRTag.c_str());
				if (nFind >= 0)
				{
					m_EnergyConsumerArray[nDev].nBelongPSRType=GIS_PowerTransformer;
					m_EnergyConsumerArray[nDev].strBelongPSRName=m_PowerTransformerArray[nFind].strName;
				}
				else
				{
					nFind=findPoleByResID(0, (int)m_PoleArray.size()-1, m_EnergyConsumerArray[nDev].strBelongPSRTag.c_str());
					if (nFind >= 0)
					{
						m_EnergyConsumerArray[nDev].nBelongPSRType=GIS_Pole;
						m_EnergyConsumerArray[nDev].strBelongPSRName=m_PoleArray[nFind].strName;
					}
					else
					{
						nFind=findJunctionByResID(0, (int)m_JunctionArray.size()-1, m_EnergyConsumerArray[nDev].strBelongPSRTag.c_str());
						if (nFind >= 0)
						{
							m_EnergyConsumerArray[nDev].nBelongPSRType=GIS_Junction;
							m_EnergyConsumerArray[nDev].strBelongPSRName=m_JunctionArray[nFind].strName;
						}
					}
				}
			}
		}
	}

	//	ACLineSegment��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		m_ACLineSegmentArray[nDev].strFeeder.clear();
		m_ACLineSegmentArray[nDev].nContainerIdx=-1;

		if (m_ACLineSegmentArray[nDev].fLength > 200)
			m_ACLineSegmentArray[nDev].fLength=0;
		if (!m_ACLineSegmentArray[nDev].strParentTag.empty())
		{
			nFind=findFeederByResID(0, (int)m_FeederArray.size()-1, m_ACLineSegmentArray[nDev].strParentTag.c_str());
			if (nFind >= 0)
				m_ACLineSegmentArray[nDev].strFeeder=m_FeederArray[nFind].strName;
			else
				m_ACLineSegmentArray[nDev].nContainerIdx=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_ACLineSegmentArray[nDev].strParentTag.c_str());
		}
		if (!m_ACLineSegmentArray[nDev].strLineTag.empty())
		{
			nFind=findFeederByResID(0, (int)m_FeederArray.size()-1, m_ACLineSegmentArray[nDev].strLineTag.c_str());
			if (nFind >= 0)
				m_ACLineSegmentArray[nDev].strFeeder=m_FeederArray[nFind].strName;
		}
	}
}

void	CGISData::ParseEquipmentConnectivityNode(const unsigned char bDataWash)
{
	register int	i;
	int		nDev, nTem;
	unsigned char	nTermFlag;
	std::vector<tagGISTerminal>	tTermArray;

	//	Substation
	for (nDev=0; nDev<(int)m_TerminalArray.size(); nDev++)
		m_TerminalArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_TerminalArray[nDev].strNodeTag.c_str());

	//	ACLineSegment������·�˵�������·��վ���ڵ㡣ͬʱΪ��·�˵㸳ֵ��·���ơ�
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		m_ACLineSegmentArray[nDev].strNodeI.clear();
		m_ACLineSegmentArray[nDev].strNodeZ.clear();

		FindTerminals(m_ACLineSegmentArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.size() < 2)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "��·�˵���Ϣ���󣬶˵���=%d\n", tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_ACLineSegmentArray[nDev].strNodeI=tTermArray[0].strNodeTag;
		m_ACLineSegmentArray[nDev].strNodeZ=tTermArray[1].strNodeTag;
	}

	//	ConnLine
	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		m_ConnLineArray[nDev].strNodeI.clear();
		m_ConnLineArray[nDev].strNodeZ.clear();

		FindTerminals(m_ConnLineArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.empty())
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "�����߶˵���Ϣ���˵���=%d\n", tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_ConnLineArray[nDev].strNodeI=m_ConnLineArray[nDev].strNodeZ	=tTermArray[0].strNodeTag;
		if (tTermArray.size() > 1)	m_ConnLineArray[nDev].strNodeZ		=tTermArray[1].strNodeTag;
	}

	//	BusbarSection
	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		m_BusbarSectionArray[nDev].strNode.clear();
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_BusbarSectionArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
			m_BusbarSectionArray[nDev].strNode=m_TerminalArray[nTem].strNodeTag;
		else
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "ĸ�߶˵���Ϣ Term=%s �����Ҳ����˵�\n", m_BusbarSectionArray[nDev].strResourceID.c_str());
#endif // _DEBUG
		}
	}

	//	EnergyConsumer
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		m_EnergyConsumerArray[nDev].strNode.clear();
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_EnergyConsumerArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
			m_EnergyConsumerArray[nDev].strNode=m_TerminalArray[nTem].strNodeTag;
		else
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "���ɶ˵���Ϣ Term=%s �����Ҳ����˵�\n", m_EnergyConsumerArray[nDev].strResourceID.c_str());
#endif // _DEBUG
		}
	}

	//	Compensator
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		m_CompensatorArray[nDev].strNode.clear();
		m_CompensatorArray[nDev].strSeriesNode.clear();

		FindTerminals(m_CompensatorArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.empty())
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "�������˵���Ϣ���˵���=%d\n", tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_CompensatorArray[nDev].strNode=tTermArray[0].strNodeTag;
		if (tTermArray.size() > 1)	m_CompensatorArray[nDev].strSeriesNode=tTermArray[1].strNodeTag;
	}

	//	Capacitor
	for (nTem=0; nTem<(int)m_TerminalArray.size(); nTem++)
		m_TerminalArray[nTem].bFlag=0;
	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		m_CapacitorArray[nDev].strNode.clear();
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_CapacitorArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
			m_CapacitorArray[nDev].strNode=m_TerminalArray[nTem].strNodeTag;
		else
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "������[%s]�˵���Ϣ�����Ҳ����˵�\n", m_CapacitorArray[nDev].strResourceID.c_str());
#endif // _DEBUG
		}
	}

	//	Breaker
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		m_BreakerArray[nDev].strNodeI.clear();
		m_BreakerArray[nDev].strNodeZ.clear();

		FindTerminals(m_BreakerArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.size() < 2)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "��·��[%s]�˵���Ϣ���󣬶˵���=%d\n", m_BreakerArray[nDev].strResourceID.c_str(), tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_BreakerArray[nDev].strNodeI=tTermArray[0].strNodeTag;
		m_BreakerArray[nDev].strNodeZ=tTermArray[1].strNodeTag;
	}

	//	Disconnector
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		m_DisconnectorArray[nDev].strNodeI.clear();
		m_DisconnectorArray[nDev].strNodeZ.clear();

		FindTerminals(m_DisconnectorArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.size() < 2)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "���뿪��[%s]�˵���Ϣ���󣬶˵���=%d\n", m_DisconnectorArray[nDev].strResourceID.c_str(), tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_DisconnectorArray[nDev].strNodeI=tTermArray[0].strNodeTag;
		m_DisconnectorArray[nDev].strNodeZ=tTermArray[1].strNodeTag;
	}

	//	GroundDisconnector
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		m_GroundDisconnectorArray[nDev].strNode.clear();
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_GroundDisconnectorArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
			m_GroundDisconnectorArray[nDev].strNode=m_TerminalArray[nTem].strNodeTag;
		else
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "�ӵص�բ[%s]�˵�1��Ϣ�����Ҳ����˵�\n", m_GroundDisconnectorArray[nDev].strResourceID.c_str());
#endif // _DEBUG
		}
	}

	//	LoadBreakSwitch
	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		m_LoadBreakSwitchArray[nDev].strNodeI.clear();
		m_LoadBreakSwitchArray[nDev].strNodeZ.clear();

		FindTerminals(m_LoadBreakSwitchArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.size() < 2)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "���ɿ���[%s]�˵���Ϣ���󣬶˵���=%d\n", m_LoadBreakSwitchArray[nDev].strResourceID.c_str(), tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_LoadBreakSwitchArray[nDev].strNodeI=tTermArray[0].strNodeTag;
		m_LoadBreakSwitchArray[nDev].strNodeZ=tTermArray[1].strNodeTag;
	}

	//	Fuse
	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		m_FuseArray[nDev].strNodeI.clear();
		m_FuseArray[nDev].strNodeZ.clear();

		FindTerminals(m_LoadBreakSwitchArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.size() < 2)
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "�۶�ʽ����[%s]�˵���Ϣ���󣬶˵���=%d\n", m_LoadBreakSwitchArray[nDev].strResourceID.c_str(), tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_FuseArray[nDev].strNodeI=tTermArray[0].strNodeTag;
		m_FuseArray[nDev].strNodeZ=tTermArray[1].strNodeTag;
	}

	//	Pole
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		m_PoleArray[nDev].strNode.clear();

		FindTerminals(m_PoleArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.empty())
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "����[%s]�˵���Ϣ���˵���=%d\n", m_PoleArray[nDev].strResourceID.c_str(), tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_PoleArray[nDev].strNode=tTermArray[0].strNodeTag;
	}

	//	Junction
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		m_JunctionArray[nDev].strNode.clear();

		FindTerminals(m_JunctionArray[nDev].strResourceID.c_str(), tTermArray);
		if (tTermArray.empty())
		{
#ifdef _DEBUG
			Log(g_lpszLogFile, "�����ն�[%s]�˵���Ϣ���˵���=%d\n", m_JunctionArray[nDev].strResourceID.c_str(), tTermArray.size());
#endif // _DEBUG
			continue;
		}
		m_JunctionArray[nDev].strNode=tTermArray[0].strNodeTag;
	}

	//	PowerTransformer���ɵ�����ѹ���˵����õ�����ѹ����վ���ڵ㡣ͬʱΪ������ѹ���˵㸳ֵ������ѹ�����ơ�
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		for (i=0; i<3; i++)
		{
			m_PowerTransformerArray[nDev].strNodeArray[i].clear();
			m_PowerTransformerArray[nDev].strVoltTagArray[i].clear();
		}

		FindTerminals(m_PowerTransformerArray[nDev].strResourceID.c_str(), tTermArray);
		m_PowerTransformerArray[nDev].nWindNum=0;
		for (nTem=0; nTem<(int)tTermArray.size(); nTem++)
		{
			nTermFlag=ParseTerminalFlag(m_PowerTransformerArray[nDev].gData.strSymbolID.c_str(), tTermArray[nTem].strResourceID.c_str());
			if (nTermFlag == 1 || nTermFlag == 2 || nTermFlag == 3)
			{
				if (m_PowerTransformerArray[nDev].nWindNum < 3)
					m_PowerTransformerArray[nDev].strNodeArray[m_PowerTransformerArray[nDev].nWindNum++]=tTermArray[nTem].strNodeTag;
			}
		}
	}

	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		m_BusbarSectionArray[nDev].nNode=-1;
		if (m_BusbarSectionArray[nDev].strNode.empty())
			continue;
		m_BusbarSectionArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_BusbarSectionArray[nDev].strNode.c_str());
		if (m_BusbarSectionArray[nDev].nNode >= 0)
			m_ConnectivityNodeArray[m_BusbarSectionArray[nDev].nNode].strBaseVoltageTag=m_BusbarSectionArray[nDev].strBaseVoltageTag;
		else
			m_BusbarSectionArray[nDev].strNode.clear();
	}
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
	{
		m_PoleArray[nDev].nNode=-1;
		if (m_PoleArray[nDev].strNode.empty())
			continue;
		m_PoleArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_PoleArray[nDev].strNode.c_str());
		if (m_PoleArray[nDev].nNode >= 0)
			m_ConnectivityNodeArray[m_PoleArray[nDev].nNode].strBaseVoltageTag=m_PoleArray[nDev].strBaseVoltageTag;
		else
			m_PoleArray[nDev].strNode.clear();
	}
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
	{
		m_JunctionArray[nDev].nNode=-1;
		if (m_JunctionArray[nDev].strNode.empty())
			continue;
		m_JunctionArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_JunctionArray[nDev].strNode.c_str());
		if (m_JunctionArray[nDev].nNode >= 0)
			m_ConnectivityNodeArray[m_JunctionArray[nDev].nNode].strBaseVoltageTag=m_JunctionArray[nDev].strBaseVoltageTag;
		else
			m_JunctionArray[nDev].strNode.clear();
	}
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		m_EnergyConsumerArray[nDev].nNode=-1;
		if (m_EnergyConsumerArray[nDev].strNode.empty())
			continue;
		m_EnergyConsumerArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_EnergyConsumerArray[nDev].strNode.c_str());
		if (m_EnergyConsumerArray[nDev].nNode >= 0)
			m_ConnectivityNodeArray[m_EnergyConsumerArray[nDev].nNode].strBaseVoltageTag=m_EnergyConsumerArray[nDev].strBaseVoltageTag;
		else
			m_EnergyConsumerArray[nDev].strNode.clear();
	}
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		m_BreakerArray[nDev].nNodeI=m_BreakerArray[nDev].nNodeZ=-1;
		if (!m_BreakerArray[nDev].strNodeI.empty())
		{
			m_BreakerArray[nDev].nNodeI=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_BreakerArray[nDev].strNodeI.c_str());
			if (m_BreakerArray[nDev].nNodeI >= 0)
				m_ConnectivityNodeArray[m_BreakerArray[nDev].nNodeI].strBaseVoltageTag=m_BreakerArray[nDev].strBaseVoltageTag;
			else
				m_BreakerArray[nDev].strNodeI.clear();
		}
		if (!m_BreakerArray[nDev].strNodeZ.empty())
		{
			m_BreakerArray[nDev].nNodeZ=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_BreakerArray[nDev].strNodeZ.c_str());
			if (m_BreakerArray[nDev].nNodeZ >= 0)
				m_ConnectivityNodeArray[m_BreakerArray[nDev].nNodeZ].strBaseVoltageTag=m_BreakerArray[nDev].strBaseVoltageTag;
			else
				m_BreakerArray[nDev].strNodeZ.clear();
		}
	}
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		m_DisconnectorArray[nDev].nNodeI=m_DisconnectorArray[nDev].nNodeZ=-1;
		if (!m_DisconnectorArray[nDev].strNodeI.empty())
		{
			m_DisconnectorArray[nDev].nNodeI=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_DisconnectorArray[nDev].strNodeI.c_str());
			if (m_DisconnectorArray[nDev].nNodeI >= 0)
				m_ConnectivityNodeArray[m_DisconnectorArray[nDev].nNodeI].strBaseVoltageTag=m_DisconnectorArray[nDev].strBaseVoltageTag;
			else
				m_DisconnectorArray[nDev].strNodeI.clear();
		}

		if (!m_DisconnectorArray[nDev].strNodeZ.empty())
		{
			m_DisconnectorArray[nDev].nNodeZ=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_DisconnectorArray[nDev].strNodeZ.c_str());
			if (m_DisconnectorArray[nDev].nNodeZ >= 0)
				m_ConnectivityNodeArray[m_DisconnectorArray[nDev].nNodeZ].strBaseVoltageTag=m_DisconnectorArray[nDev].strBaseVoltageTag;
			else
				m_DisconnectorArray[nDev].strNodeZ.clear();
		}
	}
	for (nDev=0; nDev<(int)m_LoadBreakSwitchArray.size(); nDev++)
	{
		m_LoadBreakSwitchArray[nDev].nNodeI=m_LoadBreakSwitchArray[nDev].nNodeZ=-1;
		if (!m_LoadBreakSwitchArray[nDev].strNodeI.empty())
		{
			m_LoadBreakSwitchArray[nDev].nNodeI=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_LoadBreakSwitchArray[nDev].strNodeI.c_str());
			if (m_LoadBreakSwitchArray[nDev].nNodeI >= 0)
				m_ConnectivityNodeArray[m_LoadBreakSwitchArray[nDev].nNodeI].strBaseVoltageTag=m_LoadBreakSwitchArray[nDev].strBaseVoltageTag;
			else
				m_LoadBreakSwitchArray[nDev].strNodeI.clear();
		}

		if (!m_LoadBreakSwitchArray[nDev].strNodeZ.empty())
		{
			m_LoadBreakSwitchArray[nDev].nNodeZ=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_LoadBreakSwitchArray[nDev].strNodeZ.c_str());
			if (m_LoadBreakSwitchArray[nDev].nNodeZ >= 0)
				m_ConnectivityNodeArray[m_LoadBreakSwitchArray[nDev].nNodeZ].strBaseVoltageTag=m_LoadBreakSwitchArray[nDev].strBaseVoltageTag;
			else
				m_LoadBreakSwitchArray[nDev].strNodeZ.clear();
		}
	}
	for (nDev=0; nDev<(int)m_FuseArray.size(); nDev++)
	{
		m_FuseArray[nDev].nNodeI=m_FuseArray[nDev].nNodeZ=-1;
		if (!m_FuseArray[nDev].strNodeI.empty())
		{
			m_FuseArray[nDev].nNodeI=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_FuseArray[nDev].strNodeI.c_str());
			if (m_FuseArray[nDev].nNodeI >= 0)
				m_ConnectivityNodeArray[m_FuseArray[nDev].nNodeI].strBaseVoltageTag=m_FuseArray[nDev].strBaseVoltageTag;
			else
				m_FuseArray[nDev].strNodeI.clear();
		}

		if (!m_FuseArray[nDev].strNodeZ.empty())
		{
			m_FuseArray[nDev].nNodeZ=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_FuseArray[nDev].strNodeZ.c_str());
			if (m_FuseArray[nDev].nNodeZ >= 0)
				m_ConnectivityNodeArray[m_FuseArray[nDev].nNodeZ].strBaseVoltageTag=m_FuseArray[nDev].strBaseVoltageTag;
			else
				m_FuseArray[nDev].strNodeZ.clear();
		}
	}
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		m_GroundDisconnectorArray[nDev].nNode=-1;
		if (m_GroundDisconnectorArray[nDev].strNode.empty())
			continue;
		m_GroundDisconnectorArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_GroundDisconnectorArray[nDev].strNode.c_str());
		if (m_GroundDisconnectorArray[nDev].nNode >= 0)
			m_ConnectivityNodeArray[m_GroundDisconnectorArray[nDev].nNode].strBaseVoltageTag=m_GroundDisconnectorArray[nDev].strBaseVoltageTag;
		else
			m_GroundDisconnectorArray[nDev].strNode.clear();
	}
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		m_CompensatorArray[nDev].nNode=m_CompensatorArray[nDev].nSeriesNode=-1;
		if (!m_CompensatorArray[nDev].strNode.empty())
		{
			m_CompensatorArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_CompensatorArray[nDev].strNode.c_str());
			if (m_CompensatorArray[nDev].nNode >= 0)
				m_ConnectivityNodeArray[m_CompensatorArray[nDev].nNode].strBaseVoltageTag=m_CompensatorArray[nDev].strBaseVoltageTag;
			else
				m_CompensatorArray[nDev].strNode.clear();
		}
		if (!m_CompensatorArray[nDev].strSeriesNode.empty())
		{
			m_CompensatorArray[nDev].nSeriesNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_CompensatorArray[nDev].strSeriesNode.c_str());
			if (m_CompensatorArray[nDev].nSeriesNode >= 0)
				m_ConnectivityNodeArray[m_CompensatorArray[nDev].nSeriesNode].strBaseVoltageTag=m_CompensatorArray[nDev].strBaseVoltageTag;
			else
				m_CompensatorArray[nDev].strSeriesNode.clear();
		}
	}

	for (nDev=0; nDev<(int)m_CapacitorArray.size(); nDev++)
	{
		m_CapacitorArray[nDev].nNode=-1;
		if (m_CapacitorArray[nDev].strNode.empty())
			continue;
		m_CapacitorArray[nDev].nNode=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_CapacitorArray[nDev].strNode.c_str());
		if (m_CapacitorArray[nDev].nNode >= 0)
			m_ConnectivityNodeArray[m_CapacitorArray[nDev].nNode].strBaseVoltageTag=m_CapacitorArray[nDev].strBaseVoltageTag;
		else
			m_CapacitorArray[nDev].strNode.clear();
	}
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		m_ACLineSegmentArray[nDev].nNodeI=m_ACLineSegmentArray[nDev].nNodeZ=-1;
		if (!m_ACLineSegmentArray[nDev].strNodeI.empty())
		{
			m_ACLineSegmentArray[nDev].nNodeI=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_ACLineSegmentArray[nDev].strNodeI.c_str());
			if (m_ACLineSegmentArray[nDev].nNodeI >= 0)
				m_ConnectivityNodeArray[m_ACLineSegmentArray[nDev].nNodeI].strBaseVoltageTag=m_ACLineSegmentArray[nDev].strBaseVoltageTag;
			else
				m_ACLineSegmentArray[nDev].strNodeI.clear();
		}

		if (!m_ACLineSegmentArray[nDev].strNodeZ.empty())
		{
			m_ACLineSegmentArray[nDev].nNodeZ=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_ACLineSegmentArray[nDev].strNodeZ.c_str());
			if (m_ACLineSegmentArray[nDev].nNodeZ >= 0)
				m_ConnectivityNodeArray[m_ACLineSegmentArray[nDev].nNodeZ].strBaseVoltageTag=m_ACLineSegmentArray[nDev].strBaseVoltageTag;
			else
				m_ACLineSegmentArray[nDev].strNodeZ.clear();
		}
	}
	for (nDev=0; nDev<(int)m_ConnLineArray.size(); nDev++)
	{
		m_ConnLineArray[nDev].nNodeI=m_ConnLineArray[nDev].nNodeZ=-1;
		if (!m_ConnLineArray[nDev].strNodeI.empty())
		{
			m_ConnLineArray[nDev].nNodeI=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_ConnLineArray[nDev].strNodeI.c_str());
			if (m_ConnLineArray[nDev].nNodeI >= 0)
				m_ConnectivityNodeArray[m_ConnLineArray[nDev].nNodeI].strBaseVoltageTag=m_ConnLineArray[nDev].strBaseVoltageTag;
			else
				m_ConnLineArray[nDev].strNodeI.clear();
		}

		if (!m_ConnLineArray[nDev].strNodeZ.empty())
		{
			m_ConnLineArray[nDev].nNodeZ=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_ConnLineArray[nDev].strNodeZ.c_str());
			if (m_ConnLineArray[nDev].nNodeZ >= 0)
				m_ConnectivityNodeArray[m_ConnLineArray[nDev].nNodeZ].strBaseVoltageTag=m_ConnLineArray[nDev].strBaseVoltageTag;
			else
				m_ConnLineArray[nDev].strNodeZ.clear();
		}
	}
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
		{
			m_PowerTransformerArray[nDev].nNodeArray[i]=-1;
			if (!m_PowerTransformerArray[nDev].strNodeArray[i].empty())
			{
				m_PowerTransformerArray[nDev].nNodeArray[i]=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_PowerTransformerArray[nDev].strNodeArray[i].c_str());
				if (m_PowerTransformerArray[nDev].nNodeArray[i] >= 0)
					m_PowerTransformerArray[nDev].strVoltTagArray[i]=m_ConnectivityNodeArray[m_PowerTransformerArray[nDev].nNodeArray[i]].strBaseVoltageTag;
				else
				{
					m_PowerTransformerArray[nDev].strNodeArray[i].clear();
					m_PowerTransformerArray[nDev].strVoltTagArray[i].clear();
				}
			}
		}
		for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
		{
			if (m_PowerTransformerArray[nDev].strVoltTagArray[i].empty())
				m_PowerTransformerArray[nDev].strNodeArray[i].clear();
			if (m_PowerTransformerArray[nDev].strNodeArray[i].empty())
				m_PowerTransformerArray[nDev].strVoltTagArray[i].clear();

			if (!m_PowerTransformerArray[nDev].strNodeArray[i].empty())
			{
				for (int j=i+1; j<m_PowerTransformerArray[nDev].nWindNum; j++)
				{
					if (stricmp(m_PowerTransformerArray[nDev].strNodeArray[i].c_str(), m_PowerTransformerArray[nDev].strNodeArray[j].c_str()) == 0)
					{
						m_PowerTransformerArray[nDev].strNodeArray[j].clear();
						m_PowerTransformerArray[nDev].strVoltTagArray[j].clear();
						m_PowerTransformerArray[nDev].nNodeArray[j]=-1;
					}
				}
			}
		}
	}
}

void	CGISData::FormACLineSegmentSubstation()
{
	register int	i, j;
	int		nDev, nNode, nLine;
	std::vector<int>			nNodeArray;
	std::vector<std::string>	strSubIdArray;
	std::vector<std::string>	strPoleArray;
	std::vector<std::string>	strJuncArray;

	for (nDev=0; nDev<(int)m_SubstationArray.size(); nDev++)
		m_SubstationArray[nDev].bValid=0;
	for (nDev=0; nDev<(int)m_PoleArray.size(); nDev++)
		m_PoleArray[nDev].bValid=0;
	for (nDev=0; nDev<(int)m_JunctionArray.size(); nDev++)
		m_JunctionArray[nDev].bValid=0;

	for (nLine=0; nLine<(int)m_ACLineSegmentArray.size(); nLine++)
	{
		//Log(g_lpszLogFile, "��·������վ %s \n", m_ACLineSegmentArray[nLine].strName.c_str());
		if (m_ACLineSegmentArray[nLine].nNodeI >= 0)
		{
			strSubIdArray.clear();
			strPoleArray.clear();
			strJuncArray.clear();
			TraverseNode(m_ACLineSegmentArray[nLine].nNodeI, nNodeArray);
			//if (nNodeArray.size() > 1)	Log(g_lpszLogFile, "��· %s I�� NodeNum=%d\n", m_ACLineSegmentArray[nLine].strName.c_str(), nNodeArray.size());
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i];
					if (m_BusbarSectionArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    BusbarSection AddSub = %s\n", m_BusbarSectionArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_BusbarSectionArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i];
					if (m_PowerTransformerArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    PowerTransformer AddSub = %s\n", m_PowerTransformerArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_PowerTransformerArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[i];
					if (m_GroundDisconnectorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    GroundDisconnector AddSub = %s\n", m_GroundDisconnectorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_GroundDisconnectorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[i];
					if (m_CompensatorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Compensator AddSub = %s\n", m_CompensatorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_CompensatorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[i];
					if (m_CapacitorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Capacitor AddSub = %s\n", m_CapacitorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_CapacitorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i];
					if (m_BreakerArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Breaker AddSub = %s\n", m_BreakerArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_BreakerArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i];
					if (m_DisconnectorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Disconnector AddSub = %s\n", m_DisconnectorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_DisconnectorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i];
					if (m_LoadBreakSwitchArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    LoadBreakSwitch AddSub = %s\n", m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i];
					if (m_FuseArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Fuse AddSub = %s\n", m_FuseArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_FuseArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i];
					if (m_PoleArray[nDev].strResourceID.empty())
						continue;
					m_PoleArray[nDev].bValid=1;
					//strPoleArray.push_back(m_PoleArray[nDev].szResourceID);

					//Log(g_lpszLogFile, "    Pole AddSub = %s\n", m_PoleArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_PoleArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i];
					if (m_JunctionArray[nDev].strResourceID.empty())
						continue;
					m_JunctionArray[nDev].bValid=1;
					//strJuncArray.push_back(m_JunctionArray[nDev].strResourceID);

					//Log(g_lpszLogFile, "    Junction AddSub = %s\n", m_JunctionArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_JunctionArray[nDev].strParentTag.c_str());
				}
			}
			//if (strSubIdArray.size() > 1)
			//{
			//	Log(g_lpszLogFile, "        ��· I�� ���Ӷ����վ: %s\n", m_ACLineSegmentArray[nLine].szName);
			//	for (j=0; j<strSubIdArray.size(); j++)
			//		Log(g_lpszLogFile, "            ��վ[%d/%d] = %s\n", j+1, strSubIdArray.size(), strSubIdArray[j].c_str());
			//}
			if (strSubIdArray.empty())
				Log(g_lpszLogFile, "        ��· I�� û�����ӳ�վ: %s\n", m_ACLineSegmentArray[nLine].strName.c_str());

			for (i=0; i<(int)strSubIdArray.size(); i++)
			{
				nDev=findSubstationByResID(0, (int)m_SubstationArray.size()-1, strSubIdArray[i].c_str());
				if (nDev >= 0)
				{
					m_ACLineSegmentArray[nLine].strSubITag=m_SubstationArray[nDev].strResourceID;
					for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
					{
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); j++)
						{
							m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); j++)
						{
							m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); j++)
						{
							m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); j++)
						{
							m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); j++)
						{
							m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); j++)
						{
							m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); j++)
						{
							m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); j++)
						{
							m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); j++)
						{
							m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); j++)
						{
							m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); j++)
						{
							m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray.size(); j++)
						{
							m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
					}
					m_SubstationArray[nDev].bValid=1;
				}
				//else
				//	Log(g_lpszLogFile, "        I��վ = %s ���ڳ�վ��[%d]��\n", strSubIdArray[i].c_str(), m_SubstationArray.size());
			}
		}

		if (m_ACLineSegmentArray[nLine].nNodeZ >= 0)
		{
			strSubIdArray.clear();
			strPoleArray.clear();
			strJuncArray.clear();
			TraverseNode(m_ACLineSegmentArray[nLine].nNodeZ, nNodeArray);
			//if (nNodeArray.size() > 1)	Log(g_lpszLogFile, "��· %s Z�� NodeNum=%d\n", m_ACLineSegmentArray[nLine].strName.c_str(), nNodeArray.size());
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i];
					if (m_BusbarSectionArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    BusbarSection AddSub = %s\n", m_BusbarSectionArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_BusbarSectionArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i];
					if (m_PowerTransformerArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    PowerTransformer AddSub = %s\n", m_PowerTransformerArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_PowerTransformerArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[i];
					if (m_GroundDisconnectorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    GroundDisconnector AddSub = %s\n", m_GroundDisconnectorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_GroundDisconnectorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[i];
					if (m_CompensatorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Compensator AddSub = %s\n", m_CompensatorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_CompensatorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[i];
					if (m_CapacitorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Capacitor AddSub = %s\n", m_CapacitorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_CapacitorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i];
					if (m_BreakerArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Breaker AddSub = %s\n", m_BreakerArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_BreakerArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i];
					if (m_DisconnectorArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Disconnector AddSub = %s\n", m_DisconnectorArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_DisconnectorArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i];
					if (m_LoadBreakSwitchArray[nDev].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    LoadBreakSwitch AddSub = %s\n", m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
				{
					if (m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParentTag.empty())
						continue;
					//Log(g_lpszLogFile, "    Fuse AddSub = %s\n", m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i];
					if (m_PoleArray[nDev].strResourceID.empty())
						continue;
					m_PoleArray[nDev].bValid=1;
					//strPoleArray.push_back(m_PoleArray[nDev].strResourceID);
					//Log(g_lpszLogFile, "    Pole AddSub = %s\n", m_PoleArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_PoleArray[nDev].strParentTag.c_str());
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
				{
					nDev=m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i];
					if (m_JunctionArray[nDev].strResourceID.empty())
						continue;
					m_JunctionArray[nDev].bValid=1;
					//strJuncArray.push_back(m_JunctionArray[nDev].strResourceID.c_str());
					//Log(g_lpszLogFile, "    Junction AddSub = %s\n", m_JunctionArray[nDev].strParentTag.c_str());
					AddUniqueString(strSubIdArray, m_JunctionArray[nDev].strParentTag.c_str());
				}
			}
			//if (strSubIdArray.size() > 1)
			//{
			//	Log(g_lpszLogFile, "        ��· Z�� ���Ӷ����վ: %s\n", m_ACLineSegmentArray[nLine].strName.c_str());
			//	for (i=0; i<strSubIdArray.size(); i++)
			//		Log(g_lpszLogFile, "            ��վ[%d/%d] = %s\n", i+1, strSubIdArray.size(), strSubIdArray[i].c_str());
			//}
			if (strSubIdArray.empty())
				Log(g_lpszLogFile, "        ��· Z�� û�����ӳ�վ: %s\n", m_ACLineSegmentArray[nLine].strName.c_str());

			for (i=0; i<(int)strSubIdArray.size(); i++)
			{
				nDev=findSubstationByResID(0, (int)m_SubstationArray.size()-1, strSubIdArray[i].c_str());
				if (nDev >= 0)
				{
					m_ACLineSegmentArray[nLine].strSubZTag=m_SubstationArray[nDev].strResourceID;
					for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
					{
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); j++)
						{
							m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); j++)
						{
							m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); j++)
						{
							m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); j++)
						{
							m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); j++)
						{
							m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); j++)
						{
							m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); j++)
						{
							m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); j++)
						{
							m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); j++)
						{
							m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); j++)
						{
							m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); j++)
						{
							m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
						for (j=0; j<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray.size(); j++)
						{
							m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[j]].strParentTag=m_SubstationArray[nDev].strResourceID;
							m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[j]].strParent=m_SubstationArray[nDev].strName;
						}
					}
					m_SubstationArray[nDev].bValid=1;
				}
				//else
				//	Log(g_lpszLogFile, "        Z��վ = %s ���ڳ�վ��[%d]��\n", strSubIdArray[i].c_str(), m_SubstationArray.size());
			}
		}
	}

	// 	std::vector<tagGISSubstation>	subArray;
	// 	subArray.clear();
	// 	for (nDev=0; nDev<m_SubstationArray.size(); nDev++)
	// 	{
	// 		if (m_SubstationArray[nDev].bValid)
	// 			subArray.push_back(m_SubstationArray[nDev]);
	// 	}
	// 	m_SubstationArray.assign(subArray.begin(), subArray.end());
	// 	subArray.clear();

	// 	std::vector<tagGISPole>	poleArray;
	// 	poleArray.clear();
	// 	for (nDev=0; nDev<m_PoleArray.size(); nDev++)
	// 	{
	// 		if (m_PoleArray[nDev].bValid)
	// 			poleArray.push_back(m_PoleArray[nDev]);
	// 	}
	// 	m_PoleArray.assign(poleArray.begin(), poleArray.end());
	// 	poleArray.clear();
	// 
	// 	std::vector<tagGISJunction>	juncArray;
	// 	juncArray.clear();
	// 	for (nDev=0; nDev<m_JunctionArray.size(); nDev++)
	// 	{
	// 		if (m_JunctionArray[nDev].bValid)
	// 			juncArray.push_back(m_JunctionArray[nDev]);
	// 	}
	// 	m_JunctionArray.assign(juncArray.begin(), juncArray.end());
	// 	juncArray.clear();
}

void CGISData::ACLineSegment2ConnLine()
{
	int		nDev, nLine2Conn;
	tagGISConnLine	connBuf;

	std::vector<tagGISACLineSegment>	lineArray;

	nLine2Conn=0;

	m_GISBuffer.InitializeConnLine(connBuf);
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		m_ACLineSegmentArray[nDev].bFlag=1;
		if (m_ACLineSegmentArray[nDev].nContainerIdx < 0)
			continue;
		if (m_ACLineSegmentArray[nDev].strSubITag.empty() || m_ACLineSegmentArray[nDev].strSubZTag.empty())
			continue;
		if (strcmp(m_ACLineSegmentArray[nDev].strSubITag.c_str(), m_ACLineSegmentArray[nDev].strSubZTag.c_str()) != 0)
			continue;

		m_ACLineSegmentArray[nDev].bFlag=0;

		connBuf.strResourceID		=m_ACLineSegmentArray[nDev].strResourceID;
		connBuf.strPSRTypeTag		=m_ACLineSegmentArray[nDev].strPSRTypeTag;
		connBuf.strObjectID			=m_ACLineSegmentArray[nDev].strObjectID;
		connBuf.strName				=m_ACLineSegmentArray[nDev].strName;
		connBuf.strParentTag		=m_ACLineSegmentArray[nDev].strParentTag;
		connBuf.strBaseVoltageTag	=m_ACLineSegmentArray[nDev].strBaseVoltageTag;
		if (m_ACLineSegmentArray[nDev].nContainerIdx >= 0)	connBuf.strParent			=m_SubstationArray[m_ACLineSegmentArray[nDev].nContainerIdx].strName;
		connBuf.strNodeI			=m_ACLineSegmentArray[nDev].strNodeI;
		connBuf.strNodeZ			=m_ACLineSegmentArray[nDev].strNodeZ;
		connBuf.nNodeI				=m_ACLineSegmentArray[nDev].nNodeI;
		connBuf.nNodeZ				=m_ACLineSegmentArray[nDev].nNodeZ;
		connBuf.gData.strCoordinate	=m_ACLineSegmentArray[nDev].gData.strCoordinate;
		connBuf.gData.strSymbolID	=m_ACLineSegmentArray[nDev].gData.strSymbolID;
		connBuf.gData.fSymbolSize	=m_ACLineSegmentArray[nDev].gData.fSymbolSize;
		connBuf.gData.fSymbolAngle	=m_ACLineSegmentArray[nDev].gData.fSymbolAngle;
		connBuf.gData.strPath		=m_ACLineSegmentArray[nDev].gData.strPath;
		m_ConnLineArray.push_back(connBuf);

		nLine2Conn++;
		//Log(g_lpszLogFile, "    ��·Ϊվ�������� :%s\n", m_ACLineSegmentArray[nDev].strResourceID);
	}
	Log(g_lpszLogFile, "���� %d ��·Ϊվ��������\n", nLine2Conn);

	lineArray.clear();
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		if (!m_ACLineSegmentArray[nDev].bFlag)
			continue;
		lineArray.push_back(m_ACLineSegmentArray[nDev]);
	}
	m_ACLineSegmentArray.assign(lineArray.begin(), lineArray.end());
	lineArray.clear();

	sortConnLineByResID(0, (int)m_ConnLineArray.size()-1);
}

void CGISData::TransformerWinding2UserTransformer()
{
	register int	i;
	int		nDev, nNode1DevNum, nNode2DevNum; 
	std::vector<int>	nNodeArray;

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (m_PowerTransformerArray[nDev].nWindNum != 2)
			continue;
		if (stricmp(m_PowerTransformerArray[nDev].strVoltTagArray[0].c_str(), m_PowerTransformerArray[nDev].strVoltTagArray[1].c_str()) != 0)
			continue;
		if (m_PowerTransformerArray[nDev].nNodeArray[0] < 0 && m_PowerTransformerArray[nDev].nNodeArray[1] < 0)
			continue;

		if (m_PowerTransformerArray[nDev].nNodeArray[0] < 0)
		{
			m_PowerTransformerArray[nDev].strVoltTagArray[0].clear();
			m_PowerTransformerArray[nDev].strNodeArray[0].clear();
			m_PowerTransformerArray[nDev].nNodeArray[0]=-1;
		}
		else if (m_PowerTransformerArray[nDev].nNodeArray[1] < 0)
		{
			m_PowerTransformerArray[nDev].strVoltTagArray[1].clear();
			m_PowerTransformerArray[nDev].strNodeArray[1].clear();
			m_PowerTransformerArray[nDev].nNodeArray[1]=-1;
		}
		else
		{
			nNode1DevNum=nNode2DevNum=0;
			TraverseNode(m_PowerTransformerArray[nDev].nNodeArray[0], nNodeArray);
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nGroundDisconnectorArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
				nNode1DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			}
			TraverseNode(m_PowerTransformerArray[nDev].nNodeArray[1], nNodeArray);
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nGroundDisconnectorArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCapacitorArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nACLineSegmentArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nCompensatorArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nBreakerArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nDisconnectorArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nLoadBreakSwitchArray.size();
				nNode2DevNum += (int)m_Node2EquipmentArray[nNodeArray[i]].nFuseArray.size();
			}

			if (nNode1DevNum == 1)
			{
				m_PowerTransformerArray[nDev].strVoltTagArray[0].clear();
				m_PowerTransformerArray[nDev].strNodeArray[0].clear();
				m_PowerTransformerArray[nDev].nNodeArray[0]=-1;
			}
			else if (nNode2DevNum == 1)
			{
				m_PowerTransformerArray[nDev].strVoltTagArray[1].clear();
				m_PowerTransformerArray[nDev].strNodeArray[1].clear();
				m_PowerTransformerArray[nDev].nNodeArray[1]=-1;
			}
		}

		//if (stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2003-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2301-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2303-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2304-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2305-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2308-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2318-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2319-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2320-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2321-0") == 0)	//	�������ѹ��
		//{
		//	nWindType=2;
		//}
		//else if (stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2004-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2005-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2309-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2311-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2313-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2315-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2310-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2312-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2314-0") == 0 ||
		//	stricmp(m_GraphicArray[m_PowerTransformerArray[nDev].nGraphic].strSymbolID.c_str(), "2316-0") == 0)	//	�������ѹ��
		//{
		//	nWindType=1;
		//}
	}
}

void	CGISData::fillACLinesgmentJointObject()
{
	register int	i;
	int				nLine, nNode, nDev;
	unsigned char	bFind;
	std::vector<int>	nNodeArray;

	for (nLine=0; nLine<(int)m_ACLineSegmentArray.size(); nLine++)
	{
		if (m_ACLineSegmentArray[nLine].nNodeI < 0 || m_ACLineSegmentArray[nLine].nNodeZ < 0)
			continue;

		nNode=m_ACLineSegmentArray[nLine].nNodeI;
		TraverseNode(nNode, nNodeArray);
		bFind=0;
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			if (!m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray[0];
				m_ACLineSegmentArray[nLine].nIJointEquipmentType=GetSubstationType(m_BusbarSectionArray[nDev].strParentTag.c_str());
				m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_BusbarSectionArray[nDev].strParentTag;
				bFind=1;
				break;
			}
		}
		if (!bFind)
		{
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (!m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.empty())
				{
					nDev=m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray[0];
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONLOAD;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_PowerTransformerArray[nDev].strResourceID;
					bFind=1;
					break;
				}
			}
		}
		if (!bFind)
		{
			if (!bFind && !m_Node2EquipmentArray[nNode].nBreakerArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nBreakerArray[0];
				if (!m_BreakerArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=GetSubstationType(m_BreakerArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_BreakerArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_BreakerArray[nDev].strResourceID;
				}
				bFind=1;
			}
			if (!bFind && !m_Node2EquipmentArray[nNode].nDisconnectorArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nDisconnectorArray[0];
				if (!m_DisconnectorArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=GetSubstationType(m_DisconnectorArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_DisconnectorArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_DisconnectorArray[nDev].strResourceID;
				}
				bFind=1;
			}
			if (!bFind && !m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[0];
				if (!m_LoadBreakSwitchArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=GetSubstationType(m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_LoadBreakSwitchArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_LoadBreakSwitchArray[nDev].strResourceID;
				}
				bFind=1;
			}
			if (!bFind && !m_Node2EquipmentArray[nNode].nFuseArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nFuseArray[0];
				if (!m_FuseArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=GetSubstationType(m_FuseArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_FuseArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_FuseArray[nDev].strResourceID;
				}
				bFind=1;
			}
		}
		if (!bFind)
		{
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (!m_Node2EquipmentArray[nNodeArray[i]].nPoleArray.empty())
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONDOT;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_PoleArray[m_Node2EquipmentArray[nNodeArray[i]].nPoleArray[0]].strResourceID;
					bFind=1;
					break;
				}
				else if (!m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray.empty())
				{
					m_ACLineSegmentArray[nLine].nIJointEquipmentType=PG_DISTRIBUTIONDOT;
					m_ACLineSegmentArray[nLine].strIJointEquipmentTag=m_JunctionArray[m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray[0]].strResourceID;
					bFind=1;
					break;
				}
			}
		}

		nNode=m_ACLineSegmentArray[nLine].nNodeZ;
		TraverseNode(nNode, nNodeArray);
		bFind=0;
		for (i=0; i<(int)nNodeArray.size(); i++)
		{
			if (!m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNodeArray[i]].nBusbarSectionArray[0];
				m_ACLineSegmentArray[nLine].nZJointEquipmentType=GetSubstationType(m_BusbarSectionArray[nDev].strParentTag.c_str());
				m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_BusbarSectionArray[nDev].strParentTag;
				bFind=1;
				break;
			}
		}
		if (!bFind)
		{
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (!m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray.empty())
				{
					nDev=m_Node2EquipmentArray[nNodeArray[i]].nPowerTransformerArray[0];
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONLOAD;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_PowerTransformerArray[nDev].strResourceID;
					bFind=1;
					break;
				}
			}
		}
		if (!bFind)
		{
			if (!bFind && !m_Node2EquipmentArray[nNode].nBreakerArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nBreakerArray[0];
				if (!m_BreakerArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=GetSubstationType(m_BreakerArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_BreakerArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_BreakerArray[nDev].strResourceID;
				}
				bFind=1;
			}
			if (!bFind && !m_Node2EquipmentArray[nNode].nDisconnectorArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nDisconnectorArray[0];
				if (!m_DisconnectorArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=GetSubstationType(m_DisconnectorArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_DisconnectorArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_DisconnectorArray[nDev].strResourceID;
				}
				bFind=1;
			}
			if (!bFind && !m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nLoadBreakSwitchArray[0];
				if (!m_LoadBreakSwitchArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=GetSubstationType(m_LoadBreakSwitchArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_LoadBreakSwitchArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_LoadBreakSwitchArray[nDev].strResourceID;
				}
				bFind=1;
			}
			if (!bFind && !m_Node2EquipmentArray[nNode].nFuseArray.empty())
			{
				nDev=m_Node2EquipmentArray[nNode].nFuseArray[0];
				if (!m_FuseArray[nDev].strParent.empty())
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=GetSubstationType(m_FuseArray[nDev].strParentTag.c_str());
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_FuseArray[nDev].strParentTag;
				}
				else
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONBREAKER;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_FuseArray[nDev].strResourceID;
				}
				bFind=1;
			}
		}
		if (!bFind)
		{
			for (i=0; i<(int)nNodeArray.size(); i++)
			{
				if (!m_Node2EquipmentArray[nNodeArray[i]].nPoleArray.empty())
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONDOT;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_PoleArray[m_Node2EquipmentArray[nNodeArray[i]].nPoleArray[0]].strResourceID;
					bFind=1;
					break;
				}
				else if (!m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray.empty())
				{
					m_ACLineSegmentArray[nLine].nZJointEquipmentType=PG_DISTRIBUTIONDOT;
					m_ACLineSegmentArray[nLine].strZJointEquipmentTag=m_JunctionArray[m_Node2EquipmentArray[nNodeArray[i]].nJunctionArray[0]].strResourceID;
					bFind=1;
					break;
				}
			}
		}
	}
}
