#include "stdafx.h"
#include "GISData.h"

int	CGISData::findBaseVoltageByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_BaseVoltageArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BaseVoltageArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findBaseVoltageByResID(nLeft, nMid-1, lpszResID);
			else
				return findBaseVoltageByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findPSRTypeByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_PSRTypeArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_PSRTypeArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findPSRTypeByResID(nLeft, nMid-1, lpszResID);
			else
				return findPSRTypeByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findTerminalByParentTag(int nLeft, int nRight, const char* lpszTag)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (m_TerminalArray[nMid].bFlag == 0 && strcmp(m_TerminalArray[nMid].strParentTag.c_str(), lpszTag) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_TerminalArray[nMid].strParentTag.c_str(), lpszTag) > 0)
				return findTerminalByParentTag(nLeft, nMid-1, lpszTag);
			else
				return findTerminalByParentTag(nMid+1, nRight, lpszTag);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findConnectivityNodeByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_ConnectivityNodeArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ConnectivityNodeArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findConnectivityNodeByResID(nLeft, nMid-1, lpszResID);
			else
				return findConnectivityNodeByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findConnectivityNodeByResID(int nLeft, int nRight, const char* lpszResID, const char* lpszVolt)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_ConnectivityNodeArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ConnectivityNodeArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findConnectivityNodeByResID(nLeft, nMid-1, lpszResID, lpszVolt);
			else
				return findConnectivityNodeByResID(nMid+1, nRight, lpszResID, lpszVolt);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}


int	CGISData::findSubstationByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_SubstationArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_SubstationArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findSubstationByResID(nLeft, nMid-1, lpszResID);
			else
				return findSubstationByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findBusbarSectionByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_BusbarSectionArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BusbarSectionArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findBusbarSectionByResID(nLeft, nMid-1, lpszResID);
			else
				return findBusbarSectionByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findPowerTransformerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_PowerTransformerArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_PowerTransformerArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findPowerTransformerByResID(nLeft, nMid-1, lpszResID);
			else
				return findPowerTransformerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findEnergyConsumerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_EnergyConsumerArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_EnergyConsumerArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findEnergyConsumerByResID(nLeft, nMid-1, lpszResID);
			else
				return findEnergyConsumerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findPoleByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_PoleArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_PoleArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findPoleByResID(nLeft, nMid-1, lpszResID);
			else
				return findPoleByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findJunctionByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_JunctionArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_JunctionArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findJunctionByResID(nLeft, nMid-1, lpszResID);
			else
				return findJunctionByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findFeederByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_FeederArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_FeederArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findFeederByResID(nLeft, nMid-1, lpszResID);
			else
				return findFeederByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findACLineSegmentByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_ACLineSegmentArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ACLineSegmentArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findACLineSegmentByResID(nLeft, nMid-1, lpszResID);
			else
				return findACLineSegmentByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findConnLineByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_ConnLineArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ConnLineArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findConnLineByResID(nLeft, nMid-1, lpszResID);
			else
				return findConnLineByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findBreakerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_BreakerArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BreakerArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findBreakerByResID(nLeft, nMid-1, lpszResID);
			else
				return findBreakerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findDisconnectorByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_DisconnectorArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_DisconnectorArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findDisconnectorByResID(nLeft, nMid-1, lpszResID);
			else
				return findDisconnectorByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findLoadBreakSwitchByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_LoadBreakSwitchArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_LoadBreakSwitchArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findLoadBreakSwitchByResID(nLeft, nMid-1, lpszResID);
			else
				return findLoadBreakSwitchByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findFuseByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_FuseArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_FuseArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findFuseByResID(nLeft, nMid-1, lpszResID);
			else
				return findFuseByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findCompensatorByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_CompensatorArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_CompensatorArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findCompensatorByResID(nLeft, nMid-1, lpszResID);
			else
				return findCompensatorByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findPTByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_PTArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_PTArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findPTByResID(nLeft, nMid-1, lpszResID);
			else
				return findPTByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findCTByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_CTArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_CTArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findCTByResID(nLeft, nMid-1, lpszResID);
			else
				return findCTByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findZJByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_ZJArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ZJArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findZJByResID(nLeft, nMid-1, lpszResID);
			else
				return findZJByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findBLQByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_BLQArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BLQArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findBLQByResID(nLeft, nMid-1, lpszResID);
			else
				return findBLQByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::findPipeByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;
		if (strcmp(m_PipeArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_PipeArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findPipeByResID(nLeft, nMid-1, lpszResID);
			else
				return findPipeByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

int	CGISData::FindEntityResourceId(const char* lpszResourceId, int& nGISTable, int& nTable, int& nRecord)
{
	nRecord=findSubstationByResID(0, (int)m_SubstationArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_Substation;
		nTable=GetSubstationType(m_SubstationArray[nRecord].strResourceID.c_str());
		return 1;
	}
	nRecord=findPowerTransformerByResID(0, (int)m_PowerTransformerArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_PowerTransformer;
		nTable=PG_DISTRIBUTIONLOAD;
		return 1;
	}
	nRecord=findEnergyConsumerByResID(0, (int)m_EnergyConsumerArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_EnergyConsumer;
		nTable=PG_DISTRIBUTIONLOAD;
		return 1;
	}
	nRecord=findPoleByResID(0, (int)m_PoleArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_Pole;
		nTable=PG_DISTRIBUTIONDOT;
		return 1;
	}
	nRecord=findJunctionByResID(0, (int)m_JunctionArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_Junction;
		nTable=PG_DISTRIBUTIONDOT;
		return 1;
	}
	nRecord=findBreakerByResID(0, (int)m_BreakerArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_Breaker;
		nTable=PG_DISTRIBUTIONBREAKER;
		return 1;
	}
	nRecord=findDisconnectorByResID(0, (int)m_DisconnectorArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_Disconnector;
		nTable=PG_DISTRIBUTIONBREAKER;
		return 1;
	}
	nRecord=findLoadBreakSwitchByResID(0, (int)m_LoadBreakSwitchArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_LoadBreakSwitch;
		nTable=PG_DISTRIBUTIONBREAKER;
		return 1;
	}
	nRecord=findFuseByResID(0, (int)m_FuseArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nGISTable=GIS_Fuse;
		nTable=PG_DISTRIBUTIONBREAKER;
		return 1;
	}

	return 0;
}

int	CGISData::FindLineResourceId(const char* lpszResourceId, int& nGISTable, int& nTable, int& nRecord)
{
	nGISTable=GIS_ACLineSegment;
	nTable=PG_ACLINESEGMENT;
	nRecord=findACLineSegmentByResID(0, (int)m_ACLineSegmentArray.size()-1, lpszResourceId);
	if (nRecord >= 0 && nRecord < (int)m_ACLineSegmentArray.size())
		return 1;
	nRecord=findConnLineByResID(0, (int)m_ConnLineArray.size()-1, lpszResourceId);
	if (nRecord >= 0 && nRecord < (int)m_ConnLineArray.size())
		return 1;

	nGISTable=GIS_Pipe;
	nTable=PG_PIPE;
	nRecord=findPipeByResID(0, (int)m_PipeArray.size()-1, lpszResourceId);
	if (nRecord >= 0 && nRecord < (int)m_PipeArray.size())
		return 1;
	return 0;
}
