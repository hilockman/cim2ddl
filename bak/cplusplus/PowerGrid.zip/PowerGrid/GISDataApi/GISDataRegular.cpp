#include "stdafx.h"
#include "GISData.h"

void CGISData::RegularPowerTransformerName()
{
	register int	i;
	int		nDev, nTranID;
	unsigned char	bSameName;
	char			szBuffer[MDB_CHARLEN];
	std::string		strTranName;
	std::vector<unsigned char>	bProcArray;

	bProcArray.resize(m_PowerTransformerArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	sortPowerTransformerByParentID(0, (int)m_PowerTransformerArray.size()-1);
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (bProcArray[nDev])
			continue;
		bProcArray[nDev]=1;

		bSameName=0;
		for (i=nDev+1; i<(int)m_PowerTransformerArray.size(); i++)
		{
			if (stricmp(m_PowerTransformerArray[nDev].strParentTag.c_str(), m_PowerTransformerArray[i].strParentTag.c_str()) != 0)
				break;

			if (stricmp(m_PowerTransformerArray[nDev].strName.c_str(), m_PowerTransformerArray[i].strName.c_str()) == 0)
			{
				bSameName=1;
				break;
			}
		}
		if (bSameName)
		{
			nTranID=1;
			strTranName=m_PowerTransformerArray[nDev].strName;
			for (i=nDev; i<(int)m_PowerTransformerArray.size(); i++)
			{
				if (stricmp(m_PowerTransformerArray[nDev].strParentTag.c_str(), m_PowerTransformerArray[i].strParentTag.c_str()) != 0)
					break;

				if (stricmp(strTranName.c_str(), m_PowerTransformerArray[i].strName.c_str()) == 0)
				{
					bProcArray[i]=1;

					sprintf(szBuffer, "#%d", nTranID++);
					m_PowerTransformerArray[i].strName.append(szBuffer);
				}
			}
		}
	}
}

void	CGISData::RegularPowerTransformerWind()
{
	register int	i, j, k;
	int		nDev, nNode;
	float	fVoltI, fVoltJ;
	std::string	strVolt, strNode;

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
		{
			fVoltI=0;
			for (k=0; k<(int)m_BaseVoltageArray.size(); k++)
			{
				if (stricmp(m_BaseVoltageArray[k].strResourceID.c_str(), m_PowerTransformerArray[nDev].strVoltTagArray[i].c_str()) == 0)
				{
					fVoltI=m_BaseVoltageArray[k].fNominalVoltage;
					break;
				}
			}
			for (j=i+1; j<m_PowerTransformerArray[nDev].nWindNum; j++)
			{
				fVoltJ=0;
				for (k=0; k<(int)m_BaseVoltageArray.size(); k++)
				{
					if (stricmp(m_BaseVoltageArray[k].strResourceID.c_str(), m_PowerTransformerArray[nDev].strVoltTagArray[j].c_str()) == 0)
					{
						fVoltJ=m_BaseVoltageArray[k].fNominalVoltage;
						break;
					}
				}

				if (fVoltI < fVoltJ)
				{
					strVolt	=m_PowerTransformerArray[nDev].strVoltTagArray[i]	;
					strNode	=m_PowerTransformerArray[nDev].strNodeArray[i]		;
					nNode	=m_PowerTransformerArray[nDev].nNodeArray[i]		;

					m_PowerTransformerArray[nDev].strVoltTagArray[i]=m_PowerTransformerArray[nDev].strVoltTagArray[j]	;
					m_PowerTransformerArray[nDev].strNodeArray[i]	=m_PowerTransformerArray[nDev].strNodeArray[j]		;
					m_PowerTransformerArray[nDev].nNodeArray[i]		=m_PowerTransformerArray[nDev].nNodeArray[j]		;

					m_PowerTransformerArray[nDev].strVoltTagArray[j]=strVolt;
					m_PowerTransformerArray[nDev].strNodeArray[j]	=strNode;
					m_PowerTransformerArray[nDev].nNodeArray[j]		=nNode	;
				}
			}
		}

		i=0;
		while (i < m_PowerTransformerArray[nDev].nWindNum)
		{
			if (m_PowerTransformerArray[nDev].strNodeArray[i].empty() || m_PowerTransformerArray[nDev].strVoltTagArray[i].empty())
				m_PowerTransformerArray[nDev].nWindNum--;
			else
				i++;
		}
	}
}

void	CGISData::RegularLineConnection()
{
	register int	i;
	int		nNode, nLine;
	unsigned char	bValidNodeGroup, bSubFormed;
	std::vector<unsigned char>	bNodeProcArray;
	std::vector<int>			nNodeArray;

	bNodeProcArray.resize(m_ConnectivityNodeArray.size());
	for (i=0; i<(int)bNodeProcArray.size(); i++)
		bNodeProcArray[i]=0;

	for (nLine=0; nLine<(int)m_ACLineSegmentArray.size(); nLine++)
	{
		if (m_ACLineSegmentArray[nLine].strNodeI.empty() || m_ACLineSegmentArray[nLine].strNodeZ.empty())
			continue;
		if (m_ACLineSegmentArray[nLine].nNodeI < 0 || m_ACLineSegmentArray[nLine].nNodeZ < 0)
			continue;

		if (!bNodeProcArray[m_ACLineSegmentArray[nLine].nNodeI])
		{
			TraverseNode(m_ACLineSegmentArray[nLine].nNodeI, nNodeArray);
			for (i=0; i<(int)nNodeArray.size(); i++)
				bNodeProcArray[nNodeArray[i]]=1;

			bValidNodeGroup=0;
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				if (!m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.empty())
				{
					bValidNodeGroup=1;
					break;
				}
			}

			if (!bValidNodeGroup)
				AddPsedoPole(&m_ACLineSegmentArray[nLine], 0);
		}

		if (!bNodeProcArray[m_ACLineSegmentArray[nLine].nNodeZ])
		{
			TraverseNode(m_ACLineSegmentArray[nLine].nNodeZ, nNodeArray);
			for (i=0; i<(int)nNodeArray.size(); i++)
				bNodeProcArray[nNodeArray[i]]=1;

			bValidNodeGroup=0;
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				if (!m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.empty() ||
					!m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.empty())
				{
					bValidNodeGroup=1;
					break;
				}
			}

			if (!bValidNodeGroup)
				AddPsedoPole(&m_ACLineSegmentArray[nLine], 1);
		}
	}
	sortPoleByResID(0, (int)m_PoleArray.size()-1);
	FormNode2Equipment();

	tagGISSubstation	subBuf;
	m_GISBuffer.InitializeSubstation(subBuf);
	subBuf.bVirtual=1;
	for (nLine=0; nLine<(int)m_ACLineSegmentArray.size(); nLine++)
	{
		if (m_ACLineSegmentArray[nLine].strSubITag.empty())
		{
			if (m_ACLineSegmentArray[nLine].nNodeI < 0)
				continue;
			bSubFormed=0;

			subBuf.strHighVoltage=m_ACLineSegmentArray[nLine].strBaseVoltageTag;
			TraverseNode(m_ACLineSegmentArray[nLine].nNodeI, nNodeArray);
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubITag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
			}

			if (bSubFormed)
			{
				for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
				{
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
					{
						m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParentTag=subBuf.strResourceID;
						m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); i++)
					{
						m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i]].strParentTag=subBuf.strResourceID;
						m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); i++)
					{
						m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[i]].strParentTag=subBuf.strResourceID;
						m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); i++)
					{
						m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[i]].strParentTag=subBuf.strResourceID;
						m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); i++)
					{
						m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[i]].strParentTag=subBuf.strResourceID;
						m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
					{
						m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParentTag=subBuf.strResourceID;
						m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
					{
						m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].strParentTag=subBuf.strResourceID;
						m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
					{
						m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].strParentTag=subBuf.strResourceID;
						m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
					{
						m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].strParentTag=subBuf.strResourceID;
						m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
					{
						m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParentTag=subBuf.strResourceID;
						m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
					{
						m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParentTag=subBuf.strResourceID;
						m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray.size(); i++)
					{
						m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[i]].strParentTag=subBuf.strResourceID;
						m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[i]].strParent=subBuf.strName;
					}
				}
			}
		}
		if (m_ACLineSegmentArray[nLine].strSubZTag.empty())
		{
			if (m_ACLineSegmentArray[nLine].nNodeZ < 0)
			{
				continue;
			}
			bSubFormed=0;
			subBuf.strHighVoltage=m_ACLineSegmentArray[nLine].strBaseVoltageTag;
			TraverseNode(m_ACLineSegmentArray[nLine].nNodeZ, nNodeArray);
			for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
			{
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); i++)
				{
				}
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
				for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
				{
					subBuf.strResourceID="VR";
					subBuf.strResourceID.append(m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strResourceID);
					subBuf.strObjectID=subBuf.strResourceID;
					subBuf.strName=subBuf.strResourceID;
					m_SubstationArray.push_back(subBuf);

					m_ACLineSegmentArray[nLine].strSubZTag=subBuf.strResourceID;
					bSubFormed=1;
					break;
				}
				if (bSubFormed)
					break;
			}
			if (bSubFormed)
			{
				for (nNode=0; nNode<(int)nNodeArray.size(); nNode++)
				{
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray.size(); i++)
					{
						m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParentTag=subBuf.strResourceID;
						m_BusbarSectionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBusbarSectionArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray.size(); i++)
					{
						m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i]].strParentTag=subBuf.strResourceID;
						m_PowerTransformerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPowerTransformerArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray.size(); i++)
					{
						m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[i]].strParentTag=subBuf.strResourceID;
						m_GroundDisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nGroundDisconnectorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray.size(); i++)
					{
						m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[i]].strParentTag=subBuf.strResourceID;
						m_CompensatorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCompensatorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray.size(); i++)
					{
						m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[i]].strParentTag=subBuf.strResourceID;
						m_CapacitorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nCapacitorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray.size(); i++)
					{
						m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParentTag=subBuf.strResourceID;
						m_JunctionArray[m_Node2EquipmentArray[nNodeArray[nNode]].nJunctionArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray.size(); i++)
					{
						m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].strParentTag=subBuf.strResourceID;
						m_BreakerArray[m_Node2EquipmentArray[nNodeArray[nNode]].nBreakerArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray.size(); i++)
					{
						m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].strParentTag=subBuf.strResourceID;
						m_DisconnectorArray[m_Node2EquipmentArray[nNodeArray[nNode]].nDisconnectorArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray.size(); i++)
					{
						m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].strParentTag=subBuf.strResourceID;
						m_LoadBreakSwitchArray[m_Node2EquipmentArray[nNodeArray[nNode]].nLoadBreakSwitchArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray.size(); i++)
					{
						m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParentTag=subBuf.strResourceID;
						m_FuseArray[m_Node2EquipmentArray[nNodeArray[nNode]].nFuseArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray.size(); i++)
					{
						m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParentTag=subBuf.strResourceID;
						m_PoleArray[m_Node2EquipmentArray[nNodeArray[nNode]].nPoleArray[i]].strParent=subBuf.strName;
					}
					for (i=0; i<(int)m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray.size(); i++)
					{
						m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[i]].strParentTag=subBuf.strResourceID;
						m_ConnLineArray[m_Node2EquipmentArray[nNodeArray[nNode]].nConnLineArray[i]].strParent=subBuf.strName;
					}
				}
			}
		}
	}
	sortSubstationByResID(0, (int)m_SubstationArray.size()-1);
	bNodeProcArray.clear();
	FormSub2Equipment();
}

void	CGISData::RegularPSRType()
{
}
