#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"
#include "../../../Common/TinyXML/tinyxml.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

void CPG2BpaFileApi::PG2BpaRmlFile(tagPGBlock* pPGBlock, const char* lpszFileName)
{
	int		nSub, nVolt, nDev, nVoltI, nVoltJ, nIsland;
	FILE*	fp;
	char	szBusName[MDB_CHARLEN], szRParamFile[260];

	PGMemDBTopo(pPGBlock);
	PGMemDBIsland(pPGBlock);
	PGMemDBStatus(pPGBlock, 0);
	PGMemDBPFAmend(pPGBlock);

	std::vector<char>	cGenIDArray, cLineLoopArray, cTranLoopArray;
	GetGenIDArray(pPGBlock, cGenIDArray);
	GetLineLoopArray(pPGBlock, cLineLoopArray);
	GetTranLoopArray(pPGBlock, cTranLoopArray);

	//////////////////////////////////////////////////////////////////////////
	//	������һ�κ�������ɾ��
	char	drive[_MAX_DRIVE], dir[_MAX_DIR], fname[_MAX_FNAME], ext[_MAX_EXT];
	_splitpath(lpszFileName, drive, dir, fname, ext);
	_makepath(szRParamFile, drive, dir, fname, "rml");

	fp=fopen(szRParamFile, "w");
	if (fp != NULL)
	{
		for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
		{
			if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
				continue;
			if (pPGBlock->m_IslandArray[nIsland].bDead)
				continue;

			fprintf(fp, "//MODL��ʾ�ɿ���ģ��\n");
			fprintf(fp, "//GTWO����״̬�ķ����ģ�ͣ�����Ϊ��Rerr�ǹ�����(��/��)��Trep���޸�ʱ��(hours/��)\n");
			fprintf(fp, "//          BusName  BaseKv  ID      Rerr  Trep\n");
			for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
			{
				for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
				{
					for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
					{
						if (pPGBlock->m_SynchronousMachineArray[nDev].nIsland != nIsland)
							continue;
						if (pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep < FLT_MIN)
							continue;

						fprintf(fp, "//�����: %s %s %s\n", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szVolt, pPGBlock->m_SynchronousMachineArray[nDev].szName);
						fprintf(fp, "MODL GTWO    B_%d %.2f  %c   P: %f %f\n", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage, cGenIDArray[nDev], pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr, pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep);

					}
				}
			}
			fprintf(fp, "\n");

			fprintf(fp, "//LTWO����״̬����·ģ�ͣ�����Ϊ��\n");
			fprintf(fp, "//          FromBus      ToBus      ID  Rerr Trep\n");
			fprintf(fp, "//        Name BaseKv  Name  BaseKv  \n");
			fprintf(fp, "//���������յ���Բ���DAT����ͬ��Rerr�ǹ�����(��/��)��Trep���޸�ʱ��(hours/��)\n");
			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
			{
				if (pPGBlock->m_ACLineSegmentArray[nDev].nIsland != nIsland)
					continue;
				if (pPGBlock->m_ACLineSegmentArray[nDev].ri_Rerr < FLT_MIN || pPGBlock->m_ACLineSegmentArray[nDev].ri_Trep < FLT_MIN)
					continue;

				nVoltI=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
				nVoltJ=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ, pPGBlock->m_ACLineSegmentArray[nDev].szVoltJ);

				fprintf(fp, "//��·: %s\n", pPGBlock->m_ACLineSegmentArray[nDev].szName);
				fprintf(fp, "MODL LTWO B_%d %.2f B_%d %.2f  %c   P: %f %f\n", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI, pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage, 
					pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ, pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage, cLineLoopArray[nDev], pPGBlock->m_ACLineSegmentArray[nDev].ri_Rerr, pPGBlock->m_ACLineSegmentArray[nDev].ri_Trep);
			}

			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
			{
				if (pPGBlock->m_TransformerWindingArray[nDev].nIsland != nIsland)
					continue;
				if (pPGBlock->m_TransformerWindingArray[nDev].ri_Rerr < FLT_MIN || pPGBlock->m_TransformerWindingArray[nDev].ri_Trep < FLT_MIN)
					continue;

				nVoltI=pPGBlock->m_TransformerWindingArray[nDev].nVoltI;
				nVoltJ=pPGBlock->m_TransformerWindingArray[nDev].nVoltJ;

				fprintf(fp, "//��ѹ��: %s %s\n", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);
				fprintf(fp, "MODL LTWO B_%d %.2f B_%d %.2f  %c   P: %f %f\n", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusI, pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage, 
					pPGBlock->m_TransformerWindingArray[nDev].nTopoBusJ, pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage, cTranLoopArray[nDev], pPGBlock->m_TransformerWindingArray[nDev].ri_Rerr, pPGBlock->m_TransformerWindingArray[nDev].ri_Trep);
			}
		}

		fflush(fp);
		fclose(fp);
	}


	TiXmlElement		*pElement;
	TiXmlDocument*		pDocument = new TiXmlDocument();						//����һ��XML���ĵ�����
	pDocument->LinkEndChild(new TiXmlDeclaration("1.0", "gb2312", "no"));
	TiXmlElement*		pRootElement = new TiXmlElement("BpaPRParam");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
				{
					if (pPGBlock->m_SynchronousMachineArray[nDev].nIsland != nIsland)
						continue;
					if (pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep < FLT_MIN)
						continue;

					pElement = new TiXmlElement("GenRml");			//����һ����Ԫ�ز����ӡ�
					pRootElement->LinkEndChild(pElement);

					sprintf(szBusName, "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					pElement->SetAttribute("Name",			szBusName);
					pElement->SetDoubleAttribute("Volt",	pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					pElement->SetDoubleAttribute("Rerr",	pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr);
					pElement->SetDoubleAttribute("Trep",	pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep);
				}
			}
		}
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
		{
			pElement = new TiXmlElement("LineRml");
			pRootElement->LinkEndChild(pElement);

			nVoltI=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
			nVoltJ=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ, pPGBlock->m_ACLineSegmentArray[nDev].szVoltJ);

			sprintf(szBusName, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI);	pElement->SetAttribute("BusI",	szBusName);
			pElement->SetDoubleAttribute("VoltI",	pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage);
			sprintf(szBusName, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ);	pElement->SetAttribute("BusJ",	szBusName);
			pElement->SetDoubleAttribute("VoltJ",	pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage);
			pElement->SetAttribute("Loop",			(int)cLineLoopArray[nDev]);
			pElement->SetDoubleAttribute("Rerr",	pPGBlock->m_ACLineSegmentArray[nDev].ri_Rerr);
			pElement->SetDoubleAttribute("Trep",	pPGBlock->m_ACLineSegmentArray[nDev].ri_Trep);
		}
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
		{
			pElement = new TiXmlElement("TranRml");
			pRootElement->LinkEndChild(pElement);

			nVoltI=pPGBlock->m_TransformerWindingArray[nDev].nVoltI;
			nVoltJ=pPGBlock->m_TransformerWindingArray[nDev].nVoltJ;

			sprintf(szBusName, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusI);	pElement->SetAttribute("BusI",	szBusName);
			pElement->SetDoubleAttribute("VoltI",	pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage);
			sprintf(szBusName, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusJ);	pElement->SetAttribute("BusJ",	szBusName);
			pElement->SetDoubleAttribute("VoltJ",	pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage);
			pElement->SetAttribute("Loop",			(int)cTranLoopArray[nDev]);
			pElement->SetDoubleAttribute("Rerr",	pPGBlock->m_TransformerWindingArray[nDev].ri_Rerr);
			pElement->SetDoubleAttribute("Trep",	pPGBlock->m_TransformerWindingArray[nDev].ri_Trep);
		}
	}

	_makepath(szRParamFile, drive, dir, fname, "xml");
	pDocument->SaveFile(szRParamFile);					//���浽�ļ�
	pDocument->Clear();
	delete pDocument;
}
