#include "StdAfx.h"
#include "PG2BpaApi.h"

CBpaGenModelApi::CBpaGenModelApi(void)
{
}

CBpaGenModelApi::~CBpaGenModelApi(void)
{
}

void CBpaGenModelApi::ClearModel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_nExcModel=m_nPssModel=m_nGovModel=m_nMovModel=-1;
	m_nGenIndex=m_nExcIndex=m_nPssIndex=m_nGovIndex=m_nSvoIndex=m_nMovIndex=-1;

	memset(&m_BpaSwi_GenBuffer		, 0, sizeof(tagBpaSwi_Gen	));
	memset(&m_BpaSwi_DampBuffer		, 0, sizeof(tagBpaSwi_Damp	));
	memset(&m_BpaSwi_GenLnBuffer	, 0, sizeof(tagBpaSwi_GenLn	));

	memset(&m_BpaSwi_Exc68Buffer	, 0, sizeof(tagBpaSwi_Exc68	));
	memset(&m_BpaSwi_Exc81Buffer	, 0, sizeof(tagBpaSwi_Exc81	));
	memset(&m_BpaSwi_ExcMVBuffer	, 0, sizeof(tagBpaSwi_ExcMV	));
	memset(&m_BpaSwi_ExcXBuffer		, 0, sizeof(tagBpaSwi_ExcX	));

	memset(&m_BpaSwi_PssSBuffer		, 0, sizeof(tagBpaSwi_PssS	));
	memset(&m_BpaSwi_PssSHBuffer	, 0, sizeof(tagBpaSwi_PssSH));
// 	memset(&m_BpaSwi_PssSH1Buffer	, 0, sizeof(tagBpaSwi_PssSH1));
// 	memset(&m_BpaSwi_PssSH2Buffer	, 0, sizeof(tagBpaSwi_PssSH2));
	memset(&m_BpaSwi_PssSIBuffer	, 0, sizeof(tagBpaSwi_PssSI	));
	memset(&m_BpaSwi_PssSABuffer	, 0, sizeof(tagBpaSwi_PssSA	));
	memset(&m_BpaSwi_PssSBBuffer	, 0, sizeof(tagBpaSwi_PssSB	));
	memset(&m_BpaSwi_PssSTBuffer	, 0, sizeof(tagBpaSwi_PssST	));

	memset(&m_BpaSwi_GGBuffer		, 0, sizeof(tagBpaSwi_GovGG	));
	memset(&m_BpaSwi_GHBuffer		, 0, sizeof(tagBpaSwi_GovGH	));
	memset(&m_BpaSwi_GCBuffer		, 0, sizeof(tagBpaSwi_GovGC	));
	memset(&m_BpaSwi_GSBuffer		, 0, sizeof(tagBpaSwi_GovGS	));
	memset(&m_BpaSwi_GLBuffer		, 0, sizeof(tagBpaSwi_GovGL	));
	memset(&m_BpaSwi_GWBuffer		, 0, sizeof(tagBpaSwi_GovGW	));
	memset(&m_BpaSwi_GABuffer		, 0, sizeof(tagBpaSwi_GovGA	));
	memset(&m_BpaSwi_GIBuffer		, 0, sizeof(tagBpaSwi_GovGI	));
	memset(&m_BpaSwi_GJBuffer		, 0, sizeof(tagBpaSwi_GovGJ	));
	memset(&m_BpaSwi_GKBuffer		, 0, sizeof(tagBpaSwi_GovGK	));
	memset(&m_BpaSwi_GMBuffer		, 0, sizeof(tagBpaSwi_GovGM	));
	memset(&m_BpaSwi_GDBuffer		, 0, sizeof(tagBpaSwi_GovGD	));
	memset(&m_BpaSwi_GZBuffer		, 0, sizeof(tagBpaSwi_GovGZ	));

	memset(&m_BpaSwi_TABuffer		, 0, sizeof(tagBpaSwi_MovTA	));
	memset(&m_BpaSwi_TBBuffer		, 0, sizeof(tagBpaSwi_MovTB	));
	memset(&m_BpaSwi_TCBuffer		, 0, sizeof(tagBpaSwi_MovTC	));
	memset(&m_BpaSwi_TDBuffer		, 0, sizeof(tagBpaSwi_MovTD	));
	memset(&m_BpaSwi_TEBuffer		, 0, sizeof(tagBpaSwi_MovTE	));
	memset(&m_BpaSwi_TFBuffer		, 0, sizeof(tagBpaSwi_MovTF	));
	memset(&m_BpaSwi_TWBuffer		, 0, sizeof(tagBpaSwi_MovTW	));
}

void CBpaGenModelApi::Mdb2ModelBuffer(tagBpaBlock* pBpaBlock, const char* lpszBus, const char* lpszVolt, const char* lpszID)
{
	ClearModel();

	// 	char	szName[MDB_CHARLEN], szVolt[MDB_CHARLEN], szID[MDB_CHARLEN];
	// 	if (m_nCurBpaGen < 0 || m_nCurBpaGen >= m_wndRefGenList.GetItemCount())
	// 		return;
	// 
	// 	wcstombs(szName, m_wndRefGenList.GetItemText(m_nCurBpaGen, 0), MDB_CHARLEN);
	// 	wcstombs(szVolt, m_wndRefGenList.GetItemText(m_nCurBpaGen, 1), MDB_CHARLEN);
	// 	wcstombs(szID, m_wndRefGenList.GetItemText(m_nCurBpaGen, 2), MDB_CHARLEN);

	m_BpaMemDBInterface.BpaResolveGenModel(pBpaBlock, lpszBus, (float)atof(lpszVolt), lpszID[0], 
		m_nGenIndex, m_nDampIndex, m_nExcModel, m_nExcIndex, m_nPssModel, m_nPssIndex, 
		m_nGovModel, m_nGovIndex, m_nSvoIndex, m_nMovModel, m_nMovIndex);

	if (m_nGenIndex >= 0)
		memcpy(&m_BpaSwi_GenBuffer, &pBpaBlock->m_BpaSwi_GenArray[m_nGenIndex], sizeof(tagBpaSwi_Gen));
	if (m_nDampIndex >= 0)
		memcpy(&pBpaBlock->m_BpaSwi_DampArray[m_nDampIndex], &m_BpaSwi_GenBuffer, sizeof(tagBpaSwi_Damp));

	if (m_nExcIndex >= 0)
	{
		switch (m_nExcModel)
		{
		case BPA_SWI_EXCIT68:	memcpy(&m_BpaSwi_Exc68Buffer,	&pBpaBlock->m_BpaSwi_Exc68Array[m_nExcIndex],	sizeof(tagBpaSwi_Exc68));	break;
		case BPA_SWI_EXCIT81:	memcpy(&m_BpaSwi_Exc81Buffer,	&pBpaBlock->m_BpaSwi_Exc81Array[m_nExcIndex],	sizeof(tagBpaSwi_Exc81));	break;
		case BPA_SWI_EXCITMV:	memcpy(&m_BpaSwi_ExcMVBuffer,	&pBpaBlock->m_BpaSwi_ExcMVArray[m_nExcIndex],	sizeof(tagBpaSwi_ExcMV));	break;
		case BPA_SWI_EXCITX:	memcpy(&m_BpaSwi_ExcXBuffer,	&pBpaBlock->m_BpaSwi_ExcXArray[m_nExcIndex],	sizeof(tagBpaSwi_ExcX));	break;
		}
	}

	if (m_nPssIndex >= 0)
	{
		switch (m_nPssModel)
		{
		case BPA_SWI_PSSS:		memcpy(&m_BpaSwi_PssSBuffer,	&pBpaBlock->m_BpaSwi_PssSArray[m_nPssIndex],	sizeof(tagBpaSwi_PssS));	break;
		case BPA_SWI_PSSSH	:	memcpy(&m_BpaSwi_PssSHBuffer,	&pBpaBlock->m_BpaSwi_PssSHArray[m_nPssIndex],	sizeof(tagBpaSwi_PssSH));	break;
// 		case BPA_SWI_PSSSH1:	memcpy(&m_BpaSwi_PssSH1Buffer,	&pBpaBlock->m_BpaSwi_PssSH1Array[m_nPssIndex], sizeof(tagBpaSwi_PssSH1));	break;
// 		case BPA_SWI_PSSSH2:	memcpy(&m_BpaSwi_PssSH2Buffer,	&pBpaBlock->m_BpaSwi_PssSH2Array[m_nPssIndex], sizeof(tagBpaSwi_PssSH2));	break;
		case BPA_SWI_PSSSI:		memcpy(&m_BpaSwi_PssSIBuffer,	&pBpaBlock->m_BpaSwi_PssSIArray[m_nPssIndex],	sizeof(tagBpaSwi_PssSI));	break;
		case BPA_SWI_PSSSA:		memcpy(&m_BpaSwi_PssSABuffer,	&pBpaBlock->m_BpaSwi_PssSAArray[m_nPssIndex],	sizeof(tagBpaSwi_PssSA));	break;
		case BPA_SWI_PSSSB:		memcpy(&m_BpaSwi_PssSBBuffer,	&pBpaBlock->m_BpaSwi_PssSBArray[m_nPssIndex],	sizeof(tagBpaSwi_PssSB));	break;
		case BPA_SWI_PSSST:		memcpy(&m_BpaSwi_PssSTBuffer,	&pBpaBlock->m_BpaSwi_PssSTArray[m_nPssIndex],	sizeof(tagBpaSwi_PssST));	break;
		}
	}

	if (m_nGovIndex >= 0)
	{
		switch (m_nGovModel)
		{
		case BPA_SWI_GG:	memcpy(&m_BpaSwi_GGBuffer,	&pBpaBlock->m_BpaSwi_GGArray[m_nGovIndex], sizeof(tagBpaSwi_GovGG));	break;
		case BPA_SWI_GH:	memcpy(&m_BpaSwi_GHBuffer,	&pBpaBlock->m_BpaSwi_GHArray[m_nGovIndex], sizeof(tagBpaSwi_GovGH));	break;
		case BPA_SWI_GC:	memcpy(&m_BpaSwi_GCBuffer,	&pBpaBlock->m_BpaSwi_GCArray[m_nGovIndex], sizeof(tagBpaSwi_GovGC));	break;
		case BPA_SWI_GS:	memcpy(&m_BpaSwi_GSBuffer,	&pBpaBlock->m_BpaSwi_GSArray[m_nGovIndex], sizeof(tagBpaSwi_GovGS));	break;
		case BPA_SWI_GL:	memcpy(&m_BpaSwi_GLBuffer,	&pBpaBlock->m_BpaSwi_GLArray[m_nGovIndex], sizeof(tagBpaSwi_GovGL));	break;
		case BPA_SWI_GW:	memcpy(&m_BpaSwi_GWBuffer,	&pBpaBlock->m_BpaSwi_GWArray[m_nGovIndex], sizeof(tagBpaSwi_GovGW));	break;
		case BPA_SWI_GI:	memcpy(&m_BpaSwi_GIBuffer,	&pBpaBlock->m_BpaSwi_GIArray[m_nGovIndex], sizeof(tagBpaSwi_GovGI));	break;
		case BPA_SWI_GJ:	memcpy(&m_BpaSwi_GJBuffer,	&pBpaBlock->m_BpaSwi_GJArray[m_nGovIndex], sizeof(tagBpaSwi_GovGJ));	break;
		case BPA_SWI_GK:	memcpy(&m_BpaSwi_GKBuffer,	&pBpaBlock->m_BpaSwi_GKArray[m_nGovIndex], sizeof(tagBpaSwi_GovGK));	break;
		case BPA_SWI_GM:	memcpy(&m_BpaSwi_GMBuffer,	&pBpaBlock->m_BpaSwi_GMArray[m_nGovIndex], sizeof(tagBpaSwi_GovGM));	break;
		case BPA_SWI_GD:	memcpy(&m_BpaSwi_GDBuffer,	&pBpaBlock->m_BpaSwi_GDArray[m_nGovIndex], sizeof(tagBpaSwi_GovGD));	break;
		case BPA_SWI_GZ:	memcpy(&m_BpaSwi_GZBuffer,	&pBpaBlock->m_BpaSwi_GZArray[m_nGovIndex], sizeof(tagBpaSwi_GovGZ));	break;
		}
	}

	if (m_nSvoIndex >= 0)
		memcpy(&m_BpaSwi_GABuffer, &pBpaBlock->m_BpaSwi_GAArray[m_nSvoIndex], sizeof(tagBpaSwi_GovGA));

	if (m_nMovIndex >= 0)
	{
		switch (m_nMovModel)
		{
		case BPA_SWI_TA:	memcpy(&m_BpaSwi_TABuffer,	&pBpaBlock->m_BpaSwi_TAArray[m_nMovIndex], sizeof(tagBpaSwi_MovTA));	break;
		case BPA_SWI_TB:	memcpy(&m_BpaSwi_TBBuffer,	&pBpaBlock->m_BpaSwi_TBArray[m_nMovIndex], sizeof(tagBpaSwi_MovTB));	break;
		case BPA_SWI_TC:	memcpy(&m_BpaSwi_TCBuffer,	&pBpaBlock->m_BpaSwi_TCArray[m_nMovIndex], sizeof(tagBpaSwi_MovTC));	break;
		case BPA_SWI_TD:	memcpy(&m_BpaSwi_TDBuffer,	&pBpaBlock->m_BpaSwi_TDArray[m_nMovIndex], sizeof(tagBpaSwi_MovTD));	break;
		case BPA_SWI_TE:	memcpy(&m_BpaSwi_TEBuffer,	&pBpaBlock->m_BpaSwi_TEArray[m_nMovIndex], sizeof(tagBpaSwi_MovTE));	break;
		case BPA_SWI_TF:	memcpy(&m_BpaSwi_TFBuffer,	&pBpaBlock->m_BpaSwi_TFArray[m_nMovIndex], sizeof(tagBpaSwi_MovTF));	break;
		case BPA_SWI_TW:	memcpy(&m_BpaSwi_TWBuffer,	&pBpaBlock->m_BpaSwi_TWArray[m_nMovIndex], sizeof(tagBpaSwi_MovTW));	break;
		}
	}
}

void CBpaGenModelApi::ModelBuffer2Mdb(tagBpaBlock* pBpaBlock, const char* lpszBus, const char* lpszVolt, const char* lpszID)
{
	// 	char	szName[32], szVolt[16], szID[16];
	// 	if (m_nCurBpaGen < 0 || m_nCurBpaGen >= m_wndRefGenList.GetItemCount())
	// 		return;
	// 
	// 	wcstombs(szName, m_wndRefGenList.GetItemText(m_nCurBpaGen, 0), MDB_CHARLEN);
	// 	wcstombs(szVolt, m_wndRefGenList.GetItemText(m_nCurBpaGen, 1), MDB_CHARLEN);
	// 	wcstombs(szID, m_wndRefGenList.GetItemText(m_nCurBpaGen, 2), MDB_CHARLEN);
	m_BpaMemDBInterface.BpaResolveGenModel(pBpaBlock, lpszBus, (float)atof(lpszVolt), lpszID[0], 
		m_nGenIndex, m_nDampIndex, m_nExcModel, m_nExcIndex, m_nPssModel, m_nPssIndex, m_nGovModel, m_nGovIndex, m_nSvoIndex, m_nMovModel, m_nMovIndex);

	if (m_nGenIndex < 0)
		return;

	memcpy(&pBpaBlock->m_BpaSwi_GenArray[m_nGenIndex], &m_BpaSwi_GenBuffer, sizeof(tagBpaSwi_Gen));
	if (m_nDampIndex >= 0)
		memcpy(&pBpaBlock->m_BpaSwi_DampArray[m_nDampIndex], &m_BpaSwi_GenBuffer, sizeof(tagBpaSwi_Damp));

	if (m_nExcIndex >= 0)
	{
		switch (m_nExcModel)
		{
		case BPA_SWI_EXCIT68:	memcpy(&pBpaBlock->m_BpaSwi_Exc68Array[m_nExcIndex],	&m_BpaSwi_Exc68Buffer,	sizeof(tagBpaSwi_Exc68));	break;
		case BPA_SWI_EXCIT81:	memcpy(&pBpaBlock->m_BpaSwi_Exc81Array[m_nExcIndex],	&m_BpaSwi_Exc81Buffer,	sizeof(tagBpaSwi_Exc81));	break;
		case BPA_SWI_EXCITMV:	memcpy(&pBpaBlock->m_BpaSwi_ExcMVArray[m_nExcIndex],	&m_BpaSwi_ExcMVBuffer,	sizeof(tagBpaSwi_ExcMV));	break;
		case BPA_SWI_EXCITX:	memcpy(&pBpaBlock->m_BpaSwi_ExcXArray[m_nExcIndex],		&m_BpaSwi_ExcXBuffer,	sizeof(tagBpaSwi_ExcX));	break;
		}
	}

	if (m_nPssIndex >= 0)
	{
		switch (m_nPssModel)
		{
		case BPA_SWI_PSSS:		memcpy(&pBpaBlock->m_BpaSwi_PssSArray[m_nPssIndex],		&m_BpaSwi_PssSBuffer,	sizeof(tagBpaSwi_PssS));	break;
		case BPA_SWI_PSSSH:		memcpy(&pBpaBlock->m_BpaSwi_PssSHArray[m_nPssIndex],	&m_BpaSwi_PssSHBuffer,	sizeof(tagBpaSwi_PssSH));	break;
// 		case BPA_SWI_PSSSH1:	memcpy(&pBpaBlock->m_BpaSwi_PssSH1Array[m_nPssIndex],	&m_BpaSwi_PssSH1Buffer,	sizeof(tagBpaSwi_PssSH1));	break;
// 		case BPA_SWI_PSSSH2:	memcpy(&pBpaBlock->m_BpaSwi_PssSH2Array[m_nPssIndex],	&m_BpaSwi_PssSH2Buffer,	sizeof(tagBpaSwi_PssSH2));	break;
		case BPA_SWI_PSSSI:		memcpy(&pBpaBlock->m_BpaSwi_PssSIArray[m_nPssIndex],	&m_BpaSwi_PssSIBuffer,	sizeof(tagBpaSwi_PssSI));	break;
		case BPA_SWI_PSSSA:		memcpy(&pBpaBlock->m_BpaSwi_PssSAArray[m_nPssIndex],	&m_BpaSwi_PssSABuffer,	sizeof(tagBpaSwi_PssSA));	break;
		case BPA_SWI_PSSSB:		memcpy(&pBpaBlock->m_BpaSwi_PssSBArray[m_nPssIndex],	&m_BpaSwi_PssSBBuffer,	sizeof(tagBpaSwi_PssSB));	break;
		case BPA_SWI_PSSST:		memcpy(&pBpaBlock->m_BpaSwi_PssSTArray[m_nPssIndex],	&m_BpaSwi_PssSTBuffer,	sizeof(tagBpaSwi_PssST));	break;
		}
	}

	if (m_nGovIndex >= 0)
	{
		switch (m_nGovModel)
		{
		case BPA_SWI_GG:	memcpy(&pBpaBlock->m_BpaSwi_GGArray[m_nGovIndex], &m_BpaSwi_GGBuffer,	sizeof(tagBpaSwi_GovGG));	break;
		case BPA_SWI_GH:	memcpy(&pBpaBlock->m_BpaSwi_GHArray[m_nGovIndex], &m_BpaSwi_GHBuffer,	sizeof(tagBpaSwi_GovGH));	break;
		case BPA_SWI_GC:	memcpy(&pBpaBlock->m_BpaSwi_GCArray[m_nGovIndex], &m_BpaSwi_GCBuffer,	sizeof(tagBpaSwi_GovGC));	break;
		case BPA_SWI_GS:	memcpy(&pBpaBlock->m_BpaSwi_GSArray[m_nGovIndex], &m_BpaSwi_GSBuffer,	sizeof(tagBpaSwi_GovGS));	break;
		case BPA_SWI_GL:	memcpy(&pBpaBlock->m_BpaSwi_GLArray[m_nGovIndex], &m_BpaSwi_GLBuffer,	sizeof(tagBpaSwi_GovGL));	break;
		case BPA_SWI_GW:	memcpy(&pBpaBlock->m_BpaSwi_GWArray[m_nGovIndex], &m_BpaSwi_GWBuffer,	sizeof(tagBpaSwi_GovGW));	break;
		case BPA_SWI_GI:	memcpy(&pBpaBlock->m_BpaSwi_GIArray[m_nGovIndex], &m_BpaSwi_GIBuffer,	sizeof(tagBpaSwi_GovGI));	break;
		case BPA_SWI_GJ:	memcpy(&pBpaBlock->m_BpaSwi_GJArray[m_nGovIndex], &m_BpaSwi_GJBuffer,	sizeof(tagBpaSwi_GovGJ));	break;
		case BPA_SWI_GK:	memcpy(&pBpaBlock->m_BpaSwi_GKArray[m_nGovIndex], &m_BpaSwi_GKBuffer,	sizeof(tagBpaSwi_GovGK));	break;
		case BPA_SWI_GM:	memcpy(&pBpaBlock->m_BpaSwi_GMArray[m_nGovIndex], &m_BpaSwi_GMBuffer,	sizeof(tagBpaSwi_GovGM));	break;
		case BPA_SWI_GD:	memcpy(&pBpaBlock->m_BpaSwi_GDArray[m_nGovIndex], &m_BpaSwi_GDBuffer,	sizeof(tagBpaSwi_GovGD));	break;
		case BPA_SWI_GZ:	memcpy(&pBpaBlock->m_BpaSwi_GZArray[m_nGovIndex], &m_BpaSwi_GZBuffer,	sizeof(tagBpaSwi_GovGZ));	break;
		}
	}

	if (m_nSvoIndex >= 0)
		memcpy(&pBpaBlock->m_BpaSwi_GAArray[m_nSvoIndex], &m_BpaSwi_GABuffer, sizeof(tagBpaSwi_GovGA));

	if (m_nMovIndex >= 0)
	{
		switch (m_nMovModel)
		{
		case BPA_SWI_TA:	memcpy(&pBpaBlock->m_BpaSwi_TAArray[m_nMovIndex], &m_BpaSwi_TABuffer,	sizeof(tagBpaSwi_MovTA));	break;
		case BPA_SWI_TB:	memcpy(&pBpaBlock->m_BpaSwi_TBArray[m_nMovIndex], &m_BpaSwi_TBBuffer,	sizeof(tagBpaSwi_MovTB));	break;
		case BPA_SWI_TC:	memcpy(&pBpaBlock->m_BpaSwi_TCArray[m_nMovIndex], &m_BpaSwi_TCBuffer,	sizeof(tagBpaSwi_MovTC));	break;
		case BPA_SWI_TD:	memcpy(&pBpaBlock->m_BpaSwi_TDArray[m_nMovIndex], &m_BpaSwi_TDBuffer,	sizeof(tagBpaSwi_MovTD));	break;
		case BPA_SWI_TE:	memcpy(&pBpaBlock->m_BpaSwi_TEArray[m_nMovIndex], &m_BpaSwi_TEBuffer,	sizeof(tagBpaSwi_MovTE));	break;
		case BPA_SWI_TF:	memcpy(&pBpaBlock->m_BpaSwi_TFArray[m_nMovIndex], &m_BpaSwi_TFBuffer,	sizeof(tagBpaSwi_MovTF));	break;
		case BPA_SWI_TW:	memcpy(&pBpaBlock->m_BpaSwi_TWArray[m_nMovIndex], &m_BpaSwi_TWBuffer,	sizeof(tagBpaSwi_MovTW));	break;
		}
	}
}
