#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"
#include "../../../Common/TinyXML/tinyxml.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

int		CPG2BpaFileApi::LoadPGSetting(tagPGBlock* pPGBlock, const char* lpszFileName)
{
	TiXmlDocument doc(lpszFileName);
	if (!doc.LoadFile())
		return 0;

	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "PG2BPA_SWSetting") != 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "����ָ���ļ���PG2BPA_SWSetting��\n");
		doc.Clear();
		return 0;
	}

	LoadPGSWModel(pPGBlock, pRoot);
	LoadSysParamFile(pRoot);
	LoadMonFile(pRoot);
	LoadFltFile(pRoot);

	doc.Clear();

	return 1;
}

void CPG2BpaFileApi::SavePGSetting(tagPGBlock* pPGBlock, const char* lpszFileName)
{
	TiXmlDocument*		pDocument = new TiXmlDocument();						//����һ��XML���ĵ�����
	pDocument->LinkEndChild(new TiXmlDeclaration("1.0", "gb2312", "no"));
	TiXmlElement*		pRootElement = new TiXmlElement("PG2BPA_SWSetting");	//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	SavePGSWModel(pPGBlock, pRootElement);
	SaveSysParamFile(pRootElement);
	SaveMonFile(pRootElement);
	SaveFltFile(pRootElement);

	pDocument->SaveFile(lpszFileName);					//���浽�ļ�
	pDocument->Clear();
	delete pDocument;
}

int	CPG2BpaFileApi::LoadPGSWModel(tagPGBlock* pPGBlock, TiXmlElement* pRootElement)
{
	register int	i;
	std::vector<std::string>	strValArray;

	TiXmlAttribute*	pAttr;
	TiXmlElement*	pLine;
	TiXmlElement*	pModel;
	TiXmlNode*		pNode;

	std::vector<std::string>	strEleArray;

	pLine = pRootElement->FirstChildElement();
	while (pLine != NULL)
	{
		//Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", pLine->Value());

		if (stricmp(pLine->Value(), "GenModel") == 0)
		{
			strValArray.resize(5);
			for (i=0; i<(int)strValArray.size(); i++)
				strValArray[i].clear();

			pModel=pLine->FirstChildElement();
			while (pModel != NULL)
			{
				pAttr = pModel->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Sub", pAttr->Name()) == 0)				strValArray[0]=pAttr->Value();
					else if (stricmp("Volt", pAttr->Name()) == 0)		strValArray[1]=pAttr->Value();
					else if (stricmp("Name", pAttr->Name()) == 0)		strValArray[2]=pAttr->Value();
					else if (stricmp("BpaBus", pAttr->Name()) == 0)		strValArray[3]=pAttr->Value();
					else if (stricmp("BpaVolt", pAttr->Name()) == 0)	strValArray[4]=pAttr->Value();
					pAttr=pAttr->Next();
				}

				//Log(g_lpszPG2BpaApiLogFile, "����� : %s %s %s %s %s\n", strValArray[0].c_str(), strValArray[1].c_str(), strValArray[2].c_str(), strValArray[3].c_str(), strValArray[4].c_str());
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
				{
					if (stricmp(pPGBlock->m_SynchronousMachineArray[i].szSub, strValArray[0].c_str()) == 0 &&
						stricmp(pPGBlock->m_SynchronousMachineArray[i].szVolt, strValArray[1].c_str()) == 0 &&
						stricmp(pPGBlock->m_SynchronousMachineArray[i].szName, strValArray[2].c_str()) == 0)
					{
						strcpy(pPGBlock->m_SynchronousMachineArray[i].szBpaGenBus, strValArray[3].c_str());
						pPGBlock->m_SynchronousMachineArray[i].fBpaGenVolt=(float)atof(strValArray[4].c_str());
						break;
					}
				}

				pModel=pModel->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "TranXO") == 0)
		{
			strValArray.resize(5);
			for (i=0; i<(int)strValArray.size(); i++)
				strValArray[i].clear();

			pModel=pLine->FirstChildElement();
			while (pModel != NULL)
			{
				pAttr = pModel->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Sub", pAttr->Name()) == 0)				strValArray[0]=pAttr->Value();
					else if (stricmp("Name", pAttr->Name()) == 0)		strValArray[1]=pAttr->Value();
					else if (stricmp("Neutral", pAttr->Name()) == 0)	strValArray[2]=pAttr->Value();
					else if (stricmp("R0", pAttr->Name()) == 0)			strValArray[3]=pAttr->Value();
					else if (stricmp("X0", pAttr->Name()) == 0)			strValArray[4]=pAttr->Value();
					pAttr=pAttr->Next();
				}
				//Log(g_lpszPG2BpaApiLogFile, "��ѹ�� : %s %s %s %s %s\n", strValArray[0].c_str(), strValArray[1].c_str(), strValArray[2].c_str(), strValArray[3].c_str(), strValArray[4].c_str());
				for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
				{
					if (stricmp(pPGBlock->m_TransformerWindingArray[i].szSub, strValArray[0].c_str()) == 0 &&
						stricmp(pPGBlock->m_TransformerWindingArray[i].szName, strValArray[1].c_str()) == 0)
					{
						pPGBlock->m_TransformerWindingArray[i].bNeutralStatus=atoi(strValArray[2].c_str());
						pPGBlock->m_TransformerWindingArray[i].fR0=(float)atof(strValArray[3].c_str());
						pPGBlock->m_TransformerWindingArray[i].fX0=(float)atof(strValArray[4].c_str());
						break;
					}
				}

				pModel=pModel->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "LineXO") == 0)
		{
			strValArray.resize(3);
			for (i=0; i<(int)strValArray.size(); i++)
				strValArray[i].clear();

			pModel=pLine->FirstChildElement();
			while (pModel != NULL)
			{
				pAttr = pModel->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Name", pAttr->Name()) == 0)		strValArray[0]=pAttr->Value();
					else if (stricmp("R0", pAttr->Name()) == 0)		strValArray[1]=pAttr->Value();
					else if (stricmp("X0", pAttr->Name()) == 0)		strValArray[2]=pAttr->Value();
					pAttr=pAttr->Next();
				}
				//Log(g_lpszPG2BpaApiLogFile, "��· : %s %s %s\n", strValArray[0].c_str(), strValArray[1].c_str(), strValArray[2].c_str());
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, strValArray[0].c_str()) == 0)
					{
						pPGBlock->m_ACLineSegmentArray[i].fR0=(float)atof(strValArray[1].c_str());
						pPGBlock->m_ACLineSegmentArray[i].fX0=(float)atof(strValArray[2].c_str());
						break;
					}
				}

				pModel=pModel->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "LoadModel") == 0)
		{
			strValArray.resize(14);
			for (i=0; i<(int)strValArray.size(); i++)
				strValArray[i].clear();

			pModel=pLine->FirstChildElement();
			while (pModel != NULL)
			{
				pAttr = pModel->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Sub", pAttr->Name()) == 0)			strValArray[0]=pAttr->Value();
					else if (stricmp("Volt", pAttr->Name()) == 0)	strValArray[1]=pAttr->Value();
					else if (stricmp("Name", pAttr->Name()) == 0)	strValArray[2]=pAttr->Value();
					else if (stricmp("Model", pAttr->Name()) == 0)	strValArray[3]=pAttr->Value();
					else if (stricmp("Tj", pAttr->Name()) == 0)		strValArray[4]=pAttr->Value();
					else if (stricmp("Pper", pAttr->Name()) == 0)	strValArray[5]=pAttr->Value();
					else if (stricmp("Kl", pAttr->Name()) == 0)		strValArray[6]=pAttr->Value();
					else if (stricmp("Rs", pAttr->Name()) == 0)		strValArray[7]=pAttr->Value();
					else if (stricmp("Xs", pAttr->Name()) == 0)		strValArray[8]=pAttr->Value();
					else if (stricmp("Xm", pAttr->Name()) == 0)		strValArray[9]=pAttr->Value();
					else if (stricmp("Rr", pAttr->Name()) == 0)		strValArray[10]=pAttr->Value();
					else if (stricmp("Xr", pAttr->Name()) == 0)		strValArray[11]=pAttr->Value();
					else if (stricmp("A", pAttr->Name()) == 0)		strValArray[12]=pAttr->Value();
					else if (stricmp("B", pAttr->Name()) == 0)		strValArray[13]=pAttr->Value();
					pAttr=pAttr->Next();
				}
				//Log(g_lpszPG2BpaApiLogFile, "���� : %s %s %s\n", strValArray[0].c_str(), strValArray[1].c_str(), strValArray[2].c_str());
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
				{
					if (stricmp(pPGBlock->m_EnergyConsumerArray[i].szSub, strValArray[0].c_str()) == 0 &&
						stricmp(pPGBlock->m_EnergyConsumerArray[i].szVolt, strValArray[1].c_str()) == 0 &&
						stricmp(pPGBlock->m_EnergyConsumerArray[i].szName, strValArray[2].c_str()) == 0)
					{
						strcpy(pPGBlock->m_EnergyConsumerArray[i].szSModel, strValArray[3].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorTj=(float)atof(strValArray[4].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorPper=(float)atof(strValArray[5].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorKl=(float)atof(strValArray[6].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorRs=(float)atof(strValArray[7].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorXs=(float)atof(strValArray[8].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorXm=(float)atof(strValArray[9].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorRr=(float)atof(strValArray[10].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorXr=(float)atof(strValArray[11].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorA=(float)atof(strValArray[12].c_str());
						pPGBlock->m_EnergyConsumerArray[i].fMotorB=(float)atof(strValArray[13].c_str());
						break;
					}
				}

				pModel=pModel->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "SysLoadModel") == 0)
		{
			char	szModel[MDB_CHARLEN];
			memset(szModel, 0, MDB_CHARLEN);

			pNode = pLine->FirstChild();
			if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
			{
				Log(g_lpszPG2BpaApiLogFile, "SysLoadModel=%s\n", pNode->Value());
				strcpy(szModel, pNode->Value());
			}
		}

		pLine = pLine->NextSiblingElement();
	}

	return 1;
}

void CPG2BpaFileApi::SavePGSWModel(tagPGBlock* pPGBlock, TiXmlElement* pRootElement)
{
	register int	i;
	TiXmlElement	*pModelElement, *pElement;

	for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
	{
		pModelElement=new TiXmlElement("SysLoadModel");
		pModelElement->LinkEndChild(new TiXmlText(pPGBlock->m_SubcontrolAreaArray[i].szLoadModel));
		pRootElement->LinkEndChild(pModelElement);
	}

	pModelElement = new TiXmlElement("GenModel");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pModelElement);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
	{
		pElement = new TiXmlElement("Gen");			//����һ����Ԫ�ز����ӡ�
		pModelElement->LinkEndChild(pElement);
		pElement->SetAttribute("Sub",			pPGBlock->m_SynchronousMachineArray[i].szName);
		pElement->SetAttribute("Volt",			pPGBlock->m_SynchronousMachineArray[i].szVolt);
		pElement->SetAttribute("Name",			pPGBlock->m_SynchronousMachineArray[i].szName);
		pElement->SetAttribute("BpaBus",		pPGBlock->m_SynchronousMachineArray[i].szBpaGenBus);
		pElement->SetDoubleAttribute("BpaVolt",	(double)pPGBlock->m_SynchronousMachineArray[i].fBpaGenVolt);
	}

	pModelElement = new TiXmlElement("TranXO");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pModelElement);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		pElement = new TiXmlElement("XO");			//����һ����Ԫ�ز����ӡ�
		pModelElement->LinkEndChild(pElement);
		pElement->SetAttribute("Sub",			pPGBlock->m_TransformerWindingArray[i].szSub);
		pElement->SetAttribute("Name",			pPGBlock->m_TransformerWindingArray[i].szName);
		pElement->SetAttribute("Neutral",		pPGBlock->m_TransformerWindingArray[i].bNeutralStatus);
		pElement->SetDoubleAttribute("R0",		(double)pPGBlock->m_TransformerWindingArray[i].fR0);
		pElement->SetDoubleAttribute("X0",		(double)pPGBlock->m_TransformerWindingArray[i].fX0);
	}

	pModelElement = new TiXmlElement("LineXO");				//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pModelElement);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		pElement = new TiXmlElement("XO");				//����һ����Ԫ�ز����ӡ�
		pModelElement->LinkEndChild(pElement);
		pElement->SetAttribute("Name",			pPGBlock->m_ACLineSegmentArray[i].szName);
		pElement->SetDoubleAttribute("R0",		(double)pPGBlock->m_ACLineSegmentArray[i].fR0);
		pElement->SetDoubleAttribute("X0",		(double)pPGBlock->m_ACLineSegmentArray[i].fX0);
	}

	pModelElement = new TiXmlElement("LoadModel");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pModelElement);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		pElement = new TiXmlElement("Model");			//����һ����Ԫ�ز����ӡ�
		pModelElement->LinkEndChild(pElement);

		pElement->SetAttribute("Sub",			pPGBlock->m_EnergyConsumerArray[i].szSub);
		pElement->SetAttribute("Volt",			pPGBlock->m_EnergyConsumerArray[i].szVolt);
		pElement->SetAttribute("Name",			pPGBlock->m_EnergyConsumerArray[i].szName);
		pElement->SetAttribute("Model",			pPGBlock->m_EnergyConsumerArray[i].szSModel);
		pElement->SetDoubleAttribute("Tj",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorTj);
		pElement->SetDoubleAttribute("Pper",	(double)pPGBlock->m_EnergyConsumerArray[i].fMotorPper);
		pElement->SetDoubleAttribute("Kl",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorKl);
		pElement->SetDoubleAttribute("Rs",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorRs);
		pElement->SetDoubleAttribute("Xs",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorXs);
		pElement->SetDoubleAttribute("Xm",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorXm);
		pElement->SetDoubleAttribute("Rr",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorRr);
		pElement->SetDoubleAttribute("Xr",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorXr);
		pElement->SetDoubleAttribute("A",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorA);
		pElement->SetDoubleAttribute("B",		(double)pPGBlock->m_EnergyConsumerArray[i].fMotorB);
	}
}

int CPG2BpaFileApi::LoadMonFile(TiXmlElement* pRootElement)
{
	TiXmlAttribute*	pAttr;
	TiXmlElement*	pLine;
	TiXmlElement*	pMon;

	memset(&m_ReferenceGen, 0, sizeof(tagBpaGenMonitor));
#ifdef PG2BPAAPI_USING_STL
	m_MonBusArray.clear();
	m_MonGenArray.clear();
	m_MonLineArray.clear();
	m_MonTranArray.clear();
#else
	m_nBpaBusMonNum=0;	
	m_nBpaGenMonNum=0;	
	m_nBpaLineMonNum=0;	
	m_nBpaTranMonNum=0;	
#endif

	// Traverse children of pRoot, populating the list of lines
	pLine = pRootElement->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), "BusMon") == 0)
		{
			tagBpaBusMonitor	monBuf;
			memset(&monBuf, 0, sizeof(tagBpaBusMonitor));

			pMon=pLine->FirstChildElement();
			while (pMon != NULL)
			{
				pAttr = pMon->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Sub", pAttr->Name()) == 0)				strcpy(monBuf.szDevSub, pAttr->Value());
					else if (stricmp("Volt", pAttr->Name()) == 0)		strcpy(monBuf.szDevVolt, pAttr->Value());
					else if (stricmp("Name", pAttr->Name()) == 0)		strcpy(monBuf.szDevName, pAttr->Value());
					else if (stricmp("V", pAttr->Name()) == 0)			monBuf.bMonV=atoi(pAttr->Value());
					else if (stricmp("D", pAttr->Name()) == 0)			monBuf.bMonD=atoi(pAttr->Value());
					else if (stricmp("F", pAttr->Name()) == 0)			monBuf.bMonF=atoi(pAttr->Value());
					else if (stricmp("P", pAttr->Name()) == 0)			monBuf.bMonP=atoi(pAttr->Value());
					else if (stricmp("Q", pAttr->Name()) == 0)			monBuf.bMonQ=atoi(pAttr->Value());
					pAttr=pAttr->Next();
				}
				AddBpaBusMonitor(monBuf);	//m_MonBusArray.push_back(monBuf);

				pMon=pMon->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "GenMon") == 0)
		{
			tagBpaGenMonitor	monBuf;
			memset(&monBuf, 0, sizeof(tagBpaGenMonitor));

			pAttr = pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp("RefGenSub", pAttr->Name()) == 0)			strcpy(m_ReferenceGen.szDevSub, pAttr->Value());
				else if (stricmp("RefGenVolt", pAttr->Name()) == 0)		strcpy(m_ReferenceGen.szDevVolt, pAttr->Value());
				else if (stricmp("RefGenName", pAttr->Name()) == 0)		strcpy(m_ReferenceGen.szDevName, pAttr->Value());
				pAttr=pAttr->Next();
			}

			pMon=pLine->FirstChildElement();
			while (pMon != NULL)
			{
				pAttr = pMon->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Sub", pAttr->Name()) == 0)				strcpy(monBuf.szDevSub, pAttr->Value());
					else if (stricmp("Volt", pAttr->Name()) == 0)		strcpy(monBuf.szDevVolt, pAttr->Value());
					else if (stricmp("Name", pAttr->Name()) == 0)		strcpy(monBuf.szDevName, pAttr->Value());
					else if (stricmp("D", pAttr->Name()) == 0)			monBuf.bMonD=atoi(pAttr->Value());		//	20, �Ƕ�
					else if (stricmp("S", pAttr->Name()) == 0)			monBuf.bMonS=atoi(pAttr->Value());		//	23, �ٶ�ƫ��
					else if (stricmp("EV", pAttr->Name()) == 0)			monBuf.bMonEV=atoi(pAttr->Value());		//	26, ���ŵ�ѹ
					else if (stricmp("TP", pAttr->Name()) == 0)			monBuf.bMonTP=atoi(pAttr->Value());		//	35, ��е����
					else if (stricmp("EP", pAttr->Name()) == 0)			monBuf.bMonEP=atoi(pAttr->Value());		//	38, ��Ź���
					else if (stricmp("Vd", pAttr->Name()) == 0)			monBuf.bMonVd=atoi(pAttr->Value());		//	44, ��ѹ��
					else if (stricmp("Acc", pAttr->Name()) == 0)		monBuf.bMonAcc=atoi(pAttr->Value());	//	47, ���ٹ���
					else if (stricmp("Q", pAttr->Name()) == 0)			monBuf.bMonQ=atoi(pAttr->Value());		//	50, �޹�����
					else if (stricmp("Damp", pAttr->Name()) == 0)		monBuf.bMonDamp=atoi(pAttr->Value());	//	56, ��������
					else if (stricmp("EA", pAttr->Name()) == 0)			monBuf.bMonEA=atoi(pAttr->Value());		//	59, ���ŵ���
					else if (stricmp("V", pAttr->Name()) == 0)			monBuf.bMonV=atoi(pAttr->Value());		//	+19, ���˵�ѹ
					else if (stricmp("A", pAttr->Name()) == 0)			monBuf.bMonA=atoi(pAttr->Value());		//	+20, ���˵���
					else if (stricmp("Eq", pAttr->Name()) == 0)			monBuf.bMonEq=atoi(pAttr->Value());		//	+23, Eq
					else if (stricmp("Edp", pAttr->Name()) == 0)		monBuf.bMonEdp=atoi(pAttr->Value());	//	+25, E'd
					else if (stricmp("Eqp", pAttr->Name()) == 0)		monBuf.bMonEqp=atoi(pAttr->Value());	//	+27, E'q
					else if (stricmp("Edpp", pAttr->Name()) == 0)		monBuf.bMonEdpp=atoi(pAttr->Value());	//	+29, E"d
					else if (stricmp("Eqpp", pAttr->Name()) == 0)		monBuf.bMonEqpp=atoi(pAttr->Value());	//	+31, E"q
					else if (stricmp("EqR", pAttr->Name()) == 0)		monBuf.bMonEqR=atoi(pAttr->Value());	//	+45, ��Ч����R
					else if (stricmp("EqX", pAttr->Name()) == 0)		monBuf.bMonEqX=atoi(pAttr->Value());	//	+47, ��Ч�翹X
					pAttr=pAttr->Next();
				}
				AddBpaGenMonitor(monBuf);	//m_MonGenArray.push_back(monBuf);

				pMon=pMon->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "LineMon") == 0)
		{
			tagBpaLineMonitor	monBuf;
			memset(&monBuf, 0, sizeof(tagBpaLineMonitor));

			pMon=pLine->FirstChildElement();
			while (pMon != NULL)
			{
				pAttr = pMon->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Name", pAttr->Name()) == 0)			strcpy(monBuf.szDevName, pAttr->Value());
					else if (stricmp("P", pAttr->Name()) == 0)			monBuf.bMonP=atoi(pAttr->Value());
					else if (stricmp("Q", pAttr->Name()) == 0)			monBuf.bMonQ=atoi(pAttr->Value());
					pAttr=pAttr->Next();
				}
				AddBpaLineMonitor(monBuf);	//m_MonLineArray.push_back(monBuf);

				pMon=pMon->NextSiblingElement();
			}
		}
		else if (stricmp(pLine->Value(), "TranMon") == 0)
		{
			tagBpaTranMonitor	monBuf;
			memset(&monBuf, 0, sizeof(tagBpaTranMonitor));

			pMon=pLine->FirstChildElement();
			while (pMon != NULL)
			{
				pAttr = pMon->FirstAttribute();
				while (pAttr != NULL)
				{
					if (stricmp("Sub", pAttr->Name()) == 0)				strcpy(monBuf.szDevSub, pAttr->Value());
					else if (stricmp("Name", pAttr->Name()) == 0)		strcpy(monBuf.szDevName, pAttr->Value());
					else if (stricmp("P", pAttr->Name()) == 0)			monBuf.bMonP=atoi(pAttr->Value());
					else if (stricmp("Q", pAttr->Name()) == 0)			monBuf.bMonQ=atoi(pAttr->Value());
					pAttr=pAttr->Next();
				}
				AddBpaTranMonitor(monBuf);	//m_MonTranArray.push_back(monBuf);

				pMon=pMon->NextSiblingElement();
			}
		}

		pLine = pLine->NextSiblingElement();
	}

	return 1;
}

void CPG2BpaFileApi::SaveMonFile(TiXmlElement* pRootElement)
{
	int		nItem;
	TiXmlElement		*pMonElement, *pElement;

	pMonElement = new TiXmlElement("BusMon");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pMonElement);
	for (nItem=0; nItem<GetBpaBusMonitorNum(); nItem++)
	{
		pElement = new TiXmlElement("Mon");			//����һ����Ԫ�ز����ӡ�
		pMonElement->LinkEndChild(pElement);

		pElement->SetAttribute("Sub",	m_MonBusArray[nItem].szDevSub);
		pElement->SetAttribute("Volt",	m_MonBusArray[nItem].szDevVolt);
		pElement->SetAttribute("Name",	m_MonBusArray[nItem].szDevName);
		pElement->SetAttribute("V",		m_MonBusArray[nItem].bMonV);
		pElement->SetAttribute("D",		m_MonBusArray[nItem].bMonD);
		pElement->SetAttribute("F",		m_MonBusArray[nItem].bMonF);
		pElement->SetAttribute("P",		m_MonBusArray[nItem].bMonP);
		pElement->SetAttribute("Q",		m_MonBusArray[nItem].bMonQ);
	}

	pMonElement = new TiXmlElement("GenMon");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pMonElement);
	pMonElement->SetAttribute("RefGenSub",	m_ReferenceGen.szDevSub);
	pMonElement->SetAttribute("RefGenVolt",	m_ReferenceGen.szDevVolt);
	pMonElement->SetAttribute("RefGenName",	m_ReferenceGen.szDevName);

	for (nItem=0; nItem<GetBpaGenMonitorNum(); nItem++)
	{
		pElement = new TiXmlElement("Mon");			//����һ����Ԫ�ز����ӡ�
		pMonElement->LinkEndChild(pElement);

		pElement->SetAttribute("Sub",	m_MonGenArray[nItem].szDevSub);
		pElement->SetAttribute("Volt",	m_MonGenArray[nItem].szDevVolt);
		pElement->SetAttribute("Name",	m_MonGenArray[nItem].szDevName);
		pElement->SetAttribute("D",		m_MonGenArray[nItem].bMonD);		//	20, �Ƕ�
		pElement->SetAttribute("S",		m_MonGenArray[nItem].bMonS);		//	23, �ٶ�ƫ��
		pElement->SetAttribute("EV",	m_MonGenArray[nItem].bMonEV);		//	26, ���ŵ�ѹ
		pElement->SetAttribute("TP",	m_MonGenArray[nItem].bMonTP);		//	35, ��е����
		pElement->SetAttribute("EP",	m_MonGenArray[nItem].bMonEP);		//	38, ��Ź���
		pElement->SetAttribute("Vd",	m_MonGenArray[nItem].bMonVd);		//	44, ��ѹ��
		pElement->SetAttribute("Acc",	m_MonGenArray[nItem].bMonAcc);		//	47, ���ٹ���
		pElement->SetAttribute("Q",		m_MonGenArray[nItem].bMonQ);		//	50, �޹�����
		pElement->SetAttribute("Damp",	m_MonGenArray[nItem].bMonDamp);		//	56, ��������
		pElement->SetAttribute("EA",	m_MonGenArray[nItem].bMonEA);		//	59, ���ŵ���
		pElement->SetAttribute("V",		m_MonGenArray[nItem].bMonV);		//	+19, ���˵�ѹ
		pElement->SetAttribute("A",		m_MonGenArray[nItem].bMonA);		//	+20, ���˵���
		pElement->SetAttribute("Eq",	m_MonGenArray[nItem].bMonEq);		//	+23, Eq
		pElement->SetAttribute("Edp",	m_MonGenArray[nItem].bMonEdp);		//	+25, E'd
		pElement->SetAttribute("Eqp",	m_MonGenArray[nItem].bMonEqp);		//	+27, E'q
		pElement->SetAttribute("Edpp",	m_MonGenArray[nItem].bMonEdpp);		//	+29, E"d
		pElement->SetAttribute("Eqpp",	m_MonGenArray[nItem].bMonEqpp);		//	+31, E"q
		pElement->SetAttribute("EqR",	m_MonGenArray[nItem].bMonEqR);		//	+45, ��Ч����R
		pElement->SetAttribute("EqX",	m_MonGenArray[nItem].bMonEqX);		//	+47, ��Ч�翹X
	}

	pMonElement = new TiXmlElement("LineMon");
	pRootElement->LinkEndChild(pMonElement);
	for (nItem=0; nItem<GetBpaLineMonitorNum(); nItem++)
	{
		pElement = new TiXmlElement("Mon");
		pMonElement->LinkEndChild(pElement);

		pElement->SetAttribute("Name",	m_MonLineArray[nItem].szDevName);
		pElement->SetAttribute("P",		m_MonLineArray[nItem].bMonP);
		pElement->SetAttribute("Q",		m_MonLineArray[nItem].bMonQ);
	}

	pMonElement = new TiXmlElement("TranMon");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pMonElement);
	for (nItem=0; nItem<GetBpaTranMonitorNum(); nItem++)
	{
		pElement = new TiXmlElement("Mon");
		pMonElement->LinkEndChild(pElement);

		pElement->SetAttribute("Sub",	m_MonTranArray[nItem].szDevSub);
		pElement->SetAttribute("Name",	m_MonTranArray[nItem].szDevName);
		pElement->SetAttribute("P",		m_MonTranArray[nItem].bMonP);
		pElement->SetAttribute("Q",		m_MonTranArray[nItem].bMonQ);
	}
}

int CPG2BpaFileApi::LoadSysParamFile(TiXmlElement* pRootElement)
{
	TiXmlAttribute*	pAttr;
	TiXmlElement*	pLine;
	int			nSet, nVal, nTim;

	tagBpaStaticLoadModel	mBuf;

#ifdef	PG2BPAAPI_USING_STL
	m_LoadSModelArray.clear();
#else
	m_nBpaLoadSModelNum=0;							
#endif
	memset(m_szDefaultLoadSModel, 0, MDB_CHARLEN);	
	memset(m_szUsingAutoUFModel, 0, MDB_CHARLEN);	
	memset(m_szUsingAutoUVModel, 0, MDB_CHARLEN);	

	memset(&m_SysUFSetting, 0, sizeof(tagBpaAutoLoadFV));
	memset(&m_SysUVSetting, 0, sizeof(tagBpaAutoLoadFV));

	// Traverse children of pRoot, populating the list of lines
	pLine = pRootElement->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(), "StaticLoadModel") == 0)
		{
			memset(&mBuf, 0, sizeof(tagBpaStaticLoadModel));

			pAttr = pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (strstr(pAttr->Name(), "Name") != NULL)				{	strcpy(mBuf.szName, pAttr->Value());		}
				else if (strstr(pAttr->Name(), "P1") != NULL)			{	mBuf.fP1	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "P2") != NULL)			{	mBuf.fP2	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "P3") != NULL)			{	mBuf.fP3	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "P5") != NULL)			{	mBuf.fP5	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "NP") != NULL)			{	mBuf.fNP	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "LDP") != NULL)			{	mBuf.fLDP	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Q1") != NULL)			{	mBuf.fQ1	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Q2") != NULL)			{	mBuf.fQ2	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Q3") != NULL)			{	mBuf.fQ3	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Q5") != NULL)			{	mBuf.fQ5	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "NQ") != NULL)			{	mBuf.fNQ	=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "LDQ") != NULL)			{	mBuf.fLDQ	=(float)atof(pAttr->Value());	}

				pAttr=pAttr->Next();
			}
			AddBpaStaticLoadModel(mBuf);	//m_LoadSModelArray.push_back(mBuf);
		}
		else if (stricmp(pLine->Value(), "SysStaticLoadModel") == 0)
		{
			pAttr = pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (strstr(pAttr->Name(), "Name") != NULL)				{	strcpy(m_szDefaultLoadSModel, pAttr->Value());	}
				pAttr=pAttr->Next();
			}
		}

		else if (stricmp(pLine->Value(), "SysUF") == 0)
		{
			nSet=nVal=nTim=0;
			pAttr = pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (strstr(pAttr->Name(), "Name") != NULL)			{	strcpy(m_szUsingAutoUFModel, pAttr->Value());				}
				else if (strstr(pAttr->Name(), "Tuning") != NULL)	{	m_SysUFSetting.fTuning[nSet++]=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Time") != NULL)		{	m_SysUFSetting.fDelay[nTim++]=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Shed") != NULL)		{	m_SysUFSetting.fShed[nVal++]=(float)atof(pAttr->Value());	}

				pAttr=pAttr->Next();
			}
		}
		else if (stricmp(pLine->Value(), "SysUV") == 0)
		{
			nSet=nVal=nTim=0;
			pAttr = pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (strstr(pAttr->Name(), "Name") != NULL)			{	strcpy(m_szUsingAutoUVModel, pAttr->Value());				}
				else if (strstr(pAttr->Name(), "Tuning") != NULL)	{	m_SysUVSetting.fTuning[nSet++]=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Time") != NULL)		{	m_SysUVSetting.fDelay[nTim++]=(float)atof(pAttr->Value());	}
				else if (strstr(pAttr->Name(), "Shed") != NULL)		{	m_SysUVSetting.fShed[nVal++]=(float)atof(pAttr->Value());	}

				pAttr=pAttr->Next();
			}
		}

		pLine = pLine->NextSiblingElement();
	}

	return 1;
}

void CPG2BpaFileApi::SaveSysParamFile(TiXmlElement* pRootElement)
{
	register int	i;
	TiXmlElement	*pElement;
	char			szAttrName[260];

	for (i=0; i<GetBpaStaticLoadModelNum(); i++)
	{
		pElement = new TiXmlElement("StaticLoadModel");			//����һ����Ԫ�ز����ӡ�
		pRootElement->LinkEndChild(pElement);

		pElement->SetAttribute("Name",		m_LoadSModelArray[i].szName);
		pElement->SetDoubleAttribute("P1" ,	m_LoadSModelArray[i].fP1);
		pElement->SetDoubleAttribute("P2" ,	m_LoadSModelArray[i].fP2);
		pElement->SetDoubleAttribute("P3" ,	m_LoadSModelArray[i].fP3);
		pElement->SetDoubleAttribute("P5" ,	m_LoadSModelArray[i].fP5);
		pElement->SetDoubleAttribute("NP" ,	m_LoadSModelArray[i].fNP);
		pElement->SetDoubleAttribute("LDP",	m_LoadSModelArray[i].fLDP);
		pElement->SetDoubleAttribute("Q1" ,	m_LoadSModelArray[i].fQ1);
		pElement->SetDoubleAttribute("Q2" ,	m_LoadSModelArray[i].fQ2);
		pElement->SetDoubleAttribute("Q3" ,	m_LoadSModelArray[i].fQ3);
		pElement->SetDoubleAttribute("Q5" ,	m_LoadSModelArray[i].fQ5);
		pElement->SetDoubleAttribute("NQ" ,	m_LoadSModelArray[i].fNQ);
		pElement->SetDoubleAttribute("LDQ",	m_LoadSModelArray[i].fLDQ);
	}

	pElement = new TiXmlElement("SysStaticLoadModel");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pElement);
	pElement->SetAttribute("Name",		m_szDefaultLoadSModel);

	pElement = new TiXmlElement("SysUF");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pElement);
	pElement->SetAttribute("Name",		m_szUsingAutoUFModel);
	for (i=0; i<g_nMaxUFUVRounds; i++)
	{
		Log(g_lpszPG2BpaApiLogFile, "Save SysUF[%d] = %f %f %f\n", i+1, m_SysUFSetting.fTuning[i], m_SysUFSetting.fDelay[i], m_SysUFSetting.fShed[i]);
		if (m_SysUFSetting.fTuning[i] < FLT_MIN || m_SysUFSetting.fShed[i] < FLT_MIN)
			continue;

		sprintf(szAttrName, "Tuning%d", i+1);	pElement->SetDoubleAttribute(szAttrName,	m_SysUFSetting.fTuning[i]);
		sprintf(szAttrName, "Time%d", i+1);		pElement->SetDoubleAttribute(szAttrName,	m_SysUFSetting.fDelay[i]);
		sprintf(szAttrName, "Shed%d", i+1);		pElement->SetDoubleAttribute(szAttrName,	m_SysUFSetting.fShed[i]);
	}

	pElement = new TiXmlElement("SysUV");			//����һ����Ԫ�ز����ӡ�
	pRootElement->LinkEndChild(pElement);
	pElement->SetAttribute("Name",		m_szUsingAutoUVModel);
	for (i=0; i<g_nMaxUFUVRounds; i++)
	{
		if (m_SysUVSetting.fTuning[i] < FLT_MIN || m_SysUVSetting.fShed[i] < FLT_MIN)
			continue;

		sprintf(szAttrName, "Tuning%d", i+1);	pElement->SetDoubleAttribute(szAttrName,	m_SysUVSetting.fTuning[i]);
		sprintf(szAttrName, "Time%d", i+1);		pElement->SetDoubleAttribute(szAttrName,	m_SysUVSetting.fDelay[i]);
		sprintf(szAttrName, "Shed%d", i+1);		pElement->SetDoubleAttribute(szAttrName,	m_SysUVSetting.fShed[i]);
	}
}

int CPG2BpaFileApi::LoadFltFile(TiXmlElement* pRootElement)
{
	TiXmlAttribute*	pAttr;
	TiXmlElement*	pLine;

#ifdef PG2BPAAPI_USING_STL
	m_FltDefArray.clear();
#else
	m_nFaultNum=0;
#endif

	tagBpaFltDefine	fltBuf;
	// Traverse children of pRoot, populating the list of lines
	pLine = pRootElement->FirstChildElement();
	while (pLine != NULL)
	{
		if (strstr(pLine->Value(), "Fault") != NULL)
		{
			memset(&fltBuf, 0, sizeof(tagBpaFltDefine));
			pAttr = pLine->FirstAttribute();
			while (pAttr != NULL)
			{
				if (stricmp("DevType", pAttr->Name()) == 0)				fltBuf.nDevType=atoi(pAttr->Value());
				else if (stricmp("DevSub", pAttr->Name()) == 0)			strcpy(fltBuf.szDevSub, pAttr->Value());
				else if (stricmp("DevVolt", pAttr->Name()) == 0)		strcpy(fltBuf.szDevVolt, pAttr->Value());
				else if (stricmp("DevName", pAttr->Name()) == 0)		strcpy(fltBuf.szDevName, pAttr->Value());
				else if (stricmp("FltType", pAttr->Name()) == 0)		fltBuf.nFltType=atoi(pAttr->Value());
				else if (stricmp("ShortType", pAttr->Name()) == 0)		fltBuf.nShortType=atoi(pAttr->Value());
				else if (stricmp("FltPhase", pAttr->Name()) == 0)		fltBuf.nFltPhase=atoi(pAttr->Value());
				else if (stricmp("FltSide", pAttr->Name()) == 0)		fltBuf.nFltSide=atoi(pAttr->Value());
				else if (stricmp("TCycle", pAttr->Name()) == 0)			fltBuf.fTCycle=(float)atof(pAttr->Value());
				else if (stricmp("TCyc1", pAttr->Name()) == 0)			fltBuf.fTCyc1=(float)atof(pAttr->Value());
				else if (stricmp("TCyc2", pAttr->Name()) == 0)			fltBuf.fTCyc2=(float)atof(pAttr->Value());
				else if (stricmp("TCyc11", pAttr->Name()) == 0)			fltBuf.fTCyc11=(float)atof(pAttr->Value());
				else if (stricmp("TCyc21", pAttr->Name()) == 0)			fltBuf.fTCyc21=(float)atof(pAttr->Value());
				else if (stricmp("TCyc12", pAttr->Name()) == 0)			fltBuf.fTCyc12=(float)atof(pAttr->Value());
				else if (stricmp("TCyc22", pAttr->Name()) == 0)			fltBuf.fTCyc22=(float)atof(pAttr->Value());
				else if (stricmp("FaultR", pAttr->Name()) == 0)			fltBuf.fFaultR=(float)atof(pAttr->Value());
				else if (stricmp("FaultX", pAttr->Name()) == 0)			fltBuf.fFaultX=(float)atof(pAttr->Value());
				else if (stricmp("Percent", pAttr->Name()) == 0)		fltBuf.fPercent=(float)atof(pAttr->Value());
				else if (stricmp("ElType", pAttr->Name()) == 0)			fltBuf.nElType=atoi(pAttr->Value());
				else if (stricmp("ElCrest", pAttr->Name()) == 0)		fltBuf.fElCrest=(float)atof(pAttr->Value());
				else if (stricmp("ExcitT", pAttr->Name()) == 0)			fltBuf.fExcitT=(float)atof(pAttr->Value());
				else if (stricmp("RunFlt", pAttr->Name()) == 0)			fltBuf.bRunFlt=atoi(pAttr->Value());

				pAttr=pAttr->Next();
			}

			AddBpaFltDefine(fltBuf);	//m_FltDefArray.push_back(fltBuf);
		}

		pLine = pLine->NextSiblingElement();
	}

	return 1;
}

void CPG2BpaFileApi::SaveFltFile(TiXmlElement* pRootElement)
{
	register int	i;
	char	szBuf[260];
	for (i=0; i<GetBpaFltDefineNum(); i++)
	{
		sprintf(szBuf, "%d", i+1);
		TiXmlElement*	pFault=new TiXmlElement("Fault");
		pFault->LinkEndChild(new TiXmlText(szBuf));
		pRootElement->LinkEndChild(pFault);

		pFault->SetAttribute("DevType",			m_FltDefArray[i].nDevType);
		pFault->SetAttribute("DevSub",			m_FltDefArray[i].szDevSub);
		pFault->SetAttribute("DevVolt",			m_FltDefArray[i].szDevVolt);
		pFault->SetAttribute("DevName",			m_FltDefArray[i].szDevName);
		pFault->SetAttribute("FltType",			m_FltDefArray[i].nFltType);
		pFault->SetAttribute("ShortType",		m_FltDefArray[i].nShortType);
		pFault->SetAttribute("FltPhase",		m_FltDefArray[i].nFltPhase);
		pFault->SetAttribute("FltSide",			m_FltDefArray[i].nFltSide);
		pFault->SetDoubleAttribute("TCycle",	(double)m_FltDefArray[i].fTCycle);
		pFault->SetDoubleAttribute("TCyc1",		(double)m_FltDefArray[i].fTCyc1);
		pFault->SetDoubleAttribute("TCyc2",		(double)m_FltDefArray[i].fTCyc2);
		pFault->SetDoubleAttribute("TCyc11",	(double)m_FltDefArray[i].fTCyc11);
		pFault->SetDoubleAttribute("TCyc21",	(double)m_FltDefArray[i].fTCyc21);
		pFault->SetDoubleAttribute("TCyc12",	(double)m_FltDefArray[i].fTCyc12);
		pFault->SetDoubleAttribute("TCyc22",	(double)m_FltDefArray[i].fTCyc22);
		pFault->SetDoubleAttribute("FaultR",	(double)m_FltDefArray[i].fFaultR);
		pFault->SetDoubleAttribute("FaultX",	(double)m_FltDefArray[i].fFaultX);
		pFault->SetDoubleAttribute("Percent",	(double)m_FltDefArray[i].fPercent);
		pFault->SetAttribute("ElType",			m_FltDefArray[i].nElType);
		pFault->SetDoubleAttribute("ElCrest",	(double)m_FltDefArray[i].fElCrest);
		pFault->SetDoubleAttribute("ExcitT",	(double)m_FltDefArray[i].fExcitT);
		pFault->SetAttribute("RunFlt",			m_FltDefArray[i].bRunFlt);
	}
}
