#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"

const	int	g_nCommentIniColumn=82;
const	int	g_nMaxCustomNum = 494;

void CPG2BpaFileApi::PG2BpaDatOneFile(tagPGBlock* pPGBlock, const double fGenPQFactor, const double fLoadPQFactor, const double fAutoPVMvaThreshold, const char* lpszFileName)
{
	FILE*	fp;
	int		nIsland;

	PGMemDBTopo(pPGBlock);
	PGMemDBIsland(pPGBlock);
	PGMemDBStatus(pPGBlock, 0);
	PGMemDBPFAmend(pPGBlock);

	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	FormDat_ConCard(pPGBlock, fp, 0);
	fprintf(fp, "/NETWORK_DATA\\\n");

	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		FormBArray(pPGBlock, fLoadPQFactor, fGenPQFactor,fAutoPVMvaThreshold, nIsland);
		FormLArray(pPGBlock, nIsland);
		FormTArray(pPGBlock, nIsland);

		//Log(g_lpszPG2BpaApiLogFile, "����BPA�絺[%d/%d]�ļ�:%d %d\n", nIsland, pPGBlock->m_nRecordNum[PG_ISLAND], m_LineArray.size(), m_TranArray.size());
		if (m_LineArray.empty() && m_TranArray.empty())
			continue;

		//WriteAICard	(pPGBlock, fp, nIsland);
		FormDat_BCard	(pPGBlock, fp, nIsland);
		FormDat_LCard	(pPGBlock, fp, nIsland);
		FormDat_TCard	(pPGBlock, fp, nIsland);
		//FormDat_BDCard	(pPGBlock, fp, nIsland);
		//FormDat_LDCard	(pPGBlock, fp, nIsland);
		//FormDat_RCard	(pPGBlock, fp, nIsland);
	}

	fprintf(fp, "(END)\n");
	fflush(fp);
	fclose(fp);
}

void CPG2BpaFileApi::PG2BpaDatFile(tagPGBlock* pPGBlock, const double fGenPQFactor, const double fLoadPQFactor, const double fAutoPVMvaThreshold, const unsigned char bMIslandPF, const char* lpszWorkDir)
{
	char	szFileName[260];
	FILE*	fp;
	int		nIsland;

	PGMemDBTopo(pPGBlock);
	PGMemDBIsland(pPGBlock);
	PGMemDBStatus(pPGBlock, 0);
	PGMemDBPFAmend(pPGBlock);

	if (!bMIslandPF)
	{
		float	fMaxGenIsland=-9999;
		int		nMaxGenIsland=-1;
		for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
		{
			if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
				continue;
			if (pPGBlock->m_IslandArray[nIsland].bDead)
				continue;
			if (pPGBlock->m_IslandArray[nIsland].fUnitP > fMaxGenIsland)
			{
				fMaxGenIsland=pPGBlock->m_IslandArray[nIsland].fUnitP;
				nMaxGenIsland=nIsland;
			}
		}

		if (nMaxGenIsland > 0)
		{
			for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
			{
				if (nIsland != nMaxGenIsland)
					pPGBlock->m_IslandArray[nIsland].bDead=1;
			}
		}
	}

	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		sprintf(szFileName, "%s/%s%d.pfo", lpszWorkDir, m_BpaDatConCard.szProject, nIsland);
		unlink(szFileName);
		sprintf(szFileName, "%s/%s%d.dat", lpszWorkDir, m_BpaDatConCard.szProject, nIsland);
		unlink(szFileName);

		FormBArray(pPGBlock, fGenPQFactor, fLoadPQFactor, fAutoPVMvaThreshold, nIsland);
		FormLArray(pPGBlock, nIsland);
		FormTArray(pPGBlock, nIsland);

		//Log(g_lpszPG2BpaApiLogFile, "����BPA�絺[%d/%d]�ļ�:%d %d\n", nIsland, pPGBlock->m_nRecordNum[PG_ISLAND], m_LineArray.size(), m_TranArray.size());
		if (m_LineArray.empty() && m_TranArray.empty())
			continue;

		sprintf(szFileName, "%s/%s%d.dat", lpszWorkDir, m_BpaDatConCard.szProject, nIsland);
		fp=fopen(szFileName, "w");
		if (fp != NULL)
		{
			FormDat_ConCard(pPGBlock, fp, nIsland);

			fprintf(fp, "/NETWORK_DATA\\\n");
			//WriteAICard	(pPGBlock, fp, nIsland);
			FormDat_BCard	(pPGBlock, fp, nIsland);
			FormDat_LCard	(pPGBlock, fp, nIsland);
			FormDat_TCard	(pPGBlock, fp, nIsland);
			//FormDat_BDCard	(pPGBlock, fp, nIsland);
			//FormDat_LDCard	(pPGBlock, fp, nIsland);
			//FormDat_RCard	(pPGBlock, fp, nIsland);

			fprintf(fp, "\n");
			Form_OutputCard(pPGBlock, fp, nIsland);

			fprintf(fp, "(END)\n");

			fflush(fp);
			fclose(fp);
		}
	}
}

void CPG2BpaFileApi::Form_OutputCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
	register int		i;
	int		nCustom, nCustomLineP, nCustomTranP, nCustomLineQ, nCustomTranQ;
	std::string			strString;
	std::vector<std::string>	strDivArray;
	strDivArray.clear();
	for (i=0; i<(int)m_BusArray.size(); i++)
		AddUniqueString(strDivArray, m_BusArray[i].szZone);

	nCustom = nCustomLineP = nCustomTranP = nCustomLineQ = nCustomTranQ = 0;
	strString = "/LINE_LOSS, ZONES=";
	for (i=0; i<strDivArray.size(); i++)
	{
		if (i > 0)
			strString.append(", ");
		strString.append(strDivArray[i]);
	}
	strString.append("\\");
	fprintf(fp, "%s\n", strString.c_str());

	strString = "/TRANSFORMER_LOSS, ZONES=";
	for (i=0; i<strDivArray.size(); i++)
	{
		if (i > 0)
			strString.append(", ");
		strString.append(strDivArray[i]);
	}
	strString.append("\\");
	fprintf(fp, "%s\n", strString.c_str());

	fprintf(fp, "/USER_ANALYSIS\\\n");

	fprintf(fp, ">DEFINE_TYPE SYSTEM_LOSS<\n");
	fprintf(fp, " LET SLOS\n");

	fprintf(fp, ">DEFINE_TYPE ZONE_INDEX<\n");
	for (i=0; i<strDivArray.size(); i++)
	{
		fprintf(fp, " LET Z%s = %s\n", strDivArray[i].c_str(), strDivArray[i].c_str());			nCustom++;
	}

	fprintf(fp, ">DEFINE_TYPE FUNCTION<\n");
	for (i=0; i<strDivArray.size(); i++)
	{
		fprintf(fp, " LET Z%sPG = Z%s.PG\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
		fprintf(fp, " LET Z%sQG = Z%s.QG\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
		fprintf(fp, " LET Z%sPL = Z%s.PL\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
		fprintf(fp, " LET Z%sQL = Z%s.QL\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
		fprintf(fp, " LET Z%sPLS = Z%s.PLS\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
		fprintf(fp, " LET Z%sQLS = Z%s.QLS\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
		fprintf(fp, " LET Z%sQSH = Z%s.QSH\n", strDivArray[i].c_str(), strDivArray[i].c_str());	nCustom++;
	}

	fprintf(fp, ">DEFINE_TYPE BRANCH_P<\n");
	for (i=0; i<m_LineArray.size(); i++)
	{
		if (nCustom < g_nMaxCustomNum)
		{
			fprintf(fp, " LET LP%d = %s %.2f %s %.2f %c\n", i+1, m_LineArray[i].szBusI, m_LineArray[i].fkVI, m_LineArray[i].szBusJ, m_LineArray[i].fkVJ, m_LineArray[i].cLoop);		nCustom++;
			fprintf(fp, " LET L_P%d = %s %.2f %s %.2f %c\n", i+1, m_LineArray[i].szBusJ, m_LineArray[i].fkVJ, m_LineArray[i].szBusI, m_LineArray[i].fkVI, m_LineArray[i].cLoop);	nCustom++;
			nCustomLineP++;
		}
	}
	for (i=0; i<m_TranArray.size(); i++)
	{
		if (nCustom < g_nMaxCustomNum)
		{
			fprintf(fp, " LET TP%d = %s %.2f %s %.2f %c\n", i+1, m_TranArray[i].szBusI, m_TranArray[i].fkVI, m_TranArray[i].szBusJ, m_TranArray[i].fkVJ, m_TranArray[i].cLoop);		nCustom++;
			fprintf(fp, " LET T_P%d = %s %.2f %s %.2f %c\n", i+1, m_TranArray[i].szBusJ, m_TranArray[i].fkVJ, m_TranArray[i].szBusI, m_TranArray[i].fkVI, m_TranArray[i].cLoop);	nCustom++;
			nCustomTranP++;
		}
	}

	fprintf(fp, ">DEFINE_TYPE BRANCH_Q<\n");
	for (i=0; i<m_LineArray.size(); i++)
	{
		if (nCustom < g_nMaxCustomNum)
		{
			fprintf(fp, " LET LQ%d = %s %.2f %s %.2f %c\n", i+1, m_LineArray[i].szBusI, m_LineArray[i].fkVI, m_LineArray[i].szBusJ, m_LineArray[i].fkVJ, m_LineArray[i].cLoop);		nCustom++;
			fprintf(fp, " LET L_Q%d = %s %.2f %s %.2f %c\n", i+1, m_LineArray[i].szBusJ, m_LineArray[i].fkVJ, m_LineArray[i].szBusI, m_LineArray[i].fkVI, m_LineArray[i].cLoop);	nCustom++;
			nCustomLineQ++;
		}
	}
	for (i=0; i<m_TranArray.size(); i++)
	{
		if (nCustom < g_nMaxCustomNum)
		{
			fprintf(fp, " LET TQ%d = %s %.2f %s %.2f %c\n", i+1, m_TranArray[i].szBusI, m_TranArray[i].fkVI, m_TranArray[i].szBusJ, m_TranArray[i].fkVJ, m_TranArray[i].cLoop);		nCustom++;
			fprintf(fp, " LET T_Q%d = %s %.2f %s %.2f %c\n", i+1, m_TranArray[i].szBusJ, m_TranArray[i].fkVJ, m_TranArray[i].szBusI, m_TranArray[i].fkVI, m_TranArray[i].cLoop);	nCustom++;
			nCustomTranQ++;
		}
	}

	fprintf(fp, "H �Զ������\n");
	fprintf(fp, "C �Զ����������ȫ��               $SLOS/F12.4\n"); 
	for (i=0; i<strDivArray.size(); i++)
	{
		fprintf(fp, "C �Զ�����������й����� %s   $Z%sPG/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
		fprintf(fp, "C �Զ�����������޹����� %s   $Z%sQG/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
		fprintf(fp, "C �Զ�����������й����� %s   $Z%sPL/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
		fprintf(fp, "C �Զ�����������޹����� %s   $Z%sQL/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
		fprintf(fp, "C �Զ�������й���ķ��� %s   $Z%sPLS/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
		fprintf(fp, "C �Զ�������޹���ķ��� %s   $Z%sQLS/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
		fprintf(fp, "C �Զ�������޹��������� %s   $Z%sQSH/F12.4\n", strDivArray[i].c_str(), strDivArray[i].c_str());
	}

	for (i=0; i<nCustomLineP; i++)
	{
		fprintf(fp, "C �Զ��������·�й�  %s  $LP%d/F12.4  $L_P%d/F12.4\n", m_LineArray[i].szAlias, i+1, i+1);
	}
	for (i=0; i<nCustomLineQ; i++)
	{
		fprintf(fp, "C �Զ��������·�޹�  %s  $LQ%d/F12.4  $L_Q%d/F12.4\n", m_LineArray[i].szAlias, i+1, i+1);
	}

	for (i=0; i<nCustomTranP; i++)
	{
		fprintf(fp, "C �Զ�����������й�  %s  $TP%d/F12.4  $T_P%d/F12.4\n", m_TranArray[i].szAlias, i+1, i+1);
	}
	for (i=0; i<nCustomTranQ; i++)
	{
		fprintf(fp, "C �Զ�����������޹�  %s  $TQ%d/F12.4  $T_Q%d/F12.4\n", m_TranArray[i].szAlias, i+1, i+1);
	}
}

void CPG2BpaFileApi::FormDat_ConCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
	if (nIsland > 0)
	{
		fprintf(fp, "(POWERFLOW, CASEID=%s%d, PROJECT=%s)\n", m_BpaDatConCard.szCaseID, nIsland, m_BpaDatConCard.szProject);
		fprintf(fp, "/NEW_BASE, FILE=%s%d.BSE\\\n", m_BpaDatConCard.szNewBase, nIsland);
	}
	else
	{
		fprintf(fp, "(POWERFLOW, CASEID=%s, PROJECT=%s)\n", m_BpaDatConCard.szCaseID, m_BpaDatConCard.szProject);
		fprintf(fp, "/NEW_BASE, FILE=%s.BSE\\\n", m_BpaDatConCard.szNewBase);
	}
	fprintf(fp, "/MVA_BASE=%.0f\\\n", pPGBlock->m_System.fBasePower);			//	��׼����

	//	�����̿���
	//fprintf(fp, "/SOLUTION\\\n");					//	��������������������ݺ�����Ϊ�����������
	if (m_BpaDatConCard.nAIControl == 0)		fprintf(fp, "/AI_CONTROL=CON\\\n");			//	�����߿��ƣ�ȱʡ
	else if (m_BpaDatConCard.nAIControl == 1)	fprintf(fp, "/AI_CONTROL=MON\\\n");			//	�����߲����ƣ�����
	else										fprintf(fp, "/AI_CONTROL=OFF\\\n");			//	�����߲�����

	fprintf(fp, "/SOL_ITER, DECOUPLED=%d, CURRENT=0, NEWTON=%d, OPITM=0\\\n", m_BpaDatConCard.nDecoupledNum, m_BpaDatConCard.nNewtonNum);
	fprintf(fp, "/TOLERANCE, BUSV=%f, AIPOWER=%f, TX=.005, Q=%f, OPCUT=.0001\\\n", 
		m_BpaDatConCard.fToleranceBusV, m_BpaDatConCard.fToleranceAIPower, m_BpaDatConCard.fToleranceQ);

	//	ԭʼ���ݺͼ��������

	//	���򽻻����ʿ��Ƽ��������ѡ��
	fprintf(fp, "/AI_LIST=FULL\\\n");			//	ȫ�����

	//	�����ԭʼ�������ѡ��
	fprintf(fp, "/P_INPUT_LIST, NONE\\\n");		//	�����

	//	�������
	if (m_BpaDatConCard.nRptSort == 0)		fprintf(fp, "/RPT_SORT=BUS\\\n");
	else if (m_BpaDatConCard.nRptSort == 1)	fprintf(fp, "/RPT_SORT=ZONE\\\n");
	else if (m_BpaDatConCard.nRptSort == 2)	fprintf(fp, "/RPT_SORT=AREA\\\n");

	//	���ѡ��
	fprintf(fp, "/P_OUTPUT_LIST, FULL\\\n");

	fprintf(fp, "/P_ANALYSIS_RPT, LEVEL=%d\\\n", m_BpaDatConCard.nAnalysisRpt+1);

	//fprintf(fp, "/PF_MAP, FILE=A.MAP\\\n");	//	�°�����ͼ��������
}

void CPG2BpaFileApi::FormDat_AICard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nCorp, nDiv, nVolt;
	int		nSSub, nSUnit;

	for (nCorp=0; nCorp<pPGBlock->m_nRecordNum[PG_COMPANY]; nCorp++)
	{
		nSSub=nSUnit=nVolt=0;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[i].szName, pPGBlock->m_CompanyArray[nCorp].szSlackSub) == 0)
			{
				nSSub=i;
				break;
			}
		}
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			if (strcmp(pPGBlock->m_SynchronousMachineArray[i].szSub, pPGBlock->m_CompanyArray[nCorp].szSlackSub) == 0 &&
				strcmp(pPGBlock->m_SynchronousMachineArray[i].szName, pPGBlock->m_CompanyArray[nCorp].szSlackGen) == 0)
			{
				nSUnit=i;
				break;
			}
		}
		for (i=pPGBlock->m_SubstationArray[nSSub].nVoltageLevelRange; i<pPGBlock->m_SubstationArray[nSSub+1].nVoltageLevelRange; i++)
		{
			if (strcmp(pPGBlock->m_SynchronousMachineArray[nSUnit].szVolt, pPGBlock->m_VoltageLevelArray[i].szName) == 0)
			{
				nVolt=i;
				break;
			}
		}
		fprintf(fp, "AO ");									//	AO����1-3��3��
		fprintf(fp, "%-10s", pPGBlock->m_CompanyArray[nCorp].szName);				//	��������4-13��10��
		fprintf(fp, " ");									//	14�У�����
		for (nDiv=0; nDiv<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDiv++)				//	15�п�ʼ��22��
		{
			if (strcmp(pPGBlock->m_SubcontrolAreaArray[nDiv].szCompany, pPGBlock->m_CompanyArray[nCorp].szName) == 0)
			{
				fprintf(fp, "%-.2d", nDiv);
				fprintf(fp, " ");
			}
		}
		fprintf(fp, "\n");
	}
}

void CPG2BpaFileApi::FormDat_BCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDev, nDictIni;
	char	szLine[256];

	for (nDev=0; nDev<(int)m_BusArray.size(); nDev++)
	{
		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(m_BusArray[nDev].szCardKey, BpaDatCategory_Dat);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_DAT_ACBUS, nDictIni, (const char*)&m_BusArray[nDev], szLine) <= 0)
			continue;

		if (strlen(m_BusArray[nDev].szAlias) > 0)
		{
			for (i=(int)strlen(szLine); i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';
			for (i=0; i<(int)strlen(m_BusArray[nDev].szAlias); i++)
				szLine[g_nCommentIniColumn+i] = m_BusArray[nDev].szAlias[i];
			TrimRight(szLine);
		}
		fprintf(fp, "%s\n", szLine);
	}
}

void CPG2BpaFileApi::FormDat_LCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nLine;
	char	szLine[256];

	for (nLine=0; nLine<(int)m_LineArray.size(); nLine++)
	{
		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(m_LineArray[nLine].szCardKey, BpaDatCategory_Dat);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_DAT_ACLINE, nDictIni, (const char*)&m_LineArray[nLine], szLine) <= 0)
			continue;

		if (strlen(m_LineArray[nLine].szAlias) > 0)
		{
			for (i=(int)strlen(szLine); i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';
			for (i=0; i<(int)strlen(m_LineArray[nLine].szAlias); i++)
				szLine[g_nCommentIniColumn+i] = m_LineArray[nLine].szAlias[i];
			TrimRight(szLine);
		}
		fprintf(fp, "%s\n", szLine);
	}
}

void CPG2BpaFileApi::FormDat_TCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nTran;
	char	szLine[256];

	for (nTran=0; nTran<(int)m_TranArray.size(); nTran++)
	{
		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(m_TranArray[nTran].szCardKey, BpaDatCategory_Dat);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_DAT_WIND, nDictIni, (const char*)&m_TranArray[nTran], szLine) <= 0)
			continue;

		if (strlen(m_TranArray[nTran].szAlias) > 0)
		{
			for (i=(int)strlen(szLine); i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';
			for (i=0; i<(int)strlen(m_TranArray[nTran].szAlias); i++)
				szLine[g_nCommentIniColumn+i] = m_TranArray[nTran].szAlias[i];
			TrimRight(szLine);
		}
		fprintf(fp, "%s\n", szLine);
	}
}

void CPG2BpaFileApi::FormDat_BDCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
}

void CPG2BpaFileApi::FormDat_RCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
}

void CPG2BpaFileApi::FormDat_LDCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland)
{
}
