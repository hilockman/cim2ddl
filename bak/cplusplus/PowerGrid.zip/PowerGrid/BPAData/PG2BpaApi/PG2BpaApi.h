#pragma once

#define	PG2BPAAPI_USING_STL

#include <float.h>

#ifdef _USRDLL
#	ifdef _PG2BPAAPI_EXPORTS_
#		define PG2BPAAPI_API __declspec(dllexport)
#	else
#		define PG2BPAAPI_API __declspec(dllimport)
#	endif
#else
#	define PG2BPAAPI_API
#endif

#include "../../../MemDB/PGMemDB/PGMemDB.h"
#include "../../../MemDB/BpaMemDB/BpaMemDB.h"
using	namespace	PGMemDB;
using	namespace	BpaMemDB;

#include "../../../Common/TinyXML/tinyxml.h"
#include "../../../Common/MFCControls/SimpleCurve.h"

#include "PG2BpaDefine.h"
const double	g_ConstfBaseFrequency = 50.0;

// #ifdef PG2BPAAPI_USING_STL
// #	define DLL_STL_VECTOR( STL_API, STL_TYPE ) \
// 	template class STL_API std::allocator< STL_TYPE >; \
// 	template class STL_API std::vector<STL_TYPE, std::allocator< STL_TYPE > >;
// 
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaFltDefine );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaBusMonitor );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaGenMonitor );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaLineMonitor );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaTranMonitor );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaStaticLoadModel );
// 
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaDat_ACBus );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaDat_ACLine );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaDat_Wind );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaSwi_LO );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaSwi_XO );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaSwi_XR );
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagBpaSwi_XR );
// 
// DLL_STL_VECTOR ( PG2BPAAPI_API, tagSimpleCurve );
// #endif

class PG2BPAAPI_API	CPG2BpaFileApi
{
public:
	CPG2BpaFileApi(void);
	~CPG2BpaFileApi(void);

public:
	tagBpaDat_Case	m_BpaDatConCard;
	tagBpaSwi_FF	m_BpaSwiConCard;

#ifdef PG2BPAAPI_USING_STL
	std::vector<tagBpaFltDefine>		m_FltDefArray;
	std::vector<tagBpaBusMonitor>		m_MonBusArray;
	std::vector<tagBpaGenMonitor>		m_MonGenArray;
	std::vector<tagBpaLineMonitor>		m_MonLineArray;
	std::vector<tagBpaTranMonitor>		m_MonTranArray;
	std::vector<tagBpaStaticLoadModel>	m_LoadSModelArray;
#else
	int						m_nFaultNum;
	tagBpaFltDefine			m_FltDefArray[ConstMaxFaultDefine];

	int						m_nBpaBusMonNum;
	tagBpaBusMonitor		m_MonBusArray[ConstMaxBusMonitor];

	int						m_nBpaGenMonNum;
	tagBpaGenMonitor		m_MonGenArray[ConstMaxGenMonitor];

	int						m_nBpaLineMonNum;
	tagBpaLineMonitor		m_MonLineArray[ConstMaxLineMonitor];

	int						m_nBpaTranMonNum;
	tagBpaTranMonitor		m_MonTranArray[ConstMaxTranMonitor];

	int						m_nBpaLoadSModelNum;
	tagBpaStaticLoadModel	m_LoadSModelArray[ConstMaxLoadSModel];
#endif // USING_STL

	char m_szDefaultLoadSModel[MDB_CHARLEN];
	char m_szUsingAutoUFModel[MDB_CHARLEN];
	char m_szUsingAutoUVModel[MDB_CHARLEN];

	tagBpaGenMonitor	m_ReferenceGen;
	tagBpaAutoLoadFV	m_SysUFSetting;
	tagBpaAutoLoadFV	m_SysUVSetting;

public:
	int GetBpaFltDefineNum();
	void AddBpaFltDefine(tagBpaFltDefine& sBuf);
	void DelBpaFltDefine(const int nIndex);

	int GetBpaBusMonitorNum();
	void AddBpaBusMonitor(tagBpaBusMonitor& sBuf);
	void DelBpaBusMonitor(const int nIndex);

	int GetBpaGenMonitorNum();
	void AddBpaGenMonitor(tagBpaGenMonitor& sBuf);
	void DelBpaGenMonitor(const int nIndex);

	int GetBpaLineMonitorNum();
	void AddBpaLineMonitor(tagBpaLineMonitor& sBuf);
	void DelBpaLineMonitor(const int nIndex);

	int GetBpaTranMonitorNum();
	void AddBpaTranMonitor(tagBpaTranMonitor& sBuf);
	void DelBpaTranMonitor(const int nIndex);

	int GetBpaStaticLoadModelNum();
	void AddBpaStaticLoadModel(tagBpaStaticLoadModel& sBuf);
	void DelBpaStaticLoadModel(const int nIndex);

	int LoadSysParamFile(TiXmlElement* pRootElement);
	int LoadFltFile(TiXmlElement* pRootElement);
	int LoadMonFile(TiXmlElement* pRootElement);

	int LoadPGSWModel(tagPGBlock* pPGBlock, TiXmlElement* pRootElement);

	void SaveSysParamFile(TiXmlElement* pRootElement);
	void SaveFltFile(TiXmlElement* pRootElement);
	void SaveMonFile(TiXmlElement* pRootElement);
	void SavePGSWModel(tagPGBlock* pPGBlock, TiXmlElement* pRootElement);

	int LoadPGSetting(tagPGBlock* pPGBlock, const char* lpszFileName);
	void SavePGSetting(tagPGBlock* pPGBlock, const char* lpszFileName);

	void PG2BpaDatOneFile(tagPGBlock* pPGBlock, const double fGenPQFactor, const double fLoadPQFactor, const double fAutoPVMvaThreshold, const char* lpszFileName);
	void PG2BpaSwiOneFile(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, const char* lpszFileName);

	void PG2BpaDatFile	(tagPGBlock* pPGBlock, const double fGenPQFactor, const double fLoadPQFactor, const double fAutoPVMvaThreshold, const unsigned char bMIslandPF, const char* lpszWorkDir);
	void PG2BpaSwiFile	(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, const char* lpszWorkDir);
	void PG2BpaRmlFile	(tagPGBlock* pPGBlock, const char* lpszFileName);
	int PGParsePfoFile	(tagPGBlock* pPGBlock, const char* lpszWorkDir);
	int PGParseOutFile	(tagPGBlock* pPGBlock, const char* lpszWorkDir, const int nIsland);
	//int FormFltString	(tagPGBlock* pPGBlock, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltString	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, std::vector<std::string>& strRetLineArray);

	//	����
private:
	void FormDat_ConCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_AICard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_BCard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_LCard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_TCard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_BDCard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_RCard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void FormDat_LDCard	(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);
	void Form_OutputCard(tagPGBlock* pPGBlock, FILE* fp, const int nIsland);

	//	�ȶ�
private:
	void FormSwi_GenCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_LSCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_MLCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_XOCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_LOCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_XRCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_LBCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);

	int RegularUF(tagBpaSwi_UF& ufBuf);
	int RegularUV(tagBpaSwi_UV& uvBuf);
	void FormSwi_UFCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_UVCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_RWCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_RECard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_RACard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);
	void FormSwi_RUCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland);

private:
	void ResolveNumericString	(const char* lpszString, char* lpszRetString);
	int PGParseBpaPfoBusLine	(tagPGBlock* pPGBlock, const char* lpszLine, const char* lpszLineExt, char* lpszBusName, double& fBusVolt);
	void PGParseBpaPfoBusShunt	(tagPGBlock* pPGBlock, const int nTopoBus, const char* lpszLine);
	void PGParseBpaPfoACBranch	(tagPGBlock* pPGBlock, const char* lpszFrBusName, const double fFrBusVolt, const char* lpszLine);
	void PGParseBpaPfoOutput		(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine);
	void PGParseBpaPfoLineLoss	(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine);
	void PGParseBpaPfoTranLoss	(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine);
	int isBpaPfoShuntLine(const char* lpszLine);

	std::string	FormGenPGAlias(tagPGBlock* pPGBlock, const int nDev);
	std::string	FormLoadPGAlias(tagPGBlock* pPGBlock, const int nDev);
	std::string FormPShuntPGAlias(tagPGBlock* pPGBlock, const int nDev);
	std::string	FormSShuntPGAlias(tagPGBlock* pPGBlock, const int nDev, const unsigned char nSide);
	std::string	FormLinePGAlias(tagPGBlock* pPGBlock, const int nDev, const unsigned char nSide);
	std::string	FormTranPGAlias(tagPGBlock* pPGBlock, const int nDev, const unsigned char nSide);

private:
	int FindBusInBArray(const char* lpszBusName, const float fNorminalVolt);
	int FindLineInLArray(const char* lpszLineName);
	int FindTranInTArray(const char* lpszTranName);
	void FormBArray(tagPGBlock* pPGBlock, const double fGenPQFactor, const double fLoadPQFactor, const double fAutoPVMvaThreshold, const int nIsland);
	void FormLArray(tagPGBlock* pPGBlock, const int nIsland);
	void FormTArray(tagPGBlock* pPGBlock, const int nIsland);

	void GetLineLoopArray(tagPGBlock* pPGBlock, std::vector<char>& cLoopArray);
	void GetSCapLoopArray(tagPGBlock* pPGBlock, std::vector<char>& cLoopArray);
	void GetTranLoopArray(tagPGBlock* pPGBlock, std::vector<char>& cLoopArray);
	void GetGenIDArray(tagPGBlock* pPGBlock, std::vector<char>& cIDArray);

	//	����
private:
	int FormFltBusString		(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltLineTripString	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltTranTripString	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltGenTripString	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltLoadTripString	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltLineSC3String	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltTranSC3String	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltLineSCP1String	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltTranSCP1String	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltGenElString		(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine);
	int FormFltLineSC4String	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, std::vector<std::string>& strRetLineArray);
	int FormFltTranSC4String	(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, std::vector<std::string>& strRetLineArray);

	//	����
private:
	void FormSwi_BusMonCard(tagPGBlock* pPGBlock, FILE* fp);
	void FormSwi_GenMonCard(tagPGBlock* pPGBlock, FILE* fp);
	void FormSwi_BranMonCard(tagPGBlock* pPGBlock, FILE* fp);
	void ResolveCurveName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine, char* lpszCurveName);
	void ResolveBusName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszBusName, const char* lpszBusVolt, char* lpszCurveName);
	void ResolveGenName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszBusName, const char* lpszBusVolt, char* lpszCurveName);
	void ResolveBranName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszBus1Name, const char* lpszBus1Volt, const char* lpszBus2Name, const char* lpszBus2Volt, char cLoop, char* lpszCurveName);
	void ResolveVCurveName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine, std::vector<tagSimpleCurve>& crvArray);

private:
	std::vector<tagBpaDat_ACBus>	m_BusArray;
	std::vector<tagBpaDat_ACLine>	m_LineArray;
	std::vector<tagBpaDat_Wind>		m_TranArray;
	std::vector<tagBpaSwi_LO>		m_LOArray;
	std::vector<tagBpaSwi_XO>		m_XOArray;
	std::vector<tagBpaSwi_XR>		m_XRArray;

private:
	char ResolveGenID(tagPGBlock* pPGBlock, const int nGen);
	char ResolveLineLoop(tagPGBlock* pPGBlock, const int nLine);
	char ResolveTranLoop(tagPGBlock* pPGBlock, const int nTran);
	int ResolveBusIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName);
	int ResolveLineIndex(tagPGBlock* pPGBlock, const char* lpszName);
	int ResolveTranIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName);
	int ResolveGenIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName);
	int ResolveLoadIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName);

	//	��lpszString�а�ָ�����������
private:
	void AddUniqueString(std::vector<std::string>& strStringArray, const std::string strString);
	void FillLineString(const int nType, const int nIni, const int nEnd, const int nLen, char* lpszValue, char* lpszString);

public:
#ifdef PG2BPAAPI_USING_STL
	std::vector<tagSimpleCurve>	m_BpaMonitorCurveArray;
	int	GetBpaMonitorCurveNum()	{	return (int)m_BpaMonitorCurveArray.size();	};
	tagSimpleCurve* GetCurve(const char* lpszCurveName)
	{
		int nCurve;
		for (nCurve=0; nCurve<(int)m_BpaMonitorCurveArray.size(); nCurve++)
		{
			if (stricmp(lpszCurveName, m_BpaMonitorCurveArray[nCurve].strCurveName.c_str()) == 0)	return &m_BpaMonitorCurveArray[nCurve];
		}

		return NULL;
	};
	void AddBpaMonitorCurve(tagSimpleCurve& sCurve)
	{
		m_BpaMonitorCurveArray.push_back(sCurve);
	};
#else
	int 		m_nBpaMonitorCurveNum;
	tagSimpleCurve	m_BpaMonitorCurveArray[ConstMaxBpaMonitorCurve];
	int	GetBpaMonitorCurveNum()	{	return m_nBpaMonitorCurveNum;	};
	tagSimpleCurve* GetCurve(const char* lpszCurveName)
	{
		int nCurve;
		for (nCurve=0; nCurve<m_nBpaMonitorCurveNum; nCurve++)
		{
			if (stricmp(lpszCurveName, m_BpaMonitorCurveArray[nCurve].strCurveName.c_str()) == 0)	return &m_BpaMonitorCurveArray[nCurve];
		}
		return NULL;
	};

	void AddBpaMonitorCurve(tagSimpleCurve& sCurve)
	{
		if (m_nBpaMonitorCurveNum < ConstMaxBpaMonitorCurve)
		{
			cloneSimpleCurve(&sCurve, &m_BpaMonitorCurveArray[m_nBpaMonitorCurveNum]);
			m_nBpaMonitorCurveNum++;
		}
	};
#endif
private:
	CBpaMemDBInterface	m_BpaMemDBInterface;
};

class PG2BPAAPI_API CBpaGenModelApi
{
public:
	CBpaGenModelApi(void);
	~CBpaGenModelApi(void);

public:
	void Mdb2ModelBuffer(tagBpaBlock* pBpaBlock, const char* lpszBus, const char* lpszVolt, const char* lpszID);
	void ModelBuffer2Mdb(tagBpaBlock* pBpaBlock, const char* lpszBus, const char* lpszVolt, const char* lpszID);
	void ClearModel();

public:
	int m_nExcModel;
	int m_nPssModel;
	int m_nGovModel;
	int m_nMovModel;

	int m_nGenIndex;
	int m_nDampIndex; 
	int m_nExcIndex;
	int m_nPssIndex;
	int m_nGovIndex;
	int m_nSvoIndex;
	int m_nMovIndex;

	tagBpaSwi_Gen			m_BpaSwi_GenBuffer		;
	tagBpaSwi_Damp			m_BpaSwi_DampBuffer		;
	tagBpaSwi_GenLn			m_BpaSwi_GenLnBuffer	;
	tagBpaSwi_Exc68			m_BpaSwi_Exc68Buffer	;
	tagBpaSwi_Exc81			m_BpaSwi_Exc81Buffer	;
	tagBpaSwi_ExcMV			m_BpaSwi_ExcMVBuffer	;
	tagBpaSwi_ExcX			m_BpaSwi_ExcXBuffer		;
	tagBpaSwi_PssS			m_BpaSwi_PssSBuffer		;
	tagBpaSwi_PssSH			m_BpaSwi_PssSHBuffer	;
	tagBpaSwi_PssSI			m_BpaSwi_PssSIBuffer	;
	tagBpaSwi_PssSA			m_BpaSwi_PssSABuffer	;
	tagBpaSwi_PssSB			m_BpaSwi_PssSBBuffer	;
	tagBpaSwi_PssST			m_BpaSwi_PssSTBuffer	;
	tagBpaSwi_GovGG			m_BpaSwi_GGBuffer		;
	tagBpaSwi_GovGH			m_BpaSwi_GHBuffer		;
	tagBpaSwi_GovGC			m_BpaSwi_GCBuffer		;
	tagBpaSwi_GovGS			m_BpaSwi_GSBuffer		;
	tagBpaSwi_GovGL			m_BpaSwi_GLBuffer		;
	tagBpaSwi_GovGW			m_BpaSwi_GWBuffer		;
	tagBpaSwi_GovGA			m_BpaSwi_GABuffer		;
	tagBpaSwi_GovGI			m_BpaSwi_GIBuffer		;
	tagBpaSwi_GovGJ			m_BpaSwi_GJBuffer		;
	tagBpaSwi_GovGK			m_BpaSwi_GKBuffer		;
	tagBpaSwi_GovGM			m_BpaSwi_GMBuffer		;
	tagBpaSwi_GovGD			m_BpaSwi_GDBuffer		;
	tagBpaSwi_GovGZ			m_BpaSwi_GZBuffer		;
	tagBpaSwi_MovTA			m_BpaSwi_TABuffer		;
	tagBpaSwi_MovTB			m_BpaSwi_TBBuffer		;
	tagBpaSwi_MovTC			m_BpaSwi_TCBuffer		;
	tagBpaSwi_MovTD			m_BpaSwi_TDBuffer		;
	tagBpaSwi_MovTE			m_BpaSwi_TEBuffer		;
	tagBpaSwi_MovTF			m_BpaSwi_TFBuffer		;
	tagBpaSwi_MovTW			m_BpaSwi_TWBuffer		;
private:
	CBpaMemDBInterface	m_BpaMemDBInterface;
};

extern	const	char*	g_lpszPG2BpaApiLogFile;
extern	void Log(const char* lpszLogFile, char* pformat, ...);
