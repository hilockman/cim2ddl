#include "StdAfx.h"
#include <io.h>
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"
#include "../../../Common/TinyXML/tinyxmlglobal.h"

const	char*	g_lpszPG2BpaApiLogFile="PG2BpaApi.log";
extern	void ClearLog(const char* lpszLogFile);

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/BpaMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/BpaMemDB.lib")
#endif

#ifdef _USRDLL
#	include "../../../Common/TinyXML/tinyxml.h"
//	using	namespace	TinyXML;
#	if (!defined(WIN64))
#		ifdef _DEBUG
#			pragma comment(lib, "../../../lib/libTinyXmlMDd.lib")
#			pragma message("Link LibX86 TinyXmlMDd.lib")
#		else
#			pragma comment(lib, "../../../lib/libTinyXmlMD.lib")
#			pragma message("Link LibX86 TinyXmlMD.lib")
#		endif
#	else
#		ifdef _DEBUG
#			pragma comment(lib, "../../../lib_x64/libTinyXmlMDd.lib")
#			pragma message("Link LibX64 TinyXmlMDd.lib")
#		else
#			pragma comment(lib, "../../../lib_x64/libTinyXmlMD.lib")
#			pragma message("Link LibX64 TinyXmlMD.lib")
#		endif
#	endif
#endif

CPG2BpaFileApi::CPG2BpaFileApi(void)
{
	ClearLog(g_lpszPG2BpaApiLogFile);

	memset(&m_BpaDatConCard, 0, sizeof(tagBpaDat_Case));
	memset(&m_BpaSwiConCard, 0, sizeof(tagBpaSwi_FF));
	strcpy(m_BpaSwiConCard.szCardKey, "FF");

	strcpy(m_BpaDatConCard.szCaseID,	"PG2BPA");
	strcpy(m_BpaDatConCard.szProject,	"PG2BPA");
	strcpy(m_BpaDatConCard.szNewBase,	"PG2BPA");
	m_BpaDatConCard.nDecoupledNum = 20;
	m_BpaDatConCard.nNewtonNum = 20;
	m_BpaDatConCard.fToleranceAIPower = (float)0.001;
	m_BpaDatConCard.fToleranceBusV = (float)0.005;
	m_BpaDatConCard.fToleranceQ = (float)0.005;
	m_BpaDatConCard.nAIControl = 2;
	m_BpaDatConCard.nRptSort = 0;
	m_BpaDatConCard.nAnalysisRpt = 0;

	strcpy(m_BpaSwiConCard.szCardKey, "FF");
	m_BpaSwiConCard.fT=0;
	m_BpaSwiConCard.fDT=1;
	m_BpaSwiConCard.fENDT=300;
	m_BpaSwiConCard.fDTDV=16;
	m_BpaSwiConCard.bLOVTEX=1;
	m_BpaSwiConCard.bNOANGLIM=1;
	m_BpaSwiConCard.bIMBLOK=1;

	memset(&m_SysUFSetting, 0, sizeof(tagBpaAutoLoadFV));
	memset(&m_SysUVSetting, 0, sizeof(tagBpaAutoLoadFV));
}

CPG2BpaFileApi::~CPG2BpaFileApi(void)
{
#ifdef PG2BPAAPI_USING_STL
	if (!m_FltDefArray.empty())				m_FltDefArray.clear();
	if (!m_MonBusArray.empty())				m_MonBusArray.clear();
	if (!m_MonGenArray.empty())				m_MonGenArray.clear();
	if (!m_MonLineArray.empty())			m_MonLineArray.clear();
	if (!m_MonTranArray.empty())			m_MonTranArray.clear();
	if (!m_LoadSModelArray.empty())			m_LoadSModelArray.clear();
	if (!m_BpaMonitorCurveArray.empty())	m_BpaMonitorCurveArray.clear();
#endif
}

int CPG2BpaFileApi::GetBpaFltDefineNum()
{
#ifdef PG2BPAAPI_USING_STL
	return (int)m_FltDefArray.size();
#else
	return m_nFaultNum;
#endif
}

void CPG2BpaFileApi::AddBpaFltDefine(tagBpaFltDefine& sBuf)
{
	register int	i;
#ifdef PG2BPAAPI_USING_STL
	for (i=0; i<(int)m_FltDefArray.size(); i++)
	{
		if (sBuf.nDevType == m_FltDefArray[i].nDevType &&
			stricmp(sBuf.szDevSub, m_FltDefArray[i].szDevSub) == 0 &&
			stricmp(sBuf.szDevVolt, m_FltDefArray[i].szDevVolt) == 0 &&
			stricmp(sBuf.szDevName, m_FltDefArray[i].szDevName) == 0 &&
			sBuf.nFltType == m_FltDefArray[i].nFltType &&
			sBuf.nShortType == m_FltDefArray[i].nShortType &&
			sBuf.nFltPhase == m_FltDefArray[i].nFltPhase &&
			sBuf.nFltSide == m_FltDefArray[i].nFltSide &&
			sBuf.fTCycle == m_FltDefArray[i].fTCycle &&
			sBuf.fTCyc1 == m_FltDefArray[i].fTCyc1 &&
			sBuf.fTCyc2 == m_FltDefArray[i].fTCyc2 &&
			sBuf.fTCyc11 == m_FltDefArray[i].fTCyc11 &&
			sBuf.fTCyc21 == m_FltDefArray[i].fTCyc21 &&
			sBuf.fTCyc12 == m_FltDefArray[i].fTCyc12 &&
			sBuf.fTCyc22 == m_FltDefArray[i].fTCyc22 &&
			sBuf.fFaultR == m_FltDefArray[i].fFaultR &&
			sBuf.fFaultX == m_FltDefArray[i].fFaultX &&
			sBuf.fPercent == m_FltDefArray[i].fPercent &&
			sBuf.nElType == m_FltDefArray[i].nElType &&
			sBuf.fElCrest == m_FltDefArray[i].fElCrest &&
			sBuf.fExcitT == m_FltDefArray[i].fExcitT)
			return;
	}
	m_FltDefArray.push_back(sBuf);
#else
	for (i=0; i<m_nFaultNum; i++)
	{
		if (sBuf.nDevType == m_FltDefArray[i].nDevType &&
			stricmp(sBuf.szDevSub, m_FltDefArray[i].szDevSub) == 0 &&
			stricmp(sBuf.szDevVolt, m_FltDefArray[i].szDevVolt) == 0 &&
			stricmp(sBuf.szDevName, m_FltDefArray[i].szDevName) == 0 &&
			sBuf.nFltType == m_FltDefArray[i].nFltType &&
			sBuf.nShortType == m_FltDefArray[i].nShortType &&
			sBuf.nFltPhase == m_FltDefArray[i].nFltPhase &&
			sBuf.nFltSide == m_FltDefArray[i].nFltSide &&
			sBuf.fTCycle == m_FltDefArray[i].fTCycle &&
			sBuf.fTCyc1 == m_FltDefArray[i].fTCyc1 &&
			sBuf.fTCyc2 == m_FltDefArray[i].fTCyc2 &&
			sBuf.fTCyc11 == m_FltDefArray[i].fTCyc11 &&
			sBuf.fTCyc21 == m_FltDefArray[i].fTCyc21 &&
			sBuf.fTCyc12 == m_FltDefArray[i].fTCyc12 &&
			sBuf.fTCyc22 == m_FltDefArray[i].fTCyc22 &&
			sBuf.fFaultR == m_FltDefArray[i].fFaultR &&
			sBuf.fFaultX == m_FltDefArray[i].fFaultX &&
			sBuf.fPercent == m_FltDefArray[i].fPercent &&
			sBuf.nElType == m_FltDefArray[i].nElType &&
			sBuf.fElCrest == m_FltDefArray[i].fElCrest &&
			sBuf.fExcitT == m_FltDefArray[i].fExcitT)
			return;
	}
	if (m_nFaultNum < ConstMaxFaultDefine-1)
		memcpy(&m_FltDefArray[m_nFaultNum++], &sBuf, sizeof(tagBpaFltDefine));
#endif
}

void CPG2BpaFileApi::DelBpaFltDefine(const int nIndex)
{
#ifdef PG2BPAAPI_USING_STL
	m_FltDefArray.erase(m_FltDefArray.begin()+nIndex);
#else
	register int	i;
	for (i=nIndex; i<m_nFaultNum-1; i++)
		memcpy(&m_FltDefArray[i], &m_FltDefArray[i+1], sizeof(tagBpaFltDefine));
	m_nFaultNum--;
#endif
}

int CPG2BpaFileApi::GetBpaBusMonitorNum()
{
#ifdef PG2BPAAPI_USING_STL
	return (int)m_MonBusArray.size();
#else
	return m_nBpaBusMonNum;
#endif
}

void CPG2BpaFileApi::AddBpaBusMonitor(tagBpaBusMonitor& sBuf)
{
	register int	i;
	int	nExist = -1;
#ifdef PG2BPAAPI_USING_STL
	for (i=0; i<(int)m_MonBusArray.size(); i++)
	{
		if (stricmp(m_MonBusArray[i].szDevSub, sBuf.szDevSub) == 0 &&
			stricmp(m_MonBusArray[i].szDevVolt, sBuf.szDevVolt) == 0 &&
			stricmp(m_MonBusArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonBusArray[nExist], &sBuf, sizeof(tagBpaBusMonitor));
	else
		m_MonBusArray.push_back(sBuf);
#else
	for (i=0; i<m_nBpaBusMonNum; i++)
	{
		if (stricmp(m_MonBusArray[i].szDevSub, sBuf.szDevSub) == 0 &&
			stricmp(m_MonBusArray[i].szDevVolt, sBuf.szDevVolt) == 0 &&
			stricmp(m_MonBusArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonBusArray[nExist], &sBuf, sizeof(tagBpaBusMonitor));
	else
	{
		if (m_nBpaBusMonNum < ConstMaxBusMonitor-1)
			memcpy(&m_MonBusArray[m_nBpaBusMonNum++], &sBuf, sizeof(tagBpaBusMonitor));
	}
#endif
}

void CPG2BpaFileApi::DelBpaBusMonitor(const int nIndex)
{
#ifdef PG2BPAAPI_USING_STL
	m_MonBusArray.erase(m_MonBusArray.begin()+nIndex);
#else
	register int	i;
	for (i=nIndex; i<m_nBpaBusMonNum-1; i++)
		memcpy(&m_MonBusArray[i], &m_MonBusArray[i+1], sizeof(tagBpaBusMonitor));
	m_nBpaBusMonNum--;
#endif
}

int CPG2BpaFileApi::GetBpaGenMonitorNum()
{
#ifdef PG2BPAAPI_USING_STL
	return (int)m_MonGenArray.size();
#else
	return m_nBpaGenMonNum;
#endif
}

void CPG2BpaFileApi::AddBpaGenMonitor(tagBpaGenMonitor& sBuf)
{
	register int	i;
	int	nExist = -1;
#ifdef PG2BPAAPI_USING_STL
	for (i=0; i<(int)m_MonGenArray.size(); i++)
	{
		if (stricmp(m_MonGenArray[i].szDevSub, sBuf.szDevSub) == 0 &&
			stricmp(m_MonGenArray[i].szDevVolt, sBuf.szDevVolt) == 0 &&
			stricmp(m_MonGenArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonGenArray[nExist], &sBuf, sizeof(tagBpaGenMonitor));
	else
		m_MonGenArray.push_back(sBuf);
#else
	for (i=0; i<m_nBpaGenMonNum; i++)
	{
		if (stricmp(m_MonGenArray[i].szDevSub, sBuf.szDevSub) == 0 &&
			stricmp(m_MonGenArray[i].szDevVolt, sBuf.szDevVolt) == 0 &&
			stricmp(m_MonGenArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonGenArray[nExist], &sBuf, sizeof(tagBpaGenMonitor));
	else
	{
		if (m_nBpaGenMonNum < ConstMaxGenMonitor-1)
			memcpy(&m_MonGenArray[m_nBpaGenMonNum++], &sBuf, sizeof(tagBpaGenMonitor));
	}
#endif
}

void CPG2BpaFileApi::DelBpaGenMonitor(const int nIndex)
{
#ifdef PG2BPAAPI_USING_STL
	m_MonGenArray.erase(m_MonGenArray.begin()+nIndex);
#else
	register int	i;
	for (i=nIndex; i<m_nBpaGenMonNum-1; i++)
		memcpy(&m_MonGenArray[i], &m_MonGenArray[i+1], sizeof(tagBpaGenMonitor));
	m_nBpaGenMonNum--;
#endif
}

int CPG2BpaFileApi::GetBpaLineMonitorNum()
{
#ifdef PG2BPAAPI_USING_STL
	return (int)m_MonLineArray.size();
#else
	return m_nBpaLineMonNum;
#endif
}

void CPG2BpaFileApi::AddBpaLineMonitor(tagBpaLineMonitor& sBuf)
{
	register int	i;
	int	nExist = -1;
#ifdef PG2BPAAPI_USING_STL
	for (i=0; i<(int)m_MonLineArray.size(); i++)
	{
		if (stricmp(m_MonLineArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonLineArray[nExist], &sBuf, sizeof(tagBpaLineMonitor));
	else
		m_MonLineArray.push_back(sBuf);
#else
	for (i=0; i<m_nBpaLineMonNum; i++)
	{
		if (stricmp(m_MonLineArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonLineArray[nExist], &sBuf, sizeof(tagBpaLineMonitor));
	else
	{
		if (m_nBpaLineMonNum < ConstMaxLineMonitor-1)
			memcpy(&m_MonLineArray[m_nBpaLineMonNum++], &sBuf, sizeof(tagBpaLineMonitor));
	}
#endif
}

void CPG2BpaFileApi::DelBpaLineMonitor(const int nIndex)
{
#ifdef PG2BPAAPI_USING_STL
	m_MonLineArray.erase(m_MonLineArray.begin()+nIndex);
#else
	register int	i;
	for (i=nIndex; i<m_nBpaLineMonNum-1; i++)
		memcpy(&m_MonLineArray[i], &m_MonLineArray[i+1], sizeof(tagBpaLineMonitor));
	m_nBpaLineMonNum--;
#endif
}

int CPG2BpaFileApi::GetBpaTranMonitorNum()
{
#ifdef PG2BPAAPI_USING_STL
	return (int)m_MonTranArray.size();
#else
	return m_nBpaTranMonNum;
#endif
}

void CPG2BpaFileApi::AddBpaTranMonitor(tagBpaTranMonitor& sBuf)
{
	register int	i;
	int	nExist = -1;
#ifdef PG2BPAAPI_USING_STL
	for (i=0; i<(int)m_MonTranArray.size(); i++)
	{
		if (stricmp(m_MonTranArray[i].szDevSub, sBuf.szDevSub) == 0 &&
			stricmp(m_MonTranArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonTranArray[nExist], &sBuf, sizeof(tagBpaTranMonitor));
	else
		m_MonTranArray.push_back(sBuf);
#else
	for (i=0; i<m_nBpaTranMonNum; i++)
	{
		if (stricmp(m_MonTranArray[i].szDevSub, sBuf.szDevSub) == 0 &&
			stricmp(m_MonTranArray[i].szDevName, sBuf.szDevName) == 0)
		{
			nExist = i;
			break;
		}
	}
	if (nExist >= 0)
		memcpy(&m_MonTranArray[nExist], &sBuf, sizeof(tagBpaTranMonitor));
	else
	{
		if (m_nBpaTranMonNum < ConstMaxTranMonitor-1)
			memcpy(&m_MonTranArray[m_nBpaTranMonNum++], &sBuf, sizeof(tagBpaTranMonitor));
	}
#endif
};

void CPG2BpaFileApi::DelBpaTranMonitor(const int nIndex)
{
#ifdef PG2BPAAPI_USING_STL
	m_MonTranArray.erase(m_MonTranArray.begin()+nIndex);
#else
	register int	i;
	for (i=nIndex; i<m_nBpaTranMonNum-1; i++)
		memcpy(&m_MonTranArray[i], &m_MonTranArray[i+1], sizeof(tagBpaTranMonitor));
	m_nBpaTranMonNum--;
#endif
}

int CPG2BpaFileApi::GetBpaStaticLoadModelNum()
{
#ifdef PG2BPAAPI_USING_STL
	return (int)m_LoadSModelArray.size();
#else
	return m_nBpaLoadSModelNum;
#endif
}

void CPG2BpaFileApi::AddBpaStaticLoadModel(tagBpaStaticLoadModel& sBuf)
{
	register int	i;
	unsigned char	bExist = 0;
#ifdef PG2BPAAPI_USING_STL
	for (i=0; i<(int)m_LoadSModelArray.size(); i++)
	{
		if (stricmp(sBuf.szName, m_LoadSModelArray[i].szName) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		m_LoadSModelArray.push_back(sBuf);
#else
	for (i=0; i<m_nBpaLoadSModelNum; i++)
	{
		if (stricmp(sBuf.szName, m_LoadSModelArray[i].szName) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist && m_nBpaLoadSModelNum < ConstMaxLoadSModel-1)
		memcpy(&m_LoadSModelArray[m_nBpaLoadSModelNum++], &sBuf, sizeof(tagBpaStaticLoadModel));
#endif
}

void CPG2BpaFileApi::DelBpaStaticLoadModel(const int nIndex)
{
#ifdef PG2BPAAPI_USING_STL
	m_LoadSModelArray.erase(m_LoadSModelArray.begin()+nIndex);
#else
	register int	i;
	for (i=nIndex; i<m_nBpaLoadSModelNum-1; i++)
		memcpy(&m_LoadSModelArray[i], &m_LoadSModelArray[i+1], sizeof(tagBpaStaticLoadModel));
	m_nBpaLoadSModelNum--;
#endif
}

std::string	CPG2BpaFileApi::FormGenPGAlias(tagPGBlock* pPGBlock, const int nDev)
{
	std::string	strBuffer="�����-";
	strBuffer.append(pPGBlock->m_SynchronousMachineArray[nDev].szSub).append(".");
	strBuffer.append(pPGBlock->m_SynchronousMachineArray[nDev].szVolt).append(".");
	strBuffer.append(pPGBlock->m_SynchronousMachineArray[nDev].szName);

	return strBuffer;
}

std::string	CPG2BpaFileApi::FormLoadPGAlias(tagPGBlock* pPGBlock, const int nDev)
{
	std::string	strBuffer="����-";
	strBuffer.append(pPGBlock->m_EnergyConsumerArray[nDev].szSub).append(".");
	strBuffer.append(pPGBlock->m_EnergyConsumerArray[nDev].szVolt).append(".");
	strBuffer.append(pPGBlock->m_EnergyConsumerArray[nDev].szName);

	return strBuffer;
}

std::string	CPG2BpaFileApi::FormPShuntPGAlias(tagPGBlock* pPGBlock, const int nDev)
{
	std::string	strBuffer="����-";
	strBuffer.append(pPGBlock->m_ShuntCompensatorArray[nDev].szSub).append(".");
	strBuffer.append(pPGBlock->m_ShuntCompensatorArray[nDev].szVolt).append(".");
	strBuffer.append(pPGBlock->m_ShuntCompensatorArray[nDev].szName);

	return strBuffer;
}

std::string	CPG2BpaFileApi::FormSShuntPGAlias(tagPGBlock* pPGBlock, const int nDev, const unsigned char nSide)
{
	std::string	strBuffer="����-";
	strBuffer.append(pPGBlock->m_SeriesCompensatorArray[nDev].szSub).append(".");
	strBuffer.append(pPGBlock->m_SeriesCompensatorArray[nDev].szVolt).append(".");
	strBuffer.append(pPGBlock->m_SeriesCompensatorArray[nDev].szName);

	if (nSide == 0)
		strBuffer.append("@I");
	else
		strBuffer.append("@Z");

	return strBuffer;
}

std::string	CPG2BpaFileApi::FormLinePGAlias(tagPGBlock* pPGBlock, const int nDev, const unsigned char nSide)
{
	std::string	strBuffer="��·-";
	strBuffer.append(pPGBlock->m_ACLineSegmentArray[nDev].szName);

	if (nSide == 0)
		strBuffer.append("@I");
	else
		strBuffer.append("@Z");

	return strBuffer;
}

std::string	CPG2BpaFileApi::FormTranPGAlias(tagPGBlock* pPGBlock, const int nDev, const unsigned char nSide)
{
	std::string	strBuffer="����-";
	strBuffer.append(pPGBlock->m_TransformerWindingArray[nDev].szSub).append(".");
	strBuffer.append(pPGBlock->m_TransformerWindingArray[nDev].szName);

	if (nSide == 0)
		strBuffer.append("@I");
	else
		strBuffer.append("@Z");

	return strBuffer;
}

void CPG2BpaFileApi::ResolveNumericString(const char* lpszString, char* lpszRetString)
{
	register int	i;
	int	nChar=0;

	i=0;
	while (i < (int)strlen(lpszString))
	{
		if (isascii(lpszString[i]))
		{
			if (isdigit(lpszString[i]) || lpszString[i] == '.' || lpszString[i] == '-')
			{
				lpszRetString[nChar++]=lpszString[i];
			}
			i++;
		}
		else
		{
			i++;
			i++;
		}
	}
	lpszRetString[nChar++]='\0';
}

void CPG2BpaFileApi::GetGenIDArray(tagPGBlock* pPGBlock, std::vector<char>& cIDArray)
{
	register int	i;
	int		nLine;
	char	cID;
	unsigned char	bExist;

	cIDArray.resize(pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);
	for (nLine=0; nLine<(int)cIDArray.size(); nLine++)
		cIDArray[nLine]=' ';

	for (nLine=0; nLine<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nLine++)
	{
		if (cIDArray[nLine] != ' ')
			continue;

		bExist=0;
		for (i=nLine+1; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[nLine].nTopoBus == pPGBlock->m_SynchronousMachineArray[i].nTopoBus)
			{
				bExist=1;
				break;
			}
		}

		if (bExist)
		{
			cID='1';
			for (i=nLine; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nLine].nTopoBus == pPGBlock->m_SynchronousMachineArray[i].nTopoBus)
					cIDArray[i]=cID++;
			}
		}
	}
}

void CPG2BpaFileApi::GetLineLoopArray(tagPGBlock* pPGBlock, std::vector<char>& cLoopArray)
{
	register int	i;
	int		nLine;
	char	cLoop;
	unsigned char	bExist;

	cLoopArray.resize(pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (nLine=0; nLine<(int)cLoopArray.size(); nLine++)
		cLoopArray[nLine]=' ';

	for (nLine=0; nLine<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		if (cLoopArray[nLine] != ' ')
			continue;

		bExist=0;
		for (i=nLine+1; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ ||
				pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI)
			{
				bExist=1;
				break;
			}
		}

		if (bExist)
		{
			cLoop='1';
			for (i=nLine; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
			{
				if (pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ ||
					pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI)
					cLoopArray[i]=cLoop++;
			}
		}
	}
}

void CPG2BpaFileApi::GetSCapLoopArray(tagPGBlock* pPGBlock, std::vector<char>& cLoopArray)
{
	register int	i;
	int		nLine;
	char	cLoop;
	unsigned char	bExist;

	cLoopArray.resize(pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]);
	for (nLine=0; nLine<(int)cLoopArray.size(); nLine++)
		cLoopArray[nLine]=' ';

	for (nLine=0; nLine<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nLine++)
	{
		if (cLoopArray[nLine] != ' ')
			continue;

		bExist=0;
		for (i=nLine+1; i<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
		{
			if (pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusI && pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusJ ||
				pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusJ && pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusI)
			{
				bExist=1;
				break;
			}
		}

		if (bExist)
		{
			cLoop='1';
			for (i=nLine; i<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
			{
				if (pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusI && pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusJ ||
					pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusJ && pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ == pPGBlock->m_SeriesCompensatorArray[i].nTopoBusI)
					cLoopArray[i]=cLoop++;
			}
		}
	}
}

void CPG2BpaFileApi::GetTranLoopArray(tagPGBlock* pPGBlock, std::vector<char>& cLoopArray)
{
	register int	i;
	int		nLine;
	char	cLoop;
	unsigned char	bExist;

	cLoopArray.resize(pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	for (nLine=0; nLine<(int)cLoopArray.size(); nLine++)
		cLoopArray[nLine]=' ';

	for (nLine=0; nLine<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nLine++)
	{
		if (cLoopArray[nLine] != ' ')
			continue;

		bExist=0;
		for (i=nLine+1; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		{
			if (pPGBlock->m_TransformerWindingArray[nLine].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusI && pPGBlock->m_TransformerWindingArray[nLine].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ ||
				pPGBlock->m_TransformerWindingArray[nLine].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ && pPGBlock->m_TransformerWindingArray[nLine].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusI)
			{
				bExist=1;
				break;
			}
		}

		if (bExist)
		{
			cLoop='1';
			for (i=nLine; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
			{
				if (pPGBlock->m_TransformerWindingArray[nLine].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusI && pPGBlock->m_TransformerWindingArray[nLine].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ ||
					pPGBlock->m_TransformerWindingArray[nLine].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ && pPGBlock->m_TransformerWindingArray[nLine].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusI)
					cLoopArray[i]=cLoop++;
			}
		}
	}
}

int	CPG2BpaFileApi::FindBusInBArray(const char* lpszBusName, const float fNorminalVolt)
{
	register int	i;
	for (i=0; i<(int)m_BusArray.size(); i++)
	{
		if (stricmp(m_BusArray[i].szName, lpszBusName) == 0 && fabs(m_BusArray[i].fkV-fNorminalVolt) < 0.1)
		{
			return i;
			break;
		}
	}
	return -1;
}

int CPG2BpaFileApi::FindLineInLArray(const char* lpszLineName)
{
	register int	i;
	for (i=0; i<(int)m_LineArray.size(); i++)
	{
		if (stricmp(m_LineArray[i].szAlias, lpszLineName) == 0)
		{
			return i;
			break;
		}
	}
	return -1;
}

int CPG2BpaFileApi::FindTranInTArray(const char* lpszTranName)
{
	register int	i;
	for (i=0; i<(int)m_TranArray.size(); i++)
	{
		if (stricmp(m_TranArray[i].szAlias, lpszTranName) == 0)
		{
			return i;
			break;
		}
	}
	return -1;
}

void CPG2BpaFileApi::FormBArray(tagPGBlock* pPGBlock, const double fGenPQFactor, const double fLoadPQFactor, const double fAutoPVMvaThreshold, const int nIsland)
{
	register int	i;
	int		nDiv, nSub, nVolt, nDev, nSUnit;
	int		nExist;
	tagBpaDat_ACBus	sBusBuf;
	tagBpaSwi_XR	sXRBuf;
	char	szBusName[MDB_CHARLEN_SHORTER];

	std::vector<char>	cGenIDArray;
	GetGenIDArray(pPGBlock, cGenIDArray);

	m_BusArray.clear();
	m_XRArray.clear();

	nSUnit=-1;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
	{
		if (pPGBlock->m_SynchronousMachineArray[i].nIsland != nIsland)
			continue;
		if (strcmp(pPGBlock->m_SynchronousMachineArray[i].szSub, pPGBlock->m_IslandArray[nIsland].szSlackSub) == 0 &&
			strcmp(pPGBlock->m_SynchronousMachineArray[i].szName, pPGBlock->m_IslandArray[nIsland].szSlackGen) == 0)
		{
			nSUnit=i;
			break;
		}
	}
	if (nSUnit < 0)
	{
		double	fGenMax=0;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[i].nIsland != nIsland)
				continue;

			if (fGenMax < pPGBlock->m_SynchronousMachineArray[i].fPMax && fabs(pPGBlock->m_SynchronousMachineArray[i].fPlanP) > 1.0)
			{
				fGenMax=pPGBlock->m_SynchronousMachineArray[i].fPMax;
				nSUnit=i;
			}
		}
	}
	if (nSUnit < 0)
		return;

	{
		nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_SynchronousMachineArray[nSUnit].szSub);
		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SynchronousMachineArray[nSUnit].szSub, pPGBlock->m_SynchronousMachineArray[nSUnit].szVolt);

		nDiv=0;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
			{
				nDiv=i;
				break;
			}
		}

		memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));

		sprintf(szBusName, "B_%d", pPGBlock->m_SynchronousMachineArray[nSUnit].nTopoBus);
		sBusBuf.bGenerator=1;
		strcpy(sBusBuf.szAlias, FormGenPGAlias(pPGBlock, nSUnit).c_str());
		sprintf(sBusBuf.szZone, "%d", nDiv);
		strcpy(sBusBuf.szName, szBusName);
		sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
		sBusBuf.fPmax		=pPGBlock->m_SynchronousMachineArray[nSUnit].fPMax;
		sBusBuf.fQmin		=pPGBlock->m_SynchronousMachineArray[nSUnit].fQMin;
		sBusBuf.fPGen=(float)(pPGBlock->m_SynchronousMachineArray[nSUnit].fPlanP*fGenPQFactor);
		strcpy(sBusBuf.szCardKey, "BS");
		if (pPGBlock->m_SynchronousMachineArray[nSUnit].fPlanV > 0.7 && pPGBlock->m_SynchronousMachineArray[nSUnit].fPlanV < 1.3)
			sBusBuf.fVHold_max=pPGBlock->m_SynchronousMachineArray[nSUnit].fPlanV;
		else
			sBusBuf.fVHold_max=1.0;
		sBusBuf.fQsched_Qmax	=pPGBlock->m_SynchronousMachineArray[nSUnit].fQMax;
		m_BusArray.push_back(sBusBuf);
	}

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_WINDTURBINE]; nDev++)
	{
		if (pPGBlock->m_WindTurbineArray[nDev].nIsland != nIsland)
			continue;
		if (pPGBlock->m_WindTurbineArray[nDev].bOutage != 0)
			continue;

		nDiv=0;
		nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_WindTurbineArray[nDev].szSub);
		if (nSub >= 0)
		{
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					nDiv=i;
					break;
				}
			}
		}

		sprintf(szBusName, "B_%d", pPGBlock->m_WindTurbineArray[nDev].nTopoBus);
		nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		if (nExist < 0)
		{
			memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
			sBusBuf.bGenerator=1;
			strcpy(sBusBuf.szAlias, FormGenPGAlias(pPGBlock, nDev).c_str());

			sprintf(sBusBuf.szZone, "%d", nDiv);
			strcpy(sBusBuf.szName, szBusName);
			sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

			sBusBuf.fPmax		=pPGBlock->m_WindTurbineArray[nDev].fRatedMva;
			sBusBuf.fQmin		=-pPGBlock->m_WindTurbineArray[nDev].fRatedMva/5;

			sBusBuf.fPGen=(float)(pPGBlock->m_WindTurbineArray[nDev].fP*fGenPQFactor);
			strcpy(sBusBuf.szCardKey, "B");
			sBusBuf.fQsched_Qmax=0;
			m_BusArray.push_back(sBusBuf);
		}
		else
		{
			if (nSUnit != nDev)	//	��ֹƽ����������
			{
				m_BusArray[nExist].fPmax		+= pPGBlock->m_WindTurbineArray[nDev].fRatedMva;
				m_BusArray[nExist].fQmin		= min(m_BusArray[nExist].fQmin, -pPGBlock->m_WindTurbineArray[nDev].fRatedMva/5);
				sBusBuf.bGenerator=1;		//	��������
				sBusBuf.fPGen += (float)(pPGBlock->m_WindTurbineArray[nDev].fP*fGenPQFactor);
			}
		}
	}

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_PHOTOVOLTAIC]; nDev++)
	{
		if (pPGBlock->m_PhotoVoltaicArray[nDev].nIsland != nIsland)
			continue;
		if (pPGBlock->m_PhotoVoltaicArray[nDev].bOutage != 0)
			continue;

		nDiv=0;
		nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_WindTurbineArray[nDev].szSub);
		if (nSub >= 0)
		{
			for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
			{
				if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
				{
					nDiv=i;
					break;
				}
			}
		}

		sprintf(szBusName, "B_%d", pPGBlock->m_PhotoVoltaicArray[nDev].nTopoBus);
		nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		if (nExist < 0)
		{
			memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
			sBusBuf.bGenerator=1;
			strcpy(sBusBuf.szAlias, FormGenPGAlias(pPGBlock, nDev).c_str());

			sprintf(sBusBuf.szZone, "%d", nDiv);
			strcpy(sBusBuf.szName, szBusName);
			sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

			sBusBuf.fPmax		=pPGBlock->m_PhotoVoltaicArray[nDev].fRatedMva;
			sBusBuf.fQmin		=-pPGBlock->m_PhotoVoltaicArray[nDev].fRatedMva/5;

			sBusBuf.fPGen=(float)(pPGBlock->m_PhotoVoltaicArray[nDev].fP*fGenPQFactor);
			strcpy(sBusBuf.szCardKey, "B");
			sBusBuf.fQsched_Qmax=0;
			m_BusArray.push_back(sBusBuf);
		}
		else
		{
			if (nSUnit != nDev)	//	��ֹƽ����������
			{
				m_BusArray[nExist].fPmax		+= pPGBlock->m_PhotoVoltaicArray[nDev].fRatedMva;
				m_BusArray[nExist].fQmin		= min(m_BusArray[nExist].fQmin, -pPGBlock->m_PhotoVoltaicArray[nDev].fRatedMva/5);
				sBusBuf.bGenerator=1;		//	��������
				sBusBuf.fPGen += (float)(pPGBlock->m_PhotoVoltaicArray[nDev].fP*fGenPQFactor);
			}
		}
	}

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		nDiv=0;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
			{
				nDiv=i;
				break;
			}
		}

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nDev].nIsland != nIsland)
					continue;

				if (pPGBlock->m_SynchronousMachineArray[nDev].bOutage != 0)
					continue;

				sprintf(szBusName, "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
					sBusBuf.bGenerator=1;
					strcpy(sBusBuf.szAlias, FormGenPGAlias(pPGBlock, nDev).c_str());

					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

					sBusBuf.fPmax		=pPGBlock->m_SynchronousMachineArray[nDev].fPMax;
					sBusBuf.fQmin		=pPGBlock->m_SynchronousMachineArray[nDev].fQMin;

					sBusBuf.fPGen=(float)(pPGBlock->m_SynchronousMachineArray[nDev].fPlanP*fGenPQFactor);
					if (nSUnit == nDev)
					{
						strcpy(sBusBuf.szCardKey, "BS");
						if (pPGBlock->m_SynchronousMachineArray[nDev].fPlanV > 0.7 && pPGBlock->m_SynchronousMachineArray[nDev].fPlanV < 1.3)
							sBusBuf.fVHold_max=pPGBlock->m_SynchronousMachineArray[nDev].fPlanV;
						else
							sBusBuf.fVHold_max=1.0;
						sBusBuf.fQsched_Qmax	=pPGBlock->m_SynchronousMachineArray[nDev].fQMax;
					}
					else if (pPGBlock->m_SynchronousMachineArray[nDev].fPlanV > 0.7 && pPGBlock->m_SynchronousMachineArray[nDev].fPlanV < 1.3)
					{
						strcpy(sBusBuf.szCardKey, "BQ");
						sBusBuf.fVHold_max=pPGBlock->m_SynchronousMachineArray[nDev].fPlanV;
						sBusBuf.fQsched_Qmax	=pPGBlock->m_SynchronousMachineArray[nDev].fQMax;
					}
					else
					{
						if (fAutoPVMvaThreshold > FLT_MIN && pPGBlock->m_SynchronousMachineArray[nDev].fPMax >= fAutoPVMvaThreshold)
						{
							strcpy(sBusBuf.szCardKey, "BQ");
							sBusBuf.fVHold_max=1.0;
							sBusBuf.fQsched_Qmax	=pPGBlock->m_SynchronousMachineArray[nDev].fQMax;
						}
						else
						{
							strcpy(sBusBuf.szCardKey, "B");
							sBusBuf.fQsched_Qmax=(float)(pPGBlock->m_SynchronousMachineArray[nDev].fPlanQ*fGenPQFactor);
						}
					}
					//sBusBuf.fRerr=pPGBlock->m_SynchronousMachineArray[nDev].ri_Rerr;
					//sBusBuf.fTrep=pPGBlock->m_SynchronousMachineArray[nDev].ri_Trep;

					m_BusArray.push_back(sBusBuf);
				}
				else
				{
					if (nSUnit != nDev)	//	��ֹƽ����������
					{
						m_BusArray[nExist].fPmax		+= pPGBlock->m_SynchronousMachineArray[nDev].fPMax;
						m_BusArray[nExist].fQmin		= min(m_BusArray[nExist].fQmin, pPGBlock->m_SynchronousMachineArray[nDev].fQMin);

						sBusBuf.bGenerator=1;		//	��������

						sBusBuf.fPGen += (float)(pPGBlock->m_SynchronousMachineArray[nDev].fPlanP*fGenPQFactor);
						if (stricmp(m_BusArray[nExist].szCardKey, "BQ") == 0 || stricmp(m_BusArray[nExist].szCardKey, "BE") == 0 || stricmp(m_BusArray[nExist].szCardKey, "BS") == 0 ||
							pPGBlock->m_SynchronousMachineArray[nDev].fPlanV > 0.7 && pPGBlock->m_SynchronousMachineArray[nDev].fPlanV < 1.3)
						{
							if (stricmp(m_BusArray[nExist].szCardKey, "B") == 0)
								strcpy(m_BusArray[nExist].szCardKey, "BQ");

							m_BusArray[nExist].fVHold_max=pPGBlock->m_SynchronousMachineArray[nDev].fPlanV;
							m_BusArray[nExist].fQsched_Qmax	+= pPGBlock->m_SynchronousMachineArray[nDev].fQMax;
						}
						else
						{
							m_BusArray[nExist].fQsched_Qmax += pPGBlock->m_SynchronousMachineArray[nDev].fPlanQ;
						}
					}
				}
			}


			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].bOutage != 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;
				if (fabs(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP) < 0.0001 && fabs(pPGBlock->m_EnergyConsumerArray[nDev].fPlanQ) < 0.0001)
					continue;

				memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
				memset(&sXRBuf, 0, sizeof(tagBpaSwi_XR));

				sprintf(szBusName, "B_%d", pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					strcpy(sBusBuf.szAlias, FormLoadPGAlias(pPGBlock, nDev).c_str());

					strcpy(sBusBuf.szCardKey, "B");

					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
					sBusBuf.fLoadP		=(float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*fLoadPQFactor);
					sBusBuf.fLoadQ		=(float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanQ*fLoadPQFactor);

					strcpy(sXRBuf.szCardKey, "XR");
					strcpy(sXRBuf.szName, szBusName);
					sXRBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
					sXRBuf.fX0			=pPGBlock->m_EnergyConsumerArray[nDev].fX0;

					m_BusArray.push_back(sBusBuf);
					m_XRArray.push_back(sXRBuf);

// 					if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus == 7)
// 					{
// 						char	szBuf[260];
// 						PGGetRecordKeyString(pPGBlock, PG_ENERGYCONSUMER, nDev, szBuf);
// 						Log(g_lpszPG2BpaApiLogFile, "�½�7ĸ��: Name = %s Load = %f %f \n", szBuf, sBusBuf.fLoadP, sBusBuf.fLoadQ);
// 					}
				}
				else
				{
					m_BusArray[nExist].fLoadP += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*fLoadPQFactor);
					m_BusArray[nExist].fLoadQ += (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanQ*fLoadPQFactor);

// 					if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus == 7)
// 					{
// 						char	szBuf[260];
// 						PGGetRecordKeyString(pPGBlock, PG_ENERGYCONSUMER, nDev, szBuf);
// 						Log(g_lpszPG2BpaApiLogFile, "׷��7ĸ��: Name = %s Load = %f %f \n", szBuf, m_BusArray[nExist].fLoadP, m_BusArray[nExist].fLoadQ);
// 					}
				}
			}
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nDev++)
			{
				if (pPGBlock->m_ShuntCompensatorArray[nDev].bOutage != 0)
					continue;
				if (pPGBlock->m_ShuntCompensatorArray[nDev].nIsland != nIsland)
					continue;
				if (fabs(pPGBlock->m_ShuntCompensatorArray[nDev].fCap) < 0.1)
					continue;

				memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
				memset(&sXRBuf, 0, sizeof(tagBpaSwi_XR));

				sprintf(szBusName, "B_%d", pPGBlock->m_ShuntCompensatorArray[nDev].nTopoBus);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					strcpy(sBusBuf.szAlias, FormPShuntPGAlias(pPGBlock, nDev).c_str());

					strcpy(sBusBuf.szCardKey, "B");
					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
					sBusBuf.fShuntQ		=pPGBlock->m_ShuntCompensatorArray[nDev].fCap;

					strcpy(sXRBuf.szCardKey, "XR");
					strcpy(sXRBuf.szName, szBusName);
					sXRBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
					sXRBuf.fX0			=pPGBlock->m_ShuntCompensatorArray[nDev].fX0;

					m_BusArray.push_back(sBusBuf);
					m_XRArray.push_back(sXRBuf);
				}
				else
				{
					m_BusArray[nExist].fShuntQ += pPGBlock->m_ShuntCompensatorArray[nDev].fCap;
				}
			}
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSeriesCompensatorRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSeriesCompensatorRange; nDev++)
			{
				if (pPGBlock->m_SeriesCompensatorArray[nDev].bOutage != 0)
					continue;
				if (pPGBlock->m_SeriesCompensatorArray[nDev].nIsland != nIsland)
					continue;
				//if (fabs(pPGBlock->m_SeriesCompensatorArray[nDev].x) < 0.1)
				//	continue;

				sprintf(szBusName, "B_%d", pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));

					strcpy(sBusBuf.szAlias, FormSShuntPGAlias(pPGBlock, nDev, 0).c_str());

					strcpy(sBusBuf.szCardKey, "B");

					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

					m_BusArray.push_back(sBusBuf);
				}

				sprintf(szBusName, "B_%d", pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));

					strcpy(sBusBuf.szAlias, FormSShuntPGAlias(pPGBlock, nDev, 1).c_str());

					strcpy(sBusBuf.szCardKey, "B");

					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

					m_BusArray.push_back(sBusBuf);
				}
			}
		}
	}

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		nDiv=0;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
			{
				nDiv=i;
				break;
			}
		}

		for (nDev=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			if (pPGBlock->m_TransformerWindingArray[nDev].bOutage != 0)
				continue;
			if (pPGBlock->m_TransformerWindingArray[nDev].nIsland != nIsland)
				continue;

			nVolt=pPGBlock->m_TransformerWindingArray[nDev].nVoltI;
			if (nVolt >= 0)
			{
				sprintf(szBusName, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusI);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
					strcpy(sBusBuf.szAlias, FormTranPGAlias(pPGBlock, nDev, 0).c_str());

					strcpy(sBusBuf.szCardKey, "B");

					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

					m_BusArray.push_back(sBusBuf);
				}
			}

			nVolt=pPGBlock->m_TransformerWindingArray[nDev].nVoltJ;
			if (nVolt >= 0)
			{
				sprintf(szBusName, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusJ);
				nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (nExist < 0)
				{
					memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
					strcpy(sBusBuf.szCardKey, "B");

					strcpy(sBusBuf.szAlias, FormTranPGAlias(pPGBlock, nDev, 1).c_str());

					sprintf(sBusBuf.szZone, "%d", nDiv);
					strcpy(sBusBuf.szName, szBusName);
					sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

					m_BusArray.push_back(sBusBuf);
				}
			}
		}
	}

	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (pPGBlock->m_ACLineSegmentArray[nDev].bOutage != 0)
			continue;
		if (pPGBlock->m_ACLineSegmentArray[nDev].nIsland != nIsland)
			continue;

		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (nVolt < 0)
			continue;

		sprintf(szBusName, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI);
		nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		if (nExist < 0)
		{
			nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ACLineSegmentArray[nDev].szSubI);
			if (nSub >= 0)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
				{
					if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
					{
						nDiv=i;
						break;
					}
				}
				memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
				strcpy(sBusBuf.szCardKey, "B");
				strcpy(sBusBuf.szAlias, FormLinePGAlias(pPGBlock, nDev, 0).c_str());

				sprintf(sBusBuf.szZone, "%d", nDiv);
				strcpy(sBusBuf.szName, szBusName);
				sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

				m_BusArray.push_back(sBusBuf);
			}
		}

		sprintf(szBusName, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ);
		nExist=FindBusInBArray(szBusName, pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		if (nExist < 0)
		{
			nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ACLineSegmentArray[nDev].szSubJ);
			if (nSub >= 0)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
				{
					if (strcmp(pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, pPGBlock->m_SubcontrolAreaArray[i].szName) == 0)
					{
						nDiv=i;
						break;
					}
				}
				memset(&sBusBuf, 0, sizeof(tagBpaDat_ACBus));
				strcpy(sBusBuf.szCardKey, "B");
				strcpy(sBusBuf.szAlias, FormLinePGAlias(pPGBlock, nDev, 1).c_str());

				sprintf(sBusBuf.szZone, "%d", nDiv);
				strcpy(sBusBuf.szName, szBusName);
				sBusBuf.fkV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

				m_BusArray.push_back(sBusBuf);
			}
		}
	}

	cGenIDArray.clear();
}

void CPG2BpaFileApi::FormLArray(tagPGBlock* pPGBlock, const int nIsland)
{
	int		nVolt, nLine;
	tagBpaDat_ACLine	sLineBuf;
	tagBpaSwi_LO		sLOBuf;

	std::vector<char>	cLineLoopArray, cSCapLoopArray;
	GetLineLoopArray(pPGBlock, cLineLoopArray);
	GetSCapLoopArray(pPGBlock, cSCapLoopArray);

	m_LineArray.clear();
	m_LOArray.clear();
	for (nLine=0; nLine<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nLine++)
	{
		if (pPGBlock->m_ACLineSegmentArray[nLine].bOutage != 0)
			continue;
		if (pPGBlock->m_ACLineSegmentArray[nLine].nIsland != nIsland)
			continue;

		memset(&sLineBuf, 0, sizeof(tagBpaDat_ACLine));

		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nLine].szSubI, pPGBlock->m_ACLineSegmentArray[nLine].szVoltI);

		strcpy(sLineBuf.szCardKey, "L");
		sprintf(sLineBuf.szBusI, "B_%d", pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI);
		sprintf(sLineBuf.szBusJ, "B_%d", pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ);
		sLineBuf.fkVI=sLineBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
		sLineBuf.fAMP=pPGBlock->m_ACLineSegmentArray[nLine].fRatedCur;
		sLineBuf.fR=pPGBlock->m_ACLineSegmentArray[nLine].fR;
		sLineBuf.fX=pPGBlock->m_ACLineSegmentArray[nLine].fX;
		sLineBuf.fB1=pPGBlock->m_ACLineSegmentArray[nLine].fB;
		sLineBuf.cLoop=cLineLoopArray[nLine];
		strcpy(sLineBuf.szAlias, pPGBlock->m_ACLineSegmentArray[nLine].szName);
		if (sqrt(sLineBuf.fR*sLineBuf.fR+sLineBuf.fX*sLineBuf.fX) < 0.00001)
			sLineBuf.fX=0.0001f;
		strcpy(sLineBuf.szAlias, pPGBlock->m_ACLineSegmentArray[nLine].szName);

		strcpy(sLOBuf.szCardKey, "LO");
		sprintf(sLOBuf.szBusI, "B_%d", pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI);
		sprintf(sLOBuf.szBusJ, "B_%d", pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ);
		sLOBuf.fkVI=sLOBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
		sLOBuf.fR0=pPGBlock->m_ACLineSegmentArray[nLine].fR0;
		sLOBuf.fX0=pPGBlock->m_ACLineSegmentArray[nLine].fX0;
		sLOBuf.cLoop=cLineLoopArray[nLine];

		m_LineArray.push_back(sLineBuf);
		m_LOArray.push_back(sLOBuf);
	}

	for (nLine=0; nLine<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nLine++)
	{
		if (pPGBlock->m_SeriesCompensatorArray[nLine].bOutage != 0)
			continue;
		if (pPGBlock->m_SeriesCompensatorArray[nLine].nIsland != nIsland)
			continue;
		if (pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI == pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ)
			continue;

		memset(&sLineBuf, 0, sizeof(tagBpaDat_ACLine));

		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SeriesCompensatorArray[nLine].szSub, pPGBlock->m_SeriesCompensatorArray[nLine].szVolt);

		strcpy(sLineBuf.szCardKey, "L");
		sprintf(sLineBuf.szBusI, "B_%d", pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI);
		sprintf(sLineBuf.szBusJ, "B_%d", pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ);
		sLineBuf.fkVI=sLineBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
		//sLineBuf.fAMP=pPGBlock->m_SeriesCompensatorArray[nLine].fRatedCur;
		sLineBuf.fR=pPGBlock->m_SeriesCompensatorArray[nLine].fR;
		sLineBuf.fX=pPGBlock->m_SeriesCompensatorArray[nLine].fX;
		sLineBuf.cLoop=cSCapLoopArray[nLine];
		strcpy(sLineBuf.szAlias, pPGBlock->m_SeriesCompensatorArray[nLine].szName);
		if (sqrt(sLineBuf.fR*sLineBuf.fR+sLineBuf.fX*sLineBuf.fX) < 0.00001)
			sLineBuf.fX=0.0001f;
		sprintf(sLineBuf.szAlias, "%s.%s.%s", pPGBlock->m_SeriesCompensatorArray[nLine].szSub, pPGBlock->m_SeriesCompensatorArray[nLine].szVolt, pPGBlock->m_SeriesCompensatorArray[nLine].szName);

		strcpy(sLOBuf.szCardKey, "LO");
		sprintf(sLOBuf.szBusI, "B_%d", pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusI);
		sprintf(sLOBuf.szBusJ, "B_%d", pPGBlock->m_SeriesCompensatorArray[nLine].nTopoBusJ);
		sLOBuf.fkVI=sLOBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
		sLOBuf.fX0=pPGBlock->m_SeriesCompensatorArray[nLine].fX0;
		sLOBuf.cLoop=cSCapLoopArray[nLine];

		m_LineArray.push_back(sLineBuf);
		m_LOArray.push_back(sLOBuf);
	}

	cLineLoopArray.clear();
	cSCapLoopArray.clear();
}

void CPG2BpaFileApi::FormTArray(tagPGBlock* pPGBlock, const int nIsland)
{
	int		nSub, nTran;
	int		nVoltI, nVoltZ, nTapI, nTapJ;
	float	fIT, fZT, fIV, fZV;
	tagBpaDat_Wind	sWindBuf;
	tagBpaSwi_XO	sXOBuf;

	std::vector<char>	cTranLoopArray;
	GetTranLoopArray(pPGBlock, cTranLoopArray);

	m_TranArray.clear();
	m_XOArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nTran=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nTran<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nTran++)
		{
			if (pPGBlock->m_TransformerWindingArray[nTran].bOutage != 0)
				continue;
			if (pPGBlock->m_TransformerWindingArray[nTran].nIsland != nIsland)
				continue;

			nVoltI=pPGBlock->m_TransformerWindingArray[nTran].nVoltI;
			nVoltZ=pPGBlock->m_TransformerWindingArray[nTran].nVoltJ;
			if (nVoltI < 0 || nVoltZ < 0)
				continue;

			memset(&sWindBuf, 0, sizeof(tagBpaDat_Wind));
			memset(&sXOBuf, 0, sizeof(tagBpaSwi_XO));

			strcpy(sWindBuf.szCardKey, "T");
			sprintf(sWindBuf.szBusI, "B_%d", pPGBlock->m_TransformerWindingArray[nTran].nTopoBusI);
			sprintf(sWindBuf.szBusJ, "B_%d", pPGBlock->m_TransformerWindingArray[nTran].nTopoBusJ);
			sWindBuf.fkVI=pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage;
			sWindBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage;
			sWindBuf.fMVA=pPGBlock->m_TransformerWindingArray[nTran].fRatedMva;
			sWindBuf.fR=pPGBlock->m_TransformerWindingArray[nTran].fR;
			sWindBuf.fX=pPGBlock->m_TransformerWindingArray[nTran].fX;
			sWindBuf.fB=pPGBlock->m_TransformerWindingArray[nTran].fB;

			nTapI=pPGBlock->m_TransformerWindingArray[nTran].nTapChangerI;
			nTapJ=pPGBlock->m_TransformerWindingArray[nTran].nTapChangerJ;
			if (nTapI < 0) nTapI=0;
			if (nTapJ < 0) nTapJ=0;

			fIV=pPGBlock->m_TransformerWindingArray[nTran].fRatedkVI;
			fZV=pPGBlock->m_TransformerWindingArray[nTran].fRatedkVJ;
			if (pPGBlock->m_TapChangerArray[nTapI].nTapMax != pPGBlock->m_TapChangerArray[nTapI].nTapMin && fabs(pPGBlock->m_TapChangerArray[nTapI].fTapStep) > 0)
			{
				if (pPGBlock->m_TransformerWindingArray[nTran].nTapI > pPGBlock->m_TapChangerArray[nTapI].nTapMax)
					pPGBlock->m_TransformerWindingArray[nTran].nTapI=pPGBlock->m_TapChangerArray[nTapI].nTapMax;
				if (pPGBlock->m_TransformerWindingArray[nTran].nTapI < pPGBlock->m_TapChangerArray[nTapI].nTapMin)
					pPGBlock->m_TransformerWindingArray[nTran].nTapI=pPGBlock->m_TapChangerArray[nTapI].nTapMin;
				fIT=1+(pPGBlock->m_TapChangerArray[nTapI].fTapStep/100.0f)*(pPGBlock->m_TransformerWindingArray[nTran].nTapI -pPGBlock->m_TapChangerArray[nTapI].nTapNom);
				fIV=fIT*pPGBlock->m_TransformerWindingArray[nTran].fRatedkVI;
			}
			if (pPGBlock->m_TapChangerArray[nTapJ].nTapMax != pPGBlock->m_TapChangerArray[nTapJ].nTapMin && fabs(pPGBlock->m_TapChangerArray[nTapJ].fTapStep) > 0)
			{
				if (pPGBlock->m_TransformerWindingArray[nTran].nTapJ > pPGBlock->m_TapChangerArray[nTapJ].nTapMax)
					pPGBlock->m_TransformerWindingArray[nTran].nTapJ=pPGBlock->m_TapChangerArray[nTapJ].nTapMax;
				if (pPGBlock->m_TransformerWindingArray[nTran].nTapJ < pPGBlock->m_TapChangerArray[nTapJ].nTapMin)
					pPGBlock->m_TransformerWindingArray[nTran].nTapJ=pPGBlock->m_TapChangerArray[nTapJ].nTapMin;
				fZT=1+(pPGBlock->m_TapChangerArray[nTapJ].fTapStep/100.0f)*(pPGBlock->m_TransformerWindingArray[nTran].nTapJ-pPGBlock->m_TapChangerArray[nTapJ].nTapNom);
				fZV=fZT*pPGBlock->m_TransformerWindingArray[nTran].fRatedkVJ;
			}

			if (fIV > 1.25*pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage || fIV < 0.8*pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage)
				fIV=pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage;

			if (fZV > 1.25*pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage || fZV < 0.8*pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage)
				fZV=pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage;

			sWindBuf.fTPI=fIV;
			sWindBuf.fTPJ=fZV;
			sWindBuf.cLoop=cTranLoopArray[nTran];
			if (sqrt(sWindBuf.fR*sWindBuf.fR+sWindBuf.fX*sWindBuf.fX) < 0.0001)
				sWindBuf.fX=0.001f;

			sprintf(sWindBuf.szAlias, "%s.%s", pPGBlock->m_TransformerWindingArray[nTran].szSub, pPGBlock->m_TransformerWindingArray[nTran].szName);

			strcpy(sXOBuf.szCardKey, "XO");
			sprintf(sXOBuf.szBusI, "B_%d", pPGBlock->m_TransformerWindingArray[nTran].nTopoBusI);
			sprintf(sXOBuf.szBusJ, "B_%d", pPGBlock->m_TransformerWindingArray[nTran].nTopoBusJ);
			sXOBuf.fkVI=pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage;
			sXOBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVoltZ].nominalVoltage;
			sXOBuf.cLoop=cTranLoopArray[nTran];
			if (pPGBlock->m_TransformerWindingArray[nTran].bNeutralStatus == 0)
			{
				if (pPGBlock->m_TransformerWindingArray[nTran].nWindingType == PGEnumTransformerWinding_WindConnectio_2WYY ||
					pPGBlock->m_TransformerWindingArray[nTran].nWindingType == PGEnumTransformerWinding_WindConnectio_3WY ||
					pPGBlock->m_TransformerWindingArray[nTran].nWindingType == PGEnumTransformerWinding_WindConnectio_3WAuto)	//	Y/Y���ߣ����Ե�ӵ�
				{
					sXOBuf.bSID=3;
					sXOBuf.fR0=pPGBlock->m_TransformerWindingArray[nTran].fR0;
					sXOBuf.fX0=pPGBlock->m_TransformerWindingArray[nTran].fX0;
				}
				else if (pPGBlock->m_TransformerWindingArray[nTran].nWindingType == PGEnumTransformerWinding_WindConnectio_2WYD ||
					pPGBlock->m_TransformerWindingArray[nTran].nWindingType == PGEnumTransformerWinding_WindConnectio_3WD)	//	Y/D���ߣ����Ե�ӵ�
				{
					if (pPGBlock->m_PowerTransformerArray[pPGBlock->m_TransformerWindingArray[nTran].nTran].nWindNum == 3)
						sXOBuf.bSID=(pPGBlock->m_TransformerWindingArray[nTran].bTranMidSide == 1) ? 2 : 1;
					else
						sXOBuf.bSID=(pPGBlock->m_TransformerWindingArray[nTran].fRatedkVI > pPGBlock->m_TransformerWindingArray[nTran].fRatedkVJ) ? 1 : 2;
					sXOBuf.fR0=pPGBlock->m_TransformerWindingArray[nTran].fR0;
					sXOBuf.fX0=pPGBlock->m_TransformerWindingArray[nTran].fX0;
				}
			}


			m_TranArray.push_back(sWindBuf);
			m_XOArray.push_back(sXOBuf);
		}
	}

	cTranLoopArray.clear();
}

void CPG2BpaFileApi::AddUniqueString(std::vector<std::string>& strStringArray, const std::string strString)
{
	register int	i;
	for (i=0; i<(int)strStringArray.size(); i++)
	{
		if (stricmp(strStringArray[i].c_str(), strString.c_str()) == 0)
			return;
	}
	strStringArray.push_back(strString);
}
