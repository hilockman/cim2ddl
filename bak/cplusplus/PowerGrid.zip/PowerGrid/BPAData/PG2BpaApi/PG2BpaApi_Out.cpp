#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"
#include "../../../Common/String2Double.hpp"

static	int	nVCurveNameArray[]=
{
	12 -1, 24 -1, 
	28 -1, 40 -1, 
	44 -1, 56 -1, 
	60 -1, 72 -1, 
	76 -1, 88 -1, 
	92 -1, 104-1, 
	108-1, 120-1, 
	124-1, 136-1, 
	140-1, 152-1, 
	156-1, 168-1, 
	172-1, 184-1, 
};

void CPG2BpaFileApi::ResolveGenName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszBusName, const char* lpszBusVolt, char* lpszCurveName)
{
	int		nSub, nVolt, nDev;
	char	cPGID;
	char	szBuf[260];

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nDev].nIsland != nIsland)
					continue;

				cPGID=ResolveGenID(pPGBlock, nDev);
				sprintf(szBuf, "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
				if (stricmp(lpszBusName, szBuf) == 0 && fabs(atof(lpszBusVolt)-pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage) < 0.1)
				{
					sprintf(lpszCurveName, "�����[%s %s %s]", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szVolt, pPGBlock->m_SynchronousMachineArray[nDev].szName);
					return;
				}
			}
		}
	}
}

void CPG2BpaFileApi::ResolveBusName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszBusName, const char* lpszBusVolt, char* lpszCurveName)
{
	int		nSub, nVolt, nDev;
	int		nObj;
	unsigned char	bObj;
	unsigned char	bFind;
	char	szBuf[260];
	std::string	strBusName;

	strBusName="ĸ��[";

	bFind=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				if (pPGBlock->m_BusbarSectionArray[nDev].nIsland != nIsland)
					continue;

				if (pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nDev].nNode].nTopoBus < 3)
					continue;

				sprintf(szBuf, "B_%d", pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nDev].nNode].nTopoBus);
				if (stricmp(lpszBusName, szBuf) != 0 || fabs(atof(lpszBusVolt)-pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage) > 0.1)
					continue;

				bObj=0;
				for (nObj=0; nObj<GetBpaBusMonitorNum(); nObj++)
				{
					if (stricmp(pPGBlock->m_SubstationArray[nSub].szName, m_MonBusArray[nObj].szDevSub) == 0 &&
						stricmp(pPGBlock->m_VoltageLevelArray[nVolt].szName, m_MonBusArray[nObj].szDevVolt) == 0 &&
						stricmp(pPGBlock->m_BusbarSectionArray[nDev].szName, m_MonBusArray[nObj].szDevName) == 0)
					{
						bObj=1;
						break;
					}
				}
				if (bObj)
				{
					if (bFind)
						strBusName.append(", ");
					sprintf(szBuf, "%s %s %s", pPGBlock->m_BusbarSectionArray[nDev].szSub, pPGBlock->m_BusbarSectionArray[nDev].szVolt, pPGBlock->m_BusbarSectionArray[nDev].szName);
					strBusName.append(szBuf);
					bFind=1;
				}
			}
			if (bFind)	break;
		}
		if (bFind)	break;
	}

	strBusName.append("]");
	if (bFind)
		strcpy(lpszCurveName, strBusName.c_str());
}

void CPG2BpaFileApi::ResolveBranName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszBus1Name, const char* lpszBus1Volt, const char* lpszBus2Name, const char* lpszBus2Volt, char cLoop, char* lpszCurveName)
{
	register int	i;
	int		nSub, nDev;
	char	szBuf[260];

	for (i=0; i<(int)m_LineArray.size(); i++)
	{
		if ((stricmp(m_LineArray[i].szBusI, lpszBus1Name) == 0 && stricmp(m_LineArray[i].szBusJ, lpszBus2Name) == 0 ||
			stricmp(m_LineArray[i].szBusI, lpszBus2Name) == 0 && stricmp(m_LineArray[i].szBusJ, lpszBus1Name) == 0) &&
			m_LineArray[i].cLoop == cLoop)
		{
			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
			{
				if (stricmp(m_LineArray[i].szAlias, pPGBlock->m_ACLineSegmentArray[nDev].szName) == 0)
				{
					sprintf(lpszCurveName, "��·[%s]", pPGBlock->m_ACLineSegmentArray[nDev].szName);
					return;
				}
			}
		}
	}
	for (i=0; i<(int)m_TranArray.size(); i++)
	{
		if ((stricmp(m_TranArray[i].szBusI, lpszBus1Name) == 0 && stricmp(m_TranArray[i].szBusJ, lpszBus2Name) == 0 ||
			stricmp(m_TranArray[i].szBusI, lpszBus2Name) == 0 && stricmp(m_TranArray[i].szBusJ, lpszBus1Name) == 0) &&
			m_TranArray[i].cLoop == cLoop)
		{
			for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
			{
				for (nDev=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
				{
					sprintf(szBuf, "%s.%s", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);
					if (stricmp(m_TranArray[i].szAlias, szBuf) == 0)
					{
						sprintf(lpszCurveName, "��ѹ��[%s %s]", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);
						return;
					}
				}
			}
		}
	}
}

void CPG2BpaFileApi::ResolveCurveName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine, char* lpszCurveName)
{
	register int	i;
	int		nObj;
	unsigned char	bObj;
	char	szCurveName[260];

	memset(szCurveName, 0, 260);

	bObj=0;
	nObj=0;
	for (i=0; i<(int)strlen(lpszLine); i++)
	{
		if (lpszLine[i] == '\"')
		{
			if (bObj == 0)
			{
				nObj=0;
				bObj=1;
				continue;
			}
			else
			{
				break;
			}
		}
		if (bObj)	szCurveName[nObj++]=lpszLine[i];
	}
	szCurveName[nObj]='\0';

	strcpy(lpszCurveName, szCurveName);

	char	cOutID;
	char*	lpszToken;
	std::string	strBusName;
	std::vector<std::string>	strEleArray;
	strEleArray.clear();

	if (strstr(lpszLine, "�����") != NULL || strstr(lpszLine, "��·") != NULL)
	{
		cOutID=szCurveName[strlen(szCurveName)-1];
		szCurveName[strlen(szCurveName)-1]='\0';
	}
	lpszToken=strtok(szCurveName, " \t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	//for (i=0; i<strEleArray.size(); i++)
	//	Log(g_lpszPG2BpaApiLogFile, "Ele[%d/%d]=%s\n", i, strEleArray.size(), strEleArray[i].c_str());

	FormLArray(pPGBlock, nIsland);
	FormTArray(pPGBlock, nIsland);
	if (strstr(lpszLine, "�����") != NULL)
	{
		if (strEleArray.size() >= 2)
			ResolveGenName(pPGBlock, nIsland, strEleArray[0].c_str(), strEleArray[1].c_str(), lpszCurveName);
	}
	else if (strstr(lpszLine, "�ڵ�") != NULL)
	{
		if (strEleArray.size() >= 2)
			ResolveBusName(pPGBlock, nIsland, strEleArray[0].c_str(), strEleArray[1].c_str(), lpszCurveName);
	}
	else if (strstr(lpszLine, "��·") != NULL)
	{
		if (strEleArray.size() >= 4)
			ResolveBranName(pPGBlock, nIsland, strEleArray[0].c_str(), strEleArray[1].c_str(), strEleArray[2].c_str(), strEleArray[3].c_str(), cOutID, lpszCurveName);
	}
}

void CPG2BpaFileApi::ResolveVCurveName(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine, std::vector<tagSimpleCurve>& crvArray)
{
	unsigned char	bFlag;
	int		nCurve, nChar, nNameLen, nVoltLen;
	char	szBusName[MDB_CHARLEN_SHORTER], szBusVolt[MDB_CHARLEN_SHORTER], szCurve[260];
	tagSimpleCurve	crvBuf;

	crvArray.clear();
	crvBuf.sDataArray.clear();

	for (nCurve=0; nCurve<sizeof(nVCurveNameArray)/sizeof(int)/2; nCurve++)
	{
		nChar=nVCurveNameArray[2*nCurve+0];
		if (nChar >= (int)strlen(lpszLine))
			break;

		memset(szBusName, 0, MDB_CHARLEN_SHORTER);
		memset(szBusVolt, 0, MDB_CHARLEN_SHORTER);

		nNameLen=nVoltLen=0;
		bFlag=0;
		while (nChar < (int)strlen(lpszLine) && nChar <= nVCurveNameArray[2*nCurve+1])
		{
			if (lpszLine[nChar] != ' ')
			{
				if (!bFlag)
					szBusName[nNameLen++]=lpszLine[nChar];
				else
					szBusVolt[nVoltLen++]=lpszLine[nChar];
			}

			nChar++;
			if (nChar-nVCurveNameArray[2*nCurve+0] >= 8)
				bFlag=1;
		}
		szBusName[nNameLen++]='\0';
		szBusVolt[nVoltLen++]='\0';

		if (strlen(szBusName) > 0)
		{
			sprintf(szCurve, "%s %s", szBusName, szBusVolt);

			ResolveBusName(pPGBlock, nIsland, szBusName, szBusVolt, szCurve);
			crvBuf.strCurveName=szCurve;
			crvArray.push_back(crvBuf);
		}
	}
}

int CPG2BpaFileApi::PGParseOutFile(IN tagPGBlock* pPGBlock, IN const char* lpszWorkDir, const int nIsland)
{
	int		nItem, nLine;
	unsigned char	bOutSection, bHasError;
	char	szFileName[260], szLine[1024], szCurveName[260];;
	char*	lpszToken;
	std::vector<std::string>	strEleArray;
	std::vector<std::string>	strOutLineArray;
	FILE*	fp;

	tagSimpleCurve	sCurveMaxAng ;
	tagSimpleCurve	sCurveMinVolt;
	tagSimpleCurve	sCurveMaxVolt;
	tagSimpleCurve	sCurveMinFreq;
	tagSimpleCurve	sCurveMaxFreq;
	tagCurveData	dMxDBuf;
	tagCurveData	dMnVBuf;
	tagCurveData	dMxVBuf;
	tagCurveData	dMnFBuf;
	tagCurveData	dMxFBuf;

	tagSimpleCurve	sCurveBuffer;
	tagCurveData	dBuf;

	std::vector<tagSimpleCurve>	vCurveArray;

	initSimpleCurve(sCurveMaxAng );
	initSimpleCurve(sCurveMinVolt);
	initSimpleCurve(sCurveMaxVolt);
	initSimpleCurve(sCurveMinFreq);
	initSimpleCurve(sCurveMaxFreq);
	initSimpleCurve(sCurveBuffer);

	sCurveMaxAng .strCurveName="����������Թ���";
	sCurveMinVolt.strCurveName="��ͽڵ��ѹ";
	sCurveMaxVolt.strCurveName="��߽ڵ��ѹ";
	sCurveMinFreq.strCurveName="��ͽڵ�Ƶ��";
	sCurveMaxFreq.strCurveName="��߽ڵ�Ƶ��";

	sCurveMaxAng .strXAxiasName="��";
	sCurveMinVolt.strXAxiasName="��";
	sCurveMaxVolt.strXAxiasName="��";
	sCurveMinFreq.strXAxiasName="��";
	sCurveMaxFreq.strXAxiasName="��";

	sCurveMaxAng .strYAxiasName="��";
	sCurveMinVolt.strYAxiasName="pu";
	sCurveMaxVolt.strYAxiasName="pu";
	sCurveMinFreq.strYAxiasName="Hz";
	sCurveMaxFreq.strYAxiasName="Hz";

	sCurveBuffer.strXAxiasName="��";

	vCurveArray.clear();

	bHasError=0;
	bOutSection=0;
	strOutLineArray.clear();

#ifdef PG2BPAAPI_USING_STL
	m_BpaMonitorCurveArray.clear();
#else
	m_nBpaMonitorCurveNum = 0;
#endif

	sprintf(szFileName, "%s/%s%d.out", lpszWorkDir, m_BpaDatConCard.szProject, nIsland);
	fp=fopen(szFileName, "r");
	if (fp == NULL)
		return 0;

	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);

		TrimEnd(szLine);
		TrimRight(szLine);

		if (strstr(szLine, "SWING CASE") != NULL)
		{
			if (strstr(szLine, "* * *  �� �� �� Ϣ  * * *") != NULL)
				bOutSection=1;
			else
				bOutSection=0;
			continue;
		}

		if (strstr(szLine, "ERROR") != NULL)
		{
			if (strstr(szLine, "�������ڳ��ִ��󣬼�����ֹ") != NULL)
			{
				bHasError=1;
				break;
			}
		}

		if (bOutSection)
			strOutLineArray.push_back(szLine);
	}

	fclose(fp);

	if (bHasError)
	{
		strOutLineArray.clear();
		return -1;
	}

	nLine=0;
	bOutSection=0;
	while (nLine < (int)strOutLineArray.size())
	{
		if (!strOutLineArray[nLine].empty())
		{
			if (strOutLineArray[nLine].find("��������еļ������������б�") != string::npos)
			{
				if (!vCurveArray.empty())
				{
					for (nItem=0; nItem<(int)vCurveArray.size(); nItem++)
						AddBpaMonitorCurve(vCurveArray[nItem]);
					vCurveArray.clear();
				}
				bOutSection=1;
				nLine++;	//	����
				nLine++;
				nLine++;
				nLine++;
				continue;
			}
			else if (strOutLineArray[nLine].find("��������б�") != string::npos)
			{
				if (!vCurveArray.empty())
				{
					for (nItem=0; nItem<(int)vCurveArray.size(); nItem++)
						AddBpaMonitorCurve(vCurveArray[nItem]);
					vCurveArray.clear();
				}

				bOutSection=2;
				memset(szCurveName, 0, 260);
				ResolveCurveName(pPGBlock, nIsland, strOutLineArray[nLine].c_str(), szCurveName);

				nLine++;	//	����
				nLine++;
				continue;
			}
			else if (strOutLineArray[nLine].find("��������ʽ��������ڵ������ѹ�����б�") != string::npos)
			{
				vCurveArray.clear();
				bOutSection=10;
			}
			else if (strOutLineArray[nLine][1] == '*')
			{
				if (!vCurveArray.empty())
				{
					for (nItem=0; nItem<(int)vCurveArray.size(); nItem++)
						AddBpaMonitorCurve(vCurveArray[nItem]);
					vCurveArray.clear();
				}
				bOutSection=0;
				nLine++;
				continue;
			}
		}

		strcpy(szLine, strOutLineArray[nLine].c_str());
		nLine++;

		if (bOutSection == 1)
		{
			strEleArray.clear();
			lpszToken=strtok(szLine, " /\t\n");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL, " /\t\n");
			}
			memset(&dMxDBuf, 0, sizeof(tagCurveData));
			memset(&dMnVBuf, 0, sizeof(tagCurveData));
			memset(&dMxVBuf, 0, sizeof(tagCurveData));
			memset(&dMnFBuf, 0, sizeof(tagCurveData));
			memset(&dMxFBuf, 0, sizeof(tagCurveData));

			nItem=0;
			if ((int)strEleArray.size() > nItem)
			{
				dMxDBuf.fX=(float)atof(strEleArray[nItem].c_str())/g_ConstfBaseFrequency;
				dMnVBuf.fX=(float)atof(strEleArray[nItem].c_str())/g_ConstfBaseFrequency;
				dMxVBuf.fX=(float)atof(strEleArray[nItem].c_str())/g_ConstfBaseFrequency;
				dMnFBuf.fX=(float)atof(strEleArray[nItem].c_str())/g_ConstfBaseFrequency;
				dMxFBuf.fX=(float)atof(strEleArray[nItem].c_str())/g_ConstfBaseFrequency;
				nItem++;
			}
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	dMxDBuf.fY=atof(strEleArray[nItem++].c_str());	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	dMnVBuf.fY=atof(strEleArray[nItem++].c_str());	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	dMxVBuf.fY=atof(strEleArray[nItem++].c_str());	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	dMnFBuf.fY=atof(strEleArray[nItem++].c_str());	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	nItem++;	else	continue;
			if ((int)strEleArray.size() > nItem)	dMxFBuf.fY=atof(strEleArray[nItem++].c_str());	else	continue;

			sCurveMaxAng .sDataArray.push_back(dMxDBuf);
			sCurveMinVolt.sDataArray.push_back(dMnVBuf);
			sCurveMaxVolt.sDataArray.push_back(dMxVBuf);
			sCurveMinFreq.sDataArray.push_back(dMnFBuf);
			sCurveMaxFreq.sDataArray.push_back(dMxFBuf);
		}
		else if (bOutSection == 2)
		{
			sCurveBuffer.sDataArray.clear();
			sCurveBuffer.strCurveName=szCurveName;

			strEleArray.clear();
			lpszToken=strtok(szLine, " /\t\n/=");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL, " /\t\n/=");
			}

			nItem=0;
			if ((int)strEleArray.size() > nItem)	sCurveBuffer.strCurveName.append("-").append(strEleArray[nItem++]);				else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	sCurveBuffer.strYAxiasName=strEleArray[nItem++];								else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	nItem++;																		else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	sCurveBuffer.fMaxY=atof(strEleArray[nItem++].c_str());							else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	sCurveBuffer.fMaxX=atof(strEleArray[nItem++].c_str())/g_ConstfBaseFrequency;	else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	nItem++;																		else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	sCurveBuffer.fMinY=atof(strEleArray[nItem++].c_str());							else	{	bOutSection=0;	continue;	}
			if ((int)strEleArray.size() > nItem)	sCurveBuffer.fMinX=atof(strEleArray[nItem++].c_str())/g_ConstfBaseFrequency;	else	{	bOutSection=0;	continue;	}

			bOutSection=3;
		}
		else if (bOutSection == 10)
		{
			if (strOutLineArray[nLine].find("ʱ��") != string::npos)
			{
				if (!vCurveArray.empty())
				{
					for (nItem=0; nItem<(int)vCurveArray.size(); nItem++)
						AddBpaMonitorCurve(vCurveArray[nItem]);
					vCurveArray.clear();
				}

				ResolveVCurveName(pPGBlock, nIsland, strOutLineArray[nLine].c_str(), vCurveArray);
				for (nItem=0; nItem<(int)vCurveArray.size(); nItem++)
					vCurveArray[nItem].strCurveName.append("-").append("ĸ�ߵ�ѹ");
// 				Log(g_lpszPG2BpaApiLogFile, "ResolveVCurveName: \n");
// 				for (nItem=0; nItem<vCurveArray.size(); nItem++)
// 					Log(g_lpszPG2BpaApiLogFile, "    Curve[%d]=%s\n", nItem, vCurveArray[nItem].strCurveName.c_str());
			}
			else
			{
				strEleArray.clear();
				lpszToken=strtok(szLine, " /\t\n/=");
				while (lpszToken != NULL)
				{
					strEleArray.push_back(lpszToken);
					lpszToken=strtok(NULL, " /\t\n/=");
				}

				if (strEleArray.size()-1 == vCurveArray.size())
				{
					dBuf.fX=atof(strEleArray[0].c_str())/g_ConstfBaseFrequency;
					for (nItem=0; nItem<(int)vCurveArray.size(); nItem++)
					{
						dBuf.fY=atof(strEleArray[nItem+1].c_str());
						vCurveArray[nItem].sDataArray.push_back(dBuf);
					}
				}
			}
		}
		else if (bOutSection == 3)
		{
			unsigned char	bComplexValue;
			if (strlen(szLine) <= 0)
			{
				if (!sCurveBuffer.strCurveName.empty() && !sCurveBuffer.sDataArray.empty())
					AddBpaMonitorCurve(sCurveBuffer);
				bOutSection=2;
				continue;
			}

			bComplexValue=0;
			if (strstr(szLine, "/") != NULL)
				bComplexValue=1;

			memset(&dBuf, 0, sizeof(tagCurveData));
			strEleArray.clear();
			lpszToken=strtok(szLine, " /\t\n");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL, " /\t\n");
			}

			nItem=0;
			while (nItem < (int)strEleArray.size()-1)
			{
				dBuf.fX=atof(strEleArray[nItem++].c_str())/g_ConstfBaseFrequency;
				dBuf.fY=atof(strEleArray[nItem++].c_str());
				if (bComplexValue)	nItem++;
				sCurveBuffer.sDataArray.push_back(dBuf);
			}
		}
	}

	AddBpaMonitorCurve(sCurveMaxAng );
	AddBpaMonitorCurve(sCurveMinVolt);
	AddBpaMonitorCurve(sCurveMaxVolt);
	AddBpaMonitorCurve(sCurveMinFreq);
	AddBpaMonitorCurve(sCurveMaxFreq);

	unsigned char	nR, nG, nB;
	static	int	nRGBArray[] =
	{
		RGB(255,	0,		0),
		RGB(0,		255,	0),
		RGB(0,		0,		255),
		RGB(255,	255,	0),
		RGB(0,		255,	255),
		RGB(128,	0,		0),
		RGB(0,		128,	0),
		RGB(0,		0,		128),
		RGB(128,	128,	0),
		RGB(0,		128,	128),
		RGB(128,	128,	128),
	};

	nR=255;
	nG=0;
	nB=0;
	for (nItem=0; nItem<GetBpaMonitorCurveNum(); nItem++)
	{
		getSimpleCurveMinMax(m_BpaMonitorCurveArray[nItem]);
		if (nItem < sizeof(nRGBArray)/sizeof(int))
			m_BpaMonitorCurveArray[nItem].clrCurve=nRGBArray[nItem];
		else
		{
			m_BpaMonitorCurveArray[nItem].clrCurve=RGB(nR, nG, nB);
			nR += 64;
			nG -= 64;
			nB -= 32;
		}
	}

	return 1;
}