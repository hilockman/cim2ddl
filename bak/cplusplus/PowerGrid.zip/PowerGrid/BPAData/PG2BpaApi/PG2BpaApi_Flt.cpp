#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "PG2BpaApiFlt.h"
#include "../../../Common/StringCommon.h"

int CPG2BpaFileApi::ResolveBusIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName)
{
	register int	i;
	int		nSub, nVolt;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (stricmp(pPGBlock->m_SubstationArray[nSub].szName, lpszSub) != 0)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (stricmp(pPGBlock->m_VoltageLevelArray[nVolt].szName, lpszVolt) != 0)
				continue;

			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; i++)
			{
				if (stricmp(pPGBlock->m_BusbarSectionArray[i].szName, lpszName) != 0)
					continue;

				if (pPGBlock->m_BusbarSectionArray[i].nNode < 0)
					continue;
				if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[i].nNode].nTopoBus < 3)
					continue;

				return i;
				break;
			}
		}
	}
	return -1;
}

int CPG2BpaFileApi::ResolveLineIndex(tagPGBlock* pPGBlock, const char* lpszName)
{
	register int	i;

	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, lpszName) != 0)
			continue;

		return i;
		break;
	}
	return -1;
}

int CPG2BpaFileApi::ResolveTranIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName)
{
	register int	i;
	int		nSub;

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (stricmp(pPGBlock->m_SubstationArray[nSub].szName, lpszSub) != 0)
			continue;

		for (i=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; i<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; i++)
		{
			//if (stricmp(pPGBlock->m_TransformerWindingArray[i].szVoltI, lpszVolt) != 0 && stricmp(pPGBlock->m_TransformerWindingArray[i].szVoltJ, lpszVolt) != 0)
			//	continue;
			if (stricmp(pPGBlock->m_TransformerWindingArray[i].szName, lpszName) != 0)
				continue;

			return i;
			break;
		}
	}
	return -1;
}

int CPG2BpaFileApi::ResolveGenIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName)
{
	register int	i;
	int		nSub, nVolt;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (stricmp(pPGBlock->m_SubstationArray[nSub].szName, lpszSub) != 0)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (stricmp(pPGBlock->m_VoltageLevelArray[nVolt].szName, lpszVolt) != 0)
				continue;

			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
			{
				if (stricmp(pPGBlock->m_SynchronousMachineArray[i].szName, lpszName) != 0)
					continue;

				if (pPGBlock->m_SynchronousMachineArray[i].nNode < 0)
					continue;
				if (pPGBlock->m_SynchronousMachineArray[i].nTopoBus < 3)
					continue;

				return i;
				break;
			}
		}
	}
	return -1;
}

int CPG2BpaFileApi::ResolveLoadIndex(tagPGBlock* pPGBlock, const char* lpszSub, const char* lpszVolt, const char* lpszName)
{
	register int	i;
	int		nSub, nVolt;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (stricmp(pPGBlock->m_SubstationArray[nSub].szName, lpszSub) != 0)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (stricmp(pPGBlock->m_VoltageLevelArray[nVolt].szName, lpszVolt) != 0)
				continue;

			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
			{
				if (stricmp(pPGBlock->m_EnergyConsumerArray[i].szName, lpszName) != 0)
					continue;

				if (pPGBlock->m_EnergyConsumerArray[i].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[i].nTopoBus < 3)
					continue;

				return i;
				break;
			}
		}
	}
	return -1;
}

void CPG2BpaFileApi::FillLineString(const int nType, const int nIni, const int nEnd, const int nLen, char* lpszValue, char* lpszString)
{
	register int	i;
	switch (nType)
	{
	case MDB_FLOAT:
		if (fabs(atof(lpszValue)) > 0.00000001)
		{
			m_BpaMemDBInterface.BpaFormatDecimalChar(-1, -1, lpszValue, nLen, 0);
			for (i=0; i<nLen; i++)
			{
				if (lpszValue[i] == ' ' || lpszValue[i] == '\t' || lpszValue[i] == '\n' || lpszValue[i] == '\r' || lpszValue[i] == '\0')
					break;
				lpszString[i+nIni-1]=lpszValue[i];
			}
		}
		break;
	case MDB_STRING:
		for (i=0; i<nLen; i++)
		{
			if (lpszValue[i] == ' ' || lpszValue[i] == '\t' || lpszValue[i] == '\n' || lpszValue[i] == '\r' || lpszValue[i] == '\0')
				break;
			lpszString[i+nIni-1]=lpszValue[i];
		}
		break;
	case MDB_INT:
	case MDB_BIT:
	case MDB_SHORT:
		for (i=0; i<nLen; i++)
		{
			if (lpszValue[i] == ' ' || lpszValue[i] == '\t' || lpszValue[i] == '\n' || lpszValue[i] == '\r' || lpszValue[i] == '\0')
				break;
			lpszString[i+nIni-1]=lpszValue[i];
		}
		break;
	case MDB_CHAR:
		if (lpszValue[0] != ' ' && lpszValue[0] != '\t' && lpszValue[0] != '\n' && lpszValue[0] != '\r' && lpszValue[0] != '\0')
			lpszString[nIni-1]=lpszValue[0];
		break;
	}
}

//int	CPG2BpaFileApi::FormFltString(IN tagPGBlock* pPGBlock, tagBpaFltDefine* pFltDef, char* lpszRetLine)
int	CPG2BpaFileApi::FormFltString(IN tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, std::vector<std::string>& strRetLineArray)
{
	strRetLineArray.clear();

	if (pFltDef->nFltType < 0 || pFltDef->nFltType >= sizeof(g_lpszBpaFltFltType)/sizeof(char*))
		return 0;
	if (pFltDef->nDevType < 0 || pFltDef->nDevType >= sizeof(g_lpszBpaFltDevType)/sizeof(char*))
		return 0;

	register int	i;
	char	szLine[256];
	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';

	switch (pFltDef->nDevType)
	{
	case	BpaFltDev_Bus:
		if (pFltDef->nFltType == BpaFltType_Bus)
		{
			if (FormFltBusString(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		break;
	case	BpaFltDev_Line:
		if (pFltDef->nFltType == BpaFltType_Trip)
		{
			if (FormFltLineTripString(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_SC3)
		{
			if (FormFltLineSC3String(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_SCP1)
		{
			if (FormFltLineSCP1String(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_SC4)
		{
			FormFltLineSC4String(pPGBlock, nIsland, pFltDef, strRetLineArray);
		}
		break;
	case	BpaFltDev_Wind:
		if (pFltDef->nFltType == BpaFltType_Trip)
		{
			if (FormFltTranTripString(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_SC3)
		{
			if (FormFltTranSC3String(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_SCP1)
		{
			if (FormFltTranSCP1String(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_SC4)
		{
			FormFltTranSC4String(pPGBlock, nIsland, pFltDef, strRetLineArray);
		}
		break;
	case	BpaFltDev_Gen:
		if (pFltDef->nFltType == BpaFltType_Trip)
		{
			if (FormFltGenTripString(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		else if (pFltDef->nFltType == BpaFltType_EL)
		{
			if (FormFltGenElString(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		break;
	case	BpaFltDev_Load:
		if (pFltDef->nFltType == BpaFltType_Trip)
		{
			if (FormFltLoadTripString(pPGBlock, nIsland, pFltDef, szLine))
				strRetLineArray.push_back(szLine);
		}
		break;
	}

	return 1;
}

int	CPG2BpaFileApi::FormFltBusString(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Bus || pFltDef->nFltType != BpaFltType_Bus)
		return 0;

	const short	FLT_TYPE=5;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;

	int nFltBus=ResolveBusIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltBus < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveBusIndex Error (%s %s %s)\n", pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
		return 0;
	}
	if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nFltBus].nNode].nIsland != nIsland)
		return 0;

	int nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_BusbarSectionArray[nFltBus].szSub, pPGBlock->m_BusbarSectionArray[nFltBus].szVolt);
	for (nField=0; nField<sizeof(m_BpaDictFltBus)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltBus[nField].szFieldName, "FLT") == 0)				strcpy(szValue, "FLT");
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "BUS") == 0)			sprintf(szValue, "B_%d", pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nFltBus].nNode].nTopoBus);
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "BASE") == 0)			sprintf(szValue, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "FLT_TYPE") == 0)		sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "ISHORT_TYPE") == 0)	sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "TCYC0") == 0)		sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "TCYC1") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc1);
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "FAULTR") == 0)		strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBus[nField].szFieldName, "FAULTX") == 0)		strcpy(szValue, "0");

		FillLineString(m_BpaDictFltBus[nField].nFieldType, m_BpaDictFltBus[nField].nFieldStart, m_BpaDictFltBus[nField].nFieldEnd, m_BpaDictFltBus[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltLineTripString(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Line || pFltDef->nFltType != BpaFltType_Trip)
		return 0;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;

	int nBpaLine, nFltLine=ResolveLineIndex(pPGBlock, pFltDef->szDevName);
	if (nFltLine < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveLineIndex Error (%s)\n", pFltDef->szDevName);
		return 0;
	}
	if (pPGBlock->m_ACLineSegmentArray[nFltLine].nIsland != nIsland)
		return 0;

	nBpaLine=FindLineInLArray(pPGBlock->m_ACLineSegmentArray[nFltLine].szName);
	if (nBpaLine < 0)
		return 0;

	for (nField=0; nField<sizeof(m_BpaDictFltBranTrip)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN1") == 0)	strcpy(szValue, "-");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS1") == 0)	strcpy(szValue, m_LineArray[nBpaLine].szBusI);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVI);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN2") == 0)	strcpy(szValue, "-");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS2") == 0)	strcpy(szValue, m_LineArray[nBpaLine].szBusJ);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVJ);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PAR") == 0)		szValue[0]=m_LineArray[nBpaLine].cLoop;
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "MDE") == 0)		strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTR") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTX") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PERCNT") == 0)	sprintf(szValue, "%f", pFltDef->fPercent);

		FillLineString(m_BpaDictFltBranTrip[nField].nFieldType, m_BpaDictFltBranTrip[nField].nFieldStart, m_BpaDictFltBranTrip[nField].nFieldEnd, m_BpaDictFltBranTrip[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltTranTripString(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Wind || pFltDef->nFltType != BpaFltType_Trip)
	{
		Log(g_lpszPG2BpaApiLogFile, "FormFltTranTripString DevType=%d FltType=%d)\n", pFltDef->nDevType, pFltDef->nFltType);
		return 0;
	}

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;

	int nBpaTran, nFltTran=ResolveTranIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltTran < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveTranIndex Error (%s %s %s)\n", pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
		return 0;
	}

	if (pPGBlock->m_TransformerWindingArray[nFltTran].nIsland != nIsland)
		return 0;

	sprintf(szValue, "%s.%s", pPGBlock->m_TransformerWindingArray[nFltTran].szSub, pPGBlock->m_TransformerWindingArray[nFltTran].szName);
	nBpaTran=FindTranInTArray(szValue);
	if (nBpaTran < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "FormFltTranTripString FindBpaTranError=%s)\n", szValue);
		return 0;
	}

	for (nField=0; nField<sizeof(m_BpaDictFltBranTrip)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");								
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN1") == 0)	strcpy(szValue, "-");								
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS1") == 0)	strcpy(szValue, m_TranArray[nBpaTran].szBusI);		
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVI);	
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN2") == 0)	strcpy(szValue, "-");								
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS2") == 0)	strcpy(szValue, m_TranArray[nBpaTran].szBusJ);		
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVJ);	
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PAR") == 0)		szValue[0]=m_TranArray[nBpaTran].cLoop;				
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "MDE") == 0)		strcpy(szValue, "0");								
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);			
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTR") == 0)	strcpy(szValue, "0");								
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTX") == 0)	strcpy(szValue, "0");								
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PERCNT") == 0)	sprintf(szValue, "%f", pFltDef->fPercent);			

		FillLineString(m_BpaDictFltBranTrip[nField].nFieldType, m_BpaDictFltBranTrip[nField].nFieldStart, m_BpaDictFltBranTrip[nField].nFieldEnd, m_BpaDictFltBranTrip[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

char	CPG2BpaFileApi::ResolveGenID(tagPGBlock* pPGBlock, const int nGen)
{
	register int	i;

	char	cId=' ';
	int		nSameBusNum=0;
	int		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SynchronousMachineArray[nGen].szSub, pPGBlock->m_SynchronousMachineArray[nGen].szVolt);
	for (i=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
	{
		if (pPGBlock->m_SynchronousMachineArray[i].nIsland != pPGBlock->m_SynchronousMachineArray[nGen].nIsland)
			continue;

		if (pPGBlock->m_SynchronousMachineArray[i].nTopoBus == pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus)
			nSameBusNum++;
	}
	if (nSameBusNum > 1)
	{
		cId='1';
		for (i=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[i].nIsland != pPGBlock->m_SynchronousMachineArray[nGen].nIsland)
				continue;

			if (i == nGen)
				break;

			if (pPGBlock->m_SynchronousMachineArray[i].nTopoBus == pPGBlock->m_SynchronousMachineArray[i].nTopoBus)
				cId++;
		}
	}
	return cId;
}

char CPG2BpaFileApi::ResolveLineLoop(tagPGBlock* pPGBlock, const int nLine)
{
	register int	i;
	char	cLoop=' ';
	unsigned char	bHasSame;

	bHasSame=0;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (i == nLine)
			continue;

		if (pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ ||
			pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI)
		{
			bHasSame=1;
		}
	}

	if (bHasSame)
	{
		cLoop='1';
		for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (nLine == i)
				break;

			if (pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ ||
				pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusI == pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ && pPGBlock->m_ACLineSegmentArray[nLine].nTopoBusJ == pPGBlock->m_ACLineSegmentArray[i].nTopoBusI)
			{
				cLoop++;
			}
		}
	}

	return cLoop;
}

char CPG2BpaFileApi::ResolveTranLoop(tagPGBlock* pPGBlock, const int nTran)
{
	register int	i;
	char	cLoop=' ';
	unsigned char	bHasSame;

	bHasSame=0;
	for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (i == nTran)
			continue;

		if (pPGBlock->m_TransformerWindingArray[nTran].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusI && pPGBlock->m_TransformerWindingArray[nTran].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ ||
			pPGBlock->m_TransformerWindingArray[nTran].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ && pPGBlock->m_TransformerWindingArray[nTran].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusI)
		{
			bHasSame=1;
		}
	}

	if (bHasSame)
	{
		cLoop='1';
		for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		{
			if (nTran == i)
				break;

			if (pPGBlock->m_TransformerWindingArray[nTran].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusI && pPGBlock->m_TransformerWindingArray[nTran].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ ||
				pPGBlock->m_TransformerWindingArray[nTran].nTopoBusI == pPGBlock->m_TransformerWindingArray[i].nTopoBusJ && pPGBlock->m_TransformerWindingArray[nTran].nTopoBusJ == pPGBlock->m_TransformerWindingArray[i].nTopoBusI)
			{
				cLoop++;
			}
		}
	}

	return cLoop;
}

int	CPG2BpaFileApi::FormFltGenTripString(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Gen || pFltDef->nFltType != BpaFltType_Trip)
		return 0;

	const short	MDE_TYPE=4;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;

	int nFltGen=ResolveGenIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltGen < 0)
		return 0;
	if (pPGBlock->m_SynchronousMachineArray[nFltGen].nIsland != nIsland)
		return 0;

	int		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SynchronousMachineArray[nFltGen].szSub, pPGBlock->m_SynchronousMachineArray[nFltGen].szVolt);
	char	cId=ResolveGenID(pPGBlock, nFltGen);
	for (nField=0; nField<sizeof(m_BpaDictFltGenTrip)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "BUS") == 0)		sprintf(szValue, "B_%d", pPGBlock->m_SynchronousMachineArray[nFltGen].nTopoBus);
		else if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "BASE") == 0)		sprintf(szValue, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		else if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "ID") == 0)		szValue[0]=cId;
		else if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "MDE") == 0)		sprintf(szValue, "%d", MDE_TYPE);
		else if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltGenTrip[nField].szFieldName, "PG") == 0)		strcpy(szValue, "99999");

		FillLineString(m_BpaDictFltGenTrip[nField].nFieldType, m_BpaDictFltGenTrip[nField].nFieldStart, m_BpaDictFltGenTrip[nField].nFieldEnd, m_BpaDictFltGenTrip[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltLoadTripString(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Load || pFltDef->nFltType != BpaFltType_Trip)
		return 0;

	const short	FLT_TYPE=21;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;

	int nFltLoad=ResolveLoadIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltLoad < 0)
		return 0;
	if (pPGBlock->m_EnergyConsumerArray[nFltLoad].nIsland != nIsland)
		return 0;
	if (pPGBlock->m_EnergyConsumerArray[nFltLoad].fPlanP < 0.001)
		return 0;

	int nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_EnergyConsumerArray[nFltLoad].szSub, pPGBlock->m_EnergyConsumerArray[nFltLoad].szVolt);
	for (nField=0; nField<sizeof(m_BpaDictFltLoadTrip)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "FLT") == 0)				strcpy(szValue, "FLT");
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "BUS") == 0)			sprintf(szValue, "B_%d", pPGBlock->m_EnergyConsumerArray[nFltLoad].nTopoBus);
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "BASE") == 0)		sprintf(szValue, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "ID") == 0)			szValue[0]='*';
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "FLT_TYPE") == 0)	sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "WPER") == 0)		szValue[0]=' ';
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "TCYC0") == 0)		sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "PPER") == 0)		strcpy(szValue, "100.");
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "QPER") == 0)		strcpy(szValue, "100.");
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "QSHUNT") == 0)		strcpy(szValue, "100.");
		else if (stricmp(m_BpaDictFltLoadTrip[nField].szFieldName, "PGPER") == 0)		strcpy(szValue, "100.");

		FillLineString(m_BpaDictFltLoadTrip[nField].nFieldType, m_BpaDictFltLoadTrip[nField].nFieldStart, m_BpaDictFltLoadTrip[nField].nFieldEnd, m_BpaDictFltLoadTrip[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltLineSC3String(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Line || pFltDef->nFltType != BpaFltType_SC3)
		return 0;

	const short	FLT_TYPE=1;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;
	double	fPercent;

	int nBpaLine, nFltLine=ResolveLineIndex(pPGBlock, pFltDef->szDevName);
	if (nFltLine < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveLineIndex Error (%s)\n", pFltDef->szDevName);
		return 0;
	}
	if (pPGBlock->m_ACLineSegmentArray[nFltLine].nIsland != nIsland)
		return 0;

	nBpaLine=FindLineInLArray(pPGBlock->m_ACLineSegmentArray[nFltLine].szName);
	if (nBpaLine < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "FormFltLineSC3String ResolveBpaLine=%s Error\n", pPGBlock->m_ACLineSegmentArray[nFltLine].szName);
		return 0;
	}

	fPercent=pFltDef->fPercent;
	sprintf(szValue, "B_%d", pPGBlock->m_ACLineSegmentArray[nFltLine].nTopoBusI);
	if (stricmp(m_LineArray[nBpaLine].szBusI, szValue) != 0)
		fPercent=1.0-fPercent;

	for (nField=0; nField<sizeof(m_BpaDictFltSc3)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FLT") == 0)			strcpy(szValue, "FLT");
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusI);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVI);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusJ);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVJ);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "PAR") == 0)		szValue[0]=m_LineArray[nBpaLine].cLoop;
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FLT_TYPE") == 0)	sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "SIDE") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "TCYC0") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "TCYC1") == 0)	sprintf(szValue, "%f", pFltDef->fTCyc1);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "TCYC2") == 0)	sprintf(szValue, "%f", pFltDef->fTCyc2);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "PERCENT") == 0)	{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FAULTR") == 0)	sprintf(szValue, "%f", pFltDef->fFaultR);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FAULTX") == 0)	sprintf(szValue, "%f", pFltDef->fFaultX);

		FillLineString(m_BpaDictFltSc3[nField].nFieldType, m_BpaDictFltSc3[nField].nFieldStart, m_BpaDictFltSc3[nField].nFieldEnd, m_BpaDictFltSc3[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltTranSC3String(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Wind || pFltDef->nFltType != BpaFltType_SC3)
		return 0;

	const short	FLT_TYPE=1;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;
	double	fPercent;

	int nBpaTran, nFltTran=ResolveTranIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltTran < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveTranIndex (%s %s %s) Error\n", pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
		return 0;
	}
	if (pPGBlock->m_TransformerWindingArray[nFltTran].nIsland != nIsland)
		return 0;

	sprintf(szValue, "%s.%s", pPGBlock->m_TransformerWindingArray[nFltTran].szSub, pPGBlock->m_TransformerWindingArray[nFltTran].szName);
	nBpaTran=FindTranInTArray(szValue);
	if (nBpaTran < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "FormFltTranSC3String ResolveBpaTran=%s Error\n", szValue);
		return 0;
	}

	fPercent=pFltDef->fPercent;
	sprintf(szValue, "B_%d", pPGBlock->m_TransformerWindingArray[nFltTran].nTopoBusI);
	if (stricmp(m_TranArray[nBpaTran].szBusI, szValue) != 0)
		fPercent=1.0-fPercent;

	for (nField=0; nField<sizeof(m_BpaDictFltSc3)/sizeof(tagBpa_Dict); nField++)
	{
		if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FLT") == 0)			strcpy(szValue, "FLT");
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusI);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVI);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusJ);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVJ);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "PAR") == 0)		szValue[0]=m_TranArray[nBpaTran].cLoop;
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FLT_TYPE") == 0)	sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "SIDE") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "TCYC0") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "TCYC1") == 0)	sprintf(szValue, "%f", pFltDef->fTCyc1);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "TCYC2") == 0)	sprintf(szValue, "%f", pFltDef->fTCyc2);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "PERCENT") == 0)	{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FAULTR") == 0)	sprintf(szValue, "%f", pFltDef->fFaultR);
		else if (stricmp(m_BpaDictFltSc3[nField].szFieldName, "FAULTX") == 0)	sprintf(szValue, "%f", pFltDef->fFaultX);

		FillLineString(m_BpaDictFltSc3[nField].nFieldType, m_BpaDictFltSc3[nField].nFieldStart, m_BpaDictFltSc3[nField].nFieldEnd, m_BpaDictFltSc3[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltLineSCP1String(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Line || pFltDef->nFltType != BpaFltType_SCP1)
		return 0;

	const short	FLT_TYPE=3;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;
	double	fPercent;

	int nBpaLine, nFltLine=ResolveLineIndex(pPGBlock, pFltDef->szDevName);
	if (nFltLine < 0)
		return 0;
	if (pPGBlock->m_ACLineSegmentArray[nFltLine].nIsland != nIsland)
		return 0;

	nBpaLine=FindLineInLArray(pPGBlock->m_ACLineSegmentArray[nFltLine].szName);
	if (nBpaLine < 0)
		return 0;

	fPercent=pFltDef->fPercent;
	sprintf(szValue, "B_%d", pPGBlock->m_ACLineSegmentArray[nFltLine].nTopoBusI);
	if (stricmp(m_LineArray[nBpaLine].szBusI, szValue) != 0)
		fPercent=1.0-fPercent;

	for (nField=0; nField<sizeof(m_BpaDictFltScP1)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FLT") == 0)				strcpy(szValue, "FLT");
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusI);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BASE1") == 0)		sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVI);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusJ);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BASE2") == 0)		sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVJ);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "PAR") == 0)			szValue[0]=m_LineArray[nBpaLine].cLoop;
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FLT_TYPE") == 0)	sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FHASE") == 0)		sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "SIDE") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC0") == 0)		sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC1") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc1);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC2") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc2);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "PERCENT") == 0)		{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FAULTR") == 0)		sprintf(szValue, "%f", pFltDef->fFaultR);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FAULTX") == 0)		sprintf(szValue, "%f", pFltDef->fFaultX);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC11") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc11);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC21") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc21);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC12") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc12);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC22") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc22);

		FillLineString(m_BpaDictFltScP1[nField].nFieldType, m_BpaDictFltScP1[nField].nFieldStart, m_BpaDictFltScP1[nField].nFieldEnd, m_BpaDictFltScP1[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltTranSCP1String(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Wind || pFltDef->nFltType != BpaFltType_SCP1)
		return 0;

	const short	FLT_TYPE=3;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;
	double	fPercent;

	int nBpaTran, nFltTran=ResolveTranIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltTran < 0)
		return 0;
	if (pPGBlock->m_TransformerWindingArray[nFltTran].nIsland != nIsland)
		return 0;

	sprintf(szValue, "%s.%s", pPGBlock->m_TransformerWindingArray[nFltTran].szSub, pPGBlock->m_TransformerWindingArray[nFltTran].szName);
	nBpaTran=FindTranInTArray(szValue);
	if (nBpaTran < 0)
		return 0;

	fPercent=pFltDef->fPercent;
	sprintf(szValue, "B_%d", pPGBlock->m_TransformerWindingArray[nFltTran].nTopoBusI);
	if (stricmp(m_TranArray[nBpaTran].szBusI, szValue) != 0)
		fPercent=1.0-fPercent;

	for (nField=0; nField<sizeof(m_BpaDictFltScP1)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FLT") == 0)				strcpy(szValue, "FLT");
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusI);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BASE1") == 0)		sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVI);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusJ);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "BASE2") == 0)		sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVJ);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "PAR") == 0)			szValue[0]=m_TranArray[nBpaTran].cLoop;
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FLT_TYPE") == 0)	sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FHASE") == 0)		sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "SIDE") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC0") == 0)		sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC1") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc1);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC2") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc2);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "PERCENT") == 0)		{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FAULTR") == 0)		sprintf(szValue, "%f", pFltDef->fFaultR);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "FAULTX") == 0)		sprintf(szValue, "%f", pFltDef->fFaultX);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC11") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc11);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC21") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc21);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC12") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc12);
		else if (stricmp(m_BpaDictFltScP1[nField].szFieldName, "TCYC22") == 0)		sprintf(szValue, "%f", pFltDef->fTCyc22);

		FillLineString(m_BpaDictFltScP1[nField].nFieldType, m_BpaDictFltScP1[nField].nFieldStart, m_BpaDictFltScP1[nField].nFieldEnd, m_BpaDictFltScP1[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltGenElString(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, char* lpszRetLine)
{
	if (pFltDef->nDevType != BpaFltDev_Gen || pFltDef->nFltType != BpaFltType_EL)
		return 0;

	const short	MDE_TYPE=10;

	char	szValue[MDB_CHARLEN_LONG];
	int		nField;

	int nFltGen=ResolveGenIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltGen < 0)
		return 0;
	if (pPGBlock->m_SynchronousMachineArray[nFltGen].nIsland != nIsland)
		return 0;

	char	cId=ResolveGenID(pPGBlock, nFltGen);;
	int nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SynchronousMachineArray[nFltGen].szSub, pPGBlock->m_SynchronousMachineArray[nFltGen].szVolt);
	for (nField=0; nField<sizeof(m_BpaDictFltGenEl)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "BUS") == 0)	sprintf(szValue, "B_%d", pPGBlock->m_SynchronousMachineArray[nFltGen].nTopoBus);
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "BASE") == 0)	sprintf(szValue, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "ID") == 0)		szValue[0]=cId;
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "MDE") == 0)	sprintf(szValue, "%d", MDE_TYPE);
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "SCID") == 0)	sprintf(szValue, "%d", pFltDef->nElType+1);
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "CREST") == 0)	sprintf(szValue, "%f", pFltDef->fElCrest);
		else if (stricmp(m_BpaDictFltGenEl[nField].szFieldName, "T") == 0)		sprintf(szValue, "%f", pFltDef->fExcitT+1);

		FillLineString(m_BpaDictFltGenEl[nField].nFieldType, m_BpaDictFltGenEl[nField].nFieldStart, m_BpaDictFltGenEl[nField].nFieldEnd, m_BpaDictFltGenEl[nField].nFieldLen, szValue, lpszRetLine);
	}

	TrimRight(lpszRetLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltLineSC4String(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, std::vector<std::string>& strRetLineArray)
{
	if (pFltDef->nDevType != BpaFltDev_Line || pFltDef->nFltType != BpaFltType_SC4)
		return 0;

	const short	FLT_TYPE=9;
	const short	NDE_TYPE=4;

	register int	i;
	char	szValue[MDB_CHARLEN_LONG];
	int		nField;
	double	fPercent;
	char	szLine[256];

	int nBpaLine, nFltLine=ResolveLineIndex(pPGBlock, pFltDef->szDevName);
	if (nFltLine < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveLineIndex Error (%s)\n", pFltDef->szDevName);
		return 0;
	}
	if (pPGBlock->m_ACLineSegmentArray[nFltLine].nIsland != nIsland)
		return 0;

	nBpaLine=FindLineInLArray(pPGBlock->m_ACLineSegmentArray[nFltLine].szName);
	if (nBpaLine < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "FormFltLineSC3String ResolveBpaLine=%s Error\n", pPGBlock->m_ACLineSegmentArray[nFltLine].szName);
		return 0;
	}

	fPercent=pFltDef->fPercent;
	sprintf(szValue, "B_%d", pPGBlock->m_ACLineSegmentArray[nFltLine].nTopoBusI);
	if (stricmp(m_LineArray[nBpaLine].szBusI, szValue) != 0)
		fPercent=1.0-fPercent;

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	for (nField=0; nField<sizeof(m_BpaDictFltBranSc4)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PAR") == 0)		szValue[0]=m_LineArray[nBpaLine].cLoop;
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "MDE") == 0)		sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTR") == 0)	sprintf(szValue, "%f", pFltDef->fFaultR);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTX") == 0)	sprintf(szValue, "%f", pFltDef->fFaultX);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PERCT") == 0)	{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "NDE") == 0)		sprintf(szValue, "%d", NDE_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PHA") == 0)		sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "SID") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRD") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRX") == 0)	strcpy(szValue, "0");

		Log(g_lpszPG2BpaApiLogFile, "Field[%d] = %s Value=%s\n", nField, m_BpaDictFltBranSc4[nField].szFieldName, szValue);

		FillLineString(m_BpaDictFltBranSc4[nField].nFieldType, m_BpaDictFltBranSc4[nField].nFieldStart, m_BpaDictFltBranSc4[nField].nFieldEnd, m_BpaDictFltBranSc4[nField].nFieldLen, szValue, szLine);
	}
	TrimRight(szLine);
	strRetLineArray.push_back(szLine);
	Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", szLine);

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	for (nField=0; nField<sizeof(m_BpaDictFltBranSc4)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_LineArray[nBpaLine].szBusJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PAR") == 0)		szValue[0]=m_LineArray[nBpaLine].cLoop;
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "MDE") == 0)		sprintf(szValue, "%d", -FLT_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", max(pFltDef->fTCycle+pFltDef->fTCyc1, pFltDef->fTCycle+pFltDef->fTCyc2));
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTR") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTX") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PERCT") == 0)	{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "NDE") == 0)		sprintf(szValue, "%d", NDE_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PHA") == 0)		sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "SID") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRD") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRX") == 0)	strcpy(szValue, "0");

		Log(g_lpszPG2BpaApiLogFile, "Field[%d] = %s Value=%s\n", nField, m_BpaDictFltBranSc4[nField].szFieldName, szValue);

		FillLineString(m_BpaDictFltBranSc4[nField].nFieldType, m_BpaDictFltBranSc4[nField].nFieldStart, m_BpaDictFltBranSc4[nField].nFieldEnd, m_BpaDictFltBranSc4[nField].nFieldLen, szValue, szLine);
	}
	TrimRight(szLine);
	strRetLineArray.push_back(szLine);
	Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", szLine);

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	for (nField=0; nField<sizeof(m_BpaDictFltBranTrip)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN1") == 0)	strcpy(szValue, "-");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS1") == 0)	strcpy(szValue, m_LineArray[nBpaLine].szBusI);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVI);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN2") == 0)	strcpy(szValue, "-");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS2") == 0)	strcpy(szValue, m_LineArray[nBpaLine].szBusJ);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_LineArray[nBpaLine].fkVJ);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PAR") == 0)		szValue[0]=m_LineArray[nBpaLine].cLoop;
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "MDE") == 0)		strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", max(pFltDef->fTCycle+pFltDef->fTCyc1, pFltDef->fTCycle+pFltDef->fTCyc2));
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTR") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTX") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PERCNT") == 0)	sprintf(szValue, "%f", pFltDef->fPercent);

		Log(g_lpszPG2BpaApiLogFile, "Field[%d] = %s Value=%s\n", nField, m_BpaDictFltBranTrip[nField].szFieldName, szValue);

		FillLineString(m_BpaDictFltBranTrip[nField].nFieldType, m_BpaDictFltBranTrip[nField].nFieldStart, m_BpaDictFltBranTrip[nField].nFieldEnd, m_BpaDictFltBranTrip[nField].nFieldLen, szValue, szLine);
	}
	TrimRight(szLine);
	strRetLineArray.push_back(szLine);
	Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", szLine);

	return 1;
}

int	CPG2BpaFileApi::FormFltTranSC4String(tagPGBlock* pPGBlock, const int nIsland, tagBpaFltDefine* pFltDef, std::vector<std::string>& strRetLineArray)
{
	if (pFltDef->nDevType != BpaFltDev_Wind || pFltDef->nFltType != BpaFltType_SC3)
		return 0;

	const short	FLT_TYPE=9;
	const short	NDE_TYPE=4;

	register int	i;
	char	szValue[MDB_CHARLEN_LONG];
	int		nField;
	double	fPercent;
	char	szLine[256];

	int nBpaTran, nFltTran=ResolveTranIndex(pPGBlock, pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
	if (nFltTran < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "ResolveTranIndex (%s %s %s) Error\n", pFltDef->szDevSub, pFltDef->szDevVolt, pFltDef->szDevName);
		return 0;
	}
	if (pPGBlock->m_TransformerWindingArray[nFltTran].nIsland != nIsland)
		return 0;

	sprintf(szValue, "%s.%s", pPGBlock->m_TransformerWindingArray[nFltTran].szSub, pPGBlock->m_TransformerWindingArray[nFltTran].szName);
	nBpaTran=FindTranInTArray(szValue);
	if (nBpaTran < 0)
	{
		Log(g_lpszPG2BpaApiLogFile, "FormFltTranSC3String ResolveBpaTran=%s Error\n", szValue);
		return 0;
	}

	fPercent=pFltDef->fPercent;
	sprintf(szValue, "B_%d", pPGBlock->m_TransformerWindingArray[nFltTran].nTopoBusI);
	if (stricmp(m_TranArray[nBpaTran].szBusI, szValue) != 0)
		fPercent=1.0-fPercent;

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	for (nField=0; nField<sizeof(m_BpaDictFltBranSc4)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PAR") == 0)		szValue[0]=m_TranArray[nBpaTran].cLoop;
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "MDE") == 0)		sprintf(szValue, "%d", FLT_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", pFltDef->fTCycle);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTR") == 0)	sprintf(szValue, "%f", pFltDef->fFaultR);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTX") == 0)	sprintf(szValue, "%f", pFltDef->fFaultX);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PERCT") == 0)	{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "NDE") == 0)		sprintf(szValue, "%d", NDE_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PHA") == 0)		sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "SID") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRD") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRX") == 0)	strcpy(szValue, "0");

		Log(g_lpszPG2BpaApiLogFile, "Field[%d] = %s Value=%s\n", nField, m_BpaDictFltBranSc4[nField].szFieldName, szValue);

		FillLineString(m_BpaDictFltBranSc4[nField].nFieldType, m_BpaDictFltBranSc4[nField].nFieldStart, m_BpaDictFltBranSc4[nField].nFieldEnd, m_BpaDictFltBranSc4[nField].nFieldLen, szValue, szLine);
	}
	TrimRight(szLine);
	strRetLineArray.push_back(szLine);
	Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", szLine);

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	for (nField=0; nField<sizeof(m_BpaDictFltBranSc4)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS1") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVI);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BUS2") == 0)		strcpy(szValue, m_TranArray[nBpaTran].szBusJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVJ);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PAR") == 0)		szValue[0]=m_TranArray[nBpaTran].cLoop;
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "MDE") == 0)		sprintf(szValue, "%d", -FLT_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", max(pFltDef->fTCycle+pFltDef->fTCyc1, pFltDef->fTCycle+pFltDef->fTCyc2));
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTR") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTX") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PERCT") == 0)	{	if (fPercent != 0 && fPercent != 1)	sprintf(szValue, "%f", fPercent);	}
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "NDE") == 0)		sprintf(szValue, "%d", NDE_TYPE);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "PHA") == 0)		sprintf(szValue, "%d", pFltDef->nFltPhase+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "SID") == 0)		sprintf(szValue, "%d", pFltDef->nFltSide+1);
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRD") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranSc4[nField].szFieldName, "FAULTRX") == 0)	strcpy(szValue, "0");

		Log(g_lpszPG2BpaApiLogFile, "Field[%d] = %s Value=%s\n", nField, m_BpaDictFltBranSc4[nField].szFieldName, szValue);

		FillLineString(m_BpaDictFltBranSc4[nField].nFieldType, m_BpaDictFltBranSc4[nField].nFieldStart, m_BpaDictFltBranSc4[nField].nFieldEnd, m_BpaDictFltBranSc4[nField].nFieldLen, szValue, szLine);
	}
	TrimRight(szLine);
	strRetLineArray.push_back(szLine);
	Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", szLine);

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	for (nField=0; nField<sizeof(m_BpaDictFltBranTrip)/sizeof(tagBpa_Dict); nField++)
	{
		memset(szValue, 0, MDB_CHARLEN_LONG);
		if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "LS") == 0)			strcpy(szValue, "LS");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN1") == 0)	strcpy(szValue, "-");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS1") == 0)	strcpy(szValue, m_TranArray[nBpaTran].szBusI);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE1") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVI);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "SIGN2") == 0)	strcpy(szValue, "-");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BUS2") == 0)	strcpy(szValue, m_TranArray[nBpaTran].szBusJ);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "BASE2") == 0)	sprintf(szValue, "%f", m_TranArray[nBpaTran].fkVJ);
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PAR") == 0)		szValue[0]=m_TranArray[nBpaTran].cLoop;
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "MDE") == 0)		strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "CYCLE") == 0)	sprintf(szValue, "%f", max(pFltDef->fTCycle+pFltDef->fTCyc1, pFltDef->fTCycle+pFltDef->fTCyc2));
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTR") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "FAULTX") == 0)	strcpy(szValue, "0");
		else if (stricmp(m_BpaDictFltBranTrip[nField].szFieldName, "PERCNT") == 0)	sprintf(szValue, "%f", pFltDef->fPercent);

		Log(g_lpszPG2BpaApiLogFile, "Field[%d] = %s Value=%s\n", nField, m_BpaDictFltBranTrip[nField].szFieldName, szValue);

		FillLineString(m_BpaDictFltBranTrip[nField].nFieldType, m_BpaDictFltBranTrip[nField].nFieldStart, m_BpaDictFltBranTrip[nField].nFieldEnd, m_BpaDictFltBranTrip[nField].nFieldLen, szValue, szLine);
	}
	TrimRight(szLine);
	strRetLineArray.push_back(szLine);
	Log(g_lpszPG2BpaApiLogFile, "Line=%s\n", szLine);

	return 1;
}
