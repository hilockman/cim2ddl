#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"

#include <float.h>

static	std::vector<unsigned char>	m_bGenProcArray;

void CPG2BpaFileApi::FormSwi_GenCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nSub, nVolt, nDev, nField, nRecord;
	int		nSameBusGenNum;
	char	szLine1[256], szLine2[256], szLine3[256];
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	int		nExcModel, nPssModel, nGovModel, nMovModel;
	int		nGenIndex, nDampIndex, nExcIndex, nPssIndex, nGovIndex, nSvoIndex, nMovIndex;
	tagBpaSwi_GenLn	EqGenBuf;

	memset(&EqGenBuf, 0, sizeof(tagBpaSwi_GenLn));
	strcpy(EqGenBuf.szCardKey, "LN");

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				if (m_bGenProcArray[nDev])
					continue;
				m_bGenProcArray[nDev]=1;

				if (pPGBlock->m_SynchronousMachineArray[nDev].nIsland != nIsland)
					continue;

				fprintf(fp, "\n. %s - %s\n", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szName);

				if (strlen(pPGBlock->m_SynchronousMachineArray[nDev].szBpaGenBus) <= 0 || pPGBlock->m_SynchronousMachineArray[nDev].fBpaGenVolt <= 0)
				{
					sprintf(EqGenBuf.szBus_Name, "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					EqGenBuf.fBus_kV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_GENLN, (char*)&EqGenBuf, szField);
					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_GENLN, szField, szLine1, szLine2, szLine3);
					if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
					if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
					if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);

					continue;
				}

				nSameBusGenNum=0;
				for (i=nDev; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
				{
					if (pPGBlock->m_SynchronousMachineArray[i].nIsland != nIsland)
						continue;

					if (pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus == pPGBlock->m_SynchronousMachineArray[i].nTopoBus)
						nSameBusGenNum++;
				}

				m_BpaMemDBInterface.BpaResolveGenModel(pBpaBlock, pPGBlock->m_SynchronousMachineArray[nDev].szBpaGenBus, pPGBlock->m_SynchronousMachineArray[nDev].fBpaGenVolt, '\0', 
					nGenIndex, nDampIndex, nExcModel, nExcIndex, nPssModel, nPssIndex, nGovModel, nGovIndex, nSvoIndex, nMovModel, nMovIndex);
				//Log(g_lpszPG2BpaApiLogFile, "BpaResolveGenModel Gen=[%s %.2f], GenIndex=%d ExcModel=%d ExcIndex=%d PssModel=%d PssIndex=%d GovModel=%d GovIndex=%d SvoIndex=%d MovModel=%d MovIndex=%d\n", 
				//	pPGBlock->m_SynchronousMachineArray[nDev].szBpaGenBus, pPGBlock->m_SynchronousMachineArray[nDev].fBpaGenVolt, 
				//	nGenIndex, nExcModel, nExcIndex, nPssModel, nPssIndex, nGovModel, nGovIndex, nSvoIndex, nMovModel, nMovIndex);

				if (nGenIndex < 0)
					continue;

				for (i=0; i<MAXMDBFIELDNUM; i++)
					memset(szField[i], 0, MDB_CHARLEN_LONG);
				m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_GEN, (char*)&pBpaBlock->m_BpaSwi_GenArray[nGenIndex], szField);
				memset(szField[BPA_SWI_GEN_P], 0, MDB_CHARLEN_LONG);
				memset(szField[BPA_SWI_GEN_Q], 0, MDB_CHARLEN_LONG);

				sprintf(szField[BPA_SWI_GEN_BUS_NAME], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
				sprintf(szField[BPA_SWI_GEN_BUS_KV], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);

				if (pPGBlock->m_SynchronousMachineArray[i].fPlanP > pPGBlock->m_SynchronousMachineArray[i].fPMax)
					sprintf(szField[BPA_SWI_GEN_MVA], "%f", pPGBlock->m_SynchronousMachineArray[i].fPlanP);
				else
					sprintf(szField[BPA_SWI_GEN_MVA], "%f", pPGBlock->m_SynchronousMachineArray[i].fPMax);
				szField[BPA_SWI_GEN_ID][0]=ResolveGenID(pPGBlock, nDev);

				if (nSameBusGenNum > 1)
				{
					sprintf(szField[BPA_SWI_GEN_P], "%f", 1.0/nSameBusGenNum);
					sprintf(szField[BPA_SWI_GEN_Q], "%f", 1.0/nSameBusGenNum);
				}

				memset(szLine1, 0, 256);
				memset(szLine2, 0, 256);
				memset(szLine3, 0, 256);
				m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_GEN, szField, szLine1, szLine2, szLine3);
				if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
				if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
				if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);

				nRecord = m_BpaMemDBInterface.BpaFindRecordbyKey(pBpaBlock, BPA_SWI_DAMP, pBpaBlock->m_BpaSwi_GenArray[nGenIndex].szKeyName);
				if (nRecord >= 0)
				{
					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					m_BpaMemDBInterface.BpaDataPtr2FieldArray(nExcModel, (char*)&pBpaBlock->m_BpaSwi_DampArray[nRecord], szField);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_DAMP, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_DAMP, "ACBus_kV");		sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_DAMP, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);
					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_DAMP, szField, szLine1, szLine2, szLine3);
					if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
					if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
					if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
				}

				if (nExcIndex >= 0)
				{
					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					switch (nExcModel)
					{
					case BPA_SWI_EXCIT68:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nExcModel, (char*)&pBpaBlock->m_BpaSwi_Exc68Array[nExcIndex], szField);	break;
					case BPA_SWI_EXCIT81:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nExcModel, (char*)&pBpaBlock->m_BpaSwi_Exc81Array[nExcIndex], szField);	break;
					case BPA_SWI_EXCITMV:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nExcModel, (char*)&pBpaBlock->m_BpaSwi_ExcMVArray[nExcIndex], szField);	break;
					case BPA_SWI_EXCITX:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nExcModel, (char*)&pBpaBlock->m_BpaSwi_ExcXArray[nExcIndex], szField);	break;
					}

					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nExcModel, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nExcModel, "ACBus_kV");		sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nExcModel, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(nExcModel, szField, szLine1, szLine2, szLine3);
					if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
					if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
					if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);

					if (nExcModel == BPA_SWI_EXCIT81)
					{
						nRecord = m_BpaMemDBInterface.BpaFindRecordbyKey(pBpaBlock, BPA_SWI_FZ, pBpaBlock->m_BpaSwi_Exc81Array[nExcIndex].szKeyName);
						if (nRecord >= 0)
						{
							for (i=0; i<MAXMDBFIELDNUM; i++)
								memset(szField[i], 0, MDB_CHARLEN_LONG);
							m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_FZ, (char*)&pBpaBlock->m_BpaSwi_FZArray[nRecord], szField);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FZ, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FZ, "ACBus_kV");		sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FZ, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

							memset(szLine1, 0, 256);
							memset(szLine2, 0, 256);
							memset(szLine3, 0, 256);
							m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_FZ, szField, szLine1, szLine2, szLine3);
							if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
							if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
							if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
						}
					}
					if (nExcModel == BPA_SWI_EXCITMV)
					{
						nRecord = m_BpaMemDBInterface.BpaFindRecordbyKey(pBpaBlock, BPA_SWI_FCA, pBpaBlock->m_BpaSwi_ExcMVArray[nExcIndex].szKeyName);
						if (nRecord >= 0)
						{
							for (i=0; i<MAXMDBFIELDNUM; i++)
								memset(szField[i], 0, MDB_CHARLEN_LONG);
							m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_FCA, (char*)&pBpaBlock->m_BpaSwi_FCAArray[nRecord], szField);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FCA, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FCA, "ACBus_kV");	sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FCA, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

							memset(szLine1, 0, 256);
							memset(szLine2, 0, 256);
							memset(szLine3, 0, 256);
							m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_FCA, szField, szLine1, szLine2, szLine3);
							if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
							if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
							if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
						}

						nRecord = m_BpaMemDBInterface.BpaFindRecordbyKey(pBpaBlock, BPA_SWI_FCB, pBpaBlock->m_BpaSwi_ExcMVArray[nExcIndex].szKeyName);
						if (nRecord >= 0)
						{
							for (i=0; i<MAXMDBFIELDNUM; i++)
								memset(szField[i], 0, MDB_CHARLEN_LONG);
							m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_FCB, (char*)&pBpaBlock->m_BpaSwi_FCBArray[nRecord], szField);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FCB, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FCB, "ACBus_kV");	sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
							nField=m_BpaMemDBInterface.BpaGetFieldIndex(BPA_SWI_FCB, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

							memset(szLine1, 0, 256);
							memset(szLine2, 0, 256);
							memset(szLine3, 0, 256);
							m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_FCB, szField, szLine1, szLine2, szLine3);
							if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
							if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
							if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
						}
					}
				}

				if (nPssIndex >= 0)
				{
					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					switch (nPssModel)
					{
					case BPA_SWI_PSSS:		m_BpaMemDBInterface.BpaDataPtr2FieldArray(nPssModel, (char*)&pBpaBlock->m_BpaSwi_PssSArray[nPssIndex], szField);	break;
					case BPA_SWI_PSSSH:		m_BpaMemDBInterface.BpaDataPtr2FieldArray(nPssModel, (char*)&pBpaBlock->m_BpaSwi_PssSHArray[nPssIndex], szField);	break;
					case BPA_SWI_PSSSI:		m_BpaMemDBInterface.BpaDataPtr2FieldArray(nPssModel, (char*)&pBpaBlock->m_BpaSwi_PssSIArray[nPssIndex], szField);	break;
					case BPA_SWI_PSSSA:		m_BpaMemDBInterface.BpaDataPtr2FieldArray(nPssModel, (char*)&pBpaBlock->m_BpaSwi_PssSAArray[nPssIndex], szField);	break;
					case BPA_SWI_PSSSB:		m_BpaMemDBInterface.BpaDataPtr2FieldArray(nPssModel, (char*)&pBpaBlock->m_BpaSwi_PssSBArray[nPssIndex], szField);	break;
					case BPA_SWI_PSSST:		m_BpaMemDBInterface.BpaDataPtr2FieldArray(nPssModel, (char*)&pBpaBlock->m_BpaSwi_PssSTArray[nPssIndex], szField);	break;
					}


					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nPssModel, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nPssModel, "ACBus_kV");		sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nPssModel, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(nPssModel, szField, szLine1, szLine2, szLine3);

					if (strlen(szLine1) > 0)	{	fprintf(fp, "%s\n", szLine1);		}
					if (strlen(szLine2) > 0)	{	fprintf(fp, "%s\n", szLine2);		}
					if (strlen(szLine3) > 0)	{	fprintf(fp, "%s\n", szLine3);		}
				}

				if (nGovIndex >= 0)
				{
					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					switch (nGovModel)
					{
					case BPA_SWI_GG:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GGArray[nGovIndex], szField);	break;
					case BPA_SWI_GH:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GHArray[nGovIndex], szField);	break;
					case BPA_SWI_GC:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GCArray[nGovIndex], szField);	break;
					case BPA_SWI_GS:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GSArray[nGovIndex], szField);	break;
					case BPA_SWI_GL:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GLArray[nGovIndex], szField);	break;
					case BPA_SWI_GW:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GWArray[nGovIndex], szField);	break;
					case BPA_SWI_GI:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GIArray[nGovIndex], szField);	break;
					case BPA_SWI_GJ:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GJArray[nGovIndex], szField);	break;
					case BPA_SWI_GK:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GKArray[nGovIndex], szField);	break;
					case BPA_SWI_GM:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GMArray[nGovIndex], szField);	break;
					case BPA_SWI_GD:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GDArray[nGovIndex], szField);	break;
					case BPA_SWI_GZ:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nGovModel, (char*)&pBpaBlock->m_BpaSwi_GZArray[nGovIndex], szField);	break;
					}

					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nGovModel, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nGovModel, "ACBus_kV");		sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nGovModel, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

					//	��ֹģ����ԭ��������С�ڷ��������
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nGovModel, "Gen_PMax");
					if (nField >= 0)
					{
						if (atof(szField[nField]) < pPGBlock->m_SynchronousMachineArray[i].fPlanP)
						{
							if (pPGBlock->m_SynchronousMachineArray[i].fPlanP > pPGBlock->m_SynchronousMachineArray[i].fPMax)
								sprintf(szField[nField], "%f", pPGBlock->m_SynchronousMachineArray[i].fPlanP);
							else
								sprintf(szField[nField], "%f", pPGBlock->m_SynchronousMachineArray[i].fPMax);
						}
					}

					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(nGovModel, szField, szLine1, szLine2, szLine3);
					if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
					if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
					if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
				}

				if (nSvoIndex >= 0)
				{
					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_GA, (char*)&pBpaBlock->m_BpaSwi_GAArray[nSvoIndex], szField);
					nField=BPA_SWI_GA_BUS_NAME;	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					nField=BPA_SWI_GA_BUS_KV;	sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					nField=BPA_SWI_GA_GEN_ID;	szField[nField][0]=ResolveGenID(pPGBlock, nDev);

					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_GA, szField, szLine1, szLine2, szLine3);
					if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
					if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
					if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
				}

				if (nMovIndex >= 0)
				{
					for (i=0; i<MAXMDBFIELDNUM; i++)
						memset(szField[i], 0, MDB_CHARLEN_LONG);
					switch (nMovModel)
					{
					case BPA_SWI_TA:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TAArray[nMovIndex], szField);	break;
					case BPA_SWI_TB:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TBArray[nMovIndex], szField);	break;
					case BPA_SWI_TC:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TCArray[nMovIndex], szField);	break;
					case BPA_SWI_TD:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TDArray[nMovIndex], szField);	break;
					case BPA_SWI_TE:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TEArray[nMovIndex], szField);	break;
					case BPA_SWI_TF:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TFArray[nMovIndex], szField);	break;
					case BPA_SWI_TW:	m_BpaMemDBInterface.BpaDataPtr2FieldArray(nMovModel, (char*)&pBpaBlock->m_BpaSwi_TWArray[nMovIndex], szField);	break;
					}

					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nMovModel, "ACBus_Name");	sprintf(szField[nField], "B_%d", pPGBlock->m_SynchronousMachineArray[nDev].nTopoBus);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nMovModel, "ACBus_kV");		sprintf(szField[nField], "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
					nField=m_BpaMemDBInterface.BpaGetFieldIndex(nMovModel, "Gen_ID");		szField[nField][0]=ResolveGenID(pPGBlock, nDev);

					memset(szLine1, 0, 256);
					memset(szLine2, 0, 256);
					memset(szLine3, 0, 256);
					m_BpaMemDBInterface.BpaFieldArray2LineString(nMovModel, szField, szLine1, szLine2, szLine3);
					if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
					if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
					if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
				}
			}
		}
	}

	fprintf(fp, "\n\n");
}

void CPG2BpaFileApi::FormSwi_LSCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nFlt;
	std::vector<std::string>	strLineArray;
	//char	szLine[256];

	for (nFlt=0; nFlt<GetBpaFltDefineNum(); nFlt++)
	{
		if (!m_FltDefArray[nFlt].bRunFlt)
			continue;

// 		for (i=0; i<255; i++)
// 			szLine[i]=' ';
// 		szLine[255]='\0';

		if (FormFltString(pPGBlock, nIsland, &m_FltDefArray[nFlt], strLineArray))
		{
			for (i=0; i<(int)strLineArray.size(); i++)
				fprintf(fp, "\n%s\n", strLineArray[i].c_str());
		}
	}
	fprintf(fp, "\n");
}

void CPG2BpaFileApi::FormSwi_MLCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nSub, nVolt, nDev;

	std::vector<tagBusLoadModel>	BusMotorModelArray;
	BusMotorModelArray.clear();

	BusMotorModelArray.resize(pPGBlock->m_nRecordNum[PG_TOPOBUS]);
	for (i=0; i<(int)BusMotorModelArray.size(); i++)
	{
		memset(&BusMotorModelArray[i], 0, sizeof(tagBusLoadModel));
		BusMotorModelArray[i].nMotorLoad=-1;
	}
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus < 3)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fMotorTj <= FLT_MIN || pPGBlock->m_EnergyConsumerArray[nDev].fMotorPper <= FLT_MIN)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;

				BusMotorModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].fBusVolt=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
				BusMotorModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].nMotorLoad=nDev;

				BusMotorModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].fLoadP += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
				BusMotorModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].fMotorP += pPGBlock->m_EnergyConsumerArray[nDev].fMotorPper*pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
			}
		}
	}

	char	szLine[256];
	tagBpaSwi_ML	mBuf;
	memset(&mBuf, 0, sizeof(tagBpaSwi_ML));
	strcpy(mBuf.szCardKey, "ML");

	fprintf(fp, ".���ɵ�����ģ��\n");
	for (nDev=3; nDev<(int)BusMotorModelArray.size(); nDev++)
	{
		if (BusMotorModelArray[nDev].fLoadP < FLT_MIN)
			continue;
		if (BusMotorModelArray[nDev].fMotorP < FLT_MIN)
			continue;
		if (BusMotorModelArray[nDev].nMotorLoad < 0 || BusMotorModelArray[nDev].nMotorLoad >= pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER])
			continue;
		if (pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].nIsland != nIsland)
			continue;

		sprintf(mBuf.szBus_Name, "B_%d", nDev);
		mBuf.fBus_kV=BusMotorModelArray[nDev].fBusVolt;

		mBuf.fPper=BusMotorModelArray[nDev].fMotorP/BusMotorModelArray[nDev].fLoadP;

		mBuf.fTJ=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorTj;
		mBuf.fKL=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorKl;
		mBuf.fRS=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorRs;
		mBuf.fXS=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorXs;
		mBuf.fXM=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorXm;
		mBuf.fRR=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorRr;
		mBuf.fXR=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorXr;
		mBuf.fA=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorA;
		mBuf.fB=pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].fMotorB;
		mBuf.cUseS0 = (pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].bUseS0) ? 'S' : ' ';
		mBuf.bIM=(pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].nMotorIM > 0) ? pPGBlock->m_EnergyConsumerArray[BusMotorModelArray[nDev].nMotorLoad].nMotorIM-1 : m_BpaSwiConCard.bIMBLOK;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("ML", BpaSwiCategory_Dat);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_ML, nDictIni, (const char*)&mBuf, szLine) <= 0)
			break;

		fprintf(fp, "%s\n", szLine);
	}
	fprintf(fp, "\n");
}

void CPG2BpaFileApi::FormSwi_XOCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nDev;
	char	szLine[256];

	for (nDev=0; nDev<(int)m_XOArray.size(); nDev++)
	{
		if (m_XOArray[nDev].fR0 <= FLT_MIN && m_XOArray[nDev].fX0 <= FLT_MIN)
			continue;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("XO", -1);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_XO, nDictIni, (const char*)&m_XOArray[nDev], szLine) <= 0)
			continue;

		fprintf(fp, "%s\n", szLine);
	}
	fprintf(fp, "\n");
}

void CPG2BpaFileApi::FormSwi_LOCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nDev;
	char	szLine[256];

	for (nDev=0; nDev<(int)m_LOArray.size(); nDev++)
	{
		if (m_LOArray[nDev].fR0 <= FLT_MIN && m_LOArray[nDev].fX0 <= FLT_MIN)
			continue;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("LO", -1);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_LO, nDictIni, (const char*)&m_LOArray[nDev], szLine) <= 0)
			continue;

		fprintf(fp, "%s\n", szLine);
	}
	fprintf(fp, "\n");
}

void CPG2BpaFileApi::FormSwi_XRCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nDev;
	char	szLine[256];

	for (nDev=0; nDev<(int)m_XRArray.size(); nDev++)
	{
		if (m_XRArray[nDev].fR0 <= FLT_MIN && m_XRArray[nDev].fX0 <= FLT_MIN)
			continue;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("XR", -1);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_XR, nDictIni, (const char*)&m_BusArray[nDev], szLine) <= 0)
			continue;

		fprintf(fp, "%s\n", szLine);
	}
	fprintf(fp, "\n");
}

void CPG2BpaFileApi::FormSwi_LBCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nDictIni, nZone, nSub, nVolt, nDev;
	int		nLoadModel;
	char	szLine[256];
	tagBpaSwi_LAB	lbBuf;

	//////////////////////////////////////////////////////////////////////////
	//	������������ľ�̬����ģ��
	//////////////////////////////////////////////////////////////////////////
	memset(&lbBuf, 0, sizeof(tagBpaSwi_LAB));
	strcpy(lbBuf.szCardKey, "LB");

	nLoadModel=-1;
	for (i=0; i<GetBpaStaticLoadModelNum(); i++)
	{
		if (stricmp(m_szDefaultLoadSModel, m_LoadSModelArray[i].szName) == 0)
		{
			nLoadModel=i;
			break;
		}
	}

	if (nLoadModel < 0 && GetBpaStaticLoadModelNum() > 0)
		nLoadModel=0;
	if (nLoadModel >= 0)
	{
		fprintf(fp, ".�����ľ�̬����ģ��\n");
		if (pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA] > 0)
		{
			for (nZone=0; nZone<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nZone++)
			{
				sprintf(lbBuf.szZone, "%d", nZone);
				lbBuf.fP1=m_LoadSModelArray[nLoadModel].fP1;
				lbBuf.fP2=m_LoadSModelArray[nLoadModel].fP2;
				lbBuf.fP3=m_LoadSModelArray[nLoadModel].fP3;
				lbBuf.fLDP=m_LoadSModelArray[nLoadModel].fLDP;

				lbBuf.fQ1=m_LoadSModelArray[nLoadModel].fQ1;
				lbBuf.fQ2=m_LoadSModelArray[nLoadModel].fQ2;
				lbBuf.fQ3=m_LoadSModelArray[nLoadModel].fQ3;
				lbBuf.fLDQ=m_LoadSModelArray[nLoadModel].fLDQ;

				for (i=0; i<255; i++)
					szLine[i]=' ';
				szLine[255]='\0';

				nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("LB", BpaSwiCategory_Dat);
				if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_LAB, nDictIni, (const char*)&lbBuf, szLine) <= 0)
					break;

				fprintf(fp, "%s\n", szLine);
			}
		}
		else
		{
			nZone=0;
			sprintf(lbBuf.szZone, "%d", nZone);
			lbBuf.fP1=m_LoadSModelArray[nLoadModel].fP1;
			lbBuf.fP2=m_LoadSModelArray[nLoadModel].fP2;
			lbBuf.fP3=m_LoadSModelArray[nLoadModel].fP3;
			lbBuf.fLDP=m_LoadSModelArray[nLoadModel].fLDP;

			lbBuf.fQ1=m_LoadSModelArray[nLoadModel].fQ1;
			lbBuf.fQ2=m_LoadSModelArray[nLoadModel].fQ2;
			lbBuf.fQ3=m_LoadSModelArray[nLoadModel].fQ3;
			lbBuf.fLDQ=m_LoadSModelArray[nLoadModel].fLDQ;

			for (i=0; i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';

			nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("LB", BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_LAB, nDictIni, (const char*)&lbBuf, szLine) > 0)
				fprintf(fp, "%s\n", szLine);
		}
	}
	fprintf(fp, "\n");

	//////////////////////////////////////////////////////////////////////////
	//	�������򸺺ɵ�ľ�̬����ģ��
	//////////////////////////////////////////////////////////////////////////
	std::vector<tagBusLoadModel>	BusLoadModelArray;
	BusLoadModelArray.clear();
	BusLoadModelArray.resize(pPGBlock->m_nRecordNum[PG_TOPOBUS]);
	for (i=0; i<(int)BusLoadModelArray.size(); i++)
	{
		memset(&BusLoadModelArray[i], 0, sizeof(tagBusLoadModel));
		BusLoadModelArray[i].nMotorLoad=-1;
		BusLoadModelArray[i].nSModelLoad=-1;
	}
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus < 3)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;

				//	ȱʡģ�Ͳ�����
				if (stricmp(pPGBlock->m_EnergyConsumerArray[nDev].szSModel, m_szDefaultLoadSModel) == 0)
					continue;

				nLoadModel=-1;
				for (i=0; i<GetBpaStaticLoadModelNum(); i++)
				{
					if (stricmp(pPGBlock->m_EnergyConsumerArray[nDev].szSModel, m_LoadSModelArray[i].szName) == 0)
					{
						nLoadModel=i;
						break;
					}
				}

				BusLoadModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].fLoadP += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
				if (nLoadModel >= 0)
					BusLoadModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].nSModelLoad=nLoadModel;
				BusLoadModelArray[pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus].fBusVolt=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			}
		}
	}


	fprintf(fp, ".���ɵ�ľ�̬����ģ��\n");
	memset(&lbBuf, 0, sizeof(tagBpaSwi_LAB));
	strcpy(lbBuf.szCardKey, "LB");

	for (nDev=3; nDev<(int)BusLoadModelArray.size(); nDev++)
	{
		if (BusLoadModelArray[nDev].fLoadP < FLT_MIN)
			continue;
		if (BusLoadModelArray[nDev].nSModelLoad < 0)
			continue;

		sprintf(lbBuf.szBus_Name, "B_%d", nDev);
		lbBuf.fBus_kV=BusLoadModelArray[nDev].fBusVolt;

		lbBuf.fP1=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fP1;
		lbBuf.fP2=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fP2;
		lbBuf.fP3=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fP3;
		lbBuf.fLDP=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fLDP;

		lbBuf.fQ1=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fQ1;
		lbBuf.fQ2=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fQ2;
		lbBuf.fQ3=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fQ3;
		lbBuf.fLDQ=m_LoadSModelArray[BusLoadModelArray[nDev].nSModelLoad].fLDQ;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex("LB", BpaSwiCategory_Dat);
		if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_LAB, nDictIni, (const char*)&lbBuf, szLine) <= 0)
			break;

		fprintf(fp, "%s\n", szLine);
	}
	fprintf(fp, "\n");
}

int CPG2BpaFileApi::RegularUF(tagBpaSwi_UF& ufBuf)
{
	register int	i, j;
	float	fBuf, *pfTuning, *pfTime, *pfValue;
	int		nRound;

	pfTuning=&ufBuf.fFreq01;
	pfTime=&ufBuf.fDelay01;
	pfValue=&ufBuf.fShed01;

	i = 0;
	nRound = g_nMaxUFUVRounds;
	while (i < nRound)
	{
		if (pfTuning[i] < 0.001 || pfTime[i] < 0.001)
		{
			for (j=i; j<g_nMaxUFUVRounds-1; j++)
			{
				pfTuning[j] = pfTuning[j+1];
				pfTime[j] = pfTime[j+1];
				pfValue[j] = pfValue[j+1];
			}
			nRound--;
		}
		else
		{
			i++;
		}
	}
	for (i=0; i<g_nMaxUFUVRounds; i++)
	{
		if (pfTuning[i] < 0.001 || pfTime[i] < 0.001)
			continue;

		for (j=i+1; j<g_nMaxUFUVRounds; j++)
		{
			if (pfTuning[j] < 0.001 || pfTime[j] < 0.001)
				continue;

			if (pfTime[i] > pfTime[j])	//	��ʱ�����򣨴�С��������
			{
				fBuf=pfTuning[i];
				pfTuning[i]=pfTuning[j];
				pfTuning[j]=fBuf;

				fBuf=pfTime[i];
				pfTime[i]=pfTime[j];
				pfTime[j]=fBuf;

				fBuf=pfValue[i];
				pfValue[i]=pfValue[j];
				pfValue[j]=fBuf;
			}
			else if (fabs(pfTime[i] - pfTime[j]) < FLT_MIN && pfTuning[i] < pfTuning[j])	//	������Ƶ�ʽ��򣨴Ӵ�С������
			{
				fBuf=pfTuning[i];
				pfTuning[i]=pfTuning[j];
				pfTuning[j]=fBuf;

				fBuf=pfTime[i];
				pfTime[i]=pfTime[j];
				pfTime[j]=fBuf;

				fBuf=pfValue[i];
				pfValue[i]=pfValue[j];
				pfValue[j]=fBuf;
			}
		}
	}

	nRound=0;
	for (i=0; i<g_nMaxUFUVRounds; i++)
	{
		if (pfTuning[i] < 0.001)
			break;

		nRound++;
	}
	return nRound;
}

int CPG2BpaFileApi::RegularUV(tagBpaSwi_UV& uvBuf)
{
	register int	i, j;
	float	fBuf, *pfTuning, *pfTime, *pfValue;
	int		nRound;

	pfTuning=&uvBuf.fVolt01;
	pfTime=&uvBuf.fDelay01;
	pfValue=&uvBuf.fShed01;

	i = 0;
	nRound = g_nMaxUFUVRounds;
	while (i < nRound)
	{
		if (pfTuning[i] < 0.001 || pfTime[i] < 0.001)
		{
			for (j=i; j<g_nMaxUFUVRounds-1; j++)
			{
				pfTuning[j] = pfTuning[j+1];
				pfTime[j] = pfTime[j+1];
				pfValue[j] = pfValue[j+1];
			}
			nRound--;
		}
		else
		{
			i++;
		}
	}

	for (i=0; i<g_nMaxUFUVRounds; i++)
	{
		if (pfTuning[i] < 0.001 || pfTime[i] < 0.001)
			continue;

		for (j=i+1; j<g_nMaxUFUVRounds; j++)
		{
			if (pfTuning[j] < 0.001 || pfTime[j] < 0.001)
				continue;

			if (pfTime[i] > pfTime[j])
			{
				fBuf=pfTuning[i];
				pfTuning[i]=pfTuning[j];
				pfTuning[j]=fBuf;

				fBuf=pfTime[i];
				pfTime[i]=pfTime[j];
				pfTime[j]=fBuf;

				fBuf=pfValue[i];
				pfValue[i]=pfValue[j];
				pfValue[j]=fBuf;
			}
			else if (fabs(pfTime[i] - pfTime[j]) < FLT_MIN && pfTuning[i] < pfTuning[j])
			{
				fBuf=pfTuning[i];
				pfTuning[i]=pfTuning[j];
				pfTuning[j]=fBuf;

				fBuf=pfTime[i];
				pfTime[i]=pfTime[j];
				pfTime[j]=fBuf;

				fBuf=pfValue[i];
				pfValue[i]=pfValue[j];
				pfValue[j]=fBuf;
			}
		}
	}

	nRound=0;
	for (i=0; i<g_nMaxUFUVRounds; i++)
	{
		if (pfTuning[i] < 0.001)
			break;

		nRound++;
	}
	return nRound;
}

void CPG2BpaFileApi::FormSwi_UFCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nSub, nVolt, nDev, nAuto, nRound;
	tagBpaSwi_UF	ufBuf;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	char	szLine1[256], szLine2[256], szLine3[256];
	float	*pfTuning, *pfTime, *pfValue;

	std::vector<tagBpaSwi_UF>	ufArray;
	std::vector<tagBpaSwi_UF>	ufRatioArray;

	ufArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus < 3)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fPlanP < FLT_MIN)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFFreq < FLT_MIN)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].bAutoUFPlate != PGEnumPlateStatus_Close)
					continue;

				memset(&ufBuf, 0, sizeof(tagBpaSwi_UF));
				strcpy(ufBuf.szCardKey, "UF");
				ufBuf.cW='W';										//	�ر���W����ʾ��MWΪ��λ��ȥ����

				sprintf(ufBuf.szBus, "B_%d", pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus);
				ufBuf.fKV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)

				nAuto=-1;
				for (i=0; i<(int)ufArray.size(); i++)
				{
					if (stricmp(ufArray[i].szBus, ufBuf.szBus) == 0 && fabs(ufArray[i].fKV - ufBuf.fKV) < 0.01)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto < 0)
				{
					pfTuning=&ufBuf.fFreq01;
					pfTime=&ufBuf.fDelay01;
					pfValue=&ufBuf.fShed01;

					pfTuning[0]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFFreq;
					pfTime[0]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFDelay;
					pfValue[0]=pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;

					ufArray.push_back(ufBuf);
				}
				else
				{
					pfTuning=&ufArray[nAuto].fFreq01;
					pfTime=&ufArray[nAuto].fDelay01;
					pfValue=&ufArray[nAuto].fShed01;
					nRound=-1;
					for (i=0; i<g_nMaxUFUVRounds; i++)
					{
						if (fabs(pfTuning[i] - pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFFreq) < 0.001)
						{
							nRound=i;
							break;
						}
					}
					if (nRound >= 0)
					{
						pfTuning[nRound]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFFreq;
						pfTime[nRound]=min(pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFDelay, pfTime[nRound]);
						pfValue[nRound] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
					}
					else
					{
						for (i=0; i<g_nMaxUFUVRounds; i++)
						{
							if (fabs(pfTuning[i]) < 0.001)
							{
								pfTuning[i]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFFreq;
								pfTime[i]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFDelay;
								pfValue[i] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
								break;
							}
						}
					}
				}
			}
		}
	}

// 	Log(g_lpszPG2BpaApiLogFile, "UFRatio[%d] Round1 = %f %f %f\n", nAuto, m_SysUFSetting[nAuto].fTuning, m_SysUFSetting[nAuto].fDelay01, m_SysUFSetting[nAuto].fShed);						
// 	Log(g_lpszPG2BpaApiLogFile, "UFRatio[%d] Round2 = %f %f %f\n", nAuto, m_SysUFSetting[nAuto].fTuning, m_SysUFSetting[nAuto].fDelay02, m_SysUFSetting[nAuto].fShed);						
// 	Log(g_lpszPG2BpaApiLogFile, "UFRatio[%d] Round3 = %f %f %f\n", nAuto, m_SysUFSetting[nAuto].fTuning, m_SysUFSetting[nAuto].fDelay03, m_SysUFSetting[nAuto].fShed03);						
	ufRatioArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus < 3)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fPlanP < FLT_MIN)
					continue;
				//if (pPGBlock->m_EnergyConsumerArray[nDev].fAutoUFFreq > FLT_MIN)
				//	continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].bAutoUFPlate != PGEnumPlateStatus_Close)
					continue;

				memset(&ufBuf, 0, sizeof(tagBpaSwi_UF));
				strcpy(ufBuf.szCardKey, "UF");
				ufBuf.cW='W';										//	�ر���W����ʾ��MWΪ��λ��ȥ����

				sprintf(ufBuf.szBus, "B_%d", pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus);
				ufBuf.fKV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
				//////////////////////////////////////////////////////////////////////////
				//	ȷ����ĸ��û�е��ܼ���
				nAuto=-1;
				for (i=0; i<(int)ufArray.size(); i++)
				{
					if (stricmp(ufArray[i].szBus, ufBuf.szBus) == 0 && fabs(ufArray[i].fKV - ufBuf.fKV) < 0.01)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto >= 0)
				{
					Log(g_lpszPG2BpaApiLogFile, "���ܼ��� ĸ�� =%d �޸��ɵ��ܼ���\n", pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus);
					continue;
				}
				//	ȷ����ĸ��û�е��ܼ���
				//////////////////////////////////////////////////////////////////////////

				//////////////////////////////////////////////////////////////////////////
				//	��ĸ�ߵ��ܱ���������
				nAuto=-1;
				for (i=0; i<(int)ufRatioArray.size(); i++)
				{
					if (stricmp(ufRatioArray[i].szBus, ufBuf.szBus) == 0 && fabs(ufRatioArray[i].fKV - ufBuf.fKV) < 0.01)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto < 0)
				{
					pfTuning=&ufBuf.fFreq01;
					pfTime=&ufBuf.fDelay01;
					pfValue=&ufBuf.fShed01;

					for (nRound=0; nRound<g_nMaxUFUVRounds; nRound++)
					{
						if (m_SysUFSetting.fTuning[nRound] < FLT_MIN || m_SysUFSetting.fShed[nRound] < FLT_MIN)
							continue;

						pfTuning[nRound]=m_SysUFSetting.fTuning[nRound];
						pfTime[nRound]=m_SysUFSetting.fDelay[nRound];
						pfValue[nRound] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*m_SysUFSetting.fShed[nRound];
					}
					ufRatioArray.push_back(ufBuf);
				}
				else
				{
					pfValue=&ufRatioArray[nAuto].fShed01;
					for (nRound=0; nRound<g_nMaxUFUVRounds; nRound++)
					{
						if (m_SysUFSetting.fTuning[nRound] < FLT_MIN || m_SysUFSetting.fShed[nRound] < FLT_MIN)
							continue;
						pfValue[nRound] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*m_SysUFSetting.fShed[nRound];
					}
				}
				//////////////////////////////////////////////////////////////////////////
			}
		}
	}

	Log(g_lpszPG2BpaApiLogFile, "���ܼ��� ���ɵ��ܼ���=%d �������ܼ���=%d\n", ufArray.size(), ufRatioArray.size());

	fprintf(fp, ".���ܼ���ģ��\n");
	for (nAuto=0; nAuto<(int)ufArray.size(); nAuto++)
	{
		nRound=RegularUF(ufArray[nAuto]);
		if (nRound <= 0)
			continue;

		if (nRound > 5)
		{
			for (i=0; i<MAXMDBFIELDNUM; i++)
				memset(szField[i], 0, MDB_CHARLEN_LONG);

			m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_UF, (char*)&ufArray[nAuto], szField);

			memset(szLine1, 0, 256);
			memset(szLine2, 0, 256);
			memset(szLine3, 0, 256);
			m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_UF, szField, szLine1, szLine2, szLine3);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n" , szLine1);
			if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
			if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
		}
		else
		{
			for (i=0; i<255; i++)
				szLine1[i]=' ';
			szLine1[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(ufArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_UF, nDictIni, (const char*)&ufArray[nAuto], szLine1) > 0)
				fprintf(fp, "%s\n", szLine1);
		}
	}

	for (nAuto=0; nAuto<(int)ufRatioArray.size(); nAuto++)
	{
		nRound=RegularUF(ufRatioArray[nAuto]);
		if (nRound <= 0)
			continue;

		if (nRound > 5)
		{
			for (i=0; i<MAXMDBFIELDNUM; i++)
				memset(szField[i], 0, MDB_CHARLEN_LONG);

			m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_UF, (char*)&ufRatioArray[nAuto], szField);

			memset(szLine1, 0, 256);
			memset(szLine2, 0, 256);
			memset(szLine3, 0, 256);
			m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_UF, szField, szLine1, szLine2, szLine3);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n" , szLine1);
			if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
			if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
		}
		else
		{
			for (i=0; i<255; i++)
				szLine1[i]=' ';
			szLine1[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(ufRatioArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_UF, nDictIni, (const char*)&ufRatioArray[nAuto], szLine1) > 0)
				fprintf(fp, "%s\n", szLine1);
		}
	}
	fprintf(fp, "\n");

	ufArray.clear();
	ufRatioArray.clear();
}

void CPG2BpaFileApi::FormSwi_UVCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nSub, nVolt, nDev, nAuto, nRound;
	tagBpaSwi_UV	uvBuf;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	char	szLine1[256], szLine2[256], szLine3[256];
	float	*pfTuning, *pfTime, *pfValue;

	std::vector<tagBpaSwi_UV>	uvArray;
	std::vector<tagBpaSwi_UV>	uvRatioArray;

	uvArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus < 3)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fPlanP < FLT_MIN)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVVolt < FLT_MIN)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].bAutoUVPlate != PGEnumPlateStatus_Close)
					continue;

				memset(&uvBuf, 0, sizeof(tagBpaSwi_UV));
				strcpy(uvBuf.szCardKey, "UV");
				uvBuf.cW='W';										//	�ر���W����ʾ��MWΪ��λ��ȥ����

				sprintf(uvBuf.szBus, "B_%d", pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus);
				uvBuf.fKV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

				nAuto=-1;
				for (i=0; i<(int)uvArray.size(); i++)
				{
					if (stricmp(uvArray[i].szBus, uvBuf.szBus) == 0 && fabs(uvArray[i].fKV - uvBuf.fKV) < 0.01)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto < 0)
				{
					pfTuning=&uvBuf.fVolt01;
					pfTime=&uvBuf.fDelay01;
					pfValue=&uvBuf.fShed01;

					pfTuning[0]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVVolt;
					pfTime[0]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVDelay;
					pfValue[0]=pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;

					uvArray.push_back(uvBuf);
				}
				else
				{
					pfTuning=&uvArray[nAuto].fVolt01;
					pfTime=&uvArray[nAuto].fDelay01;
					pfValue=&uvArray[nAuto].fShed01;
					nRound=-1;
					for (i=0; i<g_nMaxUFUVRounds; i++)
					{
						if (fabs(pfTuning[i] - pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVVolt) < 0.001)
						{
							nRound=i;
							break;
						}
					}
					if (nRound >= 0)
					{
						pfTuning[nRound]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVVolt;
						pfTime[nRound]=min(pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVDelay, pfTime[nRound]);
						pfValue[nRound] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
					}
					else
					{
						for (i=0; i<g_nMaxUFUVRounds; i++)
						{
							if (fabs(pfTuning[i]) < 0.001)
							{
								pfTuning[i]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVVolt;
								pfTime[i]=pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVDelay;
								pfValue[i] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
								break;
							}
						}
					}
				}
			}
		}
	}

	uvRatioArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nIsland != nIsland)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus < 3)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].fPlanP < FLT_MIN)
					continue;
				//if (pPGBlock->m_EnergyConsumerArray[nDev].fAutoUVVolt > FLT_MIN)
				//	continue;
				if (pPGBlock->m_EnergyConsumerArray[nDev].bAutoUVPlate != PGEnumPlateStatus_Close)
					continue;

				memset(&uvBuf, 0, sizeof(tagBpaSwi_UV));
				strcpy(uvBuf.szCardKey, "UV");
				uvBuf.cW='W';										//	�ر���W����ʾ��MWΪ��λ��ȥ����

				sprintf(uvBuf.szBus, "B_%d", pPGBlock->m_EnergyConsumerArray[nDev].nTopoBus);
				uvBuf.fKV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;

				//////////////////////////////////////////////////////////////////////////
				//	ȷ����ĸ��û�е�ѹ����
				nAuto=-1;
				for (i=0; i<(int)uvArray.size(); i++)
				{
					if (stricmp(uvArray[i].szBus, uvBuf.szBus) == 0 && fabs(uvArray[i].fKV - uvBuf.fKV) < 0.01)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto >= 0)
					continue;
				//	ȷ���õ�ѹ����û����д��
				//////////////////////////////////////////////////////////////////////////

				//////////////////////////////////////////////////////////////////////////
				nAuto=-1;
				for (i=0; i<(int)uvRatioArray.size(); i++)
				{
					if (stricmp(uvRatioArray[i].szBus, uvBuf.szBus) == 0 && fabs(uvRatioArray[i].fKV - uvBuf.fKV) < 0.01)
					{
						nAuto=i;
						break;
					}
				}

				if (nAuto < 0)
				{
					pfTuning=&uvBuf.fVolt01;
					pfTime=&uvBuf.fDelay01;
					pfValue=&uvBuf.fShed01;

					for (nRound=0; nRound<g_nMaxUFUVRounds; nRound++)
					{
						if (m_SysUVSetting.fTuning[nRound] < FLT_MIN || m_SysUVSetting.fShed[nRound] < FLT_MIN)
							continue;
						pfTuning[nRound]=m_SysUVSetting.fTuning[nRound];
						pfTime[nRound]=m_SysUVSetting.fDelay[nRound];
						pfValue[nRound] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*m_SysUVSetting.fShed[nRound];
					}
					uvRatioArray.push_back(uvBuf);
				}
				else
				{
					pfValue=&uvRatioArray[nAuto].fShed01;
					for (nRound=0; nRound<g_nMaxUFUVRounds; nRound++)
					{
						if (m_SysUVSetting.fTuning[nRound] < FLT_MIN || m_SysUVSetting.fShed[nRound] < FLT_MIN)
							continue;
						pfValue[nRound] += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*m_SysUVSetting.fShed[nRound];
					}
				}
				//////////////////////////////////////////////////////////////////////////
			}
		}
	}

	fprintf(fp, ".��ѹ����ģ��\n");
	for (nAuto=0; nAuto<(int)uvArray.size(); nAuto++)
	{
		nRound=RegularUV(uvArray[nAuto]);
		if (nRound <= 0)
			continue;

		if (nRound > 5)
		{
			for (i=0; i<MAXMDBFIELDNUM; i++)
				memset(szField[i], 0, MDB_CHARLEN_LONG);

			m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_UV, (char*)&uvArray[nAuto], szField);

			memset(szLine1, 0, 256);
			memset(szLine2, 0, 256);
			memset(szLine3, 0, 256);
			m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_UV, szField, szLine1, szLine2, szLine3);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n" , szLine1);
			if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
			if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
		}
		else
		{
			for (i=0; i<255; i++)
				szLine1[i]=' ';
			szLine1[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(uvArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_UV, nDictIni, (const char*)&uvArray[nAuto], szLine1) > 0)
				fprintf(fp, "%s\n", szLine1);
		}
	}

	for (nAuto=0; nAuto<(int)uvRatioArray.size(); nAuto++)
	{
		nRound=RegularUV(uvRatioArray[nAuto]);
		if (nRound <= 0)
			continue;

		if (nRound > 5)
		{
			for (i=0; i<MAXMDBFIELDNUM; i++)
				memset(szField[i], 0, MDB_CHARLEN_LONG);

			m_BpaMemDBInterface.BpaDataPtr2FieldArray(BPA_SWI_UV, (char*)&uvRatioArray[nAuto], szField);

			memset(szLine1, 0, 256);
			memset(szLine2, 0, 256);
			memset(szLine3, 0, 256);
			m_BpaMemDBInterface.BpaFieldArray2LineString(BPA_SWI_UV, szField, szLine1, szLine2, szLine3);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n" , szLine1);
			if (strlen(szLine2) > 0)	fprintf(fp, "%s\n", szLine2);
			if (strlen(szLine3) > 0)	fprintf(fp, "%s\n", szLine3);
		}
		else
		{
			for (i=0; i<255; i++)
				szLine1[i]=' ';
			szLine1[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(uvRatioArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_UV, nDictIni, (const char*)&uvRatioArray[nAuto], szLine1) > 0)
				fprintf(fp, "%s\n", szLine1);
		}
	}
	fprintf(fp, "\n");

	uvArray.clear();
	uvRatioArray.clear();
}

void CPG2BpaFileApi::FormSwi_RWCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nSub, nVolt, nGen, nAuto;
	tagBpaSwi_RW	rwBuf;
	char	szLine[256];

	std::vector<tagBpaSwi_RW>	rwArray;

	rwArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nGen=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nGen<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nGen++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nGen].nNode < 0)
					continue;
				if (pPGBlock->m_SynchronousMachineArray[nGen].nIsland != nIsland)
					continue;
				if (pPGBlock->m_SynchronousMachineArray[nGen].bRWPlate != PGEnumPlateStatus_Close)
					continue;
				if ((pPGBlock->m_SynchronousMachineArray[nGen].fRWTuning1 < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nGen].fRWDelay1 < FLT_MIN) &&
					(pPGBlock->m_SynchronousMachineArray[nGen].fRWTuning2 < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nGen].fRWDelay2 < FLT_MIN))
					continue;

				memset(&rwBuf, 0, sizeof(tagBpaSwi_RW));
				strcpy(rwBuf.szCardKey, "RW");

				sprintf(rwBuf.szBus_Name, "B_%d", pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus);
				rwBuf.fBus_kV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)
				rwBuf.cGen_ID=ResolveGenID(pPGBlock, nGen);

				nAuto=-1;
				for (i=0; i<(int)rwArray.size(); i++)
				{
					if (stricmp(rwArray[i].szBus_Name, rwBuf.szBus_Name) == 0 && fabs(rwArray[i].fBus_kV - rwBuf.fBus_kV) < 0.01 && rwArray[i].cGen_ID == rwBuf.cGen_ID)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto >= 0)
					continue;

				if (pPGBlock->m_SynchronousMachineArray[nGen].fRWTuning1 > FLT_MIN && pPGBlock->m_SynchronousMachineArray[nGen].fRWDelay1 > FLT_MIN)
				{
					rwBuf.fWset1=(float)(pPGBlock->m_SynchronousMachineArray[nGen].fRWTuning1/50.0);
					rwBuf.fDelay1=pPGBlock->m_SynchronousMachineArray[nGen].fRWDelay1;
				}
				if (pPGBlock->m_SynchronousMachineArray[nGen].fRWTuning2 > FLT_MIN && pPGBlock->m_SynchronousMachineArray[nGen].fRWDelay2 > FLT_MIN)
				{
					rwBuf.fWset2=(float)(pPGBlock->m_SynchronousMachineArray[nGen].fRWTuning2/50.0);
					rwBuf.fDelay2=pPGBlock->m_SynchronousMachineArray[nGen].fRWDelay2;
				}
				rwArray.push_back(rwBuf);
			}
		}
	}

	if (!rwArray.empty())
	{
		fprintf(fp, ".�����ת�ٱ���ģ��\n");
		for (nAuto=0; nAuto<(int)rwArray.size(); nAuto++)
		{
			for (i=0; i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(rwArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_RW, nDictIni, (const char*)&rwArray[nAuto], szLine) > 0)
				fprintf(fp, "%s\n", szLine);
		}
		fprintf(fp, "\n");
	}

	rwArray.clear();
}

void CPG2BpaFileApi::FormSwi_RECard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nSub, nVolt, nGen, nAuto;
	tagBpaSwi_RE	reBuf;
	char	szLine[256];

	std::vector<tagBpaSwi_RE>	reArray;

	reArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nGen=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nGen<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nGen++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nGen].nNode < 0)
					continue;

				if (pPGBlock->m_SynchronousMachineArray[nGen].nIsland != nIsland)
					continue;

				if ((pPGBlock->m_SynchronousMachineArray[nGen].fRETuning1 < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nGen].fREDelay1 < FLT_MIN) &&
					(pPGBlock->m_SynchronousMachineArray[nGen].fRETuning2 < FLT_MIN || pPGBlock->m_SynchronousMachineArray[nGen].fREDelay2 < FLT_MIN))
					continue;
				if (pPGBlock->m_SynchronousMachineArray[nGen].bREPlate != PGEnumPlateStatus_Close)
					continue;

				memset(&reBuf, 0, sizeof(tagBpaSwi_RE));
				strcpy(reBuf.szCardKey, "RE");

				sprintf(reBuf.szBus_Name, "B_%d", pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus);
				reBuf.fBus_kV=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)
				reBuf.cGen_ID=ResolveGenID(pPGBlock, nGen);

				nAuto=-1;
				for (i=0; i<(int)reArray.size(); i++)
				{
					if (stricmp(reArray[i].szBus_Name, reBuf.szBus_Name) == 0 && fabs(reArray[i].fBus_kV - reBuf.fBus_kV) < 0.01 && reArray[i].cGen_ID == reBuf.cGen_ID)
					{
						nAuto=i;
						break;
					}
				}
				if (nAuto >= 0)
					continue;

				if (pPGBlock->m_SynchronousMachineArray[nGen].fRETuning1 > FLT_MIN && pPGBlock->m_SynchronousMachineArray[nGen].fREDelay1 > FLT_MIN)
				{
					reBuf.fVOL1=pPGBlock->m_SynchronousMachineArray[nGen].fRETuning1;
					reBuf.fTIME1=pPGBlock->m_SynchronousMachineArray[nGen].fREDelay1;
				}
				if (pPGBlock->m_SynchronousMachineArray[nGen].fRETuning2 > FLT_MIN && pPGBlock->m_SynchronousMachineArray[nGen].fREDelay2 > FLT_MIN)
				{
					reBuf.fVOL2=pPGBlock->m_SynchronousMachineArray[nGen].fRETuning2;
					reBuf.fTIME2=pPGBlock->m_SynchronousMachineArray[nGen].fREDelay2;
				}
				reArray.push_back(reBuf);
			}
		}
	}

	if (!reArray.empty())
	{
		fprintf(fp, ".�������ѹ����ģ��\n");
		for (nAuto=0; nAuto<(int)reArray.size(); nAuto++)
		{
			for (i=0; i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(reArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_RE, nDictIni, (const char*)&reArray[nAuto], szLine) > 0)
				fprintf(fp, "%s\n", szLine);
		}
		fprintf(fp, "\n");
	}

	reArray.clear();
}

void CPG2BpaFileApi::FormSwi_RACard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nVolt, nDev, nAuto;
	tagBpaSwi_RA	raBuf;
	char	szLine[256];
	std::vector<tagBpaSwi_RA>	raArray;

	raArray.clear();
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (pPGBlock->m_ACLineSegmentArray[nDev].fRATuning < FLT_MIN || pPGBlock->m_ACLineSegmentArray[nDev].fRADelay < FLT_MIN)
			continue;
		if (pPGBlock->m_ACLineSegmentArray[nDev].bRAPlate != PGEnumPlateStatus_Close)
			continue;

		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (nVolt < 0)
			continue;

		if (pPGBlock->m_ACLineSegmentArray[nDev].nIsland != nIsland)
			continue;

		memset(&raBuf, 0, sizeof(tagBpaSwi_RA));
		strcpy(raBuf.szCardKey, "RA");

		sprintf(raBuf.szBusI, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI);
		sprintf(raBuf.szBusJ, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ);
		raBuf.fkVI=raBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)
		raBuf.cLoop=ResolveLineLoop(pPGBlock, nDev);

		nAuto=-1;
		for (i=0; i<(int)raArray.size(); i++)
		{
			if ((stricmp(raArray[i].szBusI, raBuf.szBusI) == 0 && fabs(raArray[i].fkVI - raBuf.fkVI) < 0.01 && stricmp(raArray[i].szBusJ, raBuf.szBusJ) == 0 && fabs(raArray[i].fkVJ - raBuf.fkVJ) < 0.01 ||
				 stricmp(raArray[i].szBusI, raBuf.szBusJ) == 0 && fabs(raArray[i].fkVI - raBuf.fkVJ) < 0.01 && stricmp(raArray[i].szBusJ, raBuf.szBusI) == 0 && fabs(raArray[i].fkVJ - raBuf.fkVI) < 0.01) &&
				raArray[i].cLoop == raBuf.cLoop)
			{
				nAuto=i;
				break;
			}
		}
		if (nAuto >= 0)
			continue;

		strcpy(raBuf.szCBus1, raBuf.szBusI);
		raBuf.fCkV1=raBuf.fkVI;
		raBuf.fCV1=pPGBlock->m_ACLineSegmentArray[nDev].fRATuning;
		raBuf.fCT1=pPGBlock->m_ACLineSegmentArray[nDev].fRADelay;
		raArray.push_back(raBuf);

		strcpy(raBuf.szCBus1, raBuf.szBusJ);
		raBuf.fCkV1=raBuf.fkVJ;
		raBuf.fCV1=pPGBlock->m_ACLineSegmentArray[nDev].fRATuning;
		raBuf.fCT1=pPGBlock->m_ACLineSegmentArray[nDev].fRADelay;
		raArray.push_back(raBuf);
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		if (pPGBlock->m_TransformerWindingArray[nDev].fRATuning < FLT_MIN || pPGBlock->m_TransformerWindingArray[nDev].fRADelay < FLT_MIN)
			continue;
		if (pPGBlock->m_TransformerWindingArray[nDev].bRAPlate != PGEnumPlateStatus_Close)
			continue;

		if (pPGBlock->m_TransformerWindingArray[nDev].nIsland != nIsland)
			continue;

		memset(&raBuf, 0, sizeof(tagBpaSwi_RA));
		strcpy(raBuf.szCardKey, "RA");

		sprintf(raBuf.szBusI, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusI);
		sprintf(raBuf.szBusJ, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusJ);

		nVolt=pPGBlock->m_TransformerWindingArray[nDev].nVoltI;
		if (nVolt < 0)
			continue;
		raBuf.fkVI=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;									//	��׼��ѹ(kV)

		nVolt=pPGBlock->m_TransformerWindingArray[nDev].nVoltJ;
		if (nVolt < 0)
			continue;
		raBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;									//	��׼��ѹ(kV)
		raBuf.cLoop=ResolveLineLoop(pPGBlock, nDev);

		nAuto=-1;
		for (i=0; i<(int)raArray.size(); i++)
		{
			if ((stricmp(raArray[i].szBusI, raBuf.szBusI) == 0 && fabs(raArray[i].fkVI - raBuf.fkVI) < 0.01 && stricmp(raArray[i].szBusJ, raBuf.szBusJ) == 0 && fabs(raArray[i].fkVJ - raBuf.fkVJ) < 0.01 ||
				stricmp(raArray[i].szBusI, raBuf.szBusJ) == 0 && fabs(raArray[i].fkVI - raBuf.fkVJ) < 0.01 && stricmp(raArray[i].szBusJ, raBuf.szBusI) == 0 && fabs(raArray[i].fkVJ - raBuf.fkVI) < 0.01) &&
				raArray[i].cLoop == raBuf.cLoop)
			{
				nAuto=i;
				break;
			}
		}
		if (nAuto >= 0)
			continue;

		strcpy(raBuf.szCBus1, raBuf.szBusI);
		raBuf.fCkV1=raBuf.fkVI;
		raBuf.fCV1=pPGBlock->m_TransformerWindingArray[nDev].fRATuning;
		raBuf.fCT1=pPGBlock->m_TransformerWindingArray[nDev].fRADelay;
		raArray.push_back(raBuf);

		strcpy(raBuf.szCBus1, raBuf.szBusJ);
		raBuf.fCkV1=raBuf.fkVJ;
		raBuf.fCV1=pPGBlock->m_TransformerWindingArray[nDev].fRATuning;
		raBuf.fCT1=pPGBlock->m_TransformerWindingArray[nDev].fRADelay;
		raArray.push_back(raBuf);
	}

	if (!raArray.empty())
	{
		fprintf(fp, ".��·�͵�ѹ����ģ��\n");
		for (nAuto=0; nAuto<(int)raArray.size(); nAuto++)
		{
			for (i=0; i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(raArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_RA, nDictIni, (const char*)&raArray[nAuto], szLine) > 0)
				fprintf(fp, "%s\n", szLine);
		}
		fprintf(fp, "\n");
	}

	raArray.clear();
}

void CPG2BpaFileApi::FormSwi_RUCard(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, FILE* fp, const int nIsland)
{
	register int	i;
	int		nVolt, nDev, nAuto;
	tagBpaSwi_RU	ruBuf;
	char	szLine[256];
	std::vector<tagBpaSwi_RU>	ruArray;

	ruArray.clear();
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (pPGBlock->m_ACLineSegmentArray[nDev].fRUTuning < FLT_MIN || pPGBlock->m_ACLineSegmentArray[nDev].fRUDelay < FLT_MIN)
			continue;
		if (pPGBlock->m_ACLineSegmentArray[nDev].bRUPlate != PGEnumPlateStatus_Close)
			continue;

		if (pPGBlock->m_ACLineSegmentArray[nDev].nIsland != nIsland)
			continue;

		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
		if (nVolt < 0)
			continue;

		memset(&ruBuf, 0, sizeof(tagBpaSwi_RU));
		strcpy(ruBuf.szCardKey, "RU");

		sprintf(ruBuf.szBusI, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI);
		sprintf(ruBuf.szBusJ, "B_%d", pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ);
		ruBuf.fkVI=ruBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)
		ruBuf.cLoop=ResolveLineLoop(pPGBlock, nDev);

		nAuto=-1;
		for (i=0; i<(int)ruArray.size(); i++)
		{
			if ((stricmp(ruArray[i].szBusI, ruBuf.szBusI) == 0 && fabs(ruArray[i].fkVI - ruBuf.fkVI) < 0.01 && stricmp(ruArray[i].szBusJ, ruBuf.szBusJ) == 0 && fabs(ruArray[i].fkVJ - ruBuf.fkVJ) < 0.01 ||
				stricmp(ruArray[i].szBusI, ruBuf.szBusJ) == 0 && fabs(ruArray[i].fkVI - ruBuf.fkVJ) < 0.01 && stricmp(ruArray[i].szBusJ, ruBuf.szBusI) == 0 && fabs(ruArray[i].fkVJ - ruBuf.fkVI) < 0.01) &&
				ruArray[i].cLoop == ruBuf.cLoop)
			{
				nAuto=i;
				break;
			}
		}
		if (nAuto >= 0)
			continue;

		ruBuf.fFTrip=pPGBlock->m_ACLineSegmentArray[nDev].fRUTuning;
		ruBuf.fTRelay=pPGBlock->m_ACLineSegmentArray[nDev].fRUDelay;
		ruArray.push_back(ruBuf);
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		if (pPGBlock->m_TransformerWindingArray[nDev].fRUTuning < FLT_MIN || pPGBlock->m_TransformerWindingArray[nDev].fRUDelay < FLT_MIN)
			continue;
		if (pPGBlock->m_TransformerWindingArray[nDev].bRUPlate != PGEnumPlateStatus_Close)
			continue;

		if (pPGBlock->m_TransformerWindingArray[nDev].nIsland != nIsland)
			continue;

		memset(&ruBuf, 0, sizeof(tagBpaSwi_RU));
		strcpy(ruBuf.szCardKey, "RU");

		sprintf(ruBuf.szBusI, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusI);
		sprintf(ruBuf.szBusJ, "B_%d", pPGBlock->m_TransformerWindingArray[nDev].nTopoBusJ);

		nVolt=pPGBlock->m_TransformerWindingArray[nDev].nVoltI;
		if (nVolt < 0)
			continue;
		ruBuf.fkVI=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)

		nVolt=pPGBlock->m_TransformerWindingArray[nDev].nVoltJ;
		if (nVolt < 0)
			continue;
		ruBuf.fkVJ=pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage;										//	��׼��ѹ(kV)
		ruBuf.cLoop=ResolveTranLoop(pPGBlock, nDev);

		nAuto=-1;
		for (i=0; i<(int)ruArray.size(); i++)
		{
			if ((stricmp(ruArray[i].szBusI, ruBuf.szBusI) == 0 && fabs(ruArray[i].fkVI - ruBuf.fkVI) < 0.01 && stricmp(ruArray[i].szBusJ, ruBuf.szBusJ) == 0 && fabs(ruArray[i].fkVJ - ruBuf.fkVJ) < 0.01 ||
				stricmp(ruArray[i].szBusI, ruBuf.szBusJ) == 0 && fabs(ruArray[i].fkVI - ruBuf.fkVJ) < 0.01 && stricmp(ruArray[i].szBusJ, ruBuf.szBusI) == 0 && fabs(ruArray[i].fkVJ - ruBuf.fkVI) < 0.01) &&
				ruArray[i].cLoop == ruBuf.cLoop)
			{
				nAuto=i;
				break;
			}
		}
		if (nAuto >= 0)
			continue;

		ruBuf.fFTrip=pPGBlock->m_TransformerWindingArray[nDev].fRUTuning;
		ruBuf.fTRelay=pPGBlock->m_TransformerWindingArray[nDev].fRUDelay;
		ruArray.push_back(ruBuf);
	}

	if (!ruArray.empty())
	{
		fprintf(fp, ".֧·���ܱ���ģ��\n");
		for (nAuto=0; nAuto<(int)ruArray.size(); nAuto++)
		{
			for (i=0; i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';

			int nDictIni=m_BpaMemDBInterface.BpaGetTableDictIndex(ruArray[nAuto].szCardKey, BpaSwiCategory_Dat);
			if (m_BpaMemDBInterface.BpaDataPtr2LineString((int)BPA_SWI_RU, nDictIni, (const char*)&ruArray[nAuto], szLine) > 0)
				fprintf(fp, "%s\n", szLine);
		}
		fprintf(fp, "\n");
	}
	ruArray.clear();
}

void CPG2BpaFileApi::FormSwi_BusMonCard(tagPGBlock* pPGBlock, FILE* fp)
{
	register int	i;
	int		nMon, nVolt, nBus;
	char	szBuf[260], szLine[256];
	std::vector<unsigned char>	bBusProcArray;

	bBusProcArray.resize(pPGBlock->m_nRecordNum[PG_TOPOBUS]);
	for (i=0; i<(int)bBusProcArray.size(); i++)
		bBusProcArray[i]=0;

	fprintf(fp, "BH 1\n");
	for (nMon=0; nMon<GetBpaBusMonitorNum(); nMon++)
	{
		nBus=ResolveBusIndex(pPGBlock, m_MonBusArray[nMon].szDevSub, m_MonBusArray[nMon].szDevVolt, m_MonBusArray[nMon].szDevName);
		if (nBus < 0)
			continue;
		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_BusbarSectionArray[nBus].szSub, pPGBlock->m_BusbarSectionArray[nBus].szVolt);
		if (nVolt < 0)
			continue;
		if (bBusProcArray[pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].nTopoBus])
			continue;
		bBusProcArray[pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].nTopoBus]=1;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';

		szLine[0]='B';

		sprintf(szBuf, "B_%d", pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].nTopoBus);
		FillLineString(MDB_STRING, 4, 11, 8, szBuf, szLine);

		sprintf(szBuf, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		FillLineString(MDB_FLOAT, 12, 15, 4, szBuf, szLine);

		if (m_MonBusArray[nMon].bMonV)	szLine[17]='3';
		if (m_MonBusArray[nMon].bMonD)	szLine[18]='3';
		if (m_MonBusArray[nMon].bMonF)	szLine[20]='3';
		if (m_MonBusArray[nMon].bMonP)	szLine[23]='3';
		if (m_MonBusArray[nMon].bMonQ)	szLine[26]='3';

		TrimRight(szLine);
		fprintf(fp, "%s\n", szLine);
	}
}

void CPG2BpaFileApi::FormSwi_GenMonCard(tagPGBlock* pPGBlock, FILE* fp)
{
	register int	i;
	int		nMon, nVolt, nGen;
	char	szBuf[260], szLine[256];

	for (i=0; i<255; i++)
		szLine[i]=' ';
	szLine[255]='\0';
	szLine[0]='G';
	szLine[1]='H';

	nGen=ResolveGenIndex(pPGBlock, m_ReferenceGen.szDevSub, m_ReferenceGen.szDevVolt, m_ReferenceGen.szDevName);
	if (nGen >= 0)
	{
		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SynchronousMachineArray[nGen].szSub, pPGBlock->m_SynchronousMachineArray[nGen].szVolt);

		sprintf(szBuf, "B_%d", pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus);
		FillLineString(MDB_STRING, 7, 14, 8, szBuf, szLine);

		sprintf(szBuf, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		FillLineString(MDB_FLOAT, 15, 18, 4, szBuf, szLine);

		szLine[19]=ResolveGenID(pPGBlock, nGen);
	}

	TrimRight(szLine);
	fprintf(fp, "%s\n", szLine);

// 	7-14 REFBUS���ο������ĸ����
// 	15-18 BASE���ο������ĸ�߻�׼��ѹ
// 	20 ID���ο������ʶ����

	for (nMon=0; nMon<GetBpaGenMonitorNum(); nMon++)
	{
		if (!m_MonGenArray[nMon].bMonD && 		
			!m_MonGenArray[nMon].bMonS && 		
			!m_MonGenArray[nMon].bMonEV && 		
			!m_MonGenArray[nMon].bMonTP && 		
			!m_MonGenArray[nMon].bMonEP && 		
			!m_MonGenArray[nMon].bMonVd && 		
			!m_MonGenArray[nMon].bMonAcc && 	
			!m_MonGenArray[nMon].bMonQ && 		
			!m_MonGenArray[nMon].bMonDamp && 	
			!m_MonGenArray[nMon].bMonEA)
			continue;

		nGen=ResolveGenIndex(pPGBlock, m_MonGenArray[nMon].szDevSub, m_MonGenArray[nMon].szDevVolt, m_MonGenArray[nMon].szDevName);
		if (nGen < 0)
			continue;
		nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_SynchronousMachineArray[nGen].szSub, pPGBlock->m_SynchronousMachineArray[nGen].szVolt);
		if (nVolt < 0)
			continue;

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';
		szLine[0]='G';

		sprintf(szBuf, "B_%d", pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus);
		FillLineString(MDB_STRING, 4, 11, 8, szBuf, szLine);

		sprintf(szBuf, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
		FillLineString(MDB_FLOAT, 12, 15, 4, szBuf, szLine);

		szLine[16]=ResolveGenID(pPGBlock, nGen);

		if (m_MonGenArray[nMon].bMonD)		szLine[20-1]='3';
		if (m_MonGenArray[nMon].bMonS)		szLine[23-1]='3';
		if (m_MonGenArray[nMon].bMonEV)		szLine[26-1]='3';
		if (m_MonGenArray[nMon].bMonTP)		szLine[35-1]='3';
		if (m_MonGenArray[nMon].bMonEP)		szLine[38-1]='3';
		if (m_MonGenArray[nMon].bMonVd)		szLine[44-1]='3';
		if (m_MonGenArray[nMon].bMonAcc)	szLine[47-1]='3';
		if (m_MonGenArray[nMon].bMonQ)		szLine[50-1]='3';
		if (m_MonGenArray[nMon].bMonDamp)	szLine[56-1]='3';
		if (m_MonGenArray[nMon].bMonEA)		szLine[59-1]='3';

		TrimRight(szLine);
		fprintf(fp, "%s\n", szLine);

		if (m_MonGenArray[nMon].bMonV ||
			m_MonGenArray[nMon].bMonA ||
			m_MonGenArray[nMon].bMonEq ||
			m_MonGenArray[nMon].bMonEdp ||
			m_MonGenArray[nMon].bMonEqp ||
			m_MonGenArray[nMon].bMonEdpp ||
			m_MonGenArray[nMon].bMonEqpp ||
			m_MonGenArray[nMon].bMonEqR ||
			m_MonGenArray[nMon].bMonEqX)
		{
			for (i=0; i<255; i++)
				szLine[i]=' ';
			szLine[255]='\0';
			szLine[0]='G';
			szLine[1]='+';

			sprintf(szBuf, "B_%d", pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus);
			FillLineString(MDB_STRING, 4, 11, 8, szBuf, szLine);

			sprintf(szBuf, "%f", pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
			FillLineString(MDB_FLOAT, 12, 15, 4, szBuf, szLine);

			szLine[16]=ResolveGenID(pPGBlock, nGen);

			if (m_MonGenArray[nMon].bMonV)		szLine[19-1]='3';
			if (m_MonGenArray[nMon].bMonA)		szLine[21-1]='3';
			if (m_MonGenArray[nMon].bMonEq)		szLine[23-1]='3';
			if (m_MonGenArray[nMon].bMonEdp)	szLine[25-1]='3';
			if (m_MonGenArray[nMon].bMonEqp)	szLine[27-1]='3';
			if (m_MonGenArray[nMon].bMonEdpp)	szLine[29-1]='3';
			if (m_MonGenArray[nMon].bMonEqpp)	szLine[31-1]='3';
			if (m_MonGenArray[nMon].bMonEqR)	szLine[45-1]='3';
			if (m_MonGenArray[nMon].bMonEqX)	szLine[47-1]='3';

			TrimRight(szLine);
			fprintf(fp, "%s\n", szLine);
		}
	}
}

void CPG2BpaFileApi::FormSwi_BranMonCard(tagPGBlock* pPGBlock, FILE* fp)
{
	register int	i;
	int		nMon, nDev, nBpaDev;
	char	szBuf[260], szLine[256];

	fprintf(fp, "LH 1\n");
	for (nMon=0; nMon<GetBpaLineMonitorNum(); nMon++)
	{
		nDev=ResolveLineIndex(pPGBlock, m_MonLineArray[nMon].szDevName);
		if (nDev < 0)
		{
			Log(g_lpszPG2BpaApiLogFile, "û���ҵ���·����: %s\n", m_MonLineArray[nMon].szDevName);
			continue;
		}

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';
		szLine[0]='L';

		nBpaDev=FindLineInLArray(pPGBlock->m_ACLineSegmentArray[nDev].szName);
		if (nBpaDev < 0)
		{
			Log(g_lpszPG2BpaApiLogFile, "û���ҵ���·: %s\n", pPGBlock->m_ACLineSegmentArray[nDev].szName);
			continue;
		}

		FillLineString(MDB_STRING, 4, 11, 8, m_LineArray[nBpaDev].szBusI, szLine);
		sprintf(szBuf, "%f", m_LineArray[nBpaDev].fkVI);	FillLineString(MDB_STRING, 12, 15, 4, szBuf, szLine);
		FillLineString(MDB_STRING, 17, 24, 8, m_LineArray[nBpaDev].szBusJ, szLine);
		sprintf(szBuf, "%f", m_LineArray[nBpaDev].fkVJ);	FillLineString(MDB_STRING, 25, 28, 4, szBuf, szLine);
		szLine[29]=m_LineArray[nBpaDev].cLoop;

		if (m_MonLineArray[nMon].bMonP)	szLine[34]='3';
		if (m_MonLineArray[nMon].bMonQ)	szLine[37]='3';

		TrimRight(szLine);
		fprintf(fp, "%s\n", szLine);
	}

	for (nMon=0; nMon<GetBpaTranMonitorNum(); nMon++)
	{
		nDev=ResolveTranIndex(pPGBlock, m_MonTranArray[nMon].szDevSub, "", m_MonTranArray[nMon].szDevName);
		if (nDev < 0)
		{
			Log(g_lpszPG2BpaApiLogFile, "û���ҵ���ѹ������: %s %s\n", m_MonTranArray[nMon].szDevSub, m_MonTranArray[nMon].szDevName);
			continue;
		}

		for (i=0; i<255; i++)
			szLine[i]=' ';
		szLine[255]='\0';
		szLine[0]='L';

		sprintf(szBuf, "%s.%s", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);
		nBpaDev=FindTranInTArray(szBuf);
		if (nBpaDev < 0)
		{
			Log(g_lpszPG2BpaApiLogFile, "û���ҵ���ѹ��: %s\n", szBuf);
			continue;
		}

		FillLineString(MDB_STRING, 4, 11, 8, m_TranArray[nBpaDev].szBusI, szLine);
		sprintf(szBuf, "%f", m_TranArray[nBpaDev].fkVI);	FillLineString(MDB_STRING, 12, 15, 4, szBuf, szLine);
		FillLineString(MDB_STRING, 17, 24, 8, m_TranArray[nBpaDev].szBusJ, szLine);
		sprintf(szBuf, "%f", m_TranArray[nBpaDev].fkVJ);	FillLineString(MDB_STRING, 25, 28, 4, szBuf, szLine);
		szLine[29]=m_TranArray[nBpaDev].cLoop;

		if (m_MonTranArray[nMon].bMonP)	szLine[34]='3';
		if (m_MonTranArray[nMon].bMonQ)	szLine[37]='3';

		TrimRight(szLine);
		fprintf(fp, "%s\n", szLine);
	}
}

void CPG2BpaFileApi::PG2BpaSwiOneFile(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, const char* lpszFileName)
{
	register int	i;
	FILE*	fp;
	int		nIsland;
	char	szLine1[256];
	tagBpaSwi_Case	CaseBuf;
	tagBpaSwi_F0	F0Buf;
	tagBpaSwi_F1	F1Buf;

	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	m_bGenProcArray.resize(pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);

	memset(&CaseBuf, 0, sizeof(tagBpaSwi_Case));
	memset(&F0Buf, 0, sizeof(tagBpaSwi_F0));
	memset(&F1Buf, 0, sizeof(tagBpaSwi_F1));

	strcpy(CaseBuf.szCardKey, "CASE");
	strcpy(CaseBuf.szPFCASE, "PG2BPA");
	CaseBuf.bITSKP=1;
	strcpy(F0Buf.szCardKey, "F0");
	strcpy(F1Buf.szCardKey, "F1");

	memset(szLine1, 0, 256);
	m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_CASE, (char*)&CaseBuf, szLine1);
	if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);
	Log(g_lpszPG2BpaApiLogFile, "BPA_SWI_CASE\n");

	PGMemDBTopo(pPGBlock);
	PGMemDBIsland(pPGBlock);
	PGMemDBStatus(pPGBlock, 0);
	PGMemDBPFAmend(pPGBlock);

	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		for (i=0; i<(int)m_bGenProcArray.size(); i++)
			m_bGenProcArray[i]=0;

		FormBArray(pPGBlock, 1.0, 1.0, 0, nIsland);
		FormLArray(pPGBlock, nIsland);	
		FormTArray(pPGBlock, nIsland);	

		FormSwi_LSCard(pPGBlock, pBpaBlock, fp, nIsland);	
		FormSwi_GenCard(pPGBlock, pBpaBlock, fp, nIsland);	
		FormSwi_MLCard(pPGBlock, pBpaBlock, fp, nIsland);	
		FormSwi_XOCard(pPGBlock, pBpaBlock, fp, nIsland);	
		FormSwi_LOCard(pPGBlock, pBpaBlock, fp, nIsland);	
		FormSwi_XRCard(pPGBlock, pBpaBlock, fp, nIsland);	
		FormSwi_LBCard(pPGBlock, pBpaBlock, fp, nIsland);	

		FormSwi_UFCard(pPGBlock, pBpaBlock, fp, nIsland);
		FormSwi_UVCard(pPGBlock, pBpaBlock, fp, nIsland);
		FormSwi_RACard(pPGBlock, pBpaBlock, fp, nIsland);
		FormSwi_RUCard(pPGBlock, pBpaBlock, fp, nIsland);
		FormSwi_RECard(pPGBlock, pBpaBlock, fp, nIsland);
		FormSwi_RWCard(pPGBlock, pBpaBlock, fp, nIsland);
	}

	memset(szLine1, 0, 256);
	m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_F0, (char*)&F0Buf, szLine1);
	if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

	memset(szLine1, 0, 256);
	m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_F1, (char*)&F1Buf, szLine1);
	if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

	memset(szLine1, 0, 256);
	m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_FF, (char*)&m_BpaSwiConCard, szLine1);
	if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

	fprintf(fp, "90\n");

	fprintf(fp, "MH\n");
	FormSwi_BusMonCard(pPGBlock, fp);
	FormSwi_GenMonCard(pPGBlock, fp);
	FormSwi_BranMonCard(pPGBlock, fp);

	fprintf(fp, "99\n");
	fflush(fp);
	fclose(fp);
}

void CPG2BpaFileApi::PG2BpaSwiFile(tagPGBlock* pPGBlock, tagBpaBlock* pBpaBlock, const char* lpszWorkDir)
{
	register int	i;
	char	szFileName[260];
	FILE*	fp;
	int		nIsland;
	char	szLine1[256];
	tagBpaSwi_Case	CaseBuf;
	tagBpaSwi_F0	F0Buf;
	tagBpaSwi_F1	F1Buf;

	m_bGenProcArray.resize(pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);

	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		for (i=0; i<(int)m_bGenProcArray.size(); i++)
			m_bGenProcArray[i]=0;

		sprintf(szFileName, "%s/%s%d.swi", lpszWorkDir, m_BpaDatConCard.szProject, nIsland);
		fp=fopen(szFileName, "w");
		if (fp != NULL)
		{
			FormBArray(pPGBlock, 1.0, 1.0, 0, nIsland);
			FormLArray(pPGBlock, nIsland);
			FormTArray(pPGBlock, nIsland);

			memset(&CaseBuf, 0, sizeof(tagBpaSwi_Case));
			memset(&F0Buf, 0, sizeof(tagBpaSwi_F0));
			memset(&F1Buf, 0, sizeof(tagBpaSwi_F1));

			strcpy(CaseBuf.szCardKey, "CASE");
			sprintf(CaseBuf.szPFCASE, "PG2BPA%d", nIsland);
			CaseBuf.bITSKP=1;

			strcpy(F0Buf.szCardKey, "F0");
			strcpy(F1Buf.szCardKey, "F1");

			memset(szLine1, 0, 256);
			m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_CASE, (char*)&CaseBuf, szLine1);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

			FormSwi_LSCard(pPGBlock, pBpaBlock, fp, nIsland);

			FormSwi_GenCard(pPGBlock, pBpaBlock, fp, nIsland);

			FormSwi_MLCard(pPGBlock, pBpaBlock, fp, nIsland);

			FormSwi_XOCard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_LOCard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_XRCard(pPGBlock, pBpaBlock, fp, nIsland);

			FormSwi_LBCard(pPGBlock, pBpaBlock, fp, nIsland);

			FormSwi_UFCard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_UVCard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_RACard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_RUCard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_RECard(pPGBlock, pBpaBlock, fp, nIsland);
			FormSwi_RWCard(pPGBlock, pBpaBlock, fp, nIsland);

			memset(szLine1, 0, 256);
			m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_F0, (char*)&F0Buf, szLine1);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

			memset(szLine1, 0, 256);
			m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_F1, (char*)&F1Buf, szLine1);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

			memset(szLine1, 0, 256);
			m_BpaMemDBInterface.BpaSwi2LineString(BPA_SWI_FF, (char*)&m_BpaSwiConCard, szLine1);
			if (strlen(szLine1) > 0)	fprintf(fp, "%s\n", szLine1);

			fprintf(fp, "90\n");

			fprintf(fp, "MH\n");
			FormSwi_BusMonCard(pPGBlock, fp);
			FormSwi_GenMonCard(pPGBlock, fp);
			FormSwi_BranMonCard(pPGBlock, fp);

			fprintf(fp, "99\n");
			fflush(fp);
			fclose(fp);
		}
	}
}
