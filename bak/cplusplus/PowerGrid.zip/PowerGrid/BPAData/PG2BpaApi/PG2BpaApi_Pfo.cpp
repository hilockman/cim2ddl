#include "StdAfx.h"
#include "PG2BpaApi.h"
#include "../../../Common/StringCommon.h"
#include "../../../Common/String2Double.hpp"

int	CPG2BpaFileApi::isBpaPfoShuntLine(const char* lpszLine)
{
	if (strstr(lpszLine, "�����޹�") == NULL)
		return 0;
	return 1;
}

int	CPG2BpaFileApi::PGParseBpaPfoBusLine(tagPGBlock* pPGBlock, const char* lpszLine, const char* lpszLineExt, char* lpszBusName, double& fBusVolt)
{
	int		nItem, nTopoBus;
	char	szBuffer[256];
	std::vector<std::string>	strEleArray;

	strcpy(szBuffer, lpszLine);
	strcpy(lpszBusName, "");
	fBusVolt=0;

	strEleArray.clear();
	char*	lpszToken=strtok(szBuffer, " /\t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " /\t\n");
	}

	if (strEleArray.size() < 4)
		return 0;

	strcpy(lpszBusName, strEleArray[0].c_str());
	fBusVolt=atof(strEleArray[1].c_str());

	nTopoBus=atoi(strEleArray[0].c_str()+2);
	if (nTopoBus > 0)
	{
		nItem=2;
		if ((int)strEleArray.size() > nItem)	{	ResolveNumericString(strEleArray[nItem++].c_str(), szBuffer);	pPGBlock->m_TopoBusArray[nTopoBus].fV=(float)atof(szBuffer);	}
		if ((int)strEleArray.size() > nItem)	{	ResolveNumericString(strEleArray[nItem++].c_str(), szBuffer);	pPGBlock->m_TopoBusArray[nTopoBus].fD=(float)atof(szBuffer);	}

		nItem=4;
		while (nItem < (int)strEleArray.size())
		{
			if (strstr(strEleArray[nItem].c_str(), "�й�����") != NULL)
			{
				ResolveNumericString(strEleArray[nItem].c_str(), szBuffer);
				pPGBlock->m_TopoBusArray[nTopoBus].fGenP=(float)atof(szBuffer);
			}
			else if (strstr(strEleArray[nItem].c_str(), "�޹�����") != NULL)
			{
				ResolveNumericString(strEleArray[nItem].c_str(), szBuffer);
				pPGBlock->m_TopoBusArray[nTopoBus].fGenQ=(float)atof(szBuffer);
			}
			else if (strstr(strEleArray[nItem].c_str(), "�й�����") != NULL)
			{
				ResolveNumericString(strEleArray[nItem].c_str(), szBuffer);
				pPGBlock->m_TopoBusArray[nTopoBus].fLoadP=(float)atof(szBuffer);
			}
			else if (strstr(strEleArray[nItem].c_str(), "�޹�����") != NULL)
			{
				ResolveNumericString(strEleArray[nItem].c_str(), szBuffer);
				pPGBlock->m_TopoBusArray[nTopoBus].fLoadQ=(float)atof(szBuffer);
			}

			nItem++;
		}

		return nTopoBus;
	}

	return 0;
}

void CPG2BpaFileApi::PGParseBpaPfoBusShunt(tagPGBlock* pPGBlock, const int nTopoBus, const char* lpszLine)
{
	int		nItem;
	char	szBuffer[256];
	std::vector<std::string>	strEleArray;

	strcpy(szBuffer, lpszLine);

	strEleArray.clear();
	char*	lpszToken=strtok(szBuffer, " /\t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " /\t\n");
	}

	if (strEleArray.size() < 0)
		return;

	nItem=0;
	while (nItem < (int)strEleArray.size())
	{
		if (strstr(strEleArray[nItem].c_str(), "�����޹�") != NULL)
		{
			ResolveNumericString(strEleArray[nItem].c_str(), szBuffer);
			pPGBlock->m_TopoBusArray[nTopoBus].fShuntQ=(float)atof(szBuffer);
		}

		nItem++;
	}
}

void CPG2BpaFileApi::PGParseBpaPfoOutput(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine)
{
	int		nDev, nItem;
	char	szBuffer[256];
	std::vector<std::string>	strEleArray;

	strcpy(szBuffer, lpszLine);

	strEleArray.clear();
	char*	lpszToken=strtok(szBuffer, " /\t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " /\t\n");
	}

	if (strEleArray.size() < 2)
		return;

	if (stricmp(strEleArray[0].c_str(), "�Զ����������ȫ��") == 0)		{	pPGBlock->m_IslandArray[nIsland].fLossP = (float)atof(strEleArray[1].c_str());		return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�����������й�����") == 0)	{	pPGBlock->m_IslandArray[nIsland].fUnitP += (float)atof(strEleArray[2].c_str());		return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�����������޹�����") == 0)	{	pPGBlock->m_IslandArray[nIsland].fUnitQ += (float)atof(strEleArray[2].c_str());		return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�����������й�����") == 0)	{	pPGBlock->m_IslandArray[nIsland].fLoadP += (float)atof(strEleArray[2].c_str());		return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�����������޹�����") == 0)	{	pPGBlock->m_IslandArray[nIsland].fLoadQ += (float)atof(strEleArray[2].c_str());		return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�������޹���������") == 0)	{	pPGBlock->m_IslandArray[nIsland].fShuntQ += (float)atof(strEleArray[2].c_str());	return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�������޹���ķ���") == 0)	{	pPGBlock->m_IslandArray[nIsland].fLossQ += (float)atof(strEleArray[2].c_str());		return;	}
	if (stricmp(strEleArray[0].c_str(), "�Զ��������·") == 0)
	{
		nDev = PGFindRecordbyKey(pPGBlock, PG_ACLINESEGMENT, strEleArray[1].c_str());
		if (nDev >= 0)
		{
			nItem = 2;
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fPi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fQi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fPz = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fQz = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fLossP = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fLossQ = (float)atof(strEleArray[nItem++].c_str());

			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_ACLineSegmentArray[nDev].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[nDev].fPi*pPGBlock->m_ACLineSegmentArray[nDev].fPi+pPGBlock->m_ACLineSegmentArray[nDev].fQi*pPGBlock->m_ACLineSegmentArray[nDev].fQi)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
			//Log(g_lpszPG2BpaApiLogFile, "    ������·����: %s %f %f %f %f %f %f\n", pPGBlock->m_ACLineSegmentArray[nDev].szName, pPGBlock->m_ACLineSegmentArray[nDev].fPi, pPGBlock->m_ACLineSegmentArray[nDev].fQi,
			//	pPGBlock->m_ACLineSegmentArray[nDev].fPz, pPGBlock->m_ACLineSegmentArray[nDev].fQz, pPGBlock->m_ACLineSegmentArray[nDev].fLossP, pPGBlock->m_ACLineSegmentArray[nDev].fLossQ);
		}
		return;
	}
	if (stricmp(strEleArray[0].c_str(), "�Զ��������·�й�") == 0)
	{
		nDev = PGFindRecordbyKey(pPGBlock, PG_ACLINESEGMENT, strEleArray[1].c_str());
		if (nDev >= 0)
		{
			nItem = 2;
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fPi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fPz = (float)atof(strEleArray[nItem++].c_str());

			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_ACLineSegmentArray[nDev].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[nDev].fPi*pPGBlock->m_ACLineSegmentArray[nDev].fPi+pPGBlock->m_ACLineSegmentArray[nDev].fQi*pPGBlock->m_ACLineSegmentArray[nDev].fQi)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
		}
		return;
	}
	if (stricmp(strEleArray[0].c_str(), "�Զ��������·�޹�") == 0)
	{
		nDev = PGFindRecordbyKey(pPGBlock, PG_ACLINESEGMENT, strEleArray[1].c_str());
		if (nDev >= 0)
		{
			nItem = 2;
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fQi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[nDev].fQz = (float)atof(strEleArray[nItem++].c_str());

			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_ACLineSegmentArray[nDev].szVoltI);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_ACLineSegmentArray[nDev].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[nDev].fPi*pPGBlock->m_ACLineSegmentArray[nDev].fPi+pPGBlock->m_ACLineSegmentArray[nDev].fQi*pPGBlock->m_ACLineSegmentArray[nDev].fQi)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
		}
		return;
	}
	if (stricmp(strEleArray[0].c_str(), "�Զ����������") == 0)
	{
		nDev = -1;
		for (nItem=0; nItem<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nItem++)
		{
			sprintf(szBuffer, "%s.%s", pPGBlock->m_TransformerWindingArray[nItem].szSub, pPGBlock->m_TransformerWindingArray[nItem].szName);
			if (stricmp(szBuffer, strEleArray[1].c_str()) == 0)
			{
				nDev = nItem;
				break;
			}
		}
		if (nDev >= 0)
		{
			nItem = 2;
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fPi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fQi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fPz = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fQz = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fLossP = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fLossQ = (float)atof(strEleArray[nItem++].c_str());

			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szVoltI);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_TransformerWindingArray[nDev].fAi = 1000*sqrt(pPGBlock->m_TransformerWindingArray[nDev].fPi*pPGBlock->m_TransformerWindingArray[nDev].fPi+pPGBlock->m_TransformerWindingArray[nDev].fQi*pPGBlock->m_TransformerWindingArray[nDev].fQi)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szVoltJ);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_TransformerWindingArray[nDev].fAz = 1000*sqrt(pPGBlock->m_TransformerWindingArray[nDev].fPz*pPGBlock->m_TransformerWindingArray[nDev].fPz+pPGBlock->m_TransformerWindingArray[nDev].fQz*pPGBlock->m_TransformerWindingArray[nDev].fQz)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
		}
		return;
	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�����������й�") == 0)
	{
		nDev = -1;
		for (nItem=0; nItem<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nItem++)
		{
			sprintf(szBuffer, "%s.%s", pPGBlock->m_TransformerWindingArray[nItem].szSub, pPGBlock->m_TransformerWindingArray[nItem].szName);
			if (stricmp(szBuffer, strEleArray[1].c_str()) == 0)
			{
				nDev = nItem;
				break;
			}
		}
		if (nDev >= 0)
		{
			nItem = 2;
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fPi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fPz = (float)atof(strEleArray[nItem++].c_str());
		}
		return;
	}
	if (stricmp(strEleArray[0].c_str(), "�Զ�����������޹�") == 0)
	{
		nDev = -1;
		for (nItem=0; nItem<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nItem++)
		{
			sprintf(szBuffer, "%s.%s", pPGBlock->m_TransformerWindingArray[nItem].szSub, pPGBlock->m_TransformerWindingArray[nItem].szName);
			if (stricmp(szBuffer, strEleArray[1].c_str()) == 0)
			{
				nDev = nItem;
				break;
			}
		}
		if (nDev >= 0)
		{
			nItem = 2;
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fQi = (float)atof(strEleArray[nItem++].c_str());
			if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[nDev].fQz = (float)atof(strEleArray[nItem++].c_str());

			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szVoltI);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_TransformerWindingArray[nDev].fAi = 1000*sqrt(pPGBlock->m_TransformerWindingArray[nDev].fPi*pPGBlock->m_TransformerWindingArray[nDev].fPi+pPGBlock->m_TransformerWindingArray[nDev].fQi*pPGBlock->m_TransformerWindingArray[nDev].fQi)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
			nItem = PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szVoltJ);
			if (nItem >= 0)
			{
				if (pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage > FLT_MIN)
					pPGBlock->m_TransformerWindingArray[nDev].fAz = 1000*sqrt(pPGBlock->m_TransformerWindingArray[nDev].fPz*pPGBlock->m_TransformerWindingArray[nDev].fPz+pPGBlock->m_TransformerWindingArray[nDev].fQz*pPGBlock->m_TransformerWindingArray[nDev].fQz)/pPGBlock->m_VoltageLevelArray[nItem].nominalVoltage/1.732;
			}
		}
		return;
	}
}

void CPG2BpaFileApi::PGParseBpaPfoLineLoss(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine)
{
	register int	i;
	int		nItem, nLine;
	char	szBuffer[256];
	std::vector<std::string>	strEleArray;
	char	cLoop;
	char	szFrBus[MDB_CHARLEN_SHORTER], szToBus[MDB_CHARLEN_SHORTER];
	float	fFrBusVolt, fToBusVolt;

	strcpy(szBuffer, lpszLine+10);

	strEleArray.clear();
	char*	lpszToken=strtok(szBuffer, " /\t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " /\t\n");
	}

	if (strEleArray.size() < 8)
		return;

	nItem = 0;
	strcpy(szFrBus, strEleArray[nItem++].c_str());
	fFrBusVolt = atof(strEleArray[nItem++].c_str());
	strcpy(szToBus, strEleArray[nItem++].c_str());
	fToBusVolt = atof(strEleArray[nItem++].c_str());
	if (strEleArray.size() == 8)
	{
		for (nLine=0; nLine<(int)m_LineArray.size(); nLine++)
		{
			if (stricmp(m_LineArray[nLine].szBusI, szFrBus) == 0 && stricmp(m_LineArray[nLine].szBusJ, szToBus) == 0 ||
				stricmp(m_LineArray[nLine].szBusI, szToBus) == 0 && stricmp(m_LineArray[nLine].szBusJ, szFrBus) == 0)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[i].fLossP = (float)atof(strEleArray[nItem++].c_str());
						nItem++;
						nItem++;
						if (strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[i].fLossQ = (float)atof(strEleArray[nItem++].c_str());
						break;
					}
				}

				break;
			}
		}
	}
	else if (strEleArray.size() == 9)
	{
		cLoop = strEleArray[nItem++][0];
		for (nLine=0; nLine<(int)m_LineArray.size(); nLine++)
		{
			if ((stricmp(m_LineArray[nLine].szBusI, szFrBus) == 0 && stricmp(m_LineArray[nLine].szBusJ, szToBus) == 0 || stricmp(m_LineArray[nLine].szBusI, szToBus) == 0 && stricmp(m_LineArray[nLine].szBusJ, szFrBus) == 0) &&
				cLoop == m_LineArray[nLine].cLoop)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[i].fLossP = (float)atof(strEleArray[nItem++].c_str());
						nItem++;
						nItem++;
						if (strEleArray.size() > nItem)	pPGBlock->m_ACLineSegmentArray[i].fLossQ = (float)atof(strEleArray[nItem++].c_str());
						break;
					}
				}
				break;
			}
		}
	}
}

void CPG2BpaFileApi::PGParseBpaPfoTranLoss(tagPGBlock* pPGBlock, const int nIsland, const char* lpszLine)
{
	register int	i;
	int		nItem, nTran;
	char	szBuffer[256], szTranName[260];
	std::vector<std::string>	strEleArray;
	char	cLoop;
	char	szFrBus[MDB_CHARLEN_SHORTER], szToBus[MDB_CHARLEN_SHORTER];
	float	fFrBusVolt, fToBusVolt;

	strcpy(szBuffer, lpszLine+10);

	strEleArray.clear();
	char*	lpszToken=strtok(szBuffer, " /\t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " /\t\n");
	}

	if (strEleArray.size() < 8)
		return;

	nItem = 0;
	strcpy(szFrBus, strEleArray[nItem++].c_str());
	fFrBusVolt = atof(strEleArray[nItem++].c_str());
	strcpy(szToBus, strEleArray[nItem++].c_str());
	fToBusVolt = atof(strEleArray[nItem++].c_str());
	if (strEleArray.size() == 8)
	{
		for (nTran=0; nTran<(int)m_TranArray.size(); nTran++)
		{
			if (stricmp(m_TranArray[nTran].szBusI, szFrBus) == 0 && stricmp(m_TranArray[nTran].szBusJ, szToBus) == 0 ||
				stricmp(m_TranArray[nTran].szBusI, szToBus) == 0 && stricmp(m_TranArray[nTran].szBusJ, szFrBus) == 0)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
				{
					sprintf(szTranName, "%s.%s", pPGBlock->m_TransformerWindingArray[i].szSub, pPGBlock->m_TransformerWindingArray[i].szName);
					if (stricmp(szTranName, m_TranArray[nTran].szAlias) == 0)
					{
						nItem++;
						nItem++;
						if (strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[i].fLossP = (float)atof(strEleArray[nItem++].c_str());
						if (strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[i].fLossQ = (float)atof(strEleArray[nItem++].c_str());
						break;
					}
				}
				break;
			}
		}
	}
	else if (strEleArray.size() == 9)
	{
		cLoop = strEleArray[nItem++][0];
		for (nTran=0; nTran<(int)m_TranArray.size(); nTran++)
		{
			if ((stricmp(m_TranArray[nTran].szBusI, szFrBus) == 0 && stricmp(m_TranArray[nTran].szBusJ, szToBus) == 0 || stricmp(m_TranArray[nTran].szBusI, szToBus) == 0 && stricmp(m_TranArray[nTran].szBusJ, szFrBus) == 0) &&
				cLoop == m_TranArray[nTran].cLoop)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
				{
					sprintf(szTranName, "%s.%s", pPGBlock->m_TransformerWindingArray[i].szSub, pPGBlock->m_TransformerWindingArray[i].szName);
					if (stricmp(szTranName, m_TranArray[nTran].szAlias) == 0)
					{
						nItem++;
						nItem++;
						if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[i].fLossP = (float)atof(strEleArray[nItem++].c_str());
						if ((int)strEleArray.size() > nItem)	pPGBlock->m_TransformerWindingArray[i].fLossQ = (float)atof(strEleArray[nItem++].c_str());
						break;
					}
				}

				break;
			}
		}
	}
}

void CPG2BpaFileApi::PGParseBpaPfoACBranch(tagPGBlock* pPGBlock, const char* lpszFrBusName, const double fFrBusVolt, const char* lpszLine)
{
	register int	i;
	int		nLine, nChar;
	char	szLine[256], szToBusName[MDB_CHARLEN], szTranName[MDB_CHARLEN];
	char*	lpszToken;
	double	fToBusVolt;
	char	cLoop;
	unsigned char	bSetted;
	std::vector<std::string>	strEleArray;

	nChar=0;
	for (i=7; i<34; i++)
		szLine[nChar++]=lpszLine[i];
	szLine[nChar++]='\0';

	strEleArray.clear();
	lpszToken=strtok(szLine, " \t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	if (strEleArray.size() > 0)	strcpy(szToBusName, strEleArray[0].c_str());	else	return;
	if (strEleArray.size() > 1)	fToBusVolt=atof(strEleArray[1].c_str());		else	return;

	if (strEleArray.size() > 2)
	{
		cLoop=strEleArray[2][0];

		memset(szLine, 0, 256);
		strcpy(szLine, lpszLine+37);
		strEleArray.clear();
		lpszToken=strtok(szLine, " /\t\n");
		while (lpszToken != NULL)
		{
			strEleArray.push_back(lpszToken);
			lpszToken=strtok(NULL, " /\t\n");
		}

		bSetted=0;
		for (nLine=0; nLine<(int)m_LineArray.size(); nLine++)
		{
			if (stricmp(m_LineArray[nLine].szBusI, lpszFrBusName) == 0 && stricmp(m_LineArray[nLine].szBusJ, szToBusName) == 0 && cLoop == m_LineArray[nLine].cLoop)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fPi=(float)atof(szLine);		}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fQi=(float)atof(szLine);		}
						if (strEleArray.size() > 2)	{	ResolveNumericString(strEleArray[2].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fLossP=(float)atof(szLine);	}
						if (strEleArray.size() > 3)	{	ResolveNumericString(strEleArray[3].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fLossQ=(float)atof(szLine);	}
						pPGBlock->m_ACLineSegmentArray[i].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[i].fPi*pPGBlock->m_ACLineSegmentArray[i].fPi+pPGBlock->m_ACLineSegmentArray[i].fQi*pPGBlock->m_ACLineSegmentArray[i].fQi)/fFrBusVolt/1.732;
						break;
					}
				}
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
				{
					if (stricmp(pPGBlock->m_SeriesCompensatorArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fPi=(float)atof(szLine);		}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fQi=(float)atof(szLine);		}
						if (strEleArray.size() > 2)	{	ResolveNumericString(strEleArray[2].c_str(), szLine);																		}
						if (strEleArray.size() > 3)	{	ResolveNumericString(strEleArray[3].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fLossQ=(float)atof(szLine);	}
						pPGBlock->m_SeriesCompensatorArray[i].fA = 1000*sqrt(pPGBlock->m_SeriesCompensatorArray[i].fPi*pPGBlock->m_SeriesCompensatorArray[i].fPi+pPGBlock->m_SeriesCompensatorArray[i].fQi*pPGBlock->m_SeriesCompensatorArray[i].fQi)/fFrBusVolt/1.732;
						break;
					}
				}
				bSetted=1;
				break;
			}
			else if (stricmp(m_LineArray[nLine].szBusJ, lpszFrBusName) == 0 && stricmp(m_LineArray[nLine].szBusI, szToBusName) == 0 && cLoop == m_LineArray[nLine].cLoop)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fPz=(float)atof(szLine);	}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fQz=(float)atof(szLine);	}
						pPGBlock->m_ACLineSegmentArray[i].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[i].fPz*pPGBlock->m_ACLineSegmentArray[i].fPz+pPGBlock->m_ACLineSegmentArray[i].fQz*pPGBlock->m_ACLineSegmentArray[i].fQz)/fToBusVolt/1.732;
						break;
					}
				}
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
				{
					if (stricmp(pPGBlock->m_SeriesCompensatorArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fPz=(float)atof(szLine);	}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fQz=(float)atof(szLine);	}
						pPGBlock->m_SeriesCompensatorArray[i].fA = 1000*sqrt(pPGBlock->m_SeriesCompensatorArray[i].fPz*pPGBlock->m_SeriesCompensatorArray[i].fPz+pPGBlock->m_SeriesCompensatorArray[i].fQz*pPGBlock->m_SeriesCompensatorArray[i].fQz)/fToBusVolt/1.732;
						break;
					}
				}
				bSetted=1;
				break;
			}
		}
		if (!bSetted)
		{
			for (nLine=0; nLine<(int)m_TranArray.size(); nLine++)
			{
				if (stricmp(m_TranArray[nLine].szBusI, lpszFrBusName) == 0 && stricmp(m_TranArray[nLine].szBusJ, szToBusName) == 0 && cLoop == m_TranArray[nLine].cLoop)
				{
					for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
					{
						sprintf(szTranName, "%s.%s", pPGBlock->m_TransformerWindingArray[i].szSub, pPGBlock->m_TransformerWindingArray[i].szName);
						if (stricmp(szTranName, m_TranArray[nLine].szAlias) == 0)
						{
							if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fPi=(float)atof(szLine);		}
							if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fQi=(float)atof(szLine);		}
							if (strEleArray.size() > 2)	{	ResolveNumericString(strEleArray[2].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fLossP=(float)atof(szLine);	}
							if (strEleArray.size() > 3)	{	ResolveNumericString(strEleArray[3].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fLossQ=(float)atof(szLine);	}

							pPGBlock->m_TransformerWindingArray[i].fAi = 1000*sqrt(pPGBlock->m_TransformerWindingArray[i].fPi*pPGBlock->m_TransformerWindingArray[i].fPi+pPGBlock->m_TransformerWindingArray[i].fQi*pPGBlock->m_TransformerWindingArray[i].fQi)/fFrBusVolt/1.732;
							break;
						}
					}
					bSetted=1;
					break;
				}
				else if (stricmp(m_TranArray[nLine].szBusJ, lpszFrBusName) == 0 && stricmp(m_TranArray[nLine].szBusI, szToBusName) == 0 && cLoop == m_TranArray[nLine].cLoop)
				{
					for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
					{
						sprintf(szTranName, "%s.%s", pPGBlock->m_TransformerWindingArray[i].szSub, pPGBlock->m_TransformerWindingArray[i].szName);
						if (stricmp(szTranName, m_TranArray[nLine].szAlias) == 0)
						{
							if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fPz=(float)atof(szLine);		}
							if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fQz=(float)atof(szLine);		}

							pPGBlock->m_TransformerWindingArray[i].fAz = 1000*sqrt(pPGBlock->m_TransformerWindingArray[i].fPz*pPGBlock->m_TransformerWindingArray[i].fPz+pPGBlock->m_TransformerWindingArray[i].fQz*pPGBlock->m_TransformerWindingArray[i].fQz)/fToBusVolt/1.732;
							break;
						}
					}
					bSetted=1;
					break;
				}
			}
		}
	}
	else
	{
		memset(szLine, 0, 256);
		strcpy(szLine, lpszLine+37);
		strEleArray.clear();
		lpszToken=strtok(szLine, " /\t\n");
		while (lpszToken != NULL)
		{
			strEleArray.push_back(lpszToken);
			lpszToken=strtok(NULL, " /\t\n");
		}

		bSetted=0;
		for (nLine=0; nLine<(int)m_LineArray.size(); nLine++)
		{
			if (stricmp(m_LineArray[nLine].szBusI, lpszFrBusName) == 0 && stricmp(m_LineArray[nLine].szBusJ, szToBusName) == 0)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fPi=(float)atof(szLine);		}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fQi=(float)atof(szLine);		}
						if (strEleArray.size() > 2)	{	ResolveNumericString(strEleArray[2].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fLossP=(float)atof(szLine);	}
						if (strEleArray.size() > 3)	{	ResolveNumericString(strEleArray[3].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fLossQ=(float)atof(szLine);	}
						pPGBlock->m_ACLineSegmentArray[i].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[i].fPi*pPGBlock->m_ACLineSegmentArray[i].fPi+pPGBlock->m_ACLineSegmentArray[i].fQi*pPGBlock->m_ACLineSegmentArray[i].fQi)/fFrBusVolt/1.732;
						break;
					}
				}
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
				{
					if (stricmp(pPGBlock->m_SeriesCompensatorArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fPi=(float)atof(szLine);		}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fQi=(float)atof(szLine);		}
						if (strEleArray.size() > 2)	{	ResolveNumericString(strEleArray[2].c_str(), szLine);																		}
						if (strEleArray.size() > 3)	{	ResolveNumericString(strEleArray[3].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fLossQ=(float)atof(szLine);	}
						pPGBlock->m_SeriesCompensatorArray[i].fA = 1000*sqrt(pPGBlock->m_SeriesCompensatorArray[i].fPi*pPGBlock->m_SeriesCompensatorArray[i].fPi+pPGBlock->m_SeriesCompensatorArray[i].fQi*pPGBlock->m_SeriesCompensatorArray[i].fQi)/fFrBusVolt/1.732;
						break;
					}
				}
				bSetted=1;
				break;
			}
			else if (stricmp(m_LineArray[nLine].szBusJ, lpszFrBusName) == 0 && stricmp(m_LineArray[nLine].szBusI, szToBusName) == 0)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fPz=(float)atof(szLine);		}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_ACLineSegmentArray[i].fQz=(float)atof(szLine);		}
						pPGBlock->m_ACLineSegmentArray[i].fA = 1000*sqrt(pPGBlock->m_ACLineSegmentArray[i].fPz*pPGBlock->m_ACLineSegmentArray[i].fPz+pPGBlock->m_ACLineSegmentArray[i].fQz*pPGBlock->m_ACLineSegmentArray[i].fQz)/fToBusVolt/1.732;
						break;
					}
				}
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
				{
					if (stricmp(pPGBlock->m_SeriesCompensatorArray[i].szName, m_LineArray[nLine].szAlias) == 0)
					{
						if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fPz=(float)atof(szLine);		}
						if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_SeriesCompensatorArray[i].fQz=(float)atof(szLine);		}
						pPGBlock->m_SeriesCompensatorArray[i].fA = 1000*sqrt(pPGBlock->m_SeriesCompensatorArray[i].fPz*pPGBlock->m_SeriesCompensatorArray[i].fPz+pPGBlock->m_SeriesCompensatorArray[i].fQz*pPGBlock->m_SeriesCompensatorArray[i].fQz)/fToBusVolt/1.732;
						break;
					}
				}
				bSetted=1;
				break;
			}
		}
		if (!bSetted)
		{
			for (nLine=0; nLine<(int)m_TranArray.size(); nLine++)
			{
				if (stricmp(m_TranArray[nLine].szBusI, lpszFrBusName) == 0 && stricmp(m_TranArray[nLine].szBusJ, szToBusName) == 0)
				{
					for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
					{
						sprintf(szTranName, "%s.%s", pPGBlock->m_TransformerWindingArray[i].szSub, pPGBlock->m_TransformerWindingArray[i].szName);
						if (stricmp(szTranName, m_TranArray[nLine].szAlias) == 0)
						{
							if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fPi=(float)atof(szLine);		}
							if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fQi=(float)atof(szLine);		}
							if (strEleArray.size() > 2)	{	ResolveNumericString(strEleArray[2].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fLossP=(float)atof(szLine);	}
							if (strEleArray.size() > 3)	{	ResolveNumericString(strEleArray[3].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fLossQ=(float)atof(szLine);	}
							pPGBlock->m_TransformerWindingArray[i].fAi = 1000*sqrt(pPGBlock->m_TransformerWindingArray[i].fPi*pPGBlock->m_TransformerWindingArray[i].fPi+pPGBlock->m_TransformerWindingArray[i].fQi*pPGBlock->m_TransformerWindingArray[i].fQi)/fFrBusVolt/1.732;
							break;
						}
					}
					bSetted=1;
					break;
				}
				else if (stricmp(m_TranArray[nLine].szBusJ, lpszFrBusName) == 0 && stricmp(m_TranArray[nLine].szBusI, szToBusName) == 0)
				{
					for (i=0; i<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
					{
						sprintf(szTranName, "%s.%s", pPGBlock->m_TransformerWindingArray[i].szSub, pPGBlock->m_TransformerWindingArray[i].szName);
						if (stricmp(szTranName, m_TranArray[nLine].szAlias) == 0)
						{
							if (strEleArray.size() > 0)	{	ResolveNumericString(strEleArray[0].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fPz=(float)atof(szLine);	}
							if (strEleArray.size() > 1)	{	ResolveNumericString(strEleArray[1].c_str(), szLine);	pPGBlock->m_TransformerWindingArray[i].fQz=(float)atof(szLine);	}
							pPGBlock->m_TransformerWindingArray[i].fAz = 1000*sqrt(pPGBlock->m_TransformerWindingArray[i].fPz*pPGBlock->m_TransformerWindingArray[i].fPz+pPGBlock->m_TransformerWindingArray[i].fQz*pPGBlock->m_TransformerWindingArray[i].fQz)/fToBusVolt/1.732;
							break;
						}
					}
					bSetted=1;
					break;
				}
			}
		}
	}
}

int		CPG2BpaFileApi::PGParsePfoFile(IN tagPGBlock* pPGBlock, IN const char* lpszWorkDir)
{
	int				nSub, nVolt, nDev, nLine;
	unsigned char	bPfoSection, bBpaVersion2, bDetailedOutputList;
	char			szFileName[260], szLine[1024], szFrBusName[MDB_CHARLEN];
	double			fFrBusVolt;
	FILE*			fp;

	register int	i;
	int				nNode, nIndex;
	unsigned char	nStatusBack, bRinged;
	int				nNodeNum, nNodeArray[1000];
	double			fTotal, fBreakerP, fBreakerQ;
	int				nIsland, nTopoBus, nDevNum;

	std::vector<std::string>	strPfoLineArray;

	//////////////////////////////////////////////////////////////////////////
	//	��Ϣ��ʼ��
	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		pPGBlock->m_IslandArray[nIsland].bPFConvergency=0;
		pPGBlock->m_IslandArray[nIsland].fUnitP=0;
		pPGBlock->m_IslandArray[nIsland].fUnitQ=0;
		pPGBlock->m_IslandArray[nIsland].fLoadP=0;
		pPGBlock->m_IslandArray[nIsland].fLoadQ=0;
		pPGBlock->m_IslandArray[nIsland].fShuntQ=0;
		pPGBlock->m_IslandArray[nIsland].fLossP=0;
		pPGBlock->m_IslandArray[nIsland].fLossQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TOPOBUS]; nDev++)
	{
		pPGBlock->m_TopoBusArray[nDev].fV=0;
		pPGBlock->m_TopoBusArray[nDev].fD=0;
		pPGBlock->m_TopoBusArray[nDev].fGenP=0;
		pPGBlock->m_TopoBusArray[nDev].fGenQ=0;
		pPGBlock->m_TopoBusArray[nDev].fLoadP=0;
		pPGBlock->m_TopoBusArray[nDev].fLoadQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		pPGBlock->m_SynchronousMachineArray[nDev].fV=0;
		pPGBlock->m_SynchronousMachineArray[nDev].fD=0;
		pPGBlock->m_SynchronousMachineArray[nDev].fP=0;
		pPGBlock->m_SynchronousMachineArray[nDev].fQ=0;
		pPGBlock->m_SynchronousMachineArray[nDev].fFactor=0;
		pPGBlock->m_SynchronousMachineArray[nDev].fA=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		pPGBlock->m_EnergyConsumerArray[nDev].fV=0;
		pPGBlock->m_EnergyConsumerArray[nDev].fD=0;
		pPGBlock->m_EnergyConsumerArray[nDev].fP=0;
		pPGBlock->m_EnergyConsumerArray[nDev].fQ=0;
		pPGBlock->m_EnergyConsumerArray[nDev].fFactor=0;
		pPGBlock->m_EnergyConsumerArray[nDev].fA=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; nDev++)
	{
		pPGBlock->m_ShuntCompensatorArray[nDev].fQ=0;
		pPGBlock->m_ShuntCompensatorArray[nDev].fA=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
	{
		pPGBlock->m_BusbarSectionArray[nDev].fV=0;
		pPGBlock->m_BusbarSectionArray[nDev].fD=0;
		pPGBlock->m_BusbarSectionArray[nDev].fLoadP=0;
		pPGBlock->m_BusbarSectionArray[nDev].fLoadQ=0;
		pPGBlock->m_BusbarSectionArray[nDev].fGenP=0;
		pPGBlock->m_BusbarSectionArray[nDev].fGenQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		pPGBlock->m_ACLineSegmentArray[nDev].fPi=0;
		pPGBlock->m_ACLineSegmentArray[nDev].fQi=0;
		pPGBlock->m_ACLineSegmentArray[nDev].fPz=0;
		pPGBlock->m_ACLineSegmentArray[nDev].fQz=0;
		pPGBlock->m_ACLineSegmentArray[nDev].fA=0;
		pPGBlock->m_ACLineSegmentArray[nDev].fLossP=0;
		pPGBlock->m_ACLineSegmentArray[nDev].fLossQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		pPGBlock->m_TransformerWindingArray[nDev].fPi=0;
		pPGBlock->m_TransformerWindingArray[nDev].fQi=0;
		pPGBlock->m_TransformerWindingArray[nDev].fPz=0;
		pPGBlock->m_TransformerWindingArray[nDev].fQz=0;
		pPGBlock->m_TransformerWindingArray[nDev].fAi=0;
		pPGBlock->m_TransformerWindingArray[nDev].fAz=0;
		pPGBlock->m_TransformerWindingArray[nDev].fLossP=0;
		pPGBlock->m_TransformerWindingArray[nDev].fLossQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nDev++)
	{
		pPGBlock->m_SeriesCompensatorArray[nDev].fPi=0;
		pPGBlock->m_SeriesCompensatorArray[nDev].fQi=0;
		pPGBlock->m_SeriesCompensatorArray[nDev].fPz=0;
		pPGBlock->m_SeriesCompensatorArray[nDev].fQz=0;
		pPGBlock->m_SeriesCompensatorArray[nDev].fA=0;
		pPGBlock->m_SeriesCompensatorArray[nDev].fLossQ=0;
	}
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BREAKER]; nDev++)
	{
		pPGBlock->m_BreakerArray[nDev].fP=0;
		pPGBlock->m_BreakerArray[nDev].fQ=0;
		pPGBlock->m_BreakerArray[nDev].fA=0;
	}

	//////////////////////////////////////////////////////////////////////////
	//	����PFO�ļ�
	for (nIsland=1; nIsland<pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		strPfoLineArray.clear();

		sprintf(szFileName, "%s/%s%d.pfo", lpszWorkDir, m_BpaDatConCard.szProject, nIsland);

		fp=fopen(szFileName, "r");
		if (fp == NULL)
			continue;

		bBpaVersion2=0;
		bDetailedOutputList=0;
		while (!feof(fp))
		{
			memset(szLine, 0, 1024);
			fgets(szLine, 1024, fp);

			TrimEnd(szLine);
			TrimRight(szLine);
			if (strlen(szLine) <= 0)
				continue;

			if (strstr(szLine, "SUCCESSFUL SOLUTION REACHED") != NULL || strstr(szLine, "����������") != NULL)
				pPGBlock->m_IslandArray[nIsland].bPFConvergency=1;

			if (strstr(szLine, "COMPLETE OUTPUT LISTING OF ALL BUSSES WILL BE GIVEN") != NULL)
			{
				bBpaVersion2=1;
				bDetailedOutputList=1;
			}

			if (strstr(szLine, "DETAILED OUTPUT LISTING") != NULL || strstr(szLine, "��ϸ������б�") != NULL)
				bDetailedOutputList=1;

			strPfoLineArray.push_back(szLine);
		}
		fclose(fp);

		if (bDetailedOutputList && pPGBlock->m_IslandArray[nIsland].bPFConvergency)
		{
			FormLArray(pPGBlock, nIsland);
			FormTArray(pPGBlock, nIsland);

			bPfoSection=0;

			memset(szFrBusName, 0, MDB_CHARLEN);
			nTopoBus = -1;

			nLine=0;
			while (nLine < (int)strPfoLineArray.size())
			{
				if (strPfoLineArray[nLine][0] == '*')	//	���������жϡ�
					bPfoSection=0;

				if (strPfoLineArray[nLine].find("COMPLETE OUTPUT LISTING OF ALL BUSSES WILL BE GIVEN") != string::npos)
				{
					bPfoSection=1;
					nLine++;
					continue;
				}
				else if (strPfoLineArray[nLine].find("END OF ANALYSIS LISTINGS") != string::npos || strPfoLineArray[nLine].find("OUTPUT CHECK") != string::npos)
				{
					bPfoSection=0;
				}
				else if (strPfoLineArray[nLine].find("PWRFLO case:") != string::npos || strPfoLineArray[nLine].find("������ʽ��:") != string::npos)
				{
					if (strPfoLineArray[nLine].find("DETAILED OUTPUT LISTING") != string::npos || strPfoLineArray[nLine].find("��ϸ������б�") != string::npos)
						bPfoSection=1;
					else
						bPfoSection=0;

					nLine++;
					continue;
				}
				if (strPfoLineArray[nLine].find("�Զ������") != string::npos)
				{
					bPfoSection=0;
					PGParseBpaPfoOutput(pPGBlock, nIsland, strPfoLineArray[nLine].c_str());
				}
				if (strPfoLineArray[nLine].find("���շ����������·��ĺͳ�繦�������б�") != string::npos)
				{
					bPfoSection=2;
				}
				if (strPfoLineArray[nLine].find("���շ�������ı�ѹ����������б�") != string::npos)
				{
					bPfoSection=3;
				}

				if (bPfoSection == 1)
				{
					if (bBpaVersion2)
					{
						if (strPfoLineArray[nLine][1] != ' ')
							nTopoBus = PGParseBpaPfoBusLine(pPGBlock, strPfoLineArray[nLine].c_str()+1, strPfoLineArray[nLine+1].c_str()+1, szFrBusName, fFrBusVolt);
						else if (strlen(szFrBusName) > 0)
						{
							if (nTopoBus > 0 && !isBpaPfoShuntLine(strPfoLineArray[nLine].c_str()+1))
								PGParseBpaPfoBusShunt(pPGBlock, nTopoBus, strPfoLineArray[nLine].c_str()+1);
							else
								PGParseBpaPfoACBranch(pPGBlock, szFrBusName, fFrBusVolt, strPfoLineArray[nLine].c_str()+1);
						}
					}
					else
					{
						if (strPfoLineArray[nLine][0] != ' ')
							nTopoBus = PGParseBpaPfoBusLine(pPGBlock, strPfoLineArray[nLine].c_str(), strPfoLineArray[nLine+1].c_str(), szFrBusName, fFrBusVolt);
						else if (strlen(szFrBusName) > 0)
						{
							PGParseBpaPfoACBranch(pPGBlock, szFrBusName, fFrBusVolt, strPfoLineArray[nLine].c_str());
						}
					}
				}
				else if (bPfoSection == 2)
				{
					PGParseBpaPfoLineLoss(pPGBlock, nIsland, strPfoLineArray[nLine].c_str());
				}
				else if (bPfoSection == 3)
				{
					PGParseBpaPfoTranLoss(pPGBlock, nIsland, strPfoLineArray[nLine].c_str());
				}

				nLine++;
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ToopoBus -> �����豸
	for (nTopoBus=0; nTopoBus<pPGBlock->m_nRecordNum[PG_TOPOBUS]; nTopoBus++)
	{
		if (pPGBlock->m_IslandArray[pPGBlock->m_TopoBusArray[nTopoBus].nIsland].bDead)
			continue;
		if (pPGBlock->m_TopoBusArray[nTopoBus].nVolt < 0)
			continue;

		//////////////////////////////////////////////////////////////////////////
		//	ĸ��
		nDevNum=0;
		for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nBusbarSectionRange; nDev++)
		{
			if (pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
				continue;
			if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nDev].nNode].nTopoBus != nTopoBus)
				continue;

			nDevNum++;
			pPGBlock->m_BusbarSectionArray[nDev].fV=(float)pPGBlock->m_TopoBusArray[nTopoBus].fV;
			pPGBlock->m_BusbarSectionArray[nDev].fD=(float)pPGBlock->m_TopoBusArray[nTopoBus].fD;
		}

		if (nDevNum > 0)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nBusbarSectionRange; nDev++)
			{
				if (pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nDev].nNode].nTopoBus != nTopoBus)
					continue;

				pPGBlock->m_BusbarSectionArray[nDev].fLoadP = (float)pPGBlock->m_TopoBusArray[nTopoBus].fLoadP/nDevNum;
				pPGBlock->m_BusbarSectionArray[nDev].fLoadQ = (float)pPGBlock->m_TopoBusArray[nTopoBus].fLoadQ/nDevNum;
				pPGBlock->m_BusbarSectionArray[nDev].fGenP  = (float)pPGBlock->m_TopoBusArray[nTopoBus].fGenP /nDevNum;
				pPGBlock->m_BusbarSectionArray[nDev].fGenQ  = (float)pPGBlock->m_TopoBusArray[nTopoBus].fGenQ /nDevNum;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	����
		nDevNum=0;
		for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nSynchronousMachineRange; nDev++)
		{
			if (pPGBlock->m_SynchronousMachineArray[nDev].nNode < 0)
				continue;
			if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_SynchronousMachineArray[nDev].nNode].nTopoBus != nTopoBus)
				continue;

			nDevNum++;
			pPGBlock->m_SynchronousMachineArray[nDev].fV=(float)pPGBlock->m_TopoBusArray[nTopoBus].fV;
			pPGBlock->m_SynchronousMachineArray[nDev].fD=(float)pPGBlock->m_TopoBusArray[nTopoBus].fD;
		}

		if (nDevNum > 0)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nSynchronousMachineRange; nDev++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_SynchronousMachineArray[nDev].nNode].nTopoBus != nTopoBus)
					continue;

				pPGBlock->m_SynchronousMachineArray[nDev].fP = (float)pPGBlock->m_TopoBusArray[nTopoBus].fGenP/nDevNum;
				pPGBlock->m_SynchronousMachineArray[nDev].fQ = (float)pPGBlock->m_TopoBusArray[nTopoBus].fGenQ/nDevNum;
				if (fabs(pPGBlock->m_SynchronousMachineArray[nDev].fP) < FLT_MIN && fabs(pPGBlock->m_SynchronousMachineArray[nDev].fPlanP) > FLT_MIN)
				{
					pPGBlock->m_SynchronousMachineArray[nDev].fP = pPGBlock->m_SynchronousMachineArray[nDev].fPlanP;
					pPGBlock->m_SynchronousMachineArray[nDev].fQ = pPGBlock->m_SynchronousMachineArray[nDev].fPlanQ;
				}

				if (pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nominalVoltage > FLT_MIN)
					pPGBlock->m_SynchronousMachineArray[nDev].fA = (float)(1000*sqrt(pPGBlock->m_SynchronousMachineArray[nDev].fP*pPGBlock->m_SynchronousMachineArray[nDev].fP+pPGBlock->m_SynchronousMachineArray[nDev].fQ*pPGBlock->m_SynchronousMachineArray[nDev].fQ)/pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nominalVoltage/1.732);

			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	����
		fTotal = 0;
		nDevNum = 0;
		for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nEnergyConsumerRange; nDev++)
		{
			if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
				continue;
			if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_EnergyConsumerArray[nDev].nNode].nTopoBus != nTopoBus)
				continue;

			pPGBlock->m_EnergyConsumerArray[nDev].fV=(float)pPGBlock->m_TopoBusArray[nTopoBus].fV;
			pPGBlock->m_EnergyConsumerArray[nDev].fD=(float)pPGBlock->m_TopoBusArray[nTopoBus].fD;
			fTotal += pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
			nDevNum++;
		}

		if (nDevNum > 0 && fTotal > FLT_MIN)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_EnergyConsumerArray[nDev].nNode].nTopoBus != nTopoBus)
					continue;

				pPGBlock->m_EnergyConsumerArray[nDev].fP = (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_TopoBusArray[nTopoBus].fLoadP/fTotal);
				pPGBlock->m_EnergyConsumerArray[nDev].fQ = (float)(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP*pPGBlock->m_TopoBusArray[nTopoBus].fLoadQ/fTotal);
				if (fabs(pPGBlock->m_EnergyConsumerArray[nDev].fP) < FLT_MIN && fabs(pPGBlock->m_EnergyConsumerArray[nDev].fPlanP) > FLT_MIN)
				{
					pPGBlock->m_EnergyConsumerArray[nDev].fP = pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
					pPGBlock->m_EnergyConsumerArray[nDev].fQ = pPGBlock->m_EnergyConsumerArray[nDev].fPlanQ;
				}
				else if (fabs(pPGBlock->m_EnergyConsumerArray[nDev].fP - pPGBlock->m_EnergyConsumerArray[nDev].fPlanP) > 0.01)
				{
					pPGBlock->m_EnergyConsumerArray[nDev].fP = pPGBlock->m_EnergyConsumerArray[nDev].fPlanP;
					pPGBlock->m_EnergyConsumerArray[nDev].fQ = pPGBlock->m_EnergyConsumerArray[nDev].fPlanQ;
				}
				if (pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nominalVoltage > FLT_MIN)
					pPGBlock->m_EnergyConsumerArray[nDev].fA = (float)(1000*sqrt(pPGBlock->m_EnergyConsumerArray[nDev].fP*pPGBlock->m_EnergyConsumerArray[nDev].fP+pPGBlock->m_EnergyConsumerArray[nDev].fQ*pPGBlock->m_EnergyConsumerArray[nDev].fQ)/pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nominalVoltage/1.732);
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	����
		fTotal = 0;
		nDevNum = 0;
		for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nShuntCompensatorRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nShuntCompensatorRange; nDev++)
		{
			if (pPGBlock->m_ShuntCompensatorArray[nDev].nNode < 0)
				continue;
			if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ShuntCompensatorArray[nDev].nNode].nTopoBus != nTopoBus)
				continue;

			fTotal += pPGBlock->m_ShuntCompensatorArray[nDev].fCap;
			nDevNum++;
		}

		if (nDevNum > 0 && fTotal > FLT_MIN)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nEnergyConsumerRange; nDev<pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (pPGBlock->m_ShuntCompensatorArray[nDev].nNode < 0)
					continue;
				if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ShuntCompensatorArray[nDev].nNode].nTopoBus != nTopoBus)
					continue;

				pPGBlock->m_ShuntCompensatorArray[nDev].fQ = (float)(pPGBlock->m_ShuntCompensatorArray[nDev].fCap*pPGBlock->m_TopoBusArray[nTopoBus].fShuntQ/fTotal);
				if (pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nominalVoltage > FLT_MIN)
					pPGBlock->m_ShuntCompensatorArray[nDev].fA = (float)(1000*fabs(pPGBlock->m_ShuntCompensatorArray[nDev].fQ)/pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nominalVoltage/1.732);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	���ö�·�����
	for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_BREAKER]; nDev++)
	{
		pPGBlock->m_BreakerArray[nDev].fP = 0;
		pPGBlock->m_BreakerArray[nDev].fQ = 0;
		pPGBlock->m_BreakerArray[nDev].fA = 0;
	}

	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
			{
				if (pPGBlock->m_BreakerArray[nDev].nJointDevType == PG_ACLINESEGMENT)
				{
					if (stricmp(pPGBlock->m_BreakerArray[nDev].szSub, pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].szSubI) == 0)
					{
						pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPi;
						pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQi;
						pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fA;
					}
					else
					{
						pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPz;
						pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQz;
						pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_ACLineSegmentArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fA;
					}
				}
				else if (pPGBlock->m_BreakerArray[nDev].nJointDevType == PG_TRANSFORMERWINDING)
				{
					if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].bTranMidSide == 0)
					{
						if (stricmp(pPGBlock->m_BreakerArray[nDev].szVolt, pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].szVoltI) == 0)
						{
							pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPi;
							pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQi;
							pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fAi;
						}
						else
						{
							pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPz;
							pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQz;
							pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fAz;
						}
					}
					else if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].bTranMidSide == 1)
					{
						pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPz;
						pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQz;
						pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fAz;
					}
					else
					{
						pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPi;
						pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQi;
						pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_TransformerWindingArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fAi;
					}
				}
				else if (pPGBlock->m_BreakerArray[nDev].nJointDevType == PG_SERIESCOMPENSATOR)
				{
					pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fPi;
					pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQi;
					pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fA;
				}
				else if (pPGBlock->m_BreakerArray[nDev].nJointDevType == PG_SYNCHRONOUSMACHINE)
				{
					pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_SynchronousMachineArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fP;
					pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_SynchronousMachineArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQ;
					pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_SynchronousMachineArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fA;
				}
				else if (pPGBlock->m_BreakerArray[nDev].nJointDevType == PG_ENERGYCONSUMER)
				{
					pPGBlock->m_BreakerArray[nDev].fP = pPGBlock->m_EnergyConsumerArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fP;
					pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_EnergyConsumerArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQ;
					pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_EnergyConsumerArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fA;
				}
				else if (pPGBlock->m_BreakerArray[nDev].nJointDevType == PG_SHUNTCOMPENSATOR)
				{
					pPGBlock->m_BreakerArray[nDev].fQ = pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fQ;
					pPGBlock->m_BreakerArray[nDev].fA = pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_BreakerArray[nDev].nJointDevIndex].fA;
				}
				else
				{
					nStatusBack = pPGBlock->m_BreakerArray[nDev].nStatus;
					pPGBlock->m_BreakerArray[nDev].nStatus=1;

					fBreakerP = fBreakerQ = 0;
					PGTraverseVolt(pPGBlock, pPGBlock->m_BreakerArray[nDev].nNodeI, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);

					bRinged=0;
					for (i=0; i<nNodeNum; i++)
					{
						if (nNodeArray[i] == pPGBlock->m_BreakerArray[nDev].nNodeJ)
						{
							bRinged=1;
							break;
						}
					}
					if (!bRinged)
					{
						for (nNode=0; nNode<nNodeNum; nNode++)
						{
							for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
							{
								nIndex = pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;

								if (pPGBlock->m_ACLineSegmentArray[nIndex].nNodeI == nNodeArray[nNode])
								{
									fBreakerP += pPGBlock->m_ACLineSegmentArray[nIndex].fPi;
									fBreakerQ += pPGBlock->m_ACLineSegmentArray[nIndex].fQi;
								}
								else
								{
									fBreakerP += pPGBlock->m_ACLineSegmentArray[nIndex].fPz;
									fBreakerQ += pPGBlock->m_ACLineSegmentArray[nIndex].fQz;
								}
							}
							for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; i++)
							{
								nIndex = pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding;

								if (pPGBlock->m_TransformerWindingArray[nIndex].nNodeI == nNodeArray[nNode])
								{
									fBreakerP += pPGBlock->m_TransformerWindingArray[nIndex].fPi;
									fBreakerQ += pPGBlock->m_TransformerWindingArray[nIndex].fQi;
								}
								else
								{
									fBreakerP += pPGBlock->m_TransformerWindingArray[nIndex].fPz;
									fBreakerQ += pPGBlock->m_TransformerWindingArray[nIndex].fQz;
								}
							}
							for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nSeriesCompensatorRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nSeriesCompensatorRange; i++)
							{
								nIndex = pPGBlock->m_EdgeSeriesCompensatorArray[i].nSeriesCompensator;

								if (pPGBlock->m_SeriesCompensatorArray[nIndex].nNodeI == nNodeArray[nNode])
								{
									fBreakerP += pPGBlock->m_SeriesCompensatorArray[nIndex].fPi;
									fBreakerQ += pPGBlock->m_SeriesCompensatorArray[nIndex].fQi;
								}
								else
								{
									fBreakerP += pPGBlock->m_SeriesCompensatorArray[nIndex].fPz;
									fBreakerQ += pPGBlock->m_SeriesCompensatorArray[nIndex].fQz;
								}
							}
							for (i=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; i++)
							{
								if (pPGBlock->m_SynchronousMachineArray[i].nNode == nNodeArray[nNode])
								{
									fBreakerP -= pPGBlock->m_SynchronousMachineArray[i].fP;
									fBreakerQ -= pPGBlock->m_SynchronousMachineArray[i].fQ;
								}
							}
							for (i=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; i++)
							{
								if (pPGBlock->m_EnergyConsumerArray[i].nNode == nNodeArray[nNode])
								{
									fBreakerP += pPGBlock->m_EnergyConsumerArray[i].fP;
									fBreakerQ += pPGBlock->m_EnergyConsumerArray[i].fQ;
								}
							}
							for (i=pPGBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; i++)
							{
								if (pPGBlock->m_ShuntCompensatorArray[i].nNode == nNodeArray[nNode])
								{
									fBreakerQ += pPGBlock->m_ShuntCompensatorArray[i].fQ;
								}
							}
						}

						pPGBlock->m_BreakerArray[nDev].fP = (float)-fBreakerP;
						pPGBlock->m_BreakerArray[nDev].fQ = (float)-fBreakerQ;
					}

					pPGBlock->m_BreakerArray[nDev].nStatus=nStatusBack;
				}
				if (pPGBlock->m_BreakerArray[nDev].fA < FLT_MIN && pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage > FLT_MIN)
					pPGBlock->m_BreakerArray[nDev].fA = (float)(1000*sqrt(pPGBlock->m_BreakerArray[nDev].fP*pPGBlock->m_BreakerArray[nDev].fP+pPGBlock->m_BreakerArray[nDev].fQ*pPGBlock->m_BreakerArray[nDev].fQ)/pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage/1.732);
			}
		}
	}
	PGMemDBStatistic(pPGBlock);

	return 1;
}
