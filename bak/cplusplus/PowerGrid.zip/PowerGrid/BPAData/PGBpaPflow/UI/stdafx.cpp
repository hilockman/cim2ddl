
// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// BpaPflow.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"


#if (!defined(WIN64))
#	pragma comment(lib, "../../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../../lib_x64/PGMemDB.lib")
#endif

#if (!defined(WIN64))
#	pragma comment(lib, "../../../../lib/PG2BpaApi.lib")
#else
#	pragma comment(lib, "../../../../lib_x64/PG2BpaApi.lib")
#endif

#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif
