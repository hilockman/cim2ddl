
// BpaPflowDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGBpaPflowApp.h"
#include "PGBpaPflowDlg.h"

#include "../../../../Common/Excel/ExcelAccessor.h"
#include "../../../../Common/StringCommon.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CBpaPflowDlg �Ի���

static	const	int		m_nIslandColumn=0;
static	const	int		m_nResIdColumn=1;
static	char*	lpszPFIslandColumn[]=
{
	"����", 
	"�ܷ���", 
	"�ܸ���", 
	"�������", 
};

static	char*	lpszPFBusColumn[]=
{
	"���", 
	"ID", 
	"��վ", 
	"��ѹ�ȼ�", 
	"����", 
	"��ѹ(kV)", 
	"����(��)", 
	"����", 
	"����", 
	"����ĸ��", 
};

static	char*	lpszPFLineColumn[]=
{
	"���", 
	"ID", 
	"����", 
	"��ѹ�ȼ�", 
	"��վ", 
	"�ճ�վ", 
	"��ֵ", 
	"���й�", 
	"���޹�", 
	"���й�", 
	"���޹�", 
	"������", 
	"����й�", 
	"����޹�", 
	"������ĸ��", 
	"������ĸ��", 
};

static	char*	lpszPFTranColumn[]=
{
	"���", 
	"ID", 
	"��վ", 
	"����", 
	"��ѹ�ȼ�", 
	"��ѹ�ȼ�", 
	"��ֵ", 
	"���й�", 
	"���޹�", 
	"���й�", 
	"���޹�", 
	"������", 
	"����й�", 
	"����޹�", 
	"������ĸ��", 
	"������ĸ��", 
};

const static	int	IDC_BPAPF_TAB		=10001;
const static	int	IDC_BPAPF_BUS_LIST	=10002;
const static	int	IDC_BPAPF_LINE_LIST	=10003;
const static	int	IDC_BPAPF_TRAN_LIST	=10004;
const static	int	IDC_BPAPF_PFO_LIST	=10005;

static	unsigned char	bFreezeUI = 0;

CBpaPflowDlg::CBpaPflowDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaPflowDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nCurIsland=-1;
}

void CBpaPflowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BPAPF_ISLAND_LIST, m_wndListIsland);
}

BEGIN_MESSAGE_MAP(CBpaPflowDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_BPAWORK_DIR, &CBpaPflowDlg::OnEnChangeBpadataDir)
	ON_EN_CHANGE(IDC_BPAPF_EXEC, &CBpaPflowDlg::OnEnChangeBpapfExec)
	ON_EN_CHANGE(IDC_TOLERANE_BUSV, &CBpaPflowDlg::OnEnChangeToleraneBusv)
	ON_EN_CHANGE(IDC_TOLERANE_Q, &CBpaPflowDlg::OnEnChangeToleraneQ)
	ON_EN_CHANGE(IDC_DECOUPLED_NUM, &CBpaPflowDlg::OnEnChangeDecoupledNum)
	ON_EN_CHANGE(IDC_NEWTON_NUM, &CBpaPflowDlg::OnEnChangeNewtonNum)
	ON_EN_CHANGE(IDC_AUTOPV_GENMVA, &CBpaPflowDlg::OnEnChangeAutopvGenmva)
	ON_NOTIFY(NM_CLICK, IDC_BPAPF_ISLAND_LIST, &CBpaPflowDlg::OnNMClickIslandList)
	ON_BN_CLICKED(IDC_BROWSE_WORKDIR, &CBpaPflowDlg::OnBnClickedBrowseWorkdir)
	ON_BN_CLICKED(IDC_BROWSE_BPAPF, &CBpaPflowDlg::OnBnClickedBrowseBpapf)
	ON_BN_CLICKED(IDC_PFLOW, &CBpaPflowDlg::OnBnClickedPflow)
	ON_BN_CLICKED(IDC_SHOW_DEVICE_INISLAND, &CBpaPflowDlg::OnBnClickedShowDeviceInisland)
	ON_BN_CLICKED(IDC_EXCEL_OUT, &CBpaPflowDlg::OnBnClickedExcelOut)
	ON_BN_CLICKED(IDC_PFLOW_LOADPFO, &CBpaPflowDlg::OnBnClickedPflowLoadpfo)
	ON_BN_CLICKED(IDC_SHOW_OVERLIMIT_DEVICE, &CBpaPflowDlg::OnBnClickedShowOverlimitDevice)
	ON_BN_CLICKED(IDC_DEFAULT, &CBpaPflowDlg::OnBnClickedDefault)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CBpaPflowDlg ��Ϣ��������

BOOL CBpaPflowDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	int		nColumn;
	CRect	rectBuf;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, IDC_BPAPF_TAB, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndListIsland.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListIsland.SetExtendedStyle(m_wndListIsland.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListIsland.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFIslandColumn)/sizeof(char*); nColumn++)
		m_wndListIsland.InsertColumn(nColumn, lpszPFIslandColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_BPAPF_BUS_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBus.SetExtendedStyle(m_wndListBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFBusColumn)/sizeof(char*); nColumn++)
		m_wndListBus.InsertColumn(nColumn,lpszPFBusColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_BPAPF_LINE_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLine.SetExtendedStyle(m_wndListLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFLineColumn)/sizeof(char*); nColumn++)
		m_wndListLine.InsertColumn(nColumn, lpszPFLineColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListWind.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_BPAPF_TRAN_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListWind.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListWind.SetExtendedStyle(m_wndListWind.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListWind.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFTranColumn)/sizeof(char*); nColumn++)
		m_wndListWind.InsertColumn(nColumn, lpszPFTranColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndPfoList.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, IDC_BPAPF_PFO_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndPfoList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	m_wndTab.AddTab (&m_wndListBus, _T("ĸ��"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListLine, _T("������·"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListWind, _T("��ѹ������"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndPfoList, _T("����������Ϣ"),	-1, FALSE);

	GetDlgItem(IDC_BPAWORK_DIR)->SetWindowText(g_szBpaWorkDir);
	GetDlgItem(IDC_BPAPF_EXEC)->SetWindowText(g_szBpaPFExec);

	bFreezeUI = 1;

	char		szBuf[260];
	sprintf(szBuf, "%d", g_nBpaDecoupledNum);		GetDlgItem(IDC_DECOUPLED_NUM)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_nBpaNewtonNum);			GetDlgItem(IDC_NEWTON_NUM)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", g_fBpaToleraneBusv);		GetDlgItem(IDC_TOLERANE_BUSV)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", g_fBpaToleraneQ);			GetDlgItem(IDC_TOLERANE_Q)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", g_fAutoPVMvaThreshold);	GetDlgItem(IDC_AUTOPV_GENMVA)->SetWindowText(szBuf);

	bFreezeUI = 0;

	RefreshIslandList();
	RefreshPFBusList();
	RefreshPFLineList();
	RefreshPFTranList();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CBpaPflowDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CBpaPflowDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void	CBpaPflowDlg::RefreshIslandList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListIsland.DeleteAllItems();

	nRow=0;
	for (i=1; i<g_pPGBlock->m_nRecordNum[PG_ISLAND]; i++)
	{
		if (g_pPGBlock->m_IslandArray[i].bDCIsland)
			continue;
		if (g_pPGBlock->m_IslandArray[i].bDead)
			continue;

		sprintf(szBuf, "%d", i);	m_wndListIsland.InsertItem(nRow, szBuf);

		nCol=1;

		sprintf(szBuf, "%f", g_pPGBlock->m_IslandArray[i].fUnitP);	m_wndListIsland.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_IslandArray[i].fLoadP);	m_wndListIsland.SetItemText(nRow, nCol++, szBuf);

		if (g_pPGBlock->m_IslandArray[i].bPFConvergency)
			m_wndListIsland.SetItemText(nRow, nCol++, _T("��������"));
		else
			m_wndListIsland.SetItemText(nRow, nCol++, _T("���㷢ɢ"));

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFIslandColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListIsland.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListIsland.GetColumnWidth(nCol);
		m_wndListIsland.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListIsland.GetColumnWidth(nCol);

		m_wndListIsland.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CBpaPflowDlg::RefreshPFBusList()
{
	register int	i;
	int		nIsland, nRow, nCol;
	char	szBuf[260];

	CButton*	pButton;

	pButton=(CButton*)GetDlgItem(IDC_SHOW_DEVICE_INISLAND);
	unsigned char	bShowOneIslandOnly=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_SHOW_OVERLIMIT_DEVICE);
	unsigned char	bShowOverlimitOnly=pButton->GetCheck();

	nIsland=-1;
	if (m_nCurIsland >= 0 && m_nCurIsland < m_wndListIsland.GetItemCount())
		nIsland=atoi(m_wndListIsland.GetItemText(m_nCurIsland, m_nIslandColumn));

	m_wndListBus.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (bShowOneIslandOnly)
		{
			if (nIsland >= 0)
			{
				if (g_pPGBlock->m_BusbarSectionArray[i].nIsland != nIsland)
					continue;
			}
		}
		if (bShowOverlimitOnly)
		{
			if (g_pPGBlock->m_BusbarSectionArray[i].fVLimitL <= 0)
				continue;
			if (g_pPGBlock->m_BusbarSectionArray[i].fVLimitH <= 0)
				continue;

			if (g_pPGBlock->m_BusbarSectionArray[i].fVLimitL <= g_pPGBlock->m_BusbarSectionArray[i].fV && g_pPGBlock->m_BusbarSectionArray[i].fV <=g_pPGBlock->m_BusbarSectionArray[i].fVLimitH)
				continue;
		}

		sprintf(szBuf, "%d", i+1);	m_wndListBus.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListBus.SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szResID);
		m_wndListBus.SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szSub);
		m_wndListBus.SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szVolt);
		m_wndListBus.SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szName);

		sprintf(szBuf, "%f", g_pPGBlock->m_BusbarSectionArray[i].fV);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_BusbarSectionArray[i].fD);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_BusbarSectionArray[i].fVLimitL);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_BusbarSectionArray[i].fVLimitH);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "B_%d", g_pPGBlock->m_ConnectivityNodeArray[g_pPGBlock->m_BusbarSectionArray[i].nNode].nTopoBus);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBus.GetColumnWidth(nCol);
		m_wndListBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBus.GetColumnWidth(nCol);

		m_wndListBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CBpaPflowDlg::RefreshPFLineList()
{
	register int	i;
	int		nIsland, nRow, nCol;
	double	fRatio;
	char	szBuf[260];

	CButton*	pButton;
	pButton=(CButton*)GetDlgItem(IDC_SHOW_DEVICE_INISLAND);
	unsigned char	bShowOneIslandOnly=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_SHOW_OVERLIMIT_DEVICE);
	unsigned char	bShowOverlimitOnly=pButton->GetCheck();

	nIsland=-1;
	if (m_nCurIsland >= 0 && m_nCurIsland < m_wndListIsland.GetItemCount())
		nIsland=atoi(m_wndListIsland.GetItemText(m_nCurIsland, m_nIslandColumn));

	m_wndListLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (bShowOneIslandOnly)
		{
			if (nIsland >= 0)
			{
				if (g_pPGBlock->m_ACLineSegmentArray[i].nIsland != nIsland)
					continue;
			}
		}

		if (bShowOverlimitOnly)
		{
			if (g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva <= 0)
				continue;

			if (g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva >= sqrt(g_pPGBlock->m_ACLineSegmentArray[i].fPi*g_pPGBlock->m_ACLineSegmentArray[i].fPi+g_pPGBlock->m_ACLineSegmentArray[i].fQi*g_pPGBlock->m_ACLineSegmentArray[i].fQi))
				continue;
		}

		sprintf(szBuf, "%d", i+1);	m_wndListLine.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szResID);
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szName);
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubJ);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fPi);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fQi);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fPz);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fQz);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		fRatio=0;
		if (g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva > FLT_MIN)
		{
			fRatio=max(
				sqrt(g_pPGBlock->m_ACLineSegmentArray[i].fPi*g_pPGBlock->m_ACLineSegmentArray[i].fPi+g_pPGBlock->m_ACLineSegmentArray[i].fQi*g_pPGBlock->m_ACLineSegmentArray[i].fQi)/g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva, 
				sqrt(g_pPGBlock->m_ACLineSegmentArray[i].fPz*g_pPGBlock->m_ACLineSegmentArray[i].fPz+g_pPGBlock->m_ACLineSegmentArray[i].fQz*g_pPGBlock->m_ACLineSegmentArray[i].fQz)/g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva
				);
		}
		sprintf(szBuf, "%.2f", 100.0*fRatio);		m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fLossP);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fLossQ);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "B_%d", g_pPGBlock->m_ACLineSegmentArray[i].nTopoBusI);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "B_%d", g_pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLine.GetColumnWidth(nCol);
		m_wndListLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLine.GetColumnWidth(nCol);

		m_wndListLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CBpaPflowDlg::RefreshPFTranList()
{
	register int	i;
	int		nIsland, nRow, nCol;
	double	fRatio;
	char	szBuf[260];

	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOW_DEVICE_INISLAND);
	unsigned char	bShowOneIslandOnly=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_SHOW_OVERLIMIT_DEVICE);
	unsigned char	bShowOverlimitOnly=pButton->GetCheck();

	nIsland=-1;
	if (m_nCurIsland >= 0 && m_nCurIsland < m_wndListIsland.GetItemCount())
		nIsland=atoi(m_wndListIsland.GetItemText(m_nCurIsland, m_nIslandColumn));

	m_wndListWind.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (bShowOneIslandOnly)
		{
			if (nIsland >= 0)
			{
				if (g_pPGBlock->m_TransformerWindingArray[i].nIsland != nIsland)
					continue;
			}
		}
		if (bShowOverlimitOnly)
		{
			if (g_pPGBlock->m_TransformerWindingArray[i].fRatedMva <= 0)
				continue;

			if (g_pPGBlock->m_TransformerWindingArray[i].fRatedMva >= sqrt(g_pPGBlock->m_TransformerWindingArray[i].fPi*g_pPGBlock->m_TransformerWindingArray[i].fPi+g_pPGBlock->m_TransformerWindingArray[i].fQi*g_pPGBlock->m_TransformerWindingArray[i].fQi))
				continue;
		}

		sprintf(szBuf, "%d", i+1);	m_wndListWind.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndListWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szResID);
		m_wndListWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szSub);
		m_wndListWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szName);
		m_wndListWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltI);
		m_wndListWind.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltJ);

		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fRatedMva);	m_wndListWind.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fPi);			m_wndListWind.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fQi);			m_wndListWind.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fPz);			m_wndListWind.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fQz);			m_wndListWind.SetItemText(nRow, nCol++, szBuf);

		fRatio=0;
		if (g_pPGBlock->m_TransformerWindingArray[i].fRatedMva > FLT_MIN)
		{
			fRatio=max(
				sqrt(g_pPGBlock->m_TransformerWindingArray[i].fPi*g_pPGBlock->m_TransformerWindingArray[i].fPi+g_pPGBlock->m_TransformerWindingArray[i].fQi*g_pPGBlock->m_TransformerWindingArray[i].fQi)/g_pPGBlock->m_TransformerWindingArray[i].fRatedMva, 
				sqrt(g_pPGBlock->m_TransformerWindingArray[i].fPz*g_pPGBlock->m_TransformerWindingArray[i].fPz+g_pPGBlock->m_TransformerWindingArray[i].fQz*g_pPGBlock->m_TransformerWindingArray[i].fQz)/g_pPGBlock->m_TransformerWindingArray[i].fRatedMva
				);
		}
		sprintf(szBuf, "%.2f", 100*fRatio);		m_wndListWind.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fLossP);		m_wndListWind.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fLossQ);		m_wndListWind.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "B_%d", g_pPGBlock->m_TransformerWindingArray[i].nTopoBusI);	m_wndListWind.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "B_%d", g_pPGBlock->m_TransformerWindingArray[i].nTopoBusJ);	m_wndListWind.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFTranColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListWind.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListWind.GetColumnWidth(nCol);
		m_wndListWind.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListWind.GetColumnWidth(nCol);

		m_wndListWind.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBpaPflowDlg::OnBnClickedBrowseWorkdir()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString		strFolder=g_szBpaWorkDir;
	if (theApp.GetShellManager()->BrowseForFolder(strFolder, this, strFolder))
	{
		strcpy(g_szBpaWorkDir, strFolder);
		GetDlgItem(IDC_BPAWORK_DIR)->SetWindowText(strFolder);
		SaveIni();
	}
}

void CBpaPflowDlg::OnBnClickedBrowseBpapf()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="exe";
	CString	defaultFileName=g_szBpaPFExec;
	CString	fileFilter="ִ�г���(*.exe)|*.exe;*.EXE|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("BPA��������");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	strcpy(g_szBpaPFExec, dlg.GetPathName());
	GetDlgItem(IDC_BPAPF_EXEC)->SetWindowText(g_szBpaPFExec);

	SaveIni();
}

void CBpaPflowDlg::OnEnChangeBpadataDir()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	GetDlgItem(IDC_BPAWORK_DIR)->GetWindowText(g_szBpaWorkDir, 260);
	SaveIni();
}

void CBpaPflowDlg::OnEnChangeBpapfExec()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	GetDlgItem(IDC_BPAPF_EXEC)->GetWindowText(g_szBpaPFExec, 260);
	SaveIni();
}

void CBpaPflowDlg::OnBnClickedPflow()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (_access(g_szBpaPFExec, 0) != 0)
	{
		AfxMessageBox(_T("������������������\n"));
		return;
	}
	if (_access(g_szBpaWorkDir, 0) != 0)
	{
		AfxMessageBox(_T("����Ŀ¼������\n"));
		return;
	}

	PGMemDBTopo(g_pPGBlock);
	PGMemDBIsland(g_pPGBlock);

	CButton*	pButton=(CButton*)GetDlgItem(IDC_PFLOW_MISLAND);
	unsigned char	bMIslandPF=pButton->GetCheck();

	g_PG2BpaApi.m_BpaDatConCard.nDecoupledNum	=g_nBpaDecoupledNum;
	g_PG2BpaApi.m_BpaDatConCard.nNewtonNum		=g_nBpaNewtonNum;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceBusV	=(float)g_fBpaToleraneBusv;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceQ		=(float)g_fBpaToleraneQ;
	g_PG2BpaApi.PG2BpaDatFile(g_pPGBlock, 1.0, 1.0, g_fAutoPVMvaThreshold, bMIslandPF, g_szBpaWorkDir);
	SetCurrentDirectory(g_szBpaWorkDir);

	int		nIsland;
	char	szDatFile[260], szExec[260];
	for (nIsland=1; nIsland<g_pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (g_pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (g_pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		sprintf(szDatFile, "%s\\%s%d.dat", g_szBpaWorkDir, g_PG2BpaApi.m_BpaDatConCard.szProject, nIsland);
		if (_access(szDatFile, 0) != 0)
			continue;

		sprintf(szExec, "%s %s%d.dat", g_szBpaPFExec, g_PG2BpaApi.m_BpaDatConCard.szProject, nIsland);
		system(szExec);
	}

	if (g_PG2BpaApi.PGParsePfoFile(g_pPGBlock, g_szBpaWorkDir) == -2)
	{
	}

	RefreshIslandList();
	RefreshPFBusList();
	RefreshPFLineList();
	RefreshPFTranList();
}

void CBpaPflowDlg::OnBnClickedShowDeviceInisland()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPFBusList();
	RefreshPFLineList();
	RefreshPFTranList();
}

void CBpaPflowDlg::OnNMClickIslandList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (pNMItemActivate->iItem >= 0 && m_nCurIsland != pNMItemActivate->iItem)
	{
		m_nCurIsland=pNMItemActivate->iItem;
		RefreshPFBusList();
		RefreshPFLineList();
		RefreshPFTranList();
	}
	*pResult = 0;
}

void CBpaPflowDlg::OnBnClickedExcelOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_wndListBus.GetItemCount() <= 0 && m_wndListLine.GetItemCount() <= 0 && m_wndListWind.GetItemCount() <= 0)
	{
		AfxMessageBox(_T("���ݱ�Ϊ��"));
		return;
	}

	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;

	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;

	if (m_wndListBus.GetItemCount() > 0)
	{
		xls.AddSheet(_T("ĸ��"));
		xls.SetCurSheet(_T("ĸ��"));

		nFieldNum=sizeof(lpszPFBusColumn)/sizeof(char*);
		//xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(lpszPFBusColumn[nCol]);
		for (nRow=0; nRow<m_wndListBus.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListBus.GetItemText(nRow, nCol));
		}
	}

	if (m_wndListLine.GetItemCount() > 0)
	{
		xls.AddSheet(_T("��·"));
		xls.SetCurSheet(_T("��·"));
		nFieldNum=sizeof(lpszPFLineColumn)/sizeof(char*);

		//xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(lpszPFLineColumn[nCol]);
		for (nRow=0; nRow<m_wndListLine.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListLine.GetItemText(nRow, nCol));
		}
	}

	if (m_wndListWind.GetItemCount() > 0)
	{
		xls.AddSheet(_T("��ѹ��"));
		xls.SetCurSheet(_T("��ѹ��"));
		nFieldNum=sizeof(lpszPFTranColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(lpszPFTranColumn[nCol]);
		for (nRow=0; nRow<m_wndListWind.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListWind.GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(dlg.GetPathName());
}

int CBpaPflowDlg::GetTextLen(const char* lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC *pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(lpszText, (int)strlen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(lpszText, (int)strlen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}


void CBpaPflowDlg::OnBnClickedShowOverlimitDevice()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPFBusList();
	RefreshPFLineList();
	RefreshPFTranList();
}

void CBpaPflowDlg::OnBnClickedPflowLoadpfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		iExt, nIsland=-1;
	char	szPfoFile[260], szLine[1024];
	FILE*	fp;
	if (m_nCurIsland >= 0 && m_nCurIsland < m_wndListIsland.GetItemCount())
		nIsland=atoi(m_wndListIsland.GetItemText(m_nCurIsland, m_nIslandColumn));

	m_wndPfoList.ResetContent();
	for (i=1; i<g_pPGBlock->m_nRecordNum[PG_ISLAND]; i++)
	{
		if (g_pPGBlock->m_IslandArray[i].bDCIsland)
			continue;
		if (g_pPGBlock->m_IslandArray[i].bDead)
			continue;
		if (i != nIsland)
			continue;

		sprintf(szPfoFile, "%s\\%s%d.pfo", g_szBpaWorkDir, g_PG2BpaApi.m_BpaDatConCard.szProject, i);
		if (_access(szPfoFile, 0) != 0)
			continue;

		fp=fopen(szPfoFile, "r");
		if (fp == NULL)
			continue;

		while (!feof(fp))
		{
			memset(szLine, 0, 1024);
			fgets(szLine, 1024, fp);

			TrimEnd(szLine);
			TrimRight(szLine);
			if (strlen(szLine) <= 0)
				continue;

			iExt = GetTextLen(szLine);
			if (iExt > m_wndPfoList.GetHorizontalExtent())
				m_wndPfoList.SetHorizontalExtent(iExt);
			m_wndPfoList.AddString(szLine);

		}
		fclose(fp);
	}
}

void CBpaPflowDlg::OnEnChangeToleraneBusv()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	char	szBuf[260];
	GetDlgItem(IDC_TOLERANE_BUSV)->GetWindowText(szBuf, 260);	g_fBpaToleraneBusv=atof(szBuf);
	SaveIni();
}

void CBpaPflowDlg::OnEnChangeToleraneQ()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	char	szBuf[260];
	GetDlgItem(IDC_TOLERANE_Q)->GetWindowText(szBuf, 260);		g_fBpaToleraneQ=atof(szBuf);

	SaveIni();
}

void CBpaPflowDlg::OnEnChangeDecoupledNum()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	char	szBuf[260];
	GetDlgItem(IDC_DECOUPLED_NUM)->GetWindowText(szBuf, 260);	g_nBpaDecoupledNum=atoi(szBuf);
	SaveIni();
}

void CBpaPflowDlg::OnEnChangeNewtonNum()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	char	szBuf[260];
	GetDlgItem(IDC_NEWTON_NUM)->GetWindowText(szBuf, 260);		g_nBpaNewtonNum=atoi(szBuf);
	SaveIni();
}

void CBpaPflowDlg::OnEnChangeAutopvGenmva()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	if (bFreezeUI)
		return;

	char	szBuf[260];
	GetDlgItem(IDC_AUTOPV_GENMVA)->GetWindowText(szBuf, 260);		g_fAutoPVMvaThreshold=(float)atof(szBuf);
	SaveIni();
}

void CBpaPflowDlg::OnBnClickedDefault()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_nBpaDecoupledNum=10;
	g_nBpaNewtonNum=30;
	g_fBpaToleraneBusv=0.005;
	g_fBpaToleraneQ=0.005;
	SaveIni();

	bFreezeUI = 1;
	char	szBuf[260];
	sprintf(szBuf, "%d", g_nBpaDecoupledNum);	GetDlgItem(IDC_DECOUPLED_NUM)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_nBpaNewtonNum);		GetDlgItem(IDC_NEWTON_NUM)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", g_fBpaToleraneBusv);	GetDlgItem(IDC_TOLERANE_BUSV)->SetWindowText(szBuf);
	sprintf(szBuf, "%f", g_fBpaToleraneQ);		GetDlgItem(IDC_TOLERANE_Q)->SetWindowText(szBuf);
	bFreezeUI = 0;
}
