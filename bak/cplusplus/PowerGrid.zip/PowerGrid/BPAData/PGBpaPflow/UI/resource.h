//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PGBpaPflow.rc
//
#define IDD_BPAPFLOW_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_TAB                         196
#define IDC_REARRANGE_LOAD              305
#define IDC_DEFAULT_RX                  311
#define IDC_EXCEL_OUT                   470
#define IDC_DEFAULT                     514
#define IDC_PFLOW_MISLAND               568
#define IDC_PFLOW                       673
#define IDC_PFLOW_LOADPFO               679
#define IDC_DECOUPLED_NUM               682
#define IDC_SHOW_DEVICE_INISLAND        683
#define IDC_SHOW_OVERLIMIT_DEVICE       684
#define IDC_NEWTON_NUM                  685
#define IDC_TOLERANE_BUSV               687
#define IDC_AUTOPV_GENMVA               688
#define IDC_BPAWORK_DIR                 691
#define IDC_BROWSE_WORKDIR              694
#define IDC_BPAPF_EXEC                  696
#define IDC_TOLERANE_Q                  702
#define IDC_BROWSE_BPAPF                713
#define IDC_BPAPF_ISLAND_LIST           10001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
