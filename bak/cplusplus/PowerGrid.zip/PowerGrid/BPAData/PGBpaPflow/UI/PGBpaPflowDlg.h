
// BpaPflowDlg.h : ͷ�ļ�
//

#pragma once


// CBpaPflowDlg �Ի���
class CBpaPflowDlg : public CDialog
{
// ����
public:
	CBpaPflowDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_BPAPFLOW_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedBrowseWorkdir();
	afx_msg void OnBnClickedBrowseBpapf();
	afx_msg void OnEnChangeBpadataDir();
	afx_msg void OnEnChangeBpapfExec();
	afx_msg void OnBnClickedPflow();
	afx_msg void OnBnClickedShowDeviceInisland();
	afx_msg void OnNMClickIslandList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedExcelOut();
	afx_msg void OnBnClickedPflowLoadpfo();
	afx_msg void OnBnClickedShowOverlimitDevice();
	afx_msg void OnEnChangeToleraneBusv();
	afx_msg void OnEnChangeToleraneQ();
	afx_msg void OnEnChangeDecoupledNum();
	afx_msg void OnEnChangeNewtonNum();
	afx_msg void OnBnClickedDefault();
	afx_msg void OnEnChangeAutopvGenmva();
	DECLARE_MESSAGE_MAP()
private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndListIsland;
	CMFCListCtrl	m_wndListBus, m_wndListLine, m_wndListWind;
	CListBox		m_wndPfoList;
private:
	void	RefreshIslandList();
	void	RefreshPFBusList();
	void	RefreshPFLineList();
	void	RefreshPFTranList();
	int		GetTextLen(const char* lpszText);
private:
	int		m_nCurIsland;
};
