#include <process.h>

#include <io.h>
#define	_USE_MATH_DEFINES
#include <math.h>
#include <float.h>

#include "../../../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../../lib_x64/PGMemDB.lib")
#endif
using	namespace	PGMemDB;

#include "../../../../PowerGrid/BPAData/PG2BpaApi/PG2BpaApi.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../../lib/PG2BpaApi.lib")
#else
#	pragma comment(lib, "../../../../lib_x64/PG2BpaApi.lib")
#endif

#include "../../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif

#ifndef	_MAIN_
#	define _MAIN_
#endif
#undef	_MAIN_

// Ψһ��Ӧ�ó������
const	char*	g_lpszLogFile="PGBpaPflowModule.log";
extern	void	ClearLog(const char* lpszLogFile);
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

CPG2BpaFileApi	g_PG2BpaApi;
tagPGBlock*		g_pPGBlock;

char		g_szRunDir[260];
char		g_szResultFile[260];
short		g_nBpaDecoupledNum;
short		g_nBpaNewtonNum;
double		g_fBpaToleraneBusv;
double		g_fBpaToleraneQ;
float		g_fAutoPVMvaThreshold;

void	SaveBusResult(tagPGBlock* pPGBlock, TiXmlElement* pParent);
void	SaveLineResult(tagPGBlock* pPGBlock, TiXmlElement* pParent);
void	SaveTranResult(tagPGBlock* pPGBlock, TiXmlElement* pParent);
void PrintMessage(const char* pformat, ...);

int main(int argc, char** argv, char** envp)
{
	clock_t	dBeg, dEnd;
	int		nDur;
	unsigned char	bMIslandPF = 1;
	char		szBpaWorkDir[260];
	char		szBpaPFExec[260];

	g_nBpaDecoupledNum = 20;
	g_nBpaNewtonNum = 20;
	g_fBpaToleraneBusv = 0.005;
	g_fAutoPVMvaThreshold = 0.005;
	g_fAutoPVMvaThreshold = 300;

	int	nEle=1;
	if (argc > nEle)	strcpy(g_szRunDir, argv[nEle++]);			else	return 0;
	if (argc > nEle)	strcpy(g_szResultFile, argv[nEle++]);		else	return 0;
	if (argc > nEle)	g_nBpaDecoupledNum = atoi(argv[nEle++]);	//else	return 0;
	if (argc > nEle)	g_nBpaNewtonNum = atoi(argv[nEle++]);		//else	return 0;
	if (argc > nEle)	g_fBpaToleraneBusv = atof(argv[nEle++]);	//else	return 0;
	if (argc > nEle)	g_fBpaToleraneQ = atof(argv[nEle++]);		//else	return 0;
	if (argc > nEle)	g_fAutoPVMvaThreshold = atof(argv[nEle++]);	//else	return 0;

	GetTempPath(260, szBpaWorkDir);
	sprintf(szBpaPFExec, "%s/pfnt.exe", g_szRunDir);
	if (access(szBpaPFExec, 0) != 0)
	{
		PrintMessage(("����������򲻴���"));
		return FALSE;
	}

	ClearLog(g_lpszLogFile);

	dBeg=clock();

	g_pPGBlock=(tagPGBlock*)Init_PGBlock();
	if (!g_pPGBlock)
	{
		PrintMessage("��ȡPG�ڴ�����");
		return FALSE;
	}

	if (_access(szBpaPFExec, 0) != 0)
	{
		PrintMessage(("������������������"));
		return FALSE;
	}
	if (_access(szBpaWorkDir, 0) != 0)
	{
		PrintMessage(("����Ŀ¼������"));
		return FALSE;
	}

	PGMemDBTopo(g_pPGBlock);
	PGMemDBIsland(g_pPGBlock);

	g_PG2BpaApi.m_BpaDatConCard.nDecoupledNum	=g_nBpaDecoupledNum;
	g_PG2BpaApi.m_BpaDatConCard.nNewtonNum		=g_nBpaNewtonNum;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceBusV	=(float)g_fBpaToleraneBusv;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceQ		=(float)g_fBpaToleraneQ;
	g_PG2BpaApi.PG2BpaDatFile(g_pPGBlock, 1.0, 1.0, g_fAutoPVMvaThreshold, bMIslandPF, szBpaWorkDir);
	SetCurrentDirectory(szBpaWorkDir);

	int		nIsland;
	char	szDatFile[260], szExec[260];
	for (nIsland=1; nIsland<g_pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (g_pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (g_pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		sprintf(szDatFile, "%s\\%s%d.dat", szBpaWorkDir, g_PG2BpaApi.m_BpaDatConCard.szProject, nIsland);
		if (_access(szDatFile, 0) != 0)
			continue;

		sprintf(szExec, "%s %s%d.dat", szBpaPFExec, g_PG2BpaApi.m_BpaDatConCard.szProject, nIsland);
		system(szExec);
	}

	if (g_PG2BpaApi.PGParsePfoFile(g_pPGBlock, szBpaWorkDir) == -2)
	{
	}


	TiXmlElement		*pElement;
	TiXmlDocument*		pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����
	TiXmlDeclaration*	pDeclare = new TiXmlDeclaration("1.0", "gb2312", "no");
	pDocument->LinkEndChild(pDeclare);

	TiXmlElement*	pRoot=new TiXmlElement("PGBpaPflowResult");
	pDocument->LinkEndChild(pRoot);

	pElement = new TiXmlElement("System");
	pRoot->LinkEndChild(pElement);

	pElement->SetAttribute("DecoupledNum",				g_nBpaDecoupledNum);
	pElement->SetAttribute("NewtonNum",					g_nBpaNewtonNum);
	pElement->SetDoubleAttribute("ToleraneBusv",		g_fBpaToleraneBusv);
	pElement->SetDoubleAttribute("ToleraneQ",			g_fBpaToleraneQ);
	pElement->SetDoubleAttribute("AutoPVMvaThreshold",	g_fAutoPVMvaThreshold);

	pElement->SetDoubleAttribute(PGGetFieldName(PG_SYSTEM, PG_SYSTEM_TOTALGENP),	g_pPGBlock->m_System.fTotalGenP);
	pElement->SetDoubleAttribute(PGGetFieldName(PG_SYSTEM, PG_SYSTEM_TOTALGENQ),	g_pPGBlock->m_System.fTotalGenQ);
	pElement->SetDoubleAttribute(PGGetFieldName(PG_SYSTEM, PG_SYSTEM_TOTALLOADP),	g_pPGBlock->m_System.fTotalLoadP);
	pElement->SetDoubleAttribute(PGGetFieldName(PG_SYSTEM, PG_SYSTEM_TOTALLOADQ),	g_pPGBlock->m_System.fTotalLoadQ);
	pElement->SetDoubleAttribute(PGGetFieldName(PG_SYSTEM, PG_SYSTEM_LOSSP),		g_pPGBlock->m_System.fLossP);
	pElement->SetDoubleAttribute(PGGetFieldName(PG_SYSTEM, PG_SYSTEM_LOSSQ),		g_pPGBlock->m_System.fLossQ);
	pElement->SetAttribute("IslandNum",		g_pPGBlock->m_nRecordNum[PG_ISLAND]);

	SaveBusResult (g_pPGBlock, pRoot);
	SaveLineResult(g_pPGBlock, pRoot);
	SaveTranResult(g_pPGBlock, pRoot);

	pDocument->SaveFile(g_szResultFile);
	pDocument->Clear();
	delete pDocument;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("������ɣ���ʱ %d ����", nDur);
}

void PrintMessage(const char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szMesg[1024];

	vsprintf(szMesg, pformat, args);
	vfprintf(stdout, pformat, args);
	fprintf(stdout, "\n");

	Log(g_lpszLogFile, szMesg);

	va_end(args);
}

void	SaveBusResult(tagPGBlock* pPGBlock, TiXmlElement* pParent)
{
	register int	i;
	TiXmlElement	*pElement;

	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		pElement = new TiXmlElement(PGGetTableName(PG_BUSBARSECTION));
		pParent->LinkEndChild(pElement);

		pElement->SetAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_RESOURCEID), g_pPGBlock->m_BusbarSectionArray[i].szResID);
		pElement->SetAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_SUBSTATION), g_pPGBlock->m_BusbarSectionArray[i].szSub);
		pElement->SetAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_VOLTAGELEVEL), g_pPGBlock->m_BusbarSectionArray[i].szVolt);
		pElement->SetAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_NAME), g_pPGBlock->m_BusbarSectionArray[i].szName);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_V), g_pPGBlock->m_BusbarSectionArray[i].fV);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_D), g_pPGBlock->m_BusbarSectionArray[i].fD);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_VLIMITL), g_pPGBlock->m_BusbarSectionArray[i].fVLimitL);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_VLIMITH), g_pPGBlock->m_BusbarSectionArray[i].fVLimitH);

		pElement->SetAttribute("TopoBus", g_pPGBlock->m_ConnectivityNodeArray[g_pPGBlock->m_BusbarSectionArray[i].nNode].nTopoBus);
		pElement->SetAttribute(PGGetFieldName(PG_BUSBARSECTION, PG_BUSBARSECTION_ISLAND), g_pPGBlock->m_BusbarSectionArray[i].nIsland);
	}
}

void	SaveLineResult(tagPGBlock* pPGBlock, TiXmlElement* pParent)
{
	register int	i;
	TiXmlElement	*pElement;
	double			fRatio;

	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		pElement = new TiXmlElement(PGGetTableName(PG_ACLINESEGMENT));
		pParent->LinkEndChild(pElement);

		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_RESOURCEID), g_pPGBlock->m_ACLineSegmentArray[i].szResID);
		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_NAME), g_pPGBlock->m_ACLineSegmentArray[i].szName);
		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_IVOLTAGELEVEL), g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_ISUBSTATION), g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_JSUBSTATION), g_pPGBlock->m_ACLineSegmentArray[i].szSubJ);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_RATEMVA), g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_RATECUR), g_pPGBlock->m_ACLineSegmentArray[i].fRatedCur);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_PI), g_pPGBlock->m_ACLineSegmentArray[i].fPi);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_QI), g_pPGBlock->m_ACLineSegmentArray[i].fQi);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_PJ), g_pPGBlock->m_ACLineSegmentArray[i].fPz);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_QJ), g_pPGBlock->m_ACLineSegmentArray[i].fQz);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_A), g_pPGBlock->m_ACLineSegmentArray[i].fA);

		fRatio=0;
		if (g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva > FLT_MIN)
		{
			fRatio=max(
				sqrt(g_pPGBlock->m_ACLineSegmentArray[i].fPi*g_pPGBlock->m_ACLineSegmentArray[i].fPi+g_pPGBlock->m_ACLineSegmentArray[i].fQi*g_pPGBlock->m_ACLineSegmentArray[i].fQi)/g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva, 
				sqrt(g_pPGBlock->m_ACLineSegmentArray[i].fPz*g_pPGBlock->m_ACLineSegmentArray[i].fPz+g_pPGBlock->m_ACLineSegmentArray[i].fQz*g_pPGBlock->m_ACLineSegmentArray[i].fQz)/g_pPGBlock->m_ACLineSegmentArray[i].fRatedMva);
		}
		pElement->SetDoubleAttribute("MVARatio", 100.0*fRatio);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_LOSSP), g_pPGBlock->m_ACLineSegmentArray[i].fLossP);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_LOSSQ), g_pPGBlock->m_ACLineSegmentArray[i].fLossQ);

		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_ISLAND), g_pPGBlock->m_ACLineSegmentArray[i].nIsland);
		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_TOPOBUSI), g_pPGBlock->m_ACLineSegmentArray[i].nTopoBusI);
		pElement->SetAttribute(PGGetFieldName(PG_ACLINESEGMENT, PG_ACLINESEGMENT_TOPOBUSJ), g_pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ);
	}
}

void	SaveTranResult(tagPGBlock* pPGBlock, TiXmlElement* pParent)
{
	register int	i;
	TiXmlElement	*pElement;
	double			fRatio;

	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		pElement = new TiXmlElement(PGGetTableName(PG_TRANSFORMERWINDING));
		pParent->LinkEndChild(pElement);

		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_RESOURCEID), g_pPGBlock->m_TransformerWindingArray[i].szResID);
		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_SUBSTATION), g_pPGBlock->m_TransformerWindingArray[i].szSub);
		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_NAME), g_pPGBlock->m_TransformerWindingArray[i].szName);
		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_VOLTAGELEVELI), g_pPGBlock->m_TransformerWindingArray[i].szVoltI);
		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_VOLTAGELEVELJ), g_pPGBlock->m_TransformerWindingArray[i].szVoltJ);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_RATEMVA), g_pPGBlock->m_TransformerWindingArray[i].fRatedMva);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_PI), g_pPGBlock->m_TransformerWindingArray[i].fPi);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_QI), g_pPGBlock->m_TransformerWindingArray[i].fQi);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_AI), g_pPGBlock->m_TransformerWindingArray[i].fAi);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_PZ), g_pPGBlock->m_TransformerWindingArray[i].fPz);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_QZ), g_pPGBlock->m_TransformerWindingArray[i].fQz);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_AZ), g_pPGBlock->m_TransformerWindingArray[i].fAz);

		fRatio=0;
		if (g_pPGBlock->m_TransformerWindingArray[i].fRatedMva > FLT_MIN)
		{
			fRatio=max(
				sqrt(g_pPGBlock->m_TransformerWindingArray[i].fPi*g_pPGBlock->m_TransformerWindingArray[i].fPi+g_pPGBlock->m_TransformerWindingArray[i].fQi*g_pPGBlock->m_TransformerWindingArray[i].fQi)/g_pPGBlock->m_TransformerWindingArray[i].fRatedMva, 
				sqrt(g_pPGBlock->m_TransformerWindingArray[i].fPz*g_pPGBlock->m_TransformerWindingArray[i].fPz+g_pPGBlock->m_TransformerWindingArray[i].fQz*g_pPGBlock->m_TransformerWindingArray[i].fQz)/g_pPGBlock->m_TransformerWindingArray[i].fRatedMva);
		}
		pElement->SetDoubleAttribute("MVARatio", 100*fRatio);

		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_LOSSP), g_pPGBlock->m_TransformerWindingArray[i].fLossP);
		pElement->SetDoubleAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_LOSSQ), g_pPGBlock->m_TransformerWindingArray[i].fLossQ);

		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_ISLAND), g_pPGBlock->m_TransformerWindingArray[i].nIsland);
		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_TOPOBUSI), g_pPGBlock->m_TransformerWindingArray[i].nTopoBusI);
		pElement->SetAttribute(PGGetFieldName(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_TOPOBUSJ), g_pPGBlock->m_TransformerWindingArray[i].nTopoBusJ);
	}
}
