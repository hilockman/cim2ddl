#include "stdAfx.h"
#include "BPAData.h"
#include "../../../Common/StringCommon.h"

static	char*	lpszLogFileName="BpaFile2BpaMdb.log";
void CBPAData::ClearLog()
{
	char	szTempPath[260], szFileName[260];

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/%s", szTempPath, lpszLogFileName);
	FILE*	fp=fopen(szFileName, "w");
	if (fp != NULL)
	{
		fflush(fp);
		fclose(fp);
	}
	//unlink(szFileName);
}

void CBPAData::Log(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szTempPath[260], szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/%s", szTempPath, lpszLogFileName);
	fp=fopen(szFileName, "a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}

void CBPAData::CheckDecimal(char szFloat[], const int nFloat)
{
	register int	i;
	int		nChar;
	char	szBuf[MDB_CHARLEN_SHORTER];

	if (strstr(szFloat, ".") != NULL || nFloat == 0)
		return;

	nChar=0;
	memset(szBuf, 0, MDB_CHARLEN_SHORTER);
	for (i=0; i<(int)strlen(szFloat); i++)
	{
		if (i == strlen(szFloat)-nFloat)
		{
			szBuf[nChar++]='.';
		}
		szBuf[nChar++]=szFloat[i];
	}
	szBuf[nChar]='\0';

	strcpy(szFloat, szBuf);
}
