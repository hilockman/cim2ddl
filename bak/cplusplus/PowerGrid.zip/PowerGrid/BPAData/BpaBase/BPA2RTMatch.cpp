#include "StdAfx.h"
#include "BPA2RTMatch.h"

CBPA2RTMatch::CBPA2RTMatch(void)
{
}

CBPA2RTMatch::~CBPA2RTMatch(void)
{
}


static	char*	lpszLogFileName="BpaMatch.log";
void CBPA2RTMatch::ClearLog()
{
	char	szTempPath[260], szFileName[260];

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/%s", szTempPath, lpszLogFileName);
	FILE*	fp=fopen(szFileName, "w");
	if (fp != NULL)
	{
		fflush(fp);
		fclose(fp);
	}
	//unlink(szFileName);
}

void CBPA2RTMatch::Log(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szTempPath[260], szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/%s", szTempPath, lpszLogFileName);
	fp=fopen(szFileName, "a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}

int CBPA2RTMatch::IsCimDeviceMatched(tagBpaBlock* pBpaBlock, const int nBpaTable, const char* lpszPGDev)
{
	register int	i;
	switch (nBpaTable)
	{
	case BPA_DAT_SUB:
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_SubArray[i].szAlias, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case BPA_DAT_ACBUS:
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[i].szAlias, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case BPA_DAT_ACLINE:
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[i].szAlias, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case BPA_DAT_WIND:
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_WindArray[i].szAlias, lpszPGDev) == 0)	
				return 1;
		}
		break;
	}

	return 0;
}

void CBPA2RTMatch::CheckBpa2CimMatch(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock)
{
	register int	i;
	int		nBpa, nFind, nSub, nVolt, nDev;
	int		nSubI, nSubJ;
	char	szBuf[260];

	std::vector<unsigned char>	bLineProc;
	bLineProc.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE], 0);

	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_SubArray[nBpa].szAlias) <= 0)
		{
			for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
			{
				if (strcmp(pBpaBlock->m_BpaDat_SubArray[nBpa].szName, pBpaBlock->m_BpaDat_ACBusArray[i].szBpaSub) == 0)
				{
					memset(pBpaBlock->m_BpaDat_ACBusArray[i].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
				}
			}
			continue;
		}
		nFind=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_SubArray[nBpa].szAlias, pPGBlock->m_SubstationArray[i].szName) == 0)
			{
				nFind=i;
				break;
			}
		}
		if (nFind < 0)	//	ȷ��BPA��վ������PG��վ��PG���ݿ��д���
		{
			memset(pBpaBlock->m_BpaDat_SubArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_SUB, BPA_DAT_SUB_ALIAS));
			for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
			{
				if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[i].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nBpa].szName) == 0)
				{
					memset(pBpaBlock->m_BpaDat_ACBusArray[i].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
				}
			}
		}
	}

	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias) <= 0)
			continue;

		nFind=-1;
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szBpaSub, pBpaBlock->m_BpaDat_SubArray[i].szName) == 0)
			{
				nFind=i;
				break;
			}
		}
		if (nFind < 0)	//	һ�㲻����ָ��������ֹ���⡣ȷ��BPAĸ������BPA��վ��BPA���ݿ��д���
		{
			memset(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
			continue;
		}

		nSub=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strcmp(pPGBlock->m_SubstationArray[i].szName, pBpaBlock->m_BpaDat_SubArray[nFind].szAlias) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub < 0)	//	ȷ��BPAĸ������PG��վ��PG���ݿ��д��ڣ���������ڳ�վ������Ѿ����ϣ���������Ǳ�������³��
		{
			memset(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
			continue;
		}

		//	ȷ��ĸ����PG��վ�ڴ���
		nFind=-1;
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				sprintf(szBuf, "%s, %s, %s", pPGBlock->m_BusbarSectionArray[nDev].szSub, pPGBlock->m_BusbarSectionArray[nDev].szVolt, pPGBlock->m_BusbarSectionArray[nDev].szName);
				if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, szBuf) == 0)
				{
					nFind=nDev;
					break;
				}
			}
			if (nFind >= 0)
				break;
		}
		if (nFind < 0)
		{
			for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
				{
					sprintf(szBuf, "%s, %s, %s", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szVolt, pPGBlock->m_SynchronousMachineArray[nDev].szName);
					if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, szBuf) == 0)
					{
						nFind=nDev;
						break;
					}
				}
				if (nFind >= 0)
					break;
			}
		}
		if (nFind < 0)
			memset(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
	}
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias) <= 0)
			continue;
		if (pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus < 0 || pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus < 0)
		{
			memset(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACLINE, BPA_DAT_ACLINE_ALIAS));
			continue;
		}

		nFind=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias, pPGBlock->m_ACLineSegmentArray[i].szName) == 0)
			{
				nFind=i;
				break;
			}
		}
		if (nFind < 0)	//	ȷ��BPA��·��PG���ݿ��д���
		{
			memset(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACLINE, BPA_DAT_ACLINE_ALIAS));
			continue;
		}

		nSubI=nSubJ=-1;
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_SubArray[i].szName, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szBpaSub) == 0)
			{
				nSubI=i;
				break;
			}
		}
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_SubArray[i].szName, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szBpaSub) == 0)
			{
				nSubJ=i;
				break;
			}
		}
		if (nSubI < 0 || nSubJ < 0)
		{
			memset(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACLINE, BPA_DAT_ACLINE_ALIAS));
			continue;
		}

		if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nFind].szSubI) == 0 && strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nFind].szSubJ) == 0 ||
			strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nFind].szSubJ) == 0 && strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nFind].szSubI) == 0)
		{

		}
		else
		{
			memset(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACLINE, BPA_DAT_ACLINE_ALIAS));
			continue;
		}
	}
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias) <= 0)
			continue;
		if (pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus < 0 || pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus < 0)
		{
			memset(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_WIND, BPA_DAT_WIND_ALIAS));
			continue;
		}

		nSub=-1;
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szBpaSub, pBpaBlock->m_BpaDat_SubArray[i].szName) == 0)
			{
				nSub=i;
				break;
			}
		}
		if (nSub < 0)	//	ȷ��BPAĸ������BPA��վ��BPA���ݿ��д���
		{
			memset(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
			continue;
		}

		nFind=-1;
		for (nDev=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nDev<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nDev++)
		{
			sprintf(szBuf, "%s, %s", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);
			if (strcmp(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, szBuf) == 0)
			{
				nFind=i;
				break;
			}
		}
		if (nFind < 0)
		{
			memset(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, 0, BpaGetFieldLen(BPA_DAT_WIND, BPA_DAT_WIND_ALIAS));
			continue;
		}
	}
}


void CBPA2RTMatch::ReadBpa2CimMatch(tagBpaBlock* pBpaBlock, const char* lpszFileName)
{
	register int	i;
	int		nData;
	char	szBuf[260];

	tagBpaMatchCim	dBuf;

	m_Bpa2PGArray.clear();

	FILE*	fp;
	fp=fopen(lpszFileName, "r");
	if (fp == NULL)
		return;

	char*	lpszToken;
	char	szLine[1024];
	std::vector<std::string>	strEleArray;
	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);

		if (strlen(szLine) <= 0)
			continue;

		strEleArray.clear();

		lpszToken=strtok(szLine, " \t\n");
		while (lpszToken != NULL)
		{
			strEleArray.push_back(lpszToken);
			lpszToken=strtok(NULL, " \t\n");
		}
		if (strEleArray.size() == 3)
		{
			strcpy(dBuf.szBpaDev, strEleArray[0].c_str());
			strcpy(dBuf.szBpaKey, strEleArray[1].c_str());
			strcpy(dBuf.szCimKey, strEleArray[2].c_str());

			dBuf.nDevType=(short)BpaGetTableIndex(dBuf.szBpaDev);
			if (dBuf.nDevType == BPA_DAT_SUB || 
				dBuf.nDevType == BPA_DAT_ACBUS ||
				dBuf.nDevType == BPA_DAT_ACLINE ||
				dBuf.nDevType == BPA_DAT_WIND)
				m_Bpa2PGArray.push_back(dBuf);
		}
	}

	fclose(fp);

	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
		memset(pBpaBlock->m_BpaDat_SubArray[i].szAlias, 0, BpaGetFieldLen(BPA_DAT_SUB, BPA_DAT_SUB_ALIAS));
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		memset(pBpaBlock->m_BpaDat_ACBusArray[i].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACBUS, BPA_DAT_ACBUS_ALIAS));
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
		memset(pBpaBlock->m_BpaDat_ACLineArray[i].szAlias, 0, BpaGetFieldLen(BPA_DAT_ACLINE, BPA_DAT_ACLINE_ALIAS));
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
		memset(pBpaBlock->m_BpaDat_WindArray[i].szAlias, 0, BpaGetFieldLen(BPA_DAT_WIND, BPA_DAT_WIND_ALIAS));
	//InitBpa2CimMatch(pBpaBlock);

	for (nData=0; nData<(int)m_Bpa2PGArray.size(); nData++)
	{
		switch (m_Bpa2PGArray[nData].nDevType)
		{
		case BPA_DAT_SUB:
			for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
			{
				if (strcmp(pBpaBlock->m_BpaDat_SubArray[i].szName, m_Bpa2PGArray[nData].szBpaKey) == 0)
				{
					strcpy(pBpaBlock->m_BpaDat_SubArray[i].szAlias, m_Bpa2PGArray[nData].szCimKey);
					break;
				}
			}
			break;
		case	BPA_DAT_ACBUS:
			for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
			{
				sprintf(szBuf, "%s.%.2f", pBpaBlock->m_BpaDat_ACBusArray[i].szName, pBpaBlock->m_BpaDat_ACBusArray[i].fkV);
				if (strcmp(szBuf, m_Bpa2PGArray[nData].szBpaKey) == 0)
				{
					strcpy(pBpaBlock->m_BpaDat_ACBusArray[i].szAlias, m_Bpa2PGArray[nData].szCimKey);
					break;
				}
			}
			break;
		case	BPA_DAT_ACLINE:
			for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
			{
				if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[i].szKeyName, m_Bpa2PGArray[nData].szBpaKey) == 0)
				{
					strcpy(pBpaBlock->m_BpaDat_ACLineArray[i].szAlias, m_Bpa2PGArray[nData].szCimKey);
					break;
				}
			}
			break;
		case	BPA_DAT_WIND:
			for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
			{
				if (strcmp(pBpaBlock->m_BpaDat_WindArray[i].szKeyName, m_Bpa2PGArray[nData].szBpaKey) == 0)
				{
					strcpy(pBpaBlock->m_BpaDat_WindArray[i].szAlias, m_Bpa2PGArray[nData].szCimKey);
					break;
				}
			}
			break;
		}
	}
}

void CBPA2RTMatch::SaveBpa2CimMatch(tagBpaBlock* pBpaBlock, const char* lpszFileName)
{
	register int	i;
	tagBpaMatchCim	dBuf;

	m_Bpa2PGArray.clear();

	memset(&dBuf, 0, sizeof(tagBpaMatchCim));
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
	{
		if (strlen(pBpaBlock->m_BpaDat_SubArray[i].szAlias) > 0)
		{
			dBuf.nDevType=BPA_DAT_SUB;
			BpaGetTableName(BPA_DAT_SUB, dBuf.szBpaDev);
			strcpy(dBuf.szBpaKey, pBpaBlock->m_BpaDat_SubArray[i].szName);
			strcpy(dBuf.szCimKey, pBpaBlock->m_BpaDat_SubArray[i].szAlias);

			m_Bpa2PGArray.push_back(dBuf);
		}
	}
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACBusArray[i].szAlias) > 0)
		{
			dBuf.nDevType=BPA_DAT_ACBUS;
			BpaGetTableName(BPA_DAT_ACBUS, dBuf.szBpaDev);
			sprintf(dBuf.szBpaKey, "%s.%.2f", pBpaBlock->m_BpaDat_ACBusArray[i].szName, pBpaBlock->m_BpaDat_ACBusArray[i].fkV);
			strcpy(dBuf.szCimKey, pBpaBlock->m_BpaDat_ACBusArray[i].szAlias);

			m_Bpa2PGArray.push_back(dBuf);
		}
	}
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACLineArray[i].szAlias) > 0)
		{
			dBuf.nDevType=BPA_DAT_ACLINE;
			BpaGetTableName(BPA_DAT_ACLINE, dBuf.szBpaDev);
			strcpy(dBuf.szBpaKey, pBpaBlock->m_BpaDat_ACLineArray[i].szKeyName);
			strcpy(dBuf.szCimKey, pBpaBlock->m_BpaDat_ACLineArray[i].szAlias);

			m_Bpa2PGArray.push_back(dBuf);
		}
	}
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; i++)
	{
		if (strlen(pBpaBlock->m_BpaDat_WindArray[i].szAlias) > 0)
		{
			dBuf.nDevType=BPA_DAT_WIND;
			BpaGetTableName(BPA_DAT_WIND, dBuf.szBpaDev);
			strcpy(dBuf.szBpaKey, pBpaBlock->m_BpaDat_WindArray[i].szKeyName);
			strcpy(dBuf.szCimKey, pBpaBlock->m_BpaDat_WindArray[i].szAlias);

			m_Bpa2PGArray.push_back(dBuf);
		}
	}

	FILE*	fp;
	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	for (i=0; i<(int)m_Bpa2PGArray.size(); i++)
		fprintf(fp, "%s %s %s\n", m_Bpa2PGArray[i].szBpaDev, m_Bpa2PGArray[i].szBpaKey, m_Bpa2PGArray[i].szCimKey);

	fflush(fp);
	fclose(fp);
}

void CBPA2RTMatch::AutoBpa2CimMatch(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock)
{
	register int	i;
	int		nData, nBpa, nFind;
	int		nSub, nVolt, nBpaSub, nSubI, nSubJ, nVoltI, nVoltJ;
	unsigned char	bBusSetted;
	int		nNodeNum, nNodeArray[1000];
	char	szBuf[MDB_CHARLEN_LONG];

	CheckBpa2CimMatch(pBpaBlock, pPGBlock);

	std::vector<unsigned char>	bProcArray;
	std::vector<unsigned char>	bBusProcArray;

	bBusProcArray.resize(pPGBlock->m_nRecordNum[PG_BUSBARSECTION]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nData++)
		bBusProcArray[nData]=0;

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nData++)
		bProcArray[nData]=0;
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias) > 0)
			continue;

		nBpaSub=-1;
		for (nData=0; nData<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nData++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nData].szName) == 0)
			{
				nBpaSub=nData;
				break;
			}
		}
		if (nBpaSub < 0)
			continue;

		nFind=-1;
		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_SubArray[nBpaSub].szAlias, pPGBlock->m_SubstationArray[nSub].szName) != 0)
				continue;

			for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				if (pBpaBlock->m_BpaDat_ACBusArray[nBpa].bGenerator != 0 && pBpaBlock->m_BpaDat_ACBusArray[nBpa].bDCBound == 0)
				{
					for (nData=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nData<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nData++)
					{
						if (bProcArray[nData])
							continue;

						sprintf(szBuf, "%s, %s, %s", pPGBlock->m_SynchronousMachineArray[nData].szSub, pPGBlock->m_SynchronousMachineArray[nData].szVolt, pPGBlock->m_SynchronousMachineArray[nData].szName);
						strcpy(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, szBuf);
						nFind=nData;
						bProcArray[nData]=1;
						break;
					}
				}
				if (nFind >= 0)
					break;
			}
			if (nFind >= 0)
				break;
		}
	}

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nData++)
		bProcArray[nData]=0;

	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias) > 0)
			continue;
		if (pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus < 0 || pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus < 0)
			continue;

		nSubI=nSubJ=-1;
		for (nData=0; nData<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nData++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nData].szName) == 0)
			{
				nSubI=nData;
				break;
			}
		}
		for (nData=0; nData<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nData++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nData].szName) == 0)
			{
				nSubJ=nData;
				break;
			}
		}
		if (nSubI < 0 || nSubJ < 0)
			continue;

		for (nData=0; nData<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nData++)
		{
			if (bProcArray[nData])
				continue;
			if ((strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0 && strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubJ) == 0) ||
				(strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubJ) == 0 && strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0))
			{
				strcpy(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szName);
				bProcArray[nData]=1;

				bBusSetted=0;
				if (!bBusSetted)
				{
					PGTraverseVolt(pPGBlock, pPGBlock->m_ACLineSegmentArray[nData].nNodeI, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
					for (i=0; i<nNodeNum; i++)
					{
 						if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
						{
							if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szAlias, szBuf);
								Log("    ��·ͬ��[%s]����BPA I��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].fkV, szBuf);
							}
							else if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szAlias, szBuf);
								Log("    ��·����[%s]����BPA J��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].fkV, szBuf);
							}
							break;
						}
					}
				}

				if (!bBusSetted)
				{
					PGTraverseVolt(pPGBlock, pPGBlock->m_ACLineSegmentArray[nData].nNodeI, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
					for (i=0; i<nNodeNum; i++)
					{
						if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
						{
							if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szAlias, szBuf);
								Log("    ��·ͬ��[%s]����BPA I��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].fkV, szBuf);
							}
							else if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szAlias, szBuf);
								Log("    ��·����[%s]����BPA J��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].fkV, szBuf);
							}
							break;
						}
					}
				}

				bBusSetted=0;
				if (!bBusSetted)
				{
					PGTraverseVolt(pPGBlock, pPGBlock->m_ACLineSegmentArray[nData].nNodeJ, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
					for (i=0; i<nNodeNum; i++)
					{
						if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
						{
							if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubJ) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szAlias, szBuf);

								Log("    ��·����[%s]����BPA I��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].fkV, szBuf);
							}
							else if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubJ) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szAlias, szBuf);
								Log("    ��·ͬ��[%s]����BPA J��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].fkV, szBuf);
							}
							break;
						}
					}
				}
				if (!bBusSetted)
				{
					PGTraverseVolt(pPGBlock, pPGBlock->m_ACLineSegmentArray[nData].nNodeJ, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
					for (i=0; i<nNodeNum; i++)
					{
						if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
						{
							if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubJ) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szAlias, szBuf);
								Log("    ��·����[%s]����BPA I��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nIBus].fkV, szBuf);
							}
							else if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubJ].szAlias, pPGBlock->m_ACLineSegmentArray[nData].szSubJ) == 0)
							{
								bBusSetted=1;
								bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
								sprintf(szBuf, "%s, %s, %s", 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
									pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
								strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szAlias, szBuf);
								Log("    ��·ͬ��[%s]����BPA J��ĸ��[%s %.2f] = %s\n", pBpaBlock->m_BpaDat_ACLineArray[nBpa].szKeyName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].szName, 
									pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nBpa].nZBus].fkV, szBuf);
							}
							break;
						}
					}
				}
				break;
			}
		}
	}

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nData++)
		bProcArray[nData]=0;

	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias) > 0)
			continue;
		if (pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus < 0)
			continue;

		nBpaSub=-1;
		for (nData=0; nData<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nData++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nData].szName) == 0)
			{
				nBpaSub=nData;
				break;
			}
		}
		if (nBpaSub < 0)
			continue;

		nFind=-1;
		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_SubArray[nBpaSub].szAlias, pPGBlock->m_SubstationArray[nSub].szName) != 0)
				continue;

			for (nData=pPGBlock->m_SubstationArray[nSub].nTransformerWindingRange; nData<pPGBlock->m_SubstationArray[nSub+1].nTransformerWindingRange; nData++)
			{
				if (bProcArray[nData])
					continue;

				nVoltI=pPGBlock->m_TransformerWindingArray[nData].nVoltI;
				nVoltJ=pPGBlock->m_TransformerWindingArray[nData].nVoltJ;
				if (pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].bTMid)
				{
					if (fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ/10 ||
						fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ/10)
					{
						sprintf(szBuf, "%s, %s", pPGBlock->m_TransformerWindingArray[nData].szSub, pPGBlock->m_TransformerWindingArray[nData].szName);
						strcpy(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, szBuf);
						nFind=nData;
						bProcArray[nData]=1;
						if (pPGBlock->m_TransformerWindingArray[nData].bTranMidSide != 1)
						{
							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
						}
						if (pPGBlock->m_TransformerWindingArray[nData].bTranMidSide != 2)
						{
							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
						}
						break;
					}
				}
				else if (pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].bTMid)
				{
					if (fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI/10 ||
						fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI/10)
					{
						sprintf(szBuf, "%s, %s", pPGBlock->m_TransformerWindingArray[nData].szSub, pPGBlock->m_TransformerWindingArray[nData].szName);
						strcpy(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, szBuf);

						nFind=nData;
						bProcArray[nData]=1;
						if (pPGBlock->m_TransformerWindingArray[nData].bTranMidSide != 1)
						{
							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}
						}
						if (pPGBlock->m_TransformerWindingArray[nData].bTranMidSide != 2)
						{
							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}
						}
						break;
					}
				}
				else
				{
					if (fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI/10 && fabs(pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ/10 ||
						fabs(pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI/10 && fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ/10)
					{
						sprintf(szBuf, "%s, %s", pPGBlock->m_TransformerWindingArray[nData].szSub, pPGBlock->m_TransformerWindingArray[nData].szName);
						strcpy(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, szBuf);

						nFind=nData;
						bProcArray[nData]=1;

						if (fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVI/10 && fabs(pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage-pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ) < pBpaBlock->m_BpaDat_WindArray[nBpa].fkVJ/10)
						{
							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ��ͬ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ��ͬ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}

							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ����������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ����������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
						}
						else
						{
							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ����������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeJ, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szAlias, szBuf);

										Log("��ѹ����������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].fkV, szBuf);
										break;
									}
								}
							}

							bBusSetted=0;
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, Y_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ��ͬ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
							if (!bBusSetted)
							{
								PGTraverseVolt(pPGBlock, pPGBlock->m_TransformerWindingArray[nData].nNodeI, N_CheckStatus, N_CheckStatus, Y_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
								for (i=0; i<nNodeNum; i++)
								{
									if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr >= 0 && !bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr])
									{
										bBusSetted=1;
										bBusProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr]=1;
										sprintf(szBuf, "%s, %s, %s", 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szSub, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szVolt, 
											pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[i]].nBusbarSectionPtr].szName);
										strcpy(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szAlias, szBuf);

										Log("��ѹ��ͬ������BPAĸ��[%s %.2f] = %s\n", 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].szName, 
											pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].fkV, szBuf);
										break;
									}
								}
							}
						}
						break;
					}
				}
			}
			if (nFind >= 0)
				break;
		}
	}

	// 	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	// 	{
	// 		if (strlen(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szPGBusbarSection) > 0)
	// 			continue;
	// 
	// 		nSubI=-1;
	// 		for (nData=0; nData<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nData++)
	// 		{
	// 			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szSub, pBpaBlock->m_BpaDat_SubArray[nData].szName) == 0)
	// 			{
	// 				nSubI=nData;
	// 				break;
	// 			}
	// 		}
	// 		if (nSubI < 0)
	// 			continue;
	// 
	// 		nFind=-1;
	// 		for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	// 		{
	// 			if (strcmp(pBpaBlock->m_BpaDat_SubArray[nSubI].szPGSub, pPGBlock->m_SubstationArray[nSub].szName) != 0)
	// 				continue;
	// 
	// 			for (nVolt=pPGBlock->m_SubstationArray[nSub].pRkv; nVolt<pPGBlock->m_SubstationArray[nSub+1].pRkv; nVolt++)
	// 			{
	// 				if (fabs(pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage-pBpaBlock->m_BpaDat_ACBusArray[nBpa].fkV) > pBpaBlock->m_BpaDat_ACBusArray[nBpa].fkV/10)
	// 					continue;
	// 
	// 				if (pBpaBlock->m_BpaDat_ACBusArray[nBpa].bGen)
	// 				{
	// 				}
	// 				else
	// 				{
	// 					for (nData=pPGBlock->m_VoltageLevelArray[nVolt].pRbus; nData<pPGBlock->m_VoltageLevelArray[nVolt+1].pRbus; nData++)
	// 					{
	// 						if (bBusProcArray[nData])
	// 							continue;
	// 
	// 						bBusProcArray[nData]=1;
	// 						sprintf(szBuf, "%s, %s, %s", pPGBlock->m_BusbarSectionArray[nData].szSub, pPGBlock->m_BusbarSectionArray[nData].szVolt, pPGBlock->m_BusbarSectionArray[nData].szName);
	// 						strcpy(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szPGBusbarSection, szBuf);
	// 						nFind=nData;
	// 						break;
	// 					}
	// 				}
	// 				if (nFind >= 0)
	// 					break;
	// 			}
	// 			if (nFind >= 0)
	// 				break;
	// 		}
	// 	}
}

void CBPA2RTMatch::CheckPGBusLineMatched(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock)
{
	register int	i;
	int		nSub, nVolt, nDev, nNode;
	int		nNodeNum, nNodeArray[1000];
	unsigned char	bHasMatchedLine;

	std::vector<unsigned char> bProcArray;

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_BUSBARSECTION]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		bProcArray[i]=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				if (pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
					continue;
				if (bProcArray[nDev])
					continue;

				bHasMatchedLine=0;
				PGTraverseVolt(pPGBlock, pPGBlock->m_BusbarSectionArray[nDev].nNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
					{
						if (IsCimDeviceMatched(pBpaBlock, BPA_DAT_ACLINE, pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment].szName))
						{
							bHasMatchedLine=1;
							break;
						}
					}
				}

				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr >= 0)
					{
						bProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr]=1;
						if (bHasMatchedLine)
						{
							pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr].fLoadP=pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBusbarSectionPtr].fLoadQ=0;
						}
					}
				}
			}
		}
	}
}
