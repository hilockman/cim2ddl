#include "stdAfx.h"
#include "BPAData.h"
#include "../../../Common/StringCommon.h"

void KeySplit(const char* lpszKey, char* lpszBusName, char* lpszBuskV)
{
	register int	i;
	int		nChar=0, nField=0;
	char	szChar[100];
	for (i=0; i<(int)strlen(lpszKey); i++)
	{
		if (lpszKey[i] == '\\')
		{
			szChar[nChar++]='\0';
			if (nField == 0)
				strcpy(lpszBusName, szChar);
			else if (nField > 0)
				strcpy(lpszBuskV, szChar);

			nChar=0;
			nField++;
		}
		else
		{
			szChar[nChar++]=lpszKey[i];
		}
	}
	if (nChar > 0)
	{
		szChar[nChar++]='\0';
		if (nField == 0)
			strcpy(lpszBusName, szChar);
		else if (nField > 0)
			strcpy(lpszBuskV, szChar);
	}
}

//	BPA���д洢�ؼ��֣����������ͺͿ��ؼ��֣�
//		����ͨ�����ı��п����ͺͿ��ؼ��������ݿ���ȷ����¼�ţ�
//		�����ݿ��з��ϸÿ����ͺ͹ؼ��ֵļ�¼ȡ����
//		���ֵ������Ϣ��������Ϣ���и�ֵ��
void CBPAData::Mdb2BpaDat(tagBpaBlock* pBpaBlock, const char* lpszFileName, const int bOutStatus)
{
	register int	i;
	int		nLine, nDict;
	int		nField, nRecord;
	int		nStart, nEnd, nDataLen, nDecimal;
	char	szRecArray[g_nConstMaxRestrict][MDB_CHARLEN_LONG];
	char	szValue[MDB_CHARLEN_LONG];
	char	szBuf[MDB_CHARLEN_LONG];
	char	szLine[261];
	double	fDeviate;

	for (i=0; i<g_nConstMaxRestrict; i++)
		memset(szRecArray[i], 0, MDB_CHARLEN_LONG);
	for (nLine=0; nLine<(int)m_BpaDatLineArray.size(); nLine++)
	{
		if (m_BpaDatLineArray[nLine].strCard.empty())
			continue;
		if (m_BpaDatLineArray[nLine].nMemDBTable < 0)
			continue;

		if (BpaGetTableRestrictNum(m_BpaDatLineArray[nLine].nMemDBTable) <= 0)
			continue;

		nDict=BpaGetTableDictIndex(m_BpaDatLineArray[nLine].strCard.c_str(), -1);
		if (nDict < 0)
			continue;

		for (i=0; i<(int)m_BpaDatLineArray[nLine].strLine.length(); i++)
			szLine[i]=m_BpaDatLineArray[nLine].strLine[i];
		szLine[i]='\0';

		for (i=0; i<BpaGetTableRestrictNum(m_BpaDatLineArray[nLine].nMemDBTable); i++)
			strcpy(szRecArray[i], m_BpaDatLineArray[nLine].strKey[i].c_str());
		nRecord=BpaFindRecordbyKey(pBpaBlock, m_BpaDatLineArray[nLine].nMemDBTable, szRecArray);
		if (nRecord < 0)
			continue;

		for (nField=0; nField<BpaGetTableFieldNum(m_BpaDatLineArray[nLine].nMemDBTable); nField++)
		{
			BpaGetFieldName(m_BpaDatLineArray[nLine].nMemDBTable, nField, szBuf);
			int	nDictField=BpaGetFieldDictIndex(nDict, szBuf);
			if (nDictField < 0)
				continue;
			if (!BpaGetDictModified(nDictField))
				continue;

			nStart=		BpaGetDictFieldStart(nDictField);
			nEnd=		BpaGetDictFieldEnd(nDictField);
			nDataLen=	BpaGetDictFieldLen(nDictField);
			if (nStart <= 0 || nDataLen <= 0)
				continue;

			memset(szValue, 0, MDB_CHARLEN_LONG);
			BpaGetRecordValue(pBpaBlock, m_BpaDatLineArray[nLine].nMemDBTable, nField, nRecord, szValue);
			switch (BpaGetFieldType(m_BpaDatLineArray[nLine].nMemDBTable, nField))
			{
			case MDB_FLOAT:
				nDecimal=BpaGetDictFieldDecimal(nDictField);
				ExtractBpaField(nStart, nEnd, szLine, szBuf);
				if (strlen(szBuf) > 0)
					CheckDecimal(szBuf, nDecimal);

				fDeviate=1.0;
				for (i=0; i<nDecimal; i++)
					fDeviate /= 10.0;
				fDeviate /= 10.0;

				if (fabs(atof(szBuf) - atof(szValue)) > fDeviate)
				{
					for (i=0; i<nDataLen; i++)
						szLine[i+nStart-1]=' ';

					if (fabs(atof(szValue)) > 0.00000001)
					{
						FormularBpaDecimalChar(szValue, nDataLen);
						for (i=0; i<nDataLen; i++)
						{
							if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
								break;
							szLine[i+nStart-1]=szValue[i];
						}
					}
				}
				break;
			case MDB_STRING:
				ExtractBpaField(nStart, nEnd, szLine, szBuf);
				if (strcmp(szValue, szBuf) != 0)
				{
					for (i=0; i<nDataLen; i++)
						szLine[i+nStart-1]=' ';
					for (i=0; i<nDataLen; i++)
					{
						if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
							break;
						szLine[i+nStart-1]=szValue[i];
					}
				}
				break;
			case MDB_INT:
			case MDB_BIT:
			case MDB_SHORT:
				ExtractBpaField(nStart, nEnd, szLine, szBuf);
				if (abs(atoi(szValue)-atoi(szBuf)) > 0)
				{
					for (i=0; i<nDataLen; i++)
						szLine[i+nStart-1]=' ';
					for (i=0; i<nDataLen; i++)
					{
						if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
							break;
						szLine[i+nStart-1]=szValue[i];
					}
				}
				break;
			case MDB_CHAR:
				if (szValue[0] != ' ' && szValue[0] != '\t' && szValue[0] != '\n' && szValue[0] != '\r' && szValue[0] != '\0')
					szLine[nStart-1]=szValue[0];
				break;
			}
		}

		TrimRight(szLine);
		m_BpaDatLineArray[nLine].strLine=szLine;

		if (bOutStatus)
		{
			switch (m_BpaDatLineArray[nLine].nMemDBTable)
			{
			case BPA_DAT_ACBUS:
				BpaGetRecordValue(pBpaBlock, m_BpaDatLineArray[nLine].nMemDBTable, BPA_DAT_ACBUS_STATUS, nRecord, szValue);
				if (atoi(szValue) != 0)
				{
					m_BpaDatLineArray[nLine].strLine.insert(0, ".");
				}
				break;
			case BPA_DAT_ACLINE:
				BpaGetRecordValue(pBpaBlock, m_BpaDatLineArray[nLine].nMemDBTable, BPA_DAT_ACLINE_STATUS, nRecord, szValue);
				if (atoi(szValue) != 0)
				{
					m_BpaDatLineArray[nLine].strLine.insert(0, ".");
				}
				break;
			case BPA_DAT_WIND:
				BpaGetRecordValue(pBpaBlock, m_BpaDatLineArray[nLine].nMemDBTable, BPA_DAT_WIND_STATUS, nRecord, szValue);
				if (atoi(szValue) != 0)
				{
					m_BpaDatLineArray[nLine].strLine.insert(0, ".");
				}
				break;
			default:
				break;
			}
		}
	}

	FILE*	fp;
	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	for (i=0; i<(int)m_BpaDatLineArray.size(); i++)
		fprintf(fp, "%s\n", m_BpaDatLineArray[i].strLine.c_str());
	fflush(fp);
	fclose(fp);
}

void CBPAData::MdbAppendTagedLine(tagBpaBlock* pBpaBlock, const int nTable, int& nEndGenLine)
{
	register int	i;
	int		nData, nField;
	char	szValue[MDB_CHARLEN_LONG], szCardKey[MDB_CHARLEN_SHORTER], szLine[261];;
	char	szRest[g_nConstMaxRestrict][MDB_CHARLEN_LONG];
	tagBpaLine	lBuf;

	InitializeBpaLine(lBuf);
	nField=BpaGetFieldIndex(nTable, "AppendTag");
	if (nField >= 0)
	{
		for (nData=0; nData<pBpaBlock->m_nRecordNum[nTable]; nData++)
		{
			BpaGetRecordValue(pBpaBlock, nTable, nField, nData, szValue);
			if (atoi(szValue) == 0)
				continue;

			int nComb=-1;
			BpaGetRecordValue(pBpaBlock, nTable, BpaGetFieldIndex(nTable, "CardKey"), nData, szCardKey);
			for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
			{
				if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
				{
					nComb=i;
					break;
				}
			}

			for (i=0; i<BpaGetTableRestrictNum(nTable); i++)
			{
				memset(szRest[i], 0, MDB_CHARLEN_LONG);
				BpaGetRecordValue(pBpaBlock, nTable, BpaGetTableRestrictField(nTable, i), nData, szRest[i]);
			}

			if (nComb < 0)
			{
				lBuf.strLine.clear();
				lBuf.strCard=szCardKey;
				lBuf.bCategory=BpaSwiCategory_Dat;
				for (i=0; i<BpaGetTableRestrictNum(nTable); i++)
					lBuf.strKey[i]=szRest[i];
				lBuf.nDictIndex=(short)BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
				lBuf.nMemDBTable=nTable;

				for (i=0; i<260; i++)
					szLine[i]=' ';
				szLine[i]='\0';
				WriteLine(pBpaBlock, nTable, nData, lBuf.nDictIndex, szLine);
				lBuf.strLine=szLine;

				m_BpaSwiLineArray.insert(m_BpaSwiLineArray.begin()+(++nEndGenLine), lBuf);
			}
			else
			{
				if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
				{
					lBuf.strLine.clear();
					lBuf.strCard=g_BpaCardCombArray[nComb].szMainCard;
					lBuf.bCategory=BpaSwiCategory_Dat;
					for (i=0; i<BpaGetTableRestrictNum(nTable); i++)
						lBuf.strKey[i]=szRest[i];
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
					lBuf.nMemDBTable=nTable;

					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					if (CheckLine(pBpaBlock, nTable, nData, lBuf.nDictIndex) > 0)
					{
						WriteLine(pBpaBlock, nTable, nData, lBuf.nDictIndex, szLine);
						lBuf.strLine=szLine;
						m_BpaSwiLineArray.insert(m_BpaSwiLineArray.begin()+(++nEndGenLine), lBuf);
					}
				}
				if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
				{
					lBuf.strLine.clear();
					lBuf.strCard=g_BpaCardCombArray[nComb].szExCard;
					lBuf.bCategory=BpaSwiCategory_Dat;
					for (i=0; i<BpaGetTableRestrictNum(nTable); i++)
						lBuf.strKey[i]=szRest[i];
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
					lBuf.nMemDBTable=nTable;

					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					if (CheckLine(pBpaBlock, nTable, nData, lBuf.nDictIndex) > 0)
					{
						WriteLine(pBpaBlock, nTable, nData, lBuf.nDictIndex, szLine);
						lBuf.strLine=szLine;
						m_BpaSwiLineArray.insert(m_BpaSwiLineArray.begin()+(++nEndGenLine), lBuf);
					}
				}
				if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
				{
					lBuf.strLine.clear();
					lBuf.strCard=g_BpaCardCombArray[nComb].szAugCard;
					lBuf.bCategory=BpaSwiCategory_Dat;
					for (i=0; i<BpaGetTableRestrictNum(nTable); i++)
						lBuf.strKey[i]=szRest[i];
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
					lBuf.nMemDBTable=nTable;

					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';

					if (CheckLine(pBpaBlock, nTable, nData, lBuf.nDictIndex) > 0)
					{
						WriteLine(pBpaBlock, nTable, nData, lBuf.nDictIndex, szLine);
						lBuf.strLine=szLine;
						m_BpaSwiLineArray.insert(m_BpaSwiLineArray.begin()+(++nEndGenLine), lBuf);
					}
				}
			}
		}
	}
}

void CBPAData::MdbAppendGenerator(tagBpaBlock* pBpaBlock, const unsigned char bModGen, const unsigned char bModExc, const unsigned char bModPss, const unsigned char bModGov)
{
	register int	i;
	int		nFind, nTable, nField, nData, nLine;
	tagBpaLine	lBuf;
	char	szValue[MDB_CHARLEN_LONG];
	char	szRest[g_nConstMaxRestrict][MDB_CHARLEN_LONG];

	clock_t	dBeg, dEnd;
	int		nDur;

	dBeg=clock();

	strcpy(szValue, "1");
	nTable=BPA_SWI_GEN;
	nField=BpaGetFieldIndex(nTable, "AppendTag");
	if (nField >= 0)
	{
		for (nData=0; nData<pBpaBlock->m_nRecordNum[nTable]; nData++)
			BpaSetRecordValue(pBpaBlock, nTable, nField, nData, szValue);
	}

	for (nTable=0; nTable<sizeof(g_nBpaExcTables)/sizeof(int); nTable++)
	{
		nField=BpaGetFieldIndex(g_nBpaExcTables[nTable], "AppendTag");
		if (nField >= 0)
		{
			for (nData=0; nData<pBpaBlock->m_nRecordNum[g_nBpaExcTables[nTable]]; nData++)
				BpaSetRecordValue(pBpaBlock, g_nBpaExcTables[nTable], nField, nData, szValue);
		}
	}

	for (nTable=0; nTable<sizeof(g_nBpaPssTables)/sizeof(int); nTable++)
	{
		nField=BpaGetFieldIndex(g_nBpaPssTables[nTable], "AppendTag");
		if (nField >= 0)
		{
			for (nData=0; nData<pBpaBlock->m_nRecordNum[g_nBpaPssTables[nTable]]; nData++)
				BpaSetRecordValue(pBpaBlock, g_nBpaPssTables[nTable], nField, nData, szValue);
		}
	}

	for (nTable=0; nTable<sizeof(g_nBpaGovTables)/sizeof(int); nTable++)
	{
		nField=BpaGetFieldIndex(g_nBpaGovTables[nTable], "AppendTag");
		if (nField >= 0)
		{
			for (nData=0; nData<pBpaBlock->m_nRecordNum[g_nBpaGovTables[nTable]]; nData++)
				BpaSetRecordValue(pBpaBlock, g_nBpaGovTables[nTable], nField, nData, szValue);
		}
	}

	nTable=BPA_SWI_GA;
	nField=BpaGetFieldIndex(nTable, "AppendTag");
	if (nField >= 0)
	{
		for (nData=0; nData<pBpaBlock->m_nRecordNum[nTable]; nData++)
			BpaSetRecordValue(pBpaBlock, nTable, nField, nData, szValue);
	}

	for (nTable=0; nTable<sizeof(g_nBpaMovTables)/sizeof(int); nTable++)
	{
		nField=BpaGetFieldIndex(g_nBpaMovTables[nTable], "AppendTag");
		if (nField >= 0)
		{
			for (nData=0; nData<pBpaBlock->m_nRecordNum[g_nBpaMovTables[nTable]]; nData++)
				BpaSetRecordValue(pBpaBlock, g_nBpaMovTables[nTable], nField, nData, szValue);
		}
	}

	int		nStartGenLine=-1;
	int		nEndGenLine=-1;
	strcpy(szValue, "0");
	for (nLine=0; nLine<(int)m_BpaSwiLineArray.size(); nLine++)
	{
		nTable=BpaGetGeneratorTableByCardKey(m_BpaSwiLineArray[nLine].strCard.c_str());
		if (nTable < 0)
			continue;
		nField=BpaGetFieldIndex(nTable, "AppendTag");
		if (nField >= 0)
		{
			for (i=0; i<g_nConstMaxRestrict; i++)
			{
				memset(szRest[i], 0, MDB_CHARLEN_LONG);
				if (m_BpaSwiLineArray[nLine].strKey[i].empty())
					continue;

				strcpy(szRest[i], m_BpaSwiLineArray[nLine].strKey[i].c_str());
			}
			nFind=BpaFindRecordbyKey(pBpaBlock, nTable, szRest);
			if (nFind >= 0)
				BpaSetRecordValue(pBpaBlock, nTable, nField, nFind, szValue);

		}
		if (m_BpaSwiLineArray[nLine].nSection == g_nBpaSwiSectionGen)
		{
			nEndGenLine=nLine;
			if (nStartGenLine < 0)
				nStartGenLine=nLine;
		}
	}
	if (nStartGenLine < 0)
		return;
	if (nEndGenLine < 0)
		return;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("BPA�ļ�������ϣ���ʱ%d����\n", nDur);

	InitializeBpaLine(lBuf);
	lBuf.strLine.clear();
	lBuf.strLine.append(".�����������Ƭ");
	m_BpaSwiLineArray.insert(m_BpaSwiLineArray.begin()+(++nEndGenLine), lBuf);

	if (bModGen)
	{
		nTable=BPA_SWI_GEN;
		MdbAppendTagedLine(pBpaBlock, nTable, nEndGenLine);
	}

	if (bModExc)
	{
		for (nTable=0; nTable<sizeof(g_nBpaExcTables)/sizeof(int); nTable++)
		{
			MdbAppendTagedLine(pBpaBlock, g_nBpaExcTables[nTable], nEndGenLine);
		}
	}

	if (bModPss)
	{
		for (nTable=0; nTable<sizeof(g_nBpaPssTables)/sizeof(int); nTable++)
		{
			MdbAppendTagedLine(pBpaBlock, g_nBpaPssTables[nTable], nEndGenLine);
		}
	}

	if (bModGov)
	{
		for (nTable=0; nTable<sizeof(g_nBpaGovTables)/sizeof(int); nTable++)
		{
			MdbAppendTagedLine(pBpaBlock, g_nBpaGovTables[nTable], nEndGenLine);
		}

		nTable=BPA_SWI_GA;
		MdbAppendTagedLine(pBpaBlock, nTable, nEndGenLine);

		for (nTable=0; nTable<sizeof(g_nBpaMovTables)/sizeof(int); nTable++)
		{
			MdbAppendTagedLine(pBpaBlock, g_nBpaMovTables[nTable], nEndGenLine);
		}
	}
}

int CBPAData::CheckLine(tagBpaBlock* pBpaBlock, const int nTable, const int nRecord, const int nDict)
{
	register int	i;
	int		nField;
	char	szLine[261], szValue[MDB_CHARLEN_LONG], szBuf[260];
	int		nStart, nEnd, nDataLen, nDecimal;

	for (i=0; i<260; i++)
		szLine[i]=' ';
	szLine[i]='\0';
	for (nField=0; nField<BpaGetTableFieldNum(nTable); nField++)
	{
		BpaGetFieldName(nTable, nField, szBuf);
		int	nDictField=BpaGetFieldDictIndex(nDict, szBuf);
		if (nDictField < 0)
			continue;
		if (!BpaGetDictModified(nDictField))
			continue;

		nStart=		BpaGetDictFieldStart(nDictField);
		nEnd=		BpaGetDictFieldEnd(nDictField);
		nDataLen=	BpaGetDictFieldLen(nDictField);
		if (nStart <= 0 || nDataLen <= 0)
			continue;

		memset(szValue, 0, MDB_CHARLEN_LONG);
		BpaGetRecordValue(pBpaBlock, nTable, nField, nRecord, szValue);
		switch (BpaGetFieldType(nTable, nField))
		{
		case MDB_FLOAT:
			nDecimal=BpaGetDictFieldDecimal(nDictField);
			for (i=0; i<nDataLen; i++)
				szLine[i+nStart-1]=' ';
			if (fabs(atof(szValue)) > 0.00000001)
			{
				FormularBpaDecimalChar(szValue, nDataLen);
				for (i=0; i<nDataLen; i++)
				{
					if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
						break;
					szLine[i+nStart-1]=szValue[i];
				}
			}
			break;
		case MDB_STRING:
			ExtractBpaField(nStart, nEnd, szLine, szBuf);
			if (strcmp(szValue, szBuf) != 0)
			{
				for (i=0; i<nDataLen; i++)
					szLine[i+nStart-1]=' ';
				for (i=0; i<nDataLen; i++)
				{
					if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
						break;
					szLine[i+nStart-1]=szValue[i];
				}
			}
			break;
		case MDB_INT:
		case MDB_BIT:
		case MDB_SHORT:
			ExtractBpaField(nStart, nEnd, szLine, szBuf);
			if (abs(atoi(szValue)-atoi(szBuf)) > 0)
			{
				for (i=0; i<nDataLen; i++)
					szLine[i+nStart-1]=' ';
				for (i=0; i<nDataLen; i++)
				{
					if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
						break;
					szLine[i+nStart-1]=szValue[i];
				}
			}
			break;
		case MDB_CHAR:
			if (szValue[0] != ' ' && szValue[0] != '\t' && szValue[0] != '\n' && szValue[0] != '\r' && szValue[0] != '\0')
				szLine[nStart-1]=szValue[0];
			break;
		}
	}

	TrimLeft(szLine);
	TrimRight(szLine);

	return (int)strlen(szLine);
}

void CBPAData::BpaDictKey2CardKey(char* lpszKey)
{
	if (stricmp(lpszKey, "FX+") == 0)
	{
		strcpy(lpszKey, "F+");
	}
	else if (stricmp(lpszKey, "SH1") == 0 || stricmp(lpszKey, "SH2") == 0)
	{
		strcpy(lpszKey, "SH");
	}
	else if (stricmp(lpszKey, "SH1+") == 0 || stricmp(lpszKey, "SH2+") == 0)
	{
		strcpy(lpszKey, "SH+");
	}
}

int CBPAData::WriteLine(tagBpaBlock* pBpaBlock, const int nTable, const int nRecord, const int nDict, char* lpszLine)
{
	register int	i;
	int		nField;
	char	szValue[MDB_CHARLEN_LONG], szBuf[260];
	int		nStart, nEnd, nDataLen, nDecimal;

	for (nField=0; nField<BpaGetTableFieldNum(nTable); nField++)
	{
		BpaGetFieldName(nTable, nField, szBuf);
		int	nDictField=BpaGetFieldDictIndex(nDict, szBuf);
		if (nDictField < 0)
			continue;
// 		if (!BpaGetDictModified(nDictField))
// 			continue;

		nStart=		BpaGetDictFieldStart(nDictField);
		nEnd=		BpaGetDictFieldEnd(nDictField);
		nDataLen=	BpaGetDictFieldLen(nDictField);
		if (nStart <= 0 || nDataLen <= 0)
			continue;

		memset(szValue, 0, MDB_CHARLEN_LONG);
		BpaGetRecordValue(pBpaBlock, nTable, nField, nRecord, szValue);

		if (stricmp(szBuf, "CardKey") == 0)
		{
			strcpy(szValue, BpaGetDictCardKey(nDictField));
			BpaDictKey2CardKey(szValue);
		}

		switch (BpaGetFieldType(nTable, nField))
		{
		case MDB_FLOAT:
			nDecimal=BpaGetDictFieldDecimal(nDictField);
			for (i=0; i<nDataLen; i++)
				lpszLine[i+nStart-1]=' ';
			if (fabs(atof(szValue)) > 0.00000001)
			{
				FormularBpaDecimalChar(szValue, nDataLen);
				for (i=0; i<nDataLen; i++)
				{
					if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
						break;
					lpszLine[i+nStart-1]=szValue[i];
				}
			}
			break;
		case MDB_STRING:
			ExtractBpaField(nStart, nEnd, lpszLine, szBuf);
			if (strcmp(szValue, szBuf) != 0)
			{
				for (i=0; i<nDataLen; i++)
					lpszLine[i+nStart-1]=' ';
				for (i=0; i<nDataLen; i++)
				{
					if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
						break;
					lpszLine[i+nStart-1]=szValue[i];
				}
			}
			break;
		case MDB_INT:
		case MDB_BIT:
		case MDB_SHORT:
			ExtractBpaField(nStart, nEnd, lpszLine, szBuf);
			if (abs(atoi(szValue)-atoi(szBuf)) > 0)
			{
				for (i=0; i<nDataLen; i++)
					lpszLine[i+nStart-1]=' ';
				for (i=0; i<nDataLen; i++)
				{
					if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
						break;
					lpszLine[i+nStart-1]=szValue[i];
				}
			}
			break;
		case MDB_CHAR:
			if (szValue[0] != ' ' && szValue[0] != '\t' && szValue[0] != '\n' && szValue[0] != '\r' && szValue[0] != '\0')
				lpszLine[nStart-1]=szValue[0];
			break;
		}
	}

	TrimLeft(lpszLine);
	TrimRight(lpszLine);

	return (int)strlen(lpszLine);
}

void CBPAData::Mdb2BpaSwiCard(tagBpaBlock* pBpaBlock, const char* lpszFileName, std::vector<std::string>& strKeyArray)
{
	register int	i;
	int		nKey, nRecord, nComb, nDict, nTable;
	char	szLine[261], szCardKey[MDB_CHARLEN_LONG], szRest[g_nConstMaxRestrict][MDB_CHARLEN_LONG];
	tagBpaLine	lBuf;
	FILE*	fp;

	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	for (nKey=0; nKey<g_nConstMaxRestrict; nKey++)
		memset(szRest[nKey], 0, MDB_CHARLEN_LONG);

	for (nKey=0; nKey<(int)strKeyArray.size(); nKey++)
	{
		KeySplit(strKeyArray[nKey].c_str(), szRest[0], szRest[1]);
		fprintf(fp, ". ����� %s %s\n", szRest[0], szRest[1]);

		nTable=BPA_SWI_GEN;
		nRecord=BpaFindRecordbyKey(pBpaBlock, nTable, szRest);
		if (nRecord >= 0)
		{
			nComb=-1;
			BpaGetRecordValue(pBpaBlock, nTable, BpaGetFieldIndex(nTable, "CardKey"), nRecord, szCardKey);
			for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
			{
				if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
				{
					nComb=i;
					break;
				}
			}

			if (nComb < 0)
			{
				nDict=BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
				for (i=0; i<260; i++)
					szLine[i]=' ';
				szLine[i]='\0';
				WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
				fprintf(fp, "%s\n", szLine);
			}
			else
			{
				if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
				{
					nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					if (CheckLine(pBpaBlock, nTable, nRecord, nDict) > 0)
					{
						WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
						fprintf(fp, "%s\n", szLine);
					}
				}
				if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
				{
					nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					if (CheckLine(pBpaBlock, nTable, nRecord, nDict) > 0)
					{
						WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
						fprintf(fp, "%s\n", szLine);
					}
				}
				if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
				{
					nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';

					if (CheckLine(pBpaBlock, nTable, nRecord, nDict) > 0)
					{
						WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
						fprintf(fp, "%s\n", szLine);
					}
				}
			}
		}
		fflush(fp);

		for (nTable=0; nTable<sizeof(g_nBpaExcTables)/sizeof(int); nTable++)
		{
			nRecord=BpaFindRecordbyKey(pBpaBlock, g_nBpaExcTables[nTable], szRest);
			if (nRecord >= 0)
			{
				nComb=-1;
				BpaGetRecordValue(pBpaBlock, g_nBpaExcTables[nTable], BpaGetFieldIndex(g_nBpaExcTables[nTable], "CardKey"), nRecord, szCardKey);
				for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
				{
					if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
					{
						nComb=i;
						break;
					}
				}

				if (nComb < 0)
				{
					nDict=BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					WriteLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict, szLine);
					fprintf(fp, "%s\n", szLine);
				}
				else
				{
					if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';

						if (CheckLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaExcTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
				}
			}
		}
		fflush(fp);

		for (nTable=0; nTable<sizeof(g_nBpaPssTables)/sizeof(int); nTable++)
		{
			nRecord=BpaFindRecordbyKey(pBpaBlock, g_nBpaPssTables[nTable], szRest);
			if (nRecord >= 0)
			{
				nComb=-1;
				BpaGetRecordValue(pBpaBlock, g_nBpaPssTables[nTable], BpaGetFieldIndex(g_nBpaPssTables[nTable], "CardKey"), nRecord, szCardKey);
				for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
				{
					if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
					{
						nComb=i;
						break;
					}
				}

				if (nComb < 0)
				{
					nDict=BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					WriteLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict, szLine);
					fprintf(fp, "%s\n", szLine);
				}
				else
				{
					if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';

						if (CheckLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaPssTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
				}
			}
		}

		for (nTable=0; nTable<sizeof(g_nBpaGovTables)/sizeof(int); nTable++)
		{
			nRecord=BpaFindRecordbyKey(pBpaBlock, g_nBpaGovTables[nTable], szRest);
			if (nRecord >= 0)
			{
				nComb=-1;
				BpaGetRecordValue(pBpaBlock, g_nBpaGovTables[nTable], BpaGetFieldIndex(g_nBpaGovTables[nTable], "CardKey"), nRecord, szCardKey);
				for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
				{
					if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
					{
						nComb=i;
						break;
					}
				}

				if (nComb < 0)
				{
					nDict=BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					WriteLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict, szLine);
					fprintf(fp, "%s\n", szLine);
				}
				else
				{
					if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';

						if (CheckLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaGovTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
				}
			}
		}


		nTable=BPA_SWI_GA;
		nRecord=BpaFindRecordbyKey(pBpaBlock, nTable, szRest);
		if (nRecord >= 0)
		{
			nComb=-1;
			BpaGetRecordValue(pBpaBlock, nTable, BpaGetFieldIndex(nTable, "CardKey"), nRecord, szCardKey);
			for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
			{
				if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
				{
					nComb=i;
					break;
				}
			}

			if (nComb < 0)
			{
				nDict=BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
				for (i=0; i<260; i++)
					szLine[i]=' ';
				szLine[i]='\0';
				WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
				fprintf(fp, "%s\n", szLine);
			}
			else
			{
				if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
				{
					nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					if (CheckLine(pBpaBlock, nTable, nRecord, nDict) > 0)
					{
						WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
						fprintf(fp, "%s\n", szLine);
					}
				}
				if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
				{
					nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					if (CheckLine(pBpaBlock, nTable, nRecord, nDict) > 0)
					{
						WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
						fprintf(fp, "%s\n", szLine);
					}
				}
				if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
				{
					nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';

					if (CheckLine(pBpaBlock, nTable, nRecord, nDict) > 0)
					{
						WriteLine(pBpaBlock, nTable, nRecord, nDict, szLine);
						fprintf(fp, "%s\n", szLine);
					}
				}
			}
		}

		for (nTable=0; nTable<sizeof(g_nBpaMovTables)/sizeof(int); nTable++)
		{
			nRecord=BpaFindRecordbyKey(pBpaBlock, g_nBpaMovTables[nTable], szRest);
			if (nRecord >= 0)
			{
				nComb=-1;
				BpaGetRecordValue(pBpaBlock, g_nBpaMovTables[nTable], BpaGetFieldIndex(g_nBpaMovTables[nTable], "CardKey"), nRecord, szCardKey);
				for (i=0; i<sizeof(g_BpaCardCombArray)/sizeof(tagBpaCardComb); i++)
				{
					if (stricmp(g_BpaCardCombArray[i].szMainCard, szCardKey) == 0)
					{
						nComb=i;
						break;
					}
				}

				if (nComb < 0)
				{
					nDict=BpaGetTableDictIndex(szCardKey, BpaSwiCategory_Dat);
					for (i=0; i<260; i++)
						szLine[i]=' ';
					szLine[i]='\0';
					WriteLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict, szLine);
					fprintf(fp, "%s\n", szLine);
				}
				else
				{
					if (strlen(g_BpaCardCombArray[nComb].szMainCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szMainCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szExCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szExCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';
						if (CheckLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
					if (strlen(g_BpaCardCombArray[nComb].szAugCard) > 0)
					{
						nDict=BpaGetTableDictIndex(g_BpaCardCombArray[nComb].szAugCard, BpaSwiCategory_Dat);
						for (i=0; i<260; i++)
							szLine[i]=' ';
						szLine[i]='\0';

						if (CheckLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict) > 0)
						{
							WriteLine(pBpaBlock, g_nBpaMovTables[nTable], nRecord, nDict, szLine);
							fprintf(fp, "%s\n", szLine);
						}
					}
				}
			}
		}
		fprintf(fp, "\n");
	}

	fflush(fp);
	fclose(fp);
}

void CBPAData::Mdb2BpaSwi(tagBpaBlock* pBpaBlock, const char* lpszOutFileName, const unsigned char bModGen, const unsigned char bModExc, const unsigned char bModPss, const unsigned char bModGov)
{
	register int	i;
	int		nLine, nDict;
	int		nField, nRecord;
	int		nStart, nEnd, nDataLen, nDecimal;
	char	szRecArray[g_nConstMaxRestrict][MDB_CHARLEN_LONG];
	char	szValue[MDB_CHARLEN_LONG];
	char	szBuf[MDB_CHARLEN_LONG];
	char	szLine[261];
	double	fDeviate;

	MdbAppendGenerator(pBpaBlock);

	for (i=0; i<g_nConstMaxRestrict; i++)
		memset(szRecArray[i], 0, MDB_CHARLEN_LONG);
	for (nLine=0; nLine<(int)m_BpaSwiLineArray.size(); nLine++)
	{
		if (m_BpaSwiLineArray[nLine].strCard.empty())
			continue;
		if (m_BpaSwiLineArray[nLine].nMemDBTable < 0)
			continue;

		if (!bModGen)
		{
			if (m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GEN || m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GENLN)
				continue;
		}
		if (!bModExc)
		{
			if (m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_EXCIT68 || m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_EXCIT81 ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_EXCITMV || m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_EXCITX)
				continue;
		}
		if (!bModPss)
		{
			if (m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSS ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSSH ||
				//m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSSH1 || m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSSH2 || 
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSSI ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSSA || m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSSB ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_PSSST)
				continue;
		}
		if (!bModGov)
		{
			if (m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GG ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GH ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GC ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GS ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GL ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GW ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GA ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GI ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GJ ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GK ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GM ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GD ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_GZ ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TA ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TB ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TC ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TD ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TE ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TF ||
				m_BpaSwiLineArray[nLine].nMemDBTable == BPA_SWI_TW)
				continue;
		}

		nDict=BpaGetTableDictIndex(m_BpaSwiLineArray[nLine].strCard.c_str(), -1);
		if (nDict < 0)
			continue;

		if (BpaGetTableRestrictNum(m_BpaSwiLineArray[nLine].nMemDBTable) <= 0)
			continue;

		for (i=0; i<(int)m_BpaSwiLineArray[nLine].strLine.length(); i++)
			szLine[i]=m_BpaSwiLineArray[nLine].strLine[i];
		szLine[i]='\0';

		for (i=0; i<BpaGetTableRestrictNum(m_BpaSwiLineArray[nLine].nMemDBTable); i++)
			strcpy(szRecArray[i], m_BpaSwiLineArray[nLine].strKey[i].c_str());
		nRecord=BpaFindRecordbyKey(pBpaBlock, m_BpaSwiLineArray[nLine].nMemDBTable, szRecArray);
		if (nRecord < 0)
			continue;

		for (nField=0; nField<BpaGetTableFieldNum(m_BpaSwiLineArray[nLine].nMemDBTable); nField++)
		{
			BpaGetFieldName(m_BpaSwiLineArray[nLine].nMemDBTable, nField, szBuf);
			int	nDictField=BpaGetFieldDictIndex(nDict, szBuf);
			if (nDictField < 0)
				continue;
			if (!BpaGetDictModified(nDictField))
				continue;

			nStart=		BpaGetDictFieldStart(nDictField);
			nEnd=		BpaGetDictFieldEnd(nDictField);
			nDataLen=	BpaGetDictFieldLen(nDictField);
			if (nStart <= 0 || nDataLen <= 0)
				continue;

			memset(szValue, 0, MDB_CHARLEN_LONG);
			BpaGetRecordValue(pBpaBlock, m_BpaSwiLineArray[nLine].nMemDBTable, nField, nRecord, szValue);
			switch (BpaGetFieldType(m_BpaSwiLineArray[nLine].nMemDBTable, nField))
			{
			case MDB_FLOAT:
				nDecimal=BpaGetDictFieldDecimal(nDictField);
				ExtractBpaField(nStart, nEnd, szLine, szBuf);
				if (strlen(szBuf) > 0)
					CheckDecimal(szBuf, nDecimal);

				fDeviate=1.0;
				for (i=0; i<nDecimal; i++)
					fDeviate /= 10.0;
				fDeviate /= 10.0;

				if (fabs(atof(szBuf) - atof(szValue)) > fDeviate)
				{
					for (i=0; i<nDataLen; i++)
						szLine[i+nStart-1]=' ';
					if (fabs(atof(szValue)) > 0.00000001)
					{
						FormularBpaDecimalChar(szValue, nDataLen);
						for (i=0; i<nDataLen; i++)
						{
							if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
								break;
							szLine[i+nStart-1]=szValue[i];
						}
					}
				}
				break;
			case MDB_STRING:
				ExtractBpaField(nStart, nEnd, szLine, szBuf);
				if (strcmp(szValue, szBuf) != 0)
				{
					for (i=0; i<nDataLen; i++)
						szLine[i+nStart-1]=' ';
					for (i=0; i<nDataLen; i++)
					{
						if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
							break;
						szLine[i+nStart-1]=szValue[i];
					}
				}
				break;
			case MDB_INT:
			case MDB_BIT:
			case MDB_SHORT:
				ExtractBpaField(nStart, nEnd, szLine, szBuf);
				if (abs(atoi(szValue)-atoi(szBuf)) > 0)
				{
					for (i=0; i<nDataLen; i++)
						szLine[i+nStart-1]=' ';
					for (i=0; i<nDataLen; i++)
					{
						if (szValue[i] == ' ' || szValue[i] == '\t' || szValue[i] == '\n' || szValue[i] == '\r' || szValue[i] == '\0')
							break;
						szLine[i+nStart-1]=szValue[i];
					}
				}
				break;
			case MDB_CHAR:
				if (szValue[0] != ' ' && szValue[0] != '\t' && szValue[0] != '\n' && szValue[0] != '\r' && szValue[0] != '\0')
					szLine[nStart-1]=szValue[0];
				break;
			}
		}

		TrimRight(szLine);
		m_BpaSwiLineArray[nLine].strLine=szLine;
	}

	FILE*	fp;
	fp=fopen(lpszOutFileName, "w");
	if (fp == NULL)
		return;

	for (i=0; i<(int)m_BpaSwiLineArray.size(); i++)
		fprintf(fp, "%s\n", m_BpaSwiLineArray[i].strLine.c_str());
	fflush(fp);
	fclose(fp);
}
