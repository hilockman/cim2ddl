#include "stdAfx.h"
#include "BPAData.h"

void CBPAData::BpaModel2PGBlock(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock)
{
	register int	i;
	int			nDev, bRCard;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	double		fRatio=1;

	for (i=0; i<MAXMDBTABLENUM; i++)
		pPGBlock->m_nRecordNum[i]=0;
	pPGBlock->m_nRecordNum[PG_SYSTEM]=1;
	pPGBlock->m_System.fBasePower=(float)pBpaBlock->m_BpaDat_Case.fMVABase;

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	strcpy(szField[PG_TAPCHANGER_NAME], "�ֽ�ͷ00");
	strcpy(szField[PG_TAPCHANGER_TAPMIN], "0");
	strcpy(szField[PG_TAPCHANGER_TAPMAX], "0");
	strcpy(szField[PG_TAPCHANGER_TAPNOM], "0");
	strcpy(szField[PG_TAPCHANGER_TAPSTEP], "0");
	PGAppendRecord(pPGBlock, MDB_NeedCheckData, PG_TAPCHANGER, szField);

	memset(&pPGBlock->m_CompanyArray[pPGBlock->m_nRecordNum[PG_COMPANY]], 0, sizeof(tagPGCompany));
	strcpy(pPGBlock->m_CompanyArray[pPGBlock->m_nRecordNum[PG_COMPANY]].szName, "������˾");
	pPGBlock->m_nRecordNum[PG_COMPANY]++;

	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_ZONE]; nDev++)
	{
		memset(&pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]], 0, sizeof(tagPGSubcontrolArea));
		strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szCompany, "������˾");
		strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szName, pBpaBlock->m_BpaDat_ZoneArray[nDev].szName);
		pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]++;
	}

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nDev++)
	{
		strcpy(szField[PG_SUBSTATION_COMPANY], "������˾");
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[i].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nDev].szName) == 0)
			{
				strcpy(szField[PG_SUBSTATION_SUBCONTROLAREA], pBpaBlock->m_BpaDat_ACBusArray[i].szZone);
				break;
			}
		}
		strcpy(szField[PG_SUBSTATION_NAME], pBpaBlock->m_BpaDat_SubArray[nDev].szName);
		if (!PGAppendRecord(pPGBlock, MDB_NeedCheckData, PG_SUBSTATION, szField))
			continue;

		for (i=0; i<MAXMDBFIELDNUM; i++)
			memset(szField[i], 0, MDB_CHARLEN_LONG);
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[i].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nDev].szName) != 0)
				continue;

			strcpy(szField[PG_VOLTAGELEVEL_SUBSTATION], pBpaBlock->m_BpaDat_SubArray[nDev].szName);
			PGGetVoltID(pBpaBlock->m_BpaDat_ACBusArray[i].fkV, szField[PG_VOLTAGELEVEL_NAME]);
			sprintf(szField[PG_VOLTAGELEVEL_NOMINALVOLTAGE], "%.2f", pBpaBlock->m_BpaDat_ACBusArray[i].fkV);
			PGAppendRecord(pPGBlock, MDB_NeedCheckData, PG_VOLTAGELEVEL, szField);
		}
		for (i=0; i<MAXMDBFIELDNUM; i++)
			memset(szField[i], 0, MDB_CHARLEN_LONG);
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_DCBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_DCBusArray[i].szSub, pBpaBlock->m_BpaDat_SubArray[nDev].szName) != 0)
				continue;

			strcpy(szField[PG_VOLTAGELEVEL_SUBSTATION], pBpaBlock->m_BpaDat_SubArray[nDev].szName);
			PGGetVoltID(pBpaBlock->m_BpaDat_DCBusArray[i].fkV, szField[PG_VOLTAGELEVEL_NAME]);
			sprintf(szField[PG_VOLTAGELEVEL_NOMINALVOLTAGE], "%.2f", pBpaBlock->m_BpaDat_DCBusArray[i].fkV);
			PGAppendRecord(pPGBlock, MDB_NeedCheckData, PG_VOLTAGELEVEL, szField);
		}
	}

	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nDev++)
	{
		memset(&pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]], 0, sizeof(tagPGBusbarSection));
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szSub, pBpaBlock->m_BpaDat_ACBusArray[nDev].szBpaSub);
		PGGetVoltID(pBpaBlock->m_BpaDat_ACBusArray[nDev].fkV, pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szVolt);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szName, pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szNode, pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
		pPGBlock->m_nRecordNum[PG_BUSBARSECTION]++;
	}
	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_DCBUS]; nDev++)
	{
		memset(&pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]], 0, sizeof(tagPGBusbarSection));
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szSub, pBpaBlock->m_BpaDat_DCBusArray[nDev].szSub);
		PGGetVoltID(pBpaBlock->m_BpaDat_DCBusArray[nDev].fkV, pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szVolt);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szName, pBpaBlock->m_BpaDat_DCBusArray[nDev].szName);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szNode, pBpaBlock->m_BpaDat_DCBusArray[nDev].szName);
		pPGBlock->m_nRecordNum[PG_BUSBARSECTION]++;
	}

	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nDev++)
	{
		if (pBpaBlock->m_BpaDat_ACBusArray[nDev].bGenerator != 0 && pBpaBlock->m_BpaDat_ACBusArray[nDev].bDCBound == 0)
		{
			memset(&pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]], 0, sizeof(tagPGSynchronousMachine));
			strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szName,		pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
			strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub,		pBpaBlock->m_BpaDat_ACBusArray[nDev].szBpaSub);
			PGGetVoltID(pBpaBlock->m_BpaDat_ACBusArray[nDev].fkV, pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt);
			pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=pBpaBlock->m_BpaDat_ACBusArray[nDev].fPmax;
			pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=0;
			pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanP=pBpaBlock->m_BpaDat_ACBusArray[nDev].fPGen;
			pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fP=pBpaBlock->m_BpaDat_ACBusArray[nDev].fPGen;
			pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQ=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax;
			if (pBpaBlock->m_BpaDat_ACBusArray[nDev].fVHold_max > 0.85 && pBpaBlock->m_BpaDat_ACBusArray[nDev].fVHold_max < 1.15)
			{
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanV=pBpaBlock->m_BpaDat_ACBusArray[nDev].fVHold_max;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanQ=0;

				//pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=pBpaBlock->m_BpaDat_ACBusArray[nDev].fMinQ;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQmin;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax;
			}
			else
			{
				if (pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax > 0)
				{
					pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQmin;
					pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax;
				}
				else
				{
					pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQmin;
					pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax;
				}

				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanQ=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanV=0;
			}
			if (pBpaBlock->m_BpaDat_ACBusArray[nDev].fPmax < 200)
			{
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanQ=pBpaBlock->m_BpaDat_ACBusArray[nDev].fQsched_Qmax;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanV=0;
			}

			strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
			pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]++;
		}

		if (fabs(pBpaBlock->m_BpaDat_ACBusArray[nDev].fLoadP) > 0 || fabs(pBpaBlock->m_BpaDat_ACBusArray[nDev].fLoadQ) > 0)
		{
			memset(&pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGEnergyConsumer));
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName,			pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub,	pBpaBlock->m_BpaDat_ACBusArray[nDev].szBpaSub);
			PGGetVoltID(pBpaBlock->m_BpaDat_ACBusArray[nDev].fkV, pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt);
			pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].fPlanP=pBpaBlock->m_BpaDat_ACBusArray[nDev].fLoadP;
			pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].fPlanQ=pBpaBlock->m_BpaDat_ACBusArray[nDev].fLoadQ;
			pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].fP=pBpaBlock->m_BpaDat_ACBusArray[nDev].fLoadP;
			pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].fQ=pBpaBlock->m_BpaDat_ACBusArray[nDev].fLoadQ;
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode, pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
			pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;
		}

		if (fabs(pBpaBlock->m_BpaDat_ACBusArray[nDev].fShuntQ) > 0)
		{
			memset(&pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]], 0, sizeof(tagPGShuntCompensator));
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName,			pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szSub,		pBpaBlock->m_BpaDat_ACBusArray[nDev].szBpaSub);
			PGGetVoltID(pBpaBlock->m_BpaDat_ACBusArray[nDev].fkV, pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szVolt);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szNode, pBpaBlock->m_BpaDat_ACBusArray[nDev].szName);
			pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].fCap=pBpaBlock->m_BpaDat_ACBusArray[nDev].fShuntQ;
			pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]++;
		}
	}

	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nDev++)
	{
		pBpaBlock->m_BpaDat_ACLineArray[nDev].fG1=0;

		memset(&pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]], 0, sizeof(tagPGACLineSegment));
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szName,			pBpaBlock->m_BpaDat_ACLineArray[nDev].szKeyName);
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubI,	pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nDev].nIBus].szBpaSub);
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubJ,	pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_ACLineArray[nDev].nZBus].szBpaSub);
		PGGetVoltID(pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVI, pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltI);
		PGGetVoltID(pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVJ, pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltJ);
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fR=(float)(fRatio*pBpaBlock->m_BpaDat_ACLineArray[nDev].fR);
		if (pBpaBlock->m_BpaDat_ACLineArray[nDev].fX < 0.0001)
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fX=0.001f;
		else
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fX=(float)(fRatio*pBpaBlock->m_BpaDat_ACLineArray[nDev].fX);
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fRatedCur=(float)(fRatio*pBpaBlock->m_BpaDat_ACLineArray[nDev].fAMP);
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fRatedMva=(float)(1.732*pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVI*fRatio*pBpaBlock->m_BpaDat_ACLineArray[nDev].fAMP/1000);
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fG=(float)(pBpaBlock->m_BpaDat_ACLineArray[nDev].fG1/fRatio);
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fB=(float)(pBpaBlock->m_BpaDat_ACLineArray[nDev].fB1/fRatio);
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeI, pBpaBlock->m_BpaDat_ACLineArray[nDev].szBusI);
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeJ, pBpaBlock->m_BpaDat_ACLineArray[nDev].szBusJ);
		pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]++;
	}

	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_LINEHG]; nDev++)
	{
		if (pBpaBlock->m_BpaDat_LineHGArray[nDev].fShuntI > 0.1)
		{
			memset(&pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]], 0, sizeof(tagPGShuntCompensator));
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName,		pBpaBlock->m_BpaDat_LineHGArray[nDev].szBusI);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szSub,	pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_LineHGArray[nDev].nIBus].szBpaSub);
			PGGetVoltID(pBpaBlock->m_BpaDat_LineHGArray[nDev].fkVI, pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szVolt);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szNode, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_LineHGArray[nDev].nIBus].szName);
			pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].fCap=-pBpaBlock->m_BpaDat_LineHGArray[nDev].fShuntI;
			pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]++;
		}

		if (pBpaBlock->m_BpaDat_LineHGArray[nDev].fShuntJ > 0.1)
		{
			memset(&pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]], 0, sizeof(tagPGShuntCompensator));
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName,		pBpaBlock->m_BpaDat_LineHGArray[nDev].szBusJ);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szSub,	pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_LineHGArray[nDev].nZBus].szBpaSub);
			PGGetVoltID(pBpaBlock->m_BpaDat_LineHGArray[nDev].fkVJ, pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szVolt);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szNode, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_LineHGArray[nDev].nZBus].szName);
			pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].fCap=-pBpaBlock->m_BpaDat_LineHGArray[nDev].fShuntJ;
			pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]++;
		}
	}

	// 	for (i=0; i<MAXMDBFIELDNUM; i++)
	// 		memset(szField[i], 0, MDB_CHARLEN_LONG);
	// 	for (i=0; i<(int)m_LDCardArray.size(); i++)
	// 	{
	// 		sprintf(szField[PG_DCLINESEGMENT_NAME], "%s-%s", m_LDCardArray[i].szRectifier, m_LDCardArray[i].szInverter);
	// 		PGAppendRecord(pPGBlock, MDB_NeedCheckData, PG_DCLINESEGMENT, szField);
	// 	}

	// 	for (i=0; i<MAXMDBFIELDNUM; i++)
	// 		memset(szField[i], 0, MDB_CHARLEN_LONG);
	// 	for (i=0; i<(int)pBpaBlock->m_BpaDat_RArray.size(); i++)
	// 		pBpaBlock->m_BpaDat_RArray[i].bProc=0;
	// 	for (i=0; i<(int)pBpaBlock->m_BpaDat_RArray.size(); i++)
	// 	{
	// 		if (strcmp(pBpaBlock->m_BpaDat_RArray[i].szBusI, pBpaBlock->m_BpaDat_RArray[j].szConBus) == 0 && pBpaBlock->m_BpaDat_RArray[i].fkVI == pBpaBlock->m_BpaDat_RArray[j].fConBusV)
	// 		{
	// 		}
	// 		if (strcmp(pBpaBlock->m_BpaDat_RArray[i].szBusJ, pBpaBlock->m_BpaDat_RArray[j].szConBus) == 0 && pBpaBlock->m_BpaDat_RArray[i].fkVJ == pBpaBlock->m_BpaDat_RArray[j].fConBusV)
	// 		{
	// 		}
	// 
	// 		sprintf(szField[PG_RECTIFIERINVERTER_NAME], "%s-%s", pBpaBlock->m_BpaDat_RArray[i].szBusI, pBpaBlock->m_BpaDat_RArray[i].szBusJ);
	// 		strcpy(szField[PG_RECTIFIERINVERTER_SUBSTATION], pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_RArray[i].nACBus].szSub);
	// 		strcpy(szField[PG_RECTIFIERINVERTER_VOLTAGELEVEL1], PGGetVoltID(pBpaBlock->m_BpaDat_RArray[i].fkVI));
	// 		strcpy(szField[PG_RECTIFIERINVERTER_CONNECTIVITYNODE1], pBpaBlock->m_BpaDat_RArray[i].szBusI);
	// 		strcpy(szField[PG_RECTIFIERINVERTER_CONNECTIVITYNODE2], pBpaBlock->m_BpaDat_RArray[i].szBusJ);
	// 
	// 		//sprintf(szField[PG_RECTIFIERINVERTER_BRIDGES], "%d", );
	// 
	// 		PGAppendRecord(pPGBlock, MDB_NeedCheckData, PG_RECTIFIERINVERTER, szField);
	// 	}

	//	T���е���R����Ե�T������Ϊ��ѹ�����룬�����������
	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nDev++)
	{
		bRCard=0;
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_R]; i++)
		{
			if ((strcmp(pBpaBlock->m_BpaDat_RArray[i].szBusI, pBpaBlock->m_BpaDat_WindArray[nDev].szBusI) == 0 && pBpaBlock->m_BpaDat_RArray[i].fkVI == pBpaBlock->m_BpaDat_WindArray[nDev].fkVI &&
				strcmp(pBpaBlock->m_BpaDat_RArray[i].szBusJ, pBpaBlock->m_BpaDat_WindArray[nDev].szBusJ) == 0 && pBpaBlock->m_BpaDat_RArray[i].fkVJ == pBpaBlock->m_BpaDat_WindArray[nDev].fkVJ) ||
				(strcmp(pBpaBlock->m_BpaDat_RArray[i].szBusI, pBpaBlock->m_BpaDat_WindArray[nDev].szBusJ) == 0 && pBpaBlock->m_BpaDat_RArray[i].fkVI == pBpaBlock->m_BpaDat_WindArray[nDev].fkVJ &&
				strcmp(pBpaBlock->m_BpaDat_RArray[i].szBusJ, pBpaBlock->m_BpaDat_WindArray[nDev].szBusI) == 0 && pBpaBlock->m_BpaDat_RArray[i].fkVJ == pBpaBlock->m_BpaDat_WindArray[nDev].fkVI))
			{
				bRCard=1;
				break;
			}
		}
		if (bRCard)
			continue;

		memset(&pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName, pBpaBlock->m_BpaDat_WindArray[nDev].szKeyName);
		strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nDev].nIBus].szBpaSub);
		if (pBpaBlock->m_BpaDat_WindArray[nDev].fkVI >= pBpaBlock->m_BpaDat_WindArray[nDev].fkVJ)
		{
			PGGetVoltID(pBpaBlock->m_BpaDat_WindArray[nDev].fkVI, pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI);
			PGGetVoltID(pBpaBlock->m_BpaDat_WindArray[nDev].fkVJ, pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ);
			pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVI=pBpaBlock->m_BpaDat_WindArray[nDev].fTPI;
			pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVJ=pBpaBlock->m_BpaDat_WindArray[nDev].fTPJ;
			strcpy	(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI, pBpaBlock->m_BpaDat_WindArray[nDev].szBusI);
			strcpy	(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, pBpaBlock->m_BpaDat_WindArray[nDev].szBusJ);
		}
		else
		{
			PGGetVoltID(pBpaBlock->m_BpaDat_WindArray[nDev].fkVI, pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ);
			PGGetVoltID(pBpaBlock->m_BpaDat_WindArray[nDev].fkVJ, pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI);
			pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVJ=pBpaBlock->m_BpaDat_WindArray[nDev].fTPI;
			pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVI=pBpaBlock->m_BpaDat_WindArray[nDev].fTPJ;
			strcpy	(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, pBpaBlock->m_BpaDat_WindArray[nDev].szBusI);
			strcpy	(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI, pBpaBlock->m_BpaDat_WindArray[nDev].szBusJ);
		}
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fR=(float)(fRatio*pBpaBlock->m_BpaDat_WindArray[nDev].fR);
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fX=(float)(fRatio*pBpaBlock->m_BpaDat_WindArray[nDev].fX);
		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fB=pBpaBlock->m_BpaDat_WindArray[nDev].fB;
		strcpy	(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szTapChangerI, "�ֽ�ͷ00");
		strcpy	(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szTapChangerJ, "�ֽ�ͷ00");

		pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedMva=pBpaBlock->m_BpaDat_WindArray[nDev].fMVA;
		pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;
	}

	PGMaint(pPGBlock);
}
