#pragma once

#include "../../../MemDB/PGMemDB/PGMemDB.h"
#include "../../../MemDB/BpaMemDB/BpaMemDB.h"
using namespace PGMemDB;
using namespace	BpaMemDB;

typedef	struct	_BpaMatchCim_
{
	short	nDevType;
	char	szBpaDev[MDB_CHARLEN];
	char	szBpaKey[MDB_CHARLEN_LONG];
	char	szCimKey[MDB_CHARLEN_LONG];
}	tagBpaMatchCim;

class CBPA2RTMatch
{
public:
	CBPA2RTMatch(void);
	~CBPA2RTMatch(void);

public:
	void	ReadBpa2CimMatch(tagBpaBlock* pBpaBlock, const char* lpszFileName);
	void	SaveBpa2CimMatch(tagBpaBlock* pBpaBlock, const char* lpszFileName);
	void	AutoBpa2CimMatch(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock);
	int		IsCimDeviceMatched(tagBpaBlock* pBpaBlock, const int nBpaTable, const char* lpszPGDev);
private:
	void	CheckPGBusLineMatched(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock);
	void	CheckBpa2CimMatch(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock);

private:
	void	Log(char* pformat, ...);
	void	ClearLog();

private:
	std::vector<tagBpaMatchCim>		m_Bpa2PGArray;
};
