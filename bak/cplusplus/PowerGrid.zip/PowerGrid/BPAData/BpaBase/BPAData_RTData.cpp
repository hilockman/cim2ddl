#include "stdAfx.h"
#include "BPAData.h"

extern	int	StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

float CBPAData::FindBpaP(tagBpaBlock* pBpaBlock, const int nPType, const int nBpaBus)
{
	int		nP;
	float	fP=1.0f;

	for (nP=0; nP<pBpaBlock->m_nRecordNum[BPA_DAT_P]; nP++)
	{
		if (STRICMP(pBpaBlock->m_BpaDat_PArray[nP].szCardKey, "PA") == 0)
		{
			switch (nPType)
			{
			case	BPA_DAT_ACBUS_PLOAD:
				fP=pBpaBlock->m_BpaDat_PArray[nP].fLoadPFactor;
				break;
			case	BPA_DAT_ACBUS_QLOAD:
				fP=pBpaBlock->m_BpaDat_PArray[nP].fLoadQFactor;
				break;
			case	BPA_DAT_ACBUS_PGEN:
				fP=pBpaBlock->m_BpaDat_PArray[nP].fGenPFactor;
				break;
			case	BPA_DAT_ACBUS_QSCHED_QMAX:
				fP=pBpaBlock->m_BpaDat_PArray[nP].fGenQFactor;
				break;
			default:
				break;
			}
		}
	}

	for (nP=0; nP<pBpaBlock->m_nRecordNum[BPA_DAT_P]; nP++)
	{
		if (STRICMP(pBpaBlock->m_BpaDat_PArray[nP].szCardKey, "PZ") == 0)
		{
			if (STRICMP(pBpaBlock->m_BpaDat_ACBusArray[nBpaBus].szZone, pBpaBlock->m_BpaDat_PArray[nP].szZone) == 0)
			{
				switch (nPType)
				{
				case	BPA_DAT_ACBUS_PLOAD:
					fP=pBpaBlock->m_BpaDat_PArray[nP].fLoadPFactor;
					break;
				case	BPA_DAT_ACBUS_QLOAD:
					fP=pBpaBlock->m_BpaDat_PArray[nP].fLoadQFactor;
					break;
				case	BPA_DAT_ACBUS_PGEN:
					fP=pBpaBlock->m_BpaDat_PArray[nP].fGenPFactor;
					break;
				case	BPA_DAT_ACBUS_QSCHED_QMAX:
					fP=pBpaBlock->m_BpaDat_PArray[nP].fGenQFactor;
					break;
				default:
					break;
				}
				break;
			}
		}
	}

	return fP;
}

void CBPAData::CimRt2Bpa(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock, const char* lpszRefFile, const int bLowToMid, const char* lpszOutFile)
{
	register int	i;
	int		nBpa, nData, nSub, nVolt, nBus, nDev;
	unsigned char	bFlag, bMeasured;
	float	fP, fQ;
	char	szBuf[260];
	char	szKeyValueArray[g_nConstMaxRestrict][MDB_CHARLEN_LONG];

	std::vector<float>	fGenPArray;
	std::vector<float>	fGenQArray;
	std::vector<float>	fLoadPArray;
	std::vector<float>	fLoadQArray;
	std::vector<float>	fShuntQArray;
	std::vector<float>	fVHoldArray;

	std::vector<unsigned char>	bProcArray;
	std::vector<int>	nWindBusArray;
	std::vector<unsigned char>	bBusMeasuredArray;
	std::vector<float>	fTranPArray;
	std::vector<float>	fTranQArray;
	std::vector<int>	nTielineArray;
	std::vector<int>	nBoundBusArray;

	float	fTotalLoadP, fTotalGenP, fRTTotalLoadP, fRTTotalGenP;

	ClearLog();
	//	1�����������˷����͵絺����
	PGMemDBTopo(pPGBlock);
	PGMemDBStatus(pPGBlock, 1);

	//	3����BPA�����ļ��γ��������Ϣ
	//BpaLoadDictionary(pBpaBlock);
	ReadBpaLine(lpszRefFile, "");

	//	4����ʼ��BPA��RT��Ϣ
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenP=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fPGen;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenQ=0;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadP=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadQ=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadQ;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtShuntQ=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fShuntQ;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtVHold=0;
	}
	fGenPArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS], 0);
	fGenQArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS], 0);
	fLoadPArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS], 0);
	fLoadQArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS], 0);
	fShuntQArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS], 0);
	fVHoldArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS], 0);

	//	5�����ݵ���ģ�������豸״̬��Ϣ�γ�BPA�豸״̬��Ϣ
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nBpa++)
	{
		pBpaBlock->m_BpaDat_ACLineArray[nBpa].nStatus=0;
		if (strlen(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias) <= 0)
			continue;

		nDev=PGFindRecordbyKey(pPGBlock, PG_ACLINESEGMENT, pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias);
		if (nDev >= 0)	pBpaBlock->m_BpaDat_ACLineArray[nBpa].nStatus=pPGBlock->m_ACLineSegmentArray[nDev].bOutage;
	}
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nBpa++)
	{
		pBpaBlock->m_BpaDat_WindArray[nBpa].nStatus=0;
		if (strlen(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias) <= 0)
			continue;

		strcpy(szBuf, pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias);
		i=0;
		char*	lpszToken=strtok(szBuf, ", ");
		while (lpszToken != NULL)
		{
			if (i < g_nConstMaxRestrict)	strcpy(szKeyValueArray[i++], lpszToken);
			lpszToken=strtok(NULL, ", ");
		}
		nDev=PGFindRecordbyKey(pPGBlock, PG_TRANSFORMERWINDING, szKeyValueArray);
		if (nDev >= 0)	pBpaBlock->m_BpaDat_WindArray[nBpa].nStatus=pPGBlock->m_TransformerWindingArray[nDev].bOutage;
	}
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].nStatus=0;
		if (!IsZoneInWorkArea(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szZone))
			continue;

		bFlag=0;
		if (!bFlag)
		{
			for (i=pBpaBlock->m_BpaDat_ACBusArray[nBpa].nACLineRange; i<pBpaBlock->m_BpaDat_ACBusArray[nBpa+1].nACLineRange; i++)
			{
				if (pBpaBlock->m_BpaDat_ACLineArray[pBpaBlock->m_BpaDat_EdgeLineArray[i].iRLine].nStatus == 0)
				{
					bFlag=1;
					break;
				}
			}
		}
		if (!bFlag)
		{
			for (i=pBpaBlock->m_BpaDat_ACBusArray[nBpa].nWindRange; i<pBpaBlock->m_BpaDat_ACBusArray[nBpa+1].nWindRange; i++)
			{
				if (pBpaBlock->m_BpaDat_WindArray[pBpaBlock->m_BpaDat_EdgeWindArray[i].iRWind].nStatus == 0)
				{
					bFlag=1;
					break;
				}
			}
		}
		if (!bFlag)
			pBpaBlock->m_BpaDat_ACBusArray[nBpa].nStatus=1;
	}

	//	6���γɷ����ע����Ϣ
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				sprintf(szBuf, "%s, %s, %s", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szVolt, pPGBlock->m_SynchronousMachineArray[nDev].szName);
				for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
				{
					if (strlen(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias) <= 0)
						continue;

					if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias, szBuf) == 0)
					{
						fGenPArray[nBpa]=pPGBlock->m_SynchronousMachineArray[nDev].fP;
						fGenQArray[nBpa]=pPGBlock->m_SynchronousMachineArray[nDev].fQ;
						fVHoldArray[nBpa]=pPGBlock->m_SynchronousMachineArray[nDev].fPlanV;

						break;
					}
				}
			}
		}
	}

	//	7���γɱ�ѹ���е�ѹע����Ϣ
	bProcArray.clear();
	bProcArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_WIND], 0);
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	std::vector<unsigned char>	bBpaLineMeasuredArray;
	bBpaLineMeasuredArray.resize(pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]);
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nBpa++)
	{
		if (bProcArray[nBpa])
			continue;
		if (strlen(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias) <= 0)
			continue;
		if (pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus < 0)
			continue;


		bProcArray[nBpa]=1;

		nWindBusArray.clear();
		bBusMeasuredArray.clear();
		fTranPArray.clear();
		fTranQArray.clear();

		//	7.1����ȡ��ѹ��ĸ�ߺ�����
		if (pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].bTMid || pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus].bTMid)					//	������
		{
			nData=(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus].bTMid) ? pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus : pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus;	//	�����Ե�
			for (nDev=pBpaBlock->m_BpaDat_ACBusArray[nData].nWindRange; nDev<pBpaBlock->m_BpaDat_ACBusArray[nData+1].nWindRange; nDev++)
			{
				bProcArray[pBpaBlock->m_BpaDat_EdgeWindArray[nDev].iRWind]=1;
				if (pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[pBpaBlock->m_BpaDat_EdgeWindArray[nDev].iRWind].nIBus].bTMid)
				{
					nWindBusArray.push_back(pBpaBlock->m_BpaDat_WindArray[pBpaBlock->m_BpaDat_EdgeWindArray[nDev].iRWind].nZBus);
				}
				else
				{
					nWindBusArray.push_back(pBpaBlock->m_BpaDat_WindArray[pBpaBlock->m_BpaDat_EdgeWindArray[nDev].iRWind].nIBus);
				}
				bMeasured=(unsigned char)GetPGTranPQ(pPGBlock, bLowToMid, pBpaBlock->m_BpaDat_WindArray[pBpaBlock->m_BpaDat_EdgeWindArray[nDev].iRWind].szAlias, 0, fP, fQ);
				bBusMeasuredArray.push_back(bMeasured);
				fTranPArray.push_back(fP);
				fTranQArray.push_back(fQ);
			}
		}
		else
		{
			nWindBusArray.push_back(pBpaBlock->m_BpaDat_WindArray[nBpa].nIBus);
			bMeasured=(unsigned char)GetPGTranPQ(pPGBlock, bLowToMid, pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, 0, fP, fQ);
			bBusMeasuredArray.push_back(bMeasured);
			fTranPArray.push_back(fP);
			fTranQArray.push_back(fQ);

			nWindBusArray.push_back(pBpaBlock->m_BpaDat_WindArray[nBpa].nZBus);
			bMeasured=(unsigned char)GetPGTranPQ(pPGBlock, bLowToMid, pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias, 1, fP, fQ);
			bBusMeasuredArray.push_back(bMeasured);
			fTranPArray.push_back(fP);
			fTranQArray.push_back(fQ);
		}

		//if (strstr(pBpaBlock->m_BpaDat_WindArray[nBpa].szBusI, "������") != NULL)
		{
			for (i=0; i<(int)fTranPArray.size(); i++)
				Log("��ѹ���������� %s - %s [%d/%d] = %.2f %.2f\n", pBpaBlock->m_BpaDat_WindArray[nBpa].szBusI, pBpaBlock->m_BpaDat_WindArray[nBpa].szBusJ, i, fTranPArray.size(), fTranPArray[i], fTranQArray[i]);
		}

		for (i=0; i<(int)bBpaLineMeasuredArray.size(); i++)
			bBpaLineMeasuredArray[i]=0;
		for (nBus=0; nBus<(int)nWindBusArray.size(); nBus++)
		{
			if (!bBusMeasuredArray[nBus])
				continue;
			for (nDev=pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].nACLineRange; nDev<pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]+1].nACLineRange; nDev++)
			{
				if (bBpaLineMeasuredArray[pBpaBlock->m_BpaDat_EdgeLineArray[nDev].iRLine])
					continue;

				if (strlen(pBpaBlock->m_BpaDat_ACLineArray[pBpaBlock->m_BpaDat_EdgeLineArray[nDev].iRLine].szAlias) <= 0)
					continue;

				bFlag=0;
				for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; i++)
				{
					if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[i].szAlias, pBpaBlock->m_BpaDat_ACLineArray[pBpaBlock->m_BpaDat_EdgeLineArray[nDev].iRLine].szAlias) == 0)	
					{
						bFlag=1;
						break;
					}
				}
				if (!bFlag)
					continue;

				int	nBpaSub=-1;
				for (nData=0; nData<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; nData++)
				{
					if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].szBpaSub, pBpaBlock->m_BpaDat_SubArray[nData].szName) == 0)
					{
						nBpaSub=nData;
						break;
					}
				}
				if (nBpaSub < 0)
					continue;

				bBpaLineMeasuredArray[pBpaBlock->m_BpaDat_EdgeLineArray[nDev].iRLine]=1;
				bMeasured=(unsigned char)GetPGLinePQ(pPGBlock, bLowToMid, pBpaBlock->m_BpaDat_ACLineArray[pBpaBlock->m_BpaDat_EdgeLineArray[nDev].iRLine].szAlias, pBpaBlock->m_BpaDat_SubArray[nBpaSub].szAlias, fP, fQ);
				if (bMeasured)
				{
					fTranPArray[nBus] -= fP;
					fTranQArray[nBus] -= fQ;

					//if (strstr(pBpaBlock->m_BpaDat_WindArray[nBpa].szBusI, "������") != NULL)
					{
						for (i=0; i<(int)fTranPArray.size(); i++)
							Log("LineMod[Bus=%s Line=%d] %s - %s [%d/%d] = %.2f %.2f\n", pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].szName, pBpaBlock->m_BpaDat_EdgeLineArray[nDev].iRLine, 
								pBpaBlock->m_BpaDat_WindArray[nBpa].szBusI, pBpaBlock->m_BpaDat_WindArray[nBpa].szBusJ, i, fTranPArray.size(), fP, fQ);
					}
				}
			}
		}

		//if (strstr(pBpaBlock->m_BpaDat_WindArray[nBpa].szBusI, "������") != NULL)
		//{
		//	for (i=0; i<fTranPArray.size(); i++)
		//		Log("After LineMod %s - %s [%d/%d] = %.2f %.2f\n", pBpaBlock->m_BpaDat_WindArray[nBpa].szBusI, pBpaBlock->m_BpaDat_WindArray[nBpa].szBusJ, i, fTranPArray.size(), fTranPArray[i], fTranQArray[i]);
		//}

		for (nBus=0; nBus<(int)nWindBusArray.size(); nBus++)
		{
			if (!bBusMeasuredArray[nBus])
				continue;

			fLoadPArray[nWindBusArray[nBus]] += fTranPArray[nBus];
			fLoadQArray[nWindBusArray[nBus]] += fTranQArray[nBus];
			Log("����ĸ�߸��� %s.%.1f = %.2f %.2f\n", 
				pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].szName, 
				pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].fkV, 
				fTranPArray[nBus], fTranQArray[nBus]);
		}

		bFlag=0;
		for (nBus=0; nBus<(int)nWindBusArray.size(); nBus++)
		{
			if (pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].fkV >= 400)
			{
				bFlag=1;
			}
			else if (pBpaBlock->m_BpaDat_ACBusArray[nWindBusArray[nBus]].fkV >= 200)
			{
				fLoadPArray[nWindBusArray[nBus]] = 0;
				fLoadQArray[nWindBusArray[nBus]] = 0;
			}
		}
		if (bFlag)
		{
			for (nBus=0; nBus<(int)nWindBusArray.size(); nBus++)
			{
				fLoadPArray[nWindBusArray[nBus]] = 0;
				fLoadQArray[nWindBusArray[nBus]] = 0;
			}
		}
	}

	//	8��BPA��RT���ݸ�ֵ
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias) <= 0)
			continue;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenP=fGenPArray[nBpa]/FindBpaP(pBpaBlock, BPA_DAT_ACBUS_PGEN, nBpa);
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenQ=fGenQArray[nBpa]/FindBpaP(pBpaBlock, BPA_DAT_ACBUS_QSCHED_QMAX, nBpa);
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtShuntQ=fShuntQArray[nBpa];
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadP=fLoadPArray[nBpa]/FindBpaP(pBpaBlock, BPA_DAT_ACBUS_PLOAD, nBpa);
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadQ=fLoadQArray[nBpa]/FindBpaP(pBpaBlock, BPA_DAT_ACBUS_QLOAD, nBpa);
	}

	//	9������ƥ�䣬�������߷�ֵ����ߵ�ѹ�ȼ�
	GetTieLine(pBpaBlock, m_strFilterZoneArray, nTielineArray, nBoundBusArray);
	fTotalLoadP=fTotalGenP=fRTTotalLoadP=fRTTotalGenP=0;
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		if (IsZoneInWorkArea(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szZone))
		{
			fTotalGenP += pBpaBlock->m_BpaDat_ACBusArray[nBpa].fPGen;
			fTotalLoadP += pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP;

			fRTTotalGenP += pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenP;
			fRTTotalLoadP += pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadP;
		}
	}

	float	fMaxVolt=-9999;
	int		nMaxVoltNum;
	for (i=0; i<(int)nBoundBusArray.size(); i++)
	{
		if (fMaxVolt < pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].fkV)
		{
			fMaxVolt=pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].fkV;
		}
	}
	nMaxVoltNum=0;
	for (i=0; i<(int)nBoundBusArray.size(); i++)
	{
		if (pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].fkV >= fMaxVolt-0.0000001)
		{
			nMaxVoltNum++;
		}
	}
	if (nMaxVoltNum > 0)
	{
		for (i=0; i<(int)nBoundBusArray.size(); i++)
		{
			if (pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].fkV >= fMaxVolt-0.0000001)
			{
				pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].fRtLoadP += (fTotalLoadP-fRTTotalLoadP-(fTotalGenP-fRTTotalGenP))/nMaxVoltNum;
				Log("����ĸ��[%s %.2f]����=%f\n", pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].szName, pBpaBlock->m_BpaDat_ACBusArray[nBoundBusArray[i]].fkV, (fTotalLoadP-fRTTotalLoadP-(fTotalGenP-fRTTotalGenP))/nMaxVoltNum);
			}
		}
	}

	//	10��BPA�м������ݸ�ֵ���γɼ����ļ�
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		fGenPArray[nBpa]	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fPGen			;
		fGenQArray[nBpa]	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fQsched_Qmax	;
		fLoadPArray[nBpa]	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP		;
		fLoadQArray[nBpa]	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadQ		;
		fShuntQArray[nBpa]	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fShuntQ		;
		fVHoldArray[nBpa]	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP		;
	}

	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACBusArray[nBpa].szAlias) <= 0)
			continue;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fPGen			=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenP			;
		//pBpaBlock->m_BpaDat_ACBusArray[nBpa].fQsched_Qmax	=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtGenQ			;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP			=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadP			;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadQ			=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadQ			;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fShuntQ		=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtShuntQ			;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP			=pBpaBlock->m_BpaDat_ACBusArray[nBpa].fRtLoadP			;
	}
	Mdb2BpaDat(pBpaBlock, lpszOutFile);
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBpa++)
	{
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fPGen			=fGenPArray[nBpa]	;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fQsched_Qmax	=fGenQArray[nBpa]	;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP			=fLoadPArray[nBpa]	;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadQ			=fLoadQArray[nBpa]	;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fShuntQ		=fShuntQArray[nBpa]	;
		pBpaBlock->m_BpaDat_ACBusArray[nBpa].fLoadP			=fVHoldArray[nBpa]	;
	}
}

int	CBPAData::GetSameVBpaBusNum(tagBpaBlock* pBpaBlock, const int nBpaBus)
{
	register int	i;
	int		nSameVoltageNum=0;
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
	{
		if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[i].szBpaSub, pBpaBlock->m_BpaDat_ACBusArray[nBpaBus].szBpaSub) == 0 &&
			fabs(pBpaBlock->m_BpaDat_ACBusArray[i].fkV-pBpaBlock->m_BpaDat_ACBusArray[nBpaBus].fkV) < 0.001)
			nSameVoltageNum++;
	}

	int		nBpaSub=-1;
	int		nSameSubNum=0;
	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
	{
		if (strcmp(pBpaBlock->m_BpaDat_SubArray[i].szName, pBpaBlock->m_BpaDat_ACBusArray[nBpaBus].szBpaSub) == 0)
		{
			nBpaSub=i;
			break;
		}
	}
	if (nBpaSub < 0)
		return nSameVoltageNum;

	for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_SUB]; i++)
	{
		if (strcmp(pBpaBlock->m_BpaDat_SubArray[i].szAlias, pBpaBlock->m_BpaDat_SubArray[nBpaSub].szAlias) == 0)
		{
			nSameSubNum++;
		}
	}
	if (nSameSubNum == 1)
		return nSameVoltageNum;
	else
		return nSameSubNum*nSameVoltageNum;
}

int CBPAData::GetPGTranPQ(tagPGBlock* pBlock, const int bLowToMid, const char* lpszPGWindName, const int nSide, float& fTranP, float& fTranQ)
{
	int		nWind, nTran;
	char	szBuf[260];
	float	fP, fQ;
	unsigned char	bMeasured=1;
	char	szKeyValueArray[g_nConstMaxRestrict][MDB_CHARLEN_LONG];
	char*	lpszToken;

	strcpy(szBuf, lpszPGWindName);

	nWind=0;
	lpszToken=strtok(szBuf, ", ");
	while (lpszToken != NULL)
	{
		strcpy(szKeyValueArray[nWind++], lpszToken);
		lpszToken=strtok(NULL, ", ");
	}

	fTranP=fTranQ=0;

	nWind=PGFindRecordbyKey(pBlock, PG_TRANSFORMERWINDING, szKeyValueArray);
	if (nWind < 0)
		return 0;


	nTran=pBlock->m_TransformerWindingArray[nWind].nTran;
	if (nTran < 0)
		return 0;

	if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 3)
	{
		int	nMidNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI ||
			pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ) ?
			pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

		if (pBlock->m_PowerTransformerArray[nTran].nWindH == nWind)
		{
			fTranP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPi;
			fTranQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQi;
			if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
			{
				fTranP=fTranQ=0;
				bMeasured=0;
			}
		}
		else if (pBlock->m_PowerTransformerArray[nTran].nWindM == nWind)
		{
			if (bLowToMid)
			{
				bMeasured=2;
				fP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPi;
				fQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQi;
				if (fabs(fP) > 999990 || fabs(fQ) > 999990)
				{
					fP=fQ=0;
					bMeasured--;
					//bMeasured=0;
				}
				fTranP += fP;
				fTranQ += fQ;

				fP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPi;
				fQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQi;
				if (fabs(fP) > 999990 || fabs(fQ) > 999990)
				{
					fP=fQ=0;
					bMeasured--;
					//bMeasured=0;
				}

				fTranP += fP;
				fTranQ += fQ;
				if (bMeasured > 0)
					bMeasured=1;
			}
			else
			{
				fTranP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPi;
				fTranQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQi;
				if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
				{
					fTranP=fTranQ=0;
					bMeasured=0;
				}
			}
		}
		else if (pBlock->m_PowerTransformerArray[nTran].nWindL == nWind)
		{
			if (!bLowToMid)
			{
				fTranP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPi;
				fTranQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQi;
				if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
				{
					fTranP=fTranQ=0;
					bMeasured=0;
				}
			}
		}
	}
	else
	{
		if (nSide == 0)
		{
			fTranP = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPi;
			fTranQ = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQi;
			if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
			{
				fTranP=fTranQ=0;
				bMeasured=0;
			}
		}
		else
		{
			fTranP = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPz;
			fTranQ = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQz;
			if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
			{
				fTranP=fTranQ=0;
				bMeasured=0;
			}
		}
	}
	return bMeasured;
}

int CBPAData::GetPGLinePQ(tagPGBlock* pBlock, const int bLowToMid, const char* lpszPGLineName, const char* lpszPGSubName, float& fLineP, float& fLineQ)
{
	int		nLine;
	unsigned char	bMeasured=1;

	fLineP=fLineQ=0;

	nLine=PGFindRecordbyKey(pBlock, PG_ACLINESEGMENT, lpszPGLineName);
	if (nLine < 0)
		return 0;

	if (strcmp(pBlock->m_ACLineSegmentArray[nLine].szSubI, lpszPGSubName) == 0)
	{
		fLineP = pBlock->m_ACLineSegmentArray[nLine].fPi;
		fLineQ = pBlock->m_ACLineSegmentArray[nLine].fQi;
		if (fabs(fLineP) > 999990 || fabs(fLineQ) > 999990)
		{
			fLineP = 0;
			fLineQ = 0;
			bMeasured=0;
		}
	}
	else
	{
		fLineP = pBlock->m_ACLineSegmentArray[nLine].fPz;
		fLineQ = pBlock->m_ACLineSegmentArray[nLine].fQz;
		if (fabs(fLineP) > 999990 || fabs(fLineQ) > 999990)
		{
			fLineP = 0;
			fLineQ = 0;
			bMeasured=0;
		}
	}
	return bMeasured;
}
