#include "stdAfx.h"
#include "BPAData.h"

void CBPAData::ParamBPA2PG(tagBpaBlock* pBpaBlock, tagPGBlock* pPGBlock, const char* lpszMatchFile)
{
	register int	i;
	int		nBpa, nDev;
	double	fFactor;
	char	szBuf[260];
	char	szKeyValueArray[g_nConstMaxRestrict][MDB_CHARLEN_LONG];

	fFactor=pPGBlock->m_System.fBasePower/pBpaBlock->m_BpaDat_Case.fMVABase;
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias) <= 0)
			continue;

		nDev=PGFindRecordbyKey(pPGBlock, PG_ACLINESEGMENT, pBpaBlock->m_BpaDat_ACLineArray[nBpa].szAlias);
		if (nDev >= 0)
		{
			pPGBlock->m_ACLineSegmentArray[nDev].fR = (float)(pBpaBlock->m_BpaDat_ACLineArray[nBpa].fR * fFactor);
			pPGBlock->m_ACLineSegmentArray[nDev].fX = (float)(pBpaBlock->m_BpaDat_ACLineArray[nBpa].fX * fFactor);
			pPGBlock->m_ACLineSegmentArray[nDev].fB = (float)(pBpaBlock->m_BpaDat_ACLineArray[nBpa].fB1 / fFactor);
		}
	}
	for (nBpa=0; nBpa<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nBpa++)
	{
		if (strlen(pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias) <= 0)
			continue;

		strcpy(szBuf, pBpaBlock->m_BpaDat_WindArray[nBpa].szAlias);
		i=0;
		char*	lpszToken=strtok(szBuf, ", ");
		while (lpszToken != NULL)
		{
			if (i < g_nConstMaxRestrict)	strcpy(szKeyValueArray[i++], lpszToken);
			lpszToken=strtok(NULL, ", ");
		}
		nDev=PGFindRecordbyKey(pPGBlock, PG_TRANSFORMERWINDING, szKeyValueArray);
		if (nDev >= 0)
		{
			pPGBlock->m_TransformerWindingArray[nDev].fR = (float)(pBpaBlock->m_BpaDat_WindArray[nBpa].fR * fFactor);
			pPGBlock->m_TransformerWindingArray[nDev].fX = (float)(pBpaBlock->m_BpaDat_WindArray[nBpa].fX * fFactor);
		}
	}
}
