#include "stdAfx.h"
#include "BPAData.h"
#include "../../../Common/StringCommon.h"

void CBPAData::CheckTranSub(tagBpaBlock* pBpaBlock)
{
	int		nTran;
	for (nTran=0; nTran<pBpaBlock->m_nRecordNum[BPA_DAT_WIND]; nTran++)
	{
		if (pBpaBlock->m_BpaDat_WindArray[nTran].nIBus < 0 || pBpaBlock->m_BpaDat_WindArray[nTran].nZBus < 0)
			continue;

		if (pBpaBlock->m_BpaDat_WindArray[nTran].bRCard == 1)
		{
			if (strcmp(pBpaBlock->m_BpaDat_DCBusArray[pBpaBlock->m_BpaDat_WindArray[nTran].nIBus].szSub, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nTran].nZBus].szBpaSub) != 0)
			{
				Log("��ѹ�����೧վ��ͬ: %s (%s <-> %s)\n", pBpaBlock->m_BpaDat_WindArray[nTran].szKeyName, pBpaBlock->m_BpaDat_WindArray[nTran].szBusI, pBpaBlock->m_BpaDat_WindArray[nTran].szBusJ);
			}
		}
		else if (pBpaBlock->m_BpaDat_WindArray[nTran].bRCard ==2)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nTran].nIBus].szBpaSub, pBpaBlock->m_BpaDat_DCBusArray[pBpaBlock->m_BpaDat_WindArray[nTran].nZBus].szSub) != 0)
			{
				Log("��ѹ�����೧վ��ͬ: %s (%s <-> %s)\n", pBpaBlock->m_BpaDat_WindArray[nTran].szKeyName, pBpaBlock->m_BpaDat_WindArray[nTran].szBusI, pBpaBlock->m_BpaDat_WindArray[nTran].szBusJ);
			}
		}
		else
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nTran].nIBus].szBpaSub, pBpaBlock->m_BpaDat_ACBusArray[pBpaBlock->m_BpaDat_WindArray[nTran].nZBus].szBpaSub) != 0)
			{
				Log("��ѹ�����೧վ��ͬ: %s (%s <-> %s)\n", pBpaBlock->m_BpaDat_WindArray[nTran].szKeyName, pBpaBlock->m_BpaDat_WindArray[nTran].szBusI, pBpaBlock->m_BpaDat_WindArray[nTran].szBusJ);
			}
		}
	}

}

int	CBPAData::ReadBpaLine(const char* lpszBpaDatFile, const char* lpszBpaSwiFile)
{
	register int	i;
	clock_t	dBeg, dEnd;
	int		nDur;
	unsigned char	bDataEndFlag, bConFlag;

	dBeg=clock();

	FILE*	fp;
	char	szLine[1024], szKey[10];
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	tagBpaLine	lBuf;

	m_BpaDatLineArray.clear();
	m_BpaSwiLineArray.clear();
	m_nSwiGenStartPos=-1;

	fp=fopen(lpszBpaDatFile, "r");
	if (fp != NULL)
	{
		bDataEndFlag=0;
		while (!feof(fp))
		{
			memset(szLine, 0, 1024);
			fgets(szLine, 1024, fp);
			TrimEnd(szLine);

			lBuf.strCard.clear();
			lBuf.bCategory=BpaDatCategory_Dat;
			for (i=0; i<g_nConstMaxRestrict; i++)
				lBuf.strKey[i].clear();
			lBuf.strLine.clear();
			lBuf.nDictIndex=-1;
			lBuf.nMemDBTable=-1;
			lBuf.nSection=g_nBpaDatSectionNone;

			lBuf.strLine=szLine;

			if (szLine[0] == ' ')	//	����������ݴ���
			{
				m_BpaDatLineArray.push_back(lBuf);
				continue;
			}

			if (bDataEndFlag != 0)
			{
				m_BpaDatLineArray.push_back(lBuf);
				continue;
			}

			TrimLeft(szLine);
			TrimRight(szLine);
			if (strlen(szLine) <= 0)
			{
				m_BpaDatLineArray.push_back(lBuf);
				continue;
			}

			if (szLine[0] == '.' || szLine[0] == 'C'  || szLine[0] == 'c' || strstr(strupr(szLine), "(END)") != NULL)
			{
				m_BpaDatLineArray.push_back(lBuf);
				if (strstr(strupr(szLine), "(END)") != NULL)
					bDataEndFlag=1;
				continue;
			}
			if (szLine[0] == '(' || szLine[0] == '/' || szLine[0] == '>')
			{
				m_BpaDatLineArray.push_back(lBuf);
				continue;
			}

			memset(szKey, 0, 10);
			BpaResolveLineKey(szLine, szKey);

			BpaBpaCardKey2DictKey(szKey, szLine);
			// 			if (STRICMP(szKey, "L+") == 0)
			// 				ASSERT(FALSE);

			lBuf.nDictIndex=(short)BpaGetTableDictIndex(szKey, BpaDatCategory_Dat);
			if (lBuf.nDictIndex < 0)
			{
				m_BpaDatLineArray.push_back(lBuf);
				continue;
			}
			lBuf.nMemDBTable=(short)BpaGetTableIndex(BpaGetDictTable(lBuf.nDictIndex));
			if (lBuf.nMemDBTable < 0)
			{
				m_BpaDatLineArray.push_back(lBuf);
				continue;
			}

			lBuf.strCard=szKey;

			BpaString2FieldArray(lBuf.nMemDBTable, lBuf.nDictIndex, lBuf.strLine.c_str(), szField);
			for (i=0; i<BpaGetTableRestrictNum(lBuf.nMemDBTable); i++)
				lBuf.strKey[i]=szField[BpaGetTableRestrictField(lBuf.nMemDBTable, i)];
			m_BpaDatLineArray.push_back(lBuf);
		}
		fclose(fp);
	}

	fp=fopen(lpszBpaSwiFile, "r");
	if (fp != NULL)
	{
		bDataEndFlag=0;
		bConFlag=0;
		while (!feof(fp))
		{
			memset(szLine, 0, 1024);
			fgets(szLine, 1024, fp);
			TrimEnd(szLine);

			lBuf.strCard.clear();
			lBuf.bCategory=BpaSwiCategory_Dat;
			for (i=0; i<g_nConstMaxRestrict; i++)
				lBuf.strKey[i].clear();
			lBuf.strLine.clear();
			lBuf.nDictIndex=-1;
			lBuf.nMemDBTable=-1;
			lBuf.nSection=g_nBpaSwiSectionNone;

			lBuf.strLine=szLine;

			if (bDataEndFlag)
			{
				m_BpaSwiLineArray.push_back(lBuf);
				continue;
			}

			TrimLeft(szLine);
			TrimEnd(szLine);
			if (strlen(szLine) <= 0)
			{
				m_BpaSwiLineArray.push_back(lBuf);
				continue;
			}
			//if (szLine[0] == '.' || szLine[0] == '/' || ((szLine[0] == 'C' || szLine[0] == 'c') && szLine[1] == ' '))
			if (szLine[0] == '.' || szLine[0] == '/' || szLine[0] == 'C' || szLine[0] == 'c')
			{
				memset(szKey, 0, 10);
				strncpy(szKey, szLine, 4);
				if (STRICMP(strupr(szKey), "CASE") != 0)
				{
					m_BpaSwiLineArray.push_back(lBuf);
					continue;
				}
				else if (szLine[1] == ' ' || szLine[1] == '/')
				{
					m_BpaSwiLineArray.push_back(lBuf);
					continue;
				}
			}

			memset(szKey, 0, 10);
			BpaResolveLineKey(szLine, szKey);

			if (STRICMP(szKey, "F0") == 0)	//	������ƿ�
			{
				m_BpaSwiLineArray.push_back(lBuf);
				bConFlag=1;
				continue;
			}
			if (STRICMP(szKey, "90") == 0)	//	�����ʼ��
			{
				m_BpaSwiLineArray.push_back(lBuf);
				bDataEndFlag=1;
			}

			if (bDataEndFlag)
			{
				m_BpaSwiLineArray.push_back(lBuf);
				continue;
			}

			//if (STRICMP(szKey, "FF") == 0 || STRICMP(szKey, "F0") == 0 || STRICMP(szKey, "F1") == 0)	//	������ƿ�

			if (bConFlag == 0)
			{
				if (STRICMP(szKey, "CASE") == 0)
				{
					lBuf.bCategory=BpaSwiCategory_Con;
					BpaBpaCardKey2DictKey(szKey, szLine);
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(szKey, BpaSwiCategory_Con);
				}
				else
				{
					BpaBpaCardKey2DictKey(szKey, szLine);
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(szKey, BpaSwiCategory_Dat);
					if (BpaGetGeneratorTableByCardKey(szKey) >= 0)
						lBuf.nSection=g_nBpaSwiSectionGen;
				}
			}
			else
			{
				if (STRICMP(szKey, "F1") == 0 || STRICMP(szKey, "FF") == 0)
				{
					lBuf.bCategory=BpaSwiCategory_Con;
					BpaBpaCardKey2DictKey(szKey, szLine);
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(szKey, BpaSwiCategory_Con);
				}
				else
				{
					BpaBpaCardKey2DictKey(szKey, szLine);
					lBuf.nDictIndex=(short)BpaGetTableDictIndex(szKey, BpaSwiCategory_Dat);
				}
			}
			if (lBuf.nDictIndex < 0)
			{
				m_BpaSwiLineArray.push_back(lBuf);
				continue;
			}

			lBuf.nMemDBTable=BpaGetTableIndex(BpaGetDictTable(lBuf.nDictIndex));
			if (lBuf.nMemDBTable < 0)
			{
				m_BpaSwiLineArray.push_back(lBuf);
				continue;
			}

			lBuf.strCard=szKey;
			BpaString2FieldArray(lBuf.nMemDBTable, lBuf.nDictIndex, lBuf.strLine.c_str(), szField);
			for (i=0; i<BpaGetTableRestrictNum(lBuf.nMemDBTable); i++)
				lBuf.strKey[i]=szField[BpaGetTableRestrictField(lBuf.nMemDBTable, i)];
			m_BpaSwiLineArray.push_back(lBuf);

			//if (STRICMP(szKey, "FF") == 0 && bConFlag)	//	������ƿ�
			//	bDataEndFlag=1;
		}
		fclose(fp);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	//Log(g_lpszLogFile, "BPA�ļ���ȡ��ϣ���ʱ%d����\n", nDur);

	return 1;
}