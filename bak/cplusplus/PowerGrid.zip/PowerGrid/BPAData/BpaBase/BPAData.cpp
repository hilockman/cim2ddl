#include "stdAfx.h"
#include "BPAData.h"
#include "../../../Common/TinyXML/tinyxml.h"

CBPAData::CBPAData(void)
{
	m_fZIL=0.0001;
}

CBPAData::~CBPAData(void)
{
}

void CBPAData::ExtractBpaField(IN const int nColIni, IN const int nColEnd, IN const char* lpszInChar, OUT char* lpszChar)
{
	register int	i;
	int		nChar;
	unsigned char	bValid;

	nChar=0;
	bValid=0;

	i=nColIni-1;
	while (i < nColEnd && i < (int)strlen(lpszInChar))
	{
		if (lpszInChar[i] == '\0' || lpszInChar[i] == '\n' || lpszInChar[i] == '\r')
			break;

		if (bValid)
		{
			if (lpszInChar[i] == ' ' || lpszInChar[i] == '\t')
				break;
		}

		if (lpszInChar[i] != ' ' && lpszInChar[i] != '\t' && lpszInChar[i] != '\0')
			bValid=1;

		lpszChar[nChar++]=lpszInChar[i];

		i++;
	}
	lpszChar[nChar]='\0';
}

int	CBPAData::IsZoneInWorkArea(const char* lpszZone)
{
	register int	i;
	if (m_strFilterZoneArray.empty())
		return 1;
	for (i=0; i<(int)m_strFilterZoneArray.size(); i++)
	{
		if (strcmp(m_strFilterZoneArray[i].c_str(), lpszZone) == 0)
			return 1;
	}
	return 0;
}

int	CBPAData::IsSubInWorkArea(tagBpaBlock* pBpaBlock, const char* lpszSub)
{
	register int	i;
	if (m_strFilterZoneArray.empty())
		return 1;

	int		nBus;
	for (nBus=0; nBus<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBus++)
	{
		if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBus].szBpaSub, lpszSub) != 0)
			continue;

		for (i=0; i<(int)m_strFilterZoneArray.size(); i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBus].szZone, m_strFilterZoneArray[i].c_str()) == 0)
				return 1;
		}
	}
	return 0;
}

int	CBPAData::IsSubInArea(tagBpaBlock* pBpaBlock, const char* lpszSub, const char* lpszZone)
{
	if (m_strFilterZoneArray.empty())
		return 1;

	int		nBus;
	for (nBus=0; nBus<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; nBus++)
	{
		if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBus].szBpaSub, lpszSub) != 0)
			continue;

		if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBus].szZone, lpszZone) == 0)
			return 1;
	}
	return 0;
}



void CBPAData::GetTieLine(tagBpaBlock* pBpaBlock, std::vector<std::string>& strInAreaArray, std::vector<int>& nTLineArray)
{
	register int	i;
	int		nDev, nBusI, nBusJ, nInAreaI, nInAreaJ;

	nTLineArray.clear();
	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nDev++)
	{
		nBusI=nBusJ=-1;
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[nDev].szBusI, pBpaBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
				fabs(pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVI-pBpaBlock->m_BpaDat_ACBusArray[i].fkV) < 0.01)
			{
				nBusI=i;
				break;
			}
		}
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[nDev].szBusJ, pBpaBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
				fabs(pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVJ-pBpaBlock->m_BpaDat_ACBusArray[i].fkV) < 0.01)
			{
				nBusJ=i;
				break;
			}
		}
		if (nBusI < 0 || nBusJ < 0)
			continue;

		nInAreaI=nInAreaJ=0;
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBusI].szZone, strInAreaArray[i].c_str()) == 0)
			{
				nInAreaI=1;
				break;
			}
		}
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBusJ].szZone, strInAreaArray[i].c_str()) == 0)
			{
				nInAreaJ=1;
				break;
			}
		}
		if (nInAreaI != nInAreaJ)
		{
			nTLineArray.push_back(nDev);
		}
	}
}


void CBPAData::GetTieLine(tagBpaBlock* pBpaBlock, std::vector<std::string>& strInAreaArray, std::vector<int>& nTLineArray, std::vector<int>& nBoundBusArray)
{
	register int	i;
	int		nDev, nBusI, nBusJ, nInAreaI, nInAreaJ;

	nTLineArray.clear();
	nBoundBusArray.clear();
	for (nDev=0; nDev<pBpaBlock->m_nRecordNum[BPA_DAT_ACLINE]; nDev++)
	{
		nBusI=nBusJ=-1;
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[nDev].szBusI, pBpaBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
				fabs(pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVI-pBpaBlock->m_BpaDat_ACBusArray[i].fkV) < 0.01)
			{
				nBusI=i;
				break;
			}
		}
		for (i=0; i<pBpaBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACLineArray[nDev].szBusJ, pBpaBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
				fabs(pBpaBlock->m_BpaDat_ACLineArray[nDev].fkVJ-pBpaBlock->m_BpaDat_ACBusArray[i].fkV) < 0.01)
			{
				nBusJ=i;
				break;
			}
		}
		if (nBusI < 0 || nBusJ < 0)
			continue;

		nInAreaI=nInAreaJ=0;
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBusI].szZone, strInAreaArray[i].c_str()) == 0)
			{
				nInAreaI=1;
				break;
			}
		}
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(pBpaBlock->m_BpaDat_ACBusArray[nBusJ].szZone, strInAreaArray[i].c_str()) == 0)
			{
				nInAreaJ=1;
				break;
			}
		}
		if (nInAreaI != nInAreaJ)
		{
			nTLineArray.push_back(nDev);
			if (nInAreaI)
			{
				nBoundBusArray.push_back(nBusI);
			}
			else
			{
				nBoundBusArray.push_back(nBusJ);
			}
		}
	}
}

void CBPAData::TailorNet (tagBpaBlock* pBlock, const char* lpszOutFileName, std::vector<std::string>& strInAreaArray)
{
	register int	i;
	int		nDev, nLine, nBusI, nBusJ;
	unsigned char	bFlag;
	char	szRest[g_nConstMaxRestrict][MDB_CHARLEN_LONG];

	for (nLine=0; nLine<(int)m_BpaDatLineArray.size(); nLine++)
	{
		m_BpaDatLineArray[nLine].bDeleted=0;
		for (i=0; i<g_nConstMaxRestrict; i++)
			strcpy(szRest[i], m_BpaDatLineArray[nLine].strKey[i].c_str());

		switch (m_BpaDatLineArray[nLine].nMemDBTable)
		{
		case BPA_DAT_ACBUS:
			m_BpaDatLineArray[nLine].bDeleted=1;
			nDev=BpaFindRecordbyKey(pBlock, m_BpaDatLineArray[nLine].nMemDBTable, szRest);
			if (nDev >= 0)
			{
				for (i=0; i<(int)strInAreaArray.size(); i++)
				{
					if (strcmp(pBlock->m_BpaDat_ACBusArray[nDev].szZone, strInAreaArray[i].c_str()) == 0)
					{
						m_BpaDatLineArray[nLine].bDeleted=0;
						break;
					}
				}
			}
			break;
		case BPA_DAT_ACLINE:
			m_BpaDatLineArray[nLine].bDeleted=1;
			nDev=BpaFindRecordbyKey(pBlock, m_BpaDatLineArray[nLine].nMemDBTable, szRest);
			if (nDev >= 0)
			{
				nBusI=nBusJ=-1;
				for (i=0; i<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
				{
					if (strcmp(pBlock->m_BpaDat_ACLineArray[nDev].szBusI, pBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
						fabs(pBlock->m_BpaDat_ACLineArray[nDev].fkVI-pBlock->m_BpaDat_ACBusArray[i].fkV) < 0.001)
					{
						nBusI=i;
						break;
					}
				}
				for (i=0; i<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
				{
					if (strcmp(pBlock->m_BpaDat_ACLineArray[nDev].szBusJ, pBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
						fabs(pBlock->m_BpaDat_ACLineArray[nDev].fkVJ-pBlock->m_BpaDat_ACBusArray[i].fkV) < 0.001)
					{
						nBusJ=i;
						break;
					}
				}
				if (nBusI >= 0 && nBusJ >= 0)
				{
					bFlag=0;
					for (i=0; i<(int)strInAreaArray.size(); i++)
					{
						if (strcmp(pBlock->m_BpaDat_ACBusArray[nBusI].szZone, strInAreaArray[i].c_str()) == 0)
						{
							bFlag++;
							break;
						}
					}
					for (i=0; i<(int)strInAreaArray.size(); i++)
					{
						if (strcmp(pBlock->m_BpaDat_ACBusArray[nBusJ].szZone, strInAreaArray[i].c_str()) == 0)
						{
							bFlag++;
							break;
						}
					}
					if (bFlag == 2)
						m_BpaDatLineArray[nLine].bDeleted=0;
				}
			}
			break;
		case BPA_DAT_LINEHG:
			m_BpaDatLineArray[nLine].bDeleted=1;
			nDev=BpaFindRecordbyKey(pBlock, m_BpaDatLineArray[nLine].nMemDBTable, szRest);
			if (nDev >= 0)
			{
				nBusI=nBusJ=-1;
				for (i=0; i<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
				{
					if (strcmp(pBlock->m_BpaDat_LineHGArray[nDev].szBusI, pBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
						fabs(pBlock->m_BpaDat_LineHGArray[nDev].fkVI-pBlock->m_BpaDat_ACBusArray[i].fkV) < 0.001)
					{
						nBusI=i;
						break;
					}
				}
				for (i=0; i<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
				{
					if (strcmp(pBlock->m_BpaDat_LineHGArray[nDev].szBusJ, pBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
						fabs(pBlock->m_BpaDat_LineHGArray[nDev].fkVJ-pBlock->m_BpaDat_ACBusArray[i].fkV) < 0.001)
					{
						nBusJ=i;
						break;
					}
				}
				if (nBusI >= 0 && nBusJ >= 0)
				{
					bFlag=0;
					for (i=0; i<(int)strInAreaArray.size(); i++)
					{
						if (strcmp(pBlock->m_BpaDat_ACBusArray[nBusI].szZone, strInAreaArray[i].c_str()) == 0)
						{
							bFlag++;
							break;
						}
					}
					for (i=0; i<(int)strInAreaArray.size(); i++)
					{
						if (strcmp(pBlock->m_BpaDat_ACBusArray[nBusJ].szZone, strInAreaArray[i].c_str()) == 0)
						{
							bFlag++;
							break;
						}
					}
					if (bFlag == 2)
						m_BpaDatLineArray[nLine].bDeleted=0;
				}
			}
			break;
		case BPA_DAT_WIND:
			m_BpaDatLineArray[nLine].bDeleted=1;
			nDev=BpaFindRecordbyKey(pBlock, m_BpaDatLineArray[nLine].nMemDBTable, szRest);
			if (nDev >= 0)
			{
				nBusI=nBusJ=-1;
				for (i=0; i<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
				{
					if (strcmp(pBlock->m_BpaDat_WindArray[nDev].szBusI, pBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
						fabs(pBlock->m_BpaDat_WindArray[nDev].fkVI-pBlock->m_BpaDat_ACBusArray[i].fkV) < 0.001)
					{
						nBusI=i;
						break;
					}
				}
				for (i=0; i<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; i++)
				{
					if (strcmp(pBlock->m_BpaDat_WindArray[nDev].szBusJ, pBlock->m_BpaDat_ACBusArray[i].szName) == 0 &&
						fabs(pBlock->m_BpaDat_WindArray[nDev].fkVJ-pBlock->m_BpaDat_ACBusArray[i].fkV) < 0.001)
					{
						nBusJ=i;
						break;
					}
				}
				if (nBusI >= 0 && nBusJ >= 0)
				{
					bFlag=0;
					for (i=0; i<(int)strInAreaArray.size(); i++)
					{
						if (strcmp(pBlock->m_BpaDat_ACBusArray[nBusI].szZone, strInAreaArray[i].c_str()) == 0)
						{
							bFlag++;
							break;
						}
					}
					for (i=0; i<(int)strInAreaArray.size(); i++)
					{
						if (strcmp(pBlock->m_BpaDat_ACBusArray[nBusJ].szZone, strInAreaArray[i].c_str()) == 0)
						{
							bFlag++;
							break;
						}
					}
					if (bFlag == 2)
						m_BpaDatLineArray[nLine].bDeleted=0;
				}
			}
			break;
		case BPA_DAT_DCBUS:
			m_BpaDatLineArray[nLine].bDeleted=1;
			break;
		case BPA_DAT_DCLINE:
			m_BpaDatLineArray[nLine].bDeleted=1;
			break;
		case BPA_DAT_R:
			m_BpaDatLineArray[nLine].bDeleted=1;
			break;
		case BPA_DAT_RZ:
			m_BpaDatLineArray[nLine].bDeleted=1;
			break;
		case BPA_DAT_P:
			m_BpaDatLineArray[nLine].bDeleted=1;
			nDev=BpaFindRecordbyKey(pBlock, m_BpaDatLineArray[nLine].nMemDBTable, szRest);
			if (nDev >= 0)
			{
				for (i=0; i<(int)strInAreaArray.size(); i++)
				{
					if (strcmp(pBlock->m_BpaDat_PArray[nDev].szZone, strInAreaArray[i].c_str()) == 0)
					{
						m_BpaDatLineArray[nLine].bDeleted=0;
						break;
					}
				}
			}
			break;
		}
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[BPA_DAT_ACBUS]; nDev++)
	{
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(pBlock->m_BpaDat_ACBusArray[i].szZone, strInAreaArray[i].c_str()) == 0)
			{
				break;
			}
		}
	}

	FILE*	fp;
	fp=fopen(lpszOutFileName, "w");
	if (fp == NULL)
	return;

	for (i=0; i<(int)m_BpaDatLineArray.size(); i++)
	{
		if (m_BpaDatLineArray[i].bDeleted)
			continue;
		if (m_BpaDatLineArray[i].strLine.length() <= 0)
			continue;
		if (m_BpaDatLineArray[i].strLine[0] == '.')
			continue;

		fprintf(fp, "%s\n", m_BpaDatLineArray[i].strLine.c_str());
	}
	fflush(fp);
	fclose(fp);
}