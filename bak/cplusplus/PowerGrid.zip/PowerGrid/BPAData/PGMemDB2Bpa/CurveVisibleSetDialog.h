#pragma once
#include "afxwin.h"


// CCurveVisibleSetDialog �Ի���

class CCurveVisibleSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CCurveVisibleSetDialog)

public:
	CCurveVisibleSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CCurveVisibleSetDialog();

// �Ի�������
	enum { IDD = IDD_CURVE_SETDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();

	DECLARE_MESSAGE_MAP()
public:
	CMFCColorButton m_btnBackColor;
	CMFCColorButton m_btnForeColor;
	CMFCColorButton m_btnCurveColor;
	CMFCColorButton m_btnAxiasColor;
};
