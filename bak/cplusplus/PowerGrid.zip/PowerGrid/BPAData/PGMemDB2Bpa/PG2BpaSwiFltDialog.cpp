// PG2BpaSwiFltDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "PG2BpaSwiFltDialog.h"
#include "BpaFltSetDialog.h"
#include "../../../Common/StringCommon.h"

// CPG2BpaSwiFltDialog �Ի���
static	char*	lpszBpaFltDevColumn[]=
{
	"��վ", 
	"��ѹ", 
	"����", 
};

static	char*	lpszBpaFltLineColumn[]=
{
	"����", 
	"��ѹ", 
	"��վ", 
	"�ճ�վ", 
};

static	char*	lpszBpaFltTranColumn[]=
{
	"����", 
	"��վ", 
	"���ѹ", 
	"�յ�ѹ", 
};

static	char*	lpszBpaFltSetColumn[]=
{
	"��������", 
	"�豸����", 
	"�豸��վ", 
	"�豸��ѹ", 
	"�豸����", 
	"����ʱ��", 
};

IMPLEMENT_DYNAMIC(CPG2BpaSwiFltDialog, CDialog)

CPG2BpaSwiFltDialog::CPG2BpaSwiFltDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2BpaSwiFltDialog::IDD, pParent)
{
	m_nFltSide=0;
}

CPG2BpaSwiFltDialog::~CPG2BpaSwiFltDialog()
{
}

void CPG2BpaSwiFltDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_SIDE_I, m_nFltSide);
	DDX_Control(pDX, IDC_FLTDEF_LIST, m_wndAllFltList);
	DDX_Control(pDX, IDC_FLTRUN_LIST, m_wndRunFltList);
}


BEGIN_MESSAGE_MAP(CPG2BpaSwiFltDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_DEVTYPE_COMBO, &CPG2BpaSwiFltDialog::OnCbnSelchangeDevtypeCombo)
	ON_BN_CLICKED(IDC_FORM_FLT, &CPG2BpaSwiFltDialog::OnBnClickedFormFlt)
	ON_BN_CLICKED(IDC_REFRESH_PG, &CPG2BpaSwiFltDialog::OnBnClickedRefreshPg)
	ON_CBN_SELCHANGE(IDC_SUB_COMBO, &CPG2BpaSwiFltDialog::OnCbnSelchangeSubCombo)
	ON_BN_CLICKED(IDC_ADD_FLT, &CPG2BpaSwiFltDialog::OnBnClickedAddFlt)
	ON_BN_CLICKED(IDC_DEL_FLT, &CPG2BpaSwiFltDialog::OnBnClickedDelFlt)
	ON_BN_CLICKED(IDC_ADD_RUNFLT, &CPG2BpaSwiFltDialog::OnBnClickedAddRunflt)
	ON_BN_CLICKED(IDC_DEL_RUNFLT, &CPG2BpaSwiFltDialog::OnBnClickedDelRunflt)
END_MESSAGE_MAP()


// CPG2BpaSwiFltDialog ��Ϣ��������

BOOL CPG2BpaSwiFltDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CComboBox*	pCombo;

	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	pCombo->ResetContent();
	for (i=0; i<sizeof(g_lpszBpaFltDevType)/sizeof(char*); i++)
		pCombo->AddString(g_lpszBpaFltDevType[i]);
	pCombo->SetCurSel(0);

	pCombo=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pCombo->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTDEF_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszBpaFltSetColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBpaFltSetColumn[i]);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTRUN_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszBpaFltSetColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBpaFltSetColumn[i]);

	UpdateData(FALSE);

	RefreshUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPG2BpaSwiFltDialog::RefreshUI()
{
	OnCbnSelchangeDevtypeCombo();
	RefreshAllFltList();
	RefreshRunFltList();
}

void CPG2BpaSwiFltDialog::RefreshDeviceList()
{
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));

	char	szFilter[MDB_CHARLEN];
	memset(szFilter, 0, MDB_CHARLEN);

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	int		nSub=pCombo->GetCurSel();
	if (nSub > 0)
		pCombo->GetLBText(nSub, szFilter);

	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	int		nDevType=pCombo->GetCurSel();
	if (nDevType == CB_ERR)
		return;

	register int	i;
	int		nRow, nCol, nColNum;

	nRow=nColNum=0;
	switch (nDevType)
	{
	case	BpaFltDev_Bus:
		nColNum=sizeof(lpszBpaFltDevColumn)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			pListCtrl->InsertColumn(i, lpszBpaFltDevColumn[i]);

		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		{
			if (strlen(szFilter) > 0)
			{
				if (stricmp(g_pPGBlock->m_BusbarSectionArray[i].szSub, szFilter) != 0)
					continue;
			}
			pListCtrl->InsertItem(nRow, g_pPGBlock->m_BusbarSectionArray[i].szSub);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szName);

			nRow++;
		}
		break;
	case	BpaFltDev_Line:
		nColNum=sizeof(lpszBpaFltLineColumn)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			pListCtrl->InsertColumn(i, lpszBpaFltLineColumn[i]);

		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (strlen(szFilter) > 0)
			{
				if (stricmp(g_pPGBlock->m_ACLineSegmentArray[i].szSubI, szFilter) != 0 && stricmp(g_pPGBlock->m_ACLineSegmentArray[i].szSubJ, szFilter) != 0)
					continue;
			}
			pListCtrl->InsertItem(nRow, g_pPGBlock->m_ACLineSegmentArray[i].szName);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubJ);

			nRow++;
		}
		break;
	case	BpaFltDev_Wind:
		nColNum=sizeof(lpszBpaFltTranColumn)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			pListCtrl->InsertColumn(i, lpszBpaFltTranColumn[i]);

		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		{
			if (strlen(szFilter) > 0)
			{
				if (stricmp(g_pPGBlock->m_TransformerWindingArray[i].szSub, szFilter) != 0)
					continue;
			}
			pListCtrl->InsertItem(nRow, g_pPGBlock->m_TransformerWindingArray[i].szSub);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szName);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltJ);

			nRow++;
		}
		break;
	case	BpaFltDev_Gen:
		nColNum=sizeof(lpszBpaFltDevColumn)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			pListCtrl->InsertColumn(i, lpszBpaFltDevColumn[i]);

		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			if (strlen(szFilter) > 0)
			{
				if (stricmp(g_pPGBlock->m_SynchronousMachineArray[i].szSub, szFilter) != 0)
					continue;
			}
			pListCtrl->InsertItem(nRow, g_pPGBlock->m_SynchronousMachineArray[i].szSub);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szName);

			nRow++;
		}
		break;
	case	BpaFltDev_Load:
		nColNum=sizeof(lpszBpaFltDevColumn)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			pListCtrl->InsertColumn(i, lpszBpaFltDevColumn[i]);

		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		{
			if (g_pPGBlock->m_EnergyConsumerArray[i].fPlanP <= 0)
				continue;

			if (strlen(szFilter) > 0)
			{
				if (stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szSub, szFilter) != 0)
					continue;
			}
			pListCtrl->InsertItem(nRow, g_pPGBlock->m_EnergyConsumerArray[i].szSub);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szName);

			nRow++;
		}
		break;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<nColNum; i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPG2BpaSwiFltDialog::RefreshAllFltList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTDEF_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
	{
		pListCtrl->InsertItem(nRow, g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType]);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType]);
		pListCtrl->SetItemText(nRow, nCol++, g_PG2BpaApi.m_FltDefArray[i].szDevSub);
		pListCtrl->SetItemText(nRow, nCol++, g_PG2BpaApi.m_FltDefArray[i].szDevVolt);
		pListCtrl->SetItemText(nRow, nCol++, g_PG2BpaApi.m_FltDefArray[i].szDevName);
		sprintf(szBuf, "%.1f", g_PG2BpaApi.m_FltDefArray[i].fTCycle);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszBpaFltSetColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPG2BpaSwiFltDialog::RefreshRunFltList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTRUN_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
	{
		if (!g_PG2BpaApi.m_FltDefArray[i].bRunFlt)
			continue;

		pListCtrl->InsertItem(nRow, g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType]);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType]);
		pListCtrl->SetItemText(nRow, nCol++, g_PG2BpaApi.m_FltDefArray[i].szDevSub);
		pListCtrl->SetItemText(nRow, nCol++, g_PG2BpaApi.m_FltDefArray[i].szDevVolt);
		pListCtrl->SetItemText(nRow, nCol++, g_PG2BpaApi.m_FltDefArray[i].szDevName);
		sprintf(szBuf, "%.1f", g_PG2BpaApi.m_FltDefArray[i].fTCycle);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}


	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszBpaFltSetColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPG2BpaSwiFltDialog::OnCbnSelchangeDevtypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CPG2BpaSwiFltDialog::OnBnClickedRefreshPg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	char	szSub[MDB_CHARLEN];
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_SUB_COMBO);
	pCombo->GetWindowText(szSub, MDB_CHARLEN);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pCombo->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	int	nSub=pCombo->FindString(-1, szSub);
	if (nSub != CB_ERR)
		pCombo->SetCurSel(nSub);

	OnCbnSelchangeSubCombo();
}

void CPG2BpaSwiFltDialog::OnCbnSelchangeSubCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshDeviceList();
}

void CPG2BpaSwiFltDialog::OnBnClickedAddFlt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	int		nItem;

	tagBpaFltDefine	fltBuf;
	memset(&fltBuf, 0, sizeof(tagBpaFltDefine));

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTDEF_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);
		for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
		{
			if (stricmp(g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType], pListCtrl->GetItemText(nItem, 0)) == 0 &&
				stricmp(g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType], pListCtrl->GetItemText(nItem, 1)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevSub, pListCtrl->GetItemText(nItem, 2)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevVolt, pListCtrl->GetItemText(nItem, 3)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevName, pListCtrl->GetItemText(nItem, 4)) == 0 &&
				fabs(g_PG2BpaApi.m_FltDefArray[i].fTCycle-atof(pListCtrl->GetItemText(nItem, 5))) < 0.01 )
			{
				memcpy(&fltBuf, &g_PG2BpaApi.m_FltDefArray[i], sizeof(tagBpaFltDefine));
				break;
			}
		}
	}

	UpdateData();

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DEVTYPE_COMBO);
	fltBuf.nDevType = pCombo->GetCurSel();
	if (fltBuf.nDevType == CB_ERR)
	{
		AfxMessageBox("��ȷ���豸����");
		return;
	}

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_DEVICE_LIST);
	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
	{
		AfxMessageBox("��ȷ���¼��豸");
		return;
	}
	nItem=pListCtrl->GetNextSelectedItem(pos);
	if (nItem < 0 || nItem >= pListCtrl->GetItemCount())
	{
		AfxMessageBox("��ȷ���¼��豸");
		return;
	}


	fltBuf.nFltSide=m_nFltSide;
	switch (fltBuf.nDevType)
	{
	case	BpaFltDev_Bus:
		strcpy(fltBuf.szDevSub, pListCtrl->GetItemText(nItem, 0));
		strcpy(fltBuf.szDevVolt, pListCtrl->GetItemText(nItem, 1));
		strcpy(fltBuf.szDevName, pListCtrl->GetItemText(nItem, 2));
		break;
	case	BpaFltDev_Gen:
		strcpy(fltBuf.szDevSub, pListCtrl->GetItemText(nItem, 0));
		strcpy(fltBuf.szDevVolt, pListCtrl->GetItemText(nItem, 1));
		strcpy(fltBuf.szDevName, pListCtrl->GetItemText(nItem, 2));
		break;
	case	BpaFltDev_Load:
		strcpy(fltBuf.szDevSub, pListCtrl->GetItemText(nItem, 0));
		strcpy(fltBuf.szDevVolt, pListCtrl->GetItemText(nItem, 1));
		strcpy(fltBuf.szDevName, pListCtrl->GetItemText(nItem, 2));
		break;
	case	BpaFltDev_Line:
		strcpy(fltBuf.szDevName, pListCtrl->GetItemText(nItem, 0));
		strcpy(fltBuf.szDevVolt, pListCtrl->GetItemText(nItem, 1));
		if (m_nFltSide == 0)
			strcpy(fltBuf.szDevSub, pListCtrl->GetItemText(nItem, 2));
		else
			strcpy(fltBuf.szDevSub, pListCtrl->GetItemText(nItem, 3));
		break;
	case	BpaFltDev_Wind:
		strcpy(fltBuf.szDevSub, pListCtrl->GetItemText(nItem, 0));
		strcpy(fltBuf.szDevName, pListCtrl->GetItemText(nItem, 1));
		if (m_nFltSide == 0)
			strcpy(fltBuf.szDevVolt, pListCtrl->GetItemText(nItem, 2));
		else
			strcpy(fltBuf.szDevVolt, pListCtrl->GetItemText(nItem, 3));
		break;
	}

	CBpaFltSetDialog	dlg;
	dlg.InitFltDefine(&fltBuf);
	if (dlg.DoModal() == IDCANCEL)
		return;

	bExist=0;
	for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
	{
		if (g_PG2BpaApi.m_FltDefArray[i].nFltType == fltBuf.nFltType &&
			g_PG2BpaApi.m_FltDefArray[i].nDevType == fltBuf.nDevType &&
			stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevSub, fltBuf.szDevSub) == 0 &&
			stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevVolt, fltBuf.szDevVolt) == 0 &&
			stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevName, fltBuf.szDevName) == 0 &&
			fabs(g_PG2BpaApi.m_FltDefArray[i].fTCycle-fltBuf.fTCycle) < 0.1)
		{
			bExist=1;
			break;
		}
	}

	if (!bExist)
	{
		//g_PG2BpaApi.m_FltDefArray.push_back(fltBuf);
		g_PG2BpaApi.AddBpaFltDefine(fltBuf);
	}

	RefreshAllFltList();
}

void CPG2BpaSwiFltDialog::OnBnClickedDelFlt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTDEF_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	register int	i;
	int		nItem, nFlt;

	for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
		g_PG2BpaApi.m_FltDefArray[i].bFlag=0;
	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		nFlt=-1;
		for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
		{
			if (stricmp(g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType], pListCtrl->GetItemText(nItem, 0)) == 0 &&
				stricmp(g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType], pListCtrl->GetItemText(nItem, 1)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevSub, pListCtrl->GetItemText(nItem, 2)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevVolt, pListCtrl->GetItemText(nItem, 3)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevName, pListCtrl->GetItemText(nItem, 4)) == 0 &&
				fabs(g_PG2BpaApi.m_FltDefArray[i].fTCycle-atof(pListCtrl->GetItemText(nItem, 5))) < 0.1 )
			{
				nFlt=i;
				break;
			}
		}
		if (nFlt >= 0)
			g_PG2BpaApi.m_FltDefArray[nFlt].bFlag=1;
	}

	nItem=0;
	while (nItem < g_PG2BpaApi.GetBpaFltDefineNum())
	{
		if (g_PG2BpaApi.m_FltDefArray[nItem].bFlag)
			g_PG2BpaApi.DelBpaFltDefine(nItem);
		else
			nItem++;
	}

	RefreshAllFltList();
}

void CPG2BpaSwiFltDialog::OnBnClickedFormFlt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTRUN_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
	{
		AfxMessageBox("���ڹ��ϼ���ȷ������");
		return;
	}

	register int	i;
	int		nFlt;
	int		nItem=pListCtrl->GetNextSelectedItem(pos);
	if (nItem < 0 || nItem >= pListCtrl->GetItemCount())
	{
		AfxMessageBox("���ڹ��ϼ���ȷ������");
		return;
	}

	nFlt=-1;
	for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
	{
		if (stricmp(g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType], pListCtrl->GetItemText(nItem, 0)) == 0 &&
			stricmp(g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType], pListCtrl->GetItemText(nItem, 1)) == 0 &&
			stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevSub, pListCtrl->GetItemText(nItem, 2)) == 0 &&
			stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevVolt, pListCtrl->GetItemText(nItem, 3)) == 0 &&
			stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevName, pListCtrl->GetItemText(nItem, 4)) == 0)
		{
			nFlt=i;
			break;
		}
	}

	if (nFlt < 0)
	{
		AfxMessageBox("���ڹ��ϼ���ȷ������");
		return;
	}

	//memcpy(&g_PGMemDB2Bpa.m_FltDefSet, &g_PGMemDB2Bpa.m_FltDefArray[nFlt], sizeof(tagBpaFltDefine));

	PGMemDBTopo(g_pPGBlock);
	PGMemDBIsland(g_pPGBlock);

// 	char	szLine[256];
// 	for (i=0; i<255; i++)
// 		szLine[i]=' ';
// 	szLine[255]='\0';
// 	if (g_PG2BpaApi.FormFltString(g_pPGBlock, &g_PG2BpaApi.m_FltDefArray[nFlt], szLine))
// 		GetDlgItem(IDC_FLT_LINE)->SetWindowText(szLine);
}

void CPG2BpaSwiFltDialog::OnBnClickedAddRunflt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTDEF_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	register int	i;
	int		nItem, nFlt;
	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		nFlt=-1;
		for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
		{
			if (stricmp(g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType], pListCtrl->GetItemText(nItem, 0)) == 0 &&
				stricmp(g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType], pListCtrl->GetItemText(nItem, 1)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevSub, pListCtrl->GetItemText(nItem, 2)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevVolt, pListCtrl->GetItemText(nItem, 3)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevName, pListCtrl->GetItemText(nItem, 4)) == 0 &&
				fabs(g_PG2BpaApi.m_FltDefArray[i].fTCycle-atof(pListCtrl->GetItemText(nItem, 5))) < 0.01 )
			{
				nFlt=i;
				break;
			}
		}
		if (nFlt >= 0)
			g_PG2BpaApi.m_FltDefArray[nFlt].bRunFlt=1;
	}

	RefreshRunFltList();
}

void CPG2BpaSwiFltDialog::OnBnClickedDelRunflt()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_FLTRUN_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	register int	i;
	int		nItem, nFlt;
	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		nFlt=-1;
		for (i=0; i<g_PG2BpaApi.GetBpaFltDefineNum(); i++)
		{
			if (stricmp(g_lpszBpaFltFltType[g_PG2BpaApi.m_FltDefArray[i].nFltType], pListCtrl->GetItemText(nItem, 0)) == 0 &&
				stricmp(g_lpszBpaFltDevType[g_PG2BpaApi.m_FltDefArray[i].nDevType], pListCtrl->GetItemText(nItem, 1)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevSub, pListCtrl->GetItemText(nItem, 2)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevVolt, pListCtrl->GetItemText(nItem, 3)) == 0 &&
				stricmp(g_PG2BpaApi.m_FltDefArray[i].szDevName, pListCtrl->GetItemText(nItem, 4)) == 0 &&
				fabs(g_PG2BpaApi.m_FltDefArray[i].fTCycle-atof(pListCtrl->GetItemText(nItem, 5))) < 0.01 )
			{
				nFlt=i;
				break;
			}
		}
		if (nFlt >= 0)
			g_PG2BpaApi.m_FltDefArray[nFlt].bRunFlt=0;
	}

	RefreshRunFltList();
}
