// PG2BpaSwiDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "PG2BpaSwiDialog.h"
#include "../../../Common/StringCommon.h"
#include "CurveVisibleSetDialog.h"

// CPG2BpaSwiDialog �Ի���

IMPLEMENT_DYNAMIC(CPG2BpaSwiDialog, CDialog)

CPG2BpaSwiDialog::CPG2BpaSwiDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2BpaSwiDialog::IDD, pParent)
{
	m_fSwiEndDT=300.0;
}

CPG2BpaSwiDialog::~CPG2BpaSwiDialog()
{
}

void CPG2BpaSwiDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_ENDT, m_fSwiEndDT);
}


BEGIN_MESSAGE_MAP(CPG2BpaSwiDialog, CDialog)
	ON_BN_CLICKED(IDC_VIEW_OUT, &CPG2BpaSwiDialog::OnBnClickedViewOut)
	ON_LBN_SELCHANGE(IDC_CURVE_LIST, &CPG2BpaSwiDialog::OnLbnSelchangeCurveList)
	ON_LBN_DBLCLK(IDC_CURVE_LIST, &CPG2BpaSwiDialog::OnLbnDblclkCurveList)
	ON_BN_CLICKED(IDC_CURVE_VISIBLE_SET, &CPG2BpaSwiDialog::OnBnClickedCurveVisibleSet)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CPG2BpaSwiDialog ��Ϣ��������

BOOL CPG2BpaSwiDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CRect	rectBuf;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);
	
	m_wndCurve.Create(NULL, "CurveWindow", WS_CHILD|WS_VISIBLE|WS_BORDER, rectBuf, &m_wndTab, 51);
	m_wndCurve.SetColor(g_clrBackGround, g_clrForeGround, g_clrCurve, g_clrAxias);
	m_wndCurve.SetCurveGrid(g_nXPace, g_nYPace);

	if (!m_wndOutList.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, 54))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndOutList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	m_wndTab.AddTab (&m_wndCurve, _T("�������"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndOutList, _T("����ļ�"),			-1, FALSE);

	RefreshUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void	CPG2BpaSwiDialog::GetPG2BpaSwiSet()
{
	UpdateData();

	g_PG2BpaApi.m_BpaSwiConCard.fENDT=(float)m_fSwiEndDT;
}

void	CPG2BpaSwiDialog::RefreshUI()
{
	m_wndOutList.ResetContent();

	char	szBuf[260];
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	pCombo->ResetContent();
	for (int nIsland=0; nIsland<g_pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (g_pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (g_pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		sprintf(szBuf, "%d\n", nIsland);
		pCombo->AddString(szBuf);
	}
	m_fSwiEndDT=g_PG2BpaApi.m_BpaSwiConCard.fENDT;

	UpdateData(FALSE);

	GetDlgItem(IDC_MAX_CY)->SetWindowText("");
	GetDlgItem(IDC_MIN_CY)->SetWindowText("");
	GetDlgItem(IDC_MAX_DT)->SetWindowText("");
	GetDlgItem(IDC_MIN_DT)->SetWindowText("");

	int		nCurve;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_CURVE_LIST);
	pListBox->ResetContent();
	for (nCurve=0; nCurve<g_PG2BpaApi.GetBpaMonitorCurveNum(); nCurve++)
		pListBox->AddString(g_PG2BpaApi.m_BpaMonitorCurveArray[nCurve].strCurveName.c_str());
}

int CPG2BpaSwiDialog::GetTextLen(const char* lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC *pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(CString(lpszText), (int) strlen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(CString(lpszText), (int) strlen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CPG2BpaSwiDialog::OnBnClickedViewOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		iExt, nIsland=-1;
	char	szOutFile[260], szLine[1024];

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	int			nSel=pCombo->GetCurSel();
	if (nSel == CB_ERR)
		return;

	pCombo->GetLBText(nSel, szLine);
	nIsland=atoi(szLine);

	m_wndOutList.ResetContent();

	sprintf(szOutFile, "%s\\%s%d.out", g_szBpaWorkDir, g_PG2BpaApi.m_BpaDatConCard.szProject, nIsland);
	if (_access(szOutFile, 0) != 0)
		return;

	FILE*	fp=fopen(szOutFile, "r");
	if (fp == NULL)
		return;

	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);

		TrimEnd(szLine);
		TrimRight(szLine);
		if (strlen(szLine) <= 0)
			continue;

		iExt = GetTextLen(szLine);
		if (iExt > m_wndOutList.GetHorizontalExtent())
			m_wndOutList.SetHorizontalExtent(iExt);
		m_wndOutList.AddString(CString(szLine));

	}
	fclose(fp);

	g_PG2BpaApi.PGParseOutFile(g_pPGBlock, g_szBpaWorkDir, nIsland);

	int		nCurve;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_CURVE_LIST);
	pListBox->ResetContent();
	for (nCurve=0; nCurve<g_PG2BpaApi.GetBpaMonitorCurveNum(); nCurve++)
		pListBox->AddString(g_PG2BpaApi.m_BpaMonitorCurveArray[nCurve].strCurveName.c_str());
}

void CPG2BpaSwiDialog::OnLbnSelchangeCurveList()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
}

void CPG2BpaSwiDialog::OnLbnDblclkCurveList()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_CURVE_LIST);
	int		nCurve=pListBox->GetCurSel();
	if (nCurve == LB_ERR)
		return;

	char	szBuffer[260];
	pListBox->GetText(nCurve, szBuffer);

	tagSimpleCurve*	pCurve=g_PG2BpaApi.GetCurve(szBuffer);
	if (pCurve != NULL)
	{
		sprintf(szBuffer, "%.3f", pCurve->fMaxY);	GetDlgItem(IDC_MAX_CY)->SetWindowText(szBuffer);
		sprintf(szBuffer, "%.3f", pCurve->fMinY);	GetDlgItem(IDC_MIN_CY)->SetWindowText(szBuffer);
		sprintf(szBuffer, "%.1f", pCurve->fMaxX);	GetDlgItem(IDC_MAX_DT)->SetWindowText(szBuffer);
		sprintf(szBuffer, "%.1f", pCurve->fMinX);	GetDlgItem(IDC_MIN_DT)->SetWindowText(szBuffer);
		m_wndCurve.SetCurve(pCurve);
	}

	return;
}

void CPG2BpaSwiDialog::OnBnClickedCurveVisibleSet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CCurveVisibleSetDialog	dlg;
	dlg.DoModal();

	m_wndCurve.SetColor(g_clrBackGround, g_clrForeGround, g_clrCurve, g_clrAxias);
	m_wndCurve.SetCurveGrid(g_nXPace, g_nYPace);

	m_wndCurve.Invalidate();
}

void CPG2BpaSwiDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}
