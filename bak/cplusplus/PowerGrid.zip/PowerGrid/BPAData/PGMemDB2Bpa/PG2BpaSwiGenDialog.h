#pragma once

#include "../../../Common/MFCControls/MFCListCtrlEx.h"

// CPG2BpaSwiGenDialog �Ի���
class CPG2BpaSwiGenDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaSwiGenDialog)

public:
	CPG2BpaSwiGenDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaSwiGenDialog();

// �Ի�������
	enum { IDD = IDD_PG2BPASWI_GENDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedCapacityRadio();
	afx_msg void OnNMClickBpagenList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickPggenList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedSetBpagenmodel();
	afx_msg void OnBnClickedUnsetBpagenmodel();
	afx_msg void OnBnClickedRefreshPG();
	afx_msg void OnEnChangeBpabusFilter();
	afx_msg void OnEnChangeBpaworkDir();
	afx_msg void OnBnClickedRefreshBpa();
	DECLARE_MESSAGE_MAP()
private:
	int		m_nGenCapacity;
	int		m_nCurPGGen, m_nCurBpaGen;
	char	m_szBpaBusFilter[MDB_CHARLEN_SHORT];

	CMFCPropertyGridCtrl	m_wndPropertyList;
	CMFCListCtrlEx m_wndBpaGenList;
	CMFCListCtrlEx m_wndPGGenList;

private:
	int		m_nExcModel;
	int		m_nPssModel;
	int		m_nGovModel;
	int		m_nMovModel;

	int		m_nGenIndex;
	int		m_nDampIndex;
	int		m_nExcIndex;
	int		m_nPssIndex;
	int		m_nGovIndex;
	int		m_nSvoIndex;
	int		m_nMovIndex;

	tagBpaSwi_Gen			m_BpaSwi_GenBuffer		;
	tagBpaSwi_Damp			m_BpaSwi_DampBuffer		;
	tagBpaSwi_GenLn			m_BpaSwi_GenLnBuffer	;
	tagBpaSwi_Exc68			m_BpaSwi_Exc68Buffer	;
	tagBpaSwi_Exc81			m_BpaSwi_Exc81Buffer	;
	tagBpaSwi_ExcMV			m_BpaSwi_ExcMVBuffer	;
	tagBpaSwi_FZ			m_BpaSwi_FZBuffer	;
	tagBpaSwi_FCA			m_BpaSwi_FCABuffer	;
	tagBpaSwi_FCB			m_BpaSwi_FCBBuffer	;
	tagBpaSwi_ExcX			m_BpaSwi_ExcXBuffer		;
	tagBpaSwi_PssS			m_BpaSwi_PssSBuffer		;
	tagBpaSwi_PssSH			m_BpaSwi_PssSHBuffer	;
	tagBpaSwi_PssSI			m_BpaSwi_PssSIBuffer	;
	tagBpaSwi_PssSA			m_BpaSwi_PssSABuffer	;
	tagBpaSwi_PssSB			m_BpaSwi_PssSBBuffer	;
	tagBpaSwi_PssST			m_BpaSwi_PssSTBuffer	;
	tagBpaSwi_GovGG			m_BpaSwi_GGBuffer		;
	tagBpaSwi_GovGH			m_BpaSwi_GHBuffer		;
	tagBpaSwi_GovGC			m_BpaSwi_GCBuffer		;
	tagBpaSwi_GovGS			m_BpaSwi_GSBuffer		;
	tagBpaSwi_GovGL			m_BpaSwi_GLBuffer		;
	tagBpaSwi_GovGW			m_BpaSwi_GWBuffer		;
	tagBpaSwi_GovGA			m_BpaSwi_GABuffer		;
	tagBpaSwi_GovGI			m_BpaSwi_GIBuffer		;
	tagBpaSwi_GovGJ			m_BpaSwi_GJBuffer		;
	tagBpaSwi_GovGK			m_BpaSwi_GKBuffer		;
	tagBpaSwi_GovGM			m_BpaSwi_GMBuffer		;
	tagBpaSwi_GovGD			m_BpaSwi_GDBuffer		;
	tagBpaSwi_GovGZ			m_BpaSwi_GZBuffer		;
	tagBpaSwi_MovTA			m_BpaSwi_TABuffer		;
	tagBpaSwi_MovTB			m_BpaSwi_TBBuffer		;
	tagBpaSwi_MovTC			m_BpaSwi_TCBuffer		;
	tagBpaSwi_MovTD			m_BpaSwi_TDBuffer		;
	tagBpaSwi_MovTE			m_BpaSwi_TEBuffer		;
	tagBpaSwi_MovTF			m_BpaSwi_TFBuffer		;
	tagBpaSwi_MovTW			m_BpaSwi_TWBuffer		;

private:
	void	RefreshBpaGenList(void);
	void	RefreshPGGenList(void);
	void	RefreshPGGenParam(void);
	void	RefreshPropertyList();

private:
	void	Mdb2ModelBuffer();
	void	ModelBuffer2Mdb();
	void	ClearModel();

public:
	void	RefreshUI();
};
