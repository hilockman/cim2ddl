// BpaLoadModelSampleDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "BpaLoadModelSampleDialog.h"
#include "../../../Common/String2Double.hpp"


// CBpaLoadModelSampleDialog �Ի���

static	char*	lpszLoadMotorColumn[]=
{
	"����", 
	"�������", 
	"�й�����", 
	"������", 
	"���ӵ���", 
	"���ӵ翹", 
	"���ŵ翹", 
	"ת�ӵ���", 
	"ת�ӵ翹", 
	"A", 
	"B", 
	"MI", 
};

IMPLEMENT_DYNAMIC(CBpaLoadModelSampleDialog, CDialog)

CBpaLoadModelSampleDialog::CBpaLoadModelSampleDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaLoadModelSampleDialog::IDD, pParent)
{

}

CBpaLoadModelSampleDialog::~CBpaLoadModelSampleDialog()
{
}

void CBpaLoadModelSampleDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BPALOADMODEL_SAMPLE_LIST, m_wndLoadModelSampleList);
}


BEGIN_MESSAGE_MAP(CBpaLoadModelSampleDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CBpaLoadModelSampleDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CBpaLoadModelSampleDialog ��Ϣ��������

BOOL CBpaLoadModelSampleDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BPALOADMODEL_SAMPLE_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszLoadMotorColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLoadMotorColumn[i]);

	RefreshBpaLoadModelSampleList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void	CBpaLoadModelSampleDialog::RefreshBpaLoadModelSampleList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BPALOADMODEL_SAMPLE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pBpaBlock->m_nRecordNum[BPA_SWI_MI]; i++)
	{
		sprintf(szBuf, "%s %.1f", g_pBpaBlock->m_BpaSwi_MIArray[i].szBus_Name, g_pBpaBlock->m_BpaSwi_MIArray[i].fBus_kV);
		pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fEmws);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fP);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fMVA);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fRS);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fXS);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fXM);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fRR);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fXR);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fA);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MIArray[i].fB);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, "1");

		nRow++;
	}
	for (i=0; i<g_pBpaBlock->m_nRecordNum[BPA_SWI_ML]; i++)
	{
		sprintf(szBuf, "%s %.1f", g_pBpaBlock->m_BpaSwi_MLArray[i].szBus_Name, g_pBpaBlock->m_BpaSwi_MLArray[i].fBus_kV);
		pListCtrl->InsertItem(nRow, szBuf);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fTJ);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fPper);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fKL);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fRS);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fXS);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fXM);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fRR);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fXR);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fA);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pBpaBlock->m_BpaSwi_MLArray[i].fB);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, "0");

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszLoadMotorColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CBpaLoadModelSampleDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BPALOADMODEL_SAMPLE_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
	{
		AfxMessageBox("��ȷ��ģ��");
		return;
	}
	int		nItem=pListCtrl->GetNextSelectedItem(pos);
	if (nItem < 0 || nItem >= pListCtrl->GetItemCount())
	{
		AfxMessageBox("��ȷ��ģ��");
		return;
	}

	int		nCol=1;
	m_fTJ		=	atof(pListCtrl->GetItemText(nItem, nCol++));		
	m_fPper	=atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fKL	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fRS	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fXS	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fXM	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fRR	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fXR	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fA	=	atof(pListCtrl->GetItemText(nItem, nCol++));	
	m_fB	=	atof(pListCtrl->GetItemText(nItem, nCol++));	

	//m_fPmin=atof(pListCtrl->GetItemText(nItem, nCol++));	
	//m_fVI=atof(pListCtrl->GetItemText(nItem, nCol++));	
	//m_fTI=atof(pListCtrl->GetItemText(nItem, nCol++));	
	OnOK();
}
