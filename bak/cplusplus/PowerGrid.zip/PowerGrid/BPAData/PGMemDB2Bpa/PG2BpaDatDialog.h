#pragma once

#include "../../../Common/MFCControls/MFCListCtrlEx.h"

// CPG2BpaDatDialog �Ի���

class CPG2BpaDatDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaDatDialog)

public:
	CPG2BpaDatDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaDatDialog();

// �Ի�������
	enum { IDD = IDD_PG2BPADAT_DIALOG };
	int		m_nDecoupledNum;
	int		m_nNewtonNum;
	double	m_fToleranceBusV;
	double	m_fToleranceAiPower;
	double	m_fToleranceQ;
	int		m_nAIControl;
	int		m_nRptSort;
	int		m_nAnalysisRpt;

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedViewPfo();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrlEx	m_wndListBus, m_wndListLine, m_wndListTran;
	CListBox		m_wndPfoList;

private:
	void	RefreshPFBusList();
	void	RefreshPFLineList();
	void	RefreshPFTranList();
	int		GetTextLen(const char* lpszText);

public:
	void	GetPG2BpaDatSet();
	void	RefreshUI();
};
