// CurveVisibleSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "CurveVisibleSetDialog.h"


// CCurveVisibleSetDialog �Ի���

IMPLEMENT_DYNAMIC(CCurveVisibleSetDialog, CDialog)

CCurveVisibleSetDialog::CCurveVisibleSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CCurveVisibleSetDialog::IDD, pParent)
{

}

CCurveVisibleSetDialog::~CCurveVisibleSetDialog()
{
}

void CCurveVisibleSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BACKGROUND, m_btnBackColor);
	DDX_Control(pDX, IDC_FOREGROUND, m_btnForeColor);
	DDX_Control(pDX, IDC_CURVE, m_btnCurveColor);
	DDX_Control(pDX, IDC_AXIAS, m_btnAxiasColor);
}


BEGIN_MESSAGE_MAP(CCurveVisibleSetDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCurveVisibleSetDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CCurveVisibleSetDialog ��Ϣ��������

BOOL CCurveVisibleSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_btnBackColor.EnableAutomaticButton(_T("Automatic"), g_clrBackGround);
	m_btnBackColor.EnableOtherButton(_T("����"));
	m_btnBackColor.SetColor(g_clrBackGround);
	m_btnBackColor.SetColumnsNumber(10);

	m_btnForeColor.EnableAutomaticButton(_T("Automatic"), g_clrForeGround);
	m_btnForeColor.EnableOtherButton(_T("����"));
	m_btnForeColor.SetColor(g_clrForeGround);
	m_btnForeColor.SetColumnsNumber(10);

	m_btnCurveColor.EnableAutomaticButton(_T("Automatic"), g_clrCurve);
	m_btnCurveColor.EnableOtherButton(_T("����"));
	m_btnCurveColor.SetColor(g_clrCurve);
	m_btnCurveColor.SetColumnsNumber(10);

	m_btnAxiasColor.EnableAutomaticButton(_T("Automatic"), g_clrAxias);
	m_btnAxiasColor.EnableOtherButton(_T("����"));
	m_btnAxiasColor.SetColor(g_clrAxias);
	m_btnAxiasColor.SetColumnsNumber(10);

	char	szBuf[260];
	sprintf(szBuf, "%d", g_nXPace);	GetDlgItem(IDC_XPACE)->SetWindowText(szBuf);
	sprintf(szBuf, "%d", g_nYPace);	GetDlgItem(IDC_YPACE)->SetWindowText(szBuf);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CCurveVisibleSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];
	g_clrBackGround=m_btnBackColor.GetColor();
	g_clrForeGround=m_btnForeColor.GetColor();
	g_clrCurve=m_btnCurveColor.GetColor();
	g_clrAxias=m_btnAxiasColor.GetColor();
	GetDlgItem(IDC_XPACE)->GetWindowText(szBuf, 260);	g_nXPace=atoi(szBuf);
	GetDlgItem(IDC_YPACE)->GetWindowText(szBuf, 260);	g_nYPace=atoi(szBuf);

	if (g_nXPace < 2)	g_nXPace=2;
	if (g_nYPace < 2)	g_nYPace=2;
	SaveIni();

	OnOK();
}
