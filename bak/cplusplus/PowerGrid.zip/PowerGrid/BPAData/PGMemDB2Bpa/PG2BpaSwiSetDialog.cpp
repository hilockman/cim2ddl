// PG2BpaSwiSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "PG2BpaSwiSetDialog.h"


// CPG2BpaSwiSetDialog �Ի���
static	char*	lpszColumn[]=
{
	("����"),
	("��ֵ"),
	("����"),
	("����"),
};

static	char*	g_lpszGenModelArray[]=
{
	"MC",
	"MF",
	"MG",
};

static	char*	lpszPGGenColumn[]=
{
	"��վ",
	"��ѹ�ȼ�",
	"����",
	"����й�",
	"����޹�",
	"BPAģ�ͷ����ĸ��",
	"BPAģ�ͷ������ѹ",
};

static	char*	lpszBpaGenColumn[]=
{
	"�����ĸ��",
	"��ѹ",
	"�����",
	"�����ģ��",
	"����ģ��",
	"PSSģ��",
	"����ģ��",
	"�ŷ�ģ��",
	"ԭ����ģ��",
};

static	int		m_nGenCapacityArray[]=
{
	0,		100,
	100,	200,
	200,	300,
	300,	400,
	400,	600,
	600,	800,
	800,	999999,
};

IMPLEMENT_DYNAMIC(CPG2BpaSwiSetDialog, CDialog)

CPG2BpaSwiSetDialog::CPG2BpaSwiSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2BpaSwiSetDialog::IDD, pParent)
{
	m_nGenCapacity=0;
	m_nCurBpaGen=m_nCurPGGen=-1;
	memset(m_szBpaBusFilter, 0, MDB_CHARLEN_SHORT);

	ClearModel();
}

CPG2BpaSwiSetDialog::~CPG2BpaSwiSetDialog()
{
}

void CPG2BpaSwiSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_CAPACITY_ALL_RADIO, m_nGenCapacity);
	DDX_Control(pDX, IDC_BPAGEN_LIST, m_wndBpaGenList);
	DDX_Control(pDX, IDC_PGGEN_LIST, m_wndPGGenList);
}


BEGIN_MESSAGE_MAP(CPG2BpaSwiSetDialog, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_BPAGEN_LIST, &CPG2BpaSwiSetDialog::OnNMClickBpagenList)
	ON_NOTIFY(NM_CLICK, IDC_PGGEN_LIST, &CPG2BpaSwiSetDialog::OnNMClickPggenList)
	ON_BN_CLICKED(IDC_CAPACITY_ALL_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_100_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_200_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_300_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_400_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_600_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_800_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_CAPACITY_1000_RADIO, &CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio)
	ON_BN_CLICKED(IDC_SET_BPAGENMODEL, &CPG2BpaSwiSetDialog::OnBnClickedSetBpagenmodel)
	ON_BN_CLICKED(IDC_UNSET_BPAGENMODEL, &CPG2BpaSwiSetDialog::OnBnClickedUnsetBpagenmodel)
	ON_BN_CLICKED(IDC_REFRESH_PG, &CPG2BpaSwiSetDialog::OnBnClickedRefreshPG)
	ON_BN_CLICKED(IDC_SAVE_MODELSET, &CPG2BpaSwiSetDialog::OnBnClickedSaveModelset)
	ON_EN_CHANGE(IDC_BPABUS_FILTER, &CPG2BpaSwiSetDialog::OnEnChangeBpabusFilter)
	ON_BN_CLICKED(IDC_LOAD_MODELSET, &CPG2BpaSwiSetDialog::OnBnClickedLoadModelset)
	ON_BN_CLICKED(IDC_REFRESH_BPA, &CPG2BpaSwiSetDialog::OnBnClickedRefreshBpa)
END_MESSAGE_MAP()


// CPG2BpaSwiSetDialog ��Ϣ��������

BOOL CPG2BpaSwiSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;

	m_wndPGGenList.SetExtendedStyle(m_wndPGGenList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndPGGenList.DeleteAllItems();
	while (m_wndPGGenList.DeleteColumn(0));
	for (i=0; i<sizeof(lpszPGGenColumn)/sizeof(char*); i++)
		m_wndPGGenList.InsertColumn(i, lpszPGGenColumn[i]);


	m_wndBpaGenList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndBpaGenList.SetExtendedStyle(m_wndBpaGenList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndBpaGenList.DeleteAllItems();
	while (m_wndBpaGenList.DeleteColumn(0));
	for (i=0; i<sizeof(lpszBpaGenColumn)/sizeof(char*); i++)
		m_wndBpaGenList.InsertColumn(i, lpszBpaGenColumn[i]);

	RefreshUI();

	CRect	rectDummy;
	GetDlgItem(IDC_MODEL_PROPERTY)->GetWindowRect (&rectDummy);
	ScreenToClient (&rectDummy);
	if (!m_wndPropertyList.Create(WS_VISIBLE | WS_CHILD | WS_BORDER, rectDummy, this, 1))
	{
		TRACE(_T("δ�ܴ�����������\n"));
		return FALSE;      // δ�ܴ���
	}

	HDITEM	hdi;
	char	szBuffer[260];

	hdi.mask = HDI_TEXT;
	hdi.pszText = szBuffer;
	hdi.cchTextMax = 260;

	m_wndPropertyList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndPropertyList.EnableHeaderCtrl(TRUE);
	m_wndPropertyList.EnableDescriptionArea(FALSE);
	m_wndPropertyList.SetVSDotNetLook(TRUE);
	m_wndPropertyList.MarkModifiedProperties(TRUE);
	m_wndPropertyList.SetShowDragContext(FALSE);
	for (i=0; i<m_wndPropertyList.GetHeaderCtrl().GetItemCount(); i++)
	{
		m_wndPropertyList.GetHeaderCtrl().GetItem(i, &hdi);
		strcpy(hdi.pszText,lpszColumn[i]);
		m_wndPropertyList.GetHeaderCtrl().SetItem(i, &hdi);
	}
	m_wndPropertyList.RemoveAll();

	RefreshPropertyList();

	if (strlen(g_szBpaSwiFile) > 0)
	{
		if (_access(g_szBpaSwiFile, 0) == 0)
		{
			BpaParseInputFiles(g_pBpaBlock, NULL, g_szBpaSwiFile, 0);
			RefreshBpaGenList();
		}
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPG2BpaSwiSetDialog::ClearModel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_nExcModel=m_nPssModel=m_nGovModel=m_nMovModel=-1;
	m_nGenIndex=m_nExcIndex=m_nPssIndex=m_nGovIndex=m_nSvoIndex=m_nMovIndex=-1;

	memset(&m_BpaSwi_GenBuffer		, 0, sizeof(tagBpaSwi_Gen		));
	memset(&m_BpaSwi_GenLnBuffer	, 0, sizeof(tagBpaSwi_GenLn		));

	memset(&m_BpaSwi_Excit68Buffer	, 0, sizeof(tagBpaSwi_Excit68	));
	memset(&m_BpaSwi_Excit81Buffer	, 0, sizeof(tagBpaSwi_Excit81	));
	memset(&m_BpaSwi_ExcitMVBuffer	, 0, sizeof(tagBpaSwi_ExcitMV	));
	memset(&m_BpaSwi_ExcitXBuffer	, 0, sizeof(tagBpaSwi_ExcitX	));

	memset(&m_BpaSwi_PSSSBuffer		, 0, sizeof(tagBpaSwi_PSSS		));
	memset(&m_BpaSwi_PSSSH1Buffer	, 0, sizeof(tagBpaSwi_PSSSH1	));
	memset(&m_BpaSwi_PSSSH2Buffer	, 0, sizeof(tagBpaSwi_PSSSH2	));
	memset(&m_BpaSwi_PSSSIBuffer	, 0, sizeof(tagBpaSwi_PSSSI		));
	memset(&m_BpaSwi_PSSSABuffer	, 0, sizeof(tagBpaSwi_PSSSA		));
	memset(&m_BpaSwi_PSSSBBuffer	, 0, sizeof(tagBpaSwi_PSSSB		));
	memset(&m_BpaSwi_PSSSTBuffer	, 0, sizeof(tagBpaSwi_PSSST		));

	memset(&m_BpaSwi_GGBuffer		, 0, sizeof(tagBpaSwi_GG		));
	memset(&m_BpaSwi_GHBuffer		, 0, sizeof(tagBpaSwi_GH		));
	memset(&m_BpaSwi_GCBuffer		, 0, sizeof(tagBpaSwi_GC		));
	memset(&m_BpaSwi_GSBuffer		, 0, sizeof(tagBpaSwi_GS		));
	memset(&m_BpaSwi_GLBuffer		, 0, sizeof(tagBpaSwi_GL		));
	memset(&m_BpaSwi_GWBuffer		, 0, sizeof(tagBpaSwi_GW		));
	memset(&m_BpaSwi_GABuffer		, 0, sizeof(tagBpaSwi_GA		));
	memset(&m_BpaSwi_GIBuffer		, 0, sizeof(tagBpaSwi_GI		));
	memset(&m_BpaSwi_GJBuffer		, 0, sizeof(tagBpaSwi_GJ		));
	memset(&m_BpaSwi_GKBuffer		, 0, sizeof(tagBpaSwi_GK		));
	memset(&m_BpaSwi_GMBuffer		, 0, sizeof(tagBpaSwi_GM		));
	memset(&m_BpaSwi_GDBuffer		, 0, sizeof(tagBpaSwi_GD		));
	memset(&m_BpaSwi_GZBuffer		, 0, sizeof(tagBpaSwi_GZ		));

	memset(&m_BpaSwi_TABuffer		, 0, sizeof(tagBpaSwi_TA		));
	memset(&m_BpaSwi_TBBuffer		, 0, sizeof(tagBpaSwi_TB		));
	memset(&m_BpaSwi_TCBuffer		, 0, sizeof(tagBpaSwi_TC		));
	memset(&m_BpaSwi_TDBuffer		, 0, sizeof(tagBpaSwi_TD		));
	memset(&m_BpaSwi_TEBuffer		, 0, sizeof(tagBpaSwi_TE		));
	memset(&m_BpaSwi_TFBuffer		, 0, sizeof(tagBpaSwi_TF		));
	memset(&m_BpaSwi_TWBuffer		, 0, sizeof(tagBpaSwi_TW		));
}

void CPG2BpaSwiSetDialog::RefreshPGGenList(void)
{
	int		nRow,nCol,nGen;
	char	szBuf[260];

	m_wndPGGenList.DeleteAllItems();

	nRow=0;
	for (nGen=0; nGen<(int)g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nGen++)
	{
		m_wndPGGenList.InsertItem(nRow, g_pPGBlock->m_SynchronousMachineArray[nGen].szSub);		m_wndPGGenList.SetItemData(nRow,nRow);

		nCol=1;
		m_wndPGGenList.SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nGen].szVolt);
		m_wndPGGenList.SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nGen].szName);

		sprintf(szBuf,"%f",g_pPGBlock->m_SynchronousMachineArray[nGen].fPMax);	m_wndPGGenList.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%f",g_pPGBlock->m_SynchronousMachineArray[nGen].fQMax);	m_wndPGGenList.SetItemText(nRow, nCol++, szBuf);

		m_wndPGGenList.SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nGen].szBpaGenBus);
		sprintf(szBuf,"%f",g_pPGBlock->m_SynchronousMachineArray[nGen].fBpaGenVolt);	m_wndPGGenList.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPGGenColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndPGGenList.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndPGGenList.GetColumnWidth(nCol);
		m_wndPGGenList.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndPGGenList.GetColumnWidth(nCol);

		m_wndPGGenList.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

	if (m_nCurPGGen >= 0 && m_nCurPGGen < m_wndPGGenList.GetItemCount())
	{
		m_wndPGGenList.SetItemState(m_nCurPGGen,LVIS_SELECTED, 0xffff);
		m_wndPGGenList.EnsureVisible(m_nCurPGGen, FALSE);
	}
}

void CPG2BpaSwiSetDialog::RefreshBpaGenList(void)
{

	int		nRow,nCol,nGen;
	int		nExcModel,nPssModel,nGovModel,nMovModel;
	int		nGenIndex,nExcIndex,nPssIndex,nGovIndex,nSvoIndex,nMovIndex;
	char	szBuf[260];

	m_wndBpaGenList.DeleteAllItems();

	nRow=0;
	for (nGen=0; nGen<(int)g_pBpaBlock->m_nRecordNum[BPA_SWI_GEN]; nGen++)
	{
		if (strlen(m_szBpaBusFilter) > 0)
		{
			if (strstr(g_pBpaBlock->m_BpaSwi_GenArray[nGen].szBus_Name, m_szBpaBusFilter) == NULL)
				continue;
		}

		BpaResolveModel(g_pBpaBlock, g_pBpaBlock->m_BpaSwi_GenArray[nGen].szBus_Name, g_pBpaBlock->m_BpaSwi_GenArray[nGen].fBus_kV,nGenIndex,
			nExcModel, nExcIndex, nPssModel, nPssIndex, nGovModel, nGovIndex, nSvoIndex, nMovModel, nMovIndex);

		if (m_nGenCapacity > 0 && m_nGenCapacity <= sizeof(m_nGenCapacityArray)/sizeof(int)/2)
		{
			if (g_pBpaBlock->m_BpaSwi_GenArray[nGen].fMVA < m_nGenCapacityArray[2*(m_nGenCapacity-1)] ||
				g_pBpaBlock->m_BpaSwi_GenArray[nGen].fMVA >= m_nGenCapacityArray[2*(m_nGenCapacity-1)+1])
				continue;
		}

		m_wndBpaGenList.InsertItem(nRow, g_pBpaBlock->m_BpaSwi_GenArray[nGen].szBus_Name);		m_wndBpaGenList.SetItemData(nRow,nRow);

		nCol=1;
		sprintf(szBuf,"%.2f",g_pBpaBlock->m_BpaSwi_GenArray[nGen].fBus_kV);		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf,"%.2f",g_pBpaBlock->m_BpaSwi_GenArray[nGen].fMVA);		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);

		m_wndBpaGenList.SetItemText(nRow, nCol++, g_pBpaBlock->m_BpaSwi_GenArray[nGen].szCardKey);

		memset(szBuf,0,260);
		if (nExcModel > 0 && nExcIndex >= 0)
			BpaGetRecordValue(g_pBpaBlock, nExcModel, BpaGetFieldIndex(nExcModel, "CardKey"), nExcIndex, szBuf);
		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (nPssModel > 0 && nPssIndex >= 0)
			BpaGetRecordValue(g_pBpaBlock, nPssModel, BpaGetFieldIndex(nPssModel, "CardKey"), nPssIndex, szBuf);
		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (nGovModel >= 0 && nGovIndex >= 0)
			BpaGetRecordValue(g_pBpaBlock, nGovModel, BpaGetFieldIndex(nGovModel, "CardKey"), nGovIndex, szBuf);
		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (nSvoIndex >= 0)
			BpaGetRecordValue(g_pBpaBlock, BPA_SWI_GA, BpaGetFieldIndex(BPA_SWI_GA, "CardKey"), nSvoIndex, szBuf);
		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (nMovModel > 0 && nMovIndex >= 0)
			BpaGetRecordValue(g_pBpaBlock, nMovModel, BpaGetFieldIndex(nMovModel, "CardKey"), nMovIndex, szBuf);
		m_wndBpaGenList.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBpaGenColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndBpaGenList.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndBpaGenList.GetColumnWidth(nCol);
		m_wndBpaGenList.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndBpaGenList.GetColumnWidth(nCol);

		m_wndBpaGenList.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPG2BpaSwiSetDialog::Mdb2ModelBuffer()
{
	ClearModel();

	char	szName[32], szVolt[16];
	if (m_nCurBpaGen < 0 || m_nCurBpaGen >= m_wndBpaGenList.GetItemCount())
		return;

	strcpy(szName, m_wndBpaGenList.GetItemText(m_nCurBpaGen, 0));
	strcpy(szVolt, m_wndBpaGenList.GetItemText(m_nCurBpaGen, 1));
	BpaResolveModel(g_pBpaBlock, szName, (float)atof(szVolt),
		m_nGenIndex, m_nExcModel, m_nExcIndex, m_nPssModel, m_nPssIndex,
		m_nGovModel, m_nGovIndex, m_nSvoIndex, m_nMovModel, m_nMovIndex);

	if (m_nGenIndex >= 0)
		memcpy(&m_BpaSwi_GenBuffer, &g_pBpaBlock->m_BpaSwi_GenArray[m_nGenIndex], sizeof(tagBpaSwi_Gen));

	if (m_nExcIndex >= 0)
	{
		switch (m_nExcModel)
		{
		case BPA_SWI_EXCIT68:	memcpy(&m_BpaSwi_Excit68Buffer,	&g_pBpaBlock->m_BpaSwi_Excit68Array[m_nExcIndex],	sizeof(tagBpaSwi_Excit68));	break;
		case BPA_SWI_EXCIT81:	memcpy(&m_BpaSwi_Excit81Buffer,	&g_pBpaBlock->m_BpaSwi_Excit81Array[m_nExcIndex],	sizeof(tagBpaSwi_Excit81));	break;
		case BPA_SWI_EXCITMV:	memcpy(&m_BpaSwi_ExcitMVBuffer,	&g_pBpaBlock->m_BpaSwi_ExcitMVArray[m_nExcIndex],	sizeof(tagBpaSwi_ExcitMV));	break;
		case BPA_SWI_EXCITX:	memcpy(&m_BpaSwi_ExcitXBuffer,	&g_pBpaBlock->m_BpaSwi_ExcitXArray[m_nExcIndex],	sizeof(tagBpaSwi_ExcitX));	break;
		}
	}

	if (m_nPssIndex >= 0)
	{
		switch (m_nPssModel)
		{
		case BPA_SWI_PSSS:		memcpy(&m_BpaSwi_PSSSBuffer,	&g_pBpaBlock->m_BpaSwi_PSSSArray[m_nPssIndex],	sizeof(tagBpaSwi_PSSS));	break;
		case BPA_SWI_PSSSH1:	memcpy(&m_BpaSwi_PSSSH1Buffer,	&g_pBpaBlock->m_BpaSwi_PSSSH1Array[m_nPssIndex],sizeof(tagBpaSwi_PSSSH1));	break;
		case BPA_SWI_PSSSH2:	memcpy(&m_BpaSwi_PSSSH2Buffer,	&g_pBpaBlock->m_BpaSwi_PSSSH2Array[m_nPssIndex],sizeof(tagBpaSwi_PSSSH2));	break;
		case BPA_SWI_PSSSI:		memcpy(&m_BpaSwi_PSSSIBuffer,	&g_pBpaBlock->m_BpaSwi_PSSSIArray[m_nPssIndex],	sizeof(tagBpaSwi_PSSSI));	break;
		case BPA_SWI_PSSSA:		memcpy(&m_BpaSwi_PSSSABuffer,	&g_pBpaBlock->m_BpaSwi_PSSSAArray[m_nPssIndex],	sizeof(tagBpaSwi_PSSSA));	break;
		case BPA_SWI_PSSSB:		memcpy(&m_BpaSwi_PSSSBBuffer,	&g_pBpaBlock->m_BpaSwi_PSSSBArray[m_nPssIndex],	sizeof(tagBpaSwi_PSSSB));	break;
		case BPA_SWI_PSSST:		memcpy(&m_BpaSwi_PSSSTBuffer,	&g_pBpaBlock->m_BpaSwi_PSSSTArray[m_nPssIndex],	sizeof(tagBpaSwi_PSSST));	break;
		}
	}

	if (m_nGovIndex >= 0)
	{
		switch (m_nGovModel)
		{
		case BPA_SWI_GG:	memcpy(&m_BpaSwi_GGBuffer,	&g_pBpaBlock->m_BpaSwi_GGArray[m_nGovIndex], sizeof(tagBpaSwi_GG));	break;
		case BPA_SWI_GH:	memcpy(&m_BpaSwi_GHBuffer,	&g_pBpaBlock->m_BpaSwi_GHArray[m_nGovIndex], sizeof(tagBpaSwi_GH));	break;
		case BPA_SWI_GC:	memcpy(&m_BpaSwi_GCBuffer,	&g_pBpaBlock->m_BpaSwi_GCArray[m_nGovIndex], sizeof(tagBpaSwi_GC));	break;
		case BPA_SWI_GS:	memcpy(&m_BpaSwi_GSBuffer,	&g_pBpaBlock->m_BpaSwi_GSArray[m_nGovIndex], sizeof(tagBpaSwi_GS));	break;
		case BPA_SWI_GL:	memcpy(&m_BpaSwi_GLBuffer,	&g_pBpaBlock->m_BpaSwi_GLArray[m_nGovIndex], sizeof(tagBpaSwi_GL));	break;
		case BPA_SWI_GW:	memcpy(&m_BpaSwi_GWBuffer,	&g_pBpaBlock->m_BpaSwi_GWArray[m_nGovIndex], sizeof(tagBpaSwi_GW));	break;
		case BPA_SWI_GI:	memcpy(&m_BpaSwi_GIBuffer,	&g_pBpaBlock->m_BpaSwi_GIArray[m_nGovIndex], sizeof(tagBpaSwi_GI));	break;
		case BPA_SWI_GJ:	memcpy(&m_BpaSwi_GJBuffer,	&g_pBpaBlock->m_BpaSwi_GJArray[m_nGovIndex], sizeof(tagBpaSwi_GJ));	break;
		case BPA_SWI_GK:	memcpy(&m_BpaSwi_GKBuffer,	&g_pBpaBlock->m_BpaSwi_GKArray[m_nGovIndex], sizeof(tagBpaSwi_GK));	break;
		case BPA_SWI_GM:	memcpy(&m_BpaSwi_GMBuffer,	&g_pBpaBlock->m_BpaSwi_GMArray[m_nGovIndex], sizeof(tagBpaSwi_GM));	break;
		case BPA_SWI_GD:	memcpy(&m_BpaSwi_GDBuffer,	&g_pBpaBlock->m_BpaSwi_GDArray[m_nGovIndex], sizeof(tagBpaSwi_GD));	break;
		case BPA_SWI_GZ:	memcpy(&m_BpaSwi_GZBuffer,	&g_pBpaBlock->m_BpaSwi_GZArray[m_nGovIndex], sizeof(tagBpaSwi_GZ));	break;
		}
	}

	if (m_nSvoIndex >= 0)
		memcpy(&m_BpaSwi_GABuffer, &g_pBpaBlock->m_BpaSwi_GAArray[m_nSvoIndex], sizeof(tagBpaSwi_GA));

	if (m_nMovIndex >= 0)
	{
		switch (m_nMovModel)
		{
		case BPA_SWI_TA:	memcpy(&m_BpaSwi_TABuffer,	&g_pBpaBlock->m_BpaSwi_TAArray[m_nMovIndex], sizeof(tagBpaSwi_TA));	break;
		case BPA_SWI_TB:	memcpy(&m_BpaSwi_TBBuffer,	&g_pBpaBlock->m_BpaSwi_TBArray[m_nMovIndex], sizeof(tagBpaSwi_TB));	break;
		case BPA_SWI_TC:	memcpy(&m_BpaSwi_TCBuffer,	&g_pBpaBlock->m_BpaSwi_TCArray[m_nMovIndex], sizeof(tagBpaSwi_TC));	break;
		case BPA_SWI_TD:	memcpy(&m_BpaSwi_TDBuffer,	&g_pBpaBlock->m_BpaSwi_TDArray[m_nMovIndex], sizeof(tagBpaSwi_TD));	break;
		case BPA_SWI_TE:	memcpy(&m_BpaSwi_TEBuffer,	&g_pBpaBlock->m_BpaSwi_TEArray[m_nMovIndex], sizeof(tagBpaSwi_TE));	break;
		case BPA_SWI_TF:	memcpy(&m_BpaSwi_TFBuffer,	&g_pBpaBlock->m_BpaSwi_TFArray[m_nMovIndex], sizeof(tagBpaSwi_TF));	break;
		case BPA_SWI_TW:	memcpy(&m_BpaSwi_TWBuffer,	&g_pBpaBlock->m_BpaSwi_TWArray[m_nMovIndex], sizeof(tagBpaSwi_TW));	break;
		}
	}
}

void CPG2BpaSwiSetDialog::ModelBuffer2Mdb()
{
	char	szName[32], szVolt[16];
	if (m_nCurBpaGen < 0 || m_nCurBpaGen >= m_wndBpaGenList.GetItemCount())
		return;

	strcpy(szName, m_wndBpaGenList.GetItemText(m_nCurBpaGen, 0));
	strcpy(szVolt, m_wndBpaGenList.GetItemText(m_nCurBpaGen, 1));
	BpaResolveModel(g_pBpaBlock, szName, (float)atof(szVolt),
		m_nGenIndex, m_nExcModel, m_nExcIndex, m_nPssModel, m_nPssIndex,
		m_nGovModel, m_nGovIndex, m_nSvoIndex, m_nMovModel, m_nMovIndex);

	if (m_nGenIndex < 0)
		return;

	memcpy(&g_pBpaBlock->m_BpaSwi_GenArray[m_nGenIndex], &m_BpaSwi_GenBuffer, sizeof(tagBpaSwi_Gen));

	if (m_nExcIndex >= 0)
	{
		switch (m_nExcModel)
		{
		case BPA_SWI_EXCIT68:	memcpy(&g_pBpaBlock->m_BpaSwi_Excit68Array[m_nExcIndex],	&m_BpaSwi_Excit68Buffer,	sizeof(tagBpaSwi_Excit68));	break;
		case BPA_SWI_EXCIT81:	memcpy(&g_pBpaBlock->m_BpaSwi_Excit81Array[m_nExcIndex],	&m_BpaSwi_Excit81Buffer,	sizeof(tagBpaSwi_Excit81));	break;
		case BPA_SWI_EXCITMV:	memcpy(&g_pBpaBlock->m_BpaSwi_ExcitMVArray[m_nExcIndex],	&m_BpaSwi_ExcitMVBuffer,	sizeof(tagBpaSwi_ExcitMV));	break;
		case BPA_SWI_EXCITX:	memcpy(&g_pBpaBlock->m_BpaSwi_ExcitXArray[m_nExcIndex],		&m_BpaSwi_ExcitXBuffer,		sizeof(tagBpaSwi_ExcitX));	break;
		}
	}

	if (m_nPssIndex >= 0)
	{
		switch (m_nPssModel)
		{
		case BPA_SWI_PSSS:		memcpy(&g_pBpaBlock->m_BpaSwi_PSSSArray[m_nPssIndex],	&m_BpaSwi_PSSSBuffer,	sizeof(tagBpaSwi_PSSS));	break;
		case BPA_SWI_PSSSH1:	memcpy(&g_pBpaBlock->m_BpaSwi_PSSSH1Array[m_nPssIndex],	&m_BpaSwi_PSSSH1Buffer,	sizeof(tagBpaSwi_PSSSH1));	break;
		case BPA_SWI_PSSSH2:	memcpy(&g_pBpaBlock->m_BpaSwi_PSSSH2Array[m_nPssIndex],	&m_BpaSwi_PSSSH2Buffer,	sizeof(tagBpaSwi_PSSSH2));	break;
		case BPA_SWI_PSSSI:		memcpy(&g_pBpaBlock->m_BpaSwi_PSSSIArray[m_nPssIndex],	&m_BpaSwi_PSSSIBuffer,	sizeof(tagBpaSwi_PSSSI));	break;
		case BPA_SWI_PSSSA:		memcpy(&g_pBpaBlock->m_BpaSwi_PSSSAArray[m_nPssIndex],	&m_BpaSwi_PSSSABuffer,	sizeof(tagBpaSwi_PSSSA));	break;
		case BPA_SWI_PSSSB:		memcpy(&g_pBpaBlock->m_BpaSwi_PSSSBArray[m_nPssIndex],	&m_BpaSwi_PSSSBBuffer,	sizeof(tagBpaSwi_PSSSB));	break;
		case BPA_SWI_PSSST:		memcpy(&g_pBpaBlock->m_BpaSwi_PSSSTArray[m_nPssIndex],	&m_BpaSwi_PSSSTBuffer,	sizeof(tagBpaSwi_PSSST));	break;
		}
	}

	if (m_nGovIndex >= 0)
	{
		switch (m_nGovModel)
		{
		case BPA_SWI_GG:	memcpy(&g_pBpaBlock->m_BpaSwi_GGArray[m_nGovIndex], &m_BpaSwi_GGBuffer,	sizeof(tagBpaSwi_GG));	break;
		case BPA_SWI_GH:	memcpy(&g_pBpaBlock->m_BpaSwi_GHArray[m_nGovIndex], &m_BpaSwi_GHBuffer,	sizeof(tagBpaSwi_GH));	break;
		case BPA_SWI_GC:	memcpy(&g_pBpaBlock->m_BpaSwi_GCArray[m_nGovIndex], &m_BpaSwi_GCBuffer,	sizeof(tagBpaSwi_GC));	break;
		case BPA_SWI_GS:	memcpy(&g_pBpaBlock->m_BpaSwi_GSArray[m_nGovIndex], &m_BpaSwi_GSBuffer,	sizeof(tagBpaSwi_GS));	break;
		case BPA_SWI_GL:	memcpy(&g_pBpaBlock->m_BpaSwi_GLArray[m_nGovIndex], &m_BpaSwi_GLBuffer,	sizeof(tagBpaSwi_GL));	break;
		case BPA_SWI_GW:	memcpy(&g_pBpaBlock->m_BpaSwi_GWArray[m_nGovIndex], &m_BpaSwi_GWBuffer,	sizeof(tagBpaSwi_GW));	break;
		case BPA_SWI_GI:	memcpy(&g_pBpaBlock->m_BpaSwi_GIArray[m_nGovIndex], &m_BpaSwi_GIBuffer,	sizeof(tagBpaSwi_GI));	break;
		case BPA_SWI_GJ:	memcpy(&g_pBpaBlock->m_BpaSwi_GJArray[m_nGovIndex], &m_BpaSwi_GJBuffer,	sizeof(tagBpaSwi_GJ));	break;
		case BPA_SWI_GK:	memcpy(&g_pBpaBlock->m_BpaSwi_GKArray[m_nGovIndex], &m_BpaSwi_GKBuffer,	sizeof(tagBpaSwi_GK));	break;
		case BPA_SWI_GM:	memcpy(&g_pBpaBlock->m_BpaSwi_GMArray[m_nGovIndex], &m_BpaSwi_GMBuffer,	sizeof(tagBpaSwi_GM));	break;
		case BPA_SWI_GD:	memcpy(&g_pBpaBlock->m_BpaSwi_GDArray[m_nGovIndex], &m_BpaSwi_GDBuffer,	sizeof(tagBpaSwi_GD));	break;
		case BPA_SWI_GZ:	memcpy(&g_pBpaBlock->m_BpaSwi_GZArray[m_nGovIndex], &m_BpaSwi_GZBuffer,	sizeof(tagBpaSwi_GZ));	break;
		}
	}

	if (m_nSvoIndex >= 0)
		memcpy(&g_pBpaBlock->m_BpaSwi_GAArray[m_nSvoIndex], &m_BpaSwi_GABuffer, sizeof(tagBpaSwi_GA));

	if (m_nMovIndex >= 0)
	{
		switch (m_nMovModel)
		{
		case BPA_SWI_TA:	memcpy(&g_pBpaBlock->m_BpaSwi_TAArray[m_nMovIndex], &m_BpaSwi_TABuffer,	sizeof(tagBpaSwi_TA));	break;
		case BPA_SWI_TB:	memcpy(&g_pBpaBlock->m_BpaSwi_TBArray[m_nMovIndex], &m_BpaSwi_TBBuffer,	sizeof(tagBpaSwi_TB));	break;
		case BPA_SWI_TC:	memcpy(&g_pBpaBlock->m_BpaSwi_TCArray[m_nMovIndex], &m_BpaSwi_TCBuffer,	sizeof(tagBpaSwi_TC));	break;
		case BPA_SWI_TD:	memcpy(&g_pBpaBlock->m_BpaSwi_TDArray[m_nMovIndex], &m_BpaSwi_TDBuffer,	sizeof(tagBpaSwi_TD));	break;
		case BPA_SWI_TE:	memcpy(&g_pBpaBlock->m_BpaSwi_TEArray[m_nMovIndex], &m_BpaSwi_TEBuffer,	sizeof(tagBpaSwi_TE));	break;
		case BPA_SWI_TF:	memcpy(&g_pBpaBlock->m_BpaSwi_TFArray[m_nMovIndex], &m_BpaSwi_TFBuffer,	sizeof(tagBpaSwi_TF));	break;
		case BPA_SWI_TW:	memcpy(&g_pBpaBlock->m_BpaSwi_TWArray[m_nMovIndex], &m_BpaSwi_TWBuffer,	sizeof(tagBpaSwi_TW));	break;
		}
	}
}

void CPG2BpaSwiSetDialog::RefreshPropertyList()
{
	register int	i;
	int		nField,nEnumNum;
	char	szValue[MDB_CHARLEN_LONG],szName[MDB_CHARLEN],szDescr[MDB_CHARLEN_LONG];
	CMFCPropertyGridProperty* pProp;

	Mdb2ModelBuffer();

	char*	pGenDataPtr=NULL;
	char*	pExcDataPtr=NULL;
	char*	pPssDataPtr=NULL;
	char*	pGovDataPtr=NULL;
	char*	pSvoDataPtr=NULL;
	char*	pMovDataPtr=NULL;

	pGenDataPtr=(char*)&m_BpaSwi_GenBuffer;

	switch (m_nExcModel)
	{
	case BPA_SWI_EXCIT68:	pExcDataPtr=(char*)&m_BpaSwi_Excit68Buffer;	break;
	case BPA_SWI_EXCIT81:	pExcDataPtr=(char*)&m_BpaSwi_Excit81Buffer;	break;
	case BPA_SWI_EXCITMV:	pExcDataPtr=(char*)&m_BpaSwi_ExcitMVBuffer;	break;
	case BPA_SWI_EXCITX:	pExcDataPtr=(char*)&m_BpaSwi_ExcitXBuffer;	break;
	}

	switch (m_nPssModel)
	{
	case BPA_SWI_PSSS:		pPssDataPtr=(char*)&m_BpaSwi_PSSSBuffer		;	break;
	case BPA_SWI_PSSSH1:	pPssDataPtr=(char*)&m_BpaSwi_PSSSH1Buffer	;	break;
	case BPA_SWI_PSSSH2:	pPssDataPtr=(char*)&m_BpaSwi_PSSSH2Buffer	;	break;
	case BPA_SWI_PSSSI:		pPssDataPtr=(char*)&m_BpaSwi_PSSSIBuffer	;	break;
	case BPA_SWI_PSSSA:		pPssDataPtr=(char*)&m_BpaSwi_PSSSABuffer	;	break;
	case BPA_SWI_PSSSB:		pPssDataPtr=(char*)&m_BpaSwi_PSSSBBuffer	;	break;
	case BPA_SWI_PSSST:		pPssDataPtr=(char*)&m_BpaSwi_PSSSTBuffer	;	break;
	}

	switch (m_nGovModel)
	{
	case BPA_SWI_GG:	pGovDataPtr=(char*)&m_BpaSwi_GGBuffer;	break;
	case BPA_SWI_GH:	pGovDataPtr=(char*)&m_BpaSwi_GHBuffer;	break;
	case BPA_SWI_GC:	pGovDataPtr=(char*)&m_BpaSwi_GCBuffer;	break;
	case BPA_SWI_GS:	pGovDataPtr=(char*)&m_BpaSwi_GSBuffer;	break;
	case BPA_SWI_GL:	pGovDataPtr=(char*)&m_BpaSwi_GLBuffer;	break;
	case BPA_SWI_GW:	pGovDataPtr=(char*)&m_BpaSwi_GWBuffer;	break;
	case BPA_SWI_GI:	pGovDataPtr=(char*)&m_BpaSwi_GIBuffer;	break;
	case BPA_SWI_GJ:	pGovDataPtr=(char*)&m_BpaSwi_GJBuffer;	break;
	case BPA_SWI_GK:	pGovDataPtr=(char*)&m_BpaSwi_GKBuffer;	break;
	case BPA_SWI_GM:	pGovDataPtr=(char*)&m_BpaSwi_GMBuffer;	break;
	case BPA_SWI_GD:	pGovDataPtr=(char*)&m_BpaSwi_GDBuffer;	break;
	case BPA_SWI_GZ:	pGovDataPtr=(char*)&m_BpaSwi_GZBuffer;	break;
	}

	if (m_nSvoIndex >= 0)
		pSvoDataPtr=(char*)&m_BpaSwi_GABuffer;

	switch (m_nMovModel)
	{
	case BPA_SWI_TA:	pMovDataPtr=(char*)&m_BpaSwi_TABuffer;	break;
	case BPA_SWI_TB:	pMovDataPtr=(char*)&m_BpaSwi_TBBuffer;	break;
	case BPA_SWI_TC:	pMovDataPtr=(char*)&m_BpaSwi_TCBuffer;	break;
	case BPA_SWI_TD:	pMovDataPtr=(char*)&m_BpaSwi_TDBuffer;	break;
	case BPA_SWI_TE:	pMovDataPtr=(char*)&m_BpaSwi_TEBuffer;	break;
	case BPA_SWI_TF:	pMovDataPtr=(char*)&m_BpaSwi_TFBuffer;	break;
	case BPA_SWI_TW:	pMovDataPtr=(char*)&m_BpaSwi_TWBuffer;	break;
	}

	m_wndPropertyList.RemoveAll();

	CMFCPropertyGridProperty* pGrpGen = new CMFCPropertyGridProperty(_T("�����"));
	CMFCPropertyGridProperty* pGrpExc = new CMFCPropertyGridProperty(_T("����"));
	CMFCPropertyGridProperty* pGrpPss = new CMFCPropertyGridProperty(_T("PSS"));
	CMFCPropertyGridProperty* pGrpGov = new CMFCPropertyGridProperty(_T("������"));
	CMFCPropertyGridProperty* pGrpSvo = new CMFCPropertyGridProperty(_T("�ŷ���"));
	CMFCPropertyGridProperty* pGrpMov = new CMFCPropertyGridProperty(_T("ԭ����"));

	if (pGenDataPtr)
	{
		for (nField=0; nField<BpaGetTableFieldNum(BPA_SWI_GEN); nField++)
		{
			memset(szValue,0,MDB_CHARLEN_LONG);

			BpaGetDataPtrFieldValue(BPA_SWI_GEN, nField, pGenDataPtr, szValue);
			sprintf(szDescr,"%s[Len=%d]", BpaGetFieldName(BPA_SWI_GEN, nField), BpaGetFieldLen(BPA_SWI_GEN,nField));
			pProp=new CMFCPropertyGridProperty(_T(BpaGetFieldDesp(BPA_SWI_GEN, nField)), (_variant_t) _T(szValue), _T(szDescr), nField);
			pProp->AllowEdit(TRUE);

			nEnumNum=BpaGetFieldEnumNum(BPA_SWI_GEN,nField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				pProp->AddOption(_T(""));
				for (i=0; i<nEnumNum; i++)
				{
					BpaGetFieldEnumName(BPA_SWI_GEN, nField, i, szName);
					pProp->AddOption(szName);
				}
				pProp->AllowEdit(FALSE);
			}
			if (nField == BpaGetFieldIndex(BPA_SWI_GEN, "CardKey") ||
				nField == BpaGetFieldIndex(BPA_SWI_GEN, "ACBus_Name") ||
				nField == BpaGetFieldIndex(BPA_SWI_GEN, "ACBus_kV") ||
				nField == BpaGetFieldIndex(BPA_SWI_GEN, "Gen_ID") ||
				nField == BpaGetFieldIndex(BPA_SWI_GEN, "Gen_iRBus"))
				pProp->AllowEdit(FALSE);
			pGrpGen->AddSubItem(pProp);
		}
	}

	if (pExcDataPtr && m_nExcModel > 0)
	{
		for (nField=0; nField<BpaGetTableFieldNum(m_nExcModel); nField++)
		{
			memset(szValue,0,MDB_CHARLEN_LONG);

			BpaGetDataPtrFieldValue(m_nExcModel, nField, pExcDataPtr, szValue);

			sprintf(szDescr,"%s[Len=%d]", BpaGetFieldName(m_nExcModel,nField), BpaGetFieldLen(m_nExcModel, nField));
			pProp=new CMFCPropertyGridProperty(_T(BpaGetFieldDesp(m_nExcModel,nField)), (_variant_t) _T(szValue), _T(szDescr), nField);
			pProp->AllowEdit(TRUE);

			nEnumNum=BpaGetFieldEnumNum(m_nExcModel,nField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				pProp->AddOption(_T(""));
				for (i=0; i<nEnumNum; i++)
				{
					BpaGetFieldEnumName(m_nExcModel,nField,i,szName);
					pProp->AddOption(szName);
				}
				pProp->AllowEdit(FALSE);
			}
			if (nField == BpaGetFieldIndex(m_nExcModel, "CardKey") ||
				nField == BpaGetFieldIndex(m_nExcModel, "ACBus_Name") ||
				nField == BpaGetFieldIndex(m_nExcModel, "ACBus_kV") ||
				nField == BpaGetFieldIndex(m_nExcModel, "Gen_ID") ||
				nField == BpaGetFieldIndex(m_nExcModel, "Gen_iRBus"))
				pProp->AllowEdit(FALSE);
			pGrpExc->AddSubItem(pProp);
		}
	}

	if (pPssDataPtr && m_nPssModel > 0)
	{
		for (nField=0; nField<BpaGetTableFieldNum(m_nPssModel); nField++)
		{
			memset(szValue,0,MDB_CHARLEN_LONG);
			BpaGetDataPtrFieldValue(m_nPssModel, nField, pPssDataPtr, szValue);
			sprintf(szDescr,"%s[Len=%d]",BpaGetFieldName(m_nPssModel,nField),BpaGetFieldLen(m_nPssModel,nField));
			pProp=new CMFCPropertyGridProperty(_T(BpaGetFieldDesp(m_nPssModel,nField)),(_variant_t) _T(szValue), _T(szDescr), nField);
			pProp->AllowEdit(TRUE);

			nEnumNum=BpaGetFieldEnumNum(m_nPssModel,nField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				pProp->AddOption(_T(""));
				for (i=0; i<nEnumNum; i++)
				{
					BpaGetFieldEnumName(m_nPssModel,nField,i,szName);
					pProp->AddOption(szName);
				}
				pProp->AllowEdit(FALSE);
			}
			if (nField == BpaGetFieldIndex(m_nPssModel, "CardKey") ||
				nField == BpaGetFieldIndex(m_nPssModel, "ACBus_Name") ||
				nField == BpaGetFieldIndex(m_nPssModel, "ACBus_kV") ||
				nField == BpaGetFieldIndex(m_nPssModel, "Gen_ID") ||
				nField == BpaGetFieldIndex(m_nPssModel, "Gen_iRBus"))
				pProp->AllowEdit(FALSE);
			pGrpPss->AddSubItem(pProp);
		}
	}

	if (pGovDataPtr && m_nGovModel > 0)
	{
		for (nField=0; nField<BpaGetTableFieldNum(m_nGovModel); nField++)
		{
			memset(szValue,0,MDB_CHARLEN_LONG);
			BpaGetDataPtrFieldValue(m_nGovModel, nField, pGovDataPtr, szValue);
			sprintf(szDescr,"%s[Len=%d]",BpaGetFieldName(m_nGovModel,nField),BpaGetFieldLen(m_nGovModel,nField));
			pProp=new CMFCPropertyGridProperty(_T(BpaGetFieldDesp(m_nGovModel,nField)),(_variant_t) _T(szValue), _T(szDescr), nField);
			pProp->AllowEdit(TRUE);

			nEnumNum=BpaGetFieldEnumNum(m_nGovModel,nField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				pProp->AddOption(_T(""));
				for (i=0; i<nEnumNum; i++)
				{
					BpaGetFieldEnumName(m_nGovModel,nField,i,szName);
					pProp->AddOption(szName);
				}
				pProp->AllowEdit(FALSE);
			}
			if (nField == BpaGetFieldIndex(m_nGovModel, "CardKey") ||
				nField == BpaGetFieldIndex(m_nGovModel, "ACBus_Name") ||
				nField == BpaGetFieldIndex(m_nGovModel, "ACBus_kV") ||
				nField == BpaGetFieldIndex(m_nGovModel, "Gen_ID") ||
				nField == BpaGetFieldIndex(m_nGovModel, "Gen_iRBus"))
				pProp->AllowEdit(FALSE);
			pGrpGov->AddSubItem(pProp);
		}
	}

	if (pSvoDataPtr && (m_nGovModel == BPA_SWI_GI || m_nGovModel == BPA_SWI_GJ || m_nGovModel == BPA_SWI_GK || m_nGovModel == BPA_SWI_GM))
	{
		for (nField=0; nField<BpaGetTableFieldNum(BPA_SWI_GA); nField++)
		{
			memset(szValue,0,MDB_CHARLEN_LONG);
			BpaGetDataPtrFieldValue(BPA_SWI_GA, nField, pSvoDataPtr, szValue);
			sprintf(szDescr,"%s[Len=%d]",BpaGetFieldName(BPA_SWI_GA,nField),BpaGetFieldLen(BPA_SWI_GA,nField));
			pProp=new CMFCPropertyGridProperty(_T(BpaGetFieldDesp(BPA_SWI_GA,nField)),(_variant_t) _T(szValue), _T(szDescr), nField);
			pProp->AllowEdit(TRUE);

			nEnumNum=BpaGetFieldEnumNum(BPA_SWI_GA,nField);
			if (nEnumNum > 0)
			{
				pProp->RemoveAllOptions();
				pProp->AddOption(_T(""));
				for (i=0; i<nEnumNum; i++)
				{
					BpaGetFieldEnumName(BPA_SWI_GA,nField,i,szName);
					pProp->AddOption(szName);
				}
				pProp->AllowEdit(FALSE);
			}
			if (nField == BpaGetFieldIndex(BPA_SWI_GA, "CardKey") ||
				nField == BpaGetFieldIndex(BPA_SWI_GA, "ACBus_Name") ||
				nField == BpaGetFieldIndex(BPA_SWI_GA, "ACBus_kV") ||
				nField == BpaGetFieldIndex(BPA_SWI_GA, "Gen_ID") ||
				nField == BpaGetFieldIndex(BPA_SWI_GA, "Gen_iRBus"))
				pProp->AllowEdit(FALSE);
			pGrpSvo->AddSubItem(pProp);
		}
	}

	if (pMovDataPtr && m_nMovModel > 0)
	{
		if (m_nGovModel != BPA_SWI_GG && m_nGovModel != BPA_SWI_GH && m_nGovModel != BPA_SWI_GC)
		{
			for (nField=0; nField<BpaGetTableFieldNum(m_nGovModel); nField++)
			{
				memset(szValue,0,MDB_CHARLEN_LONG);
				BpaGetDataPtrFieldValue(m_nGovModel, nField, pMovDataPtr, szValue);
				sprintf(szDescr,"%s[Len=%d]",BpaGetFieldName(m_nGovModel,nField),BpaGetFieldLen(m_nGovModel,nField));
				pProp=new CMFCPropertyGridProperty(_T(BpaGetFieldDesp(m_nGovModel,nField)),(_variant_t) _T(szValue), _T(szDescr), nField);
				pProp->AllowEdit(TRUE);

				nEnumNum=BpaGetFieldEnumNum(m_nGovModel,nField);
				if (nEnumNum > 0)
				{
					pProp->RemoveAllOptions();
					pProp->AddOption(_T(""));
					for (i=0; i<nEnumNum; i++)
					{
						BpaGetFieldEnumName(m_nGovModel,nField,i,szName);
						pProp->AddOption(szName);
					}
					pProp->AllowEdit(FALSE);
				}
				if (nField == BpaGetFieldIndex(m_nGovModel, "CardKey") ||
					nField == BpaGetFieldIndex(m_nGovModel, "ACBus_Name") ||
					nField == BpaGetFieldIndex(m_nGovModel, "ACBus_kV") ||
					nField == BpaGetFieldIndex(m_nGovModel, "Gen_ID") ||
					nField == BpaGetFieldIndex(m_nGovModel, "Gen_iRBus"))
					pProp->AllowEdit(FALSE);
				pGrpMov->AddSubItem(pProp);
			}
		}
	}

	pGrpGen->Expand(TRUE);
	pGrpExc->Expand(TRUE);
	pGrpPss->Expand(TRUE);
	pGrpGov->Expand(TRUE);
	pGrpSvo->Expand(TRUE);
	pGrpMov->Expand(TRUE);

	m_wndPropertyList.AddProperty(pGrpGen);
	m_wndPropertyList.AddProperty(pGrpExc);
	m_wndPropertyList.AddProperty(pGrpPss);
	m_wndPropertyList.AddProperty(pGrpGov);
	m_wndPropertyList.AddProperty(pGrpSvo);
	m_wndPropertyList.AddProperty(pGrpMov);
}

void CPG2BpaSwiSetDialog::OnNMClickBpagenList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (pNMItemActivate->iItem != -1)
	{
		m_nCurBpaGen=pNMItemActivate->iItem;
		if (m_nCurBpaGen >= 0 && m_nCurBpaGen < m_wndBpaGenList.GetItemCount())
			RefreshPropertyList();
	}
	*pResult = 0;
}

void CPG2BpaSwiSetDialog::OnNMClickPggenList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (pNMItemActivate->iItem != -1)
	{
		m_nCurPGGen=pNMItemActivate->iItem;
	}
	*pResult = 0;
}

void CPG2BpaSwiSetDialog::OnBnClickedCapacityRadio()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	RefreshBpaGenList();
}

void CPG2BpaSwiSetDialog::OnBnClickedSetBpagenmodel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nGen;
	char	szBpaBus[MDB_CHARLEN], szBpaVolt[MDB_CHARLEN];

	if (m_nCurBpaGen < 0 || m_nCurBpaGen >= m_wndBpaGenList.GetItemCount())
		return;
	strcpy(szBpaBus, m_wndBpaGenList.GetItemText(m_nCurBpaGen, 0));
	strcpy(szBpaVolt, m_wndBpaGenList.GetItemText(m_nCurBpaGen, 1));

	int		nItem;
	char	szRestrict[MaxRestrict][MDB_CHARLEN_LONG];
	for (i=0; i<MaxRestrict; i++)
		memset(szRestrict[i], 0, MDB_CHARLEN_LONG);
	POSITION pos = m_wndPGGenList.GetFirstSelectedItemPosition();
	if (!pos)
		return;

	while (pos)
	{
		nItem=m_wndPGGenList.GetNextSelectedItem(pos);
		strcpy(szRestrict[0], m_wndPGGenList.GetItemText(nItem, 0));
		strcpy(szRestrict[1], m_wndPGGenList.GetItemText(nItem, 1));
		strcpy(szRestrict[2], m_wndPGGenList.GetItemText(nItem, 2));
		nGen=PGFindRecordbyKey(g_pPGBlock, PG_SYNCHRONOUSMACHINE, szRestrict);
		if (nGen >= 0)
		{
			strcpy(g_pPGBlock->m_SynchronousMachineArray[nGen].szBpaGenBus, szBpaBus);
			g_pPGBlock->m_SynchronousMachineArray[nGen].fBpaGenVolt=(float)atof(szBpaVolt);
		}
	}
	RefreshPGGenList();
}

void CPG2BpaSwiSetDialog::OnBnClickedUnsetBpagenmodel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nItem, nGen;
	char	szRestrict[MaxRestrict][MDB_CHARLEN_LONG];

	POSITION pos = m_wndPGGenList.GetFirstSelectedItemPosition();
	if (!pos)
		return;

	for (i=0; i<MaxRestrict; i++)
		memset(szRestrict[i], 0, MDB_CHARLEN_LONG);
	while (pos)
	{
		nItem=m_wndPGGenList.GetNextSelectedItem(pos);
		strcpy(szRestrict[0], m_wndPGGenList.GetItemText(m_nCurPGGen, 0));
		strcpy(szRestrict[1], m_wndPGGenList.GetItemText(m_nCurPGGen, 1));
		strcpy(szRestrict[2], m_wndPGGenList.GetItemText(m_nCurPGGen, 2));
		nGen=PGFindRecordbyKey(g_pPGBlock, PG_SYNCHRONOUSMACHINE, szRestrict);
		if (nGen >= 0)
		{
			memset(g_pPGBlock->m_SynchronousMachineArray[nGen].szBpaGenBus, 0, PGGetFieldLen(PG_SYNCHRONOUSMACHINE, PG_SYNCHRONOUSMACHINE_BPA_GENBUS));
			g_pPGBlock->m_SynchronousMachineArray[nGen].fBpaGenVolt=0;
		}
	}
	RefreshPGGenList();
}

void	CPG2BpaSwiSetDialog::RefreshUI()
{
	RefreshBpaGenList();
	RefreshPGGenList();
}

void CPG2BpaSwiSetDialog::OnBnClickedRefreshBpa()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshBpaGenList();
}

void CPG2BpaSwiSetDialog::OnBnClickedRefreshPG()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPGGenList();
}

void CPG2BpaSwiSetDialog::OnBnClickedSaveModelset()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("set");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("�����ģ�������ļ�(*.set)|*.set;*.SET|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪷����ģ�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	int	nGen;
	tagGenModePG2Bpa	mBuf;

	g_GenModelPG2BpaArray.clear();
	for (nGen=0; nGen<g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nGen++)
	{
		if (strlen(g_pPGBlock->m_SynchronousMachineArray[nGen].szBpaGenBus) <= 0 || g_pPGBlock->m_SynchronousMachineArray[nGen].fBpaGenVolt <= 0)
			continue;

		strcpy(mBuf.szPGSub, g_pPGBlock->m_SynchronousMachineArray[nGen].szSub);
		strcpy(mBuf.szPGVolt, g_pPGBlock->m_SynchronousMachineArray[nGen].szVolt);
		strcpy(mBuf.szPGName, g_pPGBlock->m_SynchronousMachineArray[nGen].szName);

		strcpy(mBuf.szBpaBus, g_pPGBlock->m_SynchronousMachineArray[nGen].szBpaGenBus);
		mBuf.fBpaVolt=g_pPGBlock->m_SynchronousMachineArray[nGen].fBpaGenVolt;

		g_GenModelPG2BpaArray.push_back(mBuf);
	}

	register int	i;
	FILE*	fp=fopen(dlg.GetPathName(),"w");
	if (fp != NULL)
	{
		for (i=0; i<(int)g_GenModelPG2BpaArray.size(); i++)
			fprintf(fp,"GenModelPG2Bpa[%d]=%s\\%s\\%s\\%s\\%f\n",i+1,g_GenModelPG2BpaArray[i].szPGSub, g_GenModelPG2BpaArray[i].szPGVolt, g_GenModelPG2BpaArray[i].szPGName, g_GenModelPG2BpaArray[i].szBpaBus, g_GenModelPG2BpaArray[i].fBpaVolt);
		fprintf(fp,"[END]\n");

		fflush(fp);
		fclose(fp);

	}
}

void CPG2BpaSwiSetDialog::OnBnClickedLoadModelset()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("set");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("�����ģ�������ļ�(*.set)|*.set;*.SET|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪷����ģ�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_GenModelPG2BpaArray.clear();

	tagGenModePG2Bpa	mBuf;
	std::vector<std::string>	strEleArray;
	char*	lpszToken;
	char	szLine[1024];
	FILE*	fp=fopen(dlg.GetPathName(), "r");
	if (fp != NULL)
	{
		while (!feof(fp))
		{
			memset(szLine,0,1024);
			fgets(szLine,1024,fp);

			memset(&mBuf, 0, sizeof(tagGenModePG2Bpa));

			strEleArray.clear();
			lpszToken=strtok(szLine,"\\ \t\n=");
			while (lpszToken != NULL)
			{
				strEleArray.push_back(lpszToken);
				lpszToken=strtok(NULL,"\\ \t\n=");
			}

			if (strEleArray.size() >= 6)
			{
				strcpy(mBuf.szPGSub, strEleArray[1].c_str());
				strcpy(mBuf.szPGVolt, strEleArray[2].c_str());
				strcpy(mBuf.szPGName, strEleArray[3].c_str());
				strcpy(mBuf.szBpaBus, strEleArray[4].c_str());
				mBuf.fBpaVolt=(float)atof(strEleArray[5].c_str());

				g_GenModelPG2BpaArray.push_back(mBuf);
			}
		}

		fclose(fp);

		SetPGGenBpaModel();
	}
}

void CPG2BpaSwiSetDialog::SetPGGenBpaModel()
{
	register int	i;
	int		nGen;
	char	szRestrict[MaxRestrict][MDB_CHARLEN_LONG];

	for (i=0; i<MaxRestrict; i++)
		memset(szRestrict[i], 0, MDB_CHARLEN_LONG);
	for (i=0; i<(int)g_GenModelPG2BpaArray.size(); i++)
	{
		strcpy(szRestrict[0], g_GenModelPG2BpaArray[i].szPGSub);
		strcpy(szRestrict[1], g_GenModelPG2BpaArray[i].szPGVolt);
		strcpy(szRestrict[2], g_GenModelPG2BpaArray[i].szPGName);

		nGen=PGFindRecordbyKey(g_pPGBlock, PG_SYNCHRONOUSMACHINE, szRestrict);
		if (nGen >= 0)
		{
			strcpy(g_pPGBlock->m_SynchronousMachineArray[nGen].szBpaGenBus, g_GenModelPG2BpaArray[i].szBpaBus);
			g_pPGBlock->m_SynchronousMachineArray[nGen].fBpaGenVolt=g_GenModelPG2BpaArray[i].fBpaVolt;
		}
	}
	RefreshPGGenList();
}

void CPG2BpaSwiSetDialog::OnEnChangeBpabusFilter()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	GetDlgItem(IDC_BPABUS_FILTER)->GetWindowText(m_szBpaBusFilter, MDB_CHARLEN_SHORT);
	RefreshBpaGenList();
}
