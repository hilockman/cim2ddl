#pragma once
#include "afxwin.h"
#include "../../../Common/MFCControls/SimpleCurveWnd.h"

// CPG2BpaSwiDialog �Ի���

class CPG2BpaSwiDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaSwiDialog)

public:
	CPG2BpaSwiDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaSwiDialog();

// �Ի�������
	enum { IDD = IDD_PG2BPASWI_DIALOG };
	double m_fSwiEndDT;

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedViewOut();
	afx_msg void OnLbnSelchangeCurveList();
	afx_msg void OnLbnDblclkCurveList();
	afx_msg void OnBnClickedCurveVisibleSet();
	DECLARE_MESSAGE_MAP()
public:
	void GetPG2BpaSwiSet();
	void RefreshUI();

private:
	CMFCTabCtrl		m_wndTab;
	CSimpleCurveWnd	m_wndCurve;
	CListBox		m_wndOutList;
private:
	int GetTextLen(const char* lpszText);
public:
};
