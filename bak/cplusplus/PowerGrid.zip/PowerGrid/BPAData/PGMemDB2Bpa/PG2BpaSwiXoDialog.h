#pragma once
#include "afxcmn.h"

#include "../../../Common/MFCControls/MFCListCtrlEx.h"

// CPG2BpaSwiXoDialog �Ի���

class CPG2BpaSwiXoDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaSwiXoDialog)

public:
	CPG2BpaSwiXoDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaSwiXoDialog();

// �Ի�������
	enum { IDD = IDD_PG2BPASWI_XODIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnNMClickTranXoList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickLineLoList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedSetXo();
	afx_msg void OnBnClickedSetLo();
	afx_msg void OnBnClickedRefreshPg();
	DECLARE_MESSAGE_MAP()
private:
	void	RefreshTranXOList();
	void	RefreshTranXOParam();

	void	RefreshLineLOList();
	void	RefreshLineLOParam();
private:
	int m_nWindType;
	BOOL m_bNeutralGnd;
private:
	CMFCListCtrlEx m_wndListTran;
	CMFCListCtrlEx m_wndListLine;

public:
	void RefreshUI();
};
