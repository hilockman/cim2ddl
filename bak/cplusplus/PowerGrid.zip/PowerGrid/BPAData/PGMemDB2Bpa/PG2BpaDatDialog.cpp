// PG2BpaDatDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "PG2BpaDatDialog.h"
#include "../../../Common/StringCommon.h"

// CPG2BpaDatDialog �Ի���

static	char*	lpszPFBusColumn[]=
{
	"��վ", 
	"��ѹ�ȼ�", 
	"����", 
	"ĸ��", 
	"��ѹ(kV)", 
	"����(��)", 
};

static	char*	lpszPFLineColumn[]=
{
	"����", 
	"��ѹ�ȼ�", 
	"��վ", 
	"�ճ�վ", 
	"��ĸ��", 
	"��ĸ��", 
	"���й�", 
	"���޹�", 
	"���й�", 
	"���޹�", 
	"����й�", 
	"����޹�", 
};

static	char*	lpszPFTranColumn[]=
{
	"��վ", 
	"����", 
	"��ѹ�ȼ�", 
	"��ѹ�ȼ�", 
	"��ĸ��", 
	"��ĸ��", 
	"���й�", 
	"���޹�", 
	"���й�", 
	"���޹�", 
	"����й�", 
	"����޹�", 
};

IMPLEMENT_DYNAMIC(CPG2BpaDatDialog, CDialog)

CPG2BpaDatDialog::CPG2BpaDatDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2BpaDatDialog::IDD, pParent)
{

}

CPG2BpaDatDialog::~CPG2BpaDatDialog()
{
}

void CPG2BpaDatDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_DECOUPLED_NUM, m_nDecoupledNum);
	DDX_Text(pDX, IDC_NEWTON_NUM, m_nNewtonNum);
	DDX_Text(pDX, IDC_TOLERANE_BUSV, m_fToleranceBusV);
	DDX_Text(pDX, IDC_TOLERANE_AIPOWER, m_fToleranceAiPower);
	DDX_Text(pDX, IDC_TOLERANE_Q, m_fToleranceQ);
	DDX_Radio(pDX, IDC_AI_CON, m_nAIControl);
	DDX_Radio(pDX, IDC_RPT_SORT_BUS, m_nRptSort);
	DDX_Radio(pDX, IDC_ANALYSIS_RPT_1, m_nAnalysisRpt);
}


BEGIN_MESSAGE_MAP(CPG2BpaDatDialog, CDialog)
	ON_BN_CLICKED(IDC_VIEW_PFO, &CPG2BpaDatDialog::OnBnClickedViewPfo)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CPG2BpaDatDialog ��Ϣ��������

BOOL CPG2BpaDatDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int		nColumn;
	CRect	rectBuf;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 11))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListBus.SetExtendedStyle(m_wndListBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFBusColumn)/sizeof(char*); nColumn++)
		m_wndListBus.InsertColumn(nColumn, lpszPFBusColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 12))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLine.SetExtendedStyle(m_wndListLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFLineColumn)/sizeof(char*); nColumn++)
		m_wndListLine.InsertColumn(nColumn, lpszPFLineColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndListTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 13))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListTran.SetExtendedStyle(m_wndListTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (nColumn=0; nColumn<sizeof(lpszPFTranColumn)/sizeof(char*); nColumn++)
		m_wndListTran.InsertColumn(nColumn, lpszPFTranColumn[nColumn],	LVCFMT_LEFT,	100);

	if (!m_wndPfoList.Create(LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL | WS_BORDER, rectBuf, &m_wndTab, 14))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndPfoList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	m_wndTab.AddTab (&m_wndListBus, _T("ĸ��"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndListLine, _T("������·"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListTran, _T("��ѹ������"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndPfoList, _T("����������Ϣ"),	-1, FALSE);

	RefreshUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void	CPG2BpaDatDialog::GetPG2BpaDatSet()
{
	UpdateData();
	g_PG2BpaApi.m_BpaDatConCard.nDecoupledNum			=m_nDecoupledNum;
	g_PG2BpaApi.m_BpaDatConCard.nNewtonNum			=m_nNewtonNum;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceAIPower	=(float)m_fToleranceAiPower;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceBusV		=(float)m_fToleranceBusV;
	g_PG2BpaApi.m_BpaDatConCard.fToleranceQ			=(float)m_fToleranceQ;
	g_PG2BpaApi.m_BpaDatConCard.nAIControl			=m_nAIControl;
	g_PG2BpaApi.m_BpaDatConCard.nRptSort				=m_nRptSort;
	g_PG2BpaApi.m_BpaDatConCard.nAnalysisRpt			=m_nAnalysisRpt;
}

void	CPG2BpaDatDialog::RefreshUI()
{
	m_nDecoupledNum		=g_PG2BpaApi.m_BpaDatConCard.nDecoupledNum;
	m_nNewtonNum		=g_PG2BpaApi.m_BpaDatConCard.nNewtonNum;
	m_fToleranceAiPower	=g_PG2BpaApi.m_BpaDatConCard.fToleranceAIPower;
	m_fToleranceBusV	=g_PG2BpaApi.m_BpaDatConCard.fToleranceBusV;
	m_fToleranceQ		=g_PG2BpaApi.m_BpaDatConCard.fToleranceQ;
	m_nAIControl		=g_PG2BpaApi.m_BpaDatConCard.nAIControl;
	m_nRptSort			=g_PG2BpaApi.m_BpaDatConCard.nRptSort;
	m_nAnalysisRpt		=g_PG2BpaApi.m_BpaDatConCard.nAnalysisRpt;

	RefreshPFBusList();
	RefreshPFLineList();
	RefreshPFTranList();
	m_wndPfoList.ResetContent();

	char	szBuf[260];
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	pCombo->ResetContent();
	for (int nIsland=0; nIsland<g_pPGBlock->m_nRecordNum[PG_ISLAND]; nIsland++)
	{
		if (g_pPGBlock->m_IslandArray[nIsland].bDCIsland)
			continue;
		if (g_pPGBlock->m_IslandArray[nIsland].bDead)
			continue;

		sprintf(szBuf, "%d\n", nIsland);
		pCombo->AddString(szBuf);
	}

	UpdateData(FALSE);
}

void	CPG2BpaDatDialog::RefreshPFBusList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListBus.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (g_pPGBlock->m_BusbarSectionArray[i].nNode < 0)
			continue;
		if (g_pPGBlock->m_ConnectivityNodeArray[g_pPGBlock->m_BusbarSectionArray[i].nNode].nTopoBus < 3)
			continue;
		if (g_pPGBlock->m_BusbarSectionArray[i].nIsland == 0 || g_pPGBlock->m_BusbarSectionArray[i].nIsland > g_pPGBlock->m_nRecordNum[PG_ISLAND])
			continue;
		if (g_pPGBlock->m_IslandArray[g_pPGBlock->m_BusbarSectionArray[i].nIsland].bDead)
			continue;

		m_wndListBus.InsertItem(nRow, g_pPGBlock->m_BusbarSectionArray[i].szSub);	m_wndListBus.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListBus.SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szVolt);
		m_wndListBus.SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szName);

		sprintf(szBuf, "B_%d", g_pPGBlock->m_ConnectivityNodeArray[g_pPGBlock->m_BusbarSectionArray[i].nNode].nTopoBus);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_BusbarSectionArray[i].fV);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_BusbarSectionArray[i].fD);	m_wndListBus.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListBus.GetColumnWidth(nCol);
		m_wndListBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListBus.GetColumnWidth(nCol);

		m_wndListBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaDatDialog::RefreshPFLineList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListLine.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (g_pPGBlock->m_ACLineSegmentArray[i].nIsland == 0 || g_pPGBlock->m_ACLineSegmentArray[i].nIsland > g_pPGBlock->m_nRecordNum[PG_ISLAND])
			continue;
		if (g_pPGBlock->m_IslandArray[g_pPGBlock->m_ACLineSegmentArray[i].nIsland].bDead)
			continue;

		m_wndListLine.InsertItem(nRow, g_pPGBlock->m_ACLineSegmentArray[i].szName);	m_wndListBus.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
		m_wndListLine.SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubJ);

		sprintf(szBuf, "B_%d", g_pPGBlock->m_ACLineSegmentArray[i].nTopoBusI);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "B_%d", g_pPGBlock->m_ACLineSegmentArray[i].nTopoBusJ);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fPi);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fQi);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fPz);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fQz);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fLossP);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fLossQ);	m_wndListLine.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLine.GetColumnWidth(nCol);
		m_wndListLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLine.GetColumnWidth(nCol);

		m_wndListLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaDatDialog::RefreshPFTranList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndListTran.DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		if (g_pPGBlock->m_TransformerWindingArray[i].nIsland == 0 || g_pPGBlock->m_TransformerWindingArray[i].nIsland > g_pPGBlock->m_nRecordNum[PG_ISLAND])
			continue;
		if (g_pPGBlock->m_IslandArray[g_pPGBlock->m_TransformerWindingArray[i].nIsland].bDead)
			continue;

		m_wndListTran.InsertItem(nRow, g_pPGBlock->m_TransformerWindingArray[i].szSub);	m_wndListBus.SetItemData(nRow, nRow);

		nCol=1;
		m_wndListTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szName);
		m_wndListTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltI);
		m_wndListTran.SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltJ);

		sprintf(szBuf, "B_%d", g_pPGBlock->m_TransformerWindingArray[i].nTopoBusI);	m_wndListTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "B_%d", g_pPGBlock->m_TransformerWindingArray[i].nTopoBusJ);	m_wndListTran.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fPi);		m_wndListTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fQi);		m_wndListTran.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fPz);		m_wndListTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fQz);		m_wndListTran.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fLossP);	m_wndListTran.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fLossQ);	m_wndListTran.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszPFTranColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListTran.GetColumnWidth(nCol);
		m_wndListTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListTran.GetColumnWidth(nCol);

		m_wndListTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

int CPG2BpaDatDialog::GetTextLen(const char* lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC *pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(CString(lpszText), (int) strlen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(CString(lpszText), (int) strlen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CPG2BpaDatDialog::OnBnClickedViewPfo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int		iExt, nIsland=-1;
	char	szPfoFile[260], szLine[1024];

	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_ISLAND_COMBO);
	int			nSel=pCombo->GetCurSel();
	if (nSel == CB_ERR)
		return;

	pCombo->GetLBText(nSel, szLine);
	nIsland=atoi(szLine);

	m_wndPfoList.ResetContent();

	sprintf(szPfoFile, "%s\\%s%d.pfo", g_szBpaWorkDir, g_PG2BpaApi.m_BpaDatConCard.szProject, nIsland);
	if (_access(szPfoFile, 0) != 0)
		return;

	FILE*	fp=fopen(szPfoFile, "r");
	if (fp == NULL)
		return;

	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);

		TrimEnd(szLine);
		TrimRight(szLine);
		if (strlen(szLine) <= 0)
			continue;

		iExt = GetTextLen(szLine);
		if (iExt > m_wndPfoList.GetHorizontalExtent())
			m_wndPfoList.SetHorizontalExtent(iExt);
		m_wndPfoList.AddString(CString(szLine));

	}
	fclose(fp);
}

void CPG2BpaDatDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}
