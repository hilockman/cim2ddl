#pragma once
#include "afxcmn.h"
#include "../../../Common/MFCControls/MFCListCtrlEx.h"

// CPG2BpaSwiFltDialog �Ի���

class CPG2BpaSwiFltDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaSwiFltDialog)

public:
	CPG2BpaSwiFltDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaSwiFltDialog();

	// �Ի�������
	enum { IDD = IDD_PG2BPASWI_FLTDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnCbnSelchangeDevtypeCombo();
	afx_msg void OnBnClickedFormFlt();
	afx_msg void OnBnClickedRefreshPg();
	afx_msg void OnCbnSelchangeSubCombo();
	afx_msg void OnBnClickedAddFlt();
	afx_msg void OnBnClickedDelFlt();
	afx_msg void OnBnClickedAddRunflt();
	afx_msg void OnBnClickedDelRunflt();
	DECLARE_MESSAGE_MAP()
private:
	int m_nFltSide;
	CMFCListCtrlEx	m_wndAllFltList;
	CMFCListCtrlEx	m_wndRunFltList;

private:
	void	RefreshDeviceList();
	void	RefreshAllFltList();
	void	RefreshRunFltList();
public:
	void	RefreshUI();
};
