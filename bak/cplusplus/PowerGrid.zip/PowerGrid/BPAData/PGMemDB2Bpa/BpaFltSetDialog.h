#pragma once


// CBpaFltSetDialog �Ի���

class CBpaFltSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CBpaFltSetDialog)

public:
	CBpaFltSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBpaFltSetDialog();

// �Ի�������
	enum { IDD = IDD_BPAFLT_SETDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();

	DECLARE_MESSAGE_MAP()
private:
	int m_nFltType;
	int	m_nFltPhase;
	int m_nShortType;
	tagBpaFltDefine*	m_pFltDef;

private:
	void	RefreshFltType();
	int		GetFltDefine(tagBpaFltDefine* pFlt);
	void	SetFltDefine(tagBpaFltDefine* pFlt);


public:
	void InitFltDefine(tagBpaFltDefine* pFltDef);
};
