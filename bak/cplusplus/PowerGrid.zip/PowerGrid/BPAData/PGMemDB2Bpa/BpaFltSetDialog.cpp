// BpaFltSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "BpaFltSetDialog.h"
#include "../../../Common/String2Double.hpp"

// CBpaFltSetDialog �Ի���

IMPLEMENT_DYNAMIC(CBpaFltSetDialog, CDialog)

CBpaFltSetDialog::CBpaFltSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBpaFltSetDialog::IDD, pParent)
{
	m_nFltPhase=0;
	m_nShortType=0;
	m_nFltType=0;

	m_pFltDef=NULL;
}

CBpaFltSetDialog::~CBpaFltSetDialog()
{
}

void CBpaFltSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_PHASEA, m_nFltPhase);
	DDX_Radio(pDX, IDC_SHORT_TYPE_1, m_nShortType);
	DDX_Radio(pDX, IDC_FLTTYPE_0, m_nFltType);
}


BEGIN_MESSAGE_MAP(CBpaFltSetDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CBpaFltSetDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CBpaFltSetDialog ��Ϣ��������

BOOL CBpaFltSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CComboBox*	pCombo;

	pCombo=(CComboBox*)GetDlgItem(IDC_ELTYPE_COMBO);
	pCombo->ResetContent();
	for (i=0; i<sizeof(g_lpszBpaFltGenELType)/sizeof(char*); i++)
		pCombo->AddString(g_lpszBpaFltGenELType[i]);

	UpdateData(FALSE);
	if (m_pFltDef)
	{
		char	szBuf[260];
		sprintf(szBuf, "%s[%s %s %s]", g_lpszBpaFltDevType[m_pFltDef->nDevType], m_pFltDef->szDevSub, m_pFltDef->szDevVolt, m_pFltDef->szDevName);
		GetDlgItem(IDC_FLT_DEV)->SetWindowText(szBuf);
	}

	//RefreshFltType();
	SetFltDefine(m_pFltDef);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBpaFltSetDialog::InitFltDefine(tagBpaFltDefine* pFltDef)
{
	m_pFltDef=pFltDef;
}

void CBpaFltSetDialog::RefreshFltType()
{
	if (!m_pFltDef)
		return;

	UpdateData();

	GetDlgItem(IDC_FLTTYPE_0)->EnableWindow(FALSE);
	GetDlgItem(IDC_FLTTYPE_1)->EnableWindow(FALSE);
	GetDlgItem(IDC_FLTTYPE_2)->EnableWindow(FALSE);
	GetDlgItem(IDC_FLTTYPE_3)->EnableWindow(FALSE);
	GetDlgItem(IDC_FLTTYPE_4)->EnableWindow(FALSE);
	switch (m_pFltDef->nDevType)
	{
	case	BpaFltDev_Bus:
		GetDlgItem(IDC_FLTTYPE_0)->EnableWindow(TRUE);
		if (m_nFltType != 0)
			m_nFltType=0;
		break;
	case	BpaFltDev_Line:
		GetDlgItem(IDC_FLTTYPE_1)->EnableWindow(TRUE);
		GetDlgItem(IDC_FLTTYPE_2)->EnableWindow(TRUE);
		GetDlgItem(IDC_FLTTYPE_3)->EnableWindow(TRUE);
		if (m_nFltType == 0)
			m_nFltType=1;
		break;
	case	BpaFltDev_Wind:
		GetDlgItem(IDC_FLTTYPE_1)->EnableWindow(TRUE);
		GetDlgItem(IDC_FLTTYPE_2)->EnableWindow(TRUE);
		GetDlgItem(IDC_FLTTYPE_3)->EnableWindow(TRUE);
		if (m_nFltType == 0)
			m_nFltType=1;
		break;
	case	BpaFltDev_Gen:
		GetDlgItem(IDC_FLTTYPE_1)->EnableWindow(TRUE);
		GetDlgItem(IDC_FLTTYPE_4)->EnableWindow(TRUE);
		if (m_nFltType != 1)
			m_nFltType=1;
		break;
	case	BpaFltDev_Load:
		GetDlgItem(IDC_FLTTYPE_1)->EnableWindow(TRUE);
		if (m_nFltType != 1)
			m_nFltType=1;
		break;
	default:
		break;
	}

	UpdateData(FALSE);
}

int CBpaFltSetDialog::GetFltDefine(tagBpaFltDefine* pFlt)
{
	CComboBox*	pCombo;

	UpdateData();

	pFlt->nFltType=m_nFltType;
	pFlt->nFltPhase=m_nFltPhase;
	pFlt->nShortType=m_nShortType;
	pFlt->fTCycle=0;
	pFlt->fTCyc1=0;
	pFlt->fTCyc2=0;
	pFlt->fTCyc11=0;
	pFlt->fTCyc21=0;
	pFlt->fTCyc12=0;
	pFlt->fTCyc22=0;
	pFlt->fFaultR=0;
	pFlt->fFaultX=0;
	pFlt->fPercent=0;
	pFlt->nElType=0;
	pFlt->fElCrest=0;
	pFlt->fExcitT=0;

	char	szBuf[260];
	GetDlgItem(IDC_CYCLE)->GetWindowText(szBuf, 260);	pFlt->fTCycle=(float)atof(szBuf);		
	GetDlgItem(IDC_TCYC1)->GetWindowText(szBuf, 260);	pFlt->fTCyc1=(float)atof(szBuf);		
	GetDlgItem(IDC_TCYC2)->GetWindowText(szBuf, 260);	pFlt->fTCyc2=(float)atof(szBuf);		
	GetDlgItem(IDC_TCYC11)->GetWindowText(szBuf, 260);	pFlt->fTCyc11=(float)atof(szBuf);		
	GetDlgItem(IDC_TCYC21)->GetWindowText(szBuf, 260);	pFlt->fTCyc21=(float)atof(szBuf);		
	GetDlgItem(IDC_TCYC12)->GetWindowText(szBuf, 260);	pFlt->fTCyc12=(float)atof(szBuf);		
	GetDlgItem(IDC_TCYC22)->GetWindowText(szBuf, 260);	pFlt->fTCyc22=(float)atof(szBuf);		
	GetDlgItem(IDC_FAULTR)->GetWindowText(szBuf, 260);	pFlt->fFaultR=(float)atof(szBuf);		
	GetDlgItem(IDC_FAULTX)->GetWindowText(szBuf, 260);	pFlt->fFaultX=(float)atof(szBuf);		
	GetDlgItem(IDC_PERCENT)->GetWindowText(szBuf, 260);	pFlt->fPercent=(float)atof(szBuf);		

	if (m_nFltType == BpaFltType_EL)
	{
		pCombo=(CComboBox*)GetDlgItem(IDC_ELTYPE_COMBO);
		pFlt->nElType=pCombo->GetCurSel();
		GetDlgItem(IDC_EL_CREST)->GetWindowText(szBuf, 260);	pFlt->fElCrest=(float)atof(szBuf);		
		GetDlgItem(IDC_EXCIT_T)->GetWindowText(szBuf, 260);		pFlt->fExcitT=(float)atof(szBuf);		
	}
	return 1;
}

void CBpaFltSetDialog::SetFltDefine(tagBpaFltDefine* pFlt)
{
	char	szBuf[260];
	CComboBox*	pCombo;

	m_nFltType=pFlt->nFltType;
	m_nFltPhase=pFlt->nFltPhase;
	m_nShortType=pFlt->nShortType;

	sprintf(szBuf, "%.2f", pFlt->fTCycle);		GetDlgItem(IDC_CYCLE)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", pFlt->fTCyc1);		GetDlgItem(IDC_TCYC1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", pFlt->fTCyc2);		GetDlgItem(IDC_TCYC2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", pFlt->fTCyc11);		GetDlgItem(IDC_TCYC11)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", pFlt->fTCyc21);		GetDlgItem(IDC_TCYC21)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", pFlt->fTCyc12);		GetDlgItem(IDC_TCYC12)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", pFlt->fTCyc22);		GetDlgItem(IDC_TCYC22)->SetWindowText(szBuf);
	sprintf(szBuf, "%.5f", pFlt->fFaultR);		GetDlgItem(IDC_FAULTR)->SetWindowText(szBuf);
	sprintf(szBuf, "%.5f", pFlt->fFaultX);		GetDlgItem(IDC_FAULTX)->SetWindowText(szBuf);
	sprintf(szBuf, "%.1f", pFlt->fPercent);		GetDlgItem(IDC_PERCENT)->SetWindowText(szBuf);

	pCombo=(CComboBox*)GetDlgItem(IDC_ELTYPE_COMBO);
	pCombo->SetCurSel(-1);
	if (m_nFltType == BpaFltType_EL)
	{
		if (pFlt->nElType >= 0 && pFlt->nElType < sizeof(g_lpszBpaFltGenELType)/sizeof(char*))
		{
			pCombo->SetCurSel(pFlt->nElType);

			sprintf(szBuf, "%f", pFlt->fElCrest);		GetDlgItem(IDC_EL_CREST)->SetWindowText(szBuf);
			sprintf(szBuf, "%f", pFlt->fExcitT);		GetDlgItem(IDC_EXCIT_T)->SetWindowText(szBuf);
		}
	}

	UpdateData(FALSE);
}

void CBpaFltSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	GetFltDefine(m_pFltDef);
	OnOK();
}
