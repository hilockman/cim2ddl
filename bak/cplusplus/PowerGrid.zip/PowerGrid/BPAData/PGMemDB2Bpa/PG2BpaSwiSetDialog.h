#pragma once

#include "../../../Common/MFCListCtrlEx.h"

// CPG2BpaSwiSetDialog �Ի���
typedef	struct _GenModePG2Bpa
{
	char	szPGSub[MDB_CHARLEN];
	char	szPGVolt[MDB_CHARLEN_TINY];
	char	szPGName[MDB_CHARLEN];
	char	szBpaBus[MDB_CHARLEN];
	float	fBpaVolt;
}	tagGenModePG2Bpa;


class CPG2BpaSwiSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaSwiSetDialog)

public:
	CPG2BpaSwiSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaSwiSetDialog();

// �Ի�������
	enum { IDD = IDD_PG2BPASWI_SETDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedCapacityRadio();
	afx_msg void OnNMClickBpagenList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickPggenList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedSetBpagenmodel();
	afx_msg void OnBnClickedUnsetBpagenmodel();
	afx_msg void OnBnClickedRefreshPG();
	afx_msg void OnBnClickedSaveModelset();
	afx_msg void OnEnChangeBpabusFilter();
	afx_msg void OnBnClickedLoadModelset();
	afx_msg void OnEnChangeBpaworkDir();
	afx_msg void OnBnClickedRefreshBpa();
	DECLARE_MESSAGE_MAP()
private:
	int		m_nGenCapacity;
	int		m_nCurPGGen, m_nCurBpaGen;
	char	m_szBpaBusFilter[MDB_CHARLEN_SHORT];

	CMFCPropertyGridCtrl	m_wndPropertyList;
	CMFCListCtrlEx m_wndBpaGenList;
	CMFCListCtrlEx m_wndPGGenList;

private:
	int		m_nExcModel;
	int		m_nPssModel;
	int		m_nGovModel;
	int		m_nMovModel;

	int		m_nGenIndex;
	int		m_nExcIndex;
	int		m_nPssIndex;
	int		m_nGovIndex;
	int		m_nSvoIndex;
	int		m_nMovIndex;

	tagBpaSwi_Gen			m_BpaSwi_GenBuffer		;
	tagBpaSwi_GenLn			m_BpaSwi_GenLnBuffer	;
	tagBpaSwi_Excit68		m_BpaSwi_Excit68Buffer	;
	tagBpaSwi_Excit81		m_BpaSwi_Excit81Buffer	;
	tagBpaSwi_ExcitMV		m_BpaSwi_ExcitMVBuffer	;
	tagBpaSwi_ExcitX		m_BpaSwi_ExcitXBuffer	;
	tagBpaSwi_PSSS			m_BpaSwi_PSSSBuffer		;
	tagBpaSwi_PSSSH1		m_BpaSwi_PSSSH1Buffer	;
	tagBpaSwi_PSSSH2		m_BpaSwi_PSSSH2Buffer	;
	tagBpaSwi_PSSSI			m_BpaSwi_PSSSIBuffer	;
	tagBpaSwi_PSSSA			m_BpaSwi_PSSSABuffer	;
	tagBpaSwi_PSSSB			m_BpaSwi_PSSSBBuffer	;
	tagBpaSwi_PSSST			m_BpaSwi_PSSSTBuffer	;
	tagBpaSwi_GG			m_BpaSwi_GGBuffer		;
	tagBpaSwi_GH			m_BpaSwi_GHBuffer		;
	tagBpaSwi_GC			m_BpaSwi_GCBuffer		;
	tagBpaSwi_GS			m_BpaSwi_GSBuffer		;
	tagBpaSwi_GL			m_BpaSwi_GLBuffer		;
	tagBpaSwi_GW			m_BpaSwi_GWBuffer		;
	tagBpaSwi_GA			m_BpaSwi_GABuffer		;
	tagBpaSwi_GI			m_BpaSwi_GIBuffer		;
	tagBpaSwi_GJ			m_BpaSwi_GJBuffer		;
	tagBpaSwi_GK			m_BpaSwi_GKBuffer		;
	tagBpaSwi_GM			m_BpaSwi_GMBuffer		;
	tagBpaSwi_GD			m_BpaSwi_GDBuffer		;
	tagBpaSwi_GZ			m_BpaSwi_GZBuffer		;
	tagBpaSwi_TA			m_BpaSwi_TABuffer		;
	tagBpaSwi_TB			m_BpaSwi_TBBuffer		;
	tagBpaSwi_TC			m_BpaSwi_TCBuffer		;
	tagBpaSwi_TD			m_BpaSwi_TDBuffer		;
	tagBpaSwi_TE			m_BpaSwi_TEBuffer		;
	tagBpaSwi_TF			m_BpaSwi_TFBuffer		;
	tagBpaSwi_TW			m_BpaSwi_TWBuffer		;

	std::vector<tagGenModePG2Bpa>	g_GenModelPG2BpaArray;

private:
	void	RefreshBpaGenList(void);
	void	RefreshPGGenList(void);
	void	RefreshPropertyList();

private:
	void	SetPGGenBpaModel();
	void	Mdb2ModelBuffer();
	void	ModelBuffer2Mdb();
	void	ClearModel();

public:
	void	RefreshUI();
};
