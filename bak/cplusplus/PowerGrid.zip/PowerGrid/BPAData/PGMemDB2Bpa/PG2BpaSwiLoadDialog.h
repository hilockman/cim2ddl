#pragma once

#include "../../../Common/MFCControls/MFCListCtrlEx.h"


// CPG2BpaSwiLoadDialog �Ի���

class CPG2BpaSwiLoadDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2BpaSwiLoadDialog)

public:
	CPG2BpaSwiLoadDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2BpaSwiLoadDialog();

// �Ի�������
	enum { IDD = IDD_PG2BPASWI_LOADDIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedSetMi();
	afx_msg void OnBnClickedSetLb();
	afx_msg void OnBnClickedRefreshPg();
	afx_msg void OnNMClickLoadMotorList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedSampleModel();
	DECLARE_MESSAGE_MAP()
private:
	CMFCListCtrlEx m_wndListLoad;
	CMFCListCtrlEx m_wndListZone;

private:
	void	RefreshLoadMotorList();
	void	RefreshLoadMotorParam();
	void	RefreshZoneLoadModelList();
	void	RefreshZoneLoadModelParam();

public:
	void RefreshUI();
};
