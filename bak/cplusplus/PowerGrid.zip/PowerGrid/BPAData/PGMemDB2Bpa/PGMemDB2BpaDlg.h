
// PGMemDB2BpaDlg.h : ͷ�ļ�
//

#pragma once

#include "PG2BpaDatDialog.h"
#include "PG2BpaSwiGenDialog.h"
#include "PG2BpaSwiLoadDialog.h"
#include "PG2BpaSwiXoDialog.h"
#include "PG2BpaSwiFltDialog.h"
#include "PG2BpaSwiDialog.h"

// CPGMemDB2BpaDlg �Ի���
class CPGMemDB2BpaDlg : public CDialog
{
// ����
public:
	CPGMemDB2BpaDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PG2BPA_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedFormBpaDat();
	afx_msg void OnBnClickedFormBpaSwi();
	afx_msg void OnBnClickedBrowseWorkdir();
	afx_msg void OnBnClickedBrowseSwiFile();
	afx_msg void OnBnClickedBrowseBpapf();
	afx_msg void OnBnClickedBrowseBpasw();
	afx_msg void OnEnChangeBpaWorkDir();
	afx_msg void OnEnChangeBpaSwiFile();
	afx_msg void OnEnChangeBpapfExec();
	afx_msg void OnEnChangeBpaswExec();
	afx_msg void OnBnClickedBpapf();
	afx_msg void OnBnClickedBpasw();
	afx_msg void OnBnClickedClearMesg();
	afx_msg void OnBnClickedLoadSet();
	afx_msg void OnBnClickedSaveSet();
	DECLARE_MESSAGE_MAP()
private:
	CMFCTabCtrl			m_wndTab;

private:
	CPG2BpaDatDialog		m_wndPG2BpaDat;
	CPG2BpaSwiGenDialog		m_wndPG2BpaSwiGen;
	CPG2BpaSwiXoDialog		m_wndPG2BpaSwiXo;
	CPG2BpaSwiLoadDialog	m_wndPG2BpaSwiLoad;
	CPG2BpaSwiFltDialog		m_wndPG2BpaSwiFlt;
	CPG2BpaSwiDialog		m_wndPG2BpaSwi;

private:
	int		GetTextLen(LPCTSTR lpszText);
	void	PrintMessage(char* pformat, ...);
public:
};
