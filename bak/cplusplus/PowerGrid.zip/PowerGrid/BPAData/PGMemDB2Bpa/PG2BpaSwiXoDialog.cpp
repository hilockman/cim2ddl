// PG2BpaSwiXoDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "PG2BpaSwiXoDialog.h"
#include "../../../Common/String2Double.hpp"


// CPG2BpaSwiXoDialog �Ի���

static	char*	lpszTranXOColumn[]=
{
	"��վ", 
	"����", 
	"��ѹ1", 
	"��ѹ2", 
	"���", 
	"���Ե�ӵ�", 
	"�������", 
	"����翹", 
};

static	char*	lpszLineLOColumn[]=
{
	"����", 
	"��ѹ", 
	"��վ1", 
	"��վ2", 
	"�������", 
	"����翹", 
};

IMPLEMENT_DYNAMIC(CPG2BpaSwiXoDialog, CDialog)

CPG2BpaSwiXoDialog::CPG2BpaSwiXoDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2BpaSwiXoDialog::IDD, pParent)
{
	m_nWindType=PGEnumTransformerWinding_WindConnectio_2WYY;
	m_bNeutralGnd=FALSE;
}

CPG2BpaSwiXoDialog::~CPG2BpaSwiXoDialog()
{
}

void CPG2BpaSwiXoDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_WIND_YY, m_nWindType);
	DDX_Check(pDX, IDC_NEUTRAL_GROUND, m_bNeutralGnd);
	DDX_Control(pDX, IDC_TRAN_XO_LIST, m_wndListTran);
	DDX_Control(pDX, IDC_LINE_LO_LIST, m_wndListLine);
}


BEGIN_MESSAGE_MAP(CPG2BpaSwiXoDialog, CDialog)
	ON_NOTIFY(NM_CLICK, IDC_TRAN_XO_LIST, &CPG2BpaSwiXoDialog::OnNMClickTranXoList)
	ON_NOTIFY(NM_CLICK, IDC_LINE_LO_LIST, &CPG2BpaSwiXoDialog::OnNMClickLineLoList)
	ON_BN_CLICKED(IDC_SET_XO, &CPG2BpaSwiXoDialog::OnBnClickedSetXo)
	ON_BN_CLICKED(IDC_SET_LO, &CPG2BpaSwiXoDialog::OnBnClickedSetLo)
	ON_BN_CLICKED(IDC_REFRESH_PG, &CPG2BpaSwiXoDialog::OnBnClickedRefreshPg)
END_MESSAGE_MAP()


// CPG2BpaSwiXoDialog ��Ϣ��������

BOOL CPG2BpaSwiXoDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;
	
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TRAN_XO_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszTranXOColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszTranXOColumn[i]);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LINE_LO_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszLineLOColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLineLOColumn[i]);

	OnBnClickedRefreshPg();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void	CPG2BpaSwiXoDialog::RefreshTranXOList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TRAN_XO_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
	{
		pListCtrl->InsertItem(nRow, g_pPGBlock->m_TransformerWindingArray[i].szSub);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szName);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltI);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_TransformerWindingArray[i].szVoltJ);

		pListCtrl->SetItemText(nRow, nCol++, PGGetFieldEnumString(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_WINDINGTYPE, g_pPGBlock->m_TransformerWindingArray[i].nWindingType));
		pListCtrl->SetItemText(nRow, nCol++, PGGetFieldEnumString(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_NEUTRALSTATUS, g_pPGBlock->m_TransformerWindingArray[i].bNeutralStatus));
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fR0);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fX0);		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszTranXOColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaSwiXoDialog::RefreshTranXOParam()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TRAN_XO_LIST);

	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		{
			if (stricmp(g_pPGBlock->m_TransformerWindingArray[i].szSub, pListCtrl->GetItemText(nRow, 0)) == 0 &&
				stricmp(g_pPGBlock->m_TransformerWindingArray[i].szName, pListCtrl->GetItemText(nRow, 1)) == 0)
			{
				nCol=4;
				pListCtrl->SetItemText(nRow, nCol++, PGGetFieldEnumString(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_WINDINGTYPE, g_pPGBlock->m_TransformerWindingArray[i].nWindingType));
				pListCtrl->SetItemText(nRow, nCol++, PGGetFieldEnumString(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_NEUTRALSTATUS, g_pPGBlock->m_TransformerWindingArray[i].bNeutralStatus));
				sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fR0);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_TransformerWindingArray[i].fX0);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				break;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszTranXOColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaSwiXoDialog::RefreshLineLOList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LINE_LO_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		pListCtrl->InsertItem(nRow, g_pPGBlock->m_ACLineSegmentArray[i].szName);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubJ);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fR0);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fX0);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszLineLOColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaSwiXoDialog::RefreshLineLOParam()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LINE_LO_LIST);

	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (stricmp(g_pPGBlock->m_ACLineSegmentArray[i].szName, pListCtrl->GetItemText(nRow, 0)) == 0)
			{
				nCol=4;
				sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fR0);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_ACLineSegmentArray[i].fX0);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
				break;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszLineLOColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPG2BpaSwiXoDialog::OnNMClickTranXoList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 	int			nItem=pNMItemActivate->iItem;
// 	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TRAN_XO_LIST);
// 
// 	if (nItem >= 0 && nItem < pListCtrl->GetItemCount())
// 	{
// 		int		nCol=4;
// 
// 		m_nWindType=PGGetFieldEnumValue(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_WINDINGTYPE, pListCtrl->GetItemText(nItem, nCol++));
// 		m_bNeutralGnd=PGGetFieldEnumValue(PG_TRANSFORMERWINDING, PG_TRANSFORMERWINDING_NEUTRALSTATUS, pListCtrl->GetItemText(nItem, nCol++));
// 		GetDlgItem(IDC_XO_R0)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
// 		GetDlgItem(IDC_XO_X0)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
// 
// 		UpdateData(FALSE);
// 	}

	*pResult = 0;
}

void CPG2BpaSwiXoDialog::OnNMClickLineLoList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
// 	int			nItem=pNMItemActivate->iItem;
// 	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LINE_LO_LIST);
// 
// 	if (nItem >= 0 && nItem < pListCtrl->GetItemCount())
// 	{
// 		int		nCol=4;
// 		GetDlgItem(IDC_LO_R0)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
// 		GetDlgItem(IDC_LO_X0)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
// 
// 		UpdateData(FALSE);
// 	}
	*pResult = 0;
}

void CPG2BpaSwiXoDialog::OnBnClickedSetXo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nItem, nWind;
	char	szBuf[260];
	char	szSub[MDB_CHARLEN], szName[MDB_CHARLEN];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TRAN_XO_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	UpdateData();
	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		strcpy(szSub, pListCtrl->GetItemText(nItem, 0));
		strcpy(szName, pListCtrl->GetItemText(nItem, 1));

		nWind=-1;
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		{
			if (stricmp(g_pPGBlock->m_TransformerWindingArray[i].szSub, szSub) == 0 &&
				stricmp(g_pPGBlock->m_TransformerWindingArray[i].szName, szName) == 0)
			{
				nWind=i;
				break;
			}
		}
		if (nWind < 0)
			continue;

		GetDlgItem(IDC_XO_R0)->GetWindowText(szBuf, 260);	g_pPGBlock->m_TransformerWindingArray[nWind].fR0=(float)atof(szBuf);
		GetDlgItem(IDC_XO_X0)->GetWindowText(szBuf, 260);	g_pPGBlock->m_TransformerWindingArray[nWind].fX0=(float)atof(szBuf);
		g_pPGBlock->m_TransformerWindingArray[nWind].nWindingType=m_nWindType;
		g_pPGBlock->m_TransformerWindingArray[nWind].bNeutralStatus=m_bNeutralGnd;
	}

	RefreshTranXOParam();
}

void CPG2BpaSwiXoDialog::OnBnClickedSetLo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nItem, nLine;
	char	szBuf[260];
	char	szName[MDB_CHARLEN];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LINE_LO_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	UpdateData();
	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		strcpy(szName, pListCtrl->GetItemText(nItem, 0));

		nLine=-1;
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (stricmp(g_pPGBlock->m_ACLineSegmentArray[i].szName, szName) == 0)
			{
				nLine=i;
				break;
			}
		}
		if (nLine < 0)
			continue;

		GetDlgItem(IDC_LO_R0)->GetWindowText(szBuf, 260);	g_pPGBlock->m_ACLineSegmentArray[nLine].fR0=(float)atof(szBuf);
		GetDlgItem(IDC_LO_X0)->GetWindowText(szBuf, 260);	g_pPGBlock->m_ACLineSegmentArray[nLine].fX0=(float)atof(szBuf);
	}

	RefreshLineLOParam();
}

void CPG2BpaSwiXoDialog::OnBnClickedRefreshPg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshUI();
}

void CPG2BpaSwiXoDialog::RefreshUI()
{
	RefreshTranXOList();
	RefreshLineLOList();
}