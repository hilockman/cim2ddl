// PG2BpaSwiLoadDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGMemDB2BpaApp.h"
#include "PG2BpaSwiLoadDialog.h"

#include "BpaLoadModelSampleDialog.h"
#include "../../../Common/String2Double.hpp"

// CPG2BpaSwiLoadDialog �Ի���

static	char*	lpszLoadMotorColumn[]=
{
	"��վ", 
	"��ѹ", 
	"����", 
	"�������", 
	"�й�����", 
	"������", 
	"���ӵ���", 
	"���ӵ翹", 
	"���ŵ翹", 
	"ת�ӵ���", 
	"ת�ӵ翹", 
	"A", 
	"B", 
};

static	char*	lpszZoneLoadModelColumn[]=
{
	"����", 
	"P1", 
	"P2", 
	"P3", 
	"LDP", 
	"Q1", 
	"Q2", 
	"Q3", 
	"LDQ", 
};

IMPLEMENT_DYNAMIC(CPG2BpaSwiLoadDialog, CDialog)

CPG2BpaSwiLoadDialog::CPG2BpaSwiLoadDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2BpaSwiLoadDialog::IDD, pParent)
{

}

CPG2BpaSwiLoadDialog::~CPG2BpaSwiLoadDialog()
{
}

void CPG2BpaSwiLoadDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOAD_MOTOR_LIST, m_wndListLoad);
	DDX_Control(pDX, IDC_ZONE_LOADMODEL_LIST, m_wndListZone);
}


BEGIN_MESSAGE_MAP(CPG2BpaSwiLoadDialog, CDialog)
	ON_BN_CLICKED(IDC_SET_MI, &CPG2BpaSwiLoadDialog::OnBnClickedSetMi)
	ON_BN_CLICKED(IDC_SET_LB, &CPG2BpaSwiLoadDialog::OnBnClickedSetLb)
	ON_BN_CLICKED(IDC_REFRESH_PG, &CPG2BpaSwiLoadDialog::OnBnClickedRefreshPg)
	ON_BN_CLICKED(IDC_SAMPLE_MODEL, &CPG2BpaSwiLoadDialog::OnBnClickedSampleModel)
END_MESSAGE_MAP()


// CPG2BpaSwiLoadDialog ��Ϣ��������

BOOL CPG2BpaSwiLoadDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_MOTOR_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszLoadMotorColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLoadMotorColumn[i]);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ZONE_LOADMODEL_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszZoneLoadModelColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszZoneLoadModelColumn[i]);

	OnBnClickedRefreshPg();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void	CPG2BpaSwiLoadDialog::RefreshLoadMotorList()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_MOTOR_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		pListCtrl->InsertItem(nRow, g_pPGBlock->m_EnergyConsumerArray[i].szSub);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szVolt);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szName);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorTj);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorPper);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorKl);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorRs);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorXs);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorXm);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorRr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorXr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorA);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorB);			pListCtrl->SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszLoadMotorColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaSwiLoadDialog::RefreshLoadMotorParam()
{
	register int	i;
	int		nRow, nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_MOTOR_LIST);

	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		{
			if (stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szSub, pListCtrl->GetItemText(nRow, 0)) == 0 &&
				stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szVolt, pListCtrl->GetItemText(nRow, 1)) == 0 &&
				stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szName, pListCtrl->GetItemText(nRow, 2)) == 0)
			{
				nCol=3;
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorTj);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorPper);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorKl);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorRs);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorXs);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorXm);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorRr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorXr);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorA);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf, "%f", g_pPGBlock->m_EnergyConsumerArray[i].fMotorB);			pListCtrl->SetItemText(nRow, nCol++, szBuf);
				break;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszLoadMotorColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaSwiLoadDialog::RefreshZoneLoadModelList()
{
	register int	i, j;
	int		nRow, nCol;
	int		nLoadModel;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ZONE_LOADMODEL_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
	{
		pListCtrl->InsertItem(nRow, g_pPGBlock->m_SubcontrolAreaArray[i].szName);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		nLoadModel=-1;
		for (j=0; j<g_pPGBlock->m_nRecordNum[PG_LOADMODEL]; j++)
		{
			if (stricmp(g_pPGBlock->m_SubcontrolAreaArray[i].szLoadModel, g_pPGBlock->m_LoadModelArray[j].szName) == 0)
			{
				nLoadModel=j;
				break;
			}
		}

		if (nLoadModel >= 0)
		{
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fPImp);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fPCur);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fPCon);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fDPf);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fQImp);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fQCur);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fQCon);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fDQf);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		}

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszZoneLoadModelColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void	CPG2BpaSwiLoadDialog::RefreshZoneLoadModelParam()
{
	register int	i, j;
	int		nRow, nCol;
	int		nLoadModel;
	char	szBuf[260];
	CListCtrl*	pListCtrl;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ZONE_LOADMODEL_LIST);

	for (nRow=0; nRow<pListCtrl->GetItemCount(); nRow++)
	{
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		{
			if (stricmp(g_pPGBlock->m_SubcontrolAreaArray[i].szName, pListCtrl->GetItemText(nRow, 0)) == 0)
			{
				nCol=1;
				nLoadModel=-1;
				for (j=0; j<g_pPGBlock->m_nRecordNum[PG_LOADMODEL]; j++)
				{
					if (stricmp(g_pPGBlock->m_SubcontrolAreaArray[i].szLoadModel, g_pPGBlock->m_LoadModelArray[j].szName) == 0)
					{
						nLoadModel=j;
						break;
					}
				}

				if (nLoadModel >= 0)
				{
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fPImp);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fPCur);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fPCon);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fDPf);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fQImp);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fQCur);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fQCon);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
					sprintf(szBuf, "%f", g_pPGBlock->m_LoadModelArray[nLoadModel].fDQf);		pListCtrl->SetItemText(nRow, nCol++, szBuf);
				}
				break;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (i=0; i<sizeof(lpszZoneLoadModelColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CPG2BpaSwiLoadDialog::OnBnClickedSetMi()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nItem, nLoad;
	char	szBuf[260];
	char	szSub[MDB_CHARLEN], szVolt[MDB_CHARLEN_SHORTER], szName[MDB_CHARLEN];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_MOTOR_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		strcpy(szSub, pListCtrl->GetItemText(nItem, 0));
		strcpy(szVolt, pListCtrl->GetItemText(nItem, 1));
		strcpy(szName, pListCtrl->GetItemText(nItem, 2));
		nLoad=-1;
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		{
			if (stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szSub, szSub) == 0 &&
				stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szVolt, szVolt) == 0 &&
				stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szName, szName) == 0)
			{
				nLoad=i;
				break;
			}
		}
		if (nLoad < 0)
			continue;

		GetDlgItem(IDC_MOTOR_TJ)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorTj=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_PPERCENT)->GetWindowText(szBuf, 260);	g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorPper=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_KL)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorKl=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_RS)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorRs=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_XS)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorXs=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_XM)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorXm=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_RR)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorRr=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_XR)->GetWindowText(szBuf, 260);		g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorXr=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_A)->GetWindowText(szBuf, 260);			g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorA=(float)atof(szBuf);
		GetDlgItem(IDC_MOTOR_B)->GetWindowText(szBuf, 260);			g_pPGBlock->m_EnergyConsumerArray[nLoad].fMotorB=(float)atof(szBuf);
	}

	RefreshLoadMotorParam();
}

void CPG2BpaSwiLoadDialog::OnBnClickedSetLb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nItem, nZone;
//	char	szBuf[260];
	char	szName[MDB_CHARLEN];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_ZONE_LOADMODEL_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	if (!pos)
		return;

	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);

		strcpy(szName, pListCtrl->GetItemText(nItem, 0));
		nZone=-1;
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		{
			if (stricmp(g_pPGBlock->m_SubcontrolAreaArray[i].szName, szName) == 0)
			{
				nZone=i;
				break;
			}
		}
		if (nZone < 0)
			continue;

// 		GetDlgItem(IDC_LB_P1)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBP1 =(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_P2)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBP2 =(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_P3)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBP3 =(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_LDP)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBLdp=(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_Q1)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBQ1 =(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_Q2)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBQ2 =(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_Q3)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBQ3 =(float)atof(szBuf);
// 		GetDlgItem(IDC_LB_LDQ)->GetWindowText(szBuf, 260);	g_pPGBlock->m_SubcontrolAreaArray[nZone].fLBLdq=(float)atof(szBuf);
	}

	RefreshZoneLoadModelParam();
}

void CPG2BpaSwiLoadDialog::OnBnClickedRefreshPg()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshUI();
}

void CPG2BpaSwiLoadDialog::RefreshUI()
{
	RefreshLoadMotorList();
	RefreshZoneLoadModelList();
}

void CPG2BpaSwiLoadDialog::OnNMClickLoadMotorList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	// 	int			nItem=pNMItemActivate->iItem;
	// 	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_MOTOR_LIST);
	// 
	// 	if (nItem >= 0 && nItem < pListCtrl->GetItemCount())
	// 	{
	// 		int		nCol=3;
	// 		GetDlgItem(IDC_MOTOR_TJ)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
	// 		GetDlgItem(IDC_MOTOR_PPERCENT)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
	// 		GetDlgItem(IDC_MOTOR_RS)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_XS)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_XM)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_RR)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_XR)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_A)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));		
	// 		GetDlgItem(IDC_MOTOR_B)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));		
	// 	}

	*pResult = 0;
}

void CPG2BpaSwiLoadDialog::OnBnClickedSampleModel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CBpaLoadModelSampleDialog	dlg;
	if (dlg.DoModal() != IDOK)
		return;

	// 		GetDlgItem(IDC_MOTOR_TJ)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
	// 		GetDlgItem(IDC_MOTOR_PPERCENT)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));
	// 		GetDlgItem(IDC_MOTOR_RS)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_XS)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_XM)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_RR)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_XR)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));	
	// 		GetDlgItem(IDC_MOTOR_A)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));		
	// 		GetDlgItem(IDC_MOTOR_B)->SetWindowText(pListCtrl->GetItemText(nItem, nCol++));		

	char	szBuf[260];
	sprintf(szBuf, "%f", dlg.m_fTJ);	GetDlgItem(IDC_MOTOR_TJ)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fPper);	GetDlgItem(IDC_MOTOR_PPERCENT)->SetWindowText(szBuf);	
	sprintf(szBuf, "%f", dlg.m_fKL);	GetDlgItem(IDC_MOTOR_KL)->SetWindowText(szBuf);	
	sprintf(szBuf, "%f", dlg.m_fRS);	GetDlgItem(IDC_MOTOR_RS)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fXS);	GetDlgItem(IDC_MOTOR_XS)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fXM);	GetDlgItem(IDC_MOTOR_XM)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fRR);	GetDlgItem(IDC_MOTOR_RR)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fXR);	GetDlgItem(IDC_MOTOR_XR)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fA);		GetDlgItem(IDC_MOTOR_A)->SetWindowText(szBuf);			
	sprintf(szBuf, "%f", dlg.m_fB);		GetDlgItem(IDC_MOTOR_B)->SetWindowText(szBuf);			

}
