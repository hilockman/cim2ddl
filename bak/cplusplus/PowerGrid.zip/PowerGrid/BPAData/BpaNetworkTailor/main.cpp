#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <io.h>
#include <float.h>
#include <direct.h>

#include "../../../MemDB/BpaMemDB/BpaMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/BpaMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/BpaMemDB.lib")
#endif
using	namespace	BpaMemDB;

#include "../../../Common/TinyXML/tinyxml.h"
//using	namespace	TinyXML;
#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib/libTinyXmlMDd.lib")
#		pragma message("Link LibX86 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib/libTinyXmlMD.lib")
#		pragma message("Link LibX86 TinyXmlMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMDd.lib")
#		pragma message("Link LibX64 TinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMD.lib")
#		pragma message("Link LibX64 TinyXmlMD.lib")
#	endif
#endif


tagBpaBlock*	g_pBpaBlock;
CBpaMemDBInterface	g_BpaMemDBInterface;
const	char*	g_lpszLogFile="BpaNetworkTailor.log";

extern	void	ClearLog(const char* lpszLogFile);
extern	int		LoadTailorSet(const char* lpszFileName, unsigned char& bRetainTieHG, unsigned char& bDCBoundPV, char* lpszSlack, std::vector<std::string>& strRetainAreaArray, std::vector<std::string>& strExcludeACBusArray, std::vector<std::string>& strExcludeDCBusArray);

int main(int argc, char** argv)
{
	int		nArg;
	clock_t	dBeg, dEnd;
	int		nDur;
	char	drive[260], dir[260], fname[260], ext[260];
	char	szSlack[260];
	unsigned char	bRetainTieHG, bDCBoundPV;

	std::vector<std::string>	strRetainAreaArray;
	std::vector<std::string>	strExcludeACBusArray;	//	ĸ������"%-8s %.2f"
	std::vector<std::string>	strExcludeDCBusArray;	//	ĸ������"%-8s %.2f"

	char	szBpaDatFile[260], szBpaSwiFile[260], szBpaShearSetFile[260], szBpaDatOutFile[260], szBpaSwiOutFile[260];
	memset(szBpaDatFile, 0, 260);
	memset(szBpaSwiFile, 0, 260);
	memset(szBpaShearSetFile, 0, 260);
	memset(szBpaDatOutFile, 0, 260);
	memset(szBpaSwiOutFile, 0, 260);
	if (argc < 5)
	{
		printf("��ȷ�ĺ����÷���: BpaNetworkTailor BpaDatFile BpaSwiFile BpaTailorSetXml BpaShearDatFile BpaShearSwiFile\n");
		return 0;
	}

	ClearLog(g_lpszLogFile);

	nArg=1;
	if (argc > nArg)	{	strcpy(szBpaDatFile, argv[nArg++]);			printf("BpaDatFile=%s\n", szBpaDatFile);		}	else	return 0;
	if (argc > nArg)	{	strcpy(szBpaSwiFile, argv[nArg++]);			printf("BpaSwiFile=%s\n", szBpaSwiFile);		}	else	return 0;
	if (argc > nArg)	{	strcpy(szBpaShearSetFile, argv[nArg++]);	printf("ShearSetFile=%s\n", szBpaShearSetFile);	}	else	return 0;
	if (argc > nArg)	{	strcpy(szBpaDatOutFile, argv[nArg++]);		printf("BpaDatOutFile=%s\n", szBpaDatOutFile);	}	else	return 0;
	if (argc > nArg)	{	strcpy(szBpaSwiOutFile, argv[nArg++]);		printf("BpaSwiOutFile=%s\n", szBpaSwiOutFile);	}	else	return 0;
	if (_access(szBpaDatFile, 0) != 0)
	{
		printf("BPA�����ļ�����\n");
		return 0;
	}
	if (_access(szBpaSwiFile, 0) != 0)
	{
		printf("BPA�ȶ��ļ�����\n");
		return 0;
	}
	if (_access(szBpaShearSetFile, 0) != 0)
	{
		printf("BPA�ü������ļ�����\n");
		return 0;
	}

	memset(szSlack, 0, 260);
	if (!LoadTailorSet(szBpaShearSetFile, bRetainTieHG, bDCBoundPV, szSlack, strRetainAreaArray, strExcludeACBusArray, strExcludeDCBusArray))
	{
		printf("����BPA�ü������ļ�����\n");
		return 0;
	}

	dBeg=clock();

	g_pBpaBlock=(tagBpaBlock*)g_BpaMemDBInterface.Init_BpaBlock();
	if (!g_pBpaBlock)
	{
		printf("��ȡBpa�ڴ�����\n");
		return 0;
	}

	_splitpath(szBpaDatOutFile, drive, dir, fname, ext);

	g_BpaMemDBInterface.BpaFiles2MemDB(g_pBpaBlock, szBpaDatFile, szBpaSwiFile, 0);
	strcpy(g_pBpaBlock->m_BpaDat_Case.szCaseID, fname);
	sprintf(g_pBpaBlock->m_BpaDat_Case.szNewBase, "%s.BSE", fname);
	strcpy(g_pBpaBlock->m_BpaDat_Case.szMap, fname);
	strcpy(g_pBpaBlock->m_BpaSwi_Case.szPFCASE, fname);

	g_BpaMemDBInterface.BpaTailorNetByZone(g_pBpaBlock, bRetainTieHG, bDCBoundPV, szSlack, strRetainAreaArray, strExcludeACBusArray, strExcludeDCBusArray);
	g_BpaMemDBInterface.BpaMemDB2Files(g_pBpaBlock, szBpaDatOutFile, szBpaSwiOutFile);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	printf("��ϣ���ʱ%d����\n", nDur);

	return 1;
}
