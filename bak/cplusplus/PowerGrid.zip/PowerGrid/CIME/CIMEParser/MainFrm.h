
// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once
#include "TableView.h"
#include "OutputWnd.h"

class CMainFrame : public CFrameWndEx
{

protected: // �������л�����
    CMainFrame();
    DECLARE_DYNCREATE(CMainFrame)

// ����
public:

// ����
public:

// ��д
public:
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
    virtual ~CMainFrame();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

public:
    COutputWnd        m_wndOutput;
protected:  // �ؼ���Ƕ���Ա
    CMFCMenuBar       m_wndMenuBar;
//	CMFCToolBar       m_wndToolBar;
    CMFCStatusBar     m_wndStatusBar;
    CTableView        m_wndTableView;

// ���ɵ���Ϣӳ�亯��
protected:
    afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
//	afx_msg void OnViewCustomize();
//	afx_msg LRESULT OnToolbarCreateNew(WPARAM wp, LPARAM lp);
    afx_msg void OnApplicationLook(UINT id);
    afx_msg void OnUpdateApplicationLook(CCmdUI* pCmdUI);
    afx_msg LRESULT OnClassChanged(WPARAM wParam, LPARAM lParam);
    DECLARE_MESSAGE_MAP()

    BOOL CreateDockingWindows();
    void SetDockingWindowIcons(BOOL bHiColorIcons);
private:
};


