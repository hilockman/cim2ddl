//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CIMEParser.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_CIMEParserTYPE            130
#define ID_WINDOW_MANAGER               131
#define IDS_WINDOWS_MANAGER             132
#define ID_VIEW_FILEVIEW                133
#define ID_VIEW_CLASSVIEW               134
#define ID_PROPERTIES                   135
#define ID_OPEN                         136
#define ID_OPEN_WITH                    137
#define ID_DUMMY_COMPILE                138
#define ID_CLASS_ADD_MEMBER_FUNCTION    139
#define ID_CLASS_ADD_MEMBER_VARIABLE    140
#define ID_CLASS_DEFINITION             141
#define ID_CLASS_PROPERTIES             142
#define ID_SORTING_GROUPBYTYPE          145
#define ID_SORTING_SORTALPHABETIC       146
#define ID_SORTING_SORTBYTYPE           147
#define ID_SORTING_SORTBYACCESS         148
#define ID_VIEW_OUTPUTWND               149
#define IDS_FILE_VIEW                   155
#define IDS_CLASS_VIEW                  156
#define IDS_OUTPUT_WND                  157
#define IDI_FILE_VIEW                   161
#define IDI_FILE_VIEW_HC                162
#define IDI_CLASS_VIEW                  163
#define IDI_CLASS_VIEW_HC               164
#define IDI_OUTPUT_WND                  165
#define IDI_OUTPUT_WND_HC               166
#define IDB_EXPLORER_24                 170
#define IDB_SORT_24                     172
#define IDR_POPUP_EXPLORER              174
#define IDB_FILE_VIEW                   175
#define IDB_FILE_VIEW_24                176
#define IDB_CLASS_VIEW                  177
#define IDB_CLASS_VIEW_24               178
#define IDR_MENU_IMAGES                 179
#define IDB_MENU_IMAGES_24              180
#define ID_TOOLS_MACRO                  181
#define IDR_OUTPUT_POPUP                182
#define IDR_THEME_MENU                  200
#define ID_SET_STYLE                    201
#define ID_VIEW_APPLOOK_WIN_2000        210
#define ID_VIEW_APPLOOK_OFF_XP          211
#define ID_VIEW_APPLOOK_WIN_XP          212
#define ID_VIEW_APPLOOK_OFF_2003        213
#define ID_VIEW_APPLOOK_VS_2005         214
#define ID_VIEW_APPLOOK_OFF_2007_BLUE   215
#define ID_VIEW_APPLOOK_OFF_2007_BLACK  216
#define ID_VIEW_APPLOOK_OFF_2007_SILVER 217
#define ID_VIEW_APPLOOK_OFF_2007_AQUA   218
#define IDS_BUILD_TAB                   300
#define IDS_DEBUG_TAB                   301
#define IDS_FIND_TAB                    302
#define IDS_EXPLORER                    305
#define IDS_EDIT_MENU                   306
#define ID_32771                        32771
#define ID_INPUT_BLOCK                  32772

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
