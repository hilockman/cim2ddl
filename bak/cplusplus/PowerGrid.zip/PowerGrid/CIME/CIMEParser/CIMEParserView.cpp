
// CIMEParserView.cpp : CCIMEParserView ���ʵ��
//

#include "stdafx.h"
#include "CIMEParser.h"

#include "CIMEParserDoc.h"
#include "CIMEParserView.h"

#include "../CIMEDataField.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCIMEParserView

IMPLEMENT_DYNCREATE(CCIMEParserView, CListView)

BEGIN_MESSAGE_MAP(CCIMEParserView, CListView)
    ON_MESSAGE(UM_CLASS_CHANGED,	OnClassChanged)
END_MESSAGE_MAP()

// CCIMEParserView ����/����

CCIMEParserView::CCIMEParserView()
{
    // TODO: �ڴ˴����ӹ������
    m_nCurClass=-1;
}

CCIMEParserView::~CCIMEParserView()
{
}

BOOL CCIMEParserView::PreCreateWindow(CREATESTRUCT& cs)
{
    // TODO: �ڴ˴�ͨ���޸�
    //  CREATESTRUCT cs ���޸Ĵ��������ʽ
    cs.style &= ~LVS_TYPEMASK;
    cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT;// | LVS_OWNERDATA | LVS_OWNERDRAWFIXED;
    return CListView::PreCreateWindow(cs);
}

void CCIMEParserView::OnInitialUpdate()
{
    CListView::OnInitialUpdate();


    // TODO: ���� GetListCtrl() ֱ�ӷ��� ListView ���б��ؼ���
    //  �Ӷ������������ ListView��
    GetListCtrl().SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void CCIMEParserView::OnRButtonUp(UINT nFlags, CPoint point)
{
    ClientToScreen(&point);
    OnContextMenu(this, point);
}

void CCIMEParserView::OnContextMenu(CWnd* pWnd, CPoint point)
{
    theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CCIMEParserView ���

#ifdef _DEBUG
void CCIMEParserView::AssertValid() const
{
    CListView::AssertValid();
}

void CCIMEParserView::Dump(CDumpContext& dc) const
{
    CListView::Dump(dc);
}

CCIMEParserDoc* CCIMEParserView::GetDocument() const // �ǵ��԰汾��������
{
    ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCIMEParserDoc)));
    return (CCIMEParserDoc*)m_pDocument;
}
#endif //_DEBUG


// CCIMEParserView ��Ϣ��������

void CCIMEParserView::Refresh(const int nClass)
{
    register int	i;
    char		szBuf[260];
    int			nCol, nColWidth, nHeaderWidth;
    int			nRowNum, nColNum;

    if (nClass < 0)
    {
        return;
    }

    nRowNum=nColNum=0;
    while (GetListCtrl().DeleteColumn(0));
    if (!GetListCtrl().DeleteAllItems())
    {
        return;
    }

    GetListCtrl().InsertColumn(0, "���");
    GetListCtrl().SetColumnWidth(0, 50);
    switch (nClass)
    {
    case	CIME_ControlArea:	//	ControlArea
        nRowNum=(int)g_CIMEData.m_ControlAreaArray.size();
        nColNum=sizeof(g_ControlAreaAttrArray)/sizeof(tagNameDesp);
        for (i=0; i<nColNum; i++)
            GetListCtrl().InsertColumn(i+1, g_ControlAreaAttrArray[i].szDesp);
        for (i=0; i<nRowNum; i++)
        {
            nCol=1;
            sprintf(szBuf, "%d", i+1);
            GetListCtrl().InsertItem(i, szBuf);

            GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ControlAreaArray[i].mRID);
            GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ControlAreaArray[i].name);
            GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ControlAreaArray[i].Parent);
            sprintf(szBuf, "%f", g_CIMEData.m_ControlAreaArray[i].p);		GetListCtrl().SetItemText(i, nCol++, szBuf);
            sprintf(szBuf, "%f", g_CIMEData.m_ControlAreaArray[i].q);		GetListCtrl().SetItemText(i, nCol++, szBuf);
        }
        break;

	case	CIME_BaseVoltage:	//	BaseVoltage
		nRowNum=(int)g_CIMEData.m_BaseVoltageArray.size();
		nColNum=sizeof(g_BaseVoltageAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_BaseVoltageAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BaseVoltageArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BaseVoltageArray[i].name);
			sprintf(szBuf, "%.2f", g_CIMEData.m_BaseVoltageArray[i].nomkV);		GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;
	case	CIME_Substation:	//	Substation
		nRowNum=(int)g_CIMEData.m_SubstationArray.size();
		nColNum=sizeof(g_SubstationAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_SubstationAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SubstationArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SubstationArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SubstationArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SubstationArray[i].type);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SubstationArray[i].ControlArea);
			sprintf(szBuf, "%f", g_CIMEData.m_SubstationArray[i].p);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SubstationArray[i].q);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SubstationArray[i].x);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SubstationArray[i].y);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_CIMEData.m_SubstationArray[i].i_flag);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_CIMEData.m_SubstationArray[i].mGdis_flag);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_CIMEData.m_SubstationArray[i].mUnXf_flag);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_VoltageLevel:	//	VoltageLevel
		nRowNum=(int)g_CIMEData.m_VoltageLevelArray.size();
		nColNum=sizeof(g_VoltageLevelAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_VoltageLevelAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_VoltageLevelArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_VoltageLevelArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_VoltageLevelArray[i].pathName);
			sprintf(szBuf, "%f", g_CIMEData.m_VoltageLevelArray[i].highkV);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_VoltageLevelArray[i].lowkV);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_VoltageLevelArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_VoltageLevelArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_VoltageLevelArray[i].type);
		}
		break;

	case	CIME_Breaker:	//	Breaker
		nRowNum=(int)g_CIMEData.m_BreakerArray.size();
		nColNum=sizeof(g_BreakerAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_BreakerAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].J_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BreakerArray[i].VoltageLevel);
			sprintf(szBuf, "%d", g_CIMEData.m_BreakerArray[i].status);		GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_Disconnector:	//	Disconnector
		nRowNum=(int)g_CIMEData.m_DisconnectorArray.size();
		nColNum=sizeof(g_DisconnectorAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_DisconnectorAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].J_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DisconnectorArray[i].VoltageLevel);
			sprintf(szBuf, "%d", g_CIMEData.m_DisconnectorArray[i].status);		GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_BusbarSection:	//	BusbarSection
		nRowNum=(int)g_CIMEData.m_BusbarSectionArray.size();
		nColNum=sizeof(g_BusbarSectionAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_BusbarSectionAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].VoltageLevel);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BusbarSectionArray[i].Location);
			sprintf(szBuf, "%f", g_CIMEData.m_BusbarSectionArray[i].V);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_BusbarSectionArray[i].A);		GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_SynchronousMachine:	//	SynchronousMachine
		nRowNum=(int)g_CIMEData.m_SynchronousMachineArray.size();
		nColNum=sizeof(g_SynchronousMachineAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_SynchronousMachineAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].type);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SynchronousMachineArray[i].VoltageLevel);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].RatedMW);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].maxU);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].minU);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].maxQ);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].minQ);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].maxP);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].minP);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].r);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].x);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].r0);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].x0);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].AuxRatio);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].P);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SynchronousMachineArray[i].Q);			GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_ACLineSegment:	//	ACLineSegment
		nRowNum=(int)g_CIMEData.m_ACLineSegmentArray.size();
		nColNum=sizeof(g_ACLineSegmentAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_ACLineSegmentAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineSegmentArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineSegmentArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineSegmentArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineSegmentArray[i].StartSt);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineSegmentArray[i].EndSt);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].ratedMW);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].ratedCurrent);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineSegmentArray[i].BaseVoltage);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].r);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].x);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].bch);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].r0);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].x0);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineSegmentArray[i].b0ch);			GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_ACLineDot:	//	ACLineDot
		nRowNum=(int)g_CIMEData.m_ACLineDotArray.size();
		nColNum=sizeof(g_ACLineDotAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_ACLineDotAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].ACLineSegment);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ACLineDotArray[i].VoltageLevel);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineDotArray[i].P);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ACLineDotArray[i].Q);				GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_DCLineSegment:	//	DCLineSegment
		nRowNum=(int)g_CIMEData.m_DCLineSegmentArray.size();
		nColNum=sizeof(g_DCLineSegmentAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_DCLineSegmentAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineSegmentArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineSegmentArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineSegmentArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineSegmentArray[i].StartSt);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineSegmentArray[i].EndSt);
			sprintf(szBuf, "%f", g_CIMEData.m_DCLineSegmentArray[i].r);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineSegmentArray[i].BaseVoltage);
		}
		break;

	case	CIME_DCLineDot:	//	DCLineDot
		nRowNum=(int)g_CIMEData.m_DCLineDotArray.size();
		nColNum=sizeof(g_DCLineDotAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_DCLineDotAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineDotArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineDotArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineDotArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineDotArray[i].DCLineSegment);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineDotArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DCLineDotArray[i].I_node);
			sprintf(szBuf, "%f", g_CIMEData.m_DCLineDotArray[i].P);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_DCLineDotArray[i].V);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_DCLineDotArray[i].I);				GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_RectifierInverter:	//	RectifierInverter
		nRowNum=(int)g_CIMEData.m_RectifierInverterArray.size();
		nColNum=sizeof(g_RectifierInverterAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_RectifierInverterAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].pathName);
			sprintf(szBuf, "%d", g_CIMEData.m_RectifierInverterArray[i].bridges);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_RectifierInverterArray[i].ratedKV);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].J_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].Z_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_RectifierInverterArray[i].BaseVoltage);
			sprintf(szBuf, "%f", g_CIMEData.m_RectifierInverterArray[i].P);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_RectifierInverterArray[i].Q);				GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_Load:	//	Load
		nRowNum=(int)g_CIMEData.m_LoadArray.size();
		nColNum=sizeof(g_LoadAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_LoadAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_LoadArray[i].VoltageLevel);
			sprintf(szBuf, "%f", g_CIMEData.m_LoadArray[i].P);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_LoadArray[i].Q);				GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_PowerTransformer:	//	PowerTransformer
		nRowNum=(int)g_CIMEData.m_PowerTransformerArray.size();
		nColNum=sizeof(g_PowerTransformerAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_PowerTransformerAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_PowerTransformerArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_PowerTransformerArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_PowerTransformerArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_PowerTransformerArray[i].type);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_PowerTransformerArray[i].Substation);
			sprintf(szBuf, "%f", g_CIMEData.m_PowerTransformerArray[i].NoLoadLoss);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_PowerTransformerArray[i].ExcitingCurrent);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_TransformerWinding:	//	TransformerWinding
		nRowNum=(int)g_CIMEData.m_TransformerWindingArray.size();
		nColNum=sizeof(g_TransformerWindingAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_TransformerWindingAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].WindingType);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].PowerTransformer);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].VoltageLevel);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TransformerWindingArray[i].TapChangerType);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].ratedMVA);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].ratedkV);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].loadLoss);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].leakageImpedence);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].x);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].r);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].x0);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].r0);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].P);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].Q);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TransformerWindingArray[i].D);					GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_TapChangerType:	//	TapChangerType
		nRowNum=(int)g_CIMEData.m_TapChangerTypeArray.size();
		nColNum=sizeof(g_TapChangerTypeAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_TapChangerTypeAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TapChangerTypeArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_TapChangerTypeArray[i].name);
			sprintf(szBuf, "%d", g_CIMEData.m_TapChangerTypeArray[i].neutralStep);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TapChangerTypeArray[i].neutralKV);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_CIMEData.m_TapChangerTypeArray[i].highStep);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_CIMEData.m_TapChangerTypeArray[i].lowStep);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TapChangerTypeArray[i].stepVolIncre);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_TapChangerTypeArray[i].D);					GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_ShuntCompensator:	//	ShuntCompensator
		nRowNum=(int)g_CIMEData.m_ShuntCompensatorArray.size();
		nColNum=sizeof(g_ShuntCompensatorAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_ShuntCompensatorAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].pathName);
			sprintf(szBuf, "%f", g_CIMEData.m_ShuntCompensatorArray[i].nomQ);				GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_ShuntCompensatorArray[i].V_rate);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].VoltageLevel);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_ShuntCompensatorArray[i].Substation);
			sprintf(szBuf, "%f", g_CIMEData.m_ShuntCompensatorArray[i].Q);					GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_SeriesCompensator:	//	SeriesCompensator
		nRowNum=(int)g_CIMEData.m_SeriesCompensatorArray.size();
		nColNum=sizeof(g_SeriesCompensatorAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_SeriesCompensatorAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].pathName);
			sprintf(szBuf, "%f", g_CIMEData.m_SeriesCompensatorArray[i].r);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SeriesCompensatorArray[i].x);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].I_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].J_node);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].BaseVoltage);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].VoltageLevel);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_SeriesCompensatorArray[i].Substation);
			sprintf(szBuf, "%f", g_CIMEData.m_SeriesCompensatorArray[i].Pi);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SeriesCompensatorArray[i].Qi);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SeriesCompensatorArray[i].Pj);					GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_CIMEData.m_SeriesCompensatorArray[i].Qj);					GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	CIME_Bay:	//	Bay
		nRowNum=(int)g_CIMEData.m_BayArray.size();
		nColNum=sizeof(g_BayAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_BayAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BayArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BayArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BayArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BayArray[i].Substation);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BayArray[i].VoltageLevel);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_BayArray[i].type);
		}
		break;

	case	CIME_Analog:	//	Analog
		nRowNum=(int)g_CIMEData.m_AnalogArray.size();
		nColNum=sizeof(g_AnalogAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_AnalogAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_AnalogArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_AnalogArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_AnalogArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_AnalogArray[i].devName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_AnalogArray[i].devID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_AnalogArray[i].type);
		}
		break;

	case	CIME_Discrete:	//	Discrete
		nRowNum=(int)g_CIMEData.m_DiscreteArray.size();
		nColNum=sizeof(g_DiscreteAttrArray)/sizeof(tagNameDesp);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_DiscreteAttrArray[i].szDesp);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DiscreteArray[i].mRID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DiscreteArray[i].name);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DiscreteArray[i].pathName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DiscreteArray[i].devName);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DiscreteArray[i].devID);
			GetListCtrl().SetItemText(i, nCol++, g_CIMEData.m_DiscreteArray[i].type);
		}
		break;

    default:
        break;
    }
    for (i=1; i<=nColNum; i++)
    {
        nColWidth=nHeaderWidth=0;

        GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
        nColWidth = GetListCtrl().GetColumnWidth(i);
        if (nRowNum <= 0)
        {
            GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
            nHeaderWidth =GetListCtrl().GetColumnWidth(i);
        }

        GetListCtrl().SetColumnWidth(i, max(nColWidth, nHeaderWidth));
    }
}

LRESULT CCIMEParserView::OnClassChanged(WPARAM wParam, LPARAM lParam)
{
    TRACE("ViewOnClassChanged: %d\n", wParam);
    if (m_nCurClass != wParam && wParam >= 0)
    {
        m_nCurClass=wParam;
        Refresh(m_nCurClass);
    }
    return 0;
}
