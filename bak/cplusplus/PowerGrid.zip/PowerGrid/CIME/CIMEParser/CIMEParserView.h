
// CIMEParserView.h : CCIMEParserView ��Ľӿ�
//


#pragma once


class CCIMEParserView : public CListView
{
protected: // �������л�����
    CCIMEParserView();
    DECLARE_DYNCREATE(CCIMEParserView)

// ����
public:
    CCIMEParserDoc* GetDocument() const;

// ����
public:

// ��д
public:
    virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
    virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
    virtual ~CCIMEParserView();
#ifdef _DEBUG
    virtual void AssertValid() const;
    virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
    afx_msg void OnFilePrintPreview();
    afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
    afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
    afx_msg LRESULT OnClassChanged(WPARAM wParam, LPARAM lParam);
    DECLARE_MESSAGE_MAP()
private:
    void Refresh(const int nClass);
    int m_nCurClass;
protected:
//	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
};

#ifndef _DEBUG  // CIMEParserView.cpp �еĵ��԰汾
inline CCIMEParserDoc* CCIMEParserView::GetDocument() const
{
    return reinterpret_cast<CCIMEParserDoc*>(m_pDocument);
}
#endif

