#include "stdafx.h"
#include "CIMEData.h"
#include "CIMEDataField.h"

int CCIMEData::read(const char* lpszFileName, const int bPackedName)
{
	register int	i;
	int		nChar;
	FILE*	fp;
	char	szLine[1024], szParser[1024];
	char	szClass[260], szEntity[260];
	int		nLen, bread;
	int		nContentType;
	int		nColNum, nColIndex[100];
	FILE*	fpDebug;
	char	szFileName[260], szTempPath[260];

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
	sprintf(szFileName, "%s/readCIME.dbg", szTempPath);
#else
	strcpy(szTempPath, "/tmp");
	sprintf(szFileName, "%s/readCIME.dbg", szTempPath);
#endif

	fp=fopen(lpszFileName, "r");
	if (fp == NULL)
		return 0;

	fpDebug=fopen(szFileName, "w");

	m_nClassNum=0;
	for (i=0; i<50; i++)
	{
		memset(m_szClassArray[i], 0, CIME_CHARLEN);
	}

    m_ControlAreaArray.clear();
    m_BaseVoltageArray.clear();
    m_SubstationArray.clear();
    m_VoltageLevelArray.clear();
    m_BreakerArray.clear();
    m_DisconnectorArray.clear();
    m_BusbarSectionArray.clear();
    m_SynchronousMachineArray.clear();
    m_ACLineSegmentArray.clear();
    m_ACLineDotArray.clear();
    m_DCLineSegmentArray.clear();
    m_DCLineDotArray.clear();
    m_RectifierInverterArray.clear();
    m_LoadArray.clear();
    m_PowerTransformerArray.clear();
    m_TransformerWindingArray.clear();
    m_TapChangerTypeArray.clear();
    m_ShuntCompensatorArray.clear();
    m_SeriesCompensatorArray.clear();
    m_BayArray.clear();
    m_AnalogArray.clear();
    m_DiscreteArray.clear();

	nContentType=-1;
	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);
		if (strlen(szLine) <= 0)
			continue;

		nLen=bread=0;
		for (i=0; i<(int)strlen(szLine); i++)
		{
			if (szLine[i] == '\'')
			{
				szLine[i]=' ';
				nChar=i+1;
				bread=(int)strlen(szLine);
				while (nChar < (int)strlen(szLine))
				{
					if (szLine[nChar] == '\'')
					{
						szLine[nChar]=' ';
						break;
					}
					if (szLine[nChar] == ' ')
					{
						szLine[nChar]='_';
					}
					nChar++;
				}
			}
		}
		bread=0;
		for (i=0; i<(int)strlen(szLine); i++)
		{
			if ((szLine[i] == ' ' || szLine[i] == '\t') && !bread)
			{
				continue;
			}
			else
			{
				bread=1;
			}
			szParser[nLen++]=szLine[i];
		}
		szParser[nLen]='\0';

		if (isComment(szParser))
		{
			continue;
		}
		if (isEntity(szParser))
		{
			readEntity(szParser);
			continue;
		}
		if (strncmp(szParser, "</", 2) == 0)
		{
			switch (nContentType)
			{
			case	CIME_ControlArea:
				break;
			}
			nContentType=-1;
			nColNum=0;
			continue;
		}
		else if (strncmp(szParser, "<", 1) == 0)
		{
			memset(szClass, 0, 260);
			memset(szEntity, 0, 260);

			if (readClass(szParser, szClass, szEntity))
			{
				nContentType=-1;
				nColNum=0;
				if (STRICMP(szClass, "ControlArea") == 0)				nContentType=CIME_ControlArea;
				else if (STRICMP(szClass, "BaseVoltage") == 0)			nContentType=CIME_BaseVoltage;
				else if (STRICMP(szClass, "Substation") == 0)			nContentType=CIME_Substation;
				else if (STRICMP(szClass, "VoltageLevel") == 0)			nContentType=CIME_VoltageLevel;
				else if (STRICMP(szClass, "Breaker") == 0)				nContentType=CIME_Breaker;
				else if (STRICMP(szClass, "Disconnector") == 0)			nContentType=CIME_Disconnector;
				else if (STRICMP(szClass, "BusbarSection") == 0)			nContentType=CIME_BusbarSection;
				else if (STRICMP(szClass, "SynchronousMachine") == 0)	nContentType=CIME_SynchronousMachine;
				else if (STRICMP(szClass, "ACLineSegment") == 0)			nContentType=CIME_ACLineSegment;
				else if (STRICMP(szClass, "ACLineDot") == 0)				nContentType=CIME_ACLineDot;
				else if (STRICMP(szClass, "DCLineSegment") == 0)			nContentType=CIME_DCLineSegment;
				else if (STRICMP(szClass, "DCLineDot") == 0)				nContentType=CIME_DCLineDot;
				else if (STRICMP(szClass, "RectifierInverter") == 0)		nContentType=CIME_RectifierInverter;
				else if (STRICMP(szClass, "Load") == 0)					nContentType=CIME_Load;
				else if (STRICMP(szClass, "PowerTransformer") == 0)		nContentType=CIME_PowerTransformer;
				else if (STRICMP(szClass, "TransformerWinding") == 0)	nContentType=CIME_TransformerWinding;
				else if (STRICMP(szClass, "TapChangerType") == 0)		nContentType=CIME_TapChangerType;
				else if (STRICMP(szClass, "ShuntCompensator") == 0)		nContentType=CIME_ShuntCompensator;
				else if (STRICMP(szClass, "SeriesCompensator") == 0)		nContentType=CIME_SeriesCompensator;
				else if (STRICMP(szClass, "Bay") == 0)					nContentType=CIME_Bay;
				else if (STRICMP(szClass, "Analog") == 0)				nContentType=CIME_Analog;
				else if (STRICMP(szClass, "Discrete") == 0)				nContentType=CIME_Discrete;
			}
			continue;
		}
		if (nContentType >= 0)
		{
			if (isAttribute(szParser))
			{
				nColNum=0;
				readAttributes(nContentType, szParser, &nColNum, nColIndex);
			}
			if (isData(szParser) && nColNum > 0)
			{
				switch (nContentType)
				{
				case	CIME_ControlArea:			readControlArea(szParser, nColNum, nColIndex);		break;
				case	CIME_BaseVoltage:			readBaseVoltage(szParser, nColNum, nColIndex);		break;
				case	CIME_Substation:			readSubstation(szParser, nColNum, nColIndex);			break;
				case	CIME_VoltageLevel:			readVoltageLevel(szParser, nColNum, nColIndex);		break;
				case	CIME_Breaker:				readBreaker(szParser, nColNum, nColIndex);			break;
				case	CIME_Disconnector:			readDisconnector(szParser, nColNum, nColIndex);		break;
				case	CIME_BusbarSection:			readBusbarSection(szParser, nColNum, nColIndex);		break;
				case	CIME_SynchronousMachine:	readSynchronousMachine(szParser, nColNum, nColIndex);	break;
				case	CIME_ACLineSegment:			readACLineSegment(szParser, nColNum, nColIndex);		break;
				case	CIME_ACLineDot:				readACLineDot(szParser, nColNum, nColIndex);			break;
				case	CIME_DCLineSegment:			readDCLineSegment(szParser, nColNum, nColIndex);		break;
				case	CIME_DCLineDot:				readDCLineDot(szParser, nColNum, nColIndex);			break;
				case	CIME_RectifierInverter:		readRectifierInverter(szParser, nColNum, nColIndex);	break;
				case	CIME_Load:					readLoad(szParser, nColNum, nColIndex);				break;
				case	CIME_PowerTransformer:		readPowerTransformer(szParser, nColNum, nColIndex);	break;
				case	CIME_TransformerWinding:	readTransformerWinding(szParser, nColNum, nColIndex);	break;
				case	CIME_TapChangerType:		readTapChangerType(szParser, nColNum, nColIndex);		break;
				case	CIME_ShuntCompensator:		readShuntCompensator(szParser, nColNum, nColIndex);	break;
				case	CIME_SeriesCompensator:		readSeriesCompensator(szParser, nColNum, nColIndex);	break;
				case	CIME_Bay:					readBay(szParser, nColNum, nColIndex);				break;
				case	CIME_Analog:				readAnalog(szParser, nColNum, nColIndex);				break;
				case	CIME_Discrete:				readDiscrete(szParser, nColNum, nColIndex);			break;
				default:																				break;
				}
			}
		}
	}

	fclose(fp);

	if (fpDebug != NULL)
	{
		fflush(fpDebug);
		fclose(fpDebug);
	}
	return 1;
}

void CCIMEData::readAttributes(const int nTable, char* lpszParser, int* pnColNum, int nColIndex[])
{
	register int	i, j;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][100];

	if (strncmp(lpszParser, "@", 1) != 0)
	{
		return;
	}

	(*pnColNum)=nEle=0;
	lpszToken=strtok(lpszParser, " \t\n@");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n@");
	}

	(*pnColNum)=nEle;
	for (i=0; i<nEle; i++)
	{
		nColIndex[i]=-1;
		switch (nTable)
		{
		case	CIME_ControlArea:
			for (j=0; j<sizeof(g_ControlAreaAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_ControlAreaAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_BaseVoltage:
			for (j=0; j<sizeof(g_BaseVoltageAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_BaseVoltageAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Substation:
			for (j=0; j<sizeof(g_SubstationAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_SubstationAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_VoltageLevel:
			for (j=0; j<sizeof(g_VoltageLevelAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_VoltageLevelAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Breaker:
			for (j=0; j<sizeof(g_BreakerAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_BreakerAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Disconnector:
			for (j=0; j<sizeof(g_DisconnectorAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_DisconnectorAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_BusbarSection:
			for (j=0; j<sizeof(g_BusbarSectionAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_BusbarSectionAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_SynchronousMachine:
			for (j=0; j<sizeof(g_SynchronousMachineAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_SynchronousMachineAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_ACLineSegment:
			for (j=0; j<sizeof(g_ACLineSegmentAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_ACLineSegmentAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_ACLineDot:
			for (j=0; j<sizeof(g_ACLineDotAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_ACLineDotAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_DCLineSegment:
			for (j=0; j<sizeof(g_DCLineSegmentAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_DCLineSegmentAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_DCLineDot:
			for (j=0; j<sizeof(g_DCLineDotAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_DCLineDotAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_RectifierInverter:
			for (j=0; j<sizeof(g_RectifierInverterAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_RectifierInverterAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Load:
			for (j=0; j<sizeof(g_LoadAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_LoadAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_PowerTransformer:
			for (j=0; j<sizeof(g_PowerTransformerAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_PowerTransformerAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_TransformerWinding:
			for (j=0; j<sizeof(g_TransformerWindingAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_TransformerWindingAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_TapChangerType:
			for (j=0; j<sizeof(g_TapChangerTypeAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_TapChangerTypeAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_ShuntCompensator:
			for (j=0; j<sizeof(g_ShuntCompensatorAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_ShuntCompensatorAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_SeriesCompensator:
			for (j=0; j<sizeof(g_SeriesCompensatorAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_SeriesCompensatorAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Bay:
			for (j=0; j<sizeof(g_BayAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_BayAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Analog:
			for (j=0; j<sizeof(g_AnalogAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_AnalogAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		case	CIME_Discrete:
			for (j=0; j<sizeof(g_DiscreteAttrArray)/sizeof(tagNameDesp); j++)
			{
				if (STRICMP(g_DiscreteAttrArray[j].szName, szEle[i]) == 0)
				{
					nColIndex[i]=j;
					break;
				}
			}
			break;
		default:
			break;
		}
	}
}

void CCIMEData::readEntity(char* lpszParser)
{

}

void CCIMEData::readControlArea(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEControlArea	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEControlArea));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_ControlArea_mRID:
			strcpy(dBuf.mRID, szEle[i]);
			break;
		case	CIME_ControlArea_name:
			strcpy(dBuf.name, szEle[i]);
			break;
		case	CIME_ControlArea_Parent:
			strcpy(dBuf.Parent, szEle[i]);
			break;
		case	CIME_ControlArea_p:
			dBuf.p=(float)atof(szEle[i]);
			break;
		case	CIME_ControlArea_q:
			dBuf.q=(float)atof(szEle[i]);
			break;
		default:
			break;
		}
	}
	m_ControlAreaArray.push_back(dBuf);
}

void CCIMEData::readBaseVoltage(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEBaseVoltage	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEBaseVoltage));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_BaseVoltage_mRID:
			strcpy(dBuf.mRID, szEle[i]);
			break;
		case	CIME_BaseVoltage_name:
			strcpy(dBuf.name, szEle[i]);
			break;
		case	CIME_BaseVoltage_nomkV:
			dBuf.nomkV=(float)atof(szEle[i]);
			break;
		default:
			break;
		}
	}
	m_BaseVoltageArray.push_back(dBuf);
}

void CCIMEData::readSubstation(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMESubstation	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMESubstation));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Substation_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_Substation_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_Substation_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_Substation_type:			strcpy(dBuf.type, szEle[i]);			break;
		case	CIME_Substation_ControlArea:	strcpy(dBuf.ControlArea, szEle[i]);	break;
		case	CIME_Substation_p:				dBuf.p=(float)atof(szEle[i]);		break;
		case	CIME_Substation_q:				dBuf.q=(float)atof(szEle[i]);		break;
		case	CIME_Substation_x:				dBuf.x=(float)atof(szEle[i]);		break;
		case	CIME_Substation_y:				dBuf.y=(float)atof(szEle[i]);		break;
		case	CIME_Substation_i_flag:			dBuf.i_flag=atoi(szEle[i]);			break;
		case	CIME_Substation_mGdis_flag:		dBuf.mGdis_flag=atoi(szEle[i]);		break;
		case	CIME_Substation_mUnXf_flag:		dBuf.mUnXf_flag=atoi(szEle[i]);		break;
		default:
			break;
		}
	}
	m_SubstationArray.push_back(dBuf);
}

void CCIMEData::readVoltageLevel(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEVoltageLevel	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEVoltageLevel));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_VoltageLevel_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_VoltageLevel_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_VoltageLevel_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_VoltageLevel_highkV:		dBuf.highkV=(float)atof(szEle[i]);	break;
		case	CIME_VoltageLevel_lowkV:		dBuf.lowkV=(float)atof(szEle[i]);	break;
		case	CIME_VoltageLevel_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_VoltageLevel_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_VoltageLevel_type:			strcpy(dBuf.type, szEle[i]);			break;
		default:
			break;
		}
	}

	ResolveVoltageLevelName(dBuf.pathName, dBuf.name);
	m_VoltageLevelArray.push_back(dBuf);
}

void CCIMEData::ResolveVoltageLevelName(const char* lpszResolveName, char* lpszRetName)
{
	char	szBuf[260];
	std::vector<std::string>	strEleArray;

	strEleArray.clear();
	strcpy(szBuf, lpszResolveName);

	char*	lpszToken=strtok(szBuf, " \t\n-\\/");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " \t\n-\\/");
	}
	if (!strEleArray.empty())
		strcpy(lpszRetName, strEleArray[strEleArray.size()-1].c_str());
}

void CCIMEData::readBreaker(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEBreaker	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEBreaker));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Breaker_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_Breaker_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_Breaker_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_Breaker_I_node:		strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_Breaker_J_node:		strcpy(dBuf.J_node, szEle[i]);		break;
		case	CIME_Breaker_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_Breaker_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_Breaker_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_Breaker_status:		dBuf.status=atoi(szEle[i]);			break;
		default:
			break;
		}
	}
	m_BreakerArray.push_back(dBuf);
}

void CCIMEData::readDisconnector(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEDisconnector	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEDisconnector));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Disconnector_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_Disconnector_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_Disconnector_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_Disconnector_I_node:		strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_Disconnector_J_node:		strcpy(dBuf.J_node, szEle[i]);		break;
		case	CIME_Disconnector_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_Disconnector_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_Disconnector_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_Disconnector_status:		dBuf.status=atoi(szEle[i]);			break;
		default:
			break;
		}
	}
	m_DisconnectorArray.push_back(dBuf);
}

void CCIMEData::readBusbarSection(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEBusbarSection	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEBusbarSection));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_BusbarSection_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_BusbarSection_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_BusbarSection_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_BusbarSection_I_node:			strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_BusbarSection_Substation:		strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_BusbarSection_BaseVoltage:		strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_BusbarSection_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_BusbarSection_Location:		strcpy(dBuf.Location, szEle[i]);		break;
		case	CIME_BusbarSection_V:				dBuf.V=(float)atof(szEle[i]);		break;
		case	CIME_BusbarSection_A:				dBuf.A=(float)atof(szEle[i]);		break;
		default:
			break;
		}
	}
	m_BusbarSectionArray.push_back(dBuf);
}

void CCIMEData::readSynchronousMachine(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMESynchronousMachine	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMESynchronousMachine));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_SynchronousMachine_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_SynchronousMachine_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_SynchronousMachine_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_SynchronousMachine_type:			strcpy(dBuf.type, szEle[i]);			break;
		case	CIME_SynchronousMachine_I_node:			strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_SynchronousMachine_Substation:		strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_SynchronousMachine_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_SynchronousMachine_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_SynchronousMachine_RatedMW:		dBuf.RatedMW=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_maxU:			dBuf.maxU=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_minU:			dBuf.minU=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_maxQ:			dBuf.maxQ=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_minQ:			dBuf.minQ=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_maxP:			dBuf.maxP=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_minP:			dBuf.minP=(float)atof(szEle[i]);	break;
		case	CIME_SynchronousMachine_r:				dBuf.r=(float)atof(szEle[i]);		break;
		case	CIME_SynchronousMachine_x:				dBuf.x=(float)atof(szEle[i]);		break;
		case	CIME_SynchronousMachine_r0:				dBuf.r0=(float)atof(szEle[i]);		break;
		case	CIME_SynchronousMachine_x0:				dBuf.x0=(float)atof(szEle[i]);		break;
		case	CIME_SynchronousMachine_AuxRatio:		dBuf.AuxRatio=(float)atof(szEle[i]);break;
		case	CIME_SynchronousMachine_P:				dBuf.P=(float)atof(szEle[i]);		break;
		case	CIME_SynchronousMachine_Q:				dBuf.Q=(float)atof(szEle[i]);		break;
		default:
			break;
		}
	}
	m_SynchronousMachineArray.push_back(dBuf);
}

void CCIMEData::readACLineSegment(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEACLineSegment	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEACLineSegment));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_ACLineSegment_mRID:		strcpy(dBuf.mRID, szEle[i]);					break;
		case	CIME_ACLineSegment_name:		strcpy(dBuf.name, szEle[i]);					break;
		case	CIME_ACLineSegment_pathName:	strcpy(dBuf.pathName, szEle[i]);				break;
		case	CIME_ACLineSegment_StartSt:		strcpy(dBuf.StartSt, szEle[i]);				break;
		case	CIME_ACLineSegment_EndSt:		strcpy(dBuf.EndSt, szEle[i]);				break;
		case	CIME_ACLineSegment_ratedMW:			dBuf.ratedMW=(float)atof(szEle[i]);			break;
		case	CIME_ACLineSegment_ratedCurrent:	dBuf.ratedCurrent=(float)atof(szEle[i]);	break;
		case	CIME_ACLineSegment_BaseVoltage:		strcpy(dBuf.BaseVoltage, szEle[i]);			break;
		case	CIME_ACLineSegment_r:			dBuf.r=(float)atof(szEle[i]);				break;
		case	CIME_ACLineSegment_x:			dBuf.x=(float)atof(szEle[i]);				break;
		case	CIME_ACLineSegment_bch:			dBuf.bch=(float)atof(szEle[i]);				break;
		case	CIME_ACLineSegment_r0:			dBuf.r0=(float)atof(szEle[i]);				break;
		case	CIME_ACLineSegment_x0:			dBuf.x0=(float)atof(szEle[i]);				break;
		case	CIME_ACLineSegment_b0ch:		dBuf.b0ch=(float)atof(szEle[i]);			break;
		default:
			break;
		}
	}
	m_ACLineSegmentArray.push_back(dBuf);
}

void CCIMEData::readACLineDot(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEACLineDot	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEACLineDot));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_ACLineDot_mRID:			strcpy(dBuf.mRID, szEle[i]);				break;
		case	CIME_ACLineDot_name:			strcpy(dBuf.name, szEle[i]);				break;
		case	CIME_ACLineDot_pathName:		strcpy(dBuf.pathName, szEle[i]);			break;
		case	CIME_ACLineDot_ACLineSegment:	strcpy(dBuf.ACLineSegment, szEle[i]);	break;
		case	CIME_ACLineDot_Substation:		strcpy(dBuf.Substation, szEle[i]);		break;
		case	CIME_ACLineDot_I_node:			strcpy(dBuf.I_node, szEle[i]);			break;
		case	CIME_ACLineDot_BaseVoltage:		strcpy(dBuf.BaseVoltage, szEle[i]);		break;
		case	CIME_ACLineDot_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);		break;
		case	CIME_ACLineDot_P:				dBuf.P=(float)atof(szEle[i]);			break;
		case	CIME_ACLineDot_Q:				dBuf.Q=(float)atof(szEle[i]);			break;
		default:
			break;
		}
	}
	m_ACLineDotArray.push_back(dBuf);
}

void CCIMEData::readDCLineSegment(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEDCLineSegment	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEDCLineSegment));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_DCLineSegment_mRID:		strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_DCLineSegment_name:		strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_DCLineSegment_pathName:	strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_DCLineSegment_StartSt:		strcpy(dBuf.StartSt, szEle[i]);		break;
		case	CIME_DCLineSegment_EndSt:		strcpy(dBuf.EndSt, szEle[i]);		break;
		case	CIME_DCLineSegment_r:			dBuf.r=(float)atof(szEle[i]);		break;
		case	CIME_DCLineSegment_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		default:
			break;
		}
	}
	m_DCLineSegmentArray.push_back(dBuf);
}

void CCIMEData::readDCLineDot(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEDCLineDot	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEDCLineDot));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_DCLineDot_mRID:			strcpy(dBuf.mRID, szEle[i]);				break;
		case	CIME_DCLineDot_name:			strcpy(dBuf.name, szEle[i]);				break;
		case	CIME_DCLineDot_pathName:		strcpy(dBuf.pathName, szEle[i]);			break;
		case	CIME_DCLineDot_DCLineSegment:	strcpy(dBuf.DCLineSegment, szEle[i]);	break;
		case	CIME_DCLineDot_Substation:		strcpy(dBuf.Substation, szEle[i]);		break;
		case	CIME_DCLineDot_I_node:			strcpy(dBuf.I_node, szEle[i]);			break;
		case	CIME_DCLineDot_P:				dBuf.P=(float)atof(szEle[i]);			break;
		case	CIME_DCLineDot_V:				dBuf.V=(float)atof(szEle[i]);			break;
		case	CIME_DCLineDot_I:				dBuf.I=(float)atof(szEle[i]);			break;
		default:
			break;
		}
	}
	m_DCLineDotArray.push_back(dBuf);
}

void CCIMEData::readRectifierInverter(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMERectifierInverter	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMERectifierInverter));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_RectifierInverter_mRID:		strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_RectifierInverter_name:		strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_RectifierInverter_pathName:	strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_RectifierInverter_bridges:		dBuf.bridges=atoi(szEle[i]);		break;
		case	CIME_RectifierInverter_ratedKV:		dBuf.ratedKV=(float)atof(szEle[i]);	break;
		case	CIME_RectifierInverter_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_RectifierInverter_I_node:		strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_RectifierInverter_J_node:		strcpy(dBuf.J_node, szEle[i]);		break;
		case	CIME_RectifierInverter_Z_node:		strcpy(dBuf.Z_node, szEle[i]);		break;
		case	CIME_RectifierInverter_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_RectifierInverter_P:			dBuf.P=(float)atof(szEle[i]);		break;
		case	CIME_RectifierInverter_Q:			dBuf.Q=(float)atof(szEle[i]);		break;
		default:
			break;
		}
	}
	m_RectifierInverterArray.push_back(dBuf);
}

void CCIMEData::readLoad(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMELoad	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMELoad));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Load_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_Load_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_Load_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_Load_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_Load_I_node:		strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_Load_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_Load_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_Load_P:			dBuf.P=(float)atof(szEle[i]);		break;
		case	CIME_Load_Q:			dBuf.Q=(float)atof(szEle[i]);		break;
		default:
			break;
		}
	}
	m_LoadArray.push_back(dBuf);
}

void CCIMEData::readPowerTransformer(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEPowerTransformer	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEPowerTransformer));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_PowerTransformer_mRID:				strcpy(dBuf.mRID, szEle[i]);					break;
		case	CIME_PowerTransformer_name:				strcpy(dBuf.name, szEle[i]);					break;
		case	CIME_PowerTransformer_pathName:			strcpy(dBuf.pathName, szEle[i]);				break;
		case	CIME_PowerTransformer_type:				strcpy(dBuf.type, szEle[i]);					break;
		case	CIME_PowerTransformer_Substation:		strcpy(dBuf.Substation, szEle[i]);			break;
		case	CIME_PowerTransformer_NoLoadLoss:		dBuf.NoLoadLoss=(float)atof(szEle[i]);		break;
		case	CIME_PowerTransformer_ExcitingCurrent:	dBuf.ExcitingCurrent=(float)atof(szEle[i]);	break;
		default:
			break;
		}
	}
	m_PowerTransformerArray.push_back(dBuf);
}

void CCIMEData::readTransformerWinding(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMETransformerWinding	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMETransformerWinding));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_TransformerWinding_mRID:				strcpy(dBuf.mRID, szEle[i]);				break;
		case	CIME_TransformerWinding_name:				strcpy(dBuf.name, szEle[i]);				break;
		case	CIME_TransformerWinding_pathName:			strcpy(dBuf.pathName, szEle[i]);			break;
		case	CIME_TransformerWinding_WindingType:		strcpy(dBuf.WindingType, szEle[i]);		break;
		case	CIME_TransformerWinding_Substation:			strcpy(dBuf.Substation, szEle[i]);		break;
		case	CIME_TransformerWinding_PowerTransformer:	strcpy(dBuf.PowerTransformer, szEle[i]);	break;
		case	CIME_TransformerWinding_I_node:				strcpy(dBuf.I_node, szEle[i]);			break;
		case	CIME_TransformerWinding_BaseVoltage:		strcpy(dBuf.BaseVoltage, szEle[i]);		break;
		case	CIME_TransformerWinding_VoltageLevel:		strcpy(dBuf.VoltageLevel, szEle[i]);		break;
		case	CIME_TransformerWinding_TapChangerType:		strcpy(dBuf.TapChangerType, szEle[i]);	break;
		case	CIME_TransformerWinding_ratedMVA:			dBuf.ratedMVA=(float)atof(szEle[i]);	break;
		case	CIME_TransformerWinding_ratedkV:			dBuf.ratedkV=(float)atof(szEle[i]);		break;
		case	CIME_TransformerWinding_loadLoss:			dBuf.loadLoss=(float)atof(szEle[i]);	break;
		case	CIME_TransformerWinding_leakageImpedence:	dBuf.leakageImpedence=(float)atof(szEle[i]);	break;
		case	CIME_TransformerWinding_x:					dBuf.x=(float)atof(szEle[i]);			break;
		case	CIME_TransformerWinding_r:					dBuf.r=(float)atof(szEle[i]);			break;
		case	CIME_TransformerWinding_x0:					dBuf.x0=(float)atof(szEle[i]);			break;
		case	CIME_TransformerWinding_r0:					dBuf.r0=(float)atof(szEle[i]);			break;
		case	CIME_TransformerWinding_P:					dBuf.P=(float)atof(szEle[i]);			break;
		case	CIME_TransformerWinding_Q:					dBuf.Q=(float)atof(szEle[i]);			break;
		case	CIME_TransformerWinding_D:					dBuf.D=(float)atof(szEle[i]);			break;
		default:
			break;
		}
	}
	m_TransformerWindingArray.push_back(dBuf);
}

void CCIMEData::readTapChangerType(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMETapChangerType	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMETapChangerType));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_TapChangerType_mRID:			strcpy(dBuf.mRID, szEle[i]);				break;
		case	CIME_TapChangerType_name:			strcpy(dBuf.name, szEle[i]);				break;
		case	CIME_TapChangerType_neutralStep:	dBuf.neutralStep=atoi(szEle[i]);		break;
		case	CIME_TapChangerType_neutralKV:		dBuf.neutralKV=(float)atof(szEle[i]);	break;
		case	CIME_TapChangerType_highStep:		dBuf.highStep=atoi(szEle[i]);			break;
		case	CIME_TapChangerType_lowStep:		dBuf.lowStep=atoi(szEle[i]);			break;
		case	CIME_TapChangerType_stepVolIncre:	dBuf.stepVolIncre=(float)atof(szEle[i]);break;
		case	CIME_TapChangerType_D:				dBuf.D=(float)atof(szEle[i]);			break;
		default:
			break;
		}
	}
	m_TapChangerTypeArray.push_back(dBuf);
}

void CCIMEData::readShuntCompensator(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEShuntCompensator	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEShuntCompensator));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_ShuntCompensator_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_ShuntCompensator_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_ShuntCompensator_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_ShuntCompensator_nomQ:			dBuf.nomQ=(float)atof(szEle[i]);	break;
		case	CIME_ShuntCompensator_V_rate:		dBuf.V_rate=(float)atof(szEle[i]);	break;
		case	CIME_ShuntCompensator_I_node:		strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_ShuntCompensator_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_ShuntCompensator_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_ShuntCompensator_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_ShuntCompensator_Q:			dBuf.Q=(float)atof(szEle[i]);		break;
		default:
			break;
		}
	}
	m_ShuntCompensatorArray.push_back(dBuf);
}

void CCIMEData::readSeriesCompensator(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMESeriesCompensator	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMESeriesCompensator));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_SeriesCompensator_mRID:		strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_SeriesCompensator_name:		strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_SeriesCompensator_pathName:	strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_SeriesCompensator_r:			dBuf.r=(float)atof(szEle[i]);		break;
		case	CIME_SeriesCompensator_x:			dBuf.x=(float)atof(szEle[i]);		break;
		case	CIME_SeriesCompensator_I_node:		strcpy(dBuf.I_node, szEle[i]);		break;
		case	CIME_SeriesCompensator_J_node:		strcpy(dBuf.J_node, szEle[i]);		break;
		case	CIME_SeriesCompensator_BaseVoltage:	strcpy(dBuf.BaseVoltage, szEle[i]);	break;
		case	CIME_SeriesCompensator_VoltageLevel:strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_SeriesCompensator_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_SeriesCompensator_Pi:			dBuf.Pi=(float)atof(szEle[i]);		break;
		case	CIME_SeriesCompensator_Qi:			dBuf.Qi=(float)atof(szEle[i]);		break;
		case	CIME_SeriesCompensator_Pj:			dBuf.Pj=(float)atof(szEle[i]);		break;
		case	CIME_SeriesCompensator_Qj:			dBuf.Qj=(float)atof(szEle[i]);		break;
		default:
			break;
		}
	}
	m_SeriesCompensatorArray.push_back(dBuf);
}

void CCIMEData::readBay(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEBay	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEBay));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Bay_mRID:			strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_Bay_name:			strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_Bay_pathName:		strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_Bay_Substation:	strcpy(dBuf.Substation, szEle[i]);	break;
		case	CIME_Bay_VoltageLevel:	strcpy(dBuf.VoltageLevel, szEle[i]);	break;
		case	CIME_Bay_type:			strcpy(dBuf.type, szEle[i]);			break;
		default:
			break;
		}
	}
	m_BayArray.push_back(dBuf);
}







void CCIMEData::readAnalog(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEAnalog	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEAnalog));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Analog_mRID:		strcpy(dBuf.mRID, szEle[i]);			break;
		case	CIME_Analog_name:		strcpy(dBuf.name, szEle[i]);			break;
		case	CIME_Analog_pathName:	strcpy(dBuf.pathName, szEle[i]);		break;
		case	CIME_Analog_devName:	strcpy(dBuf.devName, szEle[i]);		break;
		case	CIME_Analog_devID:		strcpy(dBuf.devID, szEle[i]);		break;
		case	CIME_Analog_type:		strcpy(dBuf.type, szEle[i]);			break;
		default:
			break;
		}
	}
	m_AnalogArray.push_back(dBuf);
}

void CCIMEData::readDiscrete(char* lpszParser, int nColNum, int nColIndex[])
{
	register int	i;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][CIME_CHARLEN];

	tagCIMEDiscrete	dBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
	{
		return;
	}
	memset(&dBuf, 0, sizeof(tagCIMEDiscrete));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		memset(szEle[nEle], 0, CIME_CHARLEN);
		if (STRICMP(lpszToken, "NULL") != 0)
			strcpy(szEle[nEle], lpszToken);

		nEle++;

		lpszToken=strtok(NULL, " \t\n");
	}
	if (nEle != nColNum)
	{
		return;
	}

	for (i=0; i<nColNum; i++)
	{
		switch (nColIndex[i])
		{
		case	CIME_Discrete_mRID:		strcpy(dBuf.mRID, szEle[i]);		break;
		case	CIME_Discrete_name:		strcpy(dBuf.name, szEle[i]);		break;
		case	CIME_Discrete_pathName:	strcpy(dBuf.pathName, szEle[i]);	break;
		case	CIME_Discrete_devName:	strcpy(dBuf.devName, szEle[i]);	break;
		case	CIME_Discrete_devID:	strcpy(dBuf.devID, szEle[i]);	break;
		case	CIME_Discrete_type:		strcpy(dBuf.type, szEle[i]);		break;
		default:
			break;
		}
	}
	m_DiscreteArray.push_back(dBuf);
}

int CCIMEData::readClass(char* lpszParser, char* lpszRetClass, char* lpszRetEntity)
{
	register int	i;
	int		bExist;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][100];

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n<>:");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n<>:");
	}
	if (nEle > 1)
	{
		strcpy(lpszRetClass, szEle[0]);
		strcpy(lpszRetEntity, szEle[1]);
		bExist=0;
		for (i=0; i<m_nClassNum; i++)
		{
			if (strcmp(m_szClassArray[i], lpszRetClass) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			strcpy(m_szClassArray[m_nClassNum++], lpszRetClass);
		}
	}
	else
	{
		return 0;
	}

	return 1;
}

int CCIMEData::isComment(const char* lpszParser)
{
	if (strncmp(lpszParser, "//", 2) == 0)
	{
		return 1;
	}

	return 0;
}

int CCIMEData::isEntity(const char* lpszParser)
{
	if (strncmp(lpszParser, "<!", 2) == 0)
	{
		return 1;
	}

	return 0;
}

int CCIMEData::isAttribute(const char* lpszParser)
{
	if (strncmp(lpszParser, "@", 1) == 0)
	{
		return 1;
	}

	return 0;
}

int CCIMEData::isData(const char* lpszParser)
{
	if (strncmp(lpszParser, "#", 1) == 0)
	{
		return 1;
	}

	return 0;
}