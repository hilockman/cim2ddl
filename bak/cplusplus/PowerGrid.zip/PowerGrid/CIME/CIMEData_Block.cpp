#include "stdafx.h"

char*	CCIMEData::mRID2name(const int nClass, const char* lpszmRID)
{
	register int	i;
	switch (nClass)
	{
	case	CIME_ControlArea:			for (i=0; i<(int)m_ControlAreaArray.size(); i++)		{	if (STRICMP(lpszmRID, m_ControlAreaArray[i].mRID) == 0)			return m_ControlAreaArray[i].name;			}	break;
	case	CIME_BaseVoltage:			for (i=0; i<(int)m_BaseVoltageArray.size(); i++)		{	if (STRICMP(lpszmRID, m_BaseVoltageArray[i].mRID) == 0)			return m_BaseVoltageArray[i].name;			}	break;
	case	CIME_Substation:			for (i=0; i<(int)m_SubstationArray.size(); i++)			{	if (STRICMP(lpszmRID, m_SubstationArray[i].mRID) == 0)			return m_SubstationArray[i].name;			}	break;
	case	CIME_VoltageLevel:			for (i=0; i<(int)m_VoltageLevelArray.size(); i++)		{	if (STRICMP(lpszmRID, m_VoltageLevelArray[i].mRID) == 0)			return m_VoltageLevelArray[i].name;			}	break;
	case	CIME_Breaker:				for (i=0; i<(int)m_BreakerArray.size(); i++)			{	if (STRICMP(lpszmRID, m_BreakerArray[i].mRID) == 0	)			return m_BreakerArray[i].name;				}	break;
	case	CIME_Disconnector:			for (i=0; i<(int)m_DisconnectorArray.size(); i++)		{	if (STRICMP(lpszmRID, m_DisconnectorArray[i].mRID) == 0)			return m_DisconnectorArray[i].name;			}	break;
	case	CIME_BusbarSection:			for (i=0; i<(int)m_BusbarSectionArray.size(); i++)		{	if (STRICMP(lpszmRID, m_BusbarSectionArray[i].mRID) == 0)		return m_BusbarSectionArray[i].name;		}	break;
	case	CIME_SynchronousMachine:	for (i=0; i<(int)m_SynchronousMachineArray.size(); i++)	{	if (STRICMP(lpszmRID, m_SynchronousMachineArray[i].mRID) == 0)	return m_SynchronousMachineArray[i].name;	}	break;
	case	CIME_ACLineSegment:			for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)		{	if (STRICMP(lpszmRID, m_ACLineSegmentArray[i].mRID) == 0)		return m_ACLineSegmentArray[i].name;		}	break;
	case	CIME_ACLineDot:				for (i=0; i<(int)m_ACLineDotArray.size(); i++)			{	if (STRICMP(lpszmRID, m_ACLineDotArray[i].mRID) == 0)			return m_ACLineDotArray[i].name;			}	break; 
	case	CIME_DCLineSegment:			for (i=0; i<(int)m_DCLineSegmentArray.size(); i++)		{	if (STRICMP(lpszmRID, m_DCLineSegmentArray[i].mRID) == 0)		return m_DCLineSegmentArray[i].name;		}	break;
	case	CIME_DCLineDot:				for (i=0; i<(int)m_DCLineDotArray.size(); i++)			{	if (STRICMP(lpszmRID, m_DCLineDotArray[i].mRID) == 0)			return m_DCLineDotArray[i].name;			}	break;
	case	CIME_RectifierInverter:		for (i=0; i<(int)m_RectifierInverterArray.size(); i++)	{	if (STRICMP(lpszmRID, m_RectifierInverterArray[i].mRID) == 0)	return m_RectifierInverterArray[i].name;	}	break;
	case	CIME_Load:					for (i=0; i<(int)m_LoadArray.size(); i++)				{	if (STRICMP(lpszmRID, m_LoadArray[i].mRID) == 0)					return m_LoadArray[i].name;					}	break;
	case	CIME_PowerTransformer:		for (i=0; i<(int)m_PowerTransformerArray.size(); i++)	{	if (STRICMP(lpszmRID, m_PowerTransformerArray[i].mRID) == 0)		return m_PowerTransformerArray[i].name;		}	break;
	case	CIME_TransformerWinding:	for (i=0; i<(int)m_TransformerWindingArray.size(); i++)	{	if (STRICMP(lpszmRID, m_TransformerWindingArray[i].mRID) == 0)	return m_TransformerWindingArray[i].name;	}	break;
	case	CIME_TapChangerType:		for (i=0; i<(int)m_TapChangerTypeArray.size(); i++)		{	if (STRICMP(lpszmRID, m_TapChangerTypeArray[i].mRID) == 0)		return m_TapChangerTypeArray[i].name;		}	break;
	case	CIME_ShuntCompensator:		for (i=0; i<(int)m_ShuntCompensatorArray.size(); i++)	{	if (STRICMP(lpszmRID, m_ShuntCompensatorArray[i].mRID) == 0)		return m_ShuntCompensatorArray[i].name;		}	break;
	case	CIME_SeriesCompensator:		for (i=0; i<(int)m_SeriesCompensatorArray.size(); i++)	{	if (STRICMP(lpszmRID, m_SeriesCompensatorArray[i].mRID) == 0)	return m_SeriesCompensatorArray[i].name;	}	break;
	case	CIME_Bay:					for (i=0; i<(int)m_BayArray.size(); i++)				{	if (STRICMP(lpszmRID, m_BayArray[i].mRID) == 0)					return m_BayArray[i].name;					}	break;
	case	CIME_Analog:				for (i=0; i<(int)m_AnalogArray.size(); i++)				{	if (STRICMP(lpszmRID, m_AnalogArray[i].mRID) == 0)				return m_AnalogArray[i].name;				}	break;
	case	CIME_Discrete:				for (i=0; i<(int)m_DiscreteArray.size(); i++)			{	if (STRICMP(lpszmRID, m_DiscreteArray[i].mRID) == 0)				return m_DiscreteArray[i].name;				}	break;
	default:							break;
	}

	return "";
}

char*	CCIMEData::getTaptype(const char* lpszmRID)
{
	register int	i;
	for (i=0; i<(int)m_TapChangerTypeArray.size(); i++)
	{
		if (STRICMP(m_TapChangerTypeArray[i].mRID, lpszmRID) == 0)
		{
			return m_TapChangerTypeArray[i].name;
		}
	}
	return "�ֽ�ͷ00";
}

float	CCIMEData::getBaseVoltage(const char* lpszmRID)
{
	register int	i;
	for (i=0; i<(int)m_BaseVoltageArray.size(); i++)
	{
		if (STRICMP(m_BaseVoltageArray[i].mRID, lpszmRID) == 0)
		{
			return m_BaseVoltageArray[i].nomkV;
		}
	}
	return -1;
}

int	CCIMEData::isSubExclude(const char* lpszmRID)
{
//  	if (STRICMP(lpszmRID, "vst") == 0)
//  		return 1;
	return 0;
}

void	CCIMEData::clearDatabase(tagPGBlock* pBlock)
{
    register int	i;
    for (i=0; i<MAXMDBTABLENUM; i++)
        pBlock->m_nRecordNum[i]=0;
}

void	CCIMEData::insertDefault(tagPGBlock* pBlock)
{
    register int	i;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

	pBlock->m_nRecordNum[PG_SYSTEM]=1;
	pBlock->m_System.fBasePower=100;

    strcpy(szField[PG_COMPANY_NAME], "����");
    PGAppendRecord(pBlock, MDB_NeedCheckData, PG_COMPANY, szField);

    strcpy(szField[PG_COMPANY_NAME], "����");
    PGAppendRecord(pBlock, MDB_NeedCheckData, PG_COMPANY, szField);

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    strcpy(szField[PG_SUBCONTROLAREA_COMPANY], "����");
    strcpy(szField[PG_SUBCONTROLAREA_NAME], "����");
    PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SUBCONTROLAREA, szField);

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    strcpy(szField[PG_TAPCHANGER_NAME], "0��0��0%");
    strcpy(szField[PG_TAPCHANGER_TAPMIN], "0");
    strcpy(szField[PG_TAPCHANGER_TAPMAX], "0");
    strcpy(szField[PG_TAPCHANGER_TAPNOM], "0");
    strcpy(szField[PG_TAPCHANGER_TAPSTEP], "0");
    PGAppendRecord(pBlock, MDB_NeedCheckData, PG_TAPCHANGER, szField);

    insertTapChangerType(pBlock);
}

void CCIMEData::insertSubcontrolArea(tagPGBlock* pBlock, const int bCimAsOutnet)
{
    register int	i;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    if (pBlock->m_nRecordNum[PG_COMPANY] > 2)
    {
        if (bCimAsOutnet)
            strcpy(szField[PG_SUBCONTROLAREA_COMPANY], pBlock->m_CompanyArray[0].szName);
        else
            strcpy(szField[PG_SUBCONTROLAREA_COMPANY], pBlock->m_CompanyArray[1].szName);
    }
    else
    {
        strcpy(szField[PG_SUBCONTROLAREA_COMPANY], pBlock->m_CompanyArray[0].szName);
    }

    for (i=0; i<(int)m_ControlAreaArray.size(); i++)
    {
        strcpy(szField[PG_SUBCONTROLAREA_RESOURCEID], m_ControlAreaArray[i].mRID);
        strcpy(szField[PG_SUBCONTROLAREA_NAME], m_ControlAreaArray[i].name);
        strcpy(szField[PG_SUBCONTROLAREA_DESC], m_ControlAreaArray[i].Parent);
        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SUBCONTROLAREA, szField);
    }
}

void CCIMEData::insertSubstation(tagPGBlock* pBlock)
{
    register int	i, j;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (i=0; i<(int)m_SubstationArray.size(); i++)
    {
        if (m_SubstationArray[i].bExclude)
            continue;

        if (strlen(m_SubstationArray[i].ControlArea) <= 0)
        {
            log("�޷����볧վ, ��SubcontrolArea��Ϣ: (%s) (%s)\n", m_SubstationArray[i].ControlArea, m_SubstationArray[i].name);
            continue;
        }

        strcpy(szField[PG_SUBSTATION_RESOURCEID],		m_SubstationArray[i].mRID);
        strcpy(szField[PG_SUBSTATION_NAME],			m_SubstationArray[i].name);
        strcpy(szField[PG_SUBSTATION_DESC],			m_SubstationArray[i].pathName);
        strcpy(szField[PG_SUBSTATION_SUBCONTROLAREA],	mRID2name(CIME_ControlArea, m_SubstationArray[i].ControlArea));
        for (j=0; j<pBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
        {
            if (STRICMP(pBlock->m_SubcontrolAreaArray[j].szName, mRID2name(CIME_ControlArea, m_SubstationArray[i].ControlArea)) == 0)
            {
                strcpy(szField[PG_SUBSTATION_COMPANY], pBlock->m_SubcontrolAreaArray[j].szCompany);
                break;
            }
        }
        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SUBSTATION, szField);
    }
}

void CCIMEData::insertVoltageLevel(tagPGBlock* pBlock)
{
    register int	i;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (i=0; i<(int)m_VoltageLevelArray.size(); i++)
    {
		if (strlen(m_VoltageLevelArray[i].Substation) <= 0)
        {
            log("�޷������ѹ�ȼ�, ��Substation��Ϣ: (%s) (%s)\n", m_VoltageLevelArray[i].name, m_VoltageLevelArray[i].Substation);
            continue;
        }
		if (isSubExclude(m_VoltageLevelArray[i].Substation))
			continue;

        strcpy(szField[PG_VOLTAGELEVEL_RESOURCEID], m_VoltageLevelArray[i].mRID);
		strcpy(szField[PG_VOLTAGELEVEL_NAME], m_VoltageLevelArray[i].name);
		strcpy(szField[PG_VOLTAGELEVEL_DESC], m_VoltageLevelArray[i].pathName);
        strcpy(szField[PG_VOLTAGELEVEL_SUBSTATION], mRID2name(CIME_Substation, m_VoltageLevelArray[i].Substation));
        sprintf(szField[PG_VOLTAGELEVEL_NOMINALVOLTAGE], "%f", getBaseVoltage(m_VoltageLevelArray[i].BaseVoltage));
        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_VOLTAGELEVEL, szField);
    }
}

void CCIMEData::insertACLine(tagPGBlock* pBlock)
{
    register int	i;
	int			nDot;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    float		fVolt, fBase;

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
    {
		fVolt=getBaseVoltage(m_ACLineSegmentArray[i].BaseVoltage);
        fBase=pBlock->m_System.fBasePower/(fVolt*fVolt);

        strcpy(szField[PG_ACLINESEGMENT_RESOURCEID],			m_ACLineSegmentArray[i].mRID);
        strcpy(szField[PG_ACLINESEGMENT_NAME],				m_ACLineSegmentArray[i].name);
        strcpy(szField[PG_ACLINESEGMENT_DESC],			m_ACLineSegmentArray[i].pathName);
        strcpy(szField[PG_ACLINESEGMENT_ISUBSTATION],			mRID2name(CIME_Substation, m_ACLineSegmentArray[i].StartSt));
        strcpy(szField[PG_ACLINESEGMENT_JSUBSTATION],			mRID2name(CIME_Substation, m_ACLineSegmentArray[i].EndSt));

		sprintf(szField[PG_ACLINESEGMENT_R], "%f", m_ACLineSegmentArray[i].r*fBase);
		sprintf(szField[PG_ACLINESEGMENT_X], "%f", m_ACLineSegmentArray[i].x*fBase);
		sprintf(szField[PG_ACLINESEGMENT_B], "%f", m_ACLineSegmentArray[i].bch/fBase/2000000.0);
		sprintf(szField[PG_ACLINESEGMENT_R0], "%f", m_ACLineSegmentArray[i].r0*fBase);
		sprintf(szField[PG_ACLINESEGMENT_X0], "%f", m_ACLineSegmentArray[i].x0*fBase);
		sprintf(szField[PG_ACLINESEGMENT_B0], "%f", m_ACLineSegmentArray[i].b0ch/fBase/2000000.0);
		sprintf(szField[PG_ACLINESEGMENT_RATEMVA], "%f", m_ACLineSegmentArray[i].ratedMW);
		sprintf(szField[PG_ACLINESEGMENT_RATECUR], "%f", m_ACLineSegmentArray[i].ratedCurrent);

		for (nDot=0; nDot<(int)m_ACLineDotArray.size(); nDot++)
		{
			if (STRICMP(m_ACLineDotArray[nDot].ACLineSegment, m_ACLineSegmentArray[i].mRID) != 0)
				continue;

			if (STRICMP(m_ACLineDotArray[nDot].Substation, m_ACLineSegmentArray[i].StartSt) == 0)
			{
				strcpy(szField[PG_ACLINESEGMENT_IVOLTAGELEVEL],		mRID2name(CIME_VoltageLevel, m_ACLineDotArray[nDot].VoltageLevel));
				strcpy(szField[PG_ACLINESEGMENT_CONNECTIVITYNODEI],	m_ACLineDotArray[nDot].I_node);
			}
			else if (STRICMP(m_ACLineDotArray[nDot].Substation, m_ACLineSegmentArray[i].EndSt) == 0)
			{
				strcpy(szField[PG_ACLINESEGMENT_JVOLTAGELEVEL],		mRID2name(CIME_VoltageLevel, m_ACLineDotArray[nDot].VoltageLevel));
				strcpy(szField[PG_ACLINESEGMENT_CONNECTIVITYNODEJ],	m_ACLineDotArray[nDot].I_node);
			}
		}
        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ACLINESEGMENT, szField);
    }
}

void CCIMEData::insertTransformer(tagPGBlock* pBlock)
{
    register int	i;
    int			nDev, nWind, nWindNum, nWindArray[10];
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
    float		fBase, fVolt;
    int			nWindH, nWindM, nWindL;


    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
    {
        if (strlen(m_PowerTransformerArray[nDev].Substation) <= 0)
        {
            log("�޷������ѹ��, ��Substation��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
            continue;
        }
		if (isSubExclude(m_PowerTransformerArray[nDev].Substation))
			continue;

		nWindNum=0;
		nWindH=nWindM=nWindL=-1;
		for (nWind=0; nWind<(int)m_TransformerWindingArray.size(); nWind++)
		{
			if (STRICMP(m_TransformerWindingArray[nWind].PowerTransformer, m_PowerTransformerArray[nDev].mRID) == 0)
			{
				nWindNum++;
				if (STRICMP(m_TransformerWindingArray[nWind].WindingType, "��") == 0)
					nWindH=nWind;
				if (STRICMP(m_TransformerWindingArray[nWind].WindingType, "��") == 0)
					nWindM=nWind;
				if (STRICMP(m_TransformerWindingArray[nWind].WindingType, "��") == 0)
					nWindL=nWind;
			}
		}

        if (nWindNum != 2 && nWindNum != 3)
        {
            log("�޷������ѹ��, ��ѹ������=%d����: (%s) (%s)\n", nWindNum, m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
            continue;
        }

        fBase=1;
        if (nWindNum == 2)	//	������
        {
			if (nWindH < 0)	continue;
			if (nWindL < 0)	continue;

            if (strlen(m_TransformerWindingArray[nWindH].VoltageLevel) <= 0)
            {
                log("�޷������ѹ��, ��VoltageH��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindL].VoltageLevel) <= 0)
            {
                log("�޷������ѹ��, ��VoltageL��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindH].I_node) <= 0)
            {
                log("�޷������ѹ��, �޸�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation, m_TransformerWindingArray[nWindH].I_node, m_TransformerWindingArray[nWindL].I_node);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindL].I_node) <= 0)
            {
                log("�޷������ѹ��, �޵�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation, m_TransformerWindingArray[nWindH].I_node, m_TransformerWindingArray[nWindL].I_node);
                continue;
            }

			fVolt=getBaseVoltage(m_TransformerWindingArray[nWindH].BaseVoltage);
			fBase=pBlock->m_System.fBasePower/(fVolt*fVolt);

            strcpy(szField[PG_TRANSFORMERWINDING_RESOURCEID], m_PowerTransformerArray[nDev].mRID);
            strcpy(szField[PG_TRANSFORMERWINDING_NAME], m_PowerTransformerArray[nDev].name);
            strcpy(szField[PG_TRANSFORMERWINDING_DESC], m_PowerTransformerArray[nDev].pathName);
            strcpy(szField[PG_TRANSFORMERWINDING_SUBSTATION], mRID2name(CIME_Substation, m_PowerTransformerArray[nDev].Substation));
            strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELI], mRID2name(CIME_VoltageLevel, m_TransformerWindingArray[nWindH].VoltageLevel));
            strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ], mRID2name(CIME_VoltageLevel, m_TransformerWindingArray[nWindL].VoltageLevel));
            strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEI], m_TransformerWindingArray[nWindH].I_node);
            strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], m_TransformerWindingArray[nWindL].I_node);
			sprintf(szField[PG_TRANSFORMERWINDING_RATEMVA], "%f", m_TransformerWindingArray[nWindH].ratedMVA);
			strcpy(szField[PG_TRANSFORMERWINDING_TAPCHANGERI], getTaptype(m_TransformerWindingArray[nWindH].TapChangerType));
			strcpy(szField[PG_TRANSFORMERWINDING_TAPCHANGERZ], getTaptype(m_TransformerWindingArray[nWindL].TapChangerType));

			sprintf(szField[PG_TRANSFORMERWINDING_RATEKVI], "%f", m_TransformerWindingArray[nWindH].ratedkV);
			sprintf(szField[PG_TRANSFORMERWINDING_RATEKVJ], "%f", m_TransformerWindingArray[nWindL].ratedkV);

			sprintf(szField[PG_TRANSFORMERWINDING_R], "%f", m_TransformerWindingArray[nWindH].r*fBase);
			sprintf(szField[PG_TRANSFORMERWINDING_X], "%f", m_TransformerWindingArray[nWindH].x*fBase);
			sprintf(szField[PG_TRANSFORMERWINDING_R0], "%f", m_TransformerWindingArray[nWindH].r0*fBase);
			sprintf(szField[PG_TRANSFORMERWINDING_X0], "%f", m_TransformerWindingArray[nWindH].x0*fBase);

            PGAppendRecord(pBlock, MDB_NeedCheckData, PG_TRANSFORMERWINDING, szField);
        }
        else if (nWindNum == 3)	//	������
        {
            if (nWindH < 0)	continue;
            if (nWindM < 0)	continue;
            if (nWindL < 0)	continue;

			nWindArray[0]=nWindH;
			nWindArray[1]=nWindM;
			nWindArray[2]=nWindL;

            fBase=pBlock->m_System.fBasePower/(getBaseVoltage(m_TransformerWindingArray[nWindH].BaseVoltage)*getBaseVoltage(m_TransformerWindingArray[nWindH].BaseVoltage));

            if (strlen(m_TransformerWindingArray[nWindH].VoltageLevel) <= 0)
            {
                log("�޷������ѹ��, ��VoltageH��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindM].VoltageLevel) <= 0)
            {
                log("�޷������ѹ��, ��VoltageM��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindL].VoltageLevel) <= 0)
            {
                log("�޷������ѹ��, ��VoltageL��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindH].I_node) <= 0)
            {
                log("�޷������ѹ��, �޸�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation, m_TransformerWindingArray[nWindH].I_node, m_TransformerWindingArray[nWindM].I_node, m_TransformerWindingArray[nWindL].I_node);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindM].I_node) <= 0)
            {
                log("�޷������ѹ��, ����ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation, m_TransformerWindingArray[nWindH].I_node, m_TransformerWindingArray[nWindM].I_node, m_TransformerWindingArray[nWindL].I_node);
                continue;
            }
            if (strlen(m_TransformerWindingArray[nWindL].I_node) <= 0)
            {
                log("�޷������ѹ��, �޵�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].name, m_PowerTransformerArray[nDev].Substation, m_TransformerWindingArray[nWindH].I_node, m_TransformerWindingArray[nWindM].I_node, m_TransformerWindingArray[nWindL].I_node);
                continue;
            }

            for (i=0; i<nWindNum; i++)
            {
				nWind=nWindArray[i];

				fVolt=getBaseVoltage(m_TransformerWindingArray[nWindH].BaseVoltage);
				fBase=pBlock->m_System.fBasePower/(fVolt*fVolt);

				strcpy(szField[PG_TRANSFORMERWINDING_RESOURCEID], m_TransformerWindingArray[nWind].mRID);
				strcpy(szField[PG_TRANSFORMERWINDING_NAME], m_TransformerWindingArray[nWind].name);
				strcpy(szField[PG_TRANSFORMERWINDING_DESC], m_TransformerWindingArray[nWind].pathName);
				strcpy(szField[PG_TRANSFORMERWINDING_SUBSTATION], mRID2name(CIME_Substation, m_PowerTransformerArray[nDev].Substation));
				strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELI], mRID2name(CIME_VoltageLevel, m_TransformerWindingArray[nWind].VoltageLevel));
				strcpy(szField[PG_TRANSFORMERWINDING_VOLTAGELEVELJ], mRID2name(CIME_VoltageLevel, m_TransformerWindingArray[nWindL].VoltageLevel));
				strcpy(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEI], m_TransformerWindingArray[nWind].I_node);
				sprintf(szField[PG_TRANSFORMERWINDING_CONNECTIVITYNODEJ], "%s_t", m_PowerTransformerArray[nDev].name);
				sprintf(szField[PG_TRANSFORMERWINDING_RATEMVA], "%f", m_TransformerWindingArray[nWindH].ratedMVA);
				strcpy(szField[PG_TRANSFORMERWINDING_TAPCHANGERI], getTaptype(m_TransformerWindingArray[nWind].TapChangerType));
				strcpy(szField[PG_TRANSFORMERWINDING_TAPCHANGERZ], "�ֽ�ͷ00");

				sprintf(szField[PG_TRANSFORMERWINDING_RATEKVI], "%f", m_TransformerWindingArray[nWind].ratedkV);
				sprintf(szField[PG_TRANSFORMERWINDING_RATEKVJ], "%f", m_TransformerWindingArray[nWindL].ratedkV);

				sprintf(szField[PG_TRANSFORMERWINDING_R], "%f", m_TransformerWindingArray[nWind].r*fBase);
				sprintf(szField[PG_TRANSFORMERWINDING_X], "%f", m_TransformerWindingArray[nWind].x*fBase);
				sprintf(szField[PG_TRANSFORMERWINDING_R0], "%f", m_TransformerWindingArray[nWind].r0*fBase);
				sprintf(szField[PG_TRANSFORMERWINDING_X0], "%f", m_TransformerWindingArray[nWind].x0*fBase);

				sprintf(szField[PG_TRANSFORMERWINDING_ITAP], "%f", m_TransformerWindingArray[nWind].D);

				PGAppendRecord(pBlock, MDB_NeedCheckData, PG_TRANSFORMERWINDING, szField);
            }
        }
    }
}

void CCIMEData::insertSynchronousMachine(tagPGBlock* pBlock)
{
    register int	i;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (i=0; i<(int)m_SynchronousMachineArray.size(); i++)
    {
		if (strlen(m_SynchronousMachineArray[i].Substation) <= 0)
        {
            log("�޷����뷢���, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_SynchronousMachineArray[i].name, m_SynchronousMachineArray[i].Substation, m_SynchronousMachineArray[i].VoltageLevel);
            continue;
        }
		if (isSubExclude(m_SynchronousMachineArray[i].Substation))
			continue;

        if (strlen(m_SynchronousMachineArray[i].VoltageLevel) <= 0)
        {
            log("�޷����뷢���, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_SynchronousMachineArray[i].name, m_SynchronousMachineArray[i].Substation, m_SynchronousMachineArray[i].VoltageLevel);
            continue;
        }
        if (strlen(m_SynchronousMachineArray[i].I_node) <= 0)
        {
            log("�޷����뷢���, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", m_SynchronousMachineArray[i].name, m_SynchronousMachineArray[i].Substation, m_SynchronousMachineArray[i].VoltageLevel);
            continue;
        }


        if (m_SynchronousMachineArray[i].maxP <= 0)
        {
            if (m_SynchronousMachineArray[i].RatedMW > 0)
                m_SynchronousMachineArray[i].maxP=m_SynchronousMachineArray[i].RatedMW;
            else
                m_SynchronousMachineArray[i].maxP=300;
        }
        if (m_SynchronousMachineArray[i].maxQ <= 0)
            m_SynchronousMachineArray[i].maxQ=(float)(0.9*m_SynchronousMachineArray[i].maxP);

        strcpy(szField[PG_SYNCHRONOUSMACHINE_RESOURCEID], m_SynchronousMachineArray[i].mRID);
        strcpy(szField[PG_SYNCHRONOUSMACHINE_NAME], m_SynchronousMachineArray[i].name);
        strcpy(szField[PG_SYNCHRONOUSMACHINE_DESC], m_SynchronousMachineArray[i].pathName);
        strcpy(szField[PG_SYNCHRONOUSMACHINE_SUBSTATION], mRID2name(CIME_Substation, m_SynchronousMachineArray[i].Substation));
		strcpy(szField[PG_SYNCHRONOUSMACHINE_VOLTAGELEVEL], mRID2name(CIME_VoltageLevel, m_SynchronousMachineArray[i].VoltageLevel));
        strcpy(szField[PG_SYNCHRONOUSMACHINE_CONNECTIVITYNODE], m_SynchronousMachineArray[i].I_node);

        sprintf(szField[PG_SYNCHRONOUSMACHINE_PQMVARATE], "%f", m_SynchronousMachineArray[i].RatedMW);
        sprintf(szField[PG_SYNCHRONOUSMACHINE_PMAX], "%f", m_SynchronousMachineArray[i].maxP);
        sprintf(szField[PG_SYNCHRONOUSMACHINE_PMIN], "%f", m_SynchronousMachineArray[i].minP);
        sprintf(szField[PG_SYNCHRONOUSMACHINE_QMAX], "%f", m_SynchronousMachineArray[i].maxQ);
        sprintf(szField[PG_SYNCHRONOUSMACHINE_QMIN], "%f", m_SynchronousMachineArray[i].minQ);

		sprintf(szField[PG_SYNCHRONOUSMACHINE_PLANP], "%f", m_SynchronousMachineArray[i].P);
		sprintf(szField[PG_SYNCHRONOUSMACHINE_PLANQ], "%f", m_SynchronousMachineArray[i].Q);
		sprintf(szField[PG_SYNCHRONOUSMACHINE_P], "%f", m_SynchronousMachineArray[i].P);
		sprintf(szField[PG_SYNCHRONOUSMACHINE_Q], "%f", m_SynchronousMachineArray[i].Q);

        strcpy(szField[PG_SYNCHRONOUSMACHINE_AUXPCA], "0");
        strcpy(szField[PG_SYNCHRONOUSMACHINE_AUXPVA], "0");
        strcpy(szField[PG_SYNCHRONOUSMACHINE_AUXFACTOR], "0");

		strcpy(szField[PG_SYNCHRONOUSMACHINE_PVND], "0");
		if (m_SynchronousMachineArray[i].RatedMW > 300 || m_SynchronousMachineArray[i].maxP > 300)
			strcpy(szField[PG_SYNCHRONOUSMACHINE_PVND], "1");

        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SYNCHRONOUSMACHINE, szField);
    }
}

void CCIMEData::insertLoad(tagPGBlock* pBlock)
{
     register int	i;
     char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
 
     for (i=0; i<MAXMDBFIELDNUM; i++)
         memset(szField[i], 0, MDB_CHARLEN_LONG);
 
     for (i=0; i<(int)m_LoadArray.size(); i++)
     {
		 if (strlen(m_LoadArray[i].Substation) <= 0)
         {
             log("�޷����븺��, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_LoadArray[i].name, m_LoadArray[i].Substation, m_LoadArray[i].VoltageLevel);
             continue;
         }
		 if (isSubExclude(m_LoadArray[i].Substation))
			 continue;

		 if (strlen(m_LoadArray[i].VoltageLevel) <= 0)
         {
             log("�޷����븺��, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_LoadArray[i].name, m_LoadArray[i].Substation, m_LoadArray[i].VoltageLevel);
             continue;
         }
         if (strlen(m_LoadArray[i].I_node) <= 0)
         {
             log("�޷����븺��, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", m_LoadArray[i].name, m_LoadArray[i].Substation, m_LoadArray[i].VoltageLevel);
             continue;
         }
 
         strcpy(szField[PG_ENERGYCONSUMER_RESOURCEID], m_LoadArray[i].mRID);
         strcpy(szField[PG_ENERGYCONSUMER_NAME], m_LoadArray[i].name);
         strcpy(szField[PG_ENERGYCONSUMER_DESC], m_LoadArray[i].pathName);
         strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION], mRID2name(CIME_Substation, m_LoadArray[i].Substation));
         strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL], mRID2name(CIME_VoltageLevel, m_LoadArray[i].VoltageLevel));
         strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE], m_LoadArray[i].I_node);
         sprintf(szField[PG_ENERGYCONSUMER_PLANP], "%f", m_LoadArray[i].P);
         sprintf(szField[PG_ENERGYCONSUMER_PLANQ], "%f", m_LoadArray[i].Q);
         sprintf(szField[PG_ENERGYCONSUMER_P], "%f", m_LoadArray[i].P);
         sprintf(szField[PG_ENERGYCONSUMER_Q], "%f", m_LoadArray[i].Q);
 
         PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ENERGYCONSUMER, szField);
     }
}

void CCIMEData::insertShuntCompensator(tagPGBlock* pBlock)
{
     register int	i;
     char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
 
     for (i=0; i<MAXMDBFIELDNUM; i++)
         memset(szField[i], 0, MDB_CHARLEN_LONG);
 
     for (i=0; i<(int)m_ShuntCompensatorArray.size(); i++)
     {
         if (strlen(m_ShuntCompensatorArray[i].Substation) <= 0)
         {
             log("�޷����벹��, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_ShuntCompensatorArray[i].name, m_ShuntCompensatorArray[i].Substation, m_ShuntCompensatorArray[i].VoltageLevel);
             continue;
         }
		 if (isSubExclude(m_ShuntCompensatorArray[i].Substation))
			 continue;

         if (strlen(m_ShuntCompensatorArray[i].VoltageLevel) <= 0)
         {
             log("�޷����벹��, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_ShuntCompensatorArray[i].name, m_ShuntCompensatorArray[i].Substation, m_ShuntCompensatorArray[i].VoltageLevel);
             continue;
         }
         if (strlen(m_ShuntCompensatorArray[i].I_node) <= 0)
         {
             log("�޷����벹��, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", m_ShuntCompensatorArray[i].name, m_ShuntCompensatorArray[i].Substation, m_ShuntCompensatorArray[i].VoltageLevel);
             continue;
         }
 
         strcpy(szField[PG_SHUNTCOMPENSATOR_RESOURCEID], m_ShuntCompensatorArray[i].mRID);
         strcpy(szField[PG_SHUNTCOMPENSATOR_NAME], m_ShuntCompensatorArray[i].name);
         strcpy(szField[PG_SHUNTCOMPENSATOR_DESC], m_ShuntCompensatorArray[i].pathName);
         strcpy(szField[PG_SHUNTCOMPENSATOR_SUBSTATION], mRID2name(CIME_Substation, m_ShuntCompensatorArray[i].Substation));
         strcpy(szField[PG_SHUNTCOMPENSATOR_VOLTAGELEVEL], mRID2name(CIME_VoltageLevel, m_ShuntCompensatorArray[i].VoltageLevel));
         strcpy(szField[PG_SHUNTCOMPENSATOR_CONNECTIVITYNODE], m_ShuntCompensatorArray[i].I_node);
         sprintf(szField[PG_SHUNTCOMPENSATOR_CAP], "%f", m_ShuntCompensatorArray[i].nomQ);
         sprintf(szField[PG_SHUNTCOMPENSATOR_Q], "%f", -m_ShuntCompensatorArray[i].Q);
 
         PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SHUNTCOMPENSATOR, szField);
     }
}

void CCIMEData::insertBusbarSection(tagPGBlock* pBlock)
{
    register int	i;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (i=0; i<(int)m_BusbarSectionArray.size(); i++)
    {
		if (strlen(m_BusbarSectionArray[i].Substation) <= 0)
        {
            log("�޷�����ĸ��, ��Substation��Ϣ: (%s) (%s) (%s) (%s)\n", m_BusbarSectionArray[i].name, m_BusbarSectionArray[i].Substation, m_BusbarSectionArray[i].VoltageLevel, m_BusbarSectionArray[i].pathName);
            continue;
        }
		if (isSubExclude(m_BusbarSectionArray[i].Substation))
			continue;

        if (strlen(m_BusbarSectionArray[i].VoltageLevel) <= 0)
        {
            log("�޷�����ĸ��, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_BusbarSectionArray[i].name, m_BusbarSectionArray[i].Substation, m_BusbarSectionArray[i].VoltageLevel);
            continue;
        }
        if (strlen(m_BusbarSectionArray[i].I_node) <= 0)
        {
            log("�޷�����ĸ��, �޽ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_BusbarSectionArray[i].name, m_BusbarSectionArray[i].Substation, m_BusbarSectionArray[i].VoltageLevel, m_BusbarSectionArray[i].I_node);
            continue;
        }

        strcpy(szField[PG_BUSBARSECTION_RESOURCEID], m_BusbarSectionArray[i].mRID);
        strcpy(szField[PG_BUSBARSECTION_NAME], m_BusbarSectionArray[i].name);
        strcpy(szField[PG_BUSBARSECTION_DESC], m_BusbarSectionArray[i].pathName);
        strcpy(szField[PG_BUSBARSECTION_SUBSTATION], mRID2name(CIME_Substation, m_BusbarSectionArray[i].Substation));
        strcpy(szField[PG_BUSBARSECTION_VOLTAGELEVEL], mRID2name(CIME_VoltageLevel, m_BusbarSectionArray[i].VoltageLevel));
        strcpy(szField[PG_BUSBARSECTION_CONNECTIVITYNODE], m_BusbarSectionArray[i].I_node);
        sprintf(szField[PG_BUSBARSECTION_V], "%f", m_BusbarSectionArray[i].V);
        sprintf(szField[PG_BUSBARSECTION_D], "%f", m_BusbarSectionArray[i].A);

        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_BUSBARSECTION, szField);
    }
}

void CCIMEData::insertBreak(tagPGBlock* pBlock)
{
    register int	i;
    char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

    for (i=0; i<(int)m_BreakerArray.size(); i++)
    {
        if (strlen(m_BreakerArray[i].Substation) <= 0)
        {
            log("�޷����뿪��, ��Substation��Ϣ: (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].name, m_BreakerArray[i].Substation, m_BreakerArray[i].VoltageLevel, m_BreakerArray[i].pathName);
            continue;
        }
		if (isSubExclude(m_BreakerArray[i].Substation))
			continue;

		if (strlen(m_BreakerArray[i].VoltageLevel) <= 0)
        {
            log("�޷����뿪��, ��Voltage��Ϣ: (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].name, m_BreakerArray[i].Substation, m_BreakerArray[i].VoltageLevel, m_BreakerArray[i].pathName);
            continue;
        }
        if (strlen(m_BreakerArray[i].I_node) <= 0)
        {
            log("�޷����뿪��, ��I�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].name, m_BreakerArray[i].Substation, m_BreakerArray[i].VoltageLevel, m_BreakerArray[i].I_node, m_BreakerArray[i].J_node);
            continue;
        }
        if (strlen(m_BreakerArray[i].J_node) <= 0)
        {
            log("�޷����뿪��, ��J�ڵ���Ϣ: (%s) (%s) (%.2f) (%s) (%s)\n", m_BreakerArray[i].name, m_BreakerArray[i].Substation, m_BreakerArray[i].VoltageLevel, m_BreakerArray[i].I_node, m_BreakerArray[i].J_node);
            continue;
        }

        strcpy(szField[PG_BREAKER_RESOURCEID], m_BreakerArray[i].mRID);
        strcpy(szField[PG_BREAKER_NAME], m_BreakerArray[i].name);
        strcpy(szField[PG_BREAKER_DESC], m_BreakerArray[i].pathName);
        strcpy(szField[PG_BREAKER_SUBSTATION], mRID2name(CIME_Substation, m_BreakerArray[i].Substation));
        strcpy(szField[PG_BREAKER_VOLTAGELEVEL], mRID2name(CIME_VoltageLevel, m_BreakerArray[i].VoltageLevel));
        strcpy(szField[PG_BREAKER_CONNECTIVITYNODEI], m_BreakerArray[i].I_node);
        strcpy(szField[PG_BREAKER_CONNECTIVITYNODEJ], m_BreakerArray[i].J_node);
        sprintf(szField[PG_BREAKER_STATUS], "%d", (m_BreakerArray[i].status != 0) ? 0 : 1);

        PGAppendRecord(pBlock, MDB_NeedCheckData, PG_BREAKER, szField);
    }
}

void CCIMEData::insertDisconnector(tagPGBlock* pBlock)
{
     register int	i;
     char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
 
     for (i=0; i<MAXMDBFIELDNUM; i++)
         memset(szField[i], 0, MDB_CHARLEN_LONG);
 
     for (i=0; i<(int)m_DisconnectorArray.size(); i++)
     {
         if (strlen(m_DisconnectorArray[i].Substation) <= 0)
         {
             log("�޷����뵶բ, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_DisconnectorArray[i].name, m_DisconnectorArray[i].Substation, m_DisconnectorArray[i].VoltageLevel);
             continue;
         }
		 if (isSubExclude(m_DisconnectorArray[i].Substation))
			 continue;

		 if (strlen(m_DisconnectorArray[i].VoltageLevel) <= 0)
         {
             log("�޷����뵶բ, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_DisconnectorArray[i].name, m_DisconnectorArray[i].Substation, m_DisconnectorArray[i].VoltageLevel);
             continue;
         }
 
         if (strlen(m_DisconnectorArray[i].I_node) <= 0)
         {
             log("�޷����뵶բ, ��I��ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_DisconnectorArray[i].name, m_DisconnectorArray[i].Substation, m_DisconnectorArray[i].VoltageLevel, m_DisconnectorArray[i].I_node, m_DisconnectorArray[i].J_node);
             continue;
         }
         if (strlen(m_DisconnectorArray[i].J_node) <= 0)
         {
             log("�޷����뵶բ, ��J��ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_DisconnectorArray[i].name, m_DisconnectorArray[i].Substation, m_DisconnectorArray[i].VoltageLevel, m_DisconnectorArray[i].I_node, m_DisconnectorArray[i].J_node);
             continue;
         }
         strcpy(szField[PG_DISCONNECTOR_RESOURCEID],			m_DisconnectorArray[i].mRID);
         strcpy(szField[PG_DISCONNECTOR_NAME],				m_DisconnectorArray[i].name);
         strcpy(szField[PG_DISCONNECTOR_DESC],		m_DisconnectorArray[i].pathName);
         strcpy(szField[PG_DISCONNECTOR_SUBSTATION],			mRID2name(CIME_Substation, m_DisconnectorArray[i].Substation));
         strcpy(szField[PG_DISCONNECTOR_VOLTAGELEVEL],		mRID2name(CIME_VoltageLevel, m_DisconnectorArray[i].VoltageLevel));
         strcpy(szField[PG_DISCONNECTOR_CONNECTIVITYNODEI],	m_DisconnectorArray[i].I_node);
         strcpy(szField[PG_DISCONNECTOR_CONNECTIVITYNODEJ],	m_DisconnectorArray[i].J_node);
		 sprintf(szField[PG_DISCONNECTOR_STATUS], "%d",		(m_DisconnectorArray[i].status != 0) ? 0 : 1);

         PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DISCONNECTOR, szField);
     }
}

void	CCIMEData::insertDCLine(tagPGBlock* pBlock)
{
	register int	i;
	int			nDot;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	float		fVolt, fBase;

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (i=0; i<(int)m_DCLineSegmentArray.size(); i++)
	{
		fVolt=getBaseVoltage(m_DCLineSegmentArray[i].BaseVoltage);
		fBase=pBlock->m_System.fBasePower/(fVolt*fVolt);

		strcpy(szField[PG_DCLINESEGMENT_RESOURCEID],	m_DCLineSegmentArray[i].mRID);
		strcpy(szField[PG_DCLINESEGMENT_NAME],		m_DCLineSegmentArray[i].name);
		strcpy(szField[PG_DCLINESEGMENT_DESC],	m_DCLineSegmentArray[i].pathName);
		strcpy(szField[PG_DCLINESEGMENT_ISUBSTATION],	mRID2name(CIME_Substation, m_DCLineSegmentArray[i].StartSt));
		strcpy(szField[PG_DCLINESEGMENT_JSUBSTATION],	mRID2name(CIME_Substation, m_DCLineSegmentArray[i].EndSt));

		sprintf(szField[PG_DCLINESEGMENT_R], "%f", m_DCLineSegmentArray[i].r*fBase);

		for (nDot=0; nDot<(int)m_DCLineDotArray.size(); nDot++)
		{
			if (STRICMP(m_DCLineDotArray[nDot].DCLineSegment, m_DCLineSegmentArray[i].mRID) != 0)
				continue;

			if (STRICMP(m_DCLineDotArray[nDot].Substation, m_DCLineSegmentArray[i].StartSt) == 0)
				strcpy(szField[PG_DCLINESEGMENT_CONNECTIVITYNODEI],	m_DCLineDotArray[nDot].I_node);
			else if (STRICMP(m_DCLineDotArray[nDot].Substation, m_DCLineSegmentArray[i].EndSt) == 0)
				strcpy(szField[PG_DCLINESEGMENT_CONNECTIVITYNODEJ],	m_DCLineDotArray[nDot].I_node);
		}
		PGAppendRecord(pBlock, MDB_NeedCheckData, PG_DCLINESEGMENT, szField);
	}
}

void	CCIMEData::insertRectifierInverter(tagPGBlock* pBlock)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	float		fVolt, fBase;

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (i=0; i<(int)m_RectifierInverterArray.size(); i++)
	{
		fVolt=getBaseVoltage(m_RectifierInverterArray[i].BaseVoltage);
		fBase=pBlock->m_System.fBasePower/(fVolt*fVolt);

		strcpy(szField[PG_RECTIFIERINVERTER_RESOURCEID],			m_RectifierInverterArray[i].mRID);
		strcpy(szField[PG_RECTIFIERINVERTER_NAME],					m_RectifierInverterArray[i].name);
		strcpy(szField[PG_RECTIFIERINVERTER_DESC],					m_RectifierInverterArray[i].pathName);
		strcpy(szField[PG_RECTIFIERINVERTER_SUBSTATION],			mRID2name(CIME_Substation, m_RectifierInverterArray[i].Substation));
		strcpy(szField[PG_RECTIFIERINVERTER_VOLTAGELEVELAC],		mRID2name(CIME_VoltageLevel, m_RectifierInverterArray[i].VoltageLevel));
		strcpy(szField[PG_RECTIFIERINVERTER_CONNECTIVITYNODEAC],	m_RectifierInverterArray[i].Z_node);

		sprintf(szField[PG_RECTIFIERINVERTER_BRIDGES], "%d",		m_RectifierInverterArray[i].bridges);
		sprintf(szField[PG_RECTIFIERINVERTER_P], "%f",				m_RectifierInverterArray[i].P);
		sprintf(szField[PG_RECTIFIERINVERTER_Q], "%f",				m_RectifierInverterArray[i].Q);

		sprintf(szField[PG_RECTIFIERINVERTER_VOLTAGELEVELDC], "%f",	m_RectifierInverterArray[i].ratedKV);
		strcpy(szField[PG_RECTIFIERINVERTER_CONNECTIVITYNODEDCP],	m_RectifierInverterArray[i].I_node);
		sprintf(szField[PG_RECTIFIERINVERTER_VOLTAGELEVELDC], "%f",	m_RectifierInverterArray[i].ratedKV);
		strcpy(szField[PG_RECTIFIERINVERTER_CONNECTIVITYNODEDCN],	m_RectifierInverterArray[i].J_node);

		PGAppendRecord(pBlock, MDB_NeedCheckData, PG_RECTIFIERINVERTER, szField);
	}
}

void	CCIMEData::insertSeriesCompensator(tagPGBlock* pBlock)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	float		fVolt, fBase;

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (i=0; i<(int)m_SeriesCompensatorArray.size(); i++)
	{
		fVolt=getBaseVoltage(m_SeriesCompensatorArray[i].BaseVoltage);
		fBase=pBlock->m_System.fBasePower/(fVolt*fVolt);

		strcpy(szField[PG_SERIESCOMPENSATOR_RESOURCEID],			m_SeriesCompensatorArray[i].mRID);
		strcpy(szField[PG_SERIESCOMPENSATOR_NAME],				m_SeriesCompensatorArray[i].name);
		strcpy(szField[PG_SERIESCOMPENSATOR_DESC],			m_SeriesCompensatorArray[i].pathName);
		strcpy(szField[PG_SERIESCOMPENSATOR_SUBSTATION],			mRID2name(CIME_Substation, m_SeriesCompensatorArray[i].Substation));
		strcpy(szField[PG_SERIESCOMPENSATOR_VOLTAGELEVEL],		mRID2name(CIME_VoltageLevel, m_SeriesCompensatorArray[i].VoltageLevel));
		strcpy(szField[PG_SERIESCOMPENSATOR_CONNECTIVITYNODEI],	m_SeriesCompensatorArray[i].I_node);
		strcpy(szField[PG_SERIESCOMPENSATOR_CONNECTIVITYNODEJ],	m_SeriesCompensatorArray[i].J_node);

		sprintf(szField[PG_SERIESCOMPENSATOR_R], "%f",				m_SeriesCompensatorArray[i].r*fBase);
		sprintf(szField[PG_SERIESCOMPENSATOR_X], "%f",				m_SeriesCompensatorArray[i].x*fBase);

		PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SERIESCOMPENSATOR, szField);
	}
}

void CCIMEData::insertTapChangerType(tagPGBlock* pBlock)
{
    register int	i;
    int		nTap, bExist;
    char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

    for (i=0; i<MAXMDBFIELDNUM; i++)
        memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (i=0; i<(int)m_TapChangerTypeArray.size(); i++)
    {
        if (m_TapChangerTypeArray[i].highStep == m_TapChangerTypeArray[i].lowStep)
        {
            m_TapChangerTypeArray[i].highStep = m_TapChangerTypeArray[i].lowStep = m_TapChangerTypeArray[i].neutralStep = 0;
            m_TapChangerTypeArray[i].stepVolIncre=0;
        }
        bExist=0;
        for (nTap=0; nTap<pBlock->m_nRecordNum[PG_TAPCHANGER]; nTap++)
        {
            if (pBlock->m_TapChangerArray[nTap].nTapMin == m_TapChangerTypeArray[i].lowStep &&
                    pBlock->m_TapChangerArray[nTap].nTapMax == m_TapChangerTypeArray[i].highStep &&
                    pBlock->m_TapChangerArray[nTap].nTapNom == m_TapChangerTypeArray[i].neutralStep &&
                    pBlock->m_TapChangerArray[nTap].fTapStep == m_TapChangerTypeArray[i].stepVolIncre)
            {
                bExist=1;
                break;
            }
        }
        //if (!bExist)
        {
            strcpy(szField[PG_TAPCHANGER_RESOURCEID], m_TapChangerTypeArray[i].mRID);
            strcpy(szField[PG_TAPCHANGER_NAME], m_TapChangerTypeArray[i].name);
			if (fabs(m_TapChangerTypeArray[i].stepVolIncre) > 10)
				m_TapChangerTypeArray[i].stepVolIncre = 0;

			if (m_TapChangerTypeArray[i].lowStep < m_TapChangerTypeArray[i].highStep)
			{
				sprintf(szField[PG_TAPCHANGER_TAPMIN], "%d", m_TapChangerTypeArray[i].lowStep);
				sprintf(szField[PG_TAPCHANGER_TAPMAX], "%d", m_TapChangerTypeArray[i].highStep);
				sprintf(szField[PG_TAPCHANGER_TAPNOM], "%d", m_TapChangerTypeArray[i].neutralStep);
				sprintf(szField[PG_TAPCHANGER_TAPSTEP], "%f", m_TapChangerTypeArray[i].stepVolIncre);
			}
			else
			{
				sprintf(szField[PG_TAPCHANGER_TAPMAX], "%d", m_TapChangerTypeArray[i].lowStep);
				sprintf(szField[PG_TAPCHANGER_TAPMIN], "%d", m_TapChangerTypeArray[i].highStep);
				sprintf(szField[PG_TAPCHANGER_TAPNOM], "%d", m_TapChangerTypeArray[i].neutralStep);
				sprintf(szField[PG_TAPCHANGER_TAPSTEP], "%f", -m_TapChangerTypeArray[i].stepVolIncre);
			}
            PGAppendRecord(pBlock, MDB_NeedCheckData, PG_TAPCHANGER, szField);
        }
    }
}
