// EData.cpp: implementation of the CCIMEData class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"

extern	void	PrintMessage(const char* lpszMesg);
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCIMEData::CCIMEData()
{
    m_ControlAreaArray.clear();
    m_BaseVoltageArray.clear();
    m_SubstationArray.clear();
    m_VoltageLevelArray.clear();
    m_BreakerArray.clear();
    m_DisconnectorArray.clear();
    m_BusbarSectionArray.clear();
    m_SynchronousMachineArray.clear();
    m_ACLineSegmentArray.clear();
    m_ACLineDotArray.clear();
    m_DCLineSegmentArray.clear();
    m_DCLineDotArray.clear();
    m_RectifierInverterArray.clear();
    m_LoadArray.clear();
    m_PowerTransformerArray.clear();
    m_TransformerWindingArray.clear();
    m_TapChangerTypeArray.clear();
    m_ShuntCompensatorArray.clear();
    m_SeriesCompensatorArray.clear();
    m_BayArray.clear();
    m_AnalogArray.clear();
    m_DiscreteArray.clear();
}

CCIMEData::~CCIMEData()
{
    m_ControlAreaArray.clear();
    m_BaseVoltageArray.clear();
    m_SubstationArray.clear();
    m_VoltageLevelArray.clear();
    m_BreakerArray.clear();
    m_DisconnectorArray.clear();
    m_BusbarSectionArray.clear();
    m_SynchronousMachineArray.clear();
    m_ACLineSegmentArray.clear();
    m_ACLineDotArray.clear();
    m_DCLineSegmentArray.clear();
    m_DCLineDotArray.clear();
    m_RectifierInverterArray.clear();
    m_LoadArray.clear();
    m_PowerTransformerArray.clear();
    m_TransformerWindingArray.clear();
    m_TapChangerTypeArray.clear();
    m_ShuntCompensatorArray.clear();
    m_SeriesCompensatorArray.clear();
    m_BayArray.clear();
    m_AnalogArray.clear();
    m_DiscreteArray.clear();
}

void CCIMEData::log(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szTempPath[260], szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/CimE.log", szTempPath);
	fp=fopen(szFileName, "a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}


int CCIMEData::InputPGBlock(tagPGBlock* pBlock)
{
	if (::MessageBox(NULL, "�Ƿ������ǰ���ݿ⣿", "�������ݿ�", MB_YESNO|MB_SYSTEMMODAL) == IDYES)
	{
		clearDatabase(pBlock);
	}

	insertDefault(pBlock);
	insertSubcontrolArea(pBlock, 1);
	insertSubstation(pBlock);
	insertVoltageLevel(pBlock);

	PGMaint(pBlock);

	insertBusbarSection(pBlock);
	insertSynchronousMachine(pBlock);
	insertLoad(pBlock);
	insertShuntCompensator(pBlock);

	insertACLine(pBlock);
	insertTransformer(pBlock);

	insertDCLine(pBlock);
	insertRectifierInverter(pBlock);
	insertSeriesCompensator(pBlock);

	insertBreak(pBlock);
	insertDisconnector(pBlock);

	PGMaint(pBlock);

	return 0;
}
