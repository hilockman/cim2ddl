#pragma once

#ifndef _CRT_SECURE_NO_WARNINGS
#define	 _CRT_SECURE_NO_WARNINGS
#endif
#pragma warning (disable: 4996)

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/types.h>

#pragma	warning(disable:4530)
#include <vector>
using namespace	std;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
#	include <Windows.h>
#	ifndef	STRICMP
#		define	STRICMP		stricmp
#		define	STRNICMP	strnicmp
#	endif
#else
#	ifndef	STRICMP
#		define	STRICMP		strcasecmp
#		define	STRNICMP	strncasecmp
#	endif
#endif

#include "CIMEDataDefine.h"

class CCIMEData
{
public:
    CCIMEData();
    virtual ~CCIMEData();

    int		read(const char* lpszFileName, const int bPackedName = 1);
	int		InputPGBlock(tagPGBlock* pBlock);

public:
    int				m_nClassNum;
    char			m_szClassArray[50][CIME_CHARLEN];

    std::vector<tagCIMEControlArea>			m_ControlAreaArray;
    std::vector<tagCIMEBaseVoltage>			m_BaseVoltageArray;
    std::vector<tagCIMESubstation>			m_SubstationArray;
    std::vector<tagCIMEVoltageLevel>		m_VoltageLevelArray;
    std::vector<tagCIMEBreaker>				m_BreakerArray;
    std::vector<tagCIMEDisconnector>		m_DisconnectorArray;
    std::vector<tagCIMEBusbarSection>		m_BusbarSectionArray;
    std::vector<tagCIMESynchronousMachine>	m_SynchronousMachineArray;
    std::vector<tagCIMEACLineSegment>		m_ACLineSegmentArray;
    std::vector<tagCIMEACLineDot>			m_ACLineDotArray;
    std::vector<tagCIMEDCLineSegment>		m_DCLineSegmentArray;
    std::vector<tagCIMEDCLineDot>			m_DCLineDotArray;
    std::vector<tagCIMERectifierInverter>	m_RectifierInverterArray;
    std::vector<tagCIMELoad>				m_LoadArray;
    std::vector<tagCIMEPowerTransformer>	m_PowerTransformerArray;
    std::vector<tagCIMETransformerWinding>	m_TransformerWindingArray;
    std::vector<tagCIMETapChangerType>		m_TapChangerTypeArray;
    std::vector<tagCIMEShuntCompensator>	m_ShuntCompensatorArray;
    std::vector<tagCIMESeriesCompensator>	m_SeriesCompensatorArray;
    std::vector<tagCIMEBay>					m_BayArray;
    std::vector<tagCIMEAnalog>				m_AnalogArray;
    std::vector<tagCIMEDiscrete>			m_DiscreteArray;

private:
    void	readAttributes(const int nTable, char* lpszParser, int* pnColNum, int nColIndex[]);
    int		readClass(char* lpszParser, char* lpszRetClass, char* lpszRetEntity);
    void	readEntity(char* lpszParser);

    void	readControlArea			(char* lpszParser, int nColNum, int nColIndex[]);
    void	readBaseVoltage			(char* lpszParser, int nColNum, int nColIndex[]);
    void	readSubstation			(char* lpszParser, int nColNum, int nColIndex[]);
    void	readVoltageLevel		(char* lpszParser, int nColNum, int nColIndex[]);
    void	readBreaker				(char* lpszParser, int nColNum, int nColIndex[]);
    void	readDisconnector		(char* lpszParser, int nColNum, int nColIndex[]);
    void	readBusbarSection		(char* lpszParser, int nColNum, int nColIndex[]);
    void	readSynchronousMachine	(char* lpszParser, int nColNum, int nColIndex[]);
    void	readACLineSegment		(char* lpszParser, int nColNum, int nColIndex[]);
    void	readACLineDot			(char* lpszParser, int nColNum, int nColIndex[]);
    void	readDCLineSegment		(char* lpszParser, int nColNum, int nColIndex[]);
    void	readDCLineDot			(char* lpszParser, int nColNum, int nColIndex[]);
    void	readRectifierInverter	(char* lpszParser, int nColNum, int nColIndex[]);
    void	readLoad				(char* lpszParser, int nColNum, int nColIndex[]);
    void	readPowerTransformer	(char* lpszParser, int nColNum, int nColIndex[]);
    void	readTransformerWinding	(char* lpszParser, int nColNum, int nColIndex[]);
    void	readTapChangerType		(char* lpszParser, int nColNum, int nColIndex[]);
    void	readShuntCompensator	(char* lpszParser, int nColNum, int nColIndex[]);
    void	readSeriesCompensator	(char* lpszParser, int nColNum, int nColIndex[]);
    void	readBay					(char* lpszParser, int nColNum, int nColIndex[]);
    void	readAnalog				(char* lpszParser, int nColNum, int nColIndex[]);
    void	readDiscrete			(char* lpszParser, int nColNum, int nColIndex[]);

    int		isComment(const char* lpszParser);
    int		isEntity(const char* lpszParser);
    int		isAttribute(const char* lpszParser);
    int		isData(const char* lpszParser);

private:
    void	insertDefault(tagPGBlock* pBlock);
    void	insertTapChangerType(tagPGBlock* pBlock);

    void	insertSubcontrolArea(tagPGBlock* pBlock, const int bCimAsOutnet);
    void	insertSubstation(tagPGBlock* pBlock);
    void	insertVoltageLevel(tagPGBlock* pBlock);

	void	insertBusbarSection(tagPGBlock* pBlock);
	void	insertSynchronousMachine(tagPGBlock* pBlock);
	void	insertLoad(tagPGBlock* pBlock);
	void	insertShuntCompensator(tagPGBlock* pBlock);

    void	insertACLine(tagPGBlock* pBlock);
    void	insertTransformer(tagPGBlock* pBlock);

	void	insertDCLine(tagPGBlock* pBlock);
	void	insertRectifierInverter(tagPGBlock* pBlock);
	void	insertSeriesCompensator(tagPGBlock* pBlock);

    void	insertBreak(tagPGBlock* pBlock);
    void	insertDisconnector(tagPGBlock* pBlock);


	void	clearDatabase(tagPGBlock* pBlock);
	int		isSubExclude(const char* lpszmRID);
	float	getBaseVoltage(const char* lpszmRID);
	char*	getTaptype(const char* lpszmRID);
	char*	mRID2name(const int nClass, const char* lpszmRID);

private:
	void	log(char* pformat, ...);
	void	ResolveVoltageLevelName(const char* lpszResolveName, char* lpszRetName);
};
