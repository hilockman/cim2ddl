#include "stdafx.h"
#include "CIMData.h"
#include "../../Common/String2Double.hpp"

int		CCIMData::PrepareElementBuffer(const int nCimSection)
{
	switch (nCimSection)
	{
	case CIM_BasePower:				break;
	case CIM_BaseVoltage:			memset(&m_BaseVoltageBuf			, 0, sizeof(tagCIMBaseVoltage));				break;
// 	case CIM_Company:				memset(&m_CompanyBuf				, 0, sizeof(tagCIMCompany));					break;
	case CIM_SubcontrolArea:		memset(&m_SubcontrolAreaBuf			, 0, sizeof(tagCIMSubcontrolArea));			break;
	case CIM_Substation:			InitializeCimSubstation(m_SubstationBuf);										break;
	case CIM_VoltageLevel:			memset(&m_VoltageLevelBuf			, 0, sizeof(tagCIMVoltageLevel));				break;
	case CIM_Bay:					memset(&m_BayBuf					, 0, sizeof(tagCIMBay));						break;
	case CIM_BusbarSection:			memset(&m_BusbarSectionBuf			, 0, sizeof(tagCIMBusbarSection));			break;
	case CIM_ACLineSegment:			memset(&m_ACLineSegmentBuf			, 0, sizeof(tagCIMACLineSegment));			break;
	case CIM_DCLineSegment:			memset(&m_DCLineSegmentBuf			, 0, sizeof(tagCIMDCLineSegment));			break;
	case CIM_TransformerWinding:	memset(&m_TransformerWindingBuf		, 0, sizeof(tagCIMTransformerWinding));		break;
	case CIM_PowerTransformer:		memset(&m_PowerTransformerBuf		, 0, sizeof(tagCIMPowerTransformer));			break;
	case CIM_TapChanger:			memset(&m_TapChangerBuf				, 0, sizeof(tagCIMTapChanger));				break;
	case CIM_SynchronousMachine:	memset(&m_SynchronousMachineBuf		, 0, sizeof(tagCIMSynchronousMachine));		break;
	case CIM_ThermalGeneratingUnit:	memset(&m_ThermalGeneratingUnitBuf	, 0, sizeof(tagCIMThermalGeneratingUnit));	break;
	case CIM_HydroGeneratingUnit:	memset(&m_HydroGeneratingUnitBuf	, 0, sizeof(tagCIMHydroGeneratingUnit));		break;
	case CIM_EnergyConsumer:		memset(&m_EnergyConsumerBuf			, 0, sizeof(tagCIMEnergyConsumer));			break;
	case CIM_Compensator:			memset(&m_CompensatorBuf			, 0, sizeof(tagCIMCompensator));				break;
	case CIM_RectifierInverter:		memset(&m_RectifierInverterBuf		, 0, sizeof(tagCIMRectifierInverter));		break;
	case CIM_Breaker:				InitializeCimBreaker(m_BreakerBuf);												break;
	case CIM_Disconnector:			InitializeCimDisconnector(m_DisconnectorBuf);									break;
	case CIM_DCSwitch:				InitializeCimDisconnector(m_DisconnectorBuf);									break;
	case CIM_GroundDisconnector:	InitializeCimGroundDisconnector(m_GroundDisconnectorBuf);						break;
	case CIM_Terminal:				InitializeCimTerminal(m_TerminalBuf);											break;
	case CIM_ConnectivityNode:		InitializeCimConnectivityNode(m_ConnectivityNodeBuf);							break;
	case CIM_MeasurementType:		memset(&m_MeasurementTypeBuf		, 0, sizeof(tagCIMMeasurementType));			break;
	case CIM_MeasurementSource:		memset(&m_MeasurementSourceBuf		, 0, sizeof(tagCIMMeasurementSource));		break;
	case CIM_MeasurementValue:		InitializeCimMeasurementValue(m_MeasurementValueBuf);							break;
	case CIM_Measurement:			InitilizeCimMeasurement(m_MeasurementBuf);										break;
	case CIM_Analog:				InitializeCimAnalog(m_AnalogBuf);												break;
	case CIM_Discrete:				InitializeCimDiscrete(m_DiscreteBuf);											break;
	case CIM_LimitSet:				memset(&m_LimitSetBuf				, 0, sizeof(tagCIMLimitSet));					break;
	case CIM_Limit:					memset(&m_LimitBuf					, 0, sizeof(tagCIMLimit));					break;
	default:
		return 0;
		break;
	}
	return 1;
}


int		CCIMData::AppendElementBuffer(const int nCimSection)
{
	switch (nCimSection)
	{
	case CIM_BasePower:
		break;
	case CIM_BaseVoltage:
		m_BaseVoltageArray.push_back(m_BaseVoltageBuf);
		break;
	case CIM_SubcontrolArea:
		if (strlen(m_SubcontrolAreaBuf.szName) <= 0)
			strcpy(m_SubcontrolAreaBuf.szName, m_SubcontrolAreaBuf.szResourceID);

		if (strlen(m_SubcontrolAreaBuf.szDesp) <= 0)
		{
			if (strlen(m_SubcontrolAreaBuf.szAlias) > 0)
				strcpy(m_SubcontrolAreaBuf.szDesp, m_SubcontrolAreaBuf.szAlias);
			else
				strcpy(m_SubcontrolAreaBuf.szDesp, m_SubcontrolAreaBuf.szName);
		}
		if (strlen(m_SubcontrolAreaBuf.szAlias) <= 0)
			strcpy(m_SubcontrolAreaBuf.szAlias, m_SubcontrolAreaBuf.szName);

		m_SubcontrolAreaArray.push_back(m_SubcontrolAreaBuf);
		break;
	case CIM_Substation:
		if (strlen(m_SubstationBuf.szDesp) <= 0)
		{
			if (strlen(m_SubstationBuf.szAlias) > 0)
				strcpy(m_SubstationBuf.szDesp, m_SubstationBuf.szAlias);
			else
				strcpy(m_SubstationBuf.szDesp, m_SubstationBuf.szName);
		}
		if (strlen(m_SubstationBuf.szAlias) <= 0)
			strcpy(m_SubstationBuf.szAlias, m_SubstationBuf.szName);

		m_SubstationArray.push_back(m_SubstationBuf);
		break;
	case CIM_VoltageLevel:
		if (strlen(m_VoltageLevelBuf.szName) <= 0)
			strcpy(m_VoltageLevelBuf.szName, m_VoltageLevelBuf.szResourceID);
		m_VoltageLevelArray.push_back(m_VoltageLevelBuf);
		break;
	case CIM_Bay:
		if (strlen(m_BayBuf.szName) <= 0)
			strcpy(m_BayBuf.szName, m_BayBuf.szResourceID);
		m_BayArray.push_back(m_BayBuf);
		break;
	case CIM_BusbarSection:
		if (strlen(m_BusbarSectionBuf.szDesp) <= 0)
		{
			if (strlen(m_BusbarSectionBuf.szAlias) > 0)
				strcpy(m_BusbarSectionBuf.szDesp, m_BusbarSectionBuf.szAlias);
			else
				strcpy(m_BusbarSectionBuf.szDesp, m_BusbarSectionBuf.szName);
		}
		if (strlen(m_BusbarSectionBuf.szAlias) <= 0)
			strcpy(m_BusbarSectionBuf.szAlias, m_BusbarSectionBuf.szName);

		m_BusbarSectionArray.push_back(m_BusbarSectionBuf);
		break;
	case CIM_ACLineSegment:
		if (strlen(m_ACLineSegmentBuf.szDesp) <= 0)
		{
			if (strlen(m_ACLineSegmentBuf.szAlias) > 0)
				strcpy(m_ACLineSegmentBuf.szDesp, m_ACLineSegmentBuf.szAlias);
			else
				strcpy(m_ACLineSegmentBuf.szDesp, m_ACLineSegmentBuf.szName);
		}
		if (sqrt(m_ACLineSegmentBuf.fR*m_ACLineSegmentBuf.fR+m_ACLineSegmentBuf.fX*m_ACLineSegmentBuf.fX) < 0.000001)
		{
			m_ACLineSegmentBuf.fX=0.1;
			m_ACLineSegmentBuf.nRPu=m_ACLineSegmentBuf.nXPu=1;
		}
		m_ACLineSegmentArray.push_back(m_ACLineSegmentBuf);
		break;
	case CIM_DCLineSegment:
		if (strlen(m_DCLineSegmentBuf.szDesp) <= 0)
		{
			if (strlen(m_DCLineSegmentBuf.szAlias) > 0)
				strcpy(m_DCLineSegmentBuf.szDesp, m_DCLineSegmentBuf.szAlias);
			else
				strcpy(m_DCLineSegmentBuf.szDesp, m_DCLineSegmentBuf.szName);
		}
		m_DCLineSegmentArray.push_back(m_DCLineSegmentBuf);
		break;
	case CIM_TransformerWinding:
		if (strlen(m_TransformerWindingBuf.szName) <= 0)
			strcpy(m_TransformerWindingBuf.szName, m_TransformerWindingBuf.szResourceID);
		if (strlen(m_TransformerWindingBuf.szDesp) <= 0)
		{
			if (strlen(m_TransformerWindingBuf.szAlias) > 0)
				strcpy(m_TransformerWindingBuf.szDesp, m_TransformerWindingBuf.szAlias);
			else
				strcpy(m_TransformerWindingBuf.szDesp, m_TransformerWindingBuf.szName);
		}
		if (strlen(m_TransformerWindingBuf.szAlias) <= 0)
			strcpy(m_TransformerWindingBuf.szAlias, m_TransformerWindingBuf.szName);

		m_TransformerWindingArray.push_back(m_TransformerWindingBuf);
		break;
	case CIM_PowerTransformer:
		if (strlen(m_PowerTransformerBuf.szDesp) <= 0)
		{
			if (strlen(m_PowerTransformerBuf.szAlias) > 0)
				strcpy(m_PowerTransformerBuf.szDesp, m_PowerTransformerBuf.szAlias);
			else
				strcpy(m_PowerTransformerBuf.szDesp, m_PowerTransformerBuf.szName);
		}
		if (strlen(m_PowerTransformerBuf.szAlias) <= 0)
			strcpy(m_PowerTransformerBuf.szAlias, m_PowerTransformerBuf.szName);
		m_PowerTransformerArray.push_back(m_PowerTransformerBuf);
		break;
	case CIM_TapChanger:
		if (strlen(m_TapChangerBuf.szName) <= 0)
			strcpy(m_TapChangerBuf.szName, m_TapChangerBuf.szResourceID);

		if (m_TapChangerBuf.nHighStep < m_TapChangerBuf.nLowStep)
		{
			int	nBuf;
			nBuf=m_TapChangerBuf.nHighStep;
			m_TapChangerBuf.nHighStep=m_TapChangerBuf.nLowStep;
			m_TapChangerBuf.nLowStep=nBuf;
			m_TapChangerBuf.fStepVoltageIncrement=-m_TapChangerBuf.fStepVoltageIncrement;
		}
		m_TapChangerArray.push_back(m_TapChangerBuf);
		break;
	case CIM_SynchronousMachine:
		if (strlen(m_SynchronousMachineBuf.szDesp) <= 0)
		{
			if (strlen(m_SynchronousMachineBuf.szAlias) > 0)
				strcpy(m_SynchronousMachineBuf.szDesp, m_SynchronousMachineBuf.szAlias);
			else
				strcpy(m_SynchronousMachineBuf.szDesp, m_SynchronousMachineBuf.szName);
		}
		if (strlen(m_SynchronousMachineBuf.szAlias) <= 0)
			strcpy(m_SynchronousMachineBuf.szAlias, m_SynchronousMachineBuf.szName);

		m_SynchronousMachineArray.push_back(m_SynchronousMachineBuf);
		break;
	case CIM_ThermalGeneratingUnit:
		m_ThermalGeneratingUnitArray.push_back(m_ThermalGeneratingUnitBuf);
		break;
	case CIM_HydroGeneratingUnit:
		m_HydroGeneratingUnitArray.push_back(m_HydroGeneratingUnitBuf);
		break;
	case CIM_EnergyConsumer:
		if (strlen(m_EnergyConsumerBuf.szDesp) <= 0)
		{
			if (strlen(m_EnergyConsumerBuf.szAlias) > 0)
				strcpy(m_EnergyConsumerBuf.szDesp, m_EnergyConsumerBuf.szAlias);
			else
				strcpy(m_EnergyConsumerBuf.szDesp, m_EnergyConsumerBuf.szName);
		}
		if (strlen(m_EnergyConsumerBuf.szAlias) <= 0)
			strcpy(m_EnergyConsumerBuf.szAlias, m_EnergyConsumerBuf.szName);

		m_EnergyConsumerArray.push_back(m_EnergyConsumerBuf);
		break;
	case CIM_Compensator:
		if (strlen(m_CompensatorBuf.szDesp) <= 0)
		{
			if (strlen(m_CompensatorBuf.szAlias) > 0)
				strcpy(m_CompensatorBuf.szDesp, m_CompensatorBuf.szAlias);
			else
				strcpy(m_CompensatorBuf.szDesp, m_CompensatorBuf.szName);
		}
		if (strlen(m_CompensatorBuf.szAlias) <= 0)
			strcpy(m_CompensatorBuf.szAlias, m_CompensatorBuf.szName);

		m_CompensatorArray.push_back(m_CompensatorBuf);
		break;
	case CIM_RectifierInverter:
		if (strlen(m_RectifierInverterBuf.szDesp) <= 0)
		{
			if (strlen(m_RectifierInverterBuf.szAlias) > 0)
				strcpy(m_RectifierInverterBuf.szDesp, m_RectifierInverterBuf.szAlias);
			else
				strcpy(m_RectifierInverterBuf.szDesp, m_RectifierInverterBuf.szName);
		}
		if (strlen(m_RectifierInverterBuf.szAlias) <= 0)
			strcpy(m_RectifierInverterBuf.szAlias, m_RectifierInverterBuf.szName);

		m_RectifierInverterArray.push_back(m_RectifierInverterBuf);
		break;
	case CIM_Breaker:
		if (m_BreakerBuf.strDesp.empty())
		{
			if (m_BreakerBuf.strAlias.empty())
				m_BreakerBuf.strDesp=m_BreakerBuf.strAlias;
			else
				m_BreakerBuf.strDesp=m_BreakerBuf.strName;
		}
		if (m_BreakerBuf.strAlias.empty())
			m_BreakerBuf.strAlias=m_BreakerBuf.strName;

		m_BreakerArray.push_back(m_BreakerBuf);
		break;
	case CIM_Disconnector:
	case CIM_DCSwitch:
		if (m_DisconnectorBuf.strDesp.length() < m_DisconnectorBuf.strName.length() && m_DisconnectorBuf.strDesp.length() < 4 && !m_DisconnectorBuf.strAlias.empty())
			m_DisconnectorBuf.strDesp=m_DisconnectorBuf.strAlias;

		if (strcmp(m_DisconnectorBuf.strName.c_str(), m_DisconnectorBuf.strDesp.c_str()) == 0 && !m_DisconnectorBuf.strAlias.empty())
			m_DisconnectorBuf.strDesp=m_DisconnectorBuf.strAlias;

		if (m_DisconnectorBuf.strDesp.empty())
		{
			if (!m_DisconnectorBuf.strAlias.empty())
				m_DisconnectorBuf.strDesp=m_DisconnectorBuf.strAlias;
			else
				m_DisconnectorBuf.strDesp=m_DisconnectorBuf.strName;
		}
		if (m_DisconnectorBuf.strAlias.empty())
			m_DisconnectorBuf.strAlias=m_DisconnectorBuf.strName;

		m_DisconnectorArray.push_back(m_DisconnectorBuf);
		break;
	case CIM_GroundDisconnector:
		if (m_GroundDisconnectorBuf.strDesp.length() < m_GroundDisconnectorBuf.strName.length())	//	Ϊ���Ҽӵģ����������ü�����
			m_GroundDisconnectorBuf.strDesp=m_GroundDisconnectorBuf.strName;

		if (m_GroundDisconnectorBuf.strDesp.empty())
		{
			if (!m_GroundDisconnectorBuf.strAlias.empty())
				m_GroundDisconnectorBuf.strDesp=m_GroundDisconnectorBuf.strAlias;
			else
				m_GroundDisconnectorBuf.strDesp=m_GroundDisconnectorBuf.strName;
		}
		if (m_GroundDisconnectorBuf.strAlias.empty())
			m_GroundDisconnectorBuf.strAlias=m_GroundDisconnectorBuf.strName;

		m_GroundDisconnectorArray.push_back(m_GroundDisconnectorBuf);
		break;
	case CIM_Terminal:
		if (m_TerminalBuf.strName.empty())
			m_TerminalBuf.strName=m_TerminalBuf.strResourceID;

		m_TerminalArray.push_back(m_TerminalBuf);
		break;
	case CIM_ConnectivityNode:
		m_ConnectivityNodeArray.push_back(m_ConnectivityNodeBuf);
		break;
	case CIM_MeasurementType:
		if (m_bParseMeasurement)
			m_MeasurementTypeArray.push_back(m_MeasurementTypeBuf);
		break;
	case CIM_MeasurementSource:
		if (m_bParseMeasurement)
			m_MeasurementSourceArray.push_back(m_MeasurementSourceBuf);
		break;
	case CIM_MeasurementValue:	//	��������ֵ
// 		if (m_bParseMeasurement)
// 			m_MeasurementValueArray.push_back(m_MeasurementValueBuf);
		break;
	case CIM_Measurement:
		if (m_bParseMeasurement)
			m_MeasurementArray.push_back(m_MeasurementBuf);
		break;
	case CIM_Analog:
		if (m_bParseMeasurement)
			m_AnalogArray.push_back(m_AnalogBuf);
		break;
	case CIM_Discrete:
		if (m_bParseMeasurement)
			m_DiscreteArray.push_back(m_DiscreteBuf);
		break;
	case CIM_LimitSet:
		if (m_bParseMeasurement)
			m_LimitSetArray.push_back(m_LimitSetBuf);
		break;
	case CIM_Limit:
		if (m_bParseMeasurement)
			m_LimitArray.push_back(m_LimitBuf);
		break;
	default:
		return 0;
		break;
	}
	return 1;
}

void	CCIMData::fillBasePower(tagCIMBasePower* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:BasePower.basePower") == 0)
		pData->fBasePower=(float)atof(lpszElementValue);
}

void	CCIMData::fillBaseVoltage(tagCIMBaseVoltage* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:BaseVoltage.nominalVoltage") == 0)
		pData->fNominalVoltage=(float)atof(lpszElementValue);
}

void	CCIMData::fillCompany(tagCIMCompany* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)
		strcpy(pData->szAlias, lpszElementValue);
}

void	CCIMData::fillSubcontrolArea(tagCIMSubcontrolArea* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)
		strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:PowerSystemResource.OperatedBy_Companies") == 0)
		strcpy(pData->szCorp, lpszElementValue);
}

void	CCIMData::fillSubstation(tagCIMSubstation* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)
		strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Substation.MemberOf_SubcontrolArea") == 0)
		strcpy(pData->szSubcontrolAreaTag, lpszElementValue);

}

void	CCIMData::fillVoltageLevel(tagCIMVoltageLevel* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, FormatVoltageLevelName(lpszElementValue));
	else if (STRICMP(lpszElementName, "cim:VoltageLevel.highVoltageLimit") == 0)				pData->fHLimit=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:VoltageLevel.lowVoltageLimit") == 0)				pData->fLLimit=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:VoltageLevel.MemberOf_Substation") == 0)			strcpy(pData->szSubstationTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:VoltageLevel.BaseVoltage") == 0)					strcpy(pData->szBaseVoltageTag, lpszElementValue);
}

void	CCIMData::fillBay(tagCIMBay* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Bay.MemberOf_Substation") == 0)					strcpy(pData->szSubstationTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Bay.MemberOf_VoltageLevel") == 0)					strcpy(pData->szVoltageTag, lpszElementValue);
}

void	CCIMData::fillBusbarSection(tagCIMBusbarSection* pData, const char* lpszElementName, const char* lpszElementValue)
{
	//Log("        FillBusbarSecion: %s %s\n", lpszElementName, lpszElementValue);
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)				strcpy(pData->szTerminalTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			strcpy(pData->szBaseVoltageTag, lpszElementValue);
}

void	CCIMData::fillACLineSegment(tagCIMACLineSegment* pData, const char* lpszElementName, const char* lpszElementValue)
{
	float	fBuf;

	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			strcpy(pData->szBaseVoltageTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Conductor.r") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fR=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.x") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fX=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.r0") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fR0=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.x0") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fX0=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.gch") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fG=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.bch") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fB=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.gch0") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fG0=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.bch0") == 0)
	{
		//String2Double(fBuf, lpszElementValue);	//fBuf=(float)atof(lpszElementValue);
		fBuf=(float)atof(lpszElementValue);
		if (fBuf > 0)
			pData->fB0=fBuf;
	}
	else if (STRICMP(lpszElementName, "cim:Conductor.ratedA") == 0 || STRICMP(lpszElementName, "cimEx:ACLineSegment.ampRating") == 0)
	{
		//String2Double(pData->fRatedA, lpszElementValue);	//pData->fRatedA=atof(lpszElementValue);
		pData->fRatedA=atof(lpszElementValue);
	}
	else if (STRICMP(lpszElementName, "cim:ACLineSegment.MemberOf_Line") == 0)
		strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
	{
		if (strlen(pData->szTerminalTag[0]) <= 0)
			strcpy(pData->szTerminalTag[0], lpszElementValue);
		else if (strlen(pData->szTerminalTag[1]) <= 0)
			strcpy(pData->szTerminalTag[1], lpszElementValue);
	}
}

void	CCIMData::fillDCLineSegment(tagCIMDCLineSegment* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:DCLineSegment.dcSegmentInductance") == 0)			pData->fL=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:DCLineSegment.dcSegmentResistance") == 0)			pData->fR=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:DCLineSegment.MemberOf_Line") == 0)				strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			strcpy(pData->szBaseVoltageTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
	{
		if (strlen(pData->szTerminalTag[0]) <= 0)
			strcpy(pData->szTerminalTag[0], lpszElementValue);
		else if (strlen(pData->szTerminalTag[1]) <= 0)
			strcpy(pData->szTerminalTag[1], lpszElementValue);
	}
}

void	CCIMData::fillTransformerWinding(tagCIMTransformerWinding* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)									strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)							strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)								strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.r") == 0)							pData->fR=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.x") == 0)							pData->fX=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.x0") == 0)							pData->fX0=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.ratedMVA") == 0)					pData->fRatedMW=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.ratedKV") == 0)					pData->fRatedKV=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cimNX:TransformerWinding.loadLoss") == 0)					pData->fLoadLoss=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cimNX:TransformerWinding.leakageImpedence") == 0)			pData->fLeakageImpedence=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)			strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.MemberOf_PowerTransformer") == 0)	strcpy(pData->szPowerTransformerTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TransformerWinding.TapChangers") == 0)				strcpy(pData->szTapChangerTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)					strcpy(pData->szTerminalTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)				strcpy(pData->szBaseVoltageTag, lpszElementValue);
}

void	CCIMData::fillPowerTransformer(tagCIMPowerTransformer* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		strcpy(pData->szParentTag, lpszElementValue);
}

void	CCIMData::fillTapChanger(tagCIMTapChanger* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TapChanger.highStep") == 0)						pData->nHighStep=atoi(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TapChanger.lowStep") == 0)						pData->nLowStep=atoi(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TapChanger.neutralStep") == 0)					pData->nNeutralStep=atoi(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TapChanger.normalStep") == 0)						pData->nNormalStep=atoi(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TapChanger.stepVoltageIncrement") == 0)			pData->fStepVoltageIncrement=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:TapChanger.TransformerWinding") == 0)				strcpy(pData->szTransformerWindingTag, lpszElementValue);
}

void	CCIMData::fillSynchronousMachine(tagCIMSynchronousMachine* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)									strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)							strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)								strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.ratedMVA") == 0)					pData->fMvrate=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.maximumMVAr") == 0)				pData->fMaxQ=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)			strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.MemberOf_GeneratingUnit") == 0)	strcpy(pData->szUnitTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)					strcpy(pData->szTerminalTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)				strcpy(pData->szBaseVoltageTag, lpszElementValue);

	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.xDirectSync") == 0)				pData->fXd=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.xDirectTrans") == 0)				pData->fXdp=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.xDirectSubtrans") == 0)			pData->fXdpp=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.xQuadSync") == 0)					pData->fXq=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.xQuadTrans") == 0)					pData->fXqp=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.xQuadSubtrans") == 0)				pData->fXqpp=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.inertia") == 0)					pData->fTj=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:SynchronousMachine.damping") == 0)					pData->fD=(float)atof(lpszElementValue);
}

void	CCIMData::fillThermalGeneratingUnit(tagCIMThermalGeneratingUnit* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:GeneratingUnit.initialMW") == 0)				pData->fInitP=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:GeneratingUnit.minimumOperatingMW") == 0)		pData->fMinP=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:GeneratingUnit.maximumOperatingMW") == 0)		pData->fMaxP=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)
		strcpy(pData->szParentTag, lpszElementValue);

}

void	CCIMData::fillHydroGeneratingUnit(tagCIMHydroGeneratingUnit* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:GeneratingUnit.initialMW") == 0)			pData->fInitP=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:GeneratingUnit.maximumOperatingMW") == 0)	pData->fMaxP=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)
		strcpy(pData->szParentTag, lpszElementValue);
}

void	CCIMData::fillEnergyConsumer(tagCIMEnergyConsumer* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:EnergyConsumer.pfixedPct") == 0)					pData->pfixedPct=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:EnergyConsumer.qfixedPct") == 0)					pData->qfixedPct=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:EnergyConsumer.pFexp") == 0)						pData->pFexp=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:EnergyConsumer.qFexp") == 0)						pData->qFexp=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)				strcpy(pData->szTerminalTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			strcpy(pData->szBaseVoltageTag, lpszElementValue);
}

void	CCIMData::fillCompensator(tagCIMCompensator* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Compensator.nominalMVAr") == 0)					pData->fMvar=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Compensator.r") == 0)								pData->fSeriesR=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Compensator.x") == 0)								pData->fSeriesX=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Compensator.nominalkV") == 0)						pData->fNomV=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			strcpy(pData->szBaseVoltageTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Compensator.compensatorType") == 0)
	{
		char	szBuf[260];
		strcpy(szBuf, lpszElementValue);
		if (strstr(strlwr(szBuf), "series") != NULL)
			m_CompensatorBuf.bSeries=1;
		else
			m_CompensatorBuf.bSeries=0;
	}
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
	{
		if (strlen(pData->szTerminalTag1) <= 0)
			strcpy(pData->szTerminalTag1, lpszElementValue);
		else if (strlen(pData->szTerminalTag2) <= 0)
			strcpy(pData->szTerminalTag2, lpszElementValue);
	}
}

void	CCIMData::fillRectifierInverter(tagCIMRectifierInverter* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						strcpy(pData->szDesp, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:RectifierInverter.ratedKV") == 0)					pData->fRatedKV=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:RectifierInverter.bridges") == 0)					pData->nBridges=atoi(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:RectifierInverter.commutatingReactance") == 0)	pData->fCommutatingReactance=(float)atof(lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		strcpy(pData->szParentTag, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
	{
		if (strlen(pData->szTerminalTag[0]) <= 0)
			strcpy(pData->szTerminalTag[0], lpszElementValue);
		if (strlen(pData->szTerminalTag[1]) <= 0)
			strcpy(pData->szTerminalTag[1], lpszElementValue);
		if (strlen(pData->szTerminalTag[2]) <= 0)
			strcpy(pData->szTerminalTag[2], lpszElementValue);
	}
}

void	CCIMData::fillBreaker(tagCIMBreaker* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						pData->strDesp=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							pData->strAlias=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Switch.normalOpen") == 0)							pData->bOpen=(STRICMP(lpszElementValue, "false") == 0) ? 1 : 0;
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		pData->strParentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			pData->strBaseVoltageTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
	{
		if (pData->strTerminalTag[0].empty())
			pData->strTerminalTag[0]=lpszElementValue;
		if (pData->strTerminalTag[1].empty())
			pData->strTerminalTag[1]=lpszElementValue;
	}
}

void	CCIMData::fillDisconnector(tagCIMDisconnector* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)	pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)								pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)						pData->strDesp=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)							pData->strAlias=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Switch.normalOpen") == 0)							pData->bOpen= (STRICMP(lpszElementValue, "false") == 0) ? 1 : 0;
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)		pData->strParentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)			pData->strBaseVoltageTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
	{
		if (pData->strTerminalTag[0].empty())
			pData->strTerminalTag[0]=lpszElementValue;
		if (pData->strTerminalTag[1].empty())
			pData->strTerminalTag[1]=lpszElementValue;
	}
}

void	CCIMData::fillGroundDisconnector(tagCIMGroundDisconnector* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		pData->strDesp=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)
		pData->strAlias=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Switch.normalOpen") == 0)
	{
		if (STRICMP(lpszElementValue, "false") == 0)
			pData->bOpen=1;
		else
			pData->bOpen=0;
	}
	else if (STRICMP(lpszElementName, "cim:Equipment.MemberOf_EquipmentContainer") == 0)
		pData->strParentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.Terminals") == 0)
		pData->strTerminalTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConductingEquipment.BaseVoltage") == 0)
		pData->strBaseVoltageTag=lpszElementValue;
}

void	CCIMData::fillTerminal(tagCIMTerminal* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
	{
		pData->strResourceID=lpszElementValue;
		pData->strName=lpszElementValue;
	}
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)					pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Terminal.ConductingEquipment") == 0)	pData->strParentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Terminal.ConnectivityNode") == 0)		pData->strNodeTag=lpszElementValue;
}

void	CCIMData::fillConnectivityNode(tagCIMConnectivityNode* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
	{
		pData->strResourceID=lpszElementValue;
		pData->strName=lpszElementValue;
	}
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)									pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:ConnectivityNode.MemberOf_EquipmentContainer") == 0)	pData->strParentTag=lpszElementValue;
}

void	CCIMData::fillMeasurementType(tagCIMMeasurementType* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.aliasName") == 0)
		strcpy(pData->szAlias, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		strcpy(pData->szDesp, lpszElementValue);
}

void	CCIMData::fillMeasurementSource(tagCIMMeasurementSource* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		strcpy(pData->szDesp, lpszElementValue);
}

void	CCIMData::fillMeasurementValue(tagCIMMeasurementValue* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:MeasurementValue.value") == 0)
		pData->strMeasurementValue=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:MeasurementValue.MemberOf_Measurement") == 0)
		pData->strMeasurementTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:MeasurementValue.MeasurementValueSource") == 0)
		pData->strMeasurementSourceTag=lpszElementValue;
}

void	CCIMData::fillMeasurement(tagCIMMeasurement* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		pData->strDesp=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.Terminal") == 0)
		pData->strTerminalTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.MemberOf_PSR") == 0)
		pData->strEquimentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.MeasurementType") == 0)
		pData->strMeasurementTypeTag=lpszElementValue;
// 	else if (STRICMP(lpszElementName, "cim:Measurement.LimitSets") == 0)
// 	{
// 		if (pData->nLimitSetNum < 2)	pData->strLimitSetTag[pData->nLimitSetNum++]=lpszElementValue;
// 	}
}

void	CCIMData::fillAnalog(tagCIMAnalog* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		pData->strDesp=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.Terminal") == 0)
		pData->strTerminalTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.MemberOf_PSR") == 0)
		pData->strEquimentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.MeasurementType") == 0)
		pData->strMeasurementTypeTag=lpszElementValue;
// 	else if (STRICMP(lpszElementName, "cim:Measurement.LimitSets") == 0)
// 	{
// 		if (pData->nLimitSetNum < 2)
// 			pData->strLimitSetTag[pData->nLimitSetNum++]=lpszElementValue;
// 	}
}

void	CCIMData::fillDiscrete(tagCIMDiscrete* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		pData->strResourceID=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		pData->strName=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Naming.description") == 0)
		pData->strDesp=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.Terminal") == 0)
		pData->strTerminalTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.MemberOf_PSR") == 0)
		pData->strEquimentTag=lpszElementValue;
	else if (STRICMP(lpszElementName, "cim:Measurement.MeasurementType") == 0)
		pData->strMeasurementTypeTag=lpszElementValue;
// 	else if (STRICMP(lpszElementName, "cim:Measurement.LimitSets") == 0)
// 	{
// 		if (pData->nLimitSetNum < 2)
// 			pData->strLimitSetTag[pData->nLimitSetNum++]=lpszElementValue;
// 	}
}

void	CCIMData::fillLimitSet(tagCIMLimitSet* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
}

void	CCIMData::fillLimit(tagCIMLimit* pData, const char* lpszElementName, const char* lpszElementValue)
{
	if (STRICMP(lpszElementName, "rdf:ID") == 0 || STRICMP(lpszElementName, "rdfID") == 0)
		strcpy(pData->szResourceID, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Naming.name") == 0)
		strcpy(pData->szName, lpszElementValue);
	else if (STRICMP(lpszElementName, "cim:Limit.value") == 0)
		pData->fValue=atof(lpszElementValue);
// 	else if (STRICMP(lpszElementName, "cim:Limit.LimitSet") == 0)
// 		strcpy(pData->szLimitSetTag, lpszElementValue);
}
