#pragma once

const int	g_nBoudLineAttrNum=8;
const int	g_nBoudLoadAttrNum=7;

typedef	struct	_BoundLine_
{
	char	szName[100];
	char	szVolt[100];
	char	szType[100];
	float	fRatedA;
	char	szInSub[100];
	char	szInNode[100];
	char	szOutArea[100];
	unsigned char	bACLine;
}	tagBoundLine;

typedef	struct	_UCVoltageIndex_
{
	unsigned int	nID;
	char	szVolt[100];
	double	fNominal;
}	tagUCVoltageIndex;

static	tagUCVoltageIndex	g_UCVoltIndexArray[]=
{
	{	3,	"750KV",	750,	},
	{	2,	"500KV",	500,	},
	{	14,	"400KV",	400,	},
	{	1,	"220KV",	220,	},
	{	4,	"110KV",	110,	},
	{	5,	"34.5KV",	34.5,	},
	{	13,	"26KV",		26,		},
	{	17,	"22KV",		22,		},
	{	7,	"20KV",		20,		},
	{	16,	"19KV",		19,		},
	{	15,	"18KV",		18,		},
	{	8,	"15.75KV",	15.75,	},
	{	9,	"14.5KV",	14.5,	},
	{	10,	"13.8KV",	13.8,	},
	{	11,	"10.5KV",	10.5,	},
	{	12,	"6.3KV",	6.3,	},
};
