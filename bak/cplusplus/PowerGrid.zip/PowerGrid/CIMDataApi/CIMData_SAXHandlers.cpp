/*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  See the NOTICE file distributed with
* this work for additional information regarding copyright ownership.
* The ASF licenses this file to You under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with
* the License.  You may obtain a copy of the License at
*
*      http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, 
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/*
* $Id: CIMData_SAXHandlers.cpp 676911 2008-07-15 13:27:32Z amassari $
*/


// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------
#include "stdafx.h"
#include <xercesc/util/XMLUniDefs.hpp>
#include <xercesc/sax/AttributeList.hpp>
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/PlatformUtils.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/TransService.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/parsers/SAXParser.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/OutOfMemoryException.hpp"

#include "CIMData_SAXHandlers.hpp"

#include "CIMDataTable.h"

// ---------------------------------------------------------------------------
//  Local const data
//
//  Note: This is the 'safe' way to do these strings. If you compiler supports
//        L"" style strings, and portability is not a concern, you can use
//        those types constants directly.
// ---------------------------------------------------------------------------
static const XMLCh  gEndElement[] = { chOpenAngle, chForwardSlash, chNull };
static const XMLCh  gEndPI[] = { chQuestion, chCloseAngle, chNull };
static const XMLCh  gStartPI[] = { chOpenAngle, chQuestion, chNull };
static const XMLCh  gXMLDecl1[] =
{
	chOpenAngle, chQuestion, chLatin_x, chLatin_m, chLatin_l
	,   chSpace, chLatin_v, chLatin_e, chLatin_r, chLatin_s, chLatin_i
	,   chLatin_o, chLatin_n, chEqual, chDoubleQuote, chDigit_1, chPeriod
	,   chDigit_0, chDoubleQuote, chSpace, chLatin_e, chLatin_n, chLatin_c
	,   chLatin_o, chLatin_d, chLatin_i, chLatin_n, chLatin_g, chEqual
	,   chDoubleQuote, chNull
};

static const XMLCh  gXMLDecl2[] =
{
	chDoubleQuote, chQuestion, chCloseAngle
	,   chLF, chNull
};




// ---------------------------------------------------------------------------
//  CIMData_SAXHandlers: Constructors and Destructor
// ---------------------------------------------------------------------------
CIMData_SAXHandlers::CIMData_SAXHandlers(CCIMData* pCIMData,  const char* const encodingName, const XMLFormatter::UnRepFlags unRepFlags) :

fFormatter
(
 encodingName
 , 0
 , this
 , XMLFormatter::NoEscapes
 , unRepFlags
 )
{
	//
	//  Go ahead and output an XML Decl with our known encoding. This
	//  is not the best answer, but its the best we can do until we
	//  have SAX2 support.
	//
	fFormatter << gXMLDecl1 << fFormatter.getEncodingName() << gXMLDecl2;

	m_pCIMData=pCIMData;
}

CIMData_SAXHandlers::~CIMData_SAXHandlers()
{
}


static	int		m_nCimSection=-1;
static	std::string	m_strElementValue;
// ---------------------------------------------------------------------------
//  CIMData_SAXHandlers: Overrides of the output formatter target interface
// ---------------------------------------------------------------------------
void CIMData_SAXHandlers::writeChars(const XMLByte* const /* toWrite */)
{
}

void CIMData_SAXHandlers::writeChars(const XMLByte* const toWrite, const XMLSize_t count, XMLFormatter* const /* formatter */)
{
	// For this one, just dump them to the standard output
	// Surprisingly, Solaris was the only platform on which
	// required the char* cast to print out the string correctly.
	// Without the cast, it was printing the pointer value in hex.
	// Quite annoying, considering every other platform printed
	// the string with the explicit cast to char* below.
	//char* lpszValue = XMLString::transcode(name);
	//XMLString::release(&lpszValue);

	//XERCES_STD_QUALIFIER cout.write((char *) toWrite, (int) count);
	//XERCES_STD_QUALIFIER cout.flush();
}


// ---------------------------------------------------------------------------
//  CIMData_SAXHandlers: Overrides of the SAX ErrorHandler interface
// ---------------------------------------------------------------------------
void CIMData_SAXHandlers::error(const SAXParseException& e)
{
	char*	lpszID=XMLString::transcode(e.getSystemId());
	char*	lpszMesg=XMLString::transcode(e.getMessage());
	XERCES_STD_QUALIFIER cerr << "\nError at file " << lpszID
		<< ", line " << e.getLineNumber()
		<< ", char " << e.getColumnNumber()
		<< "\n  Message: " << lpszMesg << XERCES_STD_QUALIFIER endl;
	XMLString::release(&lpszMesg);
	XMLString::release(&lpszID);
}

void CIMData_SAXHandlers::fatalError(const SAXParseException& e)
{
	char*	lpszID=XMLString::transcode(e.getSystemId());
	char*	lpszMesg=XMLString::transcode(e.getMessage());
	XERCES_STD_QUALIFIER cerr << "\nFatal Error at file " << lpszID
		<< ", line " << e.getLineNumber()
		<< ", char " << e.getColumnNumber()
		<< "\n  Message: " << lpszMesg << XERCES_STD_QUALIFIER endl;
	XMLString::release(&lpszMesg);
	XMLString::release(&lpszID);
}

void CIMData_SAXHandlers::warning(const SAXParseException& e)
{
	char*	lpszID=XMLString::transcode(e.getSystemId());
	char*	lpszMesg=XMLString::transcode(e.getMessage());
	XERCES_STD_QUALIFIER cerr << "\nWarning at file " << lpszID
		<< ", line " << e.getLineNumber()
		<< ", char " << e.getColumnNumber()
		<< "\n  Message: " << lpszMesg << XERCES_STD_QUALIFIER endl;
	XMLString::release(&lpszMesg);
	XMLString::release(&lpszID);
}


// ---------------------------------------------------------------------------
//  CIMData_SAXHandlers: Overrides of the SAX DTDHandler interface
// ---------------------------------------------------------------------------
void CIMData_SAXHandlers::unparsedEntityDecl(const     XMLCh* const /* name */
											 , const   XMLCh* const /* publicId */
											 , const   XMLCh* const /* systemId */
											 , const   XMLCh* const /* notationName */)
{
	// Not used at this time
}


void CIMData_SAXHandlers::notationDecl(const   XMLCh* const /* name */
									   , const XMLCh* const /* publicId */
									   , const XMLCh* const /* systemId */)
{
	// Not used at this time
}


// ---------------------------------------------------------------------------
//  CIMData_SAXHandlers: Overrides of the SAX DocumentHandler interface
// ---------------------------------------------------------------------------
void CIMData_SAXHandlers::characters(const XMLCh* const chars, const XMLSize_t length)
{
	//fFormatter.formatBuf(chars, length, XMLFormatter::CharEscapes);
	if (length > 0)
	{
		char* lpszValue = XMLString::transcode(chars);
		m_strElementValue=lpszValue;
		XMLString::release(&lpszValue);
	}
}

void CIMData_SAXHandlers::endDocument()
{
}


void CIMData_SAXHandlers::ignorableWhitespace(const XMLCh* const chars, const  XMLSize_t    length)
{
	fFormatter.formatBuf(chars, length, XMLFormatter::NoEscapes);
}


void CIMData_SAXHandlers::processingInstruction(const  XMLCh* const target, const XMLCh* const data)
{
// 	fFormatter << XMLFormatter::NoEscapes << gStartPI  << target;
// 	if (data)
// 		fFormatter << chSpace << data;
// 	fFormatter << XMLFormatter::NoEscapes << gEndPI;
}


void CIMData_SAXHandlers::startDocument()
{
}


void CIMData_SAXHandlers::endElement(const XMLCh* const name)
{
	// No escapes are legal here
	//fFormatter << XMLFormatter::NoEscapes << gEndElement << name << chCloseAngle;
	char* lpszName = XMLString::transcode(name);

	unsigned char	bCimSection=0;
	if (m_nCimSection >= 0)
	{
		register int	i;
		for (i=0; i<sizeof(g_CIMTableArray)/sizeof(tagCIMNameDesp); i++)
		{
			if (STRICMP(lpszName, g_CIMTableArray[i].szName) == 0)
			{
				bCimSection=1;
				break;
			}
		}
	}


	if (bCimSection)
	{
		m_pCIMData->AppendElementBuffer(m_nCimSection);
		m_nCimSection=-1;
	}
	else
	{
		//if (strlen(m_szElementValue) > 0)	m_pCIMData->FillElement(m_nCimSection, lpszName, m_szElementValue);
		if (!m_strElementValue.empty())	m_pCIMData->FillElement(m_nCimSection, lpszName, m_strElementValue.c_str());
	}
	XMLString::release(&lpszName);
}

void CIMData_SAXHandlers::startElement(const XMLCh* const name, AttributeList&  attributes)
{
	// The name has to be representable without any escapes
	//fFormatter  << XMLFormatter::NoEscapes << chOpenAngle << name;
	register int	i;

	//memset(m_szElementValue, 0, 512);
	m_strElementValue.clear();
	char* lpszName = XMLString::transcode(name);

	//Log("startElement=%s\n", lpszName);
	if (m_nCimSection < 0)
	{
		for (i=0; i<sizeof(g_CIMTableArray)/sizeof(tagCIMNameDesp); i++)
		{
			if (STRICMP(lpszName, g_CIMTableArray[i].szName) == 0)
			{
				m_nCimSection=g_CIMTableArray[i].nID;
				m_pCIMData->PrepareElementBuffer(m_nCimSection);

				XMLSize_t len = attributes.getLength();
				for (XMLSize_t index = 0; index < len; index++)
				{
					char* lpszAttrName = XMLString::transcode(attributes.getName(index));
					char* lpszAttrValue = XMLString::transcode(attributes.getValue(index));

// 					if (STRICMP(lpszAttrName, "rdf:resource") != 0)
// 						continue;

					if (lpszAttrValue[0] == '#')
						m_pCIMData->FillElement(m_nCimSection, lpszAttrName, (char*)(lpszAttrValue+1));
					else
						m_pCIMData->FillElement(m_nCimSection, lpszAttrName, lpszAttrValue);

					XMLString::release(&lpszAttrName);
					XMLString::release(&lpszAttrValue);
				}
				break;
			}
		}
	}
	else
	{
		XMLSize_t len = attributes.getLength();
		for (XMLSize_t index = 0; index < len; index++)
		{
			char* lpszAttrName = XMLString::transcode(attributes.getName(index));
			char* lpszAttrValue = XMLString::transcode(attributes.getValue(index));

			if (STRICMP(lpszAttrName, "rdf:resource") == 0)
			{
				if (lpszAttrValue[0] == '#')
					m_pCIMData->FillElement(m_nCimSection, lpszName, (char*)(lpszAttrValue+1));
				else
					m_pCIMData->FillElement(m_nCimSection, lpszName, lpszAttrValue);
			}

			XMLString::release(&lpszAttrName);
			XMLString::release(&lpszAttrValue);
		}
	}

	XMLString::release(&lpszName);
}
