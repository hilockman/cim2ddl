#pragma once

#include "CIMData.h"
class CIMDATAAPI_API CCIMParser
{
public:
	CCIMParser(void);
	~CCIMParser(void);

	int		Parse(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement=1, const int bParseBySax=0, const int bNameByDesp=1, const int bSubstationNamePrefixSubcontrolArea = 1);

private:
};
