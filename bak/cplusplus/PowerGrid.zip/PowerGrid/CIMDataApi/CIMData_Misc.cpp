#include "stdafx.h"
#include "CIMData.h"

void CCIMData::sortBaseVoltageByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_BaseVoltageArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BaseVoltageArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BaseVoltageArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BaseVoltageArray[nDn], m_BaseVoltageArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBaseVoltageByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortBaseVoltageByResID(nDn, nUp0);
}

int	CCIMData::findBaseVoltageByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_BaseVoltageArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BaseVoltageArray[nMid].szResourceID, lpszResID) > 0)
				return findBaseVoltageByResID(nLeft, nMid-1, lpszResID);
			else
				return findBaseVoltageByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortTerminalByParentTag(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strParentTag=m_TerminalArray[(nDn0+nUp0)/2].strParentTag;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_TerminalArray[nDn].strParentTag.c_str(), strParentTag.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_TerminalArray[nUp].strParentTag.c_str(), strParentTag.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_TerminalArray[nDn], m_TerminalArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortTerminalByParentTag(nDn0, nUp);
	if (nDn < nUp0 )
		sortTerminalByParentTag(nDn, nUp0);
}

int	CCIMData::findTerminalByParentTag(int nLeft, int nRight, const char* lpszTag)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_TerminalArray[nMid].strParentTag.c_str(), lpszTag) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_TerminalArray[nMid].strParentTag.c_str(), lpszTag) > 0)
				return findTerminalByParentTag(nLeft, nMid-1, lpszTag);
			else
				return findTerminalByParentTag(nMid+1, nRight, lpszTag);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortConnectivityNodeByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_ConnectivityNodeArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_ConnectivityNodeArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_ConnectivityNodeArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_ConnectivityNodeArray[nDn], m_ConnectivityNodeArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortConnectivityNodeByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortConnectivityNodeByResID(nDn, nUp0);
}

int	CCIMData::findConnectivityNodeByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_ConnectivityNodeArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ConnectivityNodeArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findConnectivityNodeByResID(nLeft, nMid-1, lpszResID);
			else
				return findConnectivityNodeByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortSubstationByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_SubstationArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_SubstationArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_SubstationArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_SubstationArray[nDn], m_SubstationArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortSubstationByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortSubstationByResID(nDn, nUp0);
}

int	CCIMData::findSubstationByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_SubstationArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_SubstationArray[nMid].szResourceID, lpszResID) > 0)
				return findSubstationByResID(nLeft, nMid-1, lpszResID);
			else
				return findSubstationByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortVoltageLevelByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_VoltageLevelArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_VoltageLevelArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_VoltageLevelArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_VoltageLevelArray[nDn], m_VoltageLevelArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortVoltageLevelByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortVoltageLevelByResID(nDn, nUp0);
}

int	CCIMData::findVoltageLevelByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_VoltageLevelArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_VoltageLevelArray[nMid].szResourceID, lpszResID) > 0)
				return findVoltageLevelByResID(nLeft, nMid-1, lpszResID);
			else
				return findVoltageLevelByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortBayByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_BayArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BayArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BayArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BayArray[nDn], m_BayArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBayByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortBayByResID(nDn, nUp0);
}

int	CCIMData::findBayByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_BayArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BayArray[nMid].szResourceID, lpszResID) > 0)
				return findBayByResID(nLeft, nMid-1, lpszResID);
			else
				return findBayByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortACLineSegmentByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResID[MDB_CHARLEN];
	strcpy(szResID, m_ACLineSegmentArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_ACLineSegmentArray[nDn].szResourceID, szResID) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_ACLineSegmentArray[nUp].szResourceID, szResID) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_ACLineSegmentArray[nDn], m_ACLineSegmentArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortACLineSegmentByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortACLineSegmentByResID(nDn, nUp0);
}

int	CCIMData::findACLineSegmentByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_ACLineSegmentArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_ACLineSegmentArray[nMid].szResourceID, lpszResID) > 0)
				return findACLineSegmentByResID(nLeft, nMid-1, lpszResID);
			else
				return findACLineSegmentByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortTransformerWindingByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResID[MDB_CHARLEN];
	strcpy(szResID, m_TransformerWindingArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_TransformerWindingArray[nDn].szResourceID, szResID) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_TransformerWindingArray[nUp].szResourceID, szResID) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_TransformerWindingArray[nDn], m_TransformerWindingArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortTransformerWindingByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortTransformerWindingByResID(nDn, nUp0);
}

int	CCIMData::findTransformerWindingByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_TransformerWindingArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_TransformerWindingArray[nMid].szResourceID, lpszResID) > 0)
				return findTransformerWindingByResID(nLeft, nMid-1, lpszResID);
			else
				return findTransformerWindingByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortPowerTransformerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResID[MDB_CHARLEN];
	strcpy(szResID, m_PowerTransformerArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_PowerTransformerArray[nDn].szResourceID, szResID) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_PowerTransformerArray[nUp].szResourceID, szResID) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PowerTransformerArray[nDn], m_PowerTransformerArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortPowerTransformerByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortPowerTransformerByResID(nDn, nUp0);
}

int	CCIMData::findPowerTransformerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_PowerTransformerArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_PowerTransformerArray[nMid].szResourceID, lpszResID) > 0)
				return findPowerTransformerByResID(nLeft, nMid-1, lpszResID);
			else
				return findPowerTransformerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortTapChangerByTransformerWindingResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szWindingTag[MDB_CHARLEN];
	strcpy(szWindingTag, m_TapChangerArray[(nDn0+nUp0)/2].szTransformerWindingTag);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_TapChangerArray[nDn].szTransformerWindingTag, szWindingTag) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_TapChangerArray[nUp].szTransformerWindingTag, szWindingTag) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_TapChangerArray[nDn], m_TapChangerArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortTapChangerByTransformerWindingResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortTapChangerByTransformerWindingResID(nDn, nUp0);
}

int	CCIMData::findTapChangerByTransformerWindingResID(int nLeft, int nRight, const char* lpszTransformerWindingResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_TapChangerArray[nMid].szTransformerWindingTag, lpszTransformerWindingResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_TapChangerArray[nMid].szTransformerWindingTag, lpszTransformerWindingResID) > 0)
				return findTapChangerByTransformerWindingResID(nLeft, nMid-1, lpszTransformerWindingResID);
			else
				return findTapChangerByTransformerWindingResID(nMid+1, nRight, lpszTransformerWindingResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortTapChangerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_TapChangerArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_TapChangerArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_TapChangerArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_TapChangerArray[nDn], m_TapChangerArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortTapChangerByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortTapChangerByResID(nDn, nUp0);
}

int	CCIMData::findTapChangerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_TapChangerArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_TapChangerArray[nMid].szResourceID, lpszResID) > 0)
				return findTapChangerByResID(nLeft, nMid-1, lpszResID);
			else
				return findTapChangerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortBusbarSectionByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_BusbarSectionArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BusbarSectionArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BusbarSectionArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BusbarSectionArray[nDn], m_BusbarSectionArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBusbarSectionByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortBusbarSectionByResID(nDn, nUp0);
}

int	CCIMData::findBusbarSectionByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_BusbarSectionArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BusbarSectionArray[nMid].szResourceID, lpszResID) > 0)
				return findBusbarSectionByResID(nLeft, nMid-1, lpszResID);
			else
				return findBusbarSectionByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortSynchronousMachineByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_SynchronousMachineArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_SynchronousMachineArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_SynchronousMachineArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_SynchronousMachineArray[nDn], m_SynchronousMachineArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortSynchronousMachineByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortSynchronousMachineByResID(nDn, nUp0);
}

int	CCIMData::findSynchronousMachineByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_SynchronousMachineArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_SynchronousMachineArray[nMid].szResourceID, lpszResID) > 0)
				return findSynchronousMachineByResID(nLeft, nMid-1, lpszResID);
			else
				return findSynchronousMachineByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortEnergyConsumerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_EnergyConsumerArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_EnergyConsumerArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_EnergyConsumerArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_EnergyConsumerArray[nDn], m_EnergyConsumerArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortEnergyConsumerByResID(nDn0, nUp);

	if (nDn < nUp0 )
		sortEnergyConsumerByResID(nDn, nUp0);
}

int	CCIMData::findEnergyConsumerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_EnergyConsumerArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_EnergyConsumerArray[nMid].szResourceID, lpszResID) > 0)
				return findEnergyConsumerByResID(nLeft, nMid-1, lpszResID);
			else
				return findEnergyConsumerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortShuntCompensatorByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_CompensatorArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_CompensatorArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_CompensatorArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_CompensatorArray[nDn], m_CompensatorArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortShuntCompensatorByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortShuntCompensatorByResID(nDn, nUp0);
}

int	CCIMData::findCompensatorByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_CompensatorArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_CompensatorArray[nMid].szResourceID, lpszResID) > 0)
				return findCompensatorByResID(nLeft, nMid-1, lpszResID);
			else
				return findCompensatorByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortBreakerByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_BreakerArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_BreakerArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_BreakerArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_BreakerArray[nDn], m_BreakerArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortBreakerByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortBreakerByResID(nDn, nUp0);
}

int	CCIMData::findBreakerByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_BreakerArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_BreakerArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findBreakerByResID(nLeft, nMid-1, lpszResID);
			else
				return findBreakerByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortDisconnectorByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_DisconnectorArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_DisconnectorArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_DisconnectorArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_DisconnectorArray[nDn], m_DisconnectorArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortDisconnectorByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortDisconnectorByResID(nDn, nUp0);
}

int	CCIMData::findDisconnectorByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_DisconnectorArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_DisconnectorArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findDisconnectorByResID(nLeft, nMid-1, lpszResID);
			else
				return findDisconnectorByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortGroundDisconnectorByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_GroundDisconnectorArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_GroundDisconnectorArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_GroundDisconnectorArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_GroundDisconnectorArray[nDn], m_GroundDisconnectorArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortGroundDisconnectorByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortGroundDisconnectorByResID(nDn, nUp0);
}

int	CCIMData::findGroundDisconnectorByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_GroundDisconnectorArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_GroundDisconnectorArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findGroundDisconnectorByResID(nLeft, nMid-1, lpszResID);
			else
				return findGroundDisconnectorByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortMeasurementByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_MeasurementArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_MeasurementArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_MeasurementArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_MeasurementArray[nDn], m_MeasurementArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortMeasurementByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortMeasurementByResID(nDn, nUp0);
}

int	CCIMData::findMeasurementByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_MeasurementArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_MeasurementArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findMeasurementByResID(nLeft, nMid-1, lpszResID);
			else
				return findMeasurementByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortMeasurementTypeByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	char	szResId[MDB_CHARLEN];
	strcpy(szResId, m_MeasurementTypeArray[(nDn0+nUp0)/2].szResourceID);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_MeasurementTypeArray[nDn].szResourceID, szResId) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_MeasurementTypeArray[nUp].szResourceID, szResId) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_MeasurementTypeArray[nDn], m_MeasurementTypeArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortMeasurementTypeByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortMeasurementTypeByResID(nDn, nUp0);
}

int	CCIMData::findMeasurementTypeByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_MeasurementTypeArray[nMid].szResourceID, lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_MeasurementTypeArray[nMid].szResourceID, lpszResID) > 0)
				return findMeasurementTypeByResID(nLeft, nMid-1, lpszResID);
			else
				return findMeasurementTypeByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortAnalogByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_AnalogArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_AnalogArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_AnalogArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_AnalogArray[nDn], m_AnalogArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortAnalogByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortAnalogByResID(nDn, nUp0);
}

int	CCIMData::findAnalogByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_AnalogArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_AnalogArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findAnalogByResID(nLeft, nMid-1, lpszResID);
			else
				return findAnalogByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void CCIMData::sortDiscreteByResID(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	std::string	strResId=m_DiscreteArray[(nDn0+nUp0)/2].strResourceID;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_DiscreteArray[nDn].strResourceID.c_str(), strResId.c_str()) < 0)
			++nDn;													 
		while (nUp > nDn0 && strcmp(m_DiscreteArray[nUp].strResourceID.c_str(), strResId.c_str()) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_DiscreteArray[nDn], m_DiscreteArray[nUp]);

			++nDn;
			--nUp;
		}
	}
	strResId.clear();

	if (nDn0 < nUp)
		sortDiscreteByResID(nDn0, nUp);
	if (nDn < nUp0 )
		sortDiscreteByResID(nDn, nUp0);
}

int	CCIMData::findDiscreteByResID(int nLeft, int nRight, const char* lpszResID)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_DiscreteArray[nMid].strResourceID.c_str(), lpszResID) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_DiscreteArray[nMid].strResourceID.c_str(), lpszResID) > 0)
				return findDiscreteByResID(nLeft, nMid-1, lpszResID);
			else
				return findDiscreteByResID(nMid+1, nRight, lpszResID);
		}
	}
	else
	{
		return -1;
	}

	return -1;
}

void	CCIMData::NomalizeVoltageLevelName(const double fNorminalVoltage, char* lpszRetVoltageLevelName)
{
	register int	i;
	char	szBuf[MDB_CHARLEN_SHORTER];
	unsigned char	bHasPoint;

	return;

	sprintf(szBuf, "%.2f", fNorminalVoltage);

	bHasPoint=0;
	for (i=0; i<(int)strlen(szBuf); i++)
	{
		if (szBuf[i] == '.')
		{
			bHasPoint=1;
			break;
		}
	}
	if (bHasPoint)
	{
		for (i=(int)strlen(szBuf)-1; i>=0; i--)
		{
			if (szBuf[i] == '.')
			{
				szBuf[i]='\0';
				break;
			}

			if (szBuf[i] != '0' && szBuf[i] != ' ')
				break;
			else
			{
				szBuf[i]='\0';
			}
		}
	}
	strcpy(lpszRetVoltageLevelName, szBuf);
}

//	��ѹ�ȼ����ɽڵ�����ģ���Ϊ��ЩCIM�еĸ�ΪBAY��BAY���ܲ�ֻһ����ѹ�ȼ�
void	CCIMData::SubstationVoltagePostProc(const int bNameByDesp, const int bSubstationNamePrefixSubcontrolArea)
{
	register int	i;
	int		nDev, nFind;
	char	szBuf[MDB_CHARLEN];

	//	Substation�����Ʒ�װ
	for (nDev=0; nDev<(int)m_SubstationArray.size(); nDev++)
	{
		if (bNameByDesp)
			m_SubstationArray[nDev].strSubcontrolArea=m_SubcontrolAreaArray[0].szDesp;
		else
			m_SubstationArray[nDev].strSubcontrolArea=m_SubcontrolAreaArray[0].szName;

		for (i=0; i<(int)m_SubcontrolAreaArray.size(); i++)
		{
			if (strcmp(m_SubstationArray[nDev].szSubcontrolAreaTag, m_SubcontrolAreaArray[i].szResourceID) == 0)
			{
				m_SubstationArray[nDev].strSubcontrolArea=(bNameByDesp) ? m_SubcontrolAreaArray[i].szDesp : m_SubcontrolAreaArray[i].szName;
				break;
			}
		}

		m_SubstationArray[nDev].strRealName.clear();
		if (bSubstationNamePrefixSubcontrolArea)
		{
			m_SubstationArray[nDev].strRealName=m_SubstationArray[nDev].strSubcontrolArea;
			m_SubstationArray[nDev].strRealName += '.';
		}

		if (bNameByDesp)
			m_SubstationArray[nDev].strRealName.append(m_SubstationArray[nDev].szDesp);
		else
			m_SubstationArray[nDev].strRealName.append(m_SubstationArray[nDev].szName);
	}

	//	Voltage��ȷ����վ
	for (nDev=0; nDev<(int)m_VoltageLevelArray.size(); nDev++)
	{
		if (strlen(m_VoltageLevelArray[nDev].szSubstationTag) <= 0)
			continue;

		nFind=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_VoltageLevelArray[nDev].szSubstationTag);
		if (nFind >= 0)
			strcpy(m_VoltageLevelArray[nDev].szSub, m_SubstationArray[nFind].strRealName.c_str());
		else
			Log(g_lpszLogFile, "��ѹ�ȼ� ResID=%s �г�վ��Ϣ�����Ҳ�����վ SubRes=%s\n", m_VoltageLevelArray[nDev].szResourceID, m_VoltageLevelArray[nDev].szSubstationTag);
	}

	//	Voltage��ȷ��NominalVoltage����һ������
	for (nDev=0; nDev<(int)m_VoltageLevelArray.size(); nDev++)
	{
		nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_VoltageLevelArray[nDev].szBaseVoltageTag);
		if (nFind >= 0)
		{
			m_VoltageLevelArray[nDev].fNominal=m_BaseVoltageArray[nFind].fNominalVoltage;
			NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_VoltageLevelArray[nDev].szName);
		}
	}
	//	Bay��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_BayArray.size(); nDev++)
	{
		if (strlen(m_BayArray[nDev].szSubstationTag) > 0)
		{
			nFind=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_BayArray[nDev].szSubstationTag);
			if (nFind >= 0)
				strcpy(m_BayArray[nDev].szSub, m_SubstationArray[nFind].strRealName.c_str());
		}

		if (strlen(m_BayArray[nDev].szVoltageTag) > 0)
		{
			nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_BayArray[nDev].szVoltageTag);
			if (nFind >= 0)
			{
				strcpy(m_BayArray[nDev].szSub, m_VoltageLevelArray[nFind].szSub);
				strcpy(m_BayArray[nDev].szVolt, m_VoltageLevelArray[nFind].szName);
			}
		}

		if (strlen(m_BayArray[nDev].szSub) <= 0 && strlen(m_BayArray[nDev].szVolt) <= 0)
			Log(g_lpszLogFile, "��� ResID=%s ����Ϣ�����Ҳ�����վ�͵�ѹ SubRes=%s VoltRes=%s\n", m_BayArray[nDev].szResourceID, m_BayArray[nDev].szSubstationTag, m_BayArray[nDev].szVoltageTag);
	}
	//	PowerTransformer��ȷ��Substation
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (strlen(m_PowerTransformerArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_PowerTransformerArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_PowerTransformerArray[nDev].szSub, m_SubstationArray[nFind].strRealName.c_str());
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_PowerTransformerArray[nDev].szParentTag);
			if (nFind >= 0)
				strcpy(m_PowerTransformerArray[nDev].szSub, m_BayArray[nFind].szSub);
			else
				Log(g_lpszLogFile, "��ѹ�� ResID=%s �г�վ��Ϣ�����Ҳ�����վ SubRes=%s\n", m_PowerTransformerArray[nDev].szResourceID, m_PowerTransformerArray[nDev].szParentTag);
		}
	}

	//	RectifierInverter��ȷ��Substation
	for (nDev=0; nDev<(int)m_RectifierInverterArray.size(); nDev++)
	{
		if (strlen(m_RectifierInverterArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findSubstationByResID(0, (int)m_SubstationArray.size()-1, m_RectifierInverterArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_RectifierInverterArray[nDev].szSub, m_SubstationArray[nFind].strRealName.c_str());
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_RectifierInverterArray[nDev].szParentTag);
			if (nFind >= 0)
				strcpy(m_RectifierInverterArray[nDev].szSub, m_BayArray[nFind].szSub);
			else
				Log(g_lpszLogFile, "��������� ResID=%s �г�վ��Ϣ�����Ҳ�����վ SubRes=%s\n", m_RectifierInverterArray[nDev].szResourceID, m_RectifierInverterArray[nDev].szParentTag);
		}
	}
	//	TransformerWinding��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_TransformerWindingArray.size(); nDev++)
	{
		if (strlen(m_TransformerWindingArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_TransformerWindingArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_TransformerWindingArray[nDev].szSub, m_VoltageLevelArray[nFind].szSub);
			strcpy(m_TransformerWindingArray[nDev].szVolt, m_VoltageLevelArray[nFind].szName);
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_TransformerWindingArray[nDev].szParentTag);
			if (nFind >= 0)
			{
				strcpy(m_TransformerWindingArray[nDev].szSub, m_BayArray[nFind].szSub);
				strcpy(m_TransformerWindingArray[nDev].szVolt, m_BayArray[nFind].szVolt);
			}
			else
				Log(g_lpszLogFile, "��ѹ������ ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_TransformerWindingArray[nDev].szResourceID, m_TransformerWindingArray[nDev].szParentTag);
		}
		if (strlen(m_TransformerWindingArray[nDev].szBaseVoltageTag) > 0)
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_TransformerWindingArray[nDev].szBaseVoltageTag);
			if (nFind >= 0)
			{
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_TransformerWindingArray[nDev].szVolt);
			}
		}
	}
	//	BusbarSection��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		if (strlen(m_BusbarSectionArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_BusbarSectionArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_BusbarSectionArray[nDev].szSub, m_VoltageLevelArray[nFind].szSub);
			strcpy(m_BusbarSectionArray[nDev].szVolt, m_VoltageLevelArray[nFind].szName);
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_BusbarSectionArray[nDev].szParentTag);
			if (nFind >= 0)
			{
				strcpy(m_BusbarSectionArray[nDev].szSub, m_BayArray[nFind].szSub);
				strcpy(m_BusbarSectionArray[nDev].szVolt, m_BayArray[nFind].szVolt);
			}
			else
				Log(g_lpszLogFile, "ĸ�� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_BusbarSectionArray[nDev].szResourceID, m_BusbarSectionArray[nDev].szParentTag);
		}
		if (strlen(m_BusbarSectionArray[nDev].szBaseVoltageTag) > 0)
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_BusbarSectionArray[nDev].szBaseVoltageTag);
			if (nFind >= 0)
			{
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_BusbarSectionArray[nDev].szVolt);
			}
		}
	}
	//	SynchronousMachine��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_SynchronousMachineArray.size(); nDev++)
	{
		if (strlen(m_SynchronousMachineArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_SynchronousMachineArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_SynchronousMachineArray[nDev].szSub, m_VoltageLevelArray[nFind].szSub);
			strcpy(m_SynchronousMachineArray[nDev].szVolt, m_VoltageLevelArray[nFind].szName);
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_SynchronousMachineArray[nDev].szParentTag);
			if (nFind >= 0)
			{
				strcpy(m_SynchronousMachineArray[nDev].szSub, m_BayArray[nFind].szSub);
				strcpy(m_SynchronousMachineArray[nDev].szVolt, m_BayArray[nFind].szVolt);
			}
			else
				Log(g_lpszLogFile, "����� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_SynchronousMachineArray[nDev].szResourceID, m_SynchronousMachineArray[nDev].szParentTag);
		}
		if (strlen(m_SynchronousMachineArray[nDev].szBaseVoltageTag) > 0)
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_SynchronousMachineArray[nDev].szBaseVoltageTag);
			if (nFind >= 0)
			{
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_SynchronousMachineArray[nDev].szVolt);
			}
		}
	}
	//	EnergyConsumer��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		if (strlen(m_EnergyConsumerArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_EnergyConsumerArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_EnergyConsumerArray[nDev].szSub, m_VoltageLevelArray[nFind].szSub);
			strcpy(m_EnergyConsumerArray[nDev].szVolt, m_VoltageLevelArray[nFind].szName);
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_EnergyConsumerArray[nDev].szParentTag);
			if (nFind >= 0)
			{
				strcpy(m_EnergyConsumerArray[nDev].szSub, m_BayArray[nFind].szSub);
				strcpy(m_EnergyConsumerArray[nDev].szVolt, m_BayArray[nFind].szVolt);
			}
			else
				Log(g_lpszLogFile, "���� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_EnergyConsumerArray[nDev].szResourceID, m_EnergyConsumerArray[nDev].szParentTag);
		}
		if (strlen(m_EnergyConsumerArray[nDev].szBaseVoltageTag) > 0)
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_EnergyConsumerArray[nDev].szBaseVoltageTag);
			if (nFind >= 0)
			{
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_EnergyConsumerArray[nDev].szVolt);
			}
		}
	}
	//	ShuntCompensator��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		if (strlen(m_CompensatorArray[nDev].szParentTag) <= 0)
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_CompensatorArray[nDev].szParentTag);
		if (nFind >= 0)
		{
			strcpy(m_CompensatorArray[nDev].szSub, m_VoltageLevelArray[nFind].szSub);
			strcpy(m_CompensatorArray[nDev].szVolt, m_VoltageLevelArray[nFind].szName);
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_CompensatorArray[nDev].szParentTag);
			if (nFind >= 0)
			{
				strcpy(m_CompensatorArray[nDev].szSub, m_BayArray[nFind].szSub);
				strcpy(m_CompensatorArray[nDev].szVolt, m_BayArray[nFind].szVolt);
			}
			else
				Log(g_lpszLogFile, "���� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_CompensatorArray[nDev].szResourceID, m_CompensatorArray[nDev].szParentTag);
		}
		if (strlen(m_CompensatorArray[nDev].szBaseVoltageTag) > 0)
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_CompensatorArray[nDev].szBaseVoltageTag);
			if (nFind >= 0)
			{
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_CompensatorArray[nDev].szVolt);
			}
		}
	}
	//	Breaker��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		if (m_BreakerArray[nDev].strParentTag.empty())
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_BreakerArray[nDev].strParentTag.c_str());
		if (nFind >= 0)
		{
			m_BreakerArray[nDev].strSub=m_VoltageLevelArray[nFind].szSub;
			m_BreakerArray[nDev].strVolt=m_VoltageLevelArray[nFind].szName;
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_BreakerArray[nDev].strParentTag.c_str());
			if (nFind >= 0)
			{
				m_BreakerArray[nDev].strSub=m_BayArray[nFind].szSub;
				m_BreakerArray[nDev].strVolt=m_BayArray[nFind].szVolt;
			}
			else
				Log(g_lpszLogFile, "��·�� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_BreakerArray[nDev].strResourceID.c_str(), m_BreakerArray[nDev].strParentTag.c_str());
		}
		if (!m_BreakerArray[nDev].strBaseVoltageTag.empty())
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_BreakerArray[nDev].strBaseVoltageTag.c_str());
			if (nFind >= 0)
			{
				strcpy(szBuf, m_BreakerArray[nDev].strVolt.c_str());
				//NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, m_BreakerArray[nDev].strVolt.c_str());
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, szBuf);
				m_BreakerArray[nDev].strVolt=szBuf;
			}
		}
	}
	//	Disconnector��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		if (m_DisconnectorArray[nDev].strParentTag.empty())
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_DisconnectorArray[nDev].strParentTag.c_str());
		if (nFind >= 0)
		{
			m_DisconnectorArray[nDev].strSub =m_VoltageLevelArray[nFind].szSub;
			m_DisconnectorArray[nDev].strVolt=m_VoltageLevelArray[nFind].szName;
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_DisconnectorArray[nDev].strParentTag.c_str());
			if (nFind >= 0)
			{
				m_DisconnectorArray[nDev].strSub =m_BayArray[nFind].szSub;
				m_DisconnectorArray[nDev].strVolt=m_BayArray[nFind].szVolt;
			}
			else
				Log(g_lpszLogFile, "���뿪�� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_DisconnectorArray[nDev].strResourceID.c_str(), m_DisconnectorArray[nDev].strParentTag.c_str());
		}
		if (!m_DisconnectorArray[nDev].strBaseVoltageTag.empty())
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_DisconnectorArray[nDev].strBaseVoltageTag.c_str());
			if (nFind >= 0)
			{
				strcpy(szBuf, m_DisconnectorArray[nDev].strVolt.c_str());
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, szBuf);
				m_DisconnectorArray[nDev].strVolt=szBuf;
			}
		}
	}
	//	GroundDisconnector��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		if (m_GroundDisconnectorArray[nDev].strParentTag.empty())
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_GroundDisconnectorArray[nDev].strParentTag.c_str());
		if (nFind >= 0)
		{
			m_GroundDisconnectorArray[nDev].strSub =m_VoltageLevelArray[nFind].szSub ;
			m_GroundDisconnectorArray[nDev].strVolt=m_VoltageLevelArray[nFind].szName;
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_GroundDisconnectorArray[nDev].strParentTag.c_str());
			if (nFind >= 0)
			{
				m_GroundDisconnectorArray[nDev].strSub=m_BayArray[nFind].szSub;
				m_GroundDisconnectorArray[nDev].strVolt=m_BayArray[nFind].szVolt;
			}
			else
				Log(g_lpszLogFile, "�ӵص�բ ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_GroundDisconnectorArray[nDev].strResourceID.c_str(), m_GroundDisconnectorArray[nDev].strParentTag.c_str());
		}
		if (!m_GroundDisconnectorArray[nDev].strBaseVoltageTag.empty())
		{
			nFind=findBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1, m_GroundDisconnectorArray[nDev].strBaseVoltageTag.c_str());
			if (nFind >= 0)
			{
				strcpy(szBuf, m_GroundDisconnectorArray[nDev].strVolt.c_str());
				NomalizeVoltageLevelName(m_BaseVoltageArray[nFind].fNominalVoltage, szBuf);
				m_GroundDisconnectorArray[nDev].strVolt=szBuf;
			}
		}
	}
	//	ConnectivityNode��ȷ��Substation��VoltageLevel
	for (nDev=0; nDev<(int)m_ConnectivityNodeArray.size(); nDev++)
	{
		if (m_ConnectivityNodeArray[nDev].strParentTag.empty())
			continue;

		nFind=findVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1, m_ConnectivityNodeArray[nDev].strParentTag.c_str());
		if (nFind >= 0)
		{
			m_ConnectivityNodeArray[nDev].strSub =m_VoltageLevelArray[nFind].szSub ;
			m_ConnectivityNodeArray[nDev].strVolt=m_VoltageLevelArray[nFind].szName;
		}
		else
		{
			nFind=findBayByResID(0, (int)m_BayArray.size()-1, m_ConnectivityNodeArray[nDev].strParentTag.c_str());
			if (nFind >= 0)
			{
				m_ConnectivityNodeArray[nDev].strSub =m_BayArray[nFind].szSub;
				m_ConnectivityNodeArray[nDev].strVolt=m_BayArray[nFind].szVolt;
			}
			else
				Log(g_lpszLogFile, "�ڵ� ResID=%s �е�ѹ�ȼ���Ϣ�����Ҳ�����ѹ�ȼ� VoltRes=%s\n", m_ConnectivityNodeArray[nDev].strResourceID.c_str(), m_ConnectivityNodeArray[nDev].strParentTag.c_str());
		}
	}
}


void	CCIMData::fillConnetivityByTerminal(const int bNameByDesp)
{
	register int	i;
	int		nDev, nTem, nWind;
	int		nTerminals;

	//	�˵���ȷ���ڵ�Ͷ˵�ĳ�վ�͵�ѹ
	for (i=0; i<(int)m_TerminalArray.size(); i++)
	{
		if (m_TerminalArray[i].strNodeTag.empty())
			continue;

		m_TerminalArray[i].strNode.clear();
		nTem=findConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1, m_TerminalArray[i].strNodeTag.c_str());
		if (nTem >= 0)
		{
			m_TerminalArray[i].strSub =m_ConnectivityNodeArray[nTem].strSub ;
			m_TerminalArray[i].strVolt=m_ConnectivityNodeArray[nTem].strVolt;
			m_TerminalArray[i].strNode=m_ConnectivityNodeArray[nTem].strName;
		}
		else
		{
			Log(g_lpszLogFile, "�˵�ڵ���Ϣ TermRes=%s �����Ҳ����ڵ� NodeRes=%s\n", m_TerminalArray[i].strResourceID.c_str(), m_TerminalArray[i].strNodeTag.c_str());
		}
	}

	//	ACLineSegment������·�˵�������·��վ���ڵ㡣ͬʱΪ��·�˵㸳ֵ��·���ơ�
	for (nDev=0; nDev<(int)m_ACLineSegmentArray.size(); nDev++)
	{
		//memset(m_ACLineSegmentArray[nDev].szNode[0], 0, MDB_CHARLEN_SHORT);
		//memset(m_ACLineSegmentArray[nDev].szNode[1], 0, MDB_CHARLEN_SHORT);

		nTerminals=0;
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_ACLineSegmentArray[nDev].szResourceID);
 		if (nTem >= 0)
 		{
 			strcpy(m_ACLineSegmentArray[nDev].szTerminalTag[0], m_TerminalArray[nTem].strResourceID.c_str());
 			if (!m_TerminalArray[nTem].strSub.empty())	strcpy(m_ACLineSegmentArray[nDev].szSub[0], m_TerminalArray[nTem].strSub.c_str());
 			if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_ACLineSegmentArray[nDev].szVolt[0], m_TerminalArray[nTem].strVolt.c_str());
 			if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_ACLineSegmentArray[nDev].szNode[0], m_TerminalArray[nTem].strNode.c_str());
 
 			m_TerminalArray[nTem].strEquimentType="ACLineSegment";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_ACLineSegmentArray[nDev].szDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_ACLineSegmentArray[nDev].szName;
 		}
 		else
 		{
 			Log(g_lpszLogFile, "��·�˵�1��Ϣ Term=%s �����Ҳ��������豸\n", m_ACLineSegmentArray[nDev].szResourceID);
 		}
 
 		nTerminals=nTem;
 		nTem=findTerminalByParentTag(0, (int)nTerminals-1, m_ACLineSegmentArray[nDev].szResourceID);
 		if (nTem < 0)
			nTem=findTerminalByParentTag(nTerminals+1, (int)m_TerminalArray.size()-1, m_ACLineSegmentArray[nDev].szResourceID);
 		if (nTem >= 0)
 		{
 			strcpy(m_ACLineSegmentArray[nDev].szTerminalTag[1], m_TerminalArray[nTem].strResourceID.c_str());
 			if (!m_TerminalArray[nTem].strSub.empty())	strcpy(m_ACLineSegmentArray[nDev].szSub[1], m_TerminalArray[nTem].strSub.c_str());
 			if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_ACLineSegmentArray[nDev].szVolt[1], m_TerminalArray[nTem].strVolt.c_str());
 			if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_ACLineSegmentArray[nDev].szNode[1], m_TerminalArray[nTem].strNode.c_str());
 
 			m_TerminalArray[nTem].strEquimentType="ACLineSegment";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_ACLineSegmentArray[nDev].szDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_ACLineSegmentArray[nDev].szName;
 		}
 		else
 		{
 			Log(g_lpszLogFile, "��·�˵�2��Ϣ Term=%s �����Ҳ��������豸\n", m_ACLineSegmentArray[nDev].szResourceID);
 		}
	}

	//	DCLineSegment������·�˵�������·��վ���ڵ㡣ͬʱΪ��·�˵㸳ֵ��·���ơ�
	for (nDev=0; nDev<(int)m_DCLineSegmentArray.size(); nDev++)
	{
		//memset(m_DCLineSegmentArray[nDev].szNode[0], 0, MDB_CHARLEN_SHORT);
		//memset(m_DCLineSegmentArray[nDev].szNode[1], 0, MDB_CHARLEN_SHORT);

		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_DCLineSegmentArray[nDev].szResourceID);
		if (nTem >= 0)
		{
			strcpy(m_DCLineSegmentArray[nDev].szTerminalTag[0], m_TerminalArray[nTem].strResourceID.c_str());
			/*if (!m_TerminalArray[nTem].strSub.empty())*/	strcpy(m_DCLineSegmentArray[nDev].szSub[0], m_TerminalArray[nTem].strSub.c_str());
			/*if (!m_TerminalArray[nTem].strVolt.empty())*/	strcpy(m_DCLineSegmentArray[nDev].szVolt[0], m_TerminalArray[nTem].strVolt.c_str());
			/*if (!m_TerminalArray[nTem].strNode.empty())*/	strcpy(m_DCLineSegmentArray[nDev].szNode[0], m_TerminalArray[nTem].strNode.c_str());
		}
		else
		{
			Log(g_lpszLogFile, "ֱ����·�˵�1��Ϣ Term=%s �����Ҳ��������豸\n", m_DCLineSegmentArray[nDev].szResourceID);
		}

		nTerminals=nTem;
		nTem=findTerminalByParentTag(0, nTerminals-1, m_DCLineSegmentArray[nDev].szResourceID);
		if (nTem < 0)
			nTem=findTerminalByParentTag(nTerminals+1, (int)m_TerminalArray.size()-1, m_DCLineSegmentArray[nDev].szResourceID);
		if (nTem >= 0)
		{
			strcpy(m_DCLineSegmentArray[nDev].szTerminalTag[1], m_TerminalArray[nTem].strResourceID.c_str());
			/*if (!m_TerminalArray[nTem].strSub.empty())*/	strcpy(m_DCLineSegmentArray[nDev].szSub[1], m_TerminalArray[nTem].strSub.c_str());
			/*if (!m_TerminalArray[nTem].strVolt.empty())*/	strcpy(m_DCLineSegmentArray[nDev].szVolt[1], m_TerminalArray[nTem].strVolt.c_str());
			/*if (!m_TerminalArray[nTem].strNode.empty())*/	strcpy(m_DCLineSegmentArray[nDev].szNode[1], m_TerminalArray[nTem].strNode.c_str());
		}
	}
	//	RectifierInverter������·�˵�������·��վ���ڵ㡣ͬʱΪ��·�˵㸳ֵ��·���ơ�
	for (nDev=0; nDev<(int)m_RectifierInverterArray.size(); nDev++)
	{
		//memset(m_RectifierInverterArray[nDev].szNode[0], 0, MDB_CHARLEN_SHORT);
		//memset(m_RectifierInverterArray[nDev].szNode[1], 0, MDB_CHARLEN_SHORT);
		//memset(m_RectifierInverterArray[nDev].szNode[2], 0, MDB_CHARLEN_SHORT);

		nTerminals=0;
		for (nTem=0; nTem<(int)m_TerminalArray.size(); nTem++)
		{
			if (strcmp(m_RectifierInverterArray[nDev].szResourceID, m_TerminalArray[nTem].strParentTag.c_str()) == 0)
			{
				if (nTerminals == 0)
				{
					strcpy(m_RectifierInverterArray[nDev].szTerminalTag[nTerminals], m_TerminalArray[nTem].strResourceID.c_str());
					/*if (!m_TerminalArray[nTem].strVolt.empty())*/	strcpy(m_RectifierInverterArray[nDev].szVolt[nTerminals], m_TerminalArray[nTem].strVolt.c_str());
					/*if (!m_TerminalArray[nTem].strNode.empty())*/	strcpy(m_RectifierInverterArray[nDev].szNode[nTerminals], m_TerminalArray[nTem].strNode.c_str());
				}
				else if (nTerminals == 1)
				{
					strcpy(m_RectifierInverterArray[nDev].szTerminalTag[nTerminals], m_TerminalArray[nTem].strResourceID.c_str());
					/*if (!m_TerminalArray[nTem].strVolt.empty())*/	strcpy(m_RectifierInverterArray[nDev].szVolt[nTerminals], m_TerminalArray[nTem].strVolt.c_str());
					/*if (!m_TerminalArray[nTem].strNode.empty())*/	strcpy(m_RectifierInverterArray[nDev].szNode[nTerminals], m_TerminalArray[nTem].strNode.c_str());
				}
				else if (nTerminals == 2)
				{
					strcpy(m_RectifierInverterArray[nDev].szTerminalTag[nTerminals], m_TerminalArray[nTem].strResourceID.c_str());
					/*if (!m_TerminalArray[nTem].strVolt.empty())*/	strcpy(m_RectifierInverterArray[nDev].szVolt[nTerminals], m_TerminalArray[nTem].strVolt.c_str());
					/*if (!m_TerminalArray[nTem].strNode.empty())*/	strcpy(m_RectifierInverterArray[nDev].szNode[nTerminals], m_TerminalArray[nTem].strNode.c_str());
				}
				strcpy(m_RectifierInverterArray[nDev].szSub, m_TerminalArray[nTem].strSub.c_str());

				m_TerminalArray[nTem].strEquimentType="RectifierInverter";
				if (bNameByDesp)
					m_TerminalArray[nTem].strEquimentName=m_RectifierInverterArray[nDev].szDesp;
				else
					m_TerminalArray[nTem].strEquimentName=m_RectifierInverterArray[nDev].szName;

				nTerminals++;
			}
		}
	}

	//	TransformerWinding
	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (m_PowerTransformerArray[nDev].nWindNum <= 0)
		{
			Log(g_lpszLogFile, "PowerTransformer WindNum(%d) Error : %s-%s\n", 
				m_PowerTransformerArray[nDev].nWindNum, 
				m_PowerTransformerArray[nDev].szSub, 
				m_PowerTransformerArray[nDev].szName);
			continue;
		}
		if (m_PowerTransformerArray[nDev].nWindNum >= 3)
		{
			for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
			{
				nWind=m_PowerTransformerArray[nDev].nWindArray[i];
				//memset(m_TransformerWindingArray[nWind].szNode, 0, MDB_CHARLEN_SHORT);
				nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_TransformerWindingArray[nWind].szResourceID);
				if (nTem >= 0)
				{
					if (!m_TerminalArray[nTem].strSub.empty())	strcpy(m_TransformerWindingArray[nWind].szSub, m_TerminalArray[nTem].strSub.c_str());
					if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_TransformerWindingArray[nWind].szVolt, m_TerminalArray[nTem].strVolt.c_str());
					if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_TransformerWindingArray[nWind].szNode, m_TerminalArray[nTem].strNode.c_str());
					strcpy(m_TransformerWindingArray[nWind].szTerminalTag, m_TerminalArray[nTem].strResourceID.c_str());
					m_TerminalArray[nTem].strEquimentType="TransformerWinding";
					if (bNameByDesp)
						m_TerminalArray[nTem].strEquimentName=m_TransformerWindingArray[nWind].szDesp;
					else
						m_TerminalArray[nTem].strEquimentName=m_TransformerWindingArray[nWind].szName;
				}
				else
				{
					Log(g_lpszLogFile, "������ѹ���˵�%d��Ϣ Term=%s �����Ҳ��������豸\n", i+1, m_TransformerWindingArray[nWind].szResourceID);
				}
			}
		}
		else
		{
			nWind=m_PowerTransformerArray[nDev].nWindArray[0];
			//memset(m_TransformerWindingArray[nWind].szNode, 0, MDB_CHARLEN_SHORT);
			nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_TransformerWindingArray[nWind].szResourceID);
			if (nTem >= 0)
			{
				if (!m_TerminalArray[nTem].strSub.empty())	strcpy(m_TransformerWindingArray[nWind].szSub, m_TerminalArray[nTem].strSub.c_str());
				if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_TransformerWindingArray[nWind].szVolt, m_TerminalArray[nTem].strVolt.c_str());
				if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_TransformerWindingArray[nWind].szNode, m_TerminalArray[nTem].strNode.c_str());
				strcpy(m_TransformerWindingArray[nWind].szTerminalTag, m_TerminalArray[nTem].strResourceID.c_str());
				m_TerminalArray[nTem].strEquimentType="TransformerWinding";
				if (bNameByDesp)
					m_TerminalArray[nTem].strEquimentName=m_PowerTransformerArray[nDev].szDesp;
				else
					m_TerminalArray[nTem].strEquimentName=m_PowerTransformerArray[nDev].szName;
			}
			else
			{
				Log(g_lpszLogFile, "������ѹ���˵�1��Ϣ Term=%s �����Ҳ��������豸\n", m_TransformerWindingArray[nWind].szResourceID);
			}

			nWind=m_PowerTransformerArray[nDev].nWindArray[1];
			//memset(m_TransformerWindingArray[nWind].szNode, 0, MDB_CHARLEN_SHORT);

			nTerminals=nTem;
			nTem=findTerminalByParentTag(0, nTerminals-1, m_TransformerWindingArray[nWind].szResourceID);
			if (nTem < 0)
				nTem=findTerminalByParentTag(nTerminals+1, (int)m_TerminalArray.size()-1, m_TransformerWindingArray[nWind].szResourceID);
 			if (nTem >= 0)
 			{
				if (!m_TerminalArray[nTem].strSub.empty())	strcpy(m_TransformerWindingArray[nWind].szSub, m_TerminalArray[nTem].strSub.c_str());
				if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_TransformerWindingArray[nWind].szVolt, m_TerminalArray[nTem].strVolt.c_str());
 				if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_TransformerWindingArray[nWind].szNode, m_TerminalArray[nTem].strNode.c_str());
 				strcpy(m_TransformerWindingArray[nWind].szTerminalTag, m_TerminalArray[nTem].strResourceID.c_str());
 				m_TerminalArray[nTem].strEquimentType="TransformerWinding";
				if (bNameByDesp)
					m_TerminalArray[nTem].strEquimentName=m_PowerTransformerArray[nDev].szDesp;
				else
					m_TerminalArray[nTem].strEquimentName=m_PowerTransformerArray[nDev].szName;
 			}
			else
			{
				Log(g_lpszLogFile, "������ѹ���˵�2��Ϣ Term=%s �����Ҳ��������豸\n", m_TransformerWindingArray[nWind].szResourceID);
			}
		}
	}

	for (nDev=0; nDev<(int)m_BusbarSectionArray.size(); nDev++)
	{
		//memset(m_BusbarSectionArray[nDev].szNode, 0, MDB_CHARLEN_SHORT);
 		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_BusbarSectionArray[nDev].szResourceID);
 		if (nTem >= 0)
 		{
			if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_BusbarSectionArray[nDev].szVolt, m_TerminalArray[nTem].strVolt.c_str());
 			if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_BusbarSectionArray[nDev].szNode, m_TerminalArray[nTem].strNode.c_str());
 			strcpy(m_BusbarSectionArray[nDev].szTerminalTag, m_TerminalArray[nTem].strResourceID.c_str());
 			m_TerminalArray[nTem].strEquimentType="BusbarSection";
			if (bNameByDesp)
 				m_TerminalArray[nTem].strEquimentName=m_BusbarSectionArray[nDev].szDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_BusbarSectionArray[nDev].szName;
 		}
		else
		{
			Log(g_lpszLogFile, "ĸ�߶˵���Ϣ Term=%s �����Ҳ��������豸\n", m_BusbarSectionArray[nDev].szResourceID);
		}
	}

	//	Breaker
	for (nDev=0; nDev<(int)m_BreakerArray.size(); nDev++)
	{
		//memset(m_BreakerArray[nDev].szNode[0], 0, MDB_CHARLEN_SHORT);
		//memset(m_BreakerArray[nDev].szNode[1], 0, MDB_CHARLEN_SHORT);
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_BreakerArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	m_BreakerArray[nDev].strVolt = m_TerminalArray[nTem].strVolt;
			if (!m_TerminalArray[nTem].strNode.empty())	m_BreakerArray[nDev].strNode[0] = m_TerminalArray[nTem].strNode;
			m_BreakerArray[nDev].strTerminalTag[0]=m_TerminalArray[nTem].strResourceID;
			m_TerminalArray[nTem].strEquimentType="Breaker";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_BreakerArray[nDev].strDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_BreakerArray[nDev].strName;
		}
		else
		{
			Log(g_lpszLogFile, "���ض˵�1��Ϣ Term=%s �����Ҳ��������豸\n", m_BreakerArray[nDev].strResourceID.c_str());
		}

		nTerminals=nTem;
		nTem=findTerminalByParentTag(0, nTerminals-1, m_BreakerArray[nDev].strResourceID.c_str());
		if (nTem < 0)
			nTem=findTerminalByParentTag(nTerminals+1, (int)m_TerminalArray.size()-1, m_BreakerArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	m_BreakerArray[nDev].strVolt=m_TerminalArray[nTem].strVolt;
			if (!m_TerminalArray[nTem].strNode.empty())	m_BreakerArray[nDev].strNode[1]=m_TerminalArray[nTem].strNode;
			m_BreakerArray[nDev].strTerminalTag[1]=m_TerminalArray[nTem].strResourceID;
			m_TerminalArray[nTem].strEquimentType="Breaker";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_BreakerArray[nDev].strDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_BreakerArray[nDev].strName;
		}
		else
		{
			Log(g_lpszLogFile, "���ض˵�2��Ϣ Term=%s �����Ҳ��������豸\n", m_BreakerArray[nDev].strResourceID.c_str());
		}
	}

	//	Disconnector
	for (nDev=0; nDev<(int)m_DisconnectorArray.size(); nDev++)
	{
		//memset(m_DisconnectorArray[nDev].szNode[0], 0, MDB_CHARLEN_SHORT);
		//memset(m_DisconnectorArray[nDev].szNode[1], 0, MDB_CHARLEN_SHORT);
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_DisconnectorArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	m_DisconnectorArray[nDev].strVolt=m_TerminalArray[nTem].strVolt;
			if (!m_TerminalArray[nTem].strNode.empty())	m_DisconnectorArray[nDev].strNode[0]=m_TerminalArray[nTem].strNode;
			m_DisconnectorArray[nDev].strTerminalTag[0]=m_TerminalArray[nTem].strResourceID;
			m_TerminalArray[nTem].strEquimentType="Disconnector";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_DisconnectorArray[nDev].strDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_DisconnectorArray[nDev].strName;
		}
		else
		{
			Log(g_lpszLogFile, "��բ�˵�1��Ϣ Term=%s �����Ҳ��������豸\n", m_DisconnectorArray[nDev].strResourceID.c_str());
		}

		nTerminals=nTem;
		nTem=findTerminalByParentTag(0, nTerminals-1, m_DisconnectorArray[nDev].strResourceID.c_str());
		if (nTem < 0)
			nTem=findTerminalByParentTag(nTerminals+1, (int)m_TerminalArray.size()-1, m_DisconnectorArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	m_DisconnectorArray[nDev].strVolt=m_TerminalArray[nTem].strVolt;
			if (!m_TerminalArray[nTem].strNode.empty())	m_DisconnectorArray[nDev].strNode[1]=m_TerminalArray[nTem].strNode;
			m_DisconnectorArray[nDev].strTerminalTag[1]=m_TerminalArray[nTem].strResourceID;
			m_TerminalArray[nTem].strEquimentType="Disconnector";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_DisconnectorArray[nDev].strDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_DisconnectorArray[nDev].strName;
		}
		else
		{
			Log(g_lpszLogFile, "��բ�˵�2��Ϣ Term=%s �����Ҳ��������豸\n", m_DisconnectorArray[nDev].strResourceID.c_str());
		}
	}

	//	GroundDisconnector
	for (nDev=0; nDev<(int)m_GroundDisconnectorArray.size(); nDev++)
	{
		//memset(m_GroundDisconnectorArray[nDev].szNode, 0, MDB_CHARLEN_SHORT);
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_GroundDisconnectorArray[nDev].strResourceID.c_str());
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	m_GroundDisconnectorArray[nDev].strVolt=m_TerminalArray[nTem].strVolt;
			if (!m_TerminalArray[nTem].strNode.empty())	m_GroundDisconnectorArray[nDev].strNode=m_TerminalArray[nTem].strNode;
			m_GroundDisconnectorArray[nDev].strTerminalTag=m_TerminalArray[nTem].strResourceID;
			m_TerminalArray[nTem].strEquimentType="GroundDisconnector";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_GroundDisconnectorArray[nDev].strDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_GroundDisconnectorArray[nDev].strName;
		}
		else
		{
			Log(g_lpszLogFile, "�ص��˵���Ϣ Term=%s �����Ҳ��������豸\n", m_GroundDisconnectorArray[nDev].strResourceID.c_str());
		}
	}

	//	SynchronousMachine
	for (nDev=0; nDev<(int)m_SynchronousMachineArray.size(); nDev++)
	{
		//memset(m_SynchronousMachineArray[nDev].szNode, 0, MDB_CHARLEN_SHORT);
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_SynchronousMachineArray[nDev].szResourceID);
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_SynchronousMachineArray[nDev].szVolt, m_TerminalArray[nTem].strVolt.c_str());
			if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_SynchronousMachineArray[nDev].szNode, m_TerminalArray[nTem].strNode.c_str());
			strcpy(m_SynchronousMachineArray[nDev].szTerminalTag, m_TerminalArray[nTem].strResourceID.c_str());
			m_TerminalArray[nTem].strEquimentType="SynchronousMachine";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_SynchronousMachineArray[nDev].szDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_SynchronousMachineArray[nDev].szName;
		}
		else
		{
			Log(g_lpszLogFile, "������˵���Ϣ Term=%s �����Ҳ��������豸\n", m_SynchronousMachineArray[nDev].szResourceID);
		}

		m_SynchronousMachineArray[nDev].nUnitType=0;
		for (nTem=0; nTem<(int)m_ThermalGeneratingUnitArray.size(); nTem++)
		{
			if (strcmp(m_SynchronousMachineArray[nDev].szUnitTag, m_ThermalGeneratingUnitArray[nTem].szResourceID) == 0)
			{
				m_SynchronousMachineArray[nDev].fP=m_ThermalGeneratingUnitArray[nTem].fInitP;
				m_SynchronousMachineArray[nDev].fMaxP=m_ThermalGeneratingUnitArray[nTem].fMaxP;
				m_SynchronousMachineArray[nDev].fMinP=m_ThermalGeneratingUnitArray[nTem].fMinP;
				m_SynchronousMachineArray[nDev].nUnitType=PGEnumSynchronousMachine_Type_Thermal;
				break;
			}
		}
		for (nTem=0; nTem<(int)m_HydroGeneratingUnitArray.size(); nTem++)
		{
			if (strcmp(m_SynchronousMachineArray[nDev].szUnitTag, m_HydroGeneratingUnitArray[nTem].szResourceID) == 0)
			{
				m_SynchronousMachineArray[nDev].fP=m_HydroGeneratingUnitArray[nTem].fInitP;
				m_SynchronousMachineArray[nDev].fMaxP=m_HydroGeneratingUnitArray[nTem].fMaxP;
				m_SynchronousMachineArray[nDev].fMinP=m_HydroGeneratingUnitArray[nTem].fMinP;
				m_SynchronousMachineArray[nDev].nUnitType=PGEnumSynchronousMachine_Type_Hydro;
				break;
			}
		}
	}

	//	EnergyConsumer
	for (nDev=0; nDev<(int)m_EnergyConsumerArray.size(); nDev++)
	{
		//memset(m_EnergyConsumerArray[nDev].szNode, 0, MDB_CHARLEN_SHORT);
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_EnergyConsumerArray[nDev].szResourceID);
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_EnergyConsumerArray[nDev].szVolt, m_TerminalArray[nTem].strVolt.c_str());
			if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_EnergyConsumerArray[nDev].szNode, m_TerminalArray[nTem].strNode.c_str());
			strcpy(m_EnergyConsumerArray[nDev].szTerminalTag, m_TerminalArray[nTem].strResourceID.c_str());
			m_TerminalArray[nTem].strEquimentType="EnergyConsumer";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_EnergyConsumerArray[nDev].szDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_EnergyConsumerArray[nDev].szName;
		}
		else
		{
			Log(g_lpszLogFile, "���ɶ˵���Ϣ Term=%s �����Ҳ��������豸\n", m_EnergyConsumerArray[nDev].szResourceID);
		}
	}

	//	Compensator
	for (nDev=0; nDev<(int)m_CompensatorArray.size(); nDev++)
	{
		//memset(m_CompensatorArray[nDev].szNode1, 0, MDB_CHARLEN_SHORT);
		//memset(m_CompensatorArray[nDev].szNode2, 0, MDB_CHARLEN_SHORT);
		nTem=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_CompensatorArray[nDev].szResourceID);
		if (nTem >= 0)
		{
			if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_CompensatorArray[nDev].szVolt, m_TerminalArray[nTem].strVolt.c_str());
			if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_CompensatorArray[nDev].szTerminalTag1, m_TerminalArray[nTem].strResourceID.c_str());
			strcpy(m_CompensatorArray[nDev].szNode1, m_TerminalArray[nTem].strNode.c_str());
			m_TerminalArray[nTem].strEquimentType="Compensator";
			if (bNameByDesp)
				m_TerminalArray[nTem].strEquimentName=m_CompensatorArray[nDev].szDesp;
			else
				m_TerminalArray[nTem].strEquimentName=m_CompensatorArray[nDev].szName;
		}
		else
		{
			Log(g_lpszLogFile, "�����˵�1��Ϣ Term=%s �����Ҳ��������豸\n", m_CompensatorArray[nDev].szResourceID);
		}

		if (m_CompensatorArray[nDev].bSeries)
		{
			nTerminals=nTem;
			nTem=findTerminalByParentTag(0, (int)nTerminals-1, m_CompensatorArray[nDev].szResourceID);
			if (nTem < 0)
				nTem=findTerminalByParentTag(nTerminals+1, (int)m_TerminalArray.size()-1, m_CompensatorArray[nDev].szResourceID);
			if (nTem >= 0)
			{
				if (!m_TerminalArray[nTem].strVolt.empty())	strcpy(m_CompensatorArray[nDev].szVolt, m_TerminalArray[nTem].strVolt.c_str());
				if (!m_TerminalArray[nTem].strNode.empty())	strcpy(m_CompensatorArray[nDev].szNode2, m_TerminalArray[nTem].strNode.c_str());
				strcpy(m_CompensatorArray[nDev].szTerminalTag2, m_TerminalArray[nTem].strResourceID.c_str());
				m_TerminalArray[nTem].strEquimentType="Compensator";
				if (bNameByDesp)
					m_TerminalArray[nTem].strEquimentName=m_CompensatorArray[nDev].szDesp;
				else
					m_TerminalArray[nTem].strEquimentName=m_CompensatorArray[nDev].szName;
			}
			else
			{
				Log(g_lpszLogFile, "�����˵�2��Ϣ Term=%s �����Ҳ��������豸\n", m_CompensatorArray[nDev].szResourceID);
			}
		}
	}
}

void	CCIMData::TransFormerPostProc(const int bNameByDesp)
{
	register int	i, j;
	int				nDev, nFind;
	int				nWind, nWindH, nWindL;

	//����ѹ����ѹ����ֹ���ֶ˵��ڵ�����ڵ��Թ���������
	//for (nDev=0; nDev<m_TransformerWindingArray.size(); nDev++)
	//	{
	//	if (m_TransformerWindingArray[nDev].fRatedKV > 0)
	//		{
	//		if (m_TransformerWindingArray[nDev].fVolt < 0.8*m_TransformerWindingArray[nDev].fRatedKV ||
	//			m_TransformerWindingArray[nDev].fVolt > 1.2*m_TransformerWindingArray[nDev].fRatedKV)
	//			{
	//			sprintf(szMesg, "��ѹ����ѹ%s����%.2f (%.2f)", m_TransformerWindingArray[nDev].szName, 
	//					m_TransformerWindingArray[nDev].fVolt, m_TransformerWindingArray[nDev].fRatedKV);
	//			m_TransformerWindingArray[nDev].fVolt=m_TransformerWindingArray[nDev].fRatedKV;
	//			}
	//		}
	//	}


	for (nDev=0; nDev<(int)m_TransformerWindingArray.size(); nDev++)
	{
		if (strlen(m_TransformerWindingArray[nDev].szTapChangerTag) > 0)
			continue;

		nFind=findTapChangerByTransformerWindingResID(0, (int)m_TapChangerArray.size()-1, m_TransformerWindingArray[nDev].szResourceID);
		if (nFind >= 0)
			strcpy(m_TransformerWindingArray[nDev].szTapChangerTag, m_TapChangerArray[nFind].szResourceID);
	}

	for (nDev=0; nDev<(int)m_TransformerWindingArray.size(); nDev++)
	{
		if (strlen(m_TransformerWindingArray[nDev].szTapChangerTag) <= 0)
			continue;

		for (i=0; i<(int)m_TapChangerArray.size(); i++)
		{
			if (stricmp(m_TransformerWindingArray[nDev].szTapChangerTag, m_TapChangerArray[i].szResourceID) == 0)
			{
				strcpy(m_TransformerWindingArray[nDev].szTapChanger, m_TapChangerArray[i].szName);
				break;
			}
		}
	}

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		m_PowerTransformerArray[nDev].nWindNum=0;
		for (i=0; i<MaxPowerTransformerWindNum; i++)
			m_PowerTransformerArray[nDev].nWindArray[i]=0;
	}
	for (nDev=0; nDev<(int)m_TransformerWindingArray.size(); nDev++)
	{
		nFind=findPowerTransformerByResID(0, (int)m_PowerTransformerArray.size()-1, m_TransformerWindingArray[nDev].szPowerTransformerTag);
		if (nFind >= 0 && m_PowerTransformerArray[nFind].nWindNum < MaxPowerTransformerWindNum)
		{
			m_PowerTransformerArray[nFind].nWindArray[m_PowerTransformerArray[nFind].nWindNum++]=nDev;
			if (bNameByDesp)
				strcpy(m_TransformerWindingArray[nDev].szPowerTransformer, m_PowerTransformerArray[nFind].szDesp);
			else
				strcpy(m_TransformerWindingArray[nDev].szPowerTransformer, m_PowerTransformerArray[nFind].szName);
		}
	}

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		//	����ѹ�ɸߵ���������
		for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
		{
			nWindH=m_PowerTransformerArray[nDev].nWindArray[i];
			m_TransformerWindingArray[nWindH].nTransformerWindingType=m_PowerTransformerArray[nDev].nWindNum;
			for (j=i+1; j<m_PowerTransformerArray[nDev].nWindNum; j++)
			{
				nWindH=m_PowerTransformerArray[nDev].nWindArray[i];
				nWindL=m_PowerTransformerArray[nDev].nWindArray[j];
				if (m_TransformerWindingArray[nWindH].fRatedKV < m_TransformerWindingArray[nWindL].fRatedKV)
				{
					nWind=m_PowerTransformerArray[nDev].nWindArray[i];
					m_PowerTransformerArray[nDev].nWindArray[i]=m_PowerTransformerArray[nDev].nWindArray[j];
					m_PowerTransformerArray[nDev].nWindArray[j]=nWind;
				}
			}
		}
	}

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (m_PowerTransformerArray[nDev].nWindNum != 2 && m_PowerTransformerArray[nDev].nWindNum != 3)
		{
			// PrintMessage(szMesg, "��ѹ��%s���󣺱�ѹ���Ȳ���������Ҳ����������", m_PowerTransformerArray[nDev].szName);
		}
	}
}

void	CCIMData::MeasurementPostProc(const int bNameByDesp)
{
	register int	i, j;
	int		bFind, nFind;
	//	clock_t	dBeg, dEnd;
	//	int		nDur;

	//	����ֵ����ȷ������Դ
	for (i=0; i<(int)m_MeasurementValueArray.size(); i++)
	{
		for (j=0; j<(int)m_MeasurementSourceArray.size(); j++)
		{
			if (strcmp(m_MeasurementValueArray[i].strMeasurementSourceTag.c_str(), m_MeasurementSourceArray[j].szResourceID) == 0)
			{
				m_MeasurementValueArray[i].strMeasurementSource=m_MeasurementSourceArray[j].szName;
				break;
			}
		}
	}

	//	�������ȷ����������
	for (i=0; i<(int)m_MeasurementArray.size(); i++)
	{
		nFind=findMeasurementTypeByResID(0, (int)m_MeasurementTypeArray.size()-1, m_MeasurementArray[i].strMeasurementTypeTag.c_str());
		if (nFind >= 0)
			m_MeasurementArray[i].strMeasurementType=m_MeasurementTypeArray[nFind].szName;
	}
	for (i=0; i<(int)m_AnalogArray.size(); i++)
	{
		nFind=findMeasurementTypeByResID(0, (int)m_MeasurementTypeArray.size()-1, m_AnalogArray[i].strMeasurementTypeTag.c_str());
		if (nFind >= 0)
			m_AnalogArray[i].strMeasurementType=m_MeasurementTypeArray[nFind].szName;
	}
	for (i=0; i<(int)m_DiscreteArray.size(); i++)
	{
		nFind=findMeasurementTypeByResID(0, (int)m_MeasurementTypeArray.size()-1, m_DiscreteArray[i].strMeasurementTypeTag.c_str());
		if (nFind >= 0)
			m_DiscreteArray[i].strMeasurementType=m_MeasurementTypeArray[j].szName;
	}

	//	�������ȷ������Դ
	for (i=0; i<(int)m_MeasurementArray.size(); i++)
	{
		for (j=0; j<(int)m_MeasurementValueArray.size(); j++)
		{
			if (strcmp(m_MeasurementArray[i].strResourceID.c_str(), m_MeasurementValueArray[j].strMeasurementTag.c_str()) == 0)
			{
				m_MeasurementArray[i].strMeasurementSource=m_MeasurementValueArray[j].strMeasurementSource;
				m_MeasurementArray[i].strMeasurementValue=m_MeasurementValueArray[j].strMeasurementValue;
				break;
			}
		}
	}
	for (i=0; i<(int)m_AnalogArray.size(); i++)
	{
		for (j=0; j<(int)m_MeasurementValueArray.size(); j++)
		{
			if (strcmp(m_AnalogArray[i].strResourceID.c_str(), m_MeasurementValueArray[j].strMeasurementTag.c_str()) == 0)
			{
				m_AnalogArray[i].strMeasurementSource=m_MeasurementValueArray[j].strMeasurementSource;
				m_AnalogArray[i].strMeasurementValue=m_MeasurementValueArray[j].strMeasurementValue;
				break;
			}
		}
	}
	for (i=0; i<(int)m_DiscreteArray.size(); i++)
	{
		for (j=0; j<(int)m_MeasurementValueArray.size(); j++)
		{
			if (strcmp(m_DiscreteArray[i].strResourceID.c_str(), m_MeasurementValueArray[j].strMeasurementTag.c_str()) == 0)
			{
				m_DiscreteArray[i].strMeasurementSource=m_MeasurementValueArray[j].strMeasurementSource;
				m_DiscreteArray[i].strMeasurementValue=m_MeasurementValueArray[j].strMeasurementValue;
				break;
			}
		}
	}

	sortTapChangerByResID(0, (int)m_TapChangerArray.size()-1);
	//	�������ȷ���豸���ͣ��豸��վ����ѹ���ڵ���豸����
	for (i=0; i<(int)m_MeasurementArray.size(); i++)
	{
		if (!m_MeasurementArray[i].strTerminalTag.empty())
		{
			bFind=0;

			nFind=findTerminalByParentTag(0, (int)m_TerminalArray.size()-1, m_MeasurementArray[i].strTerminalTag.c_str());
			if (nFind >= 0)
			{
				m_MeasurementArray[i].strTerminal=m_TerminalArray[nFind].strName;
				m_MeasurementArray[i].strNode=m_TerminalArray[nFind].strNode;
				m_MeasurementArray[i].strSub=m_TerminalArray[nFind].strSub;
				m_MeasurementArray[i].strVolt=m_TerminalArray[nFind].strVolt;

				m_MeasurementArray[i].strEquimentType=m_TerminalArray[nFind].strEquimentType;
				m_MeasurementArray[i].strEquimentName=m_TerminalArray[nFind].strEquimentName;
				//bFind=1;
			}
 			//if (bFind)
 			//{
 			//	if (STRICMP(m_MeasurementArray[i].szEquimentType, "ACLineSegment") == 0 && STRICMP(m_MeasurementArray[i].szMeasurementType, "Current") == 0)
 			//	{
 			//		for (j=0; j<(int)m_ACLineSegmentArray.size(); j++)
 			//		{
 			//			if (strcmp(m_MeasurementArray[i].szEquimentName, m_ACLineSegmentArray[j].szName) == 0)
 			//			{
 			//				if (m_ACLineSegmentArray[j].fMaxCurrent < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
 			//				{
 			//					m_ACLineSegmentArray[j].fMaxCurrent=(float)readMeasurementMaxLimitValue(i);
 			//				}
 			//				break;
 			//			}
 			//		}
 			//	}
 			//	else if (STRICMP(m_MeasurementArray[i].szEquimentType, "TransformerWinding") == 0 && STRICMP(m_MeasurementArray[i].szMeasurementType, "Current") == 0)
 			//	{
 			//		for (j=0; j<(int)m_TransformerWindingArray.size(); j++)
 			//		{
 			//			if (strcmp(m_MeasurementArray[i].szEquimentName, m_TransformerWindingArray[j].szName) == 0)
 			//			{
 			//				if (m_TransformerWindingArray[j].fMaxCurrent < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
 			//				{
 			//					m_TransformerWindingArray[j].fMaxCurrent=(float)readMeasurementMaxLimitValue(i);
 			//				}
 			//				break;
 			//			}
 			//		}
 			//	}
 			//	else if (STRICMP(m_MeasurementArray[i].szEquimentType, "BusbarSection") == 0)
 			//	{
 			//		for (j=0; j<(int)m_BusbarSectionArray.size(); j++)
 			//		{
 			//			if (strcmp(m_MeasurementArray[i].szEquimentName, m_BusbarSectionArray[j].szName) == 0)
 			//			{
 			//				if (strcmp(m_MeasurementArray[i].szMeasurementType, "Voltage") == 0)
 			//				{
 			//					if (m_BusbarSectionArray[j].fVoltageLimitH < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
 			//					{
 			//						m_BusbarSectionArray[j].fVoltageLimitH=readMeasurementMaxLimitValue(i);
 			//					}
 			//					if (m_BusbarSectionArray[j].fVoltageLimitL < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
 			//					{
 			//						m_BusbarSectionArray[j].fVoltageLimitL=readMeasurementMinLimitValue(i);
 			//					}
 			//				}
 			//				else if (strcmp(m_MeasurementArray[i].szMeasurementType, "Frequency") == 0)
 			//				{
 			//					if (m_BusbarSectionArray[j].fFrequencyLimitH < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
 			//					{
 			//						m_BusbarSectionArray[j].fFrequencyLimitH=readMeasurementMaxLimitValue(i);
 			//					}
 			//					if (m_BusbarSectionArray[j].fFrequencyLimitL < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
 			//					{
 			//						m_BusbarSectionArray[j].fFrequencyLimitL=readMeasurementMinLimitValue(i);
 			//					}
 			//				}
 			//				break;
 			//			}
 			//		}
 			//	}
 			//}
 		}

		if (!m_MeasurementArray[i].strEquimentTag.empty())
		{
			bFind=0;
			nFind=findACLineSegmentByResID(0, (int)m_ACLineSegmentArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
			if (nFind >= 0)
 			{
				m_MeasurementArray[i].strEquimentType=("ACLineSegment");
				if (bNameByDesp)
					m_MeasurementArray[i].strEquimentName=(m_ACLineSegmentArray[nFind].szDesp);
				else
					m_MeasurementArray[i].strEquimentName=(m_ACLineSegmentArray[nFind].szName);

// 				if (STRICMP(m_MeasurementArray[i].szMeasurementType, "Current") == 0)
// 				{
// 					if (m_ACLineSegmentArray[nFind].fMaxCurrent < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
// 					{
// 						m_ACLineSegmentArray[nFind].fMaxCurrent=(float)readMeasurementMaxLimitValue(i);
// 					}
// 				}
				bFind=1;
 			}
 			if (!bFind)
 			{
				nFind=findTransformerWindingByResID(0, (int)m_TransformerWindingArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					m_MeasurementArray[i].strEquimentType=("TransformerWinding");
					if (m_TransformerWindingArray[nFind].nTransformerWindingType == 2)
					{
						m_MeasurementArray[i].strEquimentName=(m_TransformerWindingArray[nFind].szPowerTransformer);
					}
					else
					{
						if (bNameByDesp)
							m_MeasurementArray[i].strEquimentName=(m_TransformerWindingArray[nFind].szDesp);
						else
							m_MeasurementArray[i].strEquimentName=(m_TransformerWindingArray[nFind].szName);
					}
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub=(m_TransformerWindingArray[nFind].szSub);
						m_MeasurementArray[i].strVolt=(m_TransformerWindingArray[nFind].szVolt);
						m_MeasurementArray[i].strTerminal=(m_TransformerWindingArray[nFind].szNode);
// 						if (STRICMP(m_MeasurementArray[i].szMeasurementType, "Current") == 0)
// 						{
// 							if (m_TransformerWindingArray[nFind].fMaxCurrent < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
// 							{
// 								m_TransformerWindingArray[nFind].fMaxCurrent=(float)readMeasurementMaxLimitValue(i);
// 							}
// 						}
					}
					bFind=1;
				}
 			}
 			if (!bFind)
 			{
				nFind=findSynchronousMachineByResID(0, (int)m_SynchronousMachineArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					m_MeasurementArray[i].strEquimentType=("SynchronousMachine");
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=(m_SynchronousMachineArray[nFind].szDesp);
					else
						m_MeasurementArray[i].strEquimentName=(m_SynchronousMachineArray[nFind].szName);
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub=(m_SynchronousMachineArray[nFind].szSub);
						m_MeasurementArray[i].strVolt=(m_SynchronousMachineArray[nFind].szVolt);
						m_MeasurementArray[i].strNode=(m_SynchronousMachineArray[nFind].szNode);
					}
					bFind=1;
				}
 			}
 			if (!bFind)
 			{
				nFind=findEnergyConsumerByResID(0, (int)m_EnergyConsumerArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
 				{
					m_MeasurementArray[i].strEquimentType=("EnergyConsumer");
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=(m_EnergyConsumerArray[nFind].szDesp);
					else
						m_MeasurementArray[i].strEquimentName=(m_EnergyConsumerArray[nFind].szName);
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub=(m_EnergyConsumerArray[nFind].szSub);
						m_MeasurementArray[i].strVolt=(m_EnergyConsumerArray[nFind].szVolt);
						m_MeasurementArray[i].strNode=(m_EnergyConsumerArray[nFind].szNode);
					}
					bFind=1;
 				}
 			}
 			if (!bFind)
 			{
				nFind=findCompensatorByResID(0, (int)m_CompensatorArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
 				{
					m_MeasurementArray[i].strEquimentType=("Compensator");
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=(m_CompensatorArray[nFind].szDesp);
					else
						m_MeasurementArray[i].strEquimentName=(m_CompensatorArray[nFind].szName);
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub=(m_CompensatorArray[nFind].szSub);
						m_MeasurementArray[i].strVolt=(m_CompensatorArray[nFind].szVolt);
					}
					bFind=1;
 				}
 			}
 			if (!bFind)
 			{
				nFind=findBusbarSectionByResID(0, (int)m_BusbarSectionArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					m_MeasurementArray[i].strEquimentType=("BusbarSection");
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=(m_BusbarSectionArray[nFind].szDesp);
					else
						m_MeasurementArray[i].strEquimentName=(m_BusbarSectionArray[nFind].szName);
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub=(m_BusbarSectionArray[nFind].szSub);
						m_MeasurementArray[i].strVolt=(m_BusbarSectionArray[nFind].szVolt);
						m_MeasurementArray[i].strNode=(m_BusbarSectionArray[nFind].szNode);
// 						if (strcmp(m_MeasurementArray[i].szMeasurementType, "Voltage") == 0)
// 						{
// 							if (m_BusbarSectionArray[nFind].fVoltageLimitH < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
// 							{
// 								m_BusbarSectionArray[nFind].fVoltageLimitH=readMeasurementMaxLimitValue(i);
// 							}
// 							if (m_BusbarSectionArray[nFind].fVoltageLimitL < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
// 							{
// 								m_BusbarSectionArray[nFind].fVoltageLimitL=readMeasurementMinLimitValue(i);
// 							}
// 						}
// 						else if (strcmp(m_MeasurementArray[i].szMeasurementType, "Frequency") == 0)
// 						{
// 							if (m_BusbarSectionArray[nFind].fFrequencyLimitH < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
// 							{
// 								m_BusbarSectionArray[nFind].fFrequencyLimitH=readMeasurementMaxLimitValue(i);
// 							}
// 							if (m_BusbarSectionArray[nFind].fFrequencyLimitL < 1 && m_MeasurementArray[i].nLimitSetNum > 0)
// 							{
// 								m_BusbarSectionArray[nFind].fFrequencyLimitL=readMeasurementMinLimitValue(i);
// 							}
// 						}
					}
					bFind=1;
				}
 			}
 			if (!bFind)
 			{
				nFind=findBreakerByResID(0, (int)m_BreakerArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					m_MeasurementArray[i].strEquimentType="Breaker";
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=m_BreakerArray[nFind].strDesp;
					else
						m_MeasurementArray[i].strEquimentName=m_BreakerArray[nFind].strName;
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub= m_BreakerArray[nFind].strSub ;
						m_MeasurementArray[i].strVolt=m_BreakerArray[nFind].strVolt;
					}
					bFind=1;
				}
 			}
 			if (!bFind)
 			{
				nFind=findDisconnectorByResID(0, (int)m_DisconnectorArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					m_MeasurementArray[i].strEquimentType="Disconnector";
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=m_DisconnectorArray[nFind].strDesp;
					else
						m_MeasurementArray[i].strEquimentName=m_DisconnectorArray[nFind].strName;
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub= m_DisconnectorArray[nFind].strSub;
						m_MeasurementArray[i].strVolt=m_DisconnectorArray[nFind].strVolt;
					}
					bFind=1;
				}
 			}
			if (!bFind)
			{
				nFind=findGroundDisconnectorByResID(0, (int)m_GroundDisconnectorArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					m_MeasurementArray[i].strEquimentType=("GroundDisconnector");
					if (bNameByDesp)
						m_MeasurementArray[i].strEquimentName=(m_GroundDisconnectorArray[nFind].strDesp);
					else
						m_MeasurementArray[i].strEquimentName=(m_GroundDisconnectorArray[nFind].strName);
					if (m_MeasurementArray[i].strTerminalTag.empty())
					{
						m_MeasurementArray[i].strSub =m_GroundDisconnectorArray[nFind].strSub ;
						m_MeasurementArray[i].strVolt=m_GroundDisconnectorArray[nFind].strVolt;
					}
					bFind=1;
				}
			}
			if (!bFind)
			{
				nFind=findTapChangerByResID(0, (int)m_TapChangerArray.size()-1, m_MeasurementArray[i].strEquimentTag.c_str());
				if (nFind >= 0)
				{
					int nWind=findTransformerWindingByResID(0, (int)m_TransformerWindingArray.size()-1, m_TapChangerArray[nFind].szTransformerWindingTag);
					if (nWind >= 0)
					{
						m_MeasurementArray[i].strEquimentType=("TransformerWinding");
						if (m_TransformerWindingArray[nWind].nTransformerWindingType == 2)
						{
							m_MeasurementArray[i].strEquimentName=(m_TransformerWindingArray[nWind].szPowerTransformer);
						}
						else
						{
							if (bNameByDesp)
								m_MeasurementArray[i].strEquimentName=(m_TransformerWindingArray[nWind].szDesp);
							else
								m_MeasurementArray[i].strEquimentName=(m_TransformerWindingArray[nWind].szName);
						}
						if (m_MeasurementArray[i].strTerminalTag.empty())
						{
							m_MeasurementArray[i].strSub=(m_TransformerWindingArray[nWind].szSub);
							m_MeasurementArray[i].strVolt=(m_TransformerWindingArray[nWind].szVolt);
							m_MeasurementArray[i].strTerminal=(m_TransformerWindingArray[nWind].szNode);
						}
					}
					bFind=1;
				}
			}
		}
	}
}

double CCIMData::readMeasurementMaxLimitValue(const int nMeasurement)
{
//	register int	i, j;
	double		fMaxValue=0;
//	int			nLimit;
// 	for (i=0; i<m_MeasurementArray[nMeasurement].nLimitSetNum; i++)
// 	{
// 		nLimit=-1;
// 		for (j=0; j<(int)m_LimitSetArray.size(); j++)
// 		{
// 			if (STRICMP(m_MeasurementArray[nMeasurement].szLimitSetTag[i], m_LimitSetArray[j].szResourceID) == 0)
// 			{
// 				nLimit=j;
// 				break;
// 			}
// 		}
// 		if (nLimit >= 0)
// 		{
// 			for (j=0; j<(int)m_LimitArray.size(); j++)
// 			{
// 				if (STRICMP(m_LimitSetArray[nLimit].szResourceID, m_LimitArray[j].szLimitSetTag) == 0)
// 				{
// 					if (fMaxValue < m_LimitArray[j].fValue)
// 					{
// 						fMaxValue=m_LimitArray[j].fValue;
// 					}
// 				}
// 			}
// 		}
// 	}
	return fMaxValue;
}

double CCIMData::readMeasurementMinLimitValue(const int nMeasurement)
{
//	register int	i, j;
	double		fMinValue=0;
//	int			nLimit;
// 	for (i=0; i<m_MeasurementArray[nMeasurement].nLimitSetNum; i++)
// 	{
// 		nLimit=-1;
// 		for (j=0; j<(int)m_LimitSetArray.size(); j++)
// 		{
// 			if (STRICMP(m_MeasurementArray[nMeasurement].szLimitSetTag[i], m_LimitSetArray[j].szResourceID) == 0)
// 			{
// 				nLimit=j;
// 				break;
// 			}
// 		}
// 		if (nLimit >= 0)
// 		{
// 			fMinValue=10000000;
// 			for (j=0; j<(int)m_LimitArray.size(); j++)
// 			{
// 				if (STRICMP(m_LimitSetArray[nLimit].szResourceID, m_LimitArray[j].szLimitSetTag) == 0)
// 				{
// 					if (fMinValue > m_LimitArray[j].fValue)
// 					{
// 						fMinValue=m_LimitArray[j].fValue;
// 					}
// 				}
// 			}
// 		}
// 	}
	return fMinValue;
}
