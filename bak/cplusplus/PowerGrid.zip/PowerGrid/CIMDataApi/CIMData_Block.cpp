#include "stdafx.h"
#include "CIMData.h"

#if (!defined(WIN64))
#	pragma comment(lib, "../../lib/PGMemDB.lib")
#	pragma message("CIMDataApi Link LibX86 PGMemDB.lib")
#else					 
#	pragma comment(lib, "../../lib_x64/PGMemDB.lib")
#	pragma message("CIMDataApi Link LibX64 PGMemDB.lib")
#endif

void CCIMData::SetExcludeSubstation(std::vector<std::string>& strExcludeSubstationArray)
{
	register int	i;
	int		nData;

	for (nData=0; nData<(int)m_SubstationArray.size(); nData++)
		m_SubstationArray[nData].bExclude=0;

	for (nData=0; nData<(int)m_SubstationArray.size(); nData++)
	{
		for (i=0; i<(int)strExcludeSubstationArray.size(); i++)
		{
			if (strcmp(m_SubstationArray[nData].szName, strExcludeSubstationArray[i].c_str()) == 0)
			{
				m_SubstationArray[nData].bExclude=1;
				break;
			}
		}
	}
}

void CCIMData::SetExcludeSubcontrolArea(const int bNameByDesp, std::vector<std::string>& strExcludeSubcontrolAreaList)
{
	register int	i;
	int		nData;

	for (nData=0; nData<(int)m_SubcontrolAreaArray.size(); nData++)
		m_SubcontrolAreaArray[nData].bExclude=0;

	for (nData=0; nData<(int)m_SubcontrolAreaArray.size(); nData++)
	{
		for (i=0; i<(int)strExcludeSubcontrolAreaList.size(); i++)
		{
			if (strcmp(m_SubcontrolAreaArray[nData].szName, strExcludeSubcontrolAreaList[i].c_str()) == 0)
			{
				m_SubcontrolAreaArray[nData].bExclude=1;
				break;
			}
		}
	}

	formBound(bNameByDesp);
}


void CCIMData::formBound(const int bNameByDesp)
{
	register int	i;
	unsigned char	bExI, bExJ;

	m_BoundLineArray.clear();
	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		bExI=isSubstationExclude(m_ACLineSegmentArray[i].szSub[0], bNameByDesp);
		bExJ=isSubstationExclude(m_ACLineSegmentArray[i].szSub[1], bNameByDesp);
		//Log(g_lpszCimParserLogFile, "Line[%s] Exclude SubI[%s]=%d SubJ[%s]=%d\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], bExI, m_ACLineSegmentArray[i].szSub[1], bExJ);
		if (bExI != bExJ)
			m_BoundLineArray.push_back(m_ACLineSegmentArray[i]);
	}
}

int CCIMData::isSubcontrolAreaExclude(const char* lpszSubcontrolArea, const int bNameByDesp)
{
	register int	i;
	for (i=0; i<(int)m_SubcontrolAreaArray.size(); i++)
	{
		if (bNameByDesp)
		{
			if (strcmp(m_SubcontrolAreaArray[i].szDesp, lpszSubcontrolArea) == 0)
				return m_SubcontrolAreaArray[i].bExclude;
		}
		else
		{
			if (strcmp(m_SubcontrolAreaArray[i].szName, lpszSubcontrolArea) == 0)
				return m_SubcontrolAreaArray[i].bExclude;
		}
	}
	return 0;
}

int CCIMData::isSubstationExclude(const char* lpszSubstation, const int bNameByDesp)
{
	register int	i;
	int		nSub, nArea;

	nSub=nArea=-1;
	for (i=0; i<(int)m_SubstationArray.size(); i++)
	{
		if (strcmp(m_SubstationArray[i].strRealName.c_str(), lpszSubstation) == 0)
		{
			nSub=i;
			break;
		}
	}
	if (nSub < 0)
		return 1;

	for (i=0; i<(int)m_SubcontrolAreaArray.size(); i++)
	{
		if (bNameByDesp)
		{
			if (strcmp(m_SubcontrolAreaArray[i].szDesp, m_SubstationArray[nSub].strSubcontrolArea.c_str()) == 0)
			{
				nArea=i;
				break;
			}
		}
		else
		{
			if (strcmp(m_SubcontrolAreaArray[i].szName, m_SubstationArray[nSub].strSubcontrolArea.c_str()) == 0)
			{
				nArea=i;
				break;
			}
		}
	}
	if (nArea < 0)
		return 1;

	if (m_SubcontrolAreaArray[nArea].bExclude)
		return 1;

	if (m_SubstationArray[nSub].bExclude)
		return 1;

	return 0;
}

void CCIMData::insertSubcontrolArea(tagPGBlock* pPGBlock, const int bNameByDesp, const int bCimAsOutnet)
{
	register int	i;

	for (i=0; i<(int)m_BaseVoltageArray.size(); i++)
	{
		strcpy(pPGBlock->m_BaseVoltageArray[pPGBlock->m_nRecordNum[PG_BASEVOLTAGE]].szResID,		m_BaseVoltageArray[i].szResourceID);
		sprintf(pPGBlock->m_BaseVoltageArray[pPGBlock->m_nRecordNum[PG_BASEVOLTAGE]].szName, "%.2f",	m_BaseVoltageArray[i].fNominalVoltage);
		pPGBlock->m_BaseVoltageArray[pPGBlock->m_nRecordNum[PG_BASEVOLTAGE]].nominalVoltage=m_BaseVoltageArray[i].fNominalVoltage;
		pPGBlock->m_nRecordNum[PG_BASEVOLTAGE]++;
	}

	memset(&pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]], 0, sizeof(tagPGSubcontrolArea));
	strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szCompany, pPGBlock->m_CompanyArray[0].szName);
	for (i=0; i<(int)m_SubcontrolAreaArray.size(); i++)
	{
		if (bNameByDesp)
		{
			if (isSubcontrolAreaExclude(m_SubcontrolAreaArray[i].szDesp, bNameByDesp))
				continue;
		}
		else
		{
			if (isSubcontrolAreaExclude(m_SubcontrolAreaArray[i].szName, bNameByDesp))
				continue;
		}

		strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szResID, m_SubcontrolAreaArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szName, m_SubcontrolAreaArray[i].szDesp);
		else
			strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szName, m_SubcontrolAreaArray[i].szName);
		strcpy(pPGBlock->m_SubcontrolAreaArray[pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]].szDesp, m_SubcontrolAreaArray[i].szDesp);
		pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]++;
	}
}

void CCIMData::insertSubstation(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i, j;
	std::string	strSub;

	for (i=0; i<(int)m_SubstationArray.size(); i++)
	{
		if (isSubstationExclude(m_SubstationArray[i].strRealName.c_str(), bNameByDesp))
		{
			Log(g_lpszLogFile, " SubstationΪ����⳧վ: (%s) (%s)\n", m_SubstationArray[i].strSubcontrolArea.c_str(), m_SubstationArray[i].szName);
			continue;
		}
		if (m_SubstationArray[i].strSubcontrolArea.empty())
		{
			Log(g_lpszLogFile, "�޷����볧վ, ��SubcontrolArea��Ϣ: (%s) (%s)\n", m_SubstationArray[i].strSubcontrolArea.c_str(), m_SubstationArray[i].szName);
			continue;
		}

		memset(&pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]], 0, sizeof(tagPGSubstation));
		strcpy(pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]].szResID,	m_SubstationArray[i].szResourceID);
		strcpy(pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]].szName,	m_SubstationArray[i].strRealName.c_str());
		strcpy(pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]].szDesp,	m_SubstationArray[i].szDesp);
		strcpy(pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]].szSubcontrolArea,	m_SubstationArray[i].strSubcontrolArea.c_str());
		for (j=0; j<pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; j++)
		{
			if (strcmp(pPGBlock->m_SubcontrolAreaArray[j].szName, m_SubstationArray[i].strSubcontrolArea.c_str()) == 0)
			{
				strcpy(pPGBlock->m_SubstationArray[pPGBlock->m_nRecordNum[PG_SUBSTATION]].szCompany, pPGBlock->m_SubcontrolAreaArray[j].szCompany);
				break;
			}
		}
		pPGBlock->m_nRecordNum[PG_SUBSTATION]++;
	}
}

char* CCIMData::FormatVoltageLevelName(const char* lpszInVoltName)
{
	static	char	szFormatedVoltName[MDB_CHARLEN_LONG];
	char*	lpszToken;
	char	szBuf[MDB_CHARLEN_LONG];
	std::vector<std::string>	strEleArray;

	strcpy(szFormatedVoltName, lpszInVoltName);
	//return szFormatedVoltName;	//	����Ĳ���Ҫ�����������Ƕ������ӵ���Ҫ����

	strEleArray.clear();
	strcpy(szBuf, lpszInVoltName);
	lpszToken=strtok(szBuf, ".: \t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, ".: \t\n");
	}
	if (!strEleArray.empty())
		strcpy(szFormatedVoltName, strEleArray[strEleArray.size()-1].c_str());
	return szFormatedVoltName;
}

void CCIMData::insertVoltageLevel(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;

	for (i=0; i<(int)m_VoltageLevelArray.size(); i++)
	{
		if (isSubstationExclude(m_VoltageLevelArray[i].szSub, bNameByDesp))
			continue;

		if (strlen(m_VoltageLevelArray[i].szSub) <= 0)
		{
			Log(g_lpszLogFile, "�޷������ѹ�ȼ�, ��Substation��Ϣ: (%.2f) (%s)\n", m_VoltageLevelArray[i].fNominal, m_VoltageLevelArray[i].szSub);
			continue;
		}

		memset(&pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]], 0, sizeof(tagPGVoltageLevel));
		strcpy(pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szResID,	m_VoltageLevelArray[i].szResourceID);
		strcpy(pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szSub,	m_VoltageLevelArray[i].szSub);
		strcpy(pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]].szName,	m_VoltageLevelArray[i].szName);
		pPGBlock->m_VoltageLevelArray[pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]].nominalVoltage=m_VoltageLevelArray[i].fNominal;
		pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]++;
	}
}

void CCIMData::insertACLineSegment(tagPGBlock* pPGBlock, const int bNameByDesp, const float fLowVThreshold)
{
	register int	i, j;
	int			nVoltI, nVoltJ;
	unsigned char	bExI, bExJ;
	float		fBase;

	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		if (isSubstationExclude(m_ACLineSegmentArray[i].szSub[0], bNameByDesp) || isSubstationExclude(m_ACLineSegmentArray[i].szSub[1], bNameByDesp))	//	�����ߺ�������·�����
			continue;

		if (strlen(m_ACLineSegmentArray[i].szNode[0]) <= 0)
		{
			Log(g_lpszLogFile, "�޷�������·, �޽ڵ�1��Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szNode[1]);
			continue;
		}
		if (strlen(m_ACLineSegmentArray[i].szNode[1]) <= 0)
		{
			Log(g_lpszLogFile, "�޷�������·, �޽ڵ�2��Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szNode[1]);
			continue;
		}
		//if (strcmp(m_ACLineSegmentArray[i].szVolt[0] , m_ACLineSegmentArray[i].szVolt[1]) != 0)
		//{
		//	Log(g_lpszCimParserLogFile, "�޷�������·, �����ѹ�ȼ�(%s %s)��ͬ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szVolt[1], 
		//		m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szNode1, m_ACLineSegmentArray[i].szNode2);
		//	continue;
		//}
		nVoltI=nVoltJ=-1;
		for (j=0; j<(int)m_VoltageLevelArray.size(); j++)
		{
			if (strcmp(m_VoltageLevelArray[j].szSub, m_ACLineSegmentArray[i].szSub[0]) == 0 &&
				strcmp(m_VoltageLevelArray[j].szName, m_ACLineSegmentArray[i].szVolt[0]) == 0)
			{
				nVoltI=j;
				break;
			}
		}
		if (nVoltI < 0)
		{
			Log(g_lpszLogFile, "�޷�������·, �޵�ѹ�ȼ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szVolt[1]);
			continue;
		}

		for (j=0; j<(int)m_VoltageLevelArray.size(); j++)
		{
			if (strcmp(m_VoltageLevelArray[j].szSub, m_ACLineSegmentArray[i].szSub[1]) == 0 &&
				strcmp(m_VoltageLevelArray[j].szName, m_ACLineSegmentArray[i].szVolt[1]) == 0)
			{
				nVoltJ=j;
				break;
			}
		}
		if (nVoltJ < 0)
		{
			Log(g_lpszLogFile, "�޷�������·, �޵�ѹ�ȼ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szVolt[1]);
			continue;
		}

		if (fabs(m_VoltageLevelArray[nVoltI].fNominal-m_VoltageLevelArray[nVoltJ].fNominal) > max(m_VoltageLevelArray[nVoltI].fNominal , m_VoltageLevelArray[nVoltJ].fNominal)/10.0)
		{
			Log(g_lpszLogFile, "�޷�������·, �����ѹ�ȼ�(%s %s)��ͬ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szVolt[1], 
				m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szVolt[1]);
			continue;
		}

		if (m_VoltageLevelArray[nVoltI].fNominal < fLowVThreshold)
			continue;

		fBase=pPGBlock->m_System.fBasePower/(m_VoltageLevelArray[nVoltI].fNominal*m_VoltageLevelArray[nVoltI].fNominal);

		memset(&pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]], 0, sizeof(tagPGACLineSegment));
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szResID,		m_ACLineSegmentArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szName,		m_ACLineSegmentArray[i].szDesp);
		else
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szName,		m_ACLineSegmentArray[i].szName);
		strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szDesp,			m_ACLineSegmentArray[i].szDesp);
		if (strcmp(m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1]) < 0)
		{
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubI,		m_ACLineSegmentArray[i].szSub[0]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltI,	m_ACLineSegmentArray[i].szVolt[0]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeI,	m_ACLineSegmentArray[i].szNode[0]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubJ,		m_ACLineSegmentArray[i].szSub[1]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltJ,	m_ACLineSegmentArray[i].szVolt[1]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeJ,	m_ACLineSegmentArray[i].szNode[1]);
		}
		else
		{
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubI,		m_ACLineSegmentArray[i].szSub[1]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltI,	m_ACLineSegmentArray[i].szVolt[1]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeI,	m_ACLineSegmentArray[i].szNode[1]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szSubJ,		m_ACLineSegmentArray[i].szSub[0]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szVoltJ,	m_ACLineSegmentArray[i].szVolt[0]);
			strcpy(pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].szNodeJ,	m_ACLineSegmentArray[i].szNode[0]);
		}

		if (m_ACLineSegmentArray[i].nRPu == 1)
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fR=(float)m_ACLineSegmentArray[i].fRpu;
		else
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fR=(float)m_ACLineSegmentArray[i].fR*fBase;
		if (m_ACLineSegmentArray[i].nXPu == 1)
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fX=(float)m_ACLineSegmentArray[i].fXpu;
		else
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fX=(float)m_ACLineSegmentArray[i].fX*fBase;

		if (m_ACLineSegmentArray[i].nBPu == 1)
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fB=(float)m_ACLineSegmentArray[i].fBpu/2;
		else
		{
			//fBuf=(float)(2.0*M_PI*m_ACLineSegmentArray[i].fB/2.0/fBase/1000000.0);
			pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fB=(float)(m_ACLineSegmentArray[i].fB/fBase/1000000.0);
		}
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fRatedCur=(float)m_ACLineSegmentArray[i].fRatedA;
		pPGBlock->m_ACLineSegmentArray[pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]].fRatedMva=(float)(1.732*m_VoltageLevelArray[nVoltI].fNominal*m_ACLineSegmentArray[i].fRatedA/1000);

		pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]++;
	}

	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		bExI=isSubstationExclude(m_ACLineSegmentArray[i].szSub[0], bNameByDesp);
		bExJ=isSubstationExclude(m_ACLineSegmentArray[i].szSub[1], bNameByDesp);
		if (bExI == bExJ)	//	���������������
			continue;

		if (!bExI)
		{
			if (strlen(m_ACLineSegmentArray[i].szNode[0]) <= 0)
			{
				Log(g_lpszLogFile, "�޷�������·����, �޽ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szNode[1]);
				continue;
			}

			memset(&pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGEnergyConsumer));
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID,	m_ACLineSegmentArray[i].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szDesp);
			else
				strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szName);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szDesp, m_ACLineSegmentArray[i].szDesp);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub, m_ACLineSegmentArray[i].szSub[0]);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt, m_ACLineSegmentArray[i].szVolt[0]);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode, m_ACLineSegmentArray[i].szNode[0]);
			pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;

			Log(g_lpszLogFile, "������·����: (ResID=%s) (Sub=%s) (Volt=%s) (Node=%s) (Name=%s)\n", 
				m_ACLineSegmentArray[i].szResourceID, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szName);
		}
		else if (!bExJ)
		{
			if (strlen(m_ACLineSegmentArray[i].szNode[1]) <= 0)
			{
				Log(g_lpszLogFile, "�޷�������·����, �޽ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szNode[1]);
				continue;
			}

			memset(&pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGEnergyConsumer));
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID, m_ACLineSegmentArray[i].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szDesp);
			else
				strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szName);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szDesp, m_ACLineSegmentArray[i].szDesp);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub, m_ACLineSegmentArray[i].szSub[1]);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt, m_ACLineSegmentArray[i].szVolt[1]);
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode, m_ACLineSegmentArray[i].szNode[1]);
			pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;

			Log(g_lpszLogFile, "������·����: (ResID=%s) (Sub=%s) (Volt=%s) (Node=%s) (Name=%s)\n", 
				m_ACLineSegmentArray[i].szResourceID, m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szVolt[1], m_ACLineSegmentArray[i].szNode[1], m_ACLineSegmentArray[i].szName);
		}
	}

	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
	{
		bExI=isSubstationExclude(m_ACLineSegmentArray[i].szSub[0], bNameByDesp);
		bExJ=isSubstationExclude(m_ACLineSegmentArray[i].szSub[1], bNameByDesp);
		if (bExI || bExJ)
			continue;

		nVoltI=-1;
		for (j=0; j<(int)m_VoltageLevelArray.size(); j++)
		{
			if (strcmp(m_VoltageLevelArray[j].szSub, m_ACLineSegmentArray[i].szSub[0]) == 0 &&
				strcmp(m_VoltageLevelArray[j].szName, m_ACLineSegmentArray[i].szVolt[0]) == 0)
			{
				nVoltI=j;
				break;
			}
		}
		if (nVoltI < 0)
		{
			Log(g_lpszLogFile, "�޷�������·, �޵�ѹ�ȼ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_ACLineSegmentArray[i].szName, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szNode[1]);
			continue;
		}
		if (m_VoltageLevelArray[nVoltI].fNominal >= fLowVThreshold)
			continue;

		memset(&pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGEnergyConsumer));
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID, m_ACLineSegmentArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szDesp);
		else
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szName);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szDesp, m_ACLineSegmentArray[i].szDesp);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub, m_ACLineSegmentArray[i].szSub[0]);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt, m_ACLineSegmentArray[i].szVolt[0]);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode, m_ACLineSegmentArray[i].szNode[0]);
		pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;

		Log(g_lpszLogFile, "�����ѹ��·����: (ResID=%s) (Sub=%s) (Volt=%s) (Node=%s) (Name=%s)\n", 
			m_ACLineSegmentArray[i].szResourceID, m_ACLineSegmentArray[i].szSub[0], m_ACLineSegmentArray[i].szVolt[0], m_ACLineSegmentArray[i].szNode[0], m_ACLineSegmentArray[i].szName);

		memset(&pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGEnergyConsumer));
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID, m_ACLineSegmentArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szDesp);
		else
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_ACLineSegmentArray[i].szName);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szDesp, m_ACLineSegmentArray[i].szDesp);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub, m_ACLineSegmentArray[i].szSub[1]);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt, m_ACLineSegmentArray[i].szVolt[1]);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode, m_ACLineSegmentArray[i].szNode[1]);
		pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;

		Log(g_lpszLogFile, "�����ѹ��·����: (ResID=%s) (Sub=%s) (Volt=%s) (Node=%s) (Name=%s)\n", 
			m_ACLineSegmentArray[i].szResourceID, m_ACLineSegmentArray[i].szSub[1], m_ACLineSegmentArray[i].szVolt[1], m_ACLineSegmentArray[i].szNode[1], m_ACLineSegmentArray[i].szName);
	}
}

void CCIMData::insertDCLineSegment(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;
	unsigned char	bExI, bExJ;

	for (i=0; i<(int)m_DCLineSegmentArray.size(); i++)
	{
		bExI=isSubstationExclude(m_DCLineSegmentArray[i].szSub[0], bNameByDesp);
		bExJ=isSubstationExclude(m_DCLineSegmentArray[i].szSub[1], bNameByDesp);
		if (bExI && bExJ)
			continue;

		if (strlen(m_DCLineSegmentArray[i].szNode[0]) <= 0)
		{
			Log(g_lpszLogFile, "�޷�����ֱ����·, �޽ڵ�1��Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_DCLineSegmentArray[i].szName, m_DCLineSegmentArray[i].szSub[0], m_DCLineSegmentArray[i].szSub[1], m_DCLineSegmentArray[i].szNode[0], m_DCLineSegmentArray[i].szNode[1]);
			continue;
		}
		if (strlen(m_DCLineSegmentArray[i].szNode[1]) <= 0)
		{
			Log(g_lpszLogFile, "�޷�����ֱ����·, �޽ڵ�2��Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_DCLineSegmentArray[i].szName, m_DCLineSegmentArray[i].szSub[0], m_DCLineSegmentArray[i].szSub[1], m_DCLineSegmentArray[i].szNode[0], m_DCLineSegmentArray[i].szNode[1]);
			continue;
		}

// 		if (strcmp(m_DCLineSegmentArray[i].szVolt[0], m_DCLineSegmentArray[i].szVolt[1]) != 0)
// 		{
// 			Log(g_lpszCimParserLogFile, "�޷�����ֱ����·, �����ѹ�ȼ�(%f %f)��ͬ: (%s) (%s) (%s) (%s) (%s)\n", m_DCLineSegmentArray[i].szVolt[0], m_DCLineSegmentArray[i].szVolt[1], 
// 				m_DCLineSegmentArray[i].szName, m_DCLineSegmentArray[i].szSub[0], m_DCLineSegmentArray[i].szSub[1], m_DCLineSegmentArray[i].szNode1, m_DCLineSegmentArray[i].szNode2);
// 			continue;
// 		}

		memset(&pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]], 0, sizeof(tagPGDCLineSegment));
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szResID,	m_DCLineSegmentArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szName,	m_DCLineSegmentArray[i].szDesp);
		else
			strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szName,	m_DCLineSegmentArray[i].szName);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szDesp,		m_DCLineSegmentArray[i].szDesp);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szSubI,		m_DCLineSegmentArray[i].szSub[0]);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szSubJ,		m_DCLineSegmentArray[i].szSub[1]);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szVoltI,	m_DCLineSegmentArray[i].szVolt[0]);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szVoltJ,	m_DCLineSegmentArray[i].szVolt[1]);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szNodeI,	m_DCLineSegmentArray[i].szNode[0]);
		strcpy(pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].szNodeJ,	m_DCLineSegmentArray[i].szNode[1]);

		pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].fR=(float)m_DCLineSegmentArray[i].fR;
		pPGBlock->m_DCLineSegmentArray[pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]].fL=(float)m_DCLineSegmentArray[i].fL;

		pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]++;
	}
}

void CCIMData::insertRectifierInverter(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;

	for (i=0; i<(int)m_RectifierInverterArray.size(); i++)
	{
		if (isSubstationExclude(m_RectifierInverterArray[i].szSub, bNameByDesp))
			continue;
		if (strlen(m_RectifierInverterArray[i].szNode[0]) <= 0 && strlen(m_RectifierInverterArray[i].szNode[1]) <= 0 && strlen(m_RectifierInverterArray[i].szNode[2]) <= 0)
		{
			Log(g_lpszLogFile, "�޷��������������, �޽ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_RectifierInverterArray[i].szName, m_RectifierInverterArray[i].szSub, m_RectifierInverterArray[i].szNode[0], m_RectifierInverterArray[i].szNode[1], m_RectifierInverterArray[i].szNode[2]);
			continue;
		}

		memset(&pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]], 0, sizeof(tagPGRectifierInverter));
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szResID,		m_RectifierInverterArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szName,		m_RectifierInverterArray[i].szDesp);
		else
			strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szName,		m_RectifierInverterArray[i].szName);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szDesp,			m_RectifierInverterArray[i].szDesp);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szSub,			m_RectifierInverterArray[i].szSub);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szVoltAC,		m_RectifierInverterArray[i].szVolt[0]);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szVoltDC,		m_RectifierInverterArray[i].szVolt[1]);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szVoltDC,		m_RectifierInverterArray[i].szVolt[2]);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szNodeAC,		m_RectifierInverterArray[i].szNode[0]);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szNodeDCP,		m_RectifierInverterArray[i].szNode[1]);
		strcpy(pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].szNodeDCN,		m_RectifierInverterArray[i].szNode[2]);

		pPGBlock->m_RectifierInverterArray[pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]].nBridges=m_RectifierInverterArray[i].nBridges;

		pPGBlock->m_nRecordNum[PG_RECTIFIERINVERTER]++;
	}
}

int CCIMData::ResolvePowerTransformerWindNum(const int nRecord, int& nWindH, int& nWindM, int& nWindL)
{
	int		nWindNum;

	nWindNum=0;
	if (m_PowerTransformerArray[nRecord].nWindNum == 3)	//	������
	{
		nWindH=m_PowerTransformerArray[nRecord].nWindArray[0];
		nWindM=m_PowerTransformerArray[nRecord].nWindArray[1];
		nWindL=m_PowerTransformerArray[nRecord].nWindArray[2];
		if (nWindH >= 0)
		{
			if (strlen(m_TransformerWindingArray[nWindH].szVolt) <= 0 || strlen(m_TransformerWindingArray[nWindH].szNode) <= 0)
				nWindH=-1;
		}
		if (nWindM >= 0)
		{
			if (strlen(m_TransformerWindingArray[nWindM].szVolt) <= 0 || strlen(m_TransformerWindingArray[nWindM].szNode) <= 0)
				nWindM=-1;
		}
		if (nWindL >= 0)
		{
			if (strlen(m_TransformerWindingArray[nWindL].szVolt) <= 0 || strlen(m_TransformerWindingArray[nWindL].szNode) <= 0)
				nWindL=-1;
		}
		if (nWindH >= 0)	nWindNum++;
		if (nWindM >= 0)	nWindNum++;
		if (nWindL >= 0)	nWindNum++;
		if (nWindNum == 2)
		{
			if (nWindH < 0)
			{
				nWindH=nWindM;
				nWindL=nWindL;
			}
			else
			{
				if (nWindM >= 0)	nWindL=nWindM;
			}
		}
	}
	else if (m_PowerTransformerArray[nRecord].nWindNum == 2)
	{
		nWindH=m_PowerTransformerArray[nRecord].nWindArray[0];
		nWindL=m_PowerTransformerArray[nRecord].nWindArray[1];
		if (nWindH >= 0)
		{
			if (strlen(m_TransformerWindingArray[nWindH].szVolt) <= 0 || strlen(m_TransformerWindingArray[nWindH].szNode) <= 0)
				nWindH=-1;
		}
		if (nWindL >= 0)
		{
			if (strlen(m_TransformerWindingArray[nWindL].szVolt) <= 0 || strlen(m_TransformerWindingArray[nWindL].szNode) <= 0)
				nWindL=-1;
		}
		if (nWindH >= 0)	nWindNum++;
		if (nWindL >= 0)	nWindNum++;
	}

	return nWindNum;
}

void CCIMData::insertTranformerWinding(tagPGBlock* pPGBlock, const int bNameByDesp, const int bTranPuVoltageHigh)
{
	register int	i, j;
	int			nVolt;
	float		fBase, fMax, fMaxH, fMaxL;
	int			nWind, nWindNum, nWindH, nWindM, nWindL;

	double		fMvaH, fMvaM, fMvaL;
	double		fSCVH, fSCVM, fSCVL;
	double		fSCWH, fSCWM, fSCWL;
	double		fRatio;
	int			nDev;

	for (nDev=0; nDev<(int)m_PowerTransformerArray.size(); nDev++)
	{
		if (strlen(m_PowerTransformerArray[nDev].szSub) <= 0)
		{
			Log(g_lpszLogFile, "�޷������ѹ��, ��Substation��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
			continue;
		}
		if (isSubstationExclude(m_PowerTransformerArray[nDev].szSub, bNameByDesp))
			continue;

		nWindNum=ResolvePowerTransformerWindNum(nDev, nWindH, nWindM, nWindL);
		if (nWindNum != 2 && nWindNum != 3)
		{
			Log(g_lpszLogFile, "�޷������ѹ��, ��ѹ��������Ϣ[WindNum=%d]����: (%s) (%s)\n", nWindNum, m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
			continue;
		}

		memset(&pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]], 0, sizeof(tagPGPowerTransformer));
		if (nWindNum == 2)	//	������
		{
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szResID,		m_PowerTransformerArray[nDev].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szName,	m_PowerTransformerArray[nDev].szDesp);
			else
				strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szName,	m_PowerTransformerArray[nDev].szName);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szDesp,		m_PowerTransformerArray[nDev].szDesp);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szSub,		m_PowerTransformerArray[nDev].szSub);
			pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].nWindNum=(unsigned char)m_PowerTransformerArray[nDev].nWindNum;
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szVoltH,		m_TransformerWindingArray[nWindH].szVolt);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szVoltM,		"");
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szVoltL,		m_TransformerWindingArray[nWindL].szVolt);

			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szWindH,		m_TransformerWindingArray[nWindH].szName);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szWindM,		"");
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szWindL,		m_TransformerWindingArray[nWindL].szName);
		}
		else
		{
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szResID,		m_PowerTransformerArray[nDev].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szName,	m_PowerTransformerArray[nDev].szDesp);
			else
				strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szName,	m_PowerTransformerArray[nDev].szName);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szDesp,		m_PowerTransformerArray[nDev].szDesp);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szSub,		m_PowerTransformerArray[nDev].szSub);
			pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].nWindNum=(unsigned char)m_PowerTransformerArray[nDev].nWindNum;
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szVoltH,		m_TransformerWindingArray[nWindH].szVolt);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szVoltM,		m_TransformerWindingArray[nWindM].szVolt);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szVoltL,		m_TransformerWindingArray[nWindL].szVolt);

			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szWindH,		m_TransformerWindingArray[nWindH].szName);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szWindM,		m_TransformerWindingArray[nWindM].szName);
			strcpy(pPGBlock->m_PowerTransformerArray[pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]].szWindL,		m_TransformerWindingArray[nWindL].szName);
		}
		pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]++;

		fBase=1;
		if (nWindNum == 2)	//	������
		{
			nVolt=-1;
			for (i=0; i<(int)m_VoltageLevelArray.size(); i++)
			{
				if (strcmp(m_VoltageLevelArray[i].szSub, m_TransformerWindingArray[nWindH].szSub) == 0 &&
					strcmp(m_VoltageLevelArray[i].szName, m_TransformerWindingArray[nWindH].szVolt) == 0)
				{
					nVolt=i;
					break;
				}
			}
			if (nVolt < 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��Substation��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
				continue;
			}

			if (strlen(m_TransformerWindingArray[nWindH].szVolt) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��VoltageH��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindL].szVolt) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��VoltageL��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindH].szNode) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, �޸�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindL].szNode) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, �޵�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strcmp(m_TransformerWindingArray[nWindH].szVolt, m_TransformerWindingArray[nWindL].szVolt) == 0 &&
				strcmp(m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindL].szNode) == 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��ѹ������ڵ���ͬ: (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}

			fBase=pPGBlock->m_System.fBasePower/(m_VoltageLevelArray[nVolt].fNominal*m_VoltageLevelArray[nVolt].fNominal);
			fMaxH=(float)(1000*m_TransformerWindingArray[nWindH].fRatedMW/m_VoltageLevelArray[nVolt].fNominal/1.732);
			fMaxL=(float)(1000*m_TransformerWindingArray[nWindL].fRatedMW/m_VoltageLevelArray[nVolt].fNominal/1.732);
			fMax=max(fMaxH, fMaxL);

			if (m_TransformerWindingArray[nWindH].fR == 0 && m_TransformerWindingArray[nWindH].fX == 0)
			{
				m_TransformerWindingArray[nWindH].nRPu=m_TransformerWindingArray[nWindH].nXPu=0;
				m_TransformerWindingArray[nWindL].nRPu=m_TransformerWindingArray[nWindL].nXPu=0;

				fMvaH=m_TransformerWindingArray[nWindH].fRatedMW;
				fSCWH=m_TransformerWindingArray[nWindH].fLoadLoss+m_TransformerWindingArray[nWindL].fLoadLoss;
				fSCVH=m_TransformerWindingArray[nWindH].fLeakageImpedence+m_TransformerWindingArray[nWindL].fLeakageImpedence;
				if (fMvaH > 0)
				{
					m_TransformerWindingArray[nWindH].fR=(float)(fSCWH/1000.0*m_BasePower.fBasePower/(fMvaH*fMvaH));
					m_TransformerWindingArray[nWindH].fX=(float)(fSCVH*m_BasePower.fBasePower/100.0/fMvaH);
					m_TransformerWindingArray[nWindH].nRPu=m_TransformerWindingArray[nWindH].nXPu=1;
					m_TransformerWindingArray[nWindL].nRPu=m_TransformerWindingArray[nWindL].nXPu=1;
				}
			}
			if (m_TransformerWindingArray[nWindH].fX < 0.0001)
			{
				m_TransformerWindingArray[nWindH].nXPu=1;
				m_TransformerWindingArray[nWindH].fX0=m_TransformerWindingArray[nWindH].fX=(float)0.01;
			}

			memset(&pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szResID, m_PowerTransformerArray[nDev].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName, m_PowerTransformerArray[nDev].szDesp);
			else
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName, m_PowerTransformerArray[nDev].szName);
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szDesp, m_PowerTransformerArray[nDev].szDesp);
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub, m_PowerTransformerArray[nDev].szSub);
			if (bNameByDesp)
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer, m_PowerTransformerArray[nDev].szDesp);
			else
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer, m_PowerTransformerArray[nDev].szName);
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI, m_TransformerWindingArray[nWindH].szVolt);
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ, m_TransformerWindingArray[nWindL].szVolt);
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI, m_TransformerWindingArray[nWindH].szNode);
			strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, m_TransformerWindingArray[nWindL].szNode);

			if (m_TransformerWindingArray[nWindH].fRatedMW > 0)
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedMva=m_TransformerWindingArray[nWindH].fRatedMW;
			else if (m_TransformerWindingArray[nWindL].fRatedMW > 0)
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedMva=m_TransformerWindingArray[nWindL].fRatedMW;

			//strcpy(szFieldH[PG_TRANSFORMERWINDING_TAPCHANGERI], pPGBlock->m_TapChangerArray[0].szName);
			if (strlen(m_TransformerWindingArray[nWindH].szTapChangerTag) > 0)
			{
				for (j=0; j<(int)m_TapChangerArray.size(); j++)
				{
					if (strcmp(m_TransformerWindingArray[nWindH].szTapChangerTag, m_TapChangerArray[j].szResourceID) == 0)
					{
						strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szTapChangerI, m_TapChangerArray[j].szLocalTapName);
						break;
					}
				}
			}

			//strcpy(szFieldH[PG_TRANSFORMERWINDING_TAPCHANGERI], pPGBlock->m_TapChangerArray[0].szName);
			if (strlen(m_TransformerWindingArray[nWindL].szTapChangerTag) > 0)
			{
				for (j=0; j<(int)m_TapChangerArray.size(); j++)
				{
					if (strcmp(m_TransformerWindingArray[nWindL].szTapChangerTag, m_TapChangerArray[j].szResourceID) == 0)
					{
						strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szTapChangerJ, m_TapChangerArray[j].szLocalTapName);
						break;
					}
				}
			}

			pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVI=m_TransformerWindingArray[nWindH].fRatedKV;
			pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVJ=m_TransformerWindingArray[nWindL].fRatedKV;
			if (m_TransformerWindingArray[nWindH].nRPu)
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fR=m_TransformerWindingArray[nWindH].fR;
			else
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fR=(float)(m_TransformerWindingArray[nWindH].fR*fBase);

			if (m_TransformerWindingArray[nWindH].nXPu)
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fX=m_TransformerWindingArray[nWindH].fX;
			else
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fX=(float)(m_TransformerWindingArray[nWindH].fX*fBase);
			pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;
		}
		else	//	������
		{
			if (strlen(m_TransformerWindingArray[nWindH].szVolt) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��VoltageH��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindM].szVolt) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��VoltageM��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindL].szVolt) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��VoltageL��Ϣ: (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindH].szNode) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, �޸�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindM].szNode) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ����ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strlen(m_TransformerWindingArray[nWindL].szNode) <= 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, �޵�ѹ�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strcmp(m_TransformerWindingArray[nWindH].szVolt, m_TransformerWindingArray[nWindM].szVolt) == 0 &&
				strcmp(m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode) == 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��ѹ�����в�ڵ���ͬ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strcmp(m_TransformerWindingArray[nWindH].szVolt, m_TransformerWindingArray[nWindL].szVolt) == 0 &&
				strcmp(m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindL].szNode) == 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��ѹ���ߵͲ�ڵ���ͬ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}
			if (strcmp(m_TransformerWindingArray[nWindM].szVolt, m_TransformerWindingArray[nWindL].szVolt) == 0 &&
				strcmp(m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode) == 0)
			{
				Log(g_lpszLogFile, "�޷������ѹ��, ��ѹ���еͲ�ڵ���ͬ: (%s) (%s) (%s) (%s) (%s)\n", m_PowerTransformerArray[nDev].szName, m_PowerTransformerArray[nDev].szSub, m_TransformerWindingArray[nWindH].szNode, m_TransformerWindingArray[nWindM].szNode, m_TransformerWindingArray[nWindL].szNode);
				continue;
			}

			fMvaH=fMvaM=fMvaL=fSCVH=fSCVM=fSCVL=fSCWH=fSCWM=fSCWL=0;
			if (m_TransformerWindingArray[nWindH].fR == 0 && m_TransformerWindingArray[nWindH].fX == 0 &&
				m_TransformerWindingArray[nWindM].fR == 0 && m_TransformerWindingArray[nWindM].fX == 0 &&
				m_TransformerWindingArray[nWindL].fR == 0 && m_TransformerWindingArray[nWindL].fX == 0)
			{
				fMvaH=m_TransformerWindingArray[nWindH].fRatedMW;
				fMvaM=m_TransformerWindingArray[nWindM].fRatedMW;
				fMvaL=m_TransformerWindingArray[nWindL].fRatedMW;
				if (fMvaH > 1 && fMvaM > 1 && fMvaL > 1)
				{
					fSCVH=m_TransformerWindingArray[nWindH].fLeakageImpedence;
					fSCVM=m_TransformerWindingArray[nWindM].fLeakageImpedence;
					fSCVL=m_TransformerWindingArray[nWindL].fLeakageImpedence;
					if (fSCVH > 0.001 && fSCVM > 0.001 && fSCVL > 0.001)
					{
						fSCWH=m_TransformerWindingArray[nWindH].fLoadLoss;
						fSCWM=m_TransformerWindingArray[nWindM].fLoadLoss;
						fSCWL=m_TransformerWindingArray[nWindL].fLoadLoss;
					}
					fRatio=fMvaH/fMvaM;
					fSCWM=fSCWM*fRatio*fRatio;
					fRatio=fMvaH/fMvaL;
					fSCWL=fSCWL*fRatio*fRatio;

					m_TransformerWindingArray[nWindH].fR=(float)((fSCWH+fSCWM-fSCWL)/2000.0*m_BasePower.fBasePower/(fMvaH*fMvaH));
					m_TransformerWindingArray[nWindM].fR=(float)((fSCWH+fSCWL-fSCWM)/2000.0*m_BasePower.fBasePower/(fMvaH*fMvaH));
					m_TransformerWindingArray[nWindL].fR=(float)((fSCWM+fSCWL-fSCWH)/2000.0*m_BasePower.fBasePower/(fMvaH*fMvaH));

					m_TransformerWindingArray[nWindH].fX=(float)((fSCVH+fSCVM-fSCVL)*m_BasePower.fBasePower/200.0/fMvaH);
					m_TransformerWindingArray[nWindM].fX=(float)((fSCVH+fSCVL-fSCVM)*m_BasePower.fBasePower/200.0/fMvaH);
					m_TransformerWindingArray[nWindL].fX=(float)((fSCVM+fSCVL-fSCVH)*m_BasePower.fBasePower/200.0/fMvaH);

					if (m_TransformerWindingArray[nWindH].fX < 0)
						m_TransformerWindingArray[nWindH].fR=0;
					if (m_TransformerWindingArray[nWindM].fX < 0)
						m_TransformerWindingArray[nWindM].fR=0;
					if (m_TransformerWindingArray[nWindL].fX < 0)
						m_TransformerWindingArray[nWindL].fR=0;

					m_TransformerWindingArray[nWindH].nRPu=m_TransformerWindingArray[nWindH].nXPu=1;
					m_TransformerWindingArray[nWindM].nRPu=m_TransformerWindingArray[nWindM].nXPu=1;
					m_TransformerWindingArray[nWindL].nRPu=m_TransformerWindingArray[nWindL].nXPu=1;
				}
			}

			if (bTranPuVoltageHigh)
			{
				nVolt=-1;
				nWind=nWindH;
				for (j=0; j<(int)m_VoltageLevelArray.size(); j++)
				{
					if (strcmp(m_VoltageLevelArray[j].szSub, m_TransformerWindingArray[nWind].szSub) == 0 &&
						strcmp(m_VoltageLevelArray[j].szName, m_TransformerWindingArray[nWind].szVolt) == 0)
					{
						nVolt=j;
						break;
					}
				}
				if (nVolt >= 0)
					fBase=pPGBlock->m_System.fBasePower/(m_VoltageLevelArray[nVolt].fNominal*m_VoltageLevelArray[nVolt].fNominal);
			}

			for (i=0; i<m_PowerTransformerArray[nDev].nWindNum; i++)
			{
				nWind=m_PowerTransformerArray[nDev].nWindArray[i];

				nVolt=-1;
				for (j=0; j<(int)m_VoltageLevelArray.size(); j++)
				{
					if (strcmp(m_VoltageLevelArray[j].szSub, m_TransformerWindingArray[nWind].szSub) == 0 &&
						strcmp(m_VoltageLevelArray[j].szName, m_TransformerWindingArray[nWind].szVolt) == 0)
					{
						nVolt=j;
						break;
					}
				}
				if (nVolt < 0)
				{
					Log(g_lpszLogFile, "�޷������ѹ��, ��Voltage��Ϣ: (%s) (%s)\n", m_TransformerWindingArray[nWind].szName, m_TransformerWindingArray[nWind].szSub);
					continue;
				}
				if (!bTranPuVoltageHigh)
					fBase=pPGBlock->m_System.fBasePower/(m_VoltageLevelArray[nVolt].fNominal*m_VoltageLevelArray[nVolt].fNominal);
				memset(&pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]], 0, sizeof(tagPGTransformerWinding));
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szResID,			m_TransformerWindingArray[nWind].szResourceID);
				if (bNameByDesp)
					strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName,		m_TransformerWindingArray[nWind].szDesp);
				else
					strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szName,		m_TransformerWindingArray[nWind].szName);
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szDesp,			m_TransformerWindingArray[nWind].szDesp);
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szSub,			m_PowerTransformerArray[nDev].szSub);
				if (bNameByDesp)
					strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer,		m_PowerTransformerArray[nDev].szDesp);
				else
					strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szPowerTransformer,		m_PowerTransformerArray[nDev].szName);
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltI,			m_TransformerWindingArray[nWind].szVolt);
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szVoltJ,			m_TransformerWindingArray[nWindL].szVolt);
				strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeI,			m_TransformerWindingArray[nWind].szNode);
				sprintf(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szNodeJ, "%s_t",	m_PowerTransformerArray[nDev].szName);
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedMva=m_TransformerWindingArray[nWind].fRatedMW;

				//strcpy(szFieldH[PG_TRANSFORMERWINDING_TAPCHANGERI], pPGBlock->m_TapChangerArray[0].szName);
				if (strlen(m_TransformerWindingArray[nWind].szTapChangerTag) > 0)
				{
					for (j=0; j<(int)m_TapChangerArray.size(); j++)
					{
						if (strcmp(m_TransformerWindingArray[nWind].szTapChangerTag, m_TapChangerArray[j].szResourceID) == 0)
						{
							strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szTapChangerI,		m_TapChangerArray[j].szLocalTapName);
							break;
						}
					}
				}
				//strcpy(pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].szTapChangerJ, pPGBlock->m_TapChangerArray[0].szName);

				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVI=m_TransformerWindingArray[nWind].fRatedKV;
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fRatedkVJ=m_TransformerWindingArray[nWindL].fRatedKV;
				if (m_TransformerWindingArray[nWind].nRPu)
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fR=m_TransformerWindingArray[nWind].fR;
				else
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fR=(float)(m_TransformerWindingArray[nWind].fR*fBase);

				if (m_TransformerWindingArray[nWind].nXPu)
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fX=m_TransformerWindingArray[nWind].fX;
				else
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]].fX=(float)(m_TransformerWindingArray[nWind].fX*fBase);
				pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]++;
			}
		}
	}
}


void CCIMData::insertSynchronousMachine(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;
	int			bAllHydro;

	bAllHydro=1;
	for (i=0; i<(int)m_SynchronousMachineArray.size(); i++)
	{
		if (m_SynchronousMachineArray[i].nUnitType == 0)
		{
			bAllHydro=0;
			break;
		}
	}

	for (i=0; i<(int)m_SynchronousMachineArray.size(); i++)
	{
		if (isSubstationExclude(m_SynchronousMachineArray[i].szSub, bNameByDesp))
			continue;
		if (strlen(m_SynchronousMachineArray[i].szSub) <= 0)
		{
			Log(g_lpszLogFile, "�޷����뷢���, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_SynchronousMachineArray[i].szName, m_SynchronousMachineArray[i].szSub, m_SynchronousMachineArray[i].szVolt);
			continue;
		}
		if (strlen(m_SynchronousMachineArray[i].szVolt) <= 0)
		{
			Log(g_lpszLogFile, "�޷����뷢���, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_SynchronousMachineArray[i].szName, m_SynchronousMachineArray[i].szSub, m_SynchronousMachineArray[i].szVolt);
			continue;
		}
		//if (m_SynchronousMachineArray[i].fVolt > 40)
		//	continue;
		if (strlen(m_SynchronousMachineArray[i].szNode) <= 0)
		{
			Log(g_lpszLogFile, "�޷����뷢���, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", m_SynchronousMachineArray[i].szName, m_SynchronousMachineArray[i].szSub, m_SynchronousMachineArray[i].szVolt);
			continue;
		}

		if (m_SynchronousMachineArray[i].fMaxP <= 0)
		{
			if (m_SynchronousMachineArray[i].fMvrate > 0)
				m_SynchronousMachineArray[i].fMaxP=m_SynchronousMachineArray[i].fMvrate;
			else
				m_SynchronousMachineArray[i].fMaxP=300;
		}
		if (m_SynchronousMachineArray[i].fMvrate < 1)	continue;	//	��Ա���һЩС�ķ���������Ĳ���
		if (m_SynchronousMachineArray[i].fMaxQ <= 0)
		{
			m_SynchronousMachineArray[i].fMaxQ=(float)(0.9*m_SynchronousMachineArray[i].fMaxP);
		}

		memset(&pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]], 0, sizeof(tagPGSynchronousMachine));
		strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szResID, m_SynchronousMachineArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szName, m_SynchronousMachineArray[i].szDesp);
		else
			strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szName, m_SynchronousMachineArray[i].szName);
		strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szDesp, m_SynchronousMachineArray[i].szDesp);
		strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, m_SynchronousMachineArray[i].szSub);
		strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, m_SynchronousMachineArray[i].szVolt);
		strcpy(pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, m_SynchronousMachineArray[i].szNode);

		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fMvaRate=m_SynchronousMachineArray[i].fMvrate;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanP=m_SynchronousMachineArray[i].fP;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fP=m_SynchronousMachineArray[i].fP;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=m_SynchronousMachineArray[i].fMaxP;
		//pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=m_SynchronousMachineArray[i].fMinP;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=0;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=m_SynchronousMachineArray[i].fMaxQ;

// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fXd=m_SynchronousMachineArray[i].fXd;
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fXdp=m_SynchronousMachineArray[i].fXdp;
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fXdpp=m_SynchronousMachineArray[i].fXdpp;
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fXq=m_SynchronousMachineArray[i].fXq;
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fXqp=m_SynchronousMachineArray[i].fXqp;
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fXqpp=m_SynchronousMachineArray[i].fXqpp;
// 
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fEmws=m_SynchronousMachineArray[i].fTj;
// 		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fDamp=m_SynchronousMachineArray[i].fD;

		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPca=0;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPva=0;
		pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxFactor=0;

		if (bAllHydro)
		{
			if (strstr(m_SynchronousMachineArray[i].szSub, "ˮ��") == NULL)	//	��Ϊ����CIM/XML�з����ģ�ʹ���
				m_SynchronousMachineArray[i].nUnitType=0;
			else
				m_SynchronousMachineArray[i].nUnitType=1;
		}
		if (m_SynchronousMachineArray[i].nUnitType == 0)
		{
			pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxFactor=(float)0.85;
			if (m_SynchronousMachineArray[i].fMaxP < 150)
			{
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPca=(float)0.05;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPva=(float)0.07;
			}
			else if (150 <= m_SynchronousMachineArray[i].fMaxP && m_SynchronousMachineArray[i].fMaxP < 200)
			{
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPca=(float)0.05;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPva=(float)0.04;
			}
			else if (200 <= m_SynchronousMachineArray[i].fMaxP && m_SynchronousMachineArray[i].fMaxP < 450)
			{
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPca=(float)0.03;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPva=(float)0.03;
			}
			else
			{
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPca=(float)0.03;
				pPGBlock->m_SynchronousMachineArray[pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fAuxPva=(float)0.02;
			}
		}

		pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]++;
	}
}

void CCIMData::insertEnergyConsumer(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;

	for (i=0; i<(int)m_EnergyConsumerArray.size(); i++)
	{
		if (isSubstationExclude(m_EnergyConsumerArray[i].szSub, bNameByDesp))
			continue;
		if (strlen(m_EnergyConsumerArray[i].szSub) <= 0)
		{
			Log(g_lpszLogFile, "�޷����븺��, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_EnergyConsumerArray[i].szName, m_EnergyConsumerArray[i].szSub, m_EnergyConsumerArray[i].szVolt);
			continue;
		}
		if (strlen(m_EnergyConsumerArray[i].szVolt) <= 0)
		{
			Log(g_lpszLogFile, "�޷����븺��, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_EnergyConsumerArray[i].szName, m_EnergyConsumerArray[i].szSub, m_EnergyConsumerArray[i].szVolt);
			continue;
		}
		if (strlen(m_EnergyConsumerArray[i].szNode) <= 0)
		{
			Log(g_lpszLogFile, "�޷����븺��, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", m_EnergyConsumerArray[i].szName, m_EnergyConsumerArray[i].szSub, m_EnergyConsumerArray[i].szVolt);
			continue;
		}

		memset(&pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]], 0, sizeof(tagPGEnergyConsumer));
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szResID, m_EnergyConsumerArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_EnergyConsumerArray[i].szDesp);
		else
			strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szName, m_EnergyConsumerArray[i].szName);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szDesp, m_EnergyConsumerArray[i].szDesp);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szSub, m_EnergyConsumerArray[i].szSub);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szVolt, m_EnergyConsumerArray[i].szVolt);
		strcpy(pPGBlock->m_EnergyConsumerArray[pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]].szNode, m_EnergyConsumerArray[i].szNode);
		pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]++;
	}
}

void CCIMData::insertCompensator(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i, j;
	int			nVolt;
	float		fVoltParam;

	for (i=0; i<(int)m_CompensatorArray.size(); i++)
	{
		if (isSubstationExclude(m_CompensatorArray[i].szSub, bNameByDesp))
		{
			//Log(g_lpszCimParserLogFile, "�޷����벹��, SubstationExclude: (%s) (%s) (%s)\n", m_CompensatorArray[i].szName, m_CompensatorArray[i].szSub, m_CompensatorArray[i].szVolt);
			continue;
		}

		if (strlen(m_CompensatorArray[i].szSub) <= 0)
		{
			Log(g_lpszLogFile, "�޷����벹��, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_CompensatorArray[i].szName, m_CompensatorArray[i].szSub, m_CompensatorArray[i].szVolt);
			continue;
		}
		if (strlen(m_CompensatorArray[i].szVolt) <= 0)
		{
			Log(g_lpszLogFile, "�޷����벹��, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_CompensatorArray[i].szName, m_CompensatorArray[i].szSub, m_CompensatorArray[i].szVolt);
			continue;
		}
		nVolt=-1;
		for (j=0; j<(int)m_VoltageLevelArray.size(); j++)
		{
			if (strcmp(m_VoltageLevelArray[j].szSub, m_CompensatorArray[i].szSub) == 0 &&
				strcmp(m_VoltageLevelArray[j].szName, m_CompensatorArray[i].szVolt) == 0)
			{
				nVolt=j;
				break;
			}
		}
		if (nVolt < 0)
		{
			Log(g_lpszLogFile, "�޷����벹��, �޵�ѹ�ȼ���Ϣ: (%s) (%s) (%s)\n", m_CompensatorArray[i].szName, m_CompensatorArray[i].szSub, m_CompensatorArray[i].szVolt);
			continue;
		}
		if (strlen(m_CompensatorArray[i].szNode1) <= 0)
		{
			Log(g_lpszLogFile, "�޷����벹��, �޽ڵ���Ϣ: (%s) (%s) (%s)\n", m_CompensatorArray[i].szName, m_CompensatorArray[i].szSub, m_CompensatorArray[i].szVolt);
			continue;
		}

		if (m_CompensatorArray[i].bSeries)
		{
			if (strlen(m_CompensatorArray[i].szNode2) <= 0)
			{
				Log(g_lpszLogFile, "�޷����봮������, �޽ڵ�2��Ϣ: (%s) (%s) (%s)\n", m_CompensatorArray[i].szName, m_CompensatorArray[i].szSub, m_CompensatorArray[i].szVolt);
				continue;
			}

			memset(&pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]], 0, sizeof(tagPGSeriesCompensator));
			strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szResID, m_CompensatorArray[i].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szName, m_CompensatorArray[i].szDesp);
			else
				strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szName, m_CompensatorArray[i].szName);
			strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szDesp, m_CompensatorArray[i].szDesp);
			strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szSub, m_CompensatorArray[i].szSub);
			strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szVolt, m_CompensatorArray[i].szVolt);
			strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szNodeI, m_CompensatorArray[i].szNode1);
			strcpy(pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].szNodeJ, m_CompensatorArray[i].szNode2);
			pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].fR=m_CompensatorArray[i].fSeriesR;
			pPGBlock->m_SeriesCompensatorArray[pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]].fX=m_CompensatorArray[i].fSeriesX;
			pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]++;
		}
		else
		{
			fVoltParam=1.0f;
			if (m_CompensatorArray[i].fNomV > 1)
				fVoltParam=m_VoltageLevelArray[nVolt].fNominal*m_VoltageLevelArray[nVolt].fNominal/(m_CompensatorArray[i].fNomV*m_CompensatorArray[i].fNomV);

			memset(&pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]], 0, sizeof(tagPGShuntCompensator));
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szResID, m_CompensatorArray[i].szResourceID);
			if (bNameByDesp)
				strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName, m_CompensatorArray[i].szDesp);
			else
				strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szName, m_CompensatorArray[i].szName);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szDesp, m_CompensatorArray[i].szDesp);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szSub, m_CompensatorArray[i].szSub);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szVolt, m_CompensatorArray[i].szVolt);
			strcpy(pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].szNode, m_CompensatorArray[i].szNode1);
			pPGBlock->m_ShuntCompensatorArray[pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]].fCap=(float)(m_CompensatorArray[i].fMvar*fVoltParam);
			pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]++;
		}
	}
}

void CCIMData::insertBusbarSection(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;

	for (i=0; i<(int)m_BusbarSectionArray.size(); i++)
	{
		if (isSubstationExclude(m_BusbarSectionArray[i].szSub, bNameByDesp))
			continue;
		if (strlen(m_BusbarSectionArray[i].szSub) <= 0)
		{
			Log(g_lpszLogFile, "�޷�����ĸ��, ��Substation��Ϣ: (%s) (%s) (%s) (%s)\n", m_BusbarSectionArray[i].szName, m_BusbarSectionArray[i].szSub, m_BusbarSectionArray[i].szVolt, m_BusbarSectionArray[i].szParentTag);
			continue;
		}
		if (strlen(m_BusbarSectionArray[i].szVolt) <= 0)
		{
			Log(g_lpszLogFile, "�޷�����ĸ��, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_BusbarSectionArray[i].szName, m_BusbarSectionArray[i].szSub, m_BusbarSectionArray[i].szVolt);
			continue;
		}
		if (strlen(m_BusbarSectionArray[i].szNode) <= 0)
		{
			Log(g_lpszLogFile, "�޷�����ĸ��, �޽ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_BusbarSectionArray[i].szName, m_BusbarSectionArray[i].szSub, m_BusbarSectionArray[i].szVolt, m_BusbarSectionArray[i].szNode);
			continue;
		}

		memset(&pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]], 0, sizeof(tagPGBusbarSection));
		if ((int)strlen(m_BusbarSectionArray[i].szResourceID) <  PGGetFieldLen(PG_BUSBARSECTION, PG_BUSBARSECTION_RESOURCEID))
			strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szResID, m_BusbarSectionArray[i].szResourceID);
		if (bNameByDesp)
			strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szName, m_BusbarSectionArray[i].szDesp);
		else
			strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szName, m_BusbarSectionArray[i].szName);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szDesp, m_BusbarSectionArray[i].szDesp);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szSub, m_BusbarSectionArray[i].szSub);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szVolt, m_BusbarSectionArray[i].szVolt);
		strcpy(pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].szNode, m_BusbarSectionArray[i].szNode);

//����ֵ�ſ�		register int	j;
//����ֵ�ſ�		for (j=0; j<m_VoltageLevelArray.size(); j++)
//����ֵ�ſ�		{
//����ֵ�ſ�			if (strcmp(m_BusbarSectionArray[i].szSub, m_VoltageLevelArray[j].szSub) == 0 &&
//����ֵ�ſ�				m_BusbarSectionArray[i].fVolt == m_VoltageLevelArray[j].fNominal)
//����ֵ�ſ�			{
//����ֵ�ſ�				if (m_BusbarSectionArray[i].fVoltageLimitH > 1)
//����ֵ�ſ�				{
//����ֵ�ſ�					pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimith=m_BusbarSectionArray[i].fVoltageLimitH;
//����ֵ�ſ�				}
//����ֵ�ſ�				else
//����ֵ�ſ�				{
//����ֵ�ſ�					if (m_VoltageLevelArray[j].fHLimit > 0)
//����ֵ�ſ�						pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimith=m_VoltageLevelArray[j].fHLimit;
//����ֵ�ſ�					else
//����ֵ�ſ�						pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimith=(float)(m_VoltageLevelArray[j].fNominal*1.1);
//����ֵ�ſ�				}
//����ֵ�ſ�
//����ֵ�ſ�				if (m_BusbarSectionArray[i].fVoltageLimitL > 1)
//����ֵ�ſ�				{
//����ֵ�ſ�					pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimitl=m_BusbarSectionArray[i].fVoltageLimitL;
//����ֵ�ſ�				}
//����ֵ�ſ�				else
//����ֵ�ſ�				{
//����ֵ�ſ�					if (m_VoltageLevelArray[j].fLLimit > 0)
//����ֵ�ſ�						pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimitl=m_VoltageLevelArray[j].fLLimit;
//����ֵ�ſ�					else
//����ֵ�ſ�						pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimitl=(float)(m_VoltageLevelArray[j].fNominal/1.05);
//����ֵ�ſ�				}
//����ֵ�ſ�				//pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].vlimitd=0.1;
//����ֵ�ſ�
//����ֵ�ſ�				if (m_BusbarSectionArray[i].fFrequencyLimitH > 1)
//����ֵ�ſ�					pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].flimith=m_BusbarSectionArray[i].fFrequencyLimitH;
//����ֵ�ſ�				else
//����ֵ�ſ�					pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].flimith=50.5;
//����ֵ�ſ�				if (m_BusbarSectionArray[i].fFrequencyLimitL > 1)
//����ֵ�ſ�					pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].flimitl=m_BusbarSectionArray[i].fFrequencyLimitL;
//����ֵ�ſ�				else
//����ֵ�ſ�					pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].flimitl=49.5;
//����ֵ�ſ�
//							pPGBlock->m_BusbarSectionArray[pPGBlock->m_nRecordNum[PG_BUSBARSECTION]].flimitd=0.001;
//����ֵ�ſ�
//����ֵ�ſ�			}
//����ֵ�ſ�		}

		pPGBlock->m_nRecordNum[PG_BUSBARSECTION]++;
	}
}

void CCIMData::insertBreak(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;

	for (i=0; i<(int)m_BreakerArray.size(); i++)
	{
		if (isSubstationExclude(m_BreakerArray[i].strSub.c_str(), bNameByDesp))
			continue;

		if (m_BreakerArray[i].strSub.empty())
		{
			Log(g_lpszLogFile, "�޷����뿪��, ��Substation��Ϣ: (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].strName.c_str(), m_BreakerArray[i].strSub.c_str(), m_BreakerArray[i].strVolt.c_str(), m_BreakerArray[i].strParentTag.c_str());
			continue;
		}
		if (m_BreakerArray[i].strVolt.empty())
		{
			Log(g_lpszLogFile, "�޷����뿪��, ��Voltage��Ϣ: (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].strName.c_str(), m_BreakerArray[i].strSub.c_str(), m_BreakerArray[i].strVolt.c_str(), m_BreakerArray[i].strParentTag.c_str());
			continue;
		}
		if (m_BreakerArray[i].strNode[0].empty())
		{
			Log(g_lpszLogFile, "�޷����뿪��, ��I�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].strName.c_str(), m_BreakerArray[i].strSub.c_str(), m_BreakerArray[i].strVolt.c_str(), m_BreakerArray[i].strNode[0].c_str(), m_BreakerArray[i].strNode[1].c_str());
			continue;
		}
		if (m_BreakerArray[i].strNode[1].empty())
		{
			Log(g_lpszLogFile, "�޷����뿪��, ��J�ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_BreakerArray[i].strName.c_str(), m_BreakerArray[i].strSub.c_str(), m_BreakerArray[i].strVolt.c_str(), m_BreakerArray[i].strNode[0].c_str(), m_BreakerArray[i].strNode[1].c_str());
			continue;
		}

		memset(&pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]], 0, sizeof(tagPGBreaker));
		if ((int)m_BreakerArray[i].strResourceID.length() < PGGetFieldLen(PG_BREAKER, PG_BREAKER_RESOURCEID))
			strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szResID, m_BreakerArray[i].strResourceID.c_str());
		if (bNameByDesp)
			strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szName, m_BreakerArray[i].strDesp.c_str());
		else
			strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szName, m_BreakerArray[i].strName.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szDesp, m_BreakerArray[i].strDesp.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szSub, m_BreakerArray[i].strSub.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szVolt, m_BreakerArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szNodeI, m_BreakerArray[i].strNode[0].c_str());
		strcpy(pPGBlock->m_BreakerArray[pPGBlock->m_nRecordNum[PG_BREAKER]].szNodeJ, m_BreakerArray[i].strNode[1].c_str());
		pPGBlock->m_nRecordNum[PG_BREAKER]++;
	}
}

void CCIMData::insertDisconnector(tagPGBlock* pPGBlock, const int bNameByDesp)
{
	register int	i;

	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
	{
		if (isSubstationExclude(m_DisconnectorArray[i].strSub.c_str(), bNameByDesp))
			continue;
		if (m_DisconnectorArray[i].strSub.empty())
		{
			Log(g_lpszLogFile, "�޷����뵶բ, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_DisconnectorArray[i].strName.c_str(), m_DisconnectorArray[i].strSub.c_str(), m_DisconnectorArray[i].strVolt.c_str());
			continue;
		}
		if (m_DisconnectorArray[i].strVolt.empty())
		{
			Log(g_lpszLogFile, "�޷����뵶բ, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_DisconnectorArray[i].strName.c_str(), m_DisconnectorArray[i].strSub.c_str(), m_DisconnectorArray[i].strVolt.c_str());
			continue;
		}

		if (m_DisconnectorArray[i].strNode[0].empty())
		{
			Log(g_lpszLogFile, "�޷����뵶բ, ��I��ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_DisconnectorArray[i].strName.c_str(), m_DisconnectorArray[i].strSub.c_str(), m_DisconnectorArray[i].strVolt.c_str(), m_DisconnectorArray[i].strNode[0].c_str(), m_DisconnectorArray[i].strNode[1].c_str());
			continue;
		}
		if (m_DisconnectorArray[i].strNode[1].empty())
		{
			Log(g_lpszLogFile, "�޷����뵶բ, ��J��ڵ���Ϣ: (%s) (%s) (%s) (%s) (%s)\n", m_DisconnectorArray[i].strName.c_str(), m_DisconnectorArray[i].strSub.c_str(), m_DisconnectorArray[i].strVolt.c_str(), m_DisconnectorArray[i].strNode[0].c_str(), m_DisconnectorArray[i].strNode[1].c_str());
			continue;
		}

		memset(&pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]], 0, sizeof(tagPGDisconnector));
		if ((int)m_DisconnectorArray[i].strResourceID.length() < PGGetFieldLen(PG_DISCONNECTOR, PG_DISCONNECTOR_RESOURCEID))
			strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szResID, m_DisconnectorArray[i].strResourceID.c_str());
		if (bNameByDesp)
			strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szName, m_DisconnectorArray[i].strDesp.c_str());
		else
			strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szName, m_DisconnectorArray[i].strName.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szDesp, m_DisconnectorArray[i].strDesp.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szSub , m_DisconnectorArray[i].strSub.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szVolt, m_DisconnectorArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szNodeI, m_DisconnectorArray[i].strNode[0].c_str());
		strcpy(pPGBlock->m_DisconnectorArray[pPGBlock->m_nRecordNum[PG_DISCONNECTOR]].szNodeJ, m_DisconnectorArray[i].strNode[1].c_str());
		pPGBlock->m_nRecordNum[PG_DISCONNECTOR]++;
	}

	for (i=0; i<(int)m_GroundDisconnectorArray.size(); i++)
	{
		if (isSubstationExclude(m_GroundDisconnectorArray[i].strSub.c_str(), bNameByDesp))
			continue;
		if (m_GroundDisconnectorArray[i].strSub.empty())
		{
			//Log(g_lpszCimParserLogFile, "�޷�����ص�, ��Substation��Ϣ: (%s) (%s) (%s)\n", m_GroundDisconnectorArray[i].strName.c_str(), m_GroundDisconnectorArray[i].strSub.c_str(), m_GroundDisconnectorArray[i].strVolt.c_str());
			continue;
		}
		if (m_GroundDisconnectorArray[i].strVolt.empty())
		{
			//Log(g_lpszCimParserLogFile, "�޷�����ص�, ��Voltage��Ϣ: (%s) (%s) (%s)\n", m_GroundDisconnectorArray[i].strName.c_str(), m_GroundDisconnectorArray[i].strSub.c_str(), m_GroundDisconnectorArray[i].strVolt.c_str());
			continue;
		}
		if (m_GroundDisconnectorArray[i].strNode.empty())
		{
			//Log(g_lpszCimParserLogFile, "�޷�����ص�, �޽ڵ���Ϣ: (%s) (%s) (%s) (%s)\n", m_GroundDisconnectorArray[i].strName.c_str(), m_GroundDisconnectorArray[i].strSub.c_str(), m_GroundDisconnectorArray[i].strVolt.c_str(), m_GroundDisconnectorArray[i].strNode.c_str());
			continue;
		}

		memset(&pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]], 0, sizeof(tagPGGroundDisconnector));
		strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szResID, m_GroundDisconnectorArray[i].strResourceID.c_str());
		if (bNameByDesp)
			strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szName, m_GroundDisconnectorArray[i].strDesp.c_str());
		else
			strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szName, m_GroundDisconnectorArray[i].strName.c_str());
		strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szDesp, m_GroundDisconnectorArray[i].strDesp.c_str());
		strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szSub, m_GroundDisconnectorArray[i].strSub.c_str());
		strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szVolt, m_GroundDisconnectorArray[i].strVolt.c_str());
		strcpy(pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].szNode, m_GroundDisconnectorArray[i].strNode.c_str());
		pPGBlock->m_GroundDisconnectorArray[pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]].nStatus=1;
		pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]++;
	}
}

void CCIMData::insertTrantap(tagPGBlock* pPGBlock)
{
	register int	i;
	int		nTap, bExist;

	for (i=0; i<(int)m_TapChangerArray.size(); i++)
	{
		if (m_TapChangerArray[i].nHighStep == m_TapChangerArray[i].nLowStep)
		{
			m_TapChangerArray[i].nHighStep = m_TapChangerArray[i].nLowStep = m_TapChangerArray[i].nNeutralStep =0;
			m_TapChangerArray[i].fStepVoltageIncrement=0;
		}
		bExist=0;
		for (nTap=0; nTap<pPGBlock->m_nRecordNum[PG_TAPCHANGER]; nTap++)
		{
			if (pPGBlock->m_TapChangerArray[nTap].nTapMin == m_TapChangerArray[i].nLowStep &&
					pPGBlock->m_TapChangerArray[nTap].nTapMax == m_TapChangerArray[i].nHighStep &&
					pPGBlock->m_TapChangerArray[nTap].nTapNom == m_TapChangerArray[i].nNeutralStep &&
					pPGBlock->m_TapChangerArray[nTap].fTapStep == m_TapChangerArray[i].fStepVoltageIncrement)
			{
				bExist=1;
				strcpy(m_TapChangerArray[i].szLocalTapName, pPGBlock->m_TapChangerArray[nTap].szName);
				break;
			}
		}
		if (!bExist)
		{
			memset(&pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]], 0, sizeof(tagPGTapChanger));

			if (strlen(m_TapChangerArray[i].szDesp) > 0)
				sprintf(pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]].szName, m_TapChangerArray[i].szDesp);
			else
				sprintf(pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]].szName, "�ֽ�ͷ%.2d", pPGBlock->m_nRecordNum[PG_TAPCHANGER]);
			pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]].nTapMin=m_TapChangerArray[i].nLowStep;
			pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]].nTapMax=m_TapChangerArray[i].nHighStep;
			pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]].nTapNeu=m_TapChangerArray[i].nNeutralStep;
			if (fabs(m_TapChangerArray[i].fStepVoltageIncrement) > 10)
				m_TapChangerArray[i].fStepVoltageIncrement = 0;
			pPGBlock->m_TapChangerArray[pPGBlock->m_nRecordNum[PG_TAPCHANGER]].fTapStep=m_TapChangerArray[i].fStepVoltageIncrement;
			pPGBlock->m_nRecordNum[PG_TAPCHANGER]++;
		}
		else
		{
		}
	}
}
