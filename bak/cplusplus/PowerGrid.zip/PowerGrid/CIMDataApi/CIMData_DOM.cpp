// CIMData.cpp: implementation of the CCIMData class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CIMData.h"
#include "../../../Common/String2Double.hpp"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


int CCIMData::ParseXmlByDom(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement)
{
	int		nRet=0;
	int		nIniDepth=0;

	m_bParseMeasurement=bParseMeasurement;

	TiXmlDocument*	pXmlDoc = new TiXmlDocument(lpszFileName);
	if (pXmlDoc->LoadFile())
	{
		TiXmlElement*	pRoot= pXmlDoc->RootElement();	//��Ԫ��
		parseCim(pRoot, nIniDepth, bParseMeasurement);
		nRet=1;
	}
	delete pXmlDoc;

	return nRet;
}

void CCIMData::parseCim(TiXmlElement* pElement, int nDepth, const int bParseMeasurement)
{
	char	szBuf[260];

	if (!pElement)
		return;

	nDepth++;

	if (nDepth == 2)
	{
		strcpy(szBuf, pElement->Value());
		if (STRICMP(szBuf, "cim:BasePower") == 0)													parseBasePower(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:BaseVoltage") == 0)											parseBaseVoltage(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:SubcontrolArea") == 0 || STRICMP(szBuf, "cim:Company") == 0)	parseSubcontrolArea(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Substation") == 0)												parseSubstation(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:VoltageLevel") == 0)											parseVoltageLevel(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Bay") == 0)													parseBay(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:ACLineSegment") == 0)											parseACLineSegment(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:DCLineSegment") == 0)											parseDCLineSegment(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:TransformerWinding") == 0)										parseTransformerWinding(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:PowerTransformer") == 0)										parsePowerTransformer(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:TapChanger") == 0)												parseTapChanger(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:EnergyConsumer") == 0)											parseEnergyConsumer(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:SynchronousMachine") == 0)										parseSynchronousMachine(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:ThermalGeneratingUnit") == 0)									parseThermalGeneratingUnit(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:HydroGeneratingUnit") == 0)									parseHydroGeneratingUnit(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Compensator") == 0)											parseCompensator(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:BusbarSection") == 0)											parseBusbarSection(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:RectifierInverter") == 0)										parseRectifierInverter(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Breaker") == 0)												parseBreaker(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Disconnector") == 0)											parseDisconnector(nDepth, szBuf, pElement);
		//else if (STRICMP(szBuf, "cim:DCSwitch") == 0)												parseDisconnector(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:GroundDisconnector") == 0)										parseGroundDisconnector(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Terminal") == 0)												parseTerminal(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:ConnectivityNode") == 0)										parseConnectivityNode(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:MeasurementType") == 0 && bParseMeasurement)					parseMeasurementType(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:MeasurementValue") == 0 && bParseMeasurement)					parseMeasurementValue(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:MeasurementValueSource") == 0 && bParseMeasurement)			parseMeasurementSource(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Measurement") == 0 && bParseMeasurement)						parseMeasurement(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Analog") == 0 && bParseMeasurement)							parseAnalog(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Discrete") == 0 && bParseMeasurement)							parseDiscrete(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:LimitSet") == 0 && bParseMeasurement)							parseLimitSet(nDepth, szBuf, pElement);
		else if (STRICMP(szBuf, "cim:Limit") == 0 && bParseMeasurement)								parseLimit(nDepth, szBuf, pElement);
	}
	if (nDepth <= 2)
	{
		pElement=pElement->FirstChildElement();
		while (pElement)
		{
			parseCim(pElement, nDepth, bParseMeasurement);
			pElement=pElement->NextSiblingElement();
		}
	}
}

int	CCIMData::readElement(TiXmlElement* pElement, const int nDepth, const char* lpszParent, const char* lpszElement, char* lpszRet)
{
	if (!pElement)
		return 0;

	TiXmlNode* pEle=pElement->FirstChild();
	if (pEle && pEle == pElement->LastChild() && pEle->Type() == TiXmlElement::TINYXML_TEXT)
	{
		strcpy(lpszRet, pEle->Value());
		StringRemove(lpszRet, ' ');
	}
	else
	{
		return 0;
	}

	return 1;
}

int	CCIMData::readAttribute(TiXmlElement* pElement, const int nDepth, const char* lpszElement, const char* lpszAttribute, char* lpszRet)
{
	char	szBuf[2*MDB_CHARLEN];
	if (!pElement)
		return 0;

	TiXmlAttribute*	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		if (STRICMP(lpszAttribute, pAttr->Name()) == 0)
		{
			strcpy(szBuf, pAttr->Value());
			StringRemove(szBuf, ' ');
			if (szBuf[0] == '#')
				strcpy(lpszRet, (char*)(szBuf+1));
			else
				strcpy(lpszRet, szBuf);
			return 1;
		}
		pAttr=pAttr->Next();
	}

	return 0;
}

int	CCIMData::readAttribute(TiXmlAttribute* pAttr, const char* lpszAttribute, char* lpszRet)
{
	char	szBuf[2*MDB_CHARLEN];
	if (!pAttr)
		return 0;

	strcpy(szBuf, pAttr->Value());
	StringRemove(szBuf, ' ');
	if (szBuf[0] == '#')
		strcpy(lpszRet, (char*)(szBuf+1));
	else
		strcpy(lpszRet, szBuf);

	return 1;
}

void	CCIMData::parseBasePower(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_BasePower);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillBasePower(&m_BasePower, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillBasePower(&m_BasePower, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillBasePower(&m_BasePower, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}
}

void	CCIMData::parseBaseVoltage(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szBuf[2*MDB_CHARLEN];
	char	szName[128];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_BaseVoltage);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillBaseVoltage(&m_BaseVoltageBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement != NULL)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillBaseVoltage(&m_BaseVoltageBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillBaseVoltage(&m_BaseVoltageBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_BaseVoltage);
}

void	CCIMData::parseSubcontrolArea(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_SubcontrolArea);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillSubcontrolArea(&m_SubcontrolAreaBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillSubcontrolArea(&m_SubcontrolAreaBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillSubcontrolArea(&m_SubcontrolAreaBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_SubcontrolArea);
}

void	CCIMData::parseSubstation(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Substation);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillSubstation(&m_SubstationBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillSubstation(&m_SubstationBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillSubstation(&m_SubstationBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Substation);
}

void	CCIMData::parseVoltageLevel(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_VoltageLevel);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillVoltageLevel(&m_VoltageLevelBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillVoltageLevel(&m_VoltageLevelBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillVoltageLevel(&m_VoltageLevelBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_VoltageLevel);
}

void	CCIMData::parseBay(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Bay);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillBay(&m_BayBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillBay(&m_BayBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillBay(&m_BayBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Bay);
}

void	CCIMData::parseACLineSegment(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szBuf[2*MDB_CHARLEN];
	char	szName[128];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_ACLineSegment);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillACLineSegment(&m_ACLineSegmentBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillACLineSegment(&m_ACLineSegmentBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillACLineSegment(&m_ACLineSegmentBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_ACLineSegment);
}

void	CCIMData::parseDCLineSegment(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szBuf[2*MDB_CHARLEN];
	char	szName[128];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_DCLineSegment);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillDCLineSegment(&m_DCLineSegmentBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillDCLineSegment(&m_DCLineSegmentBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillDCLineSegment(&m_DCLineSegmentBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_DCLineSegment);
}

void	CCIMData::parseTransformerWinding(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_TransformerWinding);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillTransformerWinding(&m_TransformerWindingBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillTransformerWinding(&m_TransformerWindingBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillTransformerWinding(&m_TransformerWindingBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_TransformerWinding);
}

void	CCIMData::parsePowerTransformer(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_PowerTransformer);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillPowerTransformer(&m_PowerTransformerBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillPowerTransformer(&m_PowerTransformerBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillPowerTransformer(&m_PowerTransformerBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_PowerTransformer);
}

void	CCIMData::parseTapChanger(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_TapChanger);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillTapChanger(&m_TapChangerBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillTapChanger(&m_TapChangerBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillTapChanger(&m_TapChangerBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_TapChanger);
}

void	CCIMData::parseSynchronousMachine(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_SynchronousMachine);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillSynchronousMachine(&m_SynchronousMachineBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillSynchronousMachine(&m_SynchronousMachineBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillSynchronousMachine(&m_SynchronousMachineBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_SynchronousMachine);
}

void	CCIMData::parseThermalGeneratingUnit(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_ThermalGeneratingUnit);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillThermalGeneratingUnit(&m_ThermalGeneratingUnitBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillThermalGeneratingUnit(&m_ThermalGeneratingUnitBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillThermalGeneratingUnit(&m_ThermalGeneratingUnitBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_ThermalGeneratingUnit);
}

void	CCIMData::parseHydroGeneratingUnit(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_HydroGeneratingUnit);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillHydroGeneratingUnit(&m_HydroGeneratingUnitBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillHydroGeneratingUnit(&m_HydroGeneratingUnitBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillHydroGeneratingUnit(&m_HydroGeneratingUnitBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_HydroGeneratingUnit);
}

void	CCIMData::parseEnergyConsumer(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_EnergyConsumer);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillEnergyConsumer(&m_EnergyConsumerBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillEnergyConsumer(&m_EnergyConsumerBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillEnergyConsumer(&m_EnergyConsumerBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_EnergyConsumer);
}

void	CCIMData::parseCompensator(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Compensator);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillCompensator(&m_CompensatorBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillCompensator(&m_CompensatorBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillCompensator(&m_CompensatorBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Compensator);
}

void	CCIMData::parseRectifierInverter(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_RectifierInverter);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillRectifierInverter(&m_RectifierInverterBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillRectifierInverter(&m_RectifierInverterBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillRectifierInverter(&m_RectifierInverterBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_RectifierInverter);
}

void	CCIMData::parseBusbarSection(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char	szName[128];
	char	szBuf[2*MDB_CHARLEN];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_BusbarSection);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillBusbarSection(&m_BusbarSectionBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillBusbarSection(&m_BusbarSectionBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillBusbarSection(&m_BusbarSectionBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_BusbarSection);
}

void	CCIMData::parseBreaker(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Breaker);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillBreaker(&m_BreakerBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillBreaker(&m_BreakerBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillBreaker(&m_BreakerBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Breaker);
}

void	CCIMData::parseDisconnector(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Disconnector);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillDisconnector(&m_DisconnectorBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillDisconnector(&m_DisconnectorBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillDisconnector(&m_DisconnectorBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Disconnector);
}

void	CCIMData::parseGroundDisconnector(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_GroundDisconnector);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillGroundDisconnector(&m_GroundDisconnectorBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillGroundDisconnector(&m_GroundDisconnectorBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillGroundDisconnector(&m_GroundDisconnectorBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_GroundDisconnector);
}

void	CCIMData::parseTerminal(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Terminal);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillTerminal(&m_TerminalBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillTerminal(&m_TerminalBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillTerminal(&m_TerminalBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Terminal);
}

void	CCIMData::parseConnectivityNode(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_ConnectivityNode);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillConnectivityNode(&m_ConnectivityNodeBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillConnectivityNode(&m_ConnectivityNodeBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillConnectivityNode(&m_ConnectivityNodeBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_ConnectivityNode);
}

void	CCIMData::parseMeasurementType(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_MeasurementType);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillMeasurementType(&m_MeasurementTypeBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillMeasurementType(&m_MeasurementTypeBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillMeasurementType(&m_MeasurementTypeBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_MeasurementType);
}

void	CCIMData::parseMeasurementSource(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_MeasurementSource);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillMeasurementSource(&m_MeasurementSourceBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillMeasurementSource(&m_MeasurementSourceBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillMeasurementSource(&m_MeasurementSourceBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_MeasurementSource);
}

void	CCIMData::parseMeasurementValue(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_MeasurementValue);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillMeasurementValue(&m_MeasurementValueBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillMeasurementValue(&m_MeasurementValueBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillMeasurementValue(&m_MeasurementValueBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_MeasurementValue);
}

void	CCIMData::parseMeasurement(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Measurement);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillMeasurement(&m_MeasurementBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillMeasurement(&m_MeasurementBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillMeasurement(&m_MeasurementBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Measurement);
}

void	CCIMData::parseAnalog(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Analog);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillAnalog(&m_AnalogBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillAnalog(&m_AnalogBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillAnalog(&m_AnalogBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Analog);
}

void	CCIMData::parseDiscrete(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_Discrete);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillDiscrete(&m_DiscreteBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillDiscrete(&m_DiscreteBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillDiscrete(&m_DiscreteBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_Discrete);
}

void	CCIMData::parseLimitSet(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_LimitSet);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillLimitSet(&m_LimitSetBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillLimitSet(&m_LimitSetBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillLimitSet(&m_LimitSetBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_LimitSet);
}

void	CCIMData::parseLimit(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement)
{
	char		szName[128];
	char		szBuf[260];
	TiXmlAttribute*	pAttr;

	if (!pElement)
		return;
	PrepareElementBuffer(CIM_LimitSet);

	pAttr=pElement->FirstAttribute();
	while (pAttr != NULL)
	{
		strcpy(szName, pAttr->Name());
		if (readAttribute(pAttr, szName, szBuf))
			fillLimit(&m_LimitBuf, szName, szBuf);

		pAttr=pAttr->Next();
	}

	pElement=pElement->FirstChildElement();
	while (pElement)
	{
		pAttr=pElement->FirstAttribute();
		while (pAttr != NULL)
		{
			strcpy(szName, pAttr->Name());
			if (readAttribute(pAttr, szName, szBuf))
				fillLimit(&m_LimitBuf, szName, szBuf);

			pAttr=pAttr->Next();
		}

		strcpy(szName, pElement->Value());
		if (readElement(pElement, nDepth, lpszNodeName, szName, szBuf))
			fillLimit(&m_LimitBuf, szName, szBuf);

		pElement=pElement->NextSiblingElement();
	}

	AppendElementBuffer(CIM_LimitSet);
}
