// CIMDataApi.cpp : ���� DLL Ӧ�ó���ĵ���������
//

#include "stdafx.h"
#include "CIMDataApi.h"
#include "CIMData.h"
#include "CIMDataTable.h"
#include "CIMDataField.h"


extern	void	ClearLog(const char* lpszLogFile);
const	char*	g_lpszLogFile="CimXmlParser.log";

// �����ѵ�����Ĺ��캯����
// �й��ඨ�����Ϣ������� CIMDataApi.h
CCIMData::CCIMData()
{
	ClearLog(g_lpszLogFile);
	Release();
}

const int	CCIMData::GetCIMTableNum()
{
	return sizeof(g_CIMTableArray)/sizeof(tagCIMNameDesp);
}

const char*	CCIMData::GetCIMTableName(const int nTable)
{
	return g_CIMTableArray[nTable].szName;
}

const char*	CCIMData::GetCIMTableDesp(const int nTable)
{
	return g_CIMTableArray[nTable].szDesp;
}

const int	CCIMData::GetCIMTableID(const int nTable)
{
	return g_CIMTableArray[nTable].nID;
}

const int	CCIMData::GetCIMTableFieldNum(const int nTable)
{
	switch (nTable)
	{
	case	CIM_BasePower:	//	BaseVoltage
		return sizeof(g_BasePowerAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_BaseVoltage:	//	BaseVoltage
		return sizeof(g_BaseVoltageAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
// 	case	CIM_Company:	//	Company
// 		return sizeof(g_CompanyAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		break;
	case	CIM_SubcontrolArea:	//	SubcontrolArea
		return sizeof(g_SubcontrolAreaAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Substation:	//	Substation
		return sizeof(g_SubstationAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_VoltageLevel:	//	VoltageLevel
		return sizeof(g_VoltageLevelAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Bay:	//	Bay
		return sizeof(g_BayAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_ACLineSegment:	//	ACLineSegment
		return sizeof(g_ACLineSegmentAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_DCLineSegment:	//	DCLineSegment
		return sizeof(g_DCLineSegmentAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_RectifierInverter:	//	RectifierInverter
		return sizeof(g_RectifierInverterAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_TransformerWinding:	//	TransformerWinding
		return sizeof(g_TransformerWindingAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_PowerTransformer:	//	PowerTransformer
		return sizeof(g_PowerTransformerAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_TapChanger:	//	TapChanger
		return sizeof(g_TapChangerAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_SynchronousMachine:	//	SynchronousMachine
		return sizeof(g_SynchronousMachineAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_ThermalGeneratingUnit:	//	ThermalGeneratingUnit
		return sizeof(g_ThermalGeneratingUnitAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_HydroGeneratingUnit:	//	HydroGeneratingUnit
		return sizeof(g_HydroGeneratingUnitAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_EnergyConsumer:	//	EnergyConsumer
		return sizeof(g_EnergyConsumerAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Compensator:	//	Compensator
		return sizeof(g_CompensatorAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_BusbarSection:	//	BusbarSection
		return sizeof(g_BusbarSectionAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Breaker:	//	Breaker
		return sizeof(g_BreakerAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_DCSwitch:
	case	CIM_Disconnector:	//	Disconnector
		return sizeof(g_DisconnectorAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_GroundDisconnector:	//	GroundDisconnector
		return sizeof(g_GroundDisconnectorAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Terminal:	//	Terminal
		return sizeof(g_TerminalAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_ConnectivityNode:	//	ConnectivityNode
		return sizeof(g_ConnectivityNodeAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_MeasurementType:	//	��������
		return sizeof(g_MeasurementTypeAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_MeasurementSource:	//	������Դ
		return sizeof(g_MeasurementSourceAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_MeasurementValue:	//	����ֵ
		return sizeof(g_MeasurementValueAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Measurement:	//	����
		return sizeof(g_MeasurementAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Analog:	//	ң��
		return sizeof(g_AnalogAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Discrete:	//	ң��
		return sizeof(g_DiscreteAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_LimitSet:	//	LimitSets
		return sizeof(g_LimitSetAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	case	CIM_Limit:	//	Limits
		return sizeof(g_LimitAttrArray)/sizeof(tagCIMXmlEleDesp);
		break;
	default:
		break;
	}
	return 0;
}

const char*	CCIMData::GetCIMTableFieldDesp(const int nTable, const int nField)
{
	switch (nTable)
	{
	case	CIM_BasePower:	//	BaseVoltage
		return g_BasePowerAttrArray[nField].szDesp;
		break;
	case	CIM_BaseVoltage:	//	BaseVoltage
		return g_BaseVoltageAttrArray[nField].szDesp;
		break;
// 	case	CIM_Company:	//	Company
// 		return g_CompanyAttrArray[nField].szDesp;
// 		break;
	case	CIM_SubcontrolArea:	//	SubcontrolArea
		return g_SubcontrolAreaAttrArray[nField].szDesp;
		break;
	case	CIM_Substation:	//	Substation
		return g_SubstationAttrArray[nField].szDesp;
		break;
	case	CIM_VoltageLevel:	//	VoltageLevel
		return g_VoltageLevelAttrArray[nField].szDesp;
		break;
	case	CIM_Bay:	//	Bay
		return g_BayAttrArray[nField].szDesp;
		break;
	case	CIM_ACLineSegment:	//	ACLineSegment
		return g_ACLineSegmentAttrArray[nField].szDesp;
		break;
	case	CIM_DCLineSegment:	//	DCLineSegment
		return g_DCLineSegmentAttrArray[nField].szDesp;
		break;
	case	CIM_RectifierInverter:	//	RectifierInverter
		return g_RectifierInverterAttrArray[nField].szDesp;
		break;
	case	CIM_TransformerWinding:	//	TransformerWinding
		return g_TransformerWindingAttrArray[nField].szDesp;
		break;
	case	CIM_PowerTransformer:	//	PowerTransformer
		return g_PowerTransformerAttrArray[nField].szDesp;
		break;
	case	CIM_TapChanger:	//	TapChanger
		return g_TapChangerAttrArray[nField].szDesp;
		break;
	case	CIM_SynchronousMachine:	//	SynchronousMachine
		return g_SynchronousMachineAttrArray[nField].szDesp;
		break;
	case	CIM_EnergyConsumer:	//	EnergyConsumer
		return g_EnergyConsumerAttrArray[nField].szDesp;
		break;
	case	CIM_Compensator:	//	Compensator
		return g_CompensatorAttrArray[nField].szDesp;
		break;
	case	CIM_BusbarSection:	//	BusbarSection
		return g_BusbarSectionAttrArray[nField].szDesp;
		break;
	case	CIM_Breaker:	//	Breaker
		return g_BreakerAttrArray[nField].szDesp;
		break;
	case	CIM_DCSwitch:
	case	CIM_Disconnector:	//	Disconnector
		return g_DisconnectorAttrArray[nField].szDesp;
		break;
	case	CIM_GroundDisconnector:	//	GroundDisconnector
		return g_GroundDisconnectorAttrArray[nField].szDesp;
		break;
	case	CIM_Terminal:	//	Terminal
		return g_TerminalAttrArray[nField].szDesp;
		break;
	case	CIM_ConnectivityNode:	//	ConnectivityNode
		return g_ConnectivityNodeAttrArray[nField].szDesp;
		break;
	case	CIM_MeasurementType:	//	��������
		return g_MeasurementTypeAttrArray[nField].szDesp;
		break;
	case	CIM_MeasurementSource:	//	������Դ
		return g_MeasurementSourceAttrArray[nField].szDesp;
		break;
	case	CIM_MeasurementValue:	//	����ֵ
		return g_MeasurementValueAttrArray[nField].szDesp;
		break;
	case	CIM_Measurement:	//	����
		return g_MeasurementAttrArray[nField].szDesp;
		break;
	case	CIM_Analog:	//	ң��
		return g_AnalogAttrArray[nField].szDesp;
		break;
	case	CIM_Discrete:	//	ң��
		return g_DiscreteAttrArray[nField].szDesp;
		break;
	case	CIM_LimitSet:	//	LimitSets
		return g_LimitSetAttrArray[nField].szDesp;
		break;
	case	CIM_Limit:	//	Limits
		return g_LimitAttrArray[nField].szDesp;
		break;
	default:
		break;
	}
	return "";
}