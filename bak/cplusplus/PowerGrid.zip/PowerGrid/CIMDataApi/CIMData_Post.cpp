#include "stdafx.h"
#include "CIMData.h"

int CCIMData::eraseExVoltageLevel(tagPGBlock* pBlock, std::vector<std::string>& strExVoltageLevelArray)
{
	register int	i;
	int		nVolt, nDev;
	unsigned char	bErase;
	char	szVoltIdent[260], szDevIdent[260];

	std::vector<unsigned char>	bACLineSegmentStateArray;
	std::vector<unsigned char>	bTransformerWindingStateArray;
	std::vector<unsigned char>	bBusbarSectionStateArray;
	std::vector<unsigned char>	bBreakerStateArray;
	std::vector<unsigned char>	bDisconnectorStateArray;
	std::vector<unsigned char>	bSynchronousMachineStateArray;
	std::vector<unsigned char>	bEnergyConsumerStateArray;
	std::vector<unsigned char>	bShuntCompensatorStateArray;
	std::vector<unsigned char>	bSeriesCompensatorStateArray;

	bACLineSegmentStateArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	bTransformerWindingStateArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	bBusbarSectionStateArray.resize(pBlock->m_nRecordNum[PG_BUSBARSECTION]);
	bBreakerStateArray.resize(pBlock->m_nRecordNum[PG_BREAKER]);
	bDisconnectorStateArray.resize(pBlock->m_nRecordNum[PG_DISCONNECTOR]);
	bSynchronousMachineStateArray.resize(pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);
	bEnergyConsumerStateArray.resize(pBlock->m_nRecordNum[PG_ENERGYCONSUMER]);
	bShuntCompensatorStateArray.resize(pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]);
	bSeriesCompensatorStateArray.resize(pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]);

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		bACLineSegmentStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; i++)
		bTransformerWindingStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		bBusbarSectionStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
		bBreakerStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
		bDisconnectorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		bSynchronousMachineStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		bEnergyConsumerStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; i++)
		bShuntCompensatorStateArray[i]=0;
	for (i=0; i<pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; i++)
		bSeriesCompensatorStateArray[i]=0;

	for (nVolt=0; nVolt<pBlock->m_nRecordNum[PG_VOLTAGELEVEL]; nVolt++)
	{
		sprintf(szVoltIdent, "%s.%s", pBlock->m_VoltageLevelArray[nVolt].szSub, pBlock->m_VoltageLevelArray[nVolt].szName);

		bErase=0;
		for (i=0; i<(int)strExVoltageLevelArray.size(); i++)
		{
			if (stricmp(szVoltIdent, strExVoltageLevelArray[i].c_str()) == 0)
			{
				bErase=1;
				break;
			}
		}
		if (bErase)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_BusbarSectionArray[nDev].szSub, pBlock->m_BusbarSectionArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bBusbarSectionStateArray[nDev]=1;
			}
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_SynchronousMachineArray[nDev].szSub, pBlock->m_SynchronousMachineArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bSynchronousMachineStateArray[nDev]=1;
			}
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_EnergyConsumerArray[nDev].szSub, pBlock->m_EnergyConsumerArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bEnergyConsumerStateArray[nDev]=1;
			}
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_ShuntCompensatorArray[nDev].szSub, pBlock->m_ShuntCompensatorArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bShuntCompensatorStateArray[nDev]=1;
			}
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSeriesCompensatorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSeriesCompensatorRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_SeriesCompensatorArray[nDev].szSub, pBlock->m_SeriesCompensatorArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bSeriesCompensatorStateArray[nDev]=1;
			}
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_BreakerArray[nDev].szSub, pBlock->m_BreakerArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bBreakerStateArray[nDev]=1;
			}
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_DisconnectorArray[nDev].szSub, pBlock->m_DisconnectorArray[nDev].szVolt);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bDisconnectorStateArray[nDev]=1;
			}
			for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szVoltI);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bACLineSegmentStateArray[nDev] += 1;
				sprintf(szDevIdent, "%s.%s", pBlock->m_ACLineSegmentArray[nDev].szSubJ, pBlock->m_ACLineSegmentArray[nDev].szVoltJ);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bACLineSegmentStateArray[nDev] += 2;
			}
			for (nDev=0; nDev<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
			{
				sprintf(szDevIdent, "%s.%s", pBlock->m_TransformerWindingArray[nDev].szSub, pBlock->m_TransformerWindingArray[nDev].szVoltI);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bTransformerWindingStateArray[nDev]=1;
				sprintf(szDevIdent, "%s.%s", pBlock->m_TransformerWindingArray[nDev].szSub, pBlock->m_TransformerWindingArray[nDev].szVoltJ);
				if (stricmp(szVoltIdent, szDevIdent) == 0)
					bTransformerWindingStateArray[nDev]=1;
			}
		}
	}

	nVolt=0;
	while (nVolt < pBlock->m_nRecordNum[PG_VOLTAGELEVEL])
	{
		sprintf(szVoltIdent, "%s.%s", pBlock->m_VoltageLevelArray[nVolt].szSub, pBlock->m_VoltageLevelArray[nVolt].szName);
		bErase=0;
		for (i=0; i<(int)strExVoltageLevelArray.size(); i++)
		{
			if (stricmp(szVoltIdent, strExVoltageLevelArray[i].c_str()) == 0)
			{
				bErase=1;
				break;
			}
		}
		if (bErase)
		{
			Log(g_lpszLogFile, "ɾ����ѹ�ȼ�:(%s.%s)\n", pBlock->m_VoltageLevelArray[nVolt].szSub, pBlock->m_VoltageLevelArray[nVolt].szName);
			PGRemoveRecord(pBlock, PG_VOLTAGELEVEL, nVolt);
		}
		else
		{
			nVolt++;
		}
	}

	std::vector<unsigned char>	bTranProcArray;
	int		nCoil, nTranNum, nTranCoil[10], nTranNode[10];
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	bTranProcArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING], 0);
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		if (bTranProcArray[nDev])
			continue;

		bTranProcArray[nDev]=1;
		if (bTransformerWindingStateArray[nDev])
		{
			PGGetTranCoil(pBlock, nDev, nTranNum, nTranCoil, nTranNode);
			for (nCoil=0; nCoil<nTranNum; nCoil++)
			{
				bTranProcArray[nTranCoil[nCoil]]=1;

				bTransformerWindingStateArray[nTranCoil[nCoil]]=1;
				sprintf(szVoltIdent, "%s.%s", pBlock->m_TransformerWindingArray[nTranCoil[nCoil]].szSub, pBlock->m_ConnectivityNodeArray[nTranNode[nCoil]].szVolt);
				bErase=0;
				for (i=0; i<(int)strExVoltageLevelArray.size(); i++)
				{
					if (stricmp(szVoltIdent, strExVoltageLevelArray[i].c_str()) == 0)
					{
						bErase=1;
						break;
					}
				}
				if (!bErase)
				{
					strcpy(szField[PG_ENERGYCONSUMER_RESOURCEID],			pBlock->m_TransformerWindingArray[nTranCoil[nCoil]].szResID);
					sprintf(szField[PG_ENERGYCONSUMER_NAME], "�߽��ֵ%s",	pBlock->m_TransformerWindingArray[nTranCoil[nCoil]].szName);
					strcpy(szField[PG_ENERGYCONSUMER_DESC],					pBlock->m_TransformerWindingArray[nTranCoil[nCoil]].szDesp);
					strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION],			pBlock->m_TransformerWindingArray[nTranCoil[nCoil]].szSub);
					strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL],			pBlock->m_ConnectivityNodeArray[nTranNode[nCoil]].szVolt);
					strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE],		pBlock->m_ConnectivityNodeArray[nTranNode[nCoil]].szName);
					PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ENERGYCONSUMER, szField);
					Log(g_lpszLogFile, "        ���ӱ�ѹ����ֵ����=(%s.%s.%s)\n", szField[PG_ENERGYCONSUMER_SUBSTATION], szField[PG_ENERGYCONSUMER_VOLTAGELEVEL], szField[PG_ENERGYCONSUMER_NAME]);
				}
			}
		}
	}
	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		if (bTransformerWindingStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ����ѹ��:(%s.%s)\n", pBlock->m_TransformerWindingArray[nDev].szSub, pBlock->m_TransformerWindingArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, nDev);
			bTransformerWindingStateArray.erase(bTransformerWindingStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		if (bDisconnectorStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ����բ:(%s.%s.%s)\n", pBlock->m_DisconnectorArray[nDev].szSub, pBlock->m_DisconnectorArray[nDev].szVolt, pBlock->m_DisconnectorArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_DISCONNECTOR, nDev);
			bDisconnectorStateArray.erase(bDisconnectorStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_BREAKER])
	{
		if (bBreakerStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ������:(%s.%s.%s)\n", pBlock->m_BreakerArray[nDev].szSub, pBlock->m_BreakerArray[nDev].szVolt, pBlock->m_BreakerArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_BREAKER, nDev);
			bBreakerStateArray.erase(bBreakerStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_BUSBARSECTION])
	{
		if (bBusbarSectionStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ��ĸ��:(%s.%s.%s)\n", pBlock->m_BusbarSectionArray[nDev].szSub, pBlock->m_BusbarSectionArray[nDev].szVolt, pBlock->m_BusbarSectionArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_BUSBARSECTION, nDev);
			bBusbarSectionStateArray.erase(bBusbarSectionStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_ENERGYCONSUMER])
	{
		if (bEnergyConsumerStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ������:(%s.%s.%s)\n", pBlock->m_EnergyConsumerArray[nDev].szSub, pBlock->m_EnergyConsumerArray[nDev].szVolt, pBlock->m_EnergyConsumerArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_ENERGYCONSUMER, nDev);
			bEnergyConsumerStateArray.erase(bEnergyConsumerStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR])
	{
		if (bShuntCompensatorStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ����������:(%s.%s.%s)\n", pBlock->m_ShuntCompensatorArray[nDev].szSub, pBlock->m_ShuntCompensatorArray[nDev].szVolt, pBlock->m_ShuntCompensatorArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_SHUNTCOMPENSATOR, nDev);
			bShuntCompensatorStateArray.erase(bShuntCompensatorStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR])
	{
		if (bSeriesCompensatorStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ����������:(%s.%s.%s)\n", pBlock->m_SeriesCompensatorArray[nDev].szSub, pBlock->m_SeriesCompensatorArray[nDev].szVolt, pBlock->m_SeriesCompensatorArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_SERIESCOMPENSATOR, nDev);
			bSeriesCompensatorStateArray.erase(bSeriesCompensatorStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE])
	{
		if (bSynchronousMachineStateArray[nDev])
		{
			Log(g_lpszLogFile, "ɾ�������:(%s.%s.%s)\n", pBlock->m_SynchronousMachineArray[nDev].szSub, pBlock->m_SynchronousMachineArray[nDev].szVolt, pBlock->m_SynchronousMachineArray[nDev].szName);
			PGRemoveRecord(pBlock, PG_SYNCHRONOUSMACHINE, nDev);
			bSynchronousMachineStateArray.erase(bSynchronousMachineStateArray.begin()+nDev);
		}
		else
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_ACLINESEGMENT])
	{
		if (bACLineSegmentStateArray[nDev] > 2)
		{
			Log(g_lpszLogFile, "ɾ����·: %s(%s.%s)\n", pBlock->m_ACLineSegmentArray[nDev].szName, pBlock->m_ACLineSegmentArray[nDev].szSubI, pBlock->m_ACLineSegmentArray[nDev].szSubJ);
			PGRemoveRecord(pBlock, PG_ACLINESEGMENT, nDev);
			bACLineSegmentStateArray.erase(bACLineSegmentStateArray.begin()+nDev);
		}
		else
			nDev++;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		if (!bACLineSegmentStateArray[nDev])
			continue;

		if (bACLineSegmentStateArray[nDev] == 1)
		{
			memset(pBlock->m_ACLineSegmentArray[nDev].szSubI, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_ISUBSTATION));
			memset(pBlock->m_ACLineSegmentArray[nDev].szVoltI, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_IVOLTAGELEVEL));
		}
		else if (bACLineSegmentStateArray[nDev] == 2)
		{
			memset(pBlock->m_ACLineSegmentArray[nDev].szSubJ, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_JSUBSTATION));
			memset(pBlock->m_ACLineSegmentArray[nDev].szVoltJ, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_JVOLTAGELEVEL));
		}
	}

	PGMaint(pBlock);

	return 1;
}

int	CCIMData::FindEquipmentByResourceId(const char* lpszResourceId, int& nTable, int& nRecord)
{
	nRecord=findBusbarSectionByResID(0, (int)m_BusbarSectionArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_BUSBARSECTION;
		return 1;
	}
	nRecord=findTransformerWindingByResID(0, (int)m_TransformerWindingArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_TRANSFORMERWINDING;
		return 1;
	}
	nRecord=findSynchronousMachineByResID(0, (int)m_SynchronousMachineArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_SYNCHRONOUSMACHINE;
		return 1;
	}
	nRecord=findEnergyConsumerByResID(0, (int)m_EnergyConsumerArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_ENERGYCONSUMER;
		return 1;
	}
	nRecord=findCompensatorByResID(0, (int)m_CompensatorArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_SHUNTCOMPENSATOR;
		return 1;
	}
	nRecord=findBreakerByResID(0, (int)m_BreakerArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_BREAKER;
		return 1;
	}
	nRecord=findDisconnectorByResID(0, (int)m_DisconnectorArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_DISCONNECTOR;
		return 1;
	}
	nRecord=findGroundDisconnectorByResID(0, (int)m_GroundDisconnectorArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_GROUNDDISCONNECTOR;
		return 1;
	}
	nRecord=findSubstationByResID(0, (int)m_SubstationArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_SUBSTATION;
		return 1;
	}

	return 0;
}

int	CCIMData::FindACLineSegmentByResourceId(const char* lpszResourceId, int& nTable, int& nRecord)
{
	nRecord=findACLineSegmentByResID(0, (int)m_ACLineSegmentArray.size()-1, lpszResourceId);
	if (nRecord >= 0)
	{
		nTable=PG_ACLINESEGMENT;
		return 1;
	}

	return 0;
}

