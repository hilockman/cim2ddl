#pragma once
#pragma warning( disable: 4251 )

#include "../../MemDB/PGMemDB/PGMemDB.h"
using namespace PGMemDB;

#include "CIMDataDefine.h"
#include "../../Common/TinyXML/tinyxml.h"

// #ifndef EXPORT_CIMAPI_STL_VECTOR
// #	define EXPORT_CIMAPI_STL_VECTOR( vectype )   \
// 	template class CIMDATAAPI_API std::allocator< vectype >;   \
// 	template class CIMDATAAPI_API std::vector<vectype, std::allocator< vectype > >;
// #endif
// 

// �����Ǵ� CIMDataApi.dll ������
class CIMDATAAPI_API CCIMData
{
public:
	CCIMData(void);
	// TODO: �ڴ��������ķ�����

public:
	int		Parse(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement=1, const int bParseBySax=0, const int bNameByDesp=1, const int bSubstationNamePrefixSubcontrolArea = 1);
	void	Release();
public:
	void	FormMeasurementTable(const char* lpszFileName, const int bOutSwitchYX, const int bOutCurrent);
	void	ReadMeasurementFile(const char* lpszFileName);

	int		FindEquipmentByResourceId(const char* lpszResourceId, int& nTable, int& nRecord);
	int		FindACLineSegmentByResourceId(const char* lpszResourceId, int& nTable, int& nRecord);

public:
	void	AddOutnetEQGen(tagPGBlock* pPGBlock, const unsigned char bSetUnOutnet, std::vector<std::string>& strOutnetSubstationArray);
	void	EraseSubcontrolArea(tagPGBlock* pPGBlock, std::vector<std::string>& strSubcontrolAreaArray);

	void	formBound(const int bNameByDesp);
	void	SetExcludeSubstation(std::vector<std::string>& strExcludeSubstationArray);
	void	SetExcludeSubcontrolArea(const int bNameByDesp, std::vector<std::string>& strExcludeSubcontrolAreaList);

public:
	int		FillMemDB(tagPGBlock* pPGBlock, const int bClearMDB=1, const int bNameByDesp=0, const float fLowVThreshold=120, const int bTranPuVoltageHigh=0);
	int		FillElement(const int nCimSection, const char* lpszElementName, const char* lpszElementValue);

private:
	int		PostFillMemDB(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	dc2ac(tagPGBlock* pPGBlock, const int bNameByDesp);

public:
	int ResolvePowerTransformerWindNum(const int nRecord, int& nWindH, int& nWindM, int& nWindL);

private:
	int		ParseXmlByDom(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement=1);
	int		ParseXmlBySax(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement=1);
	void	ClearMemDB(tagPGBlock* pPGBlock);
	void	insertTrantap(tagPGBlock* pPGBlock);
	void	insertDefault(tagPGBlock* pPGBlock);
	void	insertCompany(tagPGBlock* pPGBlock, const int bNameByDesp, const int bCimAsOutnet);
	void	insertSubcontrolArea(tagPGBlock* pPGBlock, const int bNameByDesp, const int bCimAsOutnet);
	void	insertSubstation(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertVoltageLevel(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertBusbarSection(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertACLineSegment(tagPGBlock* pPGBlock, const int bNameByDesp, const float fLowVThreshold);
	void	insertDCLineSegment(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertTranformerWinding(tagPGBlock* pPGBlock, const int bNameByDesp, const int bTranPuVoltageHigh);
	void	insertSynchronousMachine(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertEnergyConsumer(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertCompensator(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertRectifierInverter(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertBreak(tagPGBlock* pPGBlock, const int bNameByDesp);
	void	insertDisconnector(tagPGBlock* pPGBlock, const int bNameByDesp);
	char*	FormatVoltageLevelName(const char* lpszInVoltName);

private:
	void	EraseNouseContainer(tagPGBlock* pPGBlock);
	void	EraseSubstation(tagPGBlock* pPGBlock, const char* lpszSubName);
	int		eraseExVoltageLevel(tagPGBlock* pPGBlock, std::vector<std::string>& strExVoltageLevelArray);

private:
	int		isSubstationExclude(const char* lpszSubstation, const int bNameByDesp);
	int		isSubcontrolAreaExclude(const char* lpszSubcontrolArea, const int bNameByDesp);

private:
	void	SubstationVoltagePostProc(const int bNameByDesp, const int bSubstationNamePrefixSubcontrolArea);
	void	fillConnetivityByTerminal(const int bNameByDesp);
	void	TransFormerPostProc(const int bNameByDesp);
	void	MeasurementPostProc(const int bNameByDesp);

	void	sortSubstationByResID(int nDn0, int nUp0);
	void	sortVoltageLevelByResID(int nDn0, int nUp0);
	void	sortBayByResID(int nDn0, int nUp0);
	void	sortBaseVoltageByResID(int nDn0, int nUp0);
	void	sortTerminalByParentTag(int nDn0, int nUp0);
	void	sortConnectivityNodeByResID(int nDn0, int nUp0);
	void	sortMeasurementByResID(int nDn0, int nUp0);
	void	sortMeasurementTypeByResID(int nDn0, int nUp0);
	void	sortAnalogByResID(int nDn0, int nUp0);
	void	sortDiscreteByResID(int nDn0, int nUp0);
	void	sortACLineSegmentByResID(int nDn0, int nUp0);
	void	sortTransformerWindingByResID(int nDn0, int nUp0);
	void	sortPowerTransformerByResID(int nDn0, int nUp0);
	void	sortBusbarSectionByResID(int nDn0, int nUp0);
	void	sortSynchronousMachineByResID(int nDn0, int nUp0);
	void	sortEnergyConsumerByResID(int nDn0, int nUp0);
	void	sortShuntCompensatorByResID(int nDn0, int nUp0);
	void	sortBreakerByResID(int nDn0, int nUp0);
	void	sortDisconnectorByResID(int nDn0, int nUp0);
	void	sortGroundDisconnectorByResID(int nDn0, int nUp0);
	void	sortTapChangerByTransformerWindingResID(int nDn0, int nUp0);
	void	sortTapChangerByResID(int nDn0, int nUp0);

	int		findSubstationByResID(int nLeft, int nRight, const char* lpszResID);
	int		findVoltageLevelByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBayByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBaseVoltageByResID(int nLeft, int nRight, const char* lpszTag);
	int		findTerminalByParentTag(int nLeft, int nRight, const char* lpszTag);
	int		findConnectivityNodeByResID(int nLeft, int nRight, const char* lpszResID);
	int		findMeasurementByResID(int nLeft, int nRight, const char* lpszResID);
	int		findMeasurementTypeByResID(int nLeft, int nRight, const char* lpszResID);
	int		findAnalogByResID(int nLeft, int nRight, const char* lpszResID);
	int		findDiscreteByResID(int nLeft, int nRight, const char* lpszResID);
	int		findACLineSegmentByResID(int nLeft, int nRight, const char* lpszResID);
	int		findTransformerWindingByResID(int nLeft, int nRight, const char* lpszResID);
	int		findPowerTransformerByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBusbarSectionByResID(int nLeft, int nRight, const char* lpszResID);
	int		findSynchronousMachineByResID(int nLeft, int nRight, const char* lpszResID);
	int		findEnergyConsumerByResID(int nLeft, int nRight, const char* lpszResID);
	int		findCompensatorByResID(int nLeft, int nRight, const char* lpszResID);
	int		findBreakerByResID(int nLeft, int nRight, const char* lpszResID);
	int		findDisconnectorByResID(int nLeft, int nRight, const char* lpszResID);
	int		findGroundDisconnectorByResID(int nLeft, int nRight, const char* lpszResID);
	int		findTapChangerByTransformerWindingResID(int nLeft, int nRight, const char* lpszResID);
	int		findTapChangerByResID(int nLeft, int nRight, const char* lpszResID);

	double	readMeasurementMaxLimitValue(const int nMeasurement);
	double	readMeasurementMinLimitValue(const int nMeasurement);
	void	NomalizeVoltageLevelName(const double fNorminalVoltage, char* lpszRetVoltageLevelName);

private:
	void	parseCim(TiXmlElement* pElement, int nDepth, const int bParseMeasurement=1);

	void	parseBasePower				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseBaseVoltage			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseCompany				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseSubcontrolArea			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseSubstation				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseVoltageLevel			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseBay					(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseBusbarSection			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseACLineSegment			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseDCLineSegment			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseTransformerWinding		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parsePowerTransformer		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseTapChanger				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseEnergyConsumer			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseSynchronousMachine		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseThermalGeneratingUnit	(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseHydroGeneratingUnit	(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseCompensator			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseRectifierInverter		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseBreaker				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseDisconnector			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseGroundDisconnector		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseTerminal				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseConnectivityNode		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);

	void	parseMeasurementType		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseMeasurementValue		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseMeasurementSource		(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseMeasurement			(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseAnalog					(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseDiscrete				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseLimitSet				(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);
	void	parseLimit					(const int nDepth, const char* lpszNodeName, TiXmlElement* pElement);

private:
	int		readElement(TiXmlElement* pElement, const int nDepth, const char* lpszParent, const char* lpszElement, char* lpszRet);
	int		readAttribute(TiXmlElement* pElement, const int nDepth, const char* lpszElement, const char* lpszAttribute, char* lpszRet);
	int		readAttribute(TiXmlAttribute* pAttr, const char* lpszAttribute, char* lpszRet);

protected:
	void	fillBasePower				(tagCIMBasePower* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillBaseVoltage				(tagCIMBaseVoltage* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillCompany					(tagCIMCompany* pData,					const char* lpszElementName, const char* lpszElementValue);
	void	fillSubcontrolArea			(tagCIMSubcontrolArea* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillSubstation				(tagCIMSubstation* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillVoltageLevel			(tagCIMVoltageLevel* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillBay						(tagCIMBay* pData,						const char* lpszElementName, const char* lpszElementValue);
	void	fillBusbarSection			(tagCIMBusbarSection* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillACLineSegment			(tagCIMACLineSegment* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillDCLineSegment			(tagCIMDCLineSegment* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillTransformerWinding		(tagCIMTransformerWinding* pData,		const char* lpszElementName, const char* lpszElementValue);
	void	fillPowerTransformer		(tagCIMPowerTransformer* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillTapChanger				(tagCIMTapChanger* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillSynchronousMachine		(tagCIMSynchronousMachine* pData,		const char* lpszElementName, const char* lpszElementValue);
	void	fillThermalGeneratingUnit	(tagCIMThermalGeneratingUnit* pData,	const char* lpszElementName, const char* lpszElementValue);
	void	fillHydroGeneratingUnit		(tagCIMHydroGeneratingUnit* pData,		const char* lpszElementName, const char* lpszElementValue);
	void	fillEnergyConsumer			(tagCIMEnergyConsumer* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillCompensator				(tagCIMCompensator* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillRectifierInverter		(tagCIMRectifierInverter* pData,		const char* lpszElementName, const char* lpszElementValue);
	void	fillBreaker					(tagCIMBreaker* pData,					const char* lpszElementName, const char* lpszElementValue);
	void	fillDisconnector			(tagCIMDisconnector* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillGroundDisconnector		(tagCIMGroundDisconnector* pData,		const char* lpszElementName, const char* lpszElementValue);
	void	fillTerminal				(tagCIMTerminal* pData,					const char* lpszElementName, const char* lpszElementValue);
	void	fillConnectivityNode		(tagCIMConnectivityNode* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillMeasurementType			(tagCIMMeasurementType* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillMeasurementSource	(tagCIMMeasurementSource* pData,		const char* lpszElementName, const char* lpszElementValue);
	void	fillMeasurementValue		(tagCIMMeasurementValue* pData,			const char* lpszElementName, const char* lpszElementValue);
	void	fillMeasurement				(tagCIMMeasurement* pData,				const char* lpszElementName, const char* lpszElementValue);
	void	fillAnalog					(tagCIMAnalog* pData,					const char* lpszElementName, const char* lpszElementValue);
	void	fillDiscrete				(tagCIMDiscrete* pData,					const char* lpszElementName, const char* lpszElementValue);
	void	fillLimitSet				(tagCIMLimitSet* pData,					const char* lpszElementName, const char* lpszElementValue);
	void	fillLimit					(tagCIMLimit* pData,					const char* lpszElementName, const char* lpszElementValue);

public:
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMBaseVoltage)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMSubcontrolArea)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMSubstation)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMVoltageLevel)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMBay)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMBusbarSection)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMACLineSegment)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMDCLineSegment)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMTransformerWinding)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMPowerTransformer)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMTapChanger)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMSynchronousMachine)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMThermalGeneratingUnit)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMHydroGeneratingUnit)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMEnergyConsumer)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMCompensator)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMRectifierInverter)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMBreaker)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMDisconnector)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMGroundDisconnector)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMTerminal)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMConnectivityNode)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMMeasurementType)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMMeasurementSource)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMMeasurementValue)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMMeasurement)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMAnalog)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMDiscrete)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMLimitSet)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMLimit)
	// EXPORT_CIMAPI_STL_VECTOR( tagCIMACLineSegment)

public:
	tagCIMBasePower								m_BasePower;
	std::vector<tagCIMBaseVoltage>				m_BaseVoltageArray;
	std::vector<tagCIMCompany>					m_CompanyArray;
	std::vector<tagCIMSubcontrolArea>			m_SubcontrolAreaArray;
	std::vector<tagCIMSubstation>				m_SubstationArray;
	std::vector<tagCIMVoltageLevel>				m_VoltageLevelArray;
	std::vector<tagCIMBay>						m_BayArray;
	std::vector<tagCIMBusbarSection>			m_BusbarSectionArray;
	std::vector<tagCIMACLineSegment>			m_ACLineSegmentArray;
	std::vector<tagCIMDCLineSegment>			m_DCLineSegmentArray;
	std::vector<tagCIMTransformerWinding>		m_TransformerWindingArray;
	std::vector<tagCIMPowerTransformer>			m_PowerTransformerArray;
	std::vector<tagCIMTapChanger>				m_TapChangerArray;
	std::vector<tagCIMSynchronousMachine>		m_SynchronousMachineArray;
	std::vector<tagCIMThermalGeneratingUnit>	m_ThermalGeneratingUnitArray;
	std::vector<tagCIMHydroGeneratingUnit>		m_HydroGeneratingUnitArray;
	std::vector<tagCIMEnergyConsumer>			m_EnergyConsumerArray;
	std::vector<tagCIMCompensator>				m_CompensatorArray;
	std::vector<tagCIMRectifierInverter>		m_RectifierInverterArray;
	std::vector<tagCIMBreaker>					m_BreakerArray;
	std::vector<tagCIMDisconnector>				m_DisconnectorArray;
	std::vector<tagCIMGroundDisconnector>		m_GroundDisconnectorArray;
	std::vector<tagCIMTerminal>					m_TerminalArray;
	std::vector<tagCIMConnectivityNode>			m_ConnectivityNodeArray;
	std::vector<tagCIMMeasurementType>			m_MeasurementTypeArray;
	std::vector<tagCIMMeasurementSource>		m_MeasurementSourceArray;
	std::vector<tagCIMMeasurementValue>			m_MeasurementValueArray;
	std::vector<tagCIMMeasurement>				m_MeasurementArray;
	std::vector<tagCIMAnalog>					m_AnalogArray;
	std::vector<tagCIMDiscrete>					m_DiscreteArray;
	std::vector<tagCIMLimitSet>					m_LimitSetArray;
	std::vector<tagCIMLimit>					m_LimitArray;

	std::vector<tagCIMACLineSegment>			m_BoundLineArray;

public:
	int		PrepareElementBuffer(const int nCimSection);
	int		AppendElementBuffer(const int nCimSection);

protected:
	void	PrevParse();
	void	PostParse(const int bNameByDesp, const int bSubstationNamePrefixSubcontrolArea);
	void	StringRemove(char* lpszString, char cRemove);
	void	StringReplace(char* lpszString, char cIni, char cRep);

protected:
	tagCIMBaseVoltage				m_BaseVoltageBuf			;
	tagCIMCompany					m_CompanyBuf			;
	tagCIMSubcontrolArea			m_SubcontrolAreaBuf			;
	tagCIMSubstation				m_SubstationBuf				;
	tagCIMVoltageLevel				m_VoltageLevelBuf			;
	tagCIMBay						m_BayBuf					;
	tagCIMBusbarSection				m_BusbarSectionBuf			;
	tagCIMACLineSegment				m_ACLineSegmentBuf			;
	tagCIMDCLineSegment				m_DCLineSegmentBuf			;
	tagCIMTransformerWinding		m_TransformerWindingBuf		;	
	tagCIMPowerTransformer			m_PowerTransformerBuf		;	
	tagCIMTapChanger				m_TapChangerBuf				;	
	tagCIMSynchronousMachine		m_SynchronousMachineBuf		;	
	tagCIMThermalGeneratingUnit		m_ThermalGeneratingUnitBuf	;
	tagCIMHydroGeneratingUnit		m_HydroGeneratingUnitBuf	;
	tagCIMEnergyConsumer			m_EnergyConsumerBuf			;
	tagCIMCompensator				m_CompensatorBuf			;
	tagCIMRectifierInverter			m_RectifierInverterBuf		;
	tagCIMBreaker					m_BreakerBuf				;	
	tagCIMDisconnector				m_DisconnectorBuf			;	
	tagCIMGroundDisconnector		m_GroundDisconnectorBuf		;	
	tagCIMTerminal					m_TerminalBuf				;	
	tagCIMConnectivityNode			m_ConnectivityNodeBuf		;	
	tagCIMMeasurementType			m_MeasurementTypeBuf		;	
	tagCIMMeasurementSource			m_MeasurementSourceBuf		;
	tagCIMMeasurementValue			m_MeasurementValueBuf		;	
	tagCIMMeasurement				m_MeasurementBuf			;	
	tagCIMAnalog					m_AnalogBuf					;	
	tagCIMDiscrete					m_DiscreteBuf				;	
	tagCIMLimitSet					m_LimitSetBuf				;	
	tagCIMLimit						m_LimitBuf					;

protected:
	unsigned char	m_bParseMeasurement;

public:
	const int	GetCIMTableNum();
	const char*	GetCIMTableName(const int nTable);
	const char*	GetCIMTableDesp(const int nTable);
	const int	GetCIMTableID(const int nTable);
	const int	GetCIMTableFieldNum(const int nTable);
	const char*	GetCIMTableFieldDesp(const int nTable, const int nField);
};


extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	const	char*	g_lpszLogFile;
