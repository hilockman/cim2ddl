#pragma  once

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#endif

#if !defined(__GNUG__) && !defined(__GNUC__)
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

//	��CIM�������Ʒ�������Σ�
//		����		name
//		ʹ����		desp
//		��װ��		packname	�ڴ����ݿ����õ�����
//	��ʵ��ʹ���У��ڴ����ݿ���������ⲿ���ƣ������ڲ�ʹ�þ������ڲ����ơ��ڲ����ƿ�ʹ��name��desp
//	����Terminal��ConnectivityNode���ⲿ����

//	˵����
//		����TAG��ʾ��TEXT
//		��TAG��ʾ��RDF:RESOURCE

//	packName�Ƿ�װ���ƣ������ڲ�����

typedef	struct _NameDesp_
{
	short	nID;
	char*	szName;
	char*	szDesp;
}	tagCIMNameDesp;

typedef	struct _CIMXmlEleDesp_
{
	char*	szName;
	char*	szDesp;
}	tagCIMXmlEleDesp;

typedef	struct _CIMConductor_
{
	// 	float	r;		//(Resistance)	Positive sequence series resistance of the entire line section.
	// 	float	x;		//(Reactance)	Positive sequence series reactance of the entire line section.
	// 	float	gch;	//(Conductance)	Positive sequence shunt (charging) conductance, uniformly distributed, of the entire line section.
	// 	float	bch;	//(Susceptance)	Positive sequence shunt (charging) susceptance, uniformly distributed, of the entire line section.
	// 	float	r0;		//(Resistance)	Zero sequence series resistance of the entire line section.
	// 	float	x0;		//(Reactance)	Zero sequence series reactance of the entire line section.
	// 	float	g0ch;	//(Conductance)	Zero sequence shunt (charging) conductance, uniformly distributed, of the entire line section.
	// 	float	b0ch;	//(Susceptance)	Zero sequence shunt (charging) susceptance, uniformly distributed, of the entire line section.
	// 	float	length;	//(LongLength)	Segment length for calculating line section capabilities (long length units)
	double	fR,								//	Conductor.r
		fX,								//	Conductor.x
		fG,								//	Conductor.gch	����CIM�в�����
		fB;								//	Conductor.bch
	double	fR0,							//	Conductor.r0	����CIM�в�����
		fX0,							//	Conductor.x0	����CIM�в�����
		fG0,							//	Conductor.gch0	����CIM�в�����
		fB0;							//	Conductor.bch0	����CIM�в�����
	double	fRpu,							//	Conductor.r
		fXpu,							//	Conductor.x
		fGpu,							//	Conductor.gch	����CIM�в�����
		fBpu;							//	Conductor.bch
	double	fR0pu,							//	Conductor.r0	����CIM�в�����
		fX0pu,							//	Conductor.x0	����CIM�в�����
		fG0pu,							//	Conductor.gch0	����CIM�в�����
		fB0pu;							//	Conductor.bch0	����CIM�в�����
}	tagCIMConductor;

enum	_ENum_CIM_Table_
{
	CIM_BasePower=0,
	CIM_BaseVoltage,
// 	CIM_Company,
	CIM_SubcontrolArea,
	CIM_Substation,
	CIM_VoltageLevel,
	CIM_Bay,
	CIM_BusbarSection,
	CIM_ACLineSegment,
	CIM_DCLineSegment,
	CIM_TransformerWinding,
	CIM_PowerTransformer,
	CIM_TapChanger,
	CIM_SynchronousMachine,
	CIM_ThermalGeneratingUnit,
	CIM_HydroGeneratingUnit,
	CIM_EnergyConsumer,
	CIM_Compensator,
	CIM_RectifierInverter,
	CIM_Breaker,
	CIM_Disconnector,
	CIM_DCSwitch,
	CIM_GroundDisconnector,
	CIM_Terminal,
	CIM_ConnectivityNode,
	CIM_MeasurementType,
	CIM_MeasurementSource,
	CIM_MeasurementValue,
	CIM_Measurement,
	CIM_Analog,
	CIM_Discrete,
	CIM_LimitSet,
	CIM_Limit,
};

struct	_CIMBasePower
{
	char	szResourceID[MDB_CHARLEN];		//	rdf:ID
	float	fBasePower;					//	cim:BasePower.basePower
}	DISALIGN;
typedef	struct	_CIMBasePower	tagCIMBasePower;

struct	_CIMBaseVoltage
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	float	fNominalVoltage;				//	BaseVoltage.nominalVoltage
}	DISALIGN;
typedef	struct	_CIMBaseVoltage	tagCIMBaseVoltage;

struct	_CIMCompany
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];					//	name
	char	szDesp[MDB_CHARLEN_LONG];					//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	//char	szPackID[MDB_CHARLEN];
	//char	szPackName[MDB_CHARLEN_SHORT];
}	DISALIGN;
typedef	struct	_CIMCompany	tagCIMCompany;

struct	_CIMSubcontrolArea
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];					//	name
	char	szDesp[MDB_CHARLEN_LONG];					//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	char	szCorp[MDB_CHARLEN];				//	aliasName

	//char	szPackID[MDB_CHARLEN];
	//char	szPackName[MDB_CHARLEN_SHORT];
	unsigned char	bExclude;
}	DISALIGN;
typedef	struct	_CIMSubcontrolArea	tagCIMSubcontrolArea;

struct	_CIMSubstation
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];					//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName

	char	szSubcontrolAreaTag[MDB_CHARLEN];	//	Substation.MemberOf_SubControlArea
	std::string	strSubcontrolArea;

	std::string	strRealName;
	unsigned char	bExclude;
}	DISALIGN;
typedef	struct	_CIMSubstation		tagCIMSubstation;
inline	void	InitializeCimSubstation(tagCIMSubstation& dBuf)
{
	memset(dBuf.szResourceID, 0, MDB_CHARLEN);			//	rdf:ID
	memset(dBuf.szName, 0, MDB_CHARLEN);				//	name
	memset(dBuf.szDesp, 0, MDB_CHARLEN_LONG);			//	description
	memset(dBuf.szAlias, 0, MDB_CHARLEN);				//	aliasName
	memset(dBuf.szSubcontrolAreaTag, 0, MDB_CHARLEN);	//	Substation.MemberOf_SubControlArea
	dBuf.strSubcontrolArea.clear();
	dBuf.strRealName.clear();
	dBuf.bExclude=0;
}

struct	_CIMVoltageLevel
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN_SHORTER];					//	name
	float	fHLimit;							//	VoltageLevel.highVoltageLimit
	float	fLLimit;							//	VoltageLevel.lowVoltageLimit

	char	szSubstationTag[MDB_CHARLEN];		//	VoltageLevel.MemberOf_Substation
	char	szBaseVoltageTag[MDB_CHARLEN];		//	VoltageLevel.BaseVoltage

	char	szSub[MDB_CHARLEN_SHORT];			//	��ӦszSubstationTag��SUBSTATION����
	float	fNominal;							//	��ӦszBaseVoltageTag��VOLTAGELEVEL��ֵ

	//char	szPackID[MDB_CHARLEN];
	//char	szPackName[MDB_CHARLEN_SHORTER];
	unsigned char	bExclude;
}	DISALIGN;
typedef	struct	_CIMVoltageLevel	tagCIMVoltageLevel;

struct	_CIMBay
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];					//	name

	char	szSubstationTag[MDB_CHARLEN];		//	VoltageLevel.MemberOf_Substation
	char	szVoltageTag[MDB_CHARLEN];			//	Bay.MemberOf_VoltageLevel

	char	szSub[MDB_CHARLEN_SHORT];			//	��ӦszSubstationTag��SUBSTATION����
	char	szVolt[MDB_CHARLEN_SHORTER];			//	��ӦszBaseVoltageTag��VOLTAGELEVEL��ֵ
}	DISALIGN;;
typedef	struct	_CIMBay	tagCIMBay;

struct	_CIMBusbarSection
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];			//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
	char	szTerminalTag[MDB_CHARLEN];			//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage

	double	fVoltageLimitH;
	double	fVoltageLimitL;
	double	fFrequencyLimitH;
	double	fFrequencyLimitL;

	char	szSub[MDB_CHARLEN_SHORT];			//	szParentTag
	char	szVolt[MDB_CHARLEN_SHORTER];			//	szParentTag
	char	szNode[PGND_CHARLEN];			//	szTerminalTag��Ӧ��ConnectivityNode
}	DISALIGN;
typedef	struct	_CIMBusbarSection	tagCIMBusbarSection;

struct	_CIMACLineSegment
{
	char	szResourceID[MDB_CHARLEN];		//	rdf:ID
	char	szName[MDB_CHARLEN];			//	name
	char	szDesp[MDB_CHARLEN_LONG];			//	description
	char	szAlias[MDB_CHARLEN];			//	aliasName
	double	fR,								//	Conductor.r
		fX,									//	Conductor.x
		fG,									//	Conductor.gch	����CIM�в�����
		fB;									//	Conductor.bch
	double	fR0,							//	Conductor.r0	����CIM�в�����
		fX0,								//	Conductor.x0	����CIM�в�����
		fG0,								//	Conductor.gch0	����CIM�в�����
		fB0;								//	Conductor.bch0	����CIM�в�����
	double	fRpu,							//	Conductor.r
		fXpu,								//	Conductor.x
		fGpu,								//	Conductor.gch	����CIM�в�����
		fBpu;								//	Conductor.bch
	double	fR0pu,							//	Conductor.r0	����CIM�в�����
		fX0pu,								//	Conductor.x0	����CIM�в�����
		fG0pu,								//	Conductor.gch0	����CIM�в�����
		fB0pu;								//	Conductor.bch0	����CIM�в�����

	double	fRatedA;
	char	szParentTag[MDB_CHARLEN];			//	ACLineSegment.MemberOf_Line	����CIM�в�����	Line
	char	szTerminalTag[2][MDB_CHARLEN];		//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage

	unsigned char	nRPu,
		nXPu,
		nGPu,
		nBPu,
		nR0Pu,
		nX0Pu,
		nG0Pu,
		nB0Pu;

	char	szSub[2][MDB_CHARLEN_SHORT];		//	��Ӧ��TERMINAL�е�SUBSTATION
	char	szVolt[2][MDB_CHARLEN_SHORTER];		//	��Ӧ��szBaseVoltageTag��VOLTAGELEVELֵ
	char	szNode[2][PGND_CHARLEN];		//	��Ӧ��szTerminalTag��NODE

	char	szTielineName[MDB_CHARLEN];			//	����Ϊ������
	float	fMaxCurrent;						//	�������е�
}	DISALIGN;
typedef	struct	_CIMACLineSegment	tagCIMACLineSegment;

struct	_CIMDCLineSegment
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];				//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	double	fL,									//	dcSegmentInductance
			fR;									//	dcSegmentResistance

	char	szParentTag[MDB_CHARLEN];			//	DCLineSegment.MemberOf_Line
	char	szTerminalTag[2][MDB_CHARLEN];		//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage

	char	szSub[2][MDB_CHARLEN_SHORT];		//	��Ӧ��TERMINAL�е�SUBSTATION
	char	szVolt[2][MDB_CHARLEN_SHORTER];		//	��Ӧ��szBaseVoltageTag��VOLTAGELEVELֵ
	char	szNode[2][PGND_CHARLEN];			//	��Ӧ��szTerminalTag��NODE
}	DISALIGN;
typedef	struct	_CIMDCLineSegment	tagCIMDCLineSegment;

struct	_CIMTransformerWinding
{
	char	szResourceID[MDB_CHARLEN];		//	rdf:ID
	char	szName[MDB_CHARLEN];			//	name
	char	szDesp[MDB_CHARLEN_LONG];			//	description
	char	szAlias[MDB_CHARLEN];			//	aliasName
	float	fR,								//	TransformerWinding.r
		fX,									//	TransformerWinding.x
		fX0,								//	TransformerWinding.x0
		fRatedMW,							//	TransformerWinding.ratedMVA
		fRatedKV;							//	TransformerWinding.ratedKV
	float	fCurrentLimit;

	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
	char	szPowerTransformerTag[MDB_CHARLEN];	//	TransformerWinding.MemberOf_PowerTransformer
	char	szTerminalTag[MDB_CHARLEN];			//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage

	unsigned char	nRPu,
		nXPu,
		nX0Pu;

	float	fLoadLoss;							//	��·���
	float	fLeakageImpedence;					//	©��

	char	szPowerTransformer[MDB_CHARLEN];	//	szPowerTransformerTag
	char	szSub[MDB_CHARLEN_SHORT];			//	szParentTag
	char	szVolt[MDB_CHARLEN_SHORTER];			//	szParentTag
	char	szNode[PGND_CHARLEN];			//	szTerminalTag

	char	szTapChangerTag[MDB_CHARLEN];
	char	szTapChanger[MDB_CHARLEN_SHORT];
	short	nTransformerWindingType;			//	�������������������

	float	fMaxCurrent;						//
}	DISALIGN;
typedef	struct	_CIMTransformerWinding	tagCIMTransformerWinding;

const int	MaxPowerTransformerWindNum=6;
struct	_CIMPowerTransformer
{
	char	szResourceID[MDB_CHARLEN];				//	rdf:ID
	char	szName[MDB_CHARLEN];					//	name
	char	szDesp[MDB_CHARLEN_LONG];					//	description
	char	szAlias[MDB_CHARLEN];					//	aliasName
	char	szParentTag[MDB_CHARLEN];				//	Equipment.MemberOf_EquipmentContainer

	char	szSub[MDB_CHARLEN_SHORT];				//	szParentTag

	short	nWindNum;
	short	nWindArray[MaxPowerTransformerWindNum];
}	DISALIGN;
typedef	struct	_CIMPowerTransformer	tagCIMPowerTransformer;

struct	_CIMTapChanger
{
	char	szResourceID[MDB_CHARLEN];				//	rdf:ID
	char	szName[MDB_CHARLEN];					//	name
	char	szDesp[MDB_CHARLEN_LONG];				//	description
	char	szAlias[MDB_CHARLEN];					//	aliasName
	short	nHighStep,								//	TapChanger.highStep
			nLowStep,								//	TapChanger.lowStep
			nNeutralStep,							//	TapChanger.neutralStep
			nNormalStep;							//	TapChanger.normalStep
	float	fStepVoltageIncrement;					//	TapChanger.stepVoltageIncrement
	char	szTransformerWindingTag[MDB_CHARLEN];	//	TapChanger.TransformerWinding
	char	szLocalTapName[MDB_CHARLEN_SHORT];		//	tapty
}	DISALIGN;
typedef	struct	_CIMTapChanger	tagCIMTapChanger;

struct	_CIMSynchronousMachine
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];				//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	float	fMvrate;							//	SynchronousMachine.ratedMVA
	float	fMaxQ;								//	SynchronousMachine.maximumMVAr
	float	fXd;
	float	fXdp;
	float	fXdpp;
	float	fXq;
	float	fXqp;
	float	fXqpp;
	float	fTj;
	float	fD;
	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
	char	szUnitTag[MDB_CHARLEN];				//	SynchronousMachine.MemberOf_GeneratingUnit
	char	szTerminalTag[MDB_CHARLEN];			//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage

	char	szSub[MDB_CHARLEN_SHORT];			//	szParentTag
	char	szVolt[MDB_CHARLEN_SHORTER];			//	szParentTag
	char	szNode[PGND_CHARLEN];			//	szTerminalTag
	float	fP;
	float	fMaxP;
	float	fMinP;

	short	nUnitType;
	char	szTielineName[MDB_CHARLEN];			//	����Ϊ������
}	DISALIGN;
typedef	struct	_CIMSynchronousMachine	tagCIMSynchronousMachine;

struct	_CIMHydroGeneratingUnit
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	float	fInitP;								//	GeneratingUnit.initialMW
	float	fMaxP;								//	GeneratingUnit.maximumOperatingMW
	float	fMinP;
	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
}	DISALIGN;
typedef	struct	_CIMHydroGeneratingUnit	tagCIMHydroGeneratingUnit;

struct	_CIMThermalGeneratingUnit
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	float	fInitP;								//	GeneratingUnit.initialMW
	float	fMinP;								//	GeneratingUnit.minimumOperatingMW
	float	fMaxP;								//	GeneratingUnit.maximumOperatingMW
	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
}	DISALIGN;
typedef	struct	_CIMThermalGeneratingUnit	tagCIMThermalGeneratingUnit;

struct	_CIMEnergyConsumer
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];				//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
	double	pVexp,
			pFexp,								//	EnergyConsumer.pFexp��ѹ��Ƶ��ָ��
			qVexp,
			qFexp;								//	EnergyConsumer.qFexp��ѹ��Ƶ��ָ��
	double	pfixedPct,							//	EnergyConsumer.pfixedPct	�̶����ɱ���
			qfixedPct;							//	EnergyConsumer.qfixedPct	�̶����ɱ���					//
	char	szTerminalTag[MDB_CHARLEN];			//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage

	char	szSub[MDB_CHARLEN_SHORT];			//	�洢��վ�����ڽ������Ʒ�װ
	char	szVolt[MDB_CHARLEN_SHORTER];
	char	szNode[PGND_CHARLEN];

	char	szTielineName[MDB_CHARLEN];			//	����Ϊ������
}	DISALIGN;
typedef	struct	_CIMEnergyConsumer	tagCIMEnergyConsumer;

struct	_CIMCompensator
{
	char	szResourceID[MDB_CHARLEN];	//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];				//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	float	fMvar;								//	ShuntCompensator.nominalMVAr
	float	fNomV;								//	ShuntCompensator.nominalkV
	float	fSeriesR;							//	SeriesCompensator R
	float	fSeriesX;							//	SeriesCompensator X
	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
	char	szTerminalTag1[MDB_CHARLEN];		//	Ϊ����дMeasurement��
	char	szTerminalTag2[MDB_CHARLEN];		//	Ϊ����дMeasurement��
	char	szBaseVoltageTag[MDB_CHARLEN];		//	ConductingEquipment.BaseVoltage
	unsigned char	bSeries;

	char	szSub[MDB_CHARLEN_SHORT];			//	szParentTag
	char	szVolt[MDB_CHARLEN_SHORTER];			//	szParentTag
	char	szNode1[PGND_CHARLEN];			//	szTerminalTag
	char	szNode2[PGND_CHARLEN];			//	szTerminalTag
}	DISALIGN;
typedef	struct	_CIMCompensator	tagCIMCompensator;

struct	_CIMRectifierInverter
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szDesp[MDB_CHARLEN_LONG];			//	description
	char	szAlias[MDB_CHARLEN];				//	aliasName
	float	fRatedKV;							//	Rectifier/inverter primary base voltage
	short	nBridges;							//	Number of bridges
	float	fCommutatingReactance;				//	Commutating reactance in ohms at AC bus frequency
	float	fCommutatingResistance;				//	Commutating resistance in ��
	float	fCompoundResistance;				//	Compounding resistance in ��
	float	fMinCompoundVoltage;				//	Minimum compounded DC voltage

	char	szParentTag[MDB_CHARLEN];			//	Equipment.MemberOf_EquipmentContainer
	char	szTerminalTag[3][MDB_CHARLEN];		//	Ϊ����дMeasurement��

	char	szSub[MDB_CHARLEN_SHORT];			//	��վ
	char	szVolt[3][MDB_CHARLEN_SHORTER];		//	��ѹ
	char	szNode[3][PGND_CHARLEN];			//	�ڵ�
}	DISALIGN;
typedef	struct	_CIMRectifierInverter	tagCIMRectifierInverter;
//	ֱ�����ֲ��������ˣ���Ϊ���ڻ�����˫��ֱ��������ֱ���������ɡ�

struct	_CIMBreaker
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;				//	name
	std::string	strDesp;				//	description
	std::string	strAlias;				//	aliasName
	unsigned char bOpen;				//	Switch.normalOpen
	std::string	strParentTag;			//	Equipment.MemberOf_EquipmentContainer
	std::string	strTerminalTag[2];		//	Ϊ����дMeasurement��
	std::string	strBaseVoltageTag;		//	ConductingEquipment.BaseVoltage

	std::string	strSub;					//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strVolt;
	std::string	strNode[2];
}	DISALIGN;
typedef	struct	_CIMBreaker	tagCIMBreaker;
inline	void	InitializeCimBreaker(tagCIMBreaker& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strName.clear();
	dBuf.strDesp.clear();
	dBuf.strAlias.clear();
	dBuf.bOpen=0;
	dBuf.strParentTag.clear();
	dBuf.strTerminalTag[0].clear();
	dBuf.strTerminalTag[1].clear();
	dBuf.strBaseVoltageTag.clear();
	dBuf.strSub.clear();
	dBuf.strVolt.clear();
	dBuf.strNode[0].clear();
	dBuf.strNode[1].clear();
}

struct	_CIMDisconnector
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;					//	name
	std::string	strDesp;					//	description
	std::string	strAlias;				//	aliasName
	unsigned char bOpen;					//	Switch.normalOpen
	std::string	strParentTag;			//	Equipment.MemberOf_EquipmentContainer
	std::string	strTerminalTag[2];		//	Ϊ����дMeasurement��
	std::string	strBaseVoltageTag;		//	ConductingEquipment.BaseVoltage
	std::string	strSub;					//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strVolt;
	std::string	strNode[2];
}	DISALIGN;
typedef	struct	_CIMDisconnector	tagCIMDisconnector;
inline	void	InitializeCimDisconnector(tagCIMDisconnector& dBuf)
{
	dBuf.strResourceID.clear();			//	rdf:ID
	dBuf.strName.clear();					//	name
	dBuf.strDesp.clear();					//	description
	dBuf.strAlias.clear();				//	aliasName
	unsigned char bOpen=0;					//	Switch.normalOpen
	dBuf.strParentTag.clear();			//	Equipment.MemberOf_EquipmentContainer
	dBuf.strTerminalTag[0].clear();		//	Ϊ����дMeasurement��
	dBuf.strTerminalTag[1].clear();		//	Ϊ����дMeasurement��
	dBuf.strBaseVoltageTag.clear();		//	ConductingEquipment.BaseVoltage
	dBuf.strSub.clear();					//	�洢��վ�����ڽ������Ʒ�װ
	dBuf.strVolt.clear();
	dBuf.strNode[0].clear();
	dBuf.strNode[1].clear();
}

struct	_CIMGroundDisconnector
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;				//	name
	std::string	strDesp;				//	description
	std::string	strAlias;				//	aliasName
	unsigned char bOpen;				//	Switch.normalOpen
	std::string	strParentTag;			//	Equipment.MemberOf_EquipmentContainer
	std::string	strTerminalTag;			//	Ϊ����дMeasurement��
	std::string	strBaseVoltageTag;		//	ConductingEquipment.BaseVoltage
	std::string	strSub;					//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strVolt;
	std::string	strNode;
}	DISALIGN;
typedef	struct	_CIMGroundDisconnector	tagCIMGroundDisconnector;
inline	void	InitializeCimGroundDisconnector(tagCIMGroundDisconnector& dBuf)
{
	dBuf.strResourceID.clear();			
	dBuf.strName.clear();				
	dBuf.strDesp.clear();				
	dBuf.strAlias.clear();				
	dBuf.bOpen=0;				
	dBuf.strParentTag.clear();			
	dBuf.strTerminalTag.clear();		
	dBuf.strBaseVoltageTag.clear();		
	dBuf.strSub.clear();				
	dBuf.strVolt.clear();
	dBuf.strNode.clear();
}

struct	_CIMTerminal
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;					//	name
	std::string	strParentTag;			//	Terminal.ConductingEquipment
	std::string	strNodeTag;				//	Terminal.ConnectivityNode

	std::string	strSub;					//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strVolt;
	std::string	strNode;

	std::string	strEquimentType;
	std::string	strEquimentName;			//	�洢��װ��
}	DISALIGN;
typedef	struct	_CIMTerminal	tagCIMTerminal;
inline	void	InitializeCimTerminal(tagCIMTerminal& dBuf)
{
	dBuf.strResourceID.clear();			//	rdf:ID
	dBuf.strName.clear();				//	name
	dBuf.strParentTag.clear();			//	Terminal.ConductingEquipment
	dBuf.strNodeTag.clear();			//	Terminal.ConnectivityNode
	dBuf.strSub.clear();				//	�洢��վ�����ڽ������Ʒ�װ
	dBuf.strVolt.clear();
	dBuf.strNode.clear();
	dBuf.strEquimentType.clear();
	dBuf.strEquimentName.clear();		//	�洢��װ��
}

struct	_CIMConnectivityNode
{
	std::string	strResourceID;	//	rdf:ID
	std::string	strName;		//	name
	std::string	strParentTag;	//	ConnectivityNode.MemberOf_EquipmentContainer
	std::string	strSub;			//	�洢��վ�����ڽ������Ʒ�װ
	std::string	strVolt;
}	DISALIGN;
typedef	struct	_CIMConnectivityNode	tagCIMConnectivityNode;
inline	void	InitializeCimConnectivityNode(tagCIMConnectivityNode& dBuf)
{
	dBuf.strResourceID.clear();	
	dBuf.strName.clear();		
	dBuf.strParentTag.clear();	
	dBuf.strSub.clear();		
	dBuf.strVolt.clear();
}

struct	_CIMMeasurementType
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szAlias[MDB_CHARLEN];				//	aliasName
	char	szDesp[MDB_CHARLEN_LONG];			//	description
}	DISALIGN;
typedef	struct	_CIMMeasurementType	tagCIMMeasurementType;

struct	_CIMMeasurementSource
{
	char	szResourceID[MDB_CHARLEN];				//	rdf:ID
	char	szName[MDB_CHARLEN];					//	name
	char	szDesp[MDB_CHARLEN_LONG];						//	description
}	DISALIGN;
typedef	struct	_CIMMeasurementSource	tagCIMMeasurementSource;

struct	_CIMMeasurementValue
{
	std::string	strResourceID;				//	rdf:ID
	std::string	strMeasurementValue;		//	MeasurementValue
	std::string	strMeasurementTag;			//	MeasurementValue.MemberOf_Measurement
	std::string	strMeasurementSourceTag;	//	MeasurementValue.MeasurementValueSource
	std::string	strMeasurementSource;
}	DISALIGN;
typedef	struct	_CIMMeasurementValue	tagCIMMeasurementValue;
inline	void	InitializeCimMeasurementValue(tagCIMMeasurementValue& dBuf)
{
	dBuf.strResourceID.clear();				//	rdf:ID
	dBuf.strMeasurementValue.clear();		//	MeasurementValue
	dBuf.strMeasurementTag.clear();			//	MeasurementValue.MemberOf_Measurement
	dBuf.strMeasurementSourceTag.clear();	//	MeasurementValue.MeasurementValueSource
	dBuf.strMeasurementSource.clear();
}

struct	_CIMMeasurement
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;				//	name
	std::string	strDesp;					//	description
	std::string	strTerminalTag;			//	Measurement.Terminal
	std::string	strEquimentTag;			//	Measurement.MemberOf_PSR
	std::string	strMeasurementTypeTag;	//	Measurement.MeasurementType

	//short	nLimitSetNum;
	//std::string	strLimitSetTag[2];		//	Measurement.LimitSets,��ʱ����һ��

	std::string	strMeasurementSource;
	std::string	strMeasurementType;
	std::string	strMeasurementValue;

	//	�ڴ������
	std::string	strSub;
	std::string	strVolt;

	std::string	strTerminal;
	std::string	strNode;
	std::string	strEquimentType;
	std::string	strEquimentName;		//	ʹ���豸��װ����
}	DISALIGN;
typedef	struct	_CIMMeasurement		tagCIMMeasurement;
inline	void	InitilizeCimMeasurement(tagCIMMeasurement& dBuf)
{
	dBuf.strResourceID.clear();			//	rdf:ID
	dBuf.strName.clear();				//	name
	dBuf.strDesp.clear();					//	description
	dBuf.strTerminalTag.clear();			//	Measurement.Terminal
	dBuf.strEquimentTag.clear();			//	Measurement.MemberOf_PSR
	dBuf.strMeasurementTypeTag.clear();	//	Measurement.MeasurementType

	//short	nLimitSetNum=0;
	//dBuf.strLimitSetTag[0].clear();		//	Measurement.LimitSets,��ʱ����һ��
	//dBuf.strLimitSetTag[1].clear();		//	Measurement.LimitSets,��ʱ����һ��

	dBuf.strMeasurementSource.clear();
	dBuf.strMeasurementType.clear();
	dBuf.strMeasurementValue.clear();

	//	�ڴ������
	dBuf.strSub.clear();
	dBuf.strVolt.clear();

	dBuf.strTerminal.clear();
	dBuf.strNode.clear();
	dBuf.strEquimentType.clear();
	dBuf.strEquimentName.clear();		//	ʹ���豸��װ����
}

struct	_CIMAnalog
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;				//	name
	std::string	strDesp;				//	description
	std::string	strTerminalTag;			//	Measurement.Terminal
	std::string	strEquimentTag;			//	Measurement.MemberOf_PSR
	std::string	strMeasurementTypeTag;	//	Measurement.MeasurementType
// 	short	nLimitSetNum;
// 	std::string	strLimitSetTag[2];		//	Measurement.LimitSets,��ʱ����һ��

	std::string	strMeasurementSource;
	std::string	strMeasurementType;
	std::string	strMeasurementValue;

	//	�ڴ������
	std::string	strSub;
	std::string	strVolt;

	std::string	strTerminal;
	std::string	strNode;
	std::string	strEquimentType;
	std::string	strEquimentName;			//	ʹ���豸��װ����
}	DISALIGN;
typedef	struct	_CIMAnalog		tagCIMAnalog;
inline	void	InitializeCimAnalog(tagCIMAnalog& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strName.clear();
	dBuf.strDesp.clear();
	dBuf.strTerminalTag.clear();
	dBuf.strEquimentTag.clear();
	dBuf.strMeasurementTypeTag.clear();
	// 	dBuf.nLimitSetNum=0;
	// 	dBuf.strLimitSetTag[0].clear();
	// 	dBuf.strLimitSetTag[1].clear();

	dBuf.strMeasurementSource.clear();
	dBuf.strMeasurementType.clear();
	dBuf.strMeasurementValue.clear();

	//	�ڴ������
	dBuf.strSub.clear();
	dBuf.strVolt.clear();

	dBuf.strTerminal.clear();
	dBuf.strNode.clear();
	dBuf.strEquimentType.clear();
	dBuf.strEquimentName.clear();
}

struct	_CIMDiscrete
{
	std::string	strResourceID;			//	rdf:ID
	std::string	strName;				//	name
	std::string	strDesp;				//	description
	std::string	strTerminalTag;			//	Measurement.Terminal
	std::string	strEquimentTag;			//	Measurement.MemberOf_PSR
	std::string	strMeasurementTypeTag;	//	Measurement.MeasurementType
	short	nLimitSetNum;
	std::string	strLimitSetTag[2];		//	Measurement.LimitSets,��ʱ����һ��

	std::string	strMeasurementSource;
	std::string	strMeasurementType;
	std::string	strMeasurementValue;

	//	�ڴ������
	std::string	strSub;
	std::string	strVolt;

	std::string	strTerminal;
	std::string	strNode;
	std::string	strEquimentType;
	std::string	strEquimentName;			//	ʹ���豸��װ����
}	DISALIGN;
typedef	struct	_CIMDiscrete		tagCIMDiscrete;
inline	void	InitializeCimDiscrete(tagCIMDiscrete& dBuf)
{
	dBuf.strResourceID.clear();
	dBuf.strName.clear();
	dBuf.strDesp.clear();
	dBuf.strTerminalTag.clear();
	dBuf.strEquimentTag.clear();
	dBuf.strMeasurementTypeTag.clear();
	dBuf.nLimitSetNum=0;
	dBuf.strLimitSetTag[0].clear();
	dBuf.strLimitSetTag[1].clear();

	dBuf.strMeasurementSource.clear();
	dBuf.strMeasurementType.clear();
	dBuf.strMeasurementValue.clear();

	//	�ڴ������
	dBuf.strSub.clear();
	dBuf.strVolt.clear();

	dBuf.strTerminal.clear();
	dBuf.strNode.clear();
	dBuf.strEquimentType.clear();
	dBuf.strEquimentName.clear();
}

struct	_CIMLimitSet
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
}	DISALIGN;
typedef	struct	_CIMLimitSet		tagCIMLimitSet;

struct	_CIMLimit
{
	char	szResourceID[MDB_CHARLEN];			//	rdf:ID
	char	szName[MDB_CHARLEN];				//	name
	char	szLimitSetTag[MDB_CHARLEN];
	double	fValue;								//	value
	char	szLimitSet[MDB_CHARLEN];
}	DISALIGN;
typedef	struct	_CIMLimit			tagCIMLimit;

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(fPower)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
