// CIMData.cpp: implementation of the CCIMData class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CIMData.h"

#include <xercesc/util/XMLUniDefs.hpp>
#include <xercesc/sax/AttributeList.hpp>
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/PlatformUtils.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/TransService.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/parsers/SAXParser.hpp"
#include "../../3rdParty/xerces-c-3.1.1/src/xercesc/util/OutOfMemoryException.hpp"
#include "CIMData_SAXHandlers.hpp"

#if (!defined(WIN64))
#	pragma comment(lib, "../../lib/xerces-c_3.lib")
#else					 
#	pragma comment(lib, "../../lib_x64/xerces-c_3.lib")
#endif

static bool                     doNamespaces        = false;
static bool                     doSchema            = false;
static bool                     schemaFullChecking  = false;
static const char*              encodingName    = "LATIN1";
static XMLFormatter::UnRepFlags unRepFlags      = XMLFormatter::UnRep_CharRef;
static SAXParser::ValSchemes    valScheme       = SAXParser::Val_Auto;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


int CCIMData::ParseXmlBySax(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement)
{
	m_bParseMeasurement=bParseMeasurement;
	try
	{
		XMLPlatformUtils::Initialize();
	}

	catch (const XMLException& toCatch)
	{
		char*	lpszMesg=XMLString::transcode(toCatch.getMessage());
		XERCES_STD_QUALIFIER cerr << "Error during initialization! :\n" << lpszMesg << XERCES_STD_QUALIFIER endl;
		XMLString::release(&lpszMesg);
		return 0;
	}

	//xmlFile = lpszFileName;
	int errorCount = 0;
	//
	//  Create a SAX parser object. Then, according to what we were told on
	//  the command line, set it to validate or not.
	//
	SAXParser* parser = new SAXParser;
	parser->setValidationScheme(valScheme);
	parser->setDoNamespaces(doNamespaces);
	parser->setDoSchema(doSchema);
	parser->setHandleMultipleImports (true);
	parser->setValidationSchemaFullChecking(schemaFullChecking);

	//
	//  Create the handler object and install it as the document and error
	//  handler for the parser-> Then parse the file and catch any exceptions
	//  that propogate out
	//
	int errorCode = 0;
	try
	{
		CIMData_SAXHandlers handler(pCIMData, encodingName, unRepFlags);
		parser->setDocumentHandler(&handler);
		parser->setErrorHandler(&handler);
		parser->parse(lpszFileName);
		errorCount = parser->getErrorCount();
	}
	catch (const OutOfMemoryException&)
	{
		XERCES_STD_QUALIFIER cerr << "OutOfMemoryException" << XERCES_STD_QUALIFIER endl;
		errorCode = 5;
	}
	catch (const XMLException& toCatch)
	{
		char*	lpszMesg=XMLString::transcode(toCatch.getMessage());
		XERCES_STD_QUALIFIER cerr << "\nAn error occurred\n  Error: " << lpszMesg << "\n" << XERCES_STD_QUALIFIER endl;
		XMLString::release(&lpszMesg);
		errorCode = 4;
	}

	if(errorCode)
	{
		XMLPlatformUtils::Terminate();
		return errorCode;
	}

	//
	//  Delete the parser itself.  Must be done prior to calling Terminate, below.
	//
	delete parser;

	// And call the termination method
	XMLPlatformUtils::Terminate();

	if (errorCount > 0)
		return 0;
	else
		return 1;
	return 1;
}

int		CCIMData::FillElement(const int nCimSection, const char* lpszElementName, const char* lpszElementValue)
{
	//Log("    SAX[%s] FillElement %s = %s\n", g_CIMTableArray[nCimSection].szDesp, lpszElementName, lpszElementValue);
	switch (nCimSection)
	{
	case CIM_BasePower:					fillBasePower				(&m_BasePower,					lpszElementName, lpszElementValue);	break;
	case CIM_BaseVoltage:				fillBaseVoltage				(&m_BaseVoltageBuf,				lpszElementName, lpszElementValue);	break;
// 	case CIM_Company:					fillCompany					(&m_CompanyBuf,					lpszElementName, lpszElementValue);	break;
	case CIM_SubcontrolArea:			fillSubcontrolArea			(&m_SubcontrolAreaBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_Substation:				fillSubstation				(&m_SubstationBuf,				lpszElementName, lpszElementValue);	break;
	case CIM_VoltageLevel:				fillVoltageLevel			(&m_VoltageLevelBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_Bay:						fillBay						(&m_BayBuf,						lpszElementName, lpszElementValue);	break;
	case CIM_BusbarSection:				fillBusbarSection			(&m_BusbarSectionBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_ACLineSegment:				fillACLineSegment			(&m_ACLineSegmentBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_DCLineSegment:				fillDCLineSegment			(&m_DCLineSegmentBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_TransformerWinding:		fillTransformerWinding		(&m_TransformerWindingBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_PowerTransformer:			fillPowerTransformer		(&m_PowerTransformerBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_TapChanger:				fillTapChanger				(&m_TapChangerBuf,				lpszElementName, lpszElementValue);	break;
	case CIM_SynchronousMachine:		fillSynchronousMachine		(&m_SynchronousMachineBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_ThermalGeneratingUnit:		fillThermalGeneratingUnit	(&m_ThermalGeneratingUnitBuf,	lpszElementName, lpszElementValue);	break;
	case CIM_HydroGeneratingUnit:		fillHydroGeneratingUnit		(&m_HydroGeneratingUnitBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_EnergyConsumer:			fillEnergyConsumer			(&m_EnergyConsumerBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_Compensator:				fillCompensator				(&m_CompensatorBuf,				lpszElementName, lpszElementValue);	break;
	case CIM_RectifierInverter:			fillRectifierInverter		(&m_RectifierInverterBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_Breaker:					fillBreaker					(&m_BreakerBuf,					lpszElementName, lpszElementValue);	break;
	case CIM_Disconnector:				fillDisconnector			(&m_DisconnectorBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_DCSwitch:					fillDisconnector			(&m_DisconnectorBuf,			lpszElementName, lpszElementValue);	break;
	case CIM_GroundDisconnector:		fillGroundDisconnector		(&m_GroundDisconnectorBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_Terminal:					fillTerminal				(&m_TerminalBuf,				lpszElementName, lpszElementValue);	break;
	case CIM_ConnectivityNode:			fillConnectivityNode		(&m_ConnectivityNodeBuf,		lpszElementName, lpszElementValue);	break;
	case CIM_MeasurementType:			if (m_bParseMeasurement)	{	fillMeasurementType			(&m_MeasurementTypeBuf,		lpszElementName, lpszElementValue);	}	break;
	case CIM_MeasurementSource:			if (m_bParseMeasurement)	{	fillMeasurementSource	(&m_MeasurementSourceBuf,	lpszElementName, lpszElementValue);	}	break;
	case CIM_MeasurementValue:			if (m_bParseMeasurement)	{	fillMeasurementValue		(&m_MeasurementValueBuf,	lpszElementName, lpszElementValue);	}	break;
	case CIM_Measurement:				if (m_bParseMeasurement)	{	fillMeasurement				(&m_MeasurementBuf,			lpszElementName, lpszElementValue);	}	break;
	case CIM_Analog:					if (m_bParseMeasurement)	{	fillAnalog					(&m_AnalogBuf,				lpszElementName, lpszElementValue);	}	break;
	case CIM_Discrete:					if (m_bParseMeasurement)	{	fillDiscrete				(&m_DiscreteBuf,			lpszElementName, lpszElementValue);	}	break;
	case CIM_LimitSet:					if (m_bParseMeasurement)	{	fillLimitSet				(&m_LimitSetBuf,			lpszElementName, lpszElementValue);	}	break;
	case CIM_Limit:						if (m_bParseMeasurement)	{	fillLimit					(&m_LimitBuf,				lpszElementName, lpszElementValue);	}	break;
	default:
		return 0;
		break;
	}
	return 1;
}
