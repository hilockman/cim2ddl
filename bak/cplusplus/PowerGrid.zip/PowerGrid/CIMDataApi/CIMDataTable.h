#pragma  once

#include "CIMDataDefine.h"

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#endif

#if !defined(__GNUG__) && !defined(__GNUC__)
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

static	tagCIMNameDesp	g_CIMTableArray[]=
{
	{	CIM_BasePower,				"cim:BasePower",				"��׼ֵ",		},
	{	CIM_BaseVoltage,			"cim:BaseVoltage",				"��׼��ѹ",		},
// 	{	CIM_Company,				"cim:Company",					"��˾",			},
	{	CIM_SubcontrolArea,			"cim:SubcontrolArea",			"����",			},
	{	CIM_Substation,				"cim:Substation",				"��վ",			},
	{	CIM_VoltageLevel,			"cim:VoltageLevel",				"��ѹ�ȼ�",		},
	{	CIM_Bay,					"cim:Bay",						"���",			},
	{	CIM_BusbarSection,			"cim:BusbarSection",			"ĸ��",			},
	{	CIM_ACLineSegment,			"cim:ACLineSegment",			"������·",		},
	{	CIM_DCLineSegment,			"cim:DCLineSegment",			"ֱ����·",		},
	{	CIM_TransformerWinding,		"cim:TransformerWinding",		"��ѹ������",	},
	{	CIM_PowerTransformer,		"cim:PowerTransformer",			"��ѹ��",		},
	{	CIM_TapChanger,				"cim:TapChanger",				"�ֽ�ͷ",		},
	{	CIM_SynchronousMachine,		"cim:SynchronousMachine",		"�����",		},
	{	CIM_ThermalGeneratingUnit,	"cim:ThermalGeneratingUnit",	"���ֻ�",		},
	{	CIM_HydroGeneratingUnit,	"cim:HydroGeneratingUnit",		"ˮ�ֻ�",		},
	{	CIM_EnergyConsumer,			"cim:EnergyConsumer",			"����",			},
	{	CIM_Compensator,			"cim:Compensator",				"����",			},
	{	CIM_RectifierInverter,		"cim:RectifierInverter",		"���������",	},
	{	CIM_Breaker,				"cim:Breaker",					"����",			},
	{	CIM_Disconnector,			"cim:Disconnector",				"��բ",			},
	//{	CIM_DCSwitch,				"cim:DCSwitch",					"��բ",			},
	{	CIM_GroundDisconnector,		"cim:GroundDisconnector",		"�ص�",			},
	{	CIM_Terminal,				"cim:Terminal",					"�˵�",			},
	{	CIM_ConnectivityNode,		"cim:ConnectivityNode",			"�ڵ�",			},
	{	CIM_MeasurementType,		"cim:MeasurementType",			"��������",		},
	{	CIM_MeasurementSource,		"cim:MeasurementSource",		"������Դ",		},
	{	CIM_MeasurementValue,		"cim:MeasurementValue",			"����ֵ",		},
	{	CIM_Measurement,			"cim:Measurement",				"����",			},
	{	CIM_Analog,					"cim:Analog",					"ң��",			},
	{	CIM_Discrete,				"cim:Discrete",					"ң��",			},
	{	CIM_LimitSet,				"cim:LimitSet",					"��ֵ��",		},
	{	CIM_Limit,					"cim:Limit",					"��ֵ",			},
};

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(power)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
