#include "StdAfx.h"
#include "CIMDataApi.h"
#include "CIMParser.h"

CCIMParser::CCIMParser(void)
{
}

CCIMParser::~CCIMParser(void)
{
}

int	CCIMParser::Parse(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement, const int bParseBySax, const int bNameByDesp, const int bSubstationNamePrefixSubcontrolArea)
{
	return 1;
}
