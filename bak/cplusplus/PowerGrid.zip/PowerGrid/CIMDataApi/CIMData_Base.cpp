#include "StdAfx.h"
#include "CIMData.h"
#include "../../Common/StringCommon.h"

void	CCIMData::Release()
{
	memset(&m_BasePower, 0, sizeof(tagCIMBasePower));

	if (!m_BaseVoltageArray.empty())
		m_BaseVoltageArray.clear();
	if (!m_SubcontrolAreaArray.empty())
		m_SubcontrolAreaArray.clear();
	if (!m_SubstationArray.empty())
		m_SubstationArray.clear();
	if (!m_VoltageLevelArray.empty())
		m_VoltageLevelArray.clear();
	if (!m_BayArray.empty())
		m_BayArray.clear();
	if (!m_ACLineSegmentArray.empty())
		m_ACLineSegmentArray.clear();
	if (!m_TransformerWindingArray.empty())
		m_TransformerWindingArray.clear();
	if (!m_PowerTransformerArray.empty())
		m_PowerTransformerArray.clear();
	if (!m_TapChangerArray.empty())
		m_TapChangerArray.clear();
	if (!m_SynchronousMachineArray.empty())
		m_SynchronousMachineArray.clear();
	if (!m_ThermalGeneratingUnitArray.empty())
		m_ThermalGeneratingUnitArray.clear();
	if (!m_HydroGeneratingUnitArray.empty())
		m_HydroGeneratingUnitArray.clear();
	if (!m_EnergyConsumerArray.empty())
		m_EnergyConsumerArray.clear();
	if (!m_CompensatorArray.empty())
		m_CompensatorArray.clear();
	if (!m_BusbarSectionArray.empty())
		m_BusbarSectionArray.clear();
	if (!m_BreakerArray.empty())
		m_BreakerArray.clear();
	if (!m_DisconnectorArray.empty())
		m_DisconnectorArray.clear();
	if (!m_GroundDisconnectorArray.empty())
		m_GroundDisconnectorArray.clear();
	if (!m_TerminalArray.empty())
		m_TerminalArray.clear();
	if (!m_ConnectivityNodeArray.empty())
		m_ConnectivityNodeArray.clear();

	if (!m_MeasurementTypeArray.empty())
		m_MeasurementTypeArray.clear();
	if (!m_MeasurementSourceArray.empty())
		m_MeasurementSourceArray.clear();
	if (!m_MeasurementValueArray.empty())
		m_MeasurementValueArray.clear();
	if (!m_MeasurementArray.empty())
		m_MeasurementArray.clear();
	if (!m_LimitSetArray.empty())
		m_LimitSetArray.clear();
	if (!m_LimitArray.empty())
		m_LimitArray.clear();
	m_BoundLineArray.clear();
}


void	CCIMData::StringRemove(char* lpszString, char cRemove)
{
	register int	i;
	int		nChar;
	char	szChar[260];

	nChar=0;
	for (i=0; i<(int)strlen(lpszString); i++)
	{
		if (lpszString[i] != cRemove)
		{
			szChar[nChar++]=lpszString[i];
		}
	}
	szChar[nChar]='\0';
	strcpy(lpszString, szChar);
}


void	CCIMData::StringReplace(char* lpszString, char cIni, char cRep)
{
	register int	i;
	char	szChar[260];

	for (i=0; i<(int)strlen(lpszString); i++)
	{
		if (lpszString[i] == cIni)
		{
			szChar[i]=cRep;
		}
	}
	szChar[i]='\0';
	strcpy(lpszString, szChar);
}

void CCIMData::PrevParse()
{
	Release();
}
/*
template<typename T> void CCIMData::sortByResID(std::vector<T>& pArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	T	tagMid;
	int nDn = nDn0;
	int nUp = nUp0;

	memcpy(&tagMid, &pArray[(nDn0+nUp0)/2], sizeof(T));
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(pArray[nDn].szResourceID, tagMid.szResourceID) < 0)
		{
			++nDn;
		}
		while (nUp > nDn0 && strcmp(pArray[nUp].szResourceID, tagMid.szResourceID) > 0)
		{
			--nUp;
		}

		if (nDn <= nUp)
		{
			std::swap(pArray[nDn], pArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
	{
		sortByResID(pArray, nDn0, nUp);
	}

	if (nDn < nUp0 )
	{
		sortByResID(pArray, nDn, nUp0);
	}
}
*/
//	CIM�����ƣ�name�����ڱ�ʾ��ʵ��ʹ�û�����������desp��������desp��alias��һ��������
//	���û��desp������Parase�����н�name����desp
//	��ѹ�ȼ����ɽڵ�����ģ���Ϊ��ЩCIM�еĸ�ΪBAY��BAY���ܲ�ֻһ����ѹ�ȼ�
void CCIMData::PostParse(const int bNameByDesp, const int bSubstationNamePrefixSubcontrolArea)
{
	register int	i;
	clock_t	dBeg, dEnd;
	int		nDur;

	sortBaseVoltageByResID(0, (int)m_BaseVoltageArray.size()-1);
	sortSubstationByResID(0, (int)m_SubstationArray.size()-1);
	sortVoltageLevelByResID(0, (int)m_VoltageLevelArray.size()-1);
	sortBayByResID(0, (int)m_BayArray.size()-1);

	sortACLineSegmentByResID(0, (int)m_ACLineSegmentArray.size()-1);
	sortTransformerWindingByResID(0, (int)m_TransformerWindingArray.size()-1);
	sortPowerTransformerByResID(0, (int)m_PowerTransformerArray.size()-1);
	sortBusbarSectionByResID(0, (int)m_BusbarSectionArray.size()-1);
	sortSynchronousMachineByResID(0, (int)m_SynchronousMachineArray.size()-1);
	sortEnergyConsumerByResID(0, (int)m_EnergyConsumerArray.size()-1);
	sortShuntCompensatorByResID(0, (int)m_CompensatorArray.size()-1);
	sortBreakerByResID(0, (int)m_BreakerArray.size()-1);
	sortDisconnectorByResID(0, (int)m_DisconnectorArray.size()-1);
	sortGroundDisconnectorByResID(0, (int)m_GroundDisconnectorArray.size()-1);
	sortTapChangerByTransformerWindingResID(0, (int)m_TapChangerArray.size()-1);

	sortTerminalByParentTag(0, (int)m_TerminalArray.size()-1);
	sortConnectivityNodeByResID(0, (int)m_ConnectivityNodeArray.size()-1);
	sortMeasurementByResID(0, (int)m_MeasurementArray.size()-1);
	sortMeasurementTypeByResID(0, (int)m_MeasurementTypeArray.size()-1);
	sortAnalogByResID(0, (int)m_AnalogArray.size()-1);
	sortDiscreteByResID(0, (int)m_DiscreteArray.size()-1);

	for (i=0; i<(int)m_SubcontrolAreaArray.size(); i++)
		m_SubcontrolAreaArray[i].bExclude=0;
	for (i=0; i<(int)m_SubstationArray.size(); i++)
		m_SubstationArray[i].bExclude=0;
	for (i=0; i<(int)m_VoltageLevelArray.size(); i++)
		m_VoltageLevelArray[i].bExclude=0;

	if (m_SubcontrolAreaArray.empty())
	{
		tagCIMSubcontrolArea	AreaBuf;
		memset(&AreaBuf, 0, sizeof(tagCIMSubcontrolArea));

		strcpy(AreaBuf.szName, "ϵͳ");
		strcpy(AreaBuf.szDesp, "ϵͳ");
		strcpy(AreaBuf.szAlias, "ϵͳ");
		m_SubcontrolAreaArray.push_back(AreaBuf);
	}
	if (m_SubstationArray.empty())
	{
		tagCIMSubstation	subBuf;
		InitializeCimSubstation(subBuf);

		strcpy(subBuf.szName, "ϵͳ");
		strcpy(subBuf.szDesp, "ϵͳ");
		strcpy(subBuf.szAlias, "ϵͳ");
		m_SubstationArray.push_back(subBuf);
	}


	//	��װ ��������վ����ѹͬʱȷ��
	//		��վ�з������ƣ���װ���ƣ�
	//		��ѹ�ȼ��г�վ����װ���ƣ�����ѹֵ
	//	�������豸���γɳ�վ�͵�ѹ�ȼ�
	dBeg=clock();
		SubstationVoltagePostProc(bNameByDesp, bSubstationNamePrefixSubcontrolArea);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    SubstationVoltagePostProc����ʱ%d����\n", nDur);


	//���߼������ͬ��ѹ�ȼ�
	//for (i=0; i<m_BusbarSectionArray.size(); i++)
	//{
	//    for (j=0; j<m_BaseVoltageArray.size(); j++)
	//    {
	//        if (strcmp(m_BusbarSectionArray[i].szBaseVoltageTag, m_BaseVoltageArray[j].szResourceID) == 0)
	//        {
	//            m_BusbarSectionArray[i].fVolt=m_BaseVoltageArray[j].fNominalVoltage;
	//            break;
	//        }
	//    }
	//}
	//for (i=0; i<m_CompensatorArray.size(); i++)
	//{
	//    for (j=0; j<m_BaseVoltageArray.size(); j++)
	//    {
	//        if (strcmp(m_CompensatorArray[i].szBaseVoltageTag, m_BaseVoltageArray[j].szResourceID) == 0)
	//        {
	//            m_CompensatorArray[i].fVolt=m_BaseVoltageArray[j].fNominalVoltage;
	//            break;
	//        }
	//    }
	//}
	//for (i=0; i<m_BreakerArray.size(); i++)
	//{
	//    for (j=0; j<m_BaseVoltageArray.size(); j++)
	//    {
	//        if (strcmp(m_BreakerArray[i].szBaseVoltageTag, m_BaseVoltageArray[j].szResourceID) == 0)
	//        {
	//            m_BreakerArray[i].fVolt=m_BaseVoltageArray[j].fNominalVoltage;
	//            break;
	//        }
	//    }
	//}
	//for (i=0; i<m_DisconnectorArray.size(); i++)
	//{
	//    for (j=0; j<m_BaseVoltageArray.size(); j++)
	//    {
	//        if (strcmp(m_DisconnectorArray[i].szBaseVoltageTag, m_BaseVoltageArray[j].szResourceID) == 0)
	//        {
	//            m_DisconnectorArray[i].fVolt=m_BaseVoltageArray[j].fNominalVoltage;
	//            break;
	//        }
	//    }
	//}
	//for (i=0; i<m_GroundDisconnectorArray.size(); i++)
	//{
	//    for (j=0; j<m_BaseVoltageArray.size(); j++)
	//    {
	//        if (strcmp(m_GroundDisconnectorArray[i].szBaseVoltageTag, m_BaseVoltageArray[j].szResourceID) == 0)
	//        {
	//            m_GroundDisconnectorArray[i].fVolt=m_BaseVoltageArray[j].fNominalVoltage;
	//            break;
	//        }
	//    }
	//}

	dBeg=clock();
		TransFormerPostProc(bNameByDesp);		//	ȷ��PowerTransformer��TransformerWinding��TapChanger�Ĺ�ϵ
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    TransFormerPostProc����ʱ%d����\n", nDur);

	dBeg=clock();
		fillConnetivityByTerminal(bNameByDesp);		//	ConnectivityNode��ȷ����վ�͵�ѹ
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    fillConnetivityByTerminal����ʱ%d����\n", nDur);
	//	�豸��ȷ���ڵ�Ͷ˵�(�˵���Ϊ��������)
	//	������Ҫע�������·�ĳ�վ��ͨ���˵�ȷ���ġ�

	dBeg=clock();
		MeasurementPostProc(bNameByDesp);			//	ͨ���˵�ȷ��������豸���͡��豸����(��װ����)�ȣ����û�ж˵���ͨ������ȷ������˵�
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log(g_lpszLogFile, "    MeasurementPostProc����ʱ%d����\n", nDur);

// 	for (i=0; i<m_SubstationArray.size(); i++)
// 	{
// 		Log(g_lpszCimParserLogFile, "��վ[%d]  ", i+1);		//	rdf:ID
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_SubstationArray[i].szResourceID);			//	rdf:ID
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_SubstationArray[i].szName);					//	name
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_SubstationArray[i].szDesp);					//	description
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_SubstationArray[i].szAlias);				//	aliasName
// 
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_SubstationArray[i].szSubcontrolAreaTag);	//	Substation.MemberOf_SubcontrolArea
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_SubstationArray[i].szSubcontrolArea);
// 
// 		Log(g_lpszCimParserLogFile, "[%d]\n", m_SubstationArray[i].bExclude);
// 	}
// 	for (i=0; i<m_ACLineSegmentArray.size(); i++)
// 	{
// 		Log(g_lpszCimParserLogFile, "��·[%d]  ", i+1);		//	rdf:ID
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szResourceID);		//	rdf:ID
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szName);			//	name
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szDesp);			//	description
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szAlias);			//	aliasName
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szParentTag);			//	ACLineSegment.MemberOf_Line	����CIM�в�����	Line
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szTerminalTag[0]);		//	Ϊ����дMeasurement��
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szTerminalTag[1]);		//	Ϊ����дMeasurement��
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szBaseVoltageTag);		//	ConductingEquipment.BaseVoltage
// 
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szSub[0]);		//	��Ӧ��TERMINAL�е�SUBSTATION
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szSub[1]);		//	��Ӧ��TERMINAL�е�SUBSTATION
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szVolt[0]);		//	��Ӧ��szBaseVoltageTag��VOLTAGELEVELֵ
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szVolt[1]);		//	��Ӧ��szBaseVoltageTag��VOLTAGELEVELֵ
// 		Log(g_lpszCimParserLogFile, "[%s] ", m_ACLineSegmentArray[i].szNode[0]);		//	��Ӧ��szTerminalTag��NODE
// 		Log(g_lpszCimParserLogFile, "[%s]\n", m_ACLineSegmentArray[i].szNode[1]);		//	��Ӧ��szTerminalTag��NODE
// 	}
}

void	CCIMData::ClearMemDB(tagPGBlock* pBlock)
{
	register int	i;
	for (i=0; i<MAXMDBTABLENUM; i++)
	{
		pBlock->m_nRecordNum[i]=0;
	}
	pBlock->m_nRecordNum[PG_SYSTEM]=1;
	pBlock->m_System.fBasePower=100;
}

void CCIMData::FormMeasurementTable(const char* lpszFileName, const int bOutSwitchYX, const int bOutCurrent)
{
	register int	i;
	FILE*	fp;
	fp=fopen(lpszFileName, "w");
	if (fp == NULL)
		return;

	for (i=0; i<(int)m_MeasurementArray.size(); i++)
	{
		if (m_MeasurementArray[i].strEquimentType.empty() ||
			m_MeasurementArray[i].strEquimentName.empty() ||
			m_MeasurementArray[i].strMeasurementType.empty())
			continue;

		if (STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "ActivePower") != 0
				&&	STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "ReactivePower") != 0
				&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "Current") != 0
				&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "Voltage") != 0
				//&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "Angle") != 0
				&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "TapPosition") != 0
				&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "SwitchPosition") != 0
				&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "BreakerPosition") != 0
				//&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "Analog") != 0
				//&& STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "State") != 0
				)
			continue;

		if (STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "Voltage") == 0 && strstr(m_MeasurementArray[i].strDesp.c_str(), "���ѹ") != NULL)
			continue;

		if (STRICMP(m_MeasurementArray[i].strEquimentType.c_str(), "GroundDisconnector")  == 0)
			continue;

		if (!bOutSwitchYX && STRICMP(m_MeasurementArray[i].strEquimentType.c_str(), "Disconnector")  == 0)
			continue;

		if (!bOutCurrent && STRICMP(m_MeasurementArray[i].strMeasurementType.c_str(), "Current") == 0)
			continue;

		fprintf(fp, "%s , %s , %s , %s , %s , %s , %s , %s , %s, 0, , , \n", 
			m_MeasurementArray[i].strResourceID.c_str(), 
			m_MeasurementArray[i].strName.c_str(), 
			m_MeasurementArray[i].strDesp.c_str(), 
			m_MeasurementArray[i].strEquimentType.c_str(), 
			m_MeasurementArray[i].strSub.c_str(), 
			m_MeasurementArray[i].strVolt.c_str(), 
			m_MeasurementArray[i].strEquimentName.c_str(), 
			m_MeasurementArray[i].strMeasurementType.c_str(), 
			m_MeasurementArray[i].strMeasurementValue.c_str());
	}
	fflush(fp);
	fclose(fp);
}

void	CCIMData::ReadMeasurementFile(const char* lpszFileName)
{
	FILE*	fp=fopen(lpszFileName, "r");
	if (fp == NULL)
		return;

	char	szLine[512];
	std::vector<std::string>	strEleArray;
	char*	lpszToken;
	int		nEleNum;
	while (!feof(fp))
	{
		memset(szLine, 0, 512);
		fgets(szLine, 512, fp);

		if (strlen(szLine) <= 0)
			continue;

		strEleArray.clear();
		lpszToken=strtok(szLine, "\t\n, ");
		while (lpszToken != NULL)
		{
			Trim(lpszToken);
			strEleArray.push_back(lpszToken);
			lpszToken=strtok(NULL, "\t\n, ");
		}

		nEleNum=(int)strEleArray.size();
		if (nEleNum > 8)
		{
			int nFind=findMeasurementByResID(0, (int)m_MeasurementArray.size()-1, strEleArray[0].c_str());
			if (nFind >= 0)
				m_MeasurementArray[nFind].strMeasurementValue=strEleArray[8];
		}
	}

	fclose(fp);
}

int CCIMData::FillMemDB(tagPGBlock* pBlock, const int bClearMDB, const int bNameByDesp, const float fLowVThreshold, const int bTranPuVoltageHigh)
{
	if (bClearMDB)
		ClearMemDB(pBlock);

	insertDefault(pBlock);
	insertSubcontrolArea(pBlock, bNameByDesp, 1);
	insertSubstation(pBlock, bNameByDesp);
	insertVoltageLevel(pBlock, bNameByDesp);

	PGMaint(pBlock);

	insertBusbarSection(pBlock, bNameByDesp);
	insertACLineSegment(pBlock, bNameByDesp, fLowVThreshold);
	insertTranformerWinding(pBlock, bNameByDesp, bTranPuVoltageHigh);
	insertSynchronousMachine(pBlock, bNameByDesp);
	insertEnergyConsumer(pBlock, bNameByDesp);
	insertCompensator(pBlock, bNameByDesp);
	insertBreak(pBlock, bNameByDesp);
	insertDisconnector(pBlock, bNameByDesp);

	insertDCLineSegment(pBlock, bNameByDesp);
	insertRectifierInverter(pBlock, bNameByDesp);

	PGMaint(pBlock);

	EraseNouseContainer(pBlock);

	PostFillMemDB(pBlock, bNameByDesp);

	return 1;
}

int	CCIMData::Parse(CCIMData* pCIMData, const char* lpszFileName, const int bParseMeasurement, const int bParseBySax, const int bNameByDesp, const int bSubstationNamePrefixSubcontrolArea)
{
	int	nRet=0;
	PrevParse();
	if (bParseBySax == 0)
		nRet=ParseXmlByDom(pCIMData, lpszFileName, bParseMeasurement);
	else
		nRet=ParseXmlBySax(pCIMData, lpszFileName, bParseMeasurement);
	PostParse(bNameByDesp, bSubstationNamePrefixSubcontrolArea);

	return nRet;
}

void	CCIMData::insertDefault(tagPGBlock* pBlock)
{
	register int	i;
	char		szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	strcpy(szField[PG_COMPANY_NAME], "����");
	PGAppendRecord(pBlock, MDB_NeedCheckData, PG_COMPANY, szField);

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	strcpy(szField[PG_TAPCHANGER_NAME], "�ֽ�ͷ00");
	strcpy(szField[PG_TAPCHANGER_TAPMIN], "0");
	strcpy(szField[PG_TAPCHANGER_TAPMAX], "0");
	strcpy(szField[PG_TAPCHANGER_TAPNOM], "0");
	strcpy(szField[PG_TAPCHANGER_TAPSTEP], "0");
	PGAppendRecord(pBlock, MDB_NeedCheckData, PG_TAPCHANGER, szField);

	insertTrantap(pBlock);
}

int CCIMData::PostFillMemDB(tagPGBlock* pBlock, const int bNameByDesp)
{
	dc2ac(pBlock, bNameByDesp);
	return 1;
}

void CCIMData::EraseNouseContainer(tagPGBlock* pBlock)
{
	int		nCont;

	for (nCont=0; nCont<pBlock->m_nRecordNum[PG_VOLTAGELEVEL]; nCont++)
		pBlock->m_VoltageLevelArray[nCont].bOutage=0;
	for (nCont=0; nCont<pBlock->m_nRecordNum[PG_VOLTAGELEVEL]; nCont++)
	{
		if (pBlock->m_VoltageLevelArray[nCont+1].nConnecivityNodeRange == pBlock->m_VoltageLevelArray[nCont].nConnecivityNodeRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nSynchronousMachineRange == pBlock->m_VoltageLevelArray[nCont].nSynchronousMachineRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nEnergyConsumerRange == pBlock->m_VoltageLevelArray[nCont].nEnergyConsumerRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nBusbarSectionRange == pBlock->m_VoltageLevelArray[nCont].nBusbarSectionRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nShuntCompensatorRange == pBlock->m_VoltageLevelArray[nCont].nShuntCompensatorRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nSeriesCompensatorRange == pBlock->m_VoltageLevelArray[nCont].nSeriesCompensatorRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nBreakerRange == pBlock->m_VoltageLevelArray[nCont].nBreakerRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nDisconnectorRange == pBlock->m_VoltageLevelArray[nCont].nDisconnectorRange &&
			pBlock->m_VoltageLevelArray[nCont+1].nGroundDisconnectorRange == pBlock->m_VoltageLevelArray[nCont].nGroundDisconnectorRange)
		{
			pBlock->m_VoltageLevelArray[nCont].bOutage=1;
		}
	}
	for (nCont=0; nCont<pBlock->m_nRecordNum[PG_SUBSTATION]; nCont++)
	{

	}

	nCont=0;
	while (nCont < pBlock->m_nRecordNum[PG_VOLTAGELEVEL])
	{
		if (pBlock->m_VoltageLevelArray[nCont].bOutage)
			PGRemoveRecord(pBlock, PG_VOLTAGELEVEL, nCont);
		else
			nCont++;
	}
	PGMaint(pBlock, 0);

	for (nCont=0; nCont<pBlock->m_nRecordNum[PG_SUBSTATION]; nCont++)
		pBlock->m_SubstationArray[nCont].bOutage=0;
	for (nCont=0; nCont<pBlock->m_nRecordNum[PG_SUBSTATION]; nCont++)
	{
		if (pBlock->m_SubstationArray[nCont+1].nVoltageLevelRange == pBlock->m_SubstationArray[nCont].nVoltageLevelRange &&
			pBlock->m_SubstationArray[nCont+1].nTransformerWindingRange == pBlock->m_SubstationArray[nCont].nTransformerWindingRange)
		{
			pBlock->m_SubstationArray[nCont].bOutage=1;
		}
	}

	nCont=0;
	while (nCont < pBlock->m_nRecordNum[PG_SUBSTATION])
	{
		if (pBlock->m_SubstationArray[nCont].bOutage)
			PGRemoveRecord(pBlock, PG_SUBSTATION, nCont);
		else
			nCont++;
	}
	PGMaint(pBlock, 0);
}

void CCIMData::EraseSubstation(tagPGBlock* pBlock, const char* lpszSubName)
{
	register int	i;
	int		nRec;

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SUBSTATION])
	{
		if (strcmp(pBlock->m_SubstationArray[nRec].szName, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SUBSTATION, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_VOLTAGELEVEL])
	{
		if (strcmp(pBlock->m_VoltageLevelArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_VOLTAGELEVEL, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_BUSBARSECTION])
	{
		if (strcmp(pBlock->m_BusbarSectionArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_BUSBARSECTION, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE])
	{
		if (strcmp(pBlock->m_SynchronousMachineArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SYNCHRONOUSMACHINE, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_ENERGYCONSUMER])
	{
		if (strcmp(pBlock->m_EnergyConsumerArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_ENERGYCONSUMER, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR])
	{
		if (strcmp(pBlock->m_ShuntCompensatorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SHUNTCOMPENSATOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR])
	{
		if (strcmp(pBlock->m_SeriesCompensatorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SERIESCOMPENSATOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_BREAKER])
	{
		if (strcmp(pBlock->m_BreakerArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_BREAKER, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		if (strcmp(pBlock->m_DisconnectorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_DISCONNECTOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR])
	{
		if (strcmp(pBlock->m_GroundDisconnectorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_GROUNDDISCONNECTOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		if (strcmp(pBlock->m_TransformerWindingArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_ACLINESEGMENT])
	{
		if (strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubI, lpszSubName) == 0 || strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubJ, lpszSubName) == 0)
		{
			i=0;
			while (i < pBlock->m_nRecordNum[PG_LINEVERTEX])
			{
				if (strcmp(pBlock->m_LineVertexArray[i].szParent, pBlock->m_ACLineSegmentArray[nRec].szResID) == 0)
					PGRemoveRecord(pBlock, PG_LINEVERTEX, i);
				else
					i++;
			}

			i=0;
			while (i < pBlock->m_nRecordNum[PG_GRAPHATTR])
			{
				if (strcmp(pBlock->m_GraphAttrArray[i].szParentID, pBlock->m_ACLineSegmentArray[nRec].szResID) == 0)
					PGRemoveRecord(pBlock, PG_GRAPHATTR, i);
				else
					i++;
			}
		}

		if (strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubI, lpszSubName) == 0)
			memset(pBlock->m_ACLineSegmentArray[nRec].szSubI, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_ISUBSTATION));

		if (strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubJ, lpszSubName) == 0)
			memset(pBlock->m_ACLineSegmentArray[nRec].szSubJ, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_JSUBSTATION));

		if (strlen(pBlock->m_ACLineSegmentArray[nRec].szSubI) <= 0 && strlen(pBlock->m_ACLineSegmentArray[nRec].szSubJ) <= 0)
		{
			PGRemoveRecord(pBlock, PG_ACLINESEGMENT, nRec);
		}
		else
		{
			nRec++;
		}
	}
}

void	CCIMData::EraseSubcontrolArea(tagPGBlock* pBlock, std::vector<std::string>& strSubcontrolAreaArray)
{
	int		nDel, nDiv, nSub;
	char	szSub[MDB_CHARLEN];
	for (nDel=0; nDel<(int)strSubcontrolAreaArray.size(); nDel++)
	{
		for (nDiv=0; nDiv<pBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDiv++)
		{
			if (strcmp(strSubcontrolAreaArray[nDel].c_str(), pBlock->m_SubcontrolAreaArray[nDiv].szName) != 0)
				continue;

			nSub=0;
			while (nSub<pBlock->m_nRecordNum[PG_SUBSTATION])
			{
				if (strcmp(pBlock->m_SubcontrolAreaArray[nDiv].szName, pBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
				{
					//PrintMessage("ɾ����վ:%s", pBlock->m_SubstationArray[nSub].szName);
					strcpy(szSub, pBlock->m_SubstationArray[nSub].szName);
					EraseSubstation(pBlock, szSub);
				}
				else
				{
					nSub++;
				}
			}
		}
	}

	for (nDel=0; nDel<(int)strSubcontrolAreaArray.size(); nDel++)
	{
		nDiv=0;
		while (nDiv < pBlock->m_nRecordNum[PG_SUBCONTROLAREA])
		{
			if (strcmp(pBlock->m_SubcontrolAreaArray[nDiv].szName, strSubcontrolAreaArray[nDel].c_str()) == 0)
			{
				PGRemoveRecord(pBlock, PG_SUBCONTROLAREA, nDiv);
			}
			else
			{
				nDiv++;
			}
		}
	}

	PGMaint(pBlock, 1);
}

void CCIMData::dc2ac(tagPGBlock* pBlock, const int bNameByDesp)
{
	register int	i;
	int		nVolt, nNode, nDev, nLine, nVoltBranNum;
	int		nACVolt, nDCVolt, nACNode;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);

	for (nDev=0; nDev<(int)m_RectifierInverterArray.size(); nDev++)
	{
		if (isSubstationExclude(m_RectifierInverterArray[nDev].szSub, bNameByDesp))
			continue;

		Log(g_lpszLogFile, "���������������%s.%s\n", m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szName);

		nACVolt=nDCVolt=nACNode=-1;
		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szVolt[0]);
		if (nVolt >= 0)
		{
			nVoltBranNum=0;
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				nVoltBranNum += pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange-pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange;
				nVoltBranNum += pBlock->m_ConnectivityNodeArray[nNode+1].nTransformerWindingRange-pBlock->m_ConnectivityNodeArray[nNode].nTransformerWindingRange;
			}
			if (nVoltBranNum > 0)
			{
				nACVolt=nVolt;
				for (i=pBlock->m_VoltageLevelArray[nACVolt].nConnecivityNodeRange; i<pBlock->m_VoltageLevelArray[nACVolt+1].nConnecivityNodeRange; i++)
				{
					if (strcmp(pBlock->m_ConnectivityNodeArray[i].szName, m_RectifierInverterArray[nDev].szNode[0]) == 0)
					{
						nACNode=i;
						break;
					}
				}
			}
			else
			{
				nDCVolt=nVolt;
			}
		}
		else
		{
			Log(g_lpszLogFile, "    �����������ѹ�ȼ�1���� %s %s\n", m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szVolt[0]);
		}

		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szVolt[1]);
		if (nVolt >= 0)
		{
			nVoltBranNum=0;
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				nVoltBranNum += pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange-pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange;
				nVoltBranNum += pBlock->m_ConnectivityNodeArray[nNode+1].nTransformerWindingRange-pBlock->m_ConnectivityNodeArray[nNode].nTransformerWindingRange;
			}
			if (nVoltBranNum > 0)
			{
				nACVolt=nVolt;
				for (i=pBlock->m_VoltageLevelArray[nACVolt].nConnecivityNodeRange; i<pBlock->m_VoltageLevelArray[nACVolt+1].nConnecivityNodeRange; i++)
				{
					if (strcmp(pBlock->m_ConnectivityNodeArray[i].szName, m_RectifierInverterArray[nDev].szNode[1]) == 0)
					{
						nACNode=i;
						break;
					}
				}
			}
			else
			{
				nDCVolt=nVolt;
			}
		}
		else
		{
			Log(g_lpszLogFile, "    �����������ѹ�ȼ�2���� %s %s\n", m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szVolt[1]);
		}

		nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szVolt[2]);
		if (nVolt >= 0)
		{
			nVoltBranNum=0;
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				nVoltBranNum += pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange-pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange;
				nVoltBranNum += pBlock->m_ConnectivityNodeArray[nNode+1].nTransformerWindingRange-pBlock->m_ConnectivityNodeArray[nNode].nTransformerWindingRange;
			}
			if (nVoltBranNum > 0)
			{
				nACVolt=nVolt;
				for (i=pBlock->m_VoltageLevelArray[nACVolt].nConnecivityNodeRange; i<pBlock->m_VoltageLevelArray[nACVolt+1].nConnecivityNodeRange; i++)
				{
					if (strcmp(pBlock->m_ConnectivityNodeArray[i].szName, m_RectifierInverterArray[nDev].szNode[2]) == 0)
					{
						nACNode=i;
						break;
					}
				}
			}
			else
			{
				nDCVolt=nVolt;
			}
		}
		else
		{
			Log(g_lpszLogFile, "    �����������ѹ�ȼ�3���� %s %s\n", m_RectifierInverterArray[nDev].szSub, m_RectifierInverterArray[nDev].szVolt[2]);
		}

		if (nACVolt < 0 || nDCVolt < 0 || nACNode < 0)
		{
			Log(g_lpszLogFile, "        ACVolt=%d DCVolt=%d ACNode=%d\n", nACVolt, nDCVolt, nACNode);
			continue;
		}
		Log(g_lpszLogFile, "        ACVolt=%d(%s.%s)    DCVolt=%d(%s.%s) ACNode=%d\n", 
			nACVolt, pBlock->m_VoltageLevelArray[nACVolt].szSub, pBlock->m_VoltageLevelArray[nACVolt].szName, 
			nDCVolt, pBlock->m_VoltageLevelArray[nDCVolt].szSub, pBlock->m_VoltageLevelArray[nDCVolt].szName, 
			nACNode);


		//	������Ҫע����Ϊֱ����·�Ĳɼ�û�У�������Ҫ¼�����������
		for (nLine=0; nLine<(int)m_DCLineSegmentArray.size(); nLine++)
		{
			if (nDCVolt == PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, m_DCLineSegmentArray[nLine].szSub[0], m_DCLineSegmentArray[nLine].szVolt[0]) ||
				nDCVolt == PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, m_DCLineSegmentArray[nLine].szSub[1], m_DCLineSegmentArray[nLine].szVolt[1]))
			{
				strcpy(szField[PG_ENERGYCONSUMER_RESOURCEID],		m_DCLineSegmentArray[nLine].szResourceID);
				strcpy(szField[PG_ENERGYCONSUMER_NAME],				m_RectifierInverterArray[nDev].szName);
				strcpy(szField[PG_ENERGYCONSUMER_DESC],				m_DCLineSegmentArray[nLine].szDesp);
				strcpy(szField[PG_ENERGYCONSUMER_SUBSTATION],		m_RectifierInverterArray[nDev].szSub);
				strcpy(szField[PG_ENERGYCONSUMER_VOLTAGELEVEL],		pBlock->m_VoltageLevelArray[nACVolt].szName);
				strcpy(szField[PG_ENERGYCONSUMER_CONNECTIVITYNODE],	pBlock->m_ConnectivityNodeArray[nACNode].szName);
				PGAppendRecord(pBlock, MDB_NeedCheckData, PG_ENERGYCONSUMER, szField);

				//strcpy(m_DCLineSegmentArray[nLine].szName, m_RectifierInverterArray[nDev].szName);
				//strcpy(m_DCLineSegmentArray[nLine].szVolt[0], pBlock->m_VoltageLevelArray[nACVolt].szName);
				//strcpy(m_DCLineSegmentArray[nLine].szNode[0], pBlock->m_ConnectivityNodeArray[nACNode].szName);

				Log(g_lpszLogFile, "        EnergyConsumer=(%s.%s.%s)\n", m_RectifierInverterArray[nDev].szSub, pBlock->m_VoltageLevelArray[nACVolt].szName, m_RectifierInverterArray[nDev].szName);
			}
		}
	}
	PGMaint(pBlock);
}

void	CCIMData::AddOutnetEQGen(tagPGBlock* pBlock, const unsigned char bSetUnOutnet, std::vector<std::string>& strOutnetSubstationArray)
{
	register int	i;
	int			nSub, nVolt, nNode, nDev;
	unsigned char	bFind;
	std::vector<std::string>	strSelArray;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];

	if (strOutnetSubstationArray.empty())
		return;

	double	fBuf, fFactor=0.85;
	for (i=0; i<(int)strOutnetSubstationArray.size(); i++)
	{
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, strOutnetSubstationArray[i].c_str());
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
				{
					memset(&pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]], 0, sizeof(tagPGSynchronousMachine));

					if (bSetUnOutnet)
					{
						if (strcmp(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, pBlock->m_EdgeACLineSegmentArray[nDev].szSub) == 0)
						{
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeI);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltI);
						}
						else
						{
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubJ);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeJ);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltJ);
						}
					}
					else
					{
						if (strcmp(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, pBlock->m_EdgeACLineSegmentArray[nDev].szSub) == 0)
						{
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubJ);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeJ);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltJ);
						}
						else
						{
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeI);
							strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltI);
						}
					}


					strcpy(pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szName, pBlock->m_EdgeACLineSegmentArray[nDev].szName);
					pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanP=10;
					pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanQ=0;

					if (pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fRatedCur > 0.1)
					{
						fBuf=1.732*pBlock->m_VoltageLevelArray[nVolt].nominalVoltage*pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fRatedCur/1000;
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=(float)fBuf;
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=(float)-fBuf;
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=(float)(fBuf*sqrt(1-fFactor*fFactor)/fFactor);
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=(float)(-fBuf*sqrt(1-fFactor*fFactor)/fFactor);
					}
					else
					{
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=9999;
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=-9999;
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=9999;
						pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=-9999;
					}
					pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanV=1.02f;
					pBlock->m_SynchronousMachineArray[pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].nType=PGGetFieldEnumValue(PG_SYNCHRONOUSMACHINE, PG_SYNCHRONOUSMACHINE_TYPE, "��ֵ����");
					pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]++;
				}
			}
		}
	}
	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	strcpy(szField[PG_COMPANY_NAME], "����");
	PGAppendRecord(pBlock, MDB_NeedCheckData, PG_COMPANY, szField);

	strcpy(szField[PG_SUBCONTROLAREA_COMPANY], "����");
	strcpy(szField[PG_SUBCONTROLAREA_NAME], "����");
	PGAppendRecord(pBlock, MDB_NeedCheckData, PG_SUBCONTROLAREA, szField);

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (i=0; i<(int)strOutnetSubstationArray.size(); i++)
		{
			if (strcmp(pBlock->m_SubstationArray[nSub].szName, strOutnetSubstationArray[i].c_str()) == 0)
			{
				strcpy(pBlock->m_SubstationArray[nSub].szCompany, "����");
				strcpy(pBlock->m_SubstationArray[nSub].szSubcontrolArea, "����");
				break;
			}
		}
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_BREAKER])
	{
		bFind=0;
		for (i=0; i<(int)strOutnetSubstationArray.size(); i++)
		{
			if (strcmp(pBlock->m_BreakerArray[nDev].szSub, strOutnetSubstationArray[i].c_str()) == 0)
			{
				PGRemoveRecord(pBlock, PG_BREAKER, nDev);
				bFind=1;
				break;
			}
		}
		if (!bFind)
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		bFind=0;
		for (i=0; i<(int)strOutnetSubstationArray.size(); i++)
		{
			if (strcmp(pBlock->m_DisconnectorArray[nDev].szSub, strOutnetSubstationArray[i].c_str()) == 0)
			{
				PGRemoveRecord(pBlock, PG_DISCONNECTOR, nDev);
				bFind=1;
				break;
			}
		}
		if (!bFind)
			nDev++;
	}

	nDev=0;
	while (nDev < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		bFind=0;
		for (i=0; i<(int)strOutnetSubstationArray.size(); i++)
		{
			if (strcmp(pBlock->m_TransformerWindingArray[nDev].szSub, strOutnetSubstationArray[i].c_str()) == 0)
			{
				PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, nDev);
				bFind=1;
				break;
			}
		}
		if (!bFind)
			nDev++;
	}

	PGMaint(pBlock);
}
