#pragma once

typedef	struct	_PGGroupBoundDev_
{
	unsigned char	nDevType;
	int				nDevIndex;
}	tagPGGroupBoundDev;

typedef	struct	_PGNode2Load_
{
	std::vector<int>	nLoadArray;
}	tagPGNode2Load;

typedef	struct	_PGLoadGroupA_
{
	float				fTotLoadP;
	std::vector<int>	nBoundNodeArray;
	std::vector<tagPGGroupBoundDev>	boundDevArray;
	std::vector<int>	nGroupLoadArray;
}	tagPGLoadGroupA;

typedef	struct	_PGLoadGroup_
{
	float	fTotLoadP;
	int		nSubstation;
	int		nACLineSegment;
	std::vector<int>	nGroupLoadArray;
}	tagPGLoadGroup;

class CPGLoadGroup
{
public:
	CPGLoadGroup(void);
	~CPGLoadGroup(void);

	void PGGroupLoadA(tagPGBlock* pPGBlock, const int bCheckOpen);
	void PGGroupLoadB(tagPGBlock* pPGBlock, const int bCheckOpen);
	void PGGroupLoadC(tagPGBlock* pPGBlock, const int bCheckOpen);
	void PGGroupLoadD(tagPGBlock* pPGBlock, const int bCheckOpen);

	std::vector<tagPGNode2Load>		m_Node2LoadArray;
	std::vector<tagPGLoadGroupA>	m_GroupAArray;
	std::vector<tagPGLoadGroup>		m_GroupBArray;
	std::vector<tagPGLoadGroup>		m_GroupCArray;
	std::vector<tagPGLoadGroup>		m_GroupDArray;
};
