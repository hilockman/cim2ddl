
// PGLoadAnalysisDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGLoadAnalysisApp.h"
#include "PGLoadAnalysisDlg.h"
#include "BoundSetDialog.h"
#include "../../Common/Excel/ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPGLoadAnalysisDlg �Ի���


static	char*	lpszLoadColumn[]=
{
	"��վ", 
	"��ѹ", 
	"����", 
};

static	char*	lpszLoadRadiusColumn[]=
{
	"��������", 
	"��������", 
	"���糤��", 
	"������վ", 
	"�����豸����", 
	"�����豸����", 
	"���", 
	"�յ�", 
	"����", 
};

static	char*	lpszLoadGroupAColumn[]=
{
	"������", 
	"�ܸ���", 
	"�߽�", 
	"��������", 
	"�����й�", 
	"��������", 
	"ֱ����·��", 
	"ֱ����·", 
};

static	char*	lpszLoadGroupBColumn[]=
{
	"������", 
	"�ܸ���", 
	"��վ", 
	"��·", 
	"��������", 
	"�����й�", 
	"��������", 
	"ֱ����·��", 
	"ֱ����·", 
};

static	char*	lpszLoadGroupColumn[]=
{
	"������", 
	"�ܸ���", 
	"��վ", 
	"��������", 
	"�����й�", 
	"��������", 
	"ֱ����·��", 
	"ֱ����·", 
};

CPGLoadAnalysisDlg::CPGLoadAnalysisDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPGLoadAnalysisDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_LoadRadiusArray.clear();
}

void CPGLoadAnalysisDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LOAD_LIST, m_wndLoadList);
	//DDX_Control(pDX, IDC_TRACE_TREE, m_wndTraceRouter);
}

BEGIN_MESSAGE_MAP(CPGLoadAnalysisDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_SETBOUND, &CPGLoadAnalysisDlg::OnBnClickedSetbound)
	ON_BN_CLICKED(IDC_LOAD_SOURCE_RADIUS, &CPGLoadAnalysisDlg::OnBnClickedLoadSourceRadius)
	ON_CBN_SELCHANGE(IDC_SUBSTATION_COMBO, &CPGLoadAnalysisDlg::OnCbnSelchangeSubstationCombo)
	ON_CBN_SELCHANGE(IDC_SUBCONTROLAREA_COMBO, &CPGLoadAnalysisDlg::OnCbnSelchangeSubcontrolareaCombo)
	ON_BN_CLICKED(IDC_ALLLOAD_SOURCE_RADIUS, &CPGLoadAnalysisDlg::OnBnClickedAllloadSourceRadius)
	ON_BN_CLICKED(IDC_REFRESH, &CPGLoadAnalysisDlg::OnBnClickedRefresh)
	ON_BN_CLICKED(IDC_LOAD_GROUPA, &CPGLoadAnalysisDlg::OnBnClickedLoadGroupa)
	ON_BN_CLICKED(IDC_LOAD_GROUPB, &CPGLoadAnalysisDlg::OnBnClickedLoadGroupb)
	ON_BN_CLICKED(IDC_LOAD_GROUPC, &CPGLoadAnalysisDlg::OnBnClickedLoadGroupc)
	ON_BN_CLICKED(IDC_LOAD_GROUPD, &CPGLoadAnalysisDlg::OnBnClickedLoadGroupd)
	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CPGLoadAnalysisDlg::OnBnClickedSaveasExcel)
END_MESSAGE_MAP()


// CPGLoadAnalysisDlg ��Ϣ��������

BOOL CPGLoadAnalysisDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	register int	i;
	CComboBox*	pComboBox;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszLoadColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLoadColumn[i],	LVCFMT_LEFT,	100);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBCONTROLAREA_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pComboBox->AddString(g_pPGBlock->m_SubcontrolAreaArray[i].szName);

	CButton*	pButton;
	pButton=(CButton*)GetDlgItem(IDC_CHECK_STATUS);
	pButton->SetCheck(1);

	pButton=(CButton*)GetDlgItem(IDC_GROUP_STATUS);
	pButton->SetCheck(1);

	CRect	rectBuf;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndTraceRouter.Create(WS_VISIBLE | WS_CHILD , rectBuf, &m_wndTab, 30))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndTraceRouter.ModifyStyle(0, TVS_SHOWSELALWAYS|TVS_LINESATROOT|TVS_DISABLEDRAGDROP|TVS_HASBUTTONS|TVS_HASLINES);
	m_wndTraceRouter.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	if (!m_wndListLoadRadius.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 31))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLoadRadius.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLoadRadius.SetExtendedStyle(m_wndListLoadRadius.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLoadRadius.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLoadRadiusColumn)/sizeof(char*); i++)
		m_wndListLoadRadius.InsertColumn(i, lpszLoadRadiusColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLoadGroupA.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 32))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLoadGroupA.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLoadGroupA.SetExtendedStyle(m_wndListLoadGroupA.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLoadGroupA.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLoadGroupAColumn)/sizeof(char*); i++)
		m_wndListLoadGroupA.InsertColumn(i, lpszLoadGroupAColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLoadGroupB.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 33))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLoadGroupB.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLoadGroupB.SetExtendedStyle(m_wndListLoadGroupB.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLoadGroupB.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLoadGroupBColumn)/sizeof(char*); i++)
		m_wndListLoadGroupB.InsertColumn(i, lpszLoadGroupBColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLoadGroupC.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 34))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLoadGroupC.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLoadGroupC.SetExtendedStyle(m_wndListLoadGroupC.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLoadGroupC.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLoadGroupColumn)/sizeof(char*); i++)
		m_wndListLoadGroupC.InsertColumn(i, lpszLoadGroupColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndListLoadGroupD.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, 35))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListLoadGroupD.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListLoadGroupD.SetExtendedStyle(m_wndListLoadGroupD.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListLoadGroupD.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLoadGroupColumn)/sizeof(char*); i++)
		m_wndListLoadGroupD.InsertColumn(i, lpszLoadGroupColumn[i],	LVCFMT_LEFT,	100);

	
	m_wndTab.AddTab (&m_wndTraceRouter,			_T("���ɹ���·��"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListLoadRadius,		_T("���ɹ���뾶"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndListLoadGroupA,		_T("������A"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListLoadGroupB,		_T("������B"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListLoadGroupC,		_T("������C"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndListLoadGroupD,		_T("������D"),		-1, FALSE);

	OnBnClickedRefresh();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CPGLoadAnalysisDlg::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshSubCombo();
	RefreshLoadList();
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CPGLoadAnalysisDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CPGLoadAnalysisDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CPGLoadAnalysisDlg::OnBnClickedSetbound()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CBoundSetDialog	dlg;
	dlg.DoModal();
}

void FormBoundNodeSet(tagPGBlock* pPGBlock, std::vector<int>& nBoundNodeArray)
{
	register int	i;
	int		nBound, nSub, nVolt;

	nBoundNodeArray.clear();
	
	for (nBound=0; nBound<(int)g_BoundArray.size(); nBound++)
	{
		if (g_BoundArray[nBound].nDevType == PG_SUBSTATION)
		{
			nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, g_BoundArray[nBound].strDevName.c_str());
			if (nSub < 0)
				continue;

			for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (i=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; i++)
				{
					nBoundNodeArray.push_back(i);
				}
			}
		}
		else if (g_BoundArray[nBound].nDevType == PG_BUSBARSECTION)
		{
			nVolt=PGFindRecordbyKey(pPGBlock, PG_VOLTAGELEVEL, g_BoundArray[nBound].strDevSub.c_str(), g_BoundArray[nBound].strDevVolt.c_str());
			if (nVolt < 0)
				continue;

			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; i++)
			{
				if (pPGBlock->m_BusbarSectionArray[i].nNode < 0)
					continue;

				if (stricmp(pPGBlock->m_BusbarSectionArray[i].szName, g_BoundArray[nBound].strDevName.c_str()) == 0)
					nBoundNodeArray.push_back(pPGBlock->m_BusbarSectionArray[i].nNode);
			}
		}
	}
}

void CPGLoadAnalysisDlg::OnBnClickedLoadSourceRadius()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nItem=-1;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
		nItem=pListCtrl->GetNextSelectedItem(pos);

	CButton*	pButton=(CButton*)GetDlgItem(IDC_CHECK_STATUS);
	unsigned char	bCheckStatus=pButton->GetCheck();

	if (nItem < 0 || nItem >= pListCtrl->GetItemCount())
		return;

	int		nLoad=-1;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szSub, pListCtrl->GetItemText(nItem, 0)) == 0 &&
			stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szVolt, pListCtrl->GetItemText(nItem, 1)) == 0 &&
			stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szName, pListCtrl->GetItemText(nItem, 2)) == 0)
		{
			nLoad=i;
			break;
		}
	}
	if (nLoad < 0)
		return;
	if (g_pPGBlock->m_EnergyConsumerArray[nLoad].nNode < 0)
		return;

	std::vector<int>	nBoundNodeArray;
	nBoundNodeArray.clear();
	FormBoundNodeSet(g_pPGBlock, nBoundNodeArray);
	g_PGTrace.PGTraceSource(g_pPGBlock, bCheckStatus, g_pPGBlock->m_EnergyConsumerArray[nLoad].nNode, nBoundNodeArray, m_TraceRouterArray, m_TraceEndingArray);

	m_wndTraceRouter.DeleteAllItems();
	FillTrace(nLoad, m_TraceRouterArray, m_TraceEndingArray);
}

void CPGLoadAnalysisDlg::FillTrace(const int nLoad, std::vector<tagPGRouter>& routerArray, std::vector<tagPGSource>& endingArray)
{
	register int	i;
	TV_INSERTSTRUCT itemTree;
	HTREEITEM		hItem;
	char			szTree[260];

	for (i=0; i<(int)routerArray.size(); i++)
		routerArray[i].bMarked=0;

	sprintf(szTree, "���� %s %s %s", g_pPGBlock->m_EnergyConsumerArray[nLoad].szSub, g_pPGBlock->m_EnergyConsumerArray[nLoad].szVolt, g_pPGBlock->m_EnergyConsumerArray[nLoad].szName);
	itemTree.hParent=TVI_ROOT;
	itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
	itemTree.item.pszText=szTree;
	itemTree.item.cchTextMax=260;
	itemTree.item.lParam=0;
	itemTree.item.state=TVIS_EXPANDED;
	itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
	hItem=m_wndTraceRouter.InsertItem(&itemTree);
	for (i=0; i<(int)endingArray.size(); i++)
	{
		sprintf(szTree, "���糧վ %s ����뾶=%3f.", g_pPGBlock->m_ConnectivityNodeArray[endingArray[i].nEndNode].szSub, endingArray[i].fEndLength);
		itemTree.hParent=hItem;
		itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
		itemTree.item.pszText=szTree;
		itemTree.item.cchTextMax=260;
		itemTree.item.lParam=0;
		itemTree.item.state=TVIS_EXPANDED;
		itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
		m_wndTraceRouter.InsertItem(&itemTree);
	}

	if (!routerArray.empty())
		FillTraceByDeep(routerArray, 0, routerArray[0].nDeep, hItem);

}

void CPGLoadAnalysisDlg::FillTraceByDeep(std::vector<tagPGRouter>& rArray, const int nIniRouter, const int nIniDeep, HTREEITEM hDeep)
{
	TV_INSERTSTRUCT itemTree;
	int			nRouter, nDev, nEdge;
	HTREEITEM	hItem;
	char		szBuf[260];

	hItem=hDeep;
	for (nRouter=nIniRouter; nRouter<(int)rArray.size(); nRouter++)
	{
		if (rArray[nRouter].bMarked)
			continue;
		if (rArray[nRouter].nDeep < nIniDeep)
			return;

		if (rArray[nRouter].nDeep == nIniDeep)
		{
			rArray[nRouter].bMarked=1;
			for (nDev=0; nDev<(int)rArray[nRouter].edgeArray.size(); nDev++)
			{
				nEdge=rArray[nRouter].edgeArray[nDev].nDevIndex;
				if (rArray[nRouter].edgeArray[nDev].nDevType == PG_ACLINESEGMENT)
				{
					if (stricmp(g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubI, g_pPGBlock->m_ConnectivityNodeArray[rArray[nRouter].nFrNode].szSub) == 0)
					{
						sprintf(szBuf, "%s %s[%s] (%s <-> %s) %.3f", g_pPGBlock->m_ACLineSegmentArray[nEdge].szVoltI, PGGetTableDesp(rArray[nRouter].edgeArray[nDev].nDevType), 
							g_pPGBlock->m_ACLineSegmentArray[nEdge].szName, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubI, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubJ, g_pPGBlock->m_ACLineSegmentArray[nEdge].fLength);
					}
					else
					{
						sprintf(szBuf, "%s %s[%s] (%s <-> %s) %.3f", g_pPGBlock->m_ACLineSegmentArray[nEdge].szVoltI, PGGetTableDesp(rArray[nRouter].edgeArray[nDev].nDevType), 
							g_pPGBlock->m_ACLineSegmentArray[nEdge].szName, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubJ, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubI, g_pPGBlock->m_ACLineSegmentArray[nEdge].fLength);
					}
				}
				else if (rArray[nRouter].edgeArray[nDev].nDevType == PG_TRANSFORMERWINDING)
				{
					if (stricmp(g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltI, g_pPGBlock->m_ConnectivityNodeArray[rArray[nRouter].nFrNode].szVolt) == 0)
					{
						sprintf(szBuf, "%s[%s %s] (%s <-> %s)", PGGetTableDesp(rArray[nRouter].edgeArray[nDev].nDevType), 
							g_pPGBlock->m_TransformerWindingArray[nEdge].szSub, g_pPGBlock->m_TransformerWindingArray[nEdge].szName, 
							g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltI, g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltJ);
					}
					else
					{
						sprintf(szBuf, "%s[%s %s] (%s <-> %s)", PGGetTableDesp(rArray[nRouter].edgeArray[nDev].nDevType), 
							g_pPGBlock->m_TransformerWindingArray[nEdge].szSub, g_pPGBlock->m_TransformerWindingArray[nEdge].szName, 
							g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltJ, g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltI);
					}
				}
				else if (rArray[nRouter].edgeArray[nDev].nDevType == PG_SERIESCOMPENSATOR)
				{
					sprintf(szBuf, "%s[%s %s %s]", PGGetTableDesp(rArray[nRouter].edgeArray[nDev].nDevType), 
						g_pPGBlock->m_SeriesCompensatorArray[nEdge].szSub, g_pPGBlock->m_SeriesCompensatorArray[nEdge].szVolt, g_pPGBlock->m_SeriesCompensatorArray[nEdge].szName);
				}
				else
				{
					continue;
				}

				itemTree.hParent=hDeep;
				itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
				itemTree.item.pszText=szBuf;
				itemTree.item.cchTextMax=260;
				itemTree.item.lParam=0;
				itemTree.item.state=TVIS_EXPANDED;
				itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
				hItem=m_wndTraceRouter.InsertItem(&itemTree);
			}
		}
		else if (rArray[nRouter].nDeep > nIniDeep)
		{
			FillTraceByDeep(rArray, nRouter, rArray[nRouter].nDeep, hItem);
		}
	}
}

void CPGLoadAnalysisDlg::RefreshSubCombo()
{
	register int	i;
	char	szArea[MDB_CHARLEN];
	memset(szArea, 0, MDB_CHARLEN);

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBCONTROLAREA_COMBO);
	int		nArea=pComboBox->GetCurSel();
	if (nArea != CB_ERR)
		pComboBox->GetLBText(nArea, szArea);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBSTATION_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		if (strlen(szArea) > 0)
		{
			if (stricmp(g_pPGBlock->m_SubstationArray[i].szSubcontrolArea, szArea) != 0)
				continue;
		}
		pComboBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);
	}
}

void CPGLoadAnalysisDlg::OnCbnSelchangeSubstationCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshLoadList();
}

void CPGLoadAnalysisDlg::OnCbnSelchangeSubcontrolareaCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshSubCombo();
}

void CPGLoadAnalysisDlg::RefreshLoadList()
{
	register int	i;
	int		nRow, nCol;
	char	szSub[MDB_CHARLEN];
	memset(szSub, 0, MDB_CHARLEN);

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBSTATION_COMBO);
	int			nSub=pComboBox->GetCurSel();
	if (nSub != CB_ERR)
		pComboBox->GetLBText(nSub, szSub);

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_LOAD_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (strlen(szSub) > 0)
		{
			if (stricmp(g_pPGBlock->m_EnergyConsumerArray[i].szSub, szSub) != 0)
				continue;
		}
		pListCtrl->InsertItem(nRow, g_pPGBlock->m_EnergyConsumerArray[i].szSub);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szVolt);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szName);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLoadColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGLoadAnalysisDlg::RefreshLoadRadiusList()
{
	register int	i, j;
	int		nRow, nCol, nLoadRow, nDev, nEdge;
	char	szBuf[260], szType[260], szDev[260], szFr[260], szTo[260], szOwn[260];
	std::string	strBuf;

	nRow=0;
	for (i=0; i<(int)m_LoadRadiusArray.size(); i++)
	{
		m_wndListLoadRadius.InsertItem(nRow, m_LoadRadiusArray[i].strLoad.c_str());	m_wndListLoadRadius.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%.3f", m_LoadRadiusArray[i].fLoadCapacity);	m_wndListLoadRadius.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.3f", m_LoadRadiusArray[i].fRouterLength);	m_wndListLoadRadius.SetItemText(nRow, nCol++, szBuf);

		strBuf.clear();
		for (j=0; j<(int)m_LoadRadiusArray[i].endingArray.size(); j++)
		{
			if (j > 0)
				strcat(szBuf, ", ");
			strBuf.append(g_pPGBlock->m_ConnectivityNodeArray[m_LoadRadiusArray[i].endingArray[j].nEndNode].szSub);
		}
		m_wndListLoadRadius.SetItemText(nRow, nCol++, strBuf.c_str());
		nRow++;

		nLoadRow=0;
		for (j=0; j<(int)m_LoadRadiusArray[i].routerArray.size(); j++)
		{
			for (nDev=0; nDev<(int)m_LoadRadiusArray[i].routerArray[j].edgeArray.size(); nDev++)
			{
				memset(szType, 0, 260);
				memset(szDev, 0, 260);
				memset(szFr, 0, 260);
				memset(szTo, 0, 260);
				memset(szOwn, 0, 260);
				nCol=4;
				strcpy(szType, PGGetTableDesp(m_LoadRadiusArray[i].routerArray[j].edgeArray[nDev].nDevType));
				nEdge=m_LoadRadiusArray[i].routerArray[j].edgeArray[nDev].nDevIndex;
				if (m_LoadRadiusArray[i].routerArray[j].edgeArray[nDev].nDevType == PG_ACLINESEGMENT)
				{
					strcpy(szOwn, g_pPGBlock->m_ACLineSegmentArray[nEdge].szLine);
					strcpy(szDev, g_pPGBlock->m_ACLineSegmentArray[nEdge].szName);
					if (stricmp(g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubI, g_pPGBlock->m_ConnectivityNodeArray[m_LoadRadiusArray[i].routerArray[j].nFrNode].szSub) == 0)
					{
						strcpy(szFr, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubI);
						strcpy(szTo, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubJ);
					}
					else
					{
						strcpy(szFr, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubJ);
						strcpy(szTo, g_pPGBlock->m_ACLineSegmentArray[nEdge].szSubI);
					}
				}
				else if (m_LoadRadiusArray[i].routerArray[j].edgeArray[nDev].nDevType == PG_TRANSFORMERWINDING)
				{
					sprintf(szDev, "%s %s", g_pPGBlock->m_TransformerWindingArray[nEdge].szSub, g_pPGBlock->m_TransformerWindingArray[nEdge].szName);
					if (stricmp(g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltI, g_pPGBlock->m_ConnectivityNodeArray[m_LoadRadiusArray[i].routerArray[j].nFrNode].szVolt) == 0)
					{
						strcpy(szFr, g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltI);
						strcpy(szTo, g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltJ);
					}
					else
					{
						strcpy(szFr, g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltJ);
						strcpy(szTo, g_pPGBlock->m_TransformerWindingArray[nEdge].szVoltI);
					}
				}
				else if (m_LoadRadiusArray[i].routerArray[j].edgeArray[nDev].nDevType == PG_SERIESCOMPENSATOR)
				{
					sprintf(szDev, "%s %s %s", g_pPGBlock->m_SeriesCompensatorArray[nEdge].szSub, g_pPGBlock->m_SeriesCompensatorArray[nEdge].szVolt, g_pPGBlock->m_SeriesCompensatorArray[nEdge].szName);
				}
				else
				{
				}

				m_wndListLoadRadius.InsertItem(nRow, "");	m_wndListLoadRadius.SetItemData(nRow, nRow);
				m_wndListLoadRadius.SetItemText(nRow, nCol++, szType);
				m_wndListLoadRadius.SetItemText(nRow, nCol++, szDev);
				m_wndListLoadRadius.SetItemText(nRow, nCol++, szFr);
				m_wndListLoadRadius.SetItemText(nRow, nCol++, szTo);
				m_wndListLoadRadius.SetItemText(nRow, nCol++, szOwn);
				nRow++;
			}
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLoadRadiusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLoadRadius.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLoadRadius.GetColumnWidth(nCol);
		m_wndListLoadRadius.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLoadRadius.GetColumnWidth(nCol);

		m_wndListLoadRadius.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGLoadAnalysisDlg::RefreshLoadGroupAList()
{
	register int	i, j;
	int		nGrp;
	int		nRow, nCol, nGrpRow;
	char	szBuf[260];

	nRow=0;
	for (nGrp=0; nGrp<(int)g_PGLoadGroup.m_GroupAArray.size(); nGrp++)
	{
		nGrpRow=(int)(max(g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray.size(), g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray.size()));
		if (nGrpRow <= 0)
			nGrpRow=1;
		for (i=0; i<nGrpRow; i++)
		{
			m_wndListLoadGroupA.InsertItem(nRow+i, "");
			m_wndListLoadGroupA.SetItemData(nRow+i, nRow+i);
		}

		nCol=0;
		sprintf(szBuf, "������%d", nGrp+1);	m_wndListLoadGroupA.SetItemText(nRow, nCol, szBuf);	nCol++;
		sprintf(szBuf, "%.3f", g_PGLoadGroup.m_GroupAArray[nGrp].fTotLoadP);	m_wndListLoadGroupA.SetItemText(nRow, nCol, szBuf);		nCol++;

		nCol=2;
		for (i=0; i<(int)g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray.size(); i++)
		{
			memset(szBuf, 0, 260);
			switch (g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevType)
			{
			case	PG_SUBSTATION:
				sprintf(szBuf, "%s %s", PGGetTableDesp(g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevType), g_pPGBlock->m_SubstationArray[g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevIndex].szName);
				break;
			case	PG_SUBSTATIONENTITY:
				sprintf(szBuf, "%s %s", PGGetTableDesp(g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevType), g_pPGBlock->m_SubstationEntityArray[g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevIndex].szName);
				break;
			case	PG_DISTRIBUTIONSWITCH:
				sprintf(szBuf, "%s %s", PGGetTableDesp(g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevType), g_pPGBlock->m_DistributionSwitchArray[g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevIndex].szName);
				break;
			case	PG_DISTRIBUTIONBREAKER:
				sprintf(szBuf, "%s %s", PGGetTableDesp(g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevType), g_pPGBlock->m_DistributionBreakerArray[g_PGLoadGroup.m_GroupAArray[nGrp].boundDevArray[i].nDevIndex].szName);
				break;
			}
			m_wndListLoadGroupA.SetItemText(nRow+i, nCol, szBuf);
		}

		nCol=3;
		for (i=0; i<(int)g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray.size(); i++)
		{
			sprintf(szBuf, "%s %s %s", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].szSub, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].szVolt, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].szName);
			m_wndListLoadGroupA.SetItemText(nRow+i, nCol+0, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].fPlanP);
			m_wndListLoadGroupA.SetItemText(nRow+i, nCol+1, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].fLoadCapacity);
			m_wndListLoadGroupA.SetItemText(nRow+i, nCol+2, szBuf);
			m_wndListLoadGroupA.SetItemText(nRow+i, nCol+3, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].szLineSegment);
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; j++)
			{
				if (stricmp(g_pPGBlock->m_ACLineSegmentArray[j].szName, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupAArray[nGrp].nGroupLoadArray[i]].szLineSegment) == 0)
				{
					m_wndListLoadGroupA.SetItemText(nRow+i, nCol+4, g_pPGBlock->m_ACLineSegmentArray[j].szLine);
					break;
				}
			}

		}

		nRow += nGrpRow;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLoadGroupAColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLoadGroupA.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLoadGroupA.GetColumnWidth(nCol);
		m_wndListLoadGroupA.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLoadGroupA.GetColumnWidth(nCol);

		m_wndListLoadGroupA.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGLoadAnalysisDlg::RefreshLoadGroupBList()
{
	register int	i, j;
	int		nGrp;
	int		nRow, nCol, nGrpRow;
	char	szBuf[260];

	nRow=0;
	for (nGrp=0; nGrp<(int)g_PGLoadGroup.m_GroupBArray.size(); nGrp++)
	{
		nGrpRow=(int)g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray.size();
		if (nGrpRow <= 0)
			nGrpRow=1;
		for (i=0; i<nGrpRow; i++)
		{
			m_wndListLoadGroupB.InsertItem(nRow+i, "");
			m_wndListLoadGroupB.SetItemData(nRow+i, nRow+i);
		}

		nCol=0;
		sprintf(szBuf, "������%d", nGrp+1);	m_wndListLoadGroupB.SetItemText(nRow, nCol, szBuf);												nCol++;
		sprintf(szBuf, "%.3f", g_PGLoadGroup.m_GroupBArray[nGrp].fTotLoadP);	m_wndListLoadGroupB.SetItemText(nRow, nCol, szBuf);				nCol++;
		m_wndListLoadGroupB.SetItemText(nRow, nCol, g_pPGBlock->m_SubstationArray[g_PGLoadGroup.m_GroupBArray[nGrp].nSubstation].szName);		nCol++;
		m_wndListLoadGroupB.SetItemText(nRow, nCol, g_pPGBlock->m_ACLineSegmentArray[g_PGLoadGroup.m_GroupBArray[nGrp].nACLineSegment].szName);	nCol++;

		nCol=4;
		for (i=0; i<(int)g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray.size(); i++)
		{
			sprintf(szBuf, "%s %s %s", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].szSub, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].szVolt, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].szName);
			m_wndListLoadGroupB.SetItemText(nRow+i, nCol+0, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].fPlanP);
			m_wndListLoadGroupB.SetItemText(nRow+i, nCol+1, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].fLoadCapacity);
			m_wndListLoadGroupB.SetItemText(nRow+i, nCol+2, szBuf);
			m_wndListLoadGroupB.SetItemText(nRow+i, nCol+3, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].szLineSegment);
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; j++)
			{
				if (stricmp(g_pPGBlock->m_ACLineSegmentArray[j].szName, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupBArray[nGrp].nGroupLoadArray[i]].szLineSegment) == 0)
				{
					m_wndListLoadGroupB.SetItemText(nRow+i, nCol+4, g_pPGBlock->m_ACLineSegmentArray[j].szLine);
					break;
				}
			}

		}
		nRow += nGrpRow;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLoadGroupBColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLoadGroupB.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLoadGroupB.GetColumnWidth(nCol);
		m_wndListLoadGroupB.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLoadGroupB.GetColumnWidth(nCol);

		m_wndListLoadGroupB.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGLoadAnalysisDlg::RefreshLoadGroupCList()
{
	register int	i, j;
	int		nGrp;
	int		nRow, nCol, nGrpRow;
	char	szBuf[260];

	nRow=0;
	for (nGrp=0; nGrp<(int)g_PGLoadGroup.m_GroupCArray.size(); nGrp++)
	{
		nGrpRow=(int)g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray.size();
		if (nGrpRow <= 0)
			nGrpRow=1;
		for (i=0; i<nGrpRow; i++)
		{
			m_wndListLoadGroupC.InsertItem(nRow+i, "");
			m_wndListLoadGroupC.SetItemData(nRow+i, nRow+i);
		}

		nCol=0;
		sprintf(szBuf, "������%d", nGrp+1);	m_wndListLoadGroupC.SetItemText(nRow, nCol, szBuf);												nCol++;
		sprintf(szBuf, "%.3f", g_PGLoadGroup.m_GroupCArray[nGrp].fTotLoadP);	m_wndListLoadGroupC.SetItemText(nRow, nCol, szBuf);				nCol++;
		m_wndListLoadGroupC.SetItemText(nRow, nCol, g_pPGBlock->m_SubstationArray[g_PGLoadGroup.m_GroupCArray[nGrp].nSubstation].szName);		nCol++;

		nCol=4;
		for (i=0; i<(int)g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray.size(); i++)
		{
			sprintf(szBuf, "%s %s %s", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].szSub, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].szVolt, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].szName);
			m_wndListLoadGroupC.SetItemText(nRow+i, nCol+0, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].fPlanP);
			m_wndListLoadGroupC.SetItemText(nRow+i, nCol+1, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].fLoadCapacity);
			m_wndListLoadGroupC.SetItemText(nRow+i, nCol+2, szBuf);
			m_wndListLoadGroupC.SetItemText(nRow+i, nCol+3, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].szLineSegment);
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; j++)
			{
				if (stricmp(g_pPGBlock->m_ACLineSegmentArray[j].szName, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupCArray[nGrp].nGroupLoadArray[i]].szLineSegment) == 0)
				{
					m_wndListLoadGroupC.SetItemText(nRow+i, nCol+4, g_pPGBlock->m_ACLineSegmentArray[j].szLine);
					break;
				}
			}

		}
		nRow += nGrpRow;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLoadGroupColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLoadGroupC.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLoadGroupC.GetColumnWidth(nCol);
		m_wndListLoadGroupC.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLoadGroupC.GetColumnWidth(nCol);

		m_wndListLoadGroupC.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGLoadAnalysisDlg::RefreshLoadGroupDList()
{
	register int	i, j;
	int		nGrp;
	int		nRow, nCol, nGrpRow;
	char	szBuf[260];

	nRow=0;
	for (nGrp=0; nGrp<(int)g_PGLoadGroup.m_GroupDArray.size(); nGrp++)
	{
		nGrpRow=(int)g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray.size();
		if (nGrpRow <= 0)
			nGrpRow=1;
		for (i=0; i<nGrpRow; i++)
		{
			m_wndListLoadGroupD.InsertItem(nRow+i, "");
			m_wndListLoadGroupD.SetItemData(nRow+i, nRow+i);
		}

		nCol=0;
		sprintf(szBuf, "������%d", nGrp+1);	m_wndListLoadGroupD.SetItemText(nRow, nCol, szBuf);												nCol++;
		sprintf(szBuf, "%.3f", g_PGLoadGroup.m_GroupDArray[nGrp].fTotLoadP);	m_wndListLoadGroupD.SetItemText(nRow, nCol, szBuf);				nCol++;
		m_wndListLoadGroupD.SetItemText(nRow, nCol, g_pPGBlock->m_SubstationArray[g_PGLoadGroup.m_GroupDArray[nGrp].nSubstation].szName);		nCol++;

		nCol=4;
		for (i=0; i<(int)g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray.size(); i++)
		{
			sprintf(szBuf, "%s %s %s", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].szSub, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].szVolt, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].szName);
			m_wndListLoadGroupD.SetItemText(nRow+i, nCol+0, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].fPlanP);
			m_wndListLoadGroupD.SetItemText(nRow+i, nCol+1, szBuf);
			sprintf(szBuf, "%.3f", g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].fLoadCapacity);
			m_wndListLoadGroupD.SetItemText(nRow+i, nCol+2, szBuf);
			m_wndListLoadGroupD.SetItemText(nRow+i, nCol+3, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].szLineSegment);
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; j++)
			{
				if (stricmp(g_pPGBlock->m_ACLineSegmentArray[j].szName, g_pPGBlock->m_EnergyConsumerArray[g_PGLoadGroup.m_GroupDArray[nGrp].nGroupLoadArray[i]].szLineSegment) == 0)
				{
					m_wndListLoadGroupD.SetItemText(nRow+i, nCol+4, g_pPGBlock->m_ACLineSegmentArray[j].szLine);
					break;
				}
			}

		}
		nRow += nGrpRow;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLoadGroupColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListLoadGroupD.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListLoadGroupD.GetColumnWidth(nCol);
		m_wndListLoadGroupD.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListLoadGroupD.GetColumnWidth(nCol);

		m_wndListLoadGroupD.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGLoadAnalysisDlg::OnBnClickedAllloadSourceRadius()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nLoad;
	char	szBuf[260];

	std::vector<int>	nBoundNodeArray;
	nBoundNodeArray.clear();
	FormBoundNodeSet(g_pPGBlock, nBoundNodeArray);

	m_LoadRadiusArray.clear();
	m_LoadRadiusArray.resize(g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]);
	for (nLoad=0; nLoad<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nLoad++)
	{
		sprintf(szBuf, "%s %s %s", g_pPGBlock->m_EnergyConsumerArray[nLoad].szSub, g_pPGBlock->m_EnergyConsumerArray[nLoad].szVolt, g_pPGBlock->m_EnergyConsumerArray[nLoad].szName);
		m_LoadRadiusArray[nLoad].strLoad=szBuf;
		m_LoadRadiusArray[nLoad].fLoadCapacity=g_pPGBlock->m_EnergyConsumerArray[nLoad].fLoadCapacity;
		m_LoadRadiusArray[nLoad].fRouterLength=0;
		m_LoadRadiusArray[nLoad].routerArray.clear();
		m_LoadRadiusArray[nLoad].endingArray.clear();
	}

	m_wndTraceRouter.DeleteAllItems();
	for (nLoad=0; nLoad<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nLoad++)
	{
		if (g_pPGBlock->m_EnergyConsumerArray[nLoad].nNode < 0)
			continue;

		g_PGTrace.PGTraceSource(g_pPGBlock, 1, g_pPGBlock->m_EnergyConsumerArray[nLoad].nNode, nBoundNodeArray, m_LoadRadiusArray[nLoad].routerArray, m_LoadRadiusArray[nLoad].endingArray);
		FillTrace(nLoad, m_LoadRadiusArray[nLoad].routerArray, m_LoadRadiusArray[nLoad].endingArray);
		for (i=0; i<(int)m_LoadRadiusArray[nLoad].endingArray.size(); i++)
		{
			if (m_LoadRadiusArray[nLoad].fRouterLength == 0 || m_LoadRadiusArray[nLoad].fRouterLength < m_LoadRadiusArray[nLoad].endingArray[i].fEndLength)
				m_LoadRadiusArray[nLoad].fRouterLength=m_LoadRadiusArray[nLoad].endingArray[i].fEndLength;
		}
	}
	RefreshLoadRadiusList();
}

void CPGLoadAnalysisDlg::OnBnClickedLoadGroupa()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton=(CButton*)GetDlgItem(IDC_GROUP_STATUS);
	g_PGLoadGroup.PGGroupLoadA(g_pPGBlock, pButton->GetCheck());
	RefreshLoadGroupAList();
}

void CPGLoadAnalysisDlg::OnBnClickedLoadGroupb()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton=(CButton*)GetDlgItem(IDC_GROUP_STATUS);
	g_PGLoadGroup.PGGroupLoadB(g_pPGBlock, pButton->GetCheck());
	RefreshLoadGroupBList();
}

void CPGLoadAnalysisDlg::OnBnClickedLoadGroupc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton=(CButton*)GetDlgItem(IDC_GROUP_STATUS);
	g_PGLoadGroup.PGGroupLoadC(g_pPGBlock, pButton->GetCheck());
	RefreshLoadGroupCList();
}

void CPGLoadAnalysisDlg::OnBnClickedLoadGroupd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton=(CButton*)GetDlgItem(IDC_GROUP_STATUS);
	g_PGLoadGroup.PGGroupLoadD(g_pPGBlock, pButton->GetCheck());
	RefreshLoadGroupDList();
}

void CPGLoadAnalysisDlg::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;

	xls.Create(dlg.GetPathName());

	int		nRow, nCol, nFieldNum;
	//if (m_wndListLoadRadius.GetItemCount() > 0)
	{
		xls.AddSheet(_T("���ɹ���뾶"));
		xls.SetCurSheet(_T("���ɹ���뾶"));

		nFieldNum=sizeof(lpszLoadRadiusColumn)/sizeof(char*);
		//xls.NewLine();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszLoadRadiusColumn[nCol]));
		for (nRow=0; nRow<m_wndListLoadRadius.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListLoadRadius.GetItemText(nRow, nCol));
		}
	}

	//if (m_wndListLoadGroupA.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������A"));
		xls.SetCurSheet(_T("������A"));
		nFieldNum=sizeof(lpszLoadGroupAColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszLoadGroupAColumn[nCol]));
		for (nRow=0; nRow<m_wndListLoadGroupA.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListLoadGroupA.GetItemText(nRow, nCol));
		}
	}

	//if (m_wndListLoadGroupB.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������B"));
		xls.SetCurSheet(_T("������B"));
		nFieldNum=sizeof(lpszLoadGroupBColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszLoadGroupBColumn[nCol]));
		for (nRow=0; nRow<m_wndListLoadGroupB.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListLoadGroupB.GetItemText(nRow, nCol));
		}
	}

	//if (m_wndListLoadGroupC.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������C"));
		xls.SetCurSheet(_T("������C"));
		nFieldNum=sizeof(lpszLoadGroupColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszLoadGroupColumn[nCol]));
		for (nRow=0; nRow<m_wndListLoadGroupC.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListLoadGroupC.GetItemText(nRow, nCol));
		}
	}

	//if (m_wndListLoadGroupD.GetItemCount() > 0)
	{
		xls.AddSheet(_T("������D"));
		xls.SetCurSheet(_T("������D"));
		nFieldNum=sizeof(lpszLoadGroupColumn)/sizeof(char*);

		//xls.NewTran();
		for (nCol=0; nCol<nFieldNum; nCol++)
			xls.AddCell(CString(lpszLoadGroupColumn[nCol]));
		for (nRow=0; nRow<m_wndListLoadGroupD.GetItemCount(); nRow++)
		{
			xls.NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				xls.AddCell(m_wndListLoadGroupD.GetItemText(nRow, nCol));
		}
	}

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));
}
