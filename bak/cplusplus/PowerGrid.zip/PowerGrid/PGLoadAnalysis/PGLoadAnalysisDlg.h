
// PGLoadAnalysisDlg.h : ͷ�ļ�
//

#pragma once
#include "afxcmn.h"
#include "../../Common/MFCControls/MFCListCtrlEx.h"


// CPGLoadAnalysisDlg �Ի���

typedef	struct _PGLoadRadius 
{
	std::string	strLoad;
	float	fLoadCapacity;
	float	fRouterLength;
	std::vector<tagPGRouter>	routerArray;
	std::vector<tagPGSource>	endingArray;
}	tagPGLoadRadius;

class CPGLoadAnalysisDlg : public CDialog
{
// ����
public:
	CPGLoadAnalysisDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PGLOADANALYSIS_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedSetbound();
	afx_msg void OnBnClickedLoadSourceRadius();
	afx_msg void OnCbnSelchangeSubstationCombo();
	afx_msg void OnCbnSelchangeSubcontrolareaCombo();
	afx_msg void OnBnClickedAllloadSourceRadius();
	afx_msg void OnBnClickedRefresh();
	afx_msg void OnBnClickedLoadGroupa();
	afx_msg void OnBnClickedLoadGroupb();
	afx_msg void OnBnClickedLoadGroupc();
	afx_msg void OnBnClickedLoadGroupd();
	afx_msg void OnBnClickedSaveasExcel();
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndListLoadRadius, m_wndListLoadGroupA, m_wndListLoadGroupB, m_wndListLoadGroupC, m_wndListLoadGroupD;
	CMFCListCtrlEx	m_wndLoadList;
	CTreeCtrl m_wndTraceRouter;

private:
	std::vector<tagPGLoadRadius>	m_LoadRadiusArray;

private:
	void	RefreshSubCombo();
	void	RefreshLoadList();

	void	RefreshLoadRadiusList();
	void	RefreshLoadGroupAList();
	void	RefreshLoadGroupBList();
	void	RefreshLoadGroupCList();
	void	RefreshLoadGroupDList();

private:
	void	FillTrace(const int nLoad, std::vector<tagPGRouter>& routerArray, std::vector<tagPGSource>& endingArray);
	void	FillTraceByDeep(std::vector<tagPGRouter>& rArray, const int nIniRouter, const int nIniDeep, HTREEITEM hDeep);
private:
	std::vector<tagPGRouter>		m_TraceRouterArray;
	std::vector<tagPGSource>	m_TraceEndingArray;
public:
};
