#pragma once
#include "afxcmn.h"
#include "../../Common/MFCControls/MFCListCtrlEx.h"

// CBoundSetDialog �Ի���

class CBoundSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CBoundSetDialog)

public:
	CBoundSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CBoundSetDialog();

// �Ի�������
	enum { IDD = IDD_TRACEBOUNDSET_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnCbnSelchangeSubcontrolareaCombo();
	afx_msg void OnCbnSelchangeSubstationCombo();
	afx_msg void OnBnClickedAddSub();
	afx_msg void OnBnClickedAddBus();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedDel();
	afx_msg void OnCbnSelchangeVoltagelevelCombo();
	DECLARE_MESSAGE_MAP()
private:
	void	RefreshSubList();
	void	RefreshBusList();
	void	RefreshBoundList();
	int		GetTextLen(const char* lpszText);

private:
	CMFCListCtrlEx m_wndBoundList;
public:
};
