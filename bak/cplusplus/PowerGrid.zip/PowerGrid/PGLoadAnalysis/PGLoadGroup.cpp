#include "StdAfx.h"
#include "PGLoadGroup.h"

CPGLoadGroup::CPGLoadGroup(void)
{
}

CPGLoadGroup::~CPGLoadGroup(void)
{
}

void CPGLoadGroup::PGGroupLoadA(tagPGBlock* pPGBlock, const int bCheckOpen)
{
	register int	i;
	int		nSub, nVolt, nNode, nLoad, nSwitchStation;
	int		nNodeNum;
	int*	pnNodeArray;
	tagPGLoadGroupA	gBuf;
	tagPGGroupBoundDev	dBuf;

	//////////////////////////////////////////////////////////////////////////
	//	��ʼ��
	unsigned char	nCheckStatus=(bCheckOpen != 0) ? Y_CheckStatus : N_CheckStatus;

	pnNodeArray=(int*)malloc(sizeof(int)*pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	if (!pnNodeArray)
		return;

	std::vector<unsigned char>	bLoadProcArray;
	bLoadProcArray.resize(pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]);
	for (i=0; i<(int)bLoadProcArray.size(); i++)
		bLoadProcArray[i]=0;

	m_Node2LoadArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_Node2LoadArray[i].nLoadArray.clear();
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (pPGBlock->m_EnergyConsumerArray[i].nNode < 0)
			continue;
		m_Node2LoadArray[pPGBlock->m_EnergyConsumerArray[i].nNode].nLoadArray.push_back(i);
	}

	//////////////////////////////////////////////////////////////////////////
	//	���ñ߽磬���з�����վ�Ͷ�·����Ϊ�߽�
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_DISTRIBUTIONBREAKER &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_DISTRIBUTIONSWITCH)
			continue;

		if (pPGBlock->m_SubstationArray[nSub].nParentType == PG_DISTRIBUTIONSWITCH)
		{
			nSwitchStation=-1;
			for (i=0; i<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONSWITCH]; i++)
			{
				if (stricmp(pPGBlock->m_DistributionSwitchArray[i].szResID, pPGBlock->m_SubstationArray[nSub].szResID) == 0)
				{
					nSwitchStation=i;
					break;
				}
			}
			if (nSwitchStation < 0 || pPGBlock->m_DistributionSwitchArray[nSwitchStation].nType == PGEnumSwitchType_CableBranchBox)
				continue;
		}
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				pPGBlock->m_ConnectivityNodeArray[nNode].bOpen=1;
			}
		}
	}
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].nBreakerRange; i<pPGBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; i++)
			{
				if (pPGBlock->m_BreakerArray[i].nCategory == PGEnumBreakerType_FuseBreaker ||
					pPGBlock->m_BreakerArray[i].nCategory == PGEnumBreakerType_LoadBreakSwitch ||
					pPGBlock->m_BreakerArray[i].nCategory == PGEnumBreakerType_Disconnector)
					continue;

				pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[i].nNodeI].bOpen=1;
				pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[i].nNodeJ].bOpen=1;
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	ͨ�����ɽ��нڵ����
	for (nLoad=0; nLoad<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nLoad++)
	{
		if (bLoadProcArray[nLoad])
			continue;
		bLoadProcArray[nLoad]=1;
		if (pPGBlock->m_EnergyConsumerArray[nLoad].nNode < 0)
			continue;
		if (pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_EnergyConsumerArray[nLoad].nNode].bOpen != 0)
			continue;

		gBuf.fTotLoadP=0;
		gBuf.nBoundNodeArray.clear();
		gBuf.nGroupLoadArray.clear();
		gBuf.boundDevArray.clear();
		PGTraverseNet(pPGBlock, pPGBlock->m_EnergyConsumerArray[nLoad].nNode, nCheckStatus, 0, nNodeNum, pnNodeArray);

		for (nNode=0; nNode<nNodeNum; nNode++)
		{
			for (i=0; i<(int)m_Node2LoadArray[pnNodeArray[nNode]].nLoadArray.size(); i++)
				bLoadProcArray[m_Node2LoadArray[pnNodeArray[nNode]].nLoadArray[i]]=1;
			if (pPGBlock->m_ConnectivityNodeArray[pnNodeArray[nNode]].bOpen)
			{
				gBuf.nBoundNodeArray.push_back(pnNodeArray[nNode]);
				continue;
			}

			for (i=0; i<(int)m_Node2LoadArray[pnNodeArray[nNode]].nLoadArray.size(); i++)
			{
				gBuf.fTotLoadP += pPGBlock->m_EnergyConsumerArray[m_Node2LoadArray[pnNodeArray[nNode]].nLoadArray[i]].fPlanP;
				gBuf.nGroupLoadArray.push_back(m_Node2LoadArray[pnNodeArray[nNode]].nLoadArray[i]);
			}
		}

		for (nNode=0; nNode<(int)gBuf.nBoundNodeArray.size(); nNode++)
		{
			nSub=PGFindRecordbyKey(pPGBlock, PG_SUBSTATION, pPGBlock->m_ConnectivityNodeArray[gBuf.nBoundNodeArray[nNode]].szSub);
			if (nSub < 0)
				continue;

			dBuf.nDevType=pPGBlock->m_SubstationArray[nSub].nParentType;
			dBuf.nDevIndex=-1;
			if (pPGBlock->m_SubstationArray[nSub].nParentType == 0)
			{
				dBuf.nDevType=PG_SUBSTATION;
				dBuf.nDevIndex=nSub;
			}
			else if (pPGBlock->m_SubstationArray[nSub].nParentType == PG_SUBSTATIONENTITY)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_SUBSTATIONENTITY]; i++)
				{
					if (stricmp(pPGBlock->m_SubstationEntityArray[i].szResID, pPGBlock->m_SubstationArray[nSub].szResID) == 0)
					{
						dBuf.nDevIndex=i;
						break;
					}
				}
			}
			else if (pPGBlock->m_SubstationArray[nSub].nParentType == PG_DISTRIBUTIONBREAKER)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONBREAKER]; i++)
				{
					if (stricmp(pPGBlock->m_DistributionBreakerArray[i].szResID, pPGBlock->m_SubstationArray[nSub].szResID) == 0)
					{
						dBuf.nDevIndex=i;
						break;
					}
				}
			}
			else if (pPGBlock->m_SubstationArray[nSub].nParentType == PG_DISTRIBUTIONSWITCH)
			{
				for (i=0; i<pPGBlock->m_nRecordNum[PG_DISTRIBUTIONSWITCH]; i++)
				{
					if (stricmp(pPGBlock->m_DistributionSwitchArray[i].szResID, pPGBlock->m_SubstationArray[nSub].szResID) == 0)
					{
						dBuf.nDevIndex=i;
						break;
					}
				}
			}
			if (dBuf.nDevIndex < 0)
				continue;

			gBuf.boundDevArray.push_back(dBuf);
		}
		if (!gBuf.nGroupLoadArray.empty())
			m_GroupAArray.push_back(gBuf);
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ɨ����
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	free(pnNodeArray);
}

void CPGLoadGroup::PGGroupLoadB(tagPGBlock* pPGBlock, const int bCheckOpen)
{
	register int	i, j;
	int		nSub, nVolt, nNode, nLine, nStartNode;
	int		nNodeNum;
	int*	pnNodeArray;
	tagPGLoadGroup	gBuf;

	//////////////////////////////////////////////////////////////////////////
	//	��ʼ��
	unsigned char	nCheckStatus=(bCheckOpen != 0) ? Y_CheckStatus : N_CheckStatus;

	pnNodeArray=(int*)malloc(sizeof(int)*pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	if (!pnNodeArray)
		return;

	std::vector<unsigned char>	bLineProcArray;
	bLineProcArray.resize(pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (i=0; i<(int)bLineProcArray.size(); i++)
		bLineProcArray[i]=0;

	m_Node2LoadArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_Node2LoadArray[i].nLoadArray.clear();
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (pPGBlock->m_EnergyConsumerArray[i].nNode < 0)
			continue;
		m_Node2LoadArray[pPGBlock->m_EnergyConsumerArray[i].nNode].nLoadArray.push_back(i);
	}

	//////////////////////////////////////////////////////////////////////////
	//	���ñ߽磬���з�����վ
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
				pPGBlock->m_ConnectivityNodeArray[nNode].bOpen=1;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��·�Բ���нڵ����
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nLine=pPGBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nLine<pPGBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nLine++)
				{
					if (bLineProcArray[pPGBlock->m_EdgeACLineSegmentArray[nLine].nACLineSegment])
						continue;
					bLineProcArray[pPGBlock->m_EdgeACLineSegmentArray[nLine].nACLineSegment]=1;

					nStartNode=(nNode == pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[nLine].nACLineSegment].nNodeI) ?
						pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[nLine].nACLineSegment].nNodeJ : pPGBlock->m_ACLineSegmentArray[pPGBlock->m_EdgeACLineSegmentArray[nLine].nACLineSegment].nNodeI;
					if (pPGBlock->m_ConnectivityNodeArray[nStartNode].bOpen)
						continue;

					gBuf.fTotLoadP=0;
					gBuf.nSubstation=nSub;
					gBuf.nACLineSegment=pPGBlock->m_EdgeACLineSegmentArray[nLine].nACLineSegment;
					gBuf.nGroupLoadArray.clear();
					PGTraverseNet(pPGBlock, nStartNode, nCheckStatus, 0, nNodeNum, pnNodeArray);

					for (i=0; i<nNodeNum; i++)
					{
						if (pPGBlock->m_ConnectivityNodeArray[pnNodeArray[i]].bOpen)
							continue;

						for (j=0; j<(int)m_Node2LoadArray[pnNodeArray[i]].nLoadArray.size(); j++)
						{
							gBuf.fTotLoadP += pPGBlock->m_EnergyConsumerArray[m_Node2LoadArray[pnNodeArray[i]].nLoadArray[j]].fPlanP;
							gBuf.nGroupLoadArray.push_back(m_Node2LoadArray[pnNodeArray[i]].nLoadArray[j]);
						}
					}
					if (!gBuf.nGroupLoadArray.empty())
						m_GroupBArray.push_back(gBuf);
				}
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ɨ����
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	free(pnNodeArray);
}

void CPGLoadGroup::PGGroupLoadC(tagPGBlock* pPGBlock, const int bCheckOpen)
{
	register int	i, j;
	int		nSub, nVolt, nNode;
	int		nNodeNum;
	int*	pnNodeArray;
	tagPGLoadGroup	gBuf;

	//////////////////////////////////////////////////////////////////////////
	//	��ʼ��
	unsigned char	nCheckStatus=(bCheckOpen != 0) ? Y_CheckStatus : N_CheckStatus;

	pnNodeArray=(int*)malloc(sizeof(int)*pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	if (!pnNodeArray)
		return;

	std::vector<unsigned char>	bNodeProcArray;
	bNodeProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<(int)bNodeProcArray.size(); i++)
		bNodeProcArray[i]=0;

	m_Node2LoadArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_Node2LoadArray[i].nLoadArray.clear();
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (pPGBlock->m_EnergyConsumerArray[i].nNode < 0)
			continue;
		m_Node2LoadArray[pPGBlock->m_EnergyConsumerArray[i].nNode].nLoadArray.push_back(i);
	}

	//////////////////////////////////////////////////////////////////////////
	//	���ñ߽磬���з�����վ
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 100)
				continue;
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
				pPGBlock->m_ConnectivityNodeArray[nNode].bOpen=1;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��·�Բ���нڵ����
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 100 || pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 150)
				continue;
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				if (bNodeProcArray[nNode])
					continue;

				gBuf.fTotLoadP=0;
				gBuf.nSubstation=nSub;
				gBuf.nGroupLoadArray.clear();
				PGTraverseNet(pPGBlock, nNode, nCheckStatus, 0, nNodeNum, pnNodeArray);
				for (i=0; i<nNodeNum; i++)
					bNodeProcArray[pnNodeArray[i]]=1;

				for (i=0; i<nNodeNum; i++)
				{
					for (j=0; j<(int)m_Node2LoadArray[pnNodeArray[i]].nLoadArray.size(); j++)
					{
						gBuf.fTotLoadP += pPGBlock->m_EnergyConsumerArray[m_Node2LoadArray[pnNodeArray[i]].nLoadArray[j]].fPlanP;
						gBuf.nGroupLoadArray.push_back(m_Node2LoadArray[pnNodeArray[i]].nLoadArray[j]);
					}
				}
				if (!gBuf.nGroupLoadArray.empty())
					m_GroupCArray.push_back(gBuf);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ɨ����
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	free(pnNodeArray);
}

void CPGLoadGroup::PGGroupLoadD(tagPGBlock* pPGBlock, const int bCheckOpen)
{
	register int	i, j;
	int		nSub, nVolt, nNode;
	int		nNodeNum;
	int*	pnNodeArray;
	tagPGLoadGroup	gBuf;

	//////////////////////////////////////////////////////////////////////////
	//	��ʼ��
	unsigned char	nCheckStatus=(bCheckOpen != 0) ? Y_CheckStatus : N_CheckStatus;

	pnNodeArray=(int*)malloc(sizeof(int)*pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	if (!pnNodeArray)
		return;

	std::vector<unsigned char>	bNodeProcArray;
	bNodeProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<(int)bNodeProcArray.size(); i++)
		bNodeProcArray[i]=0;

	m_Node2LoadArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		m_Node2LoadArray[i].nLoadArray.clear();
	for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (pPGBlock->m_EnergyConsumerArray[i].nNode < 0)
			continue;
		m_Node2LoadArray[pPGBlock->m_EnergyConsumerArray[i].nNode].nLoadArray.push_back(i);
	}

	//////////////////////////////////////////////////////////////////////////
	//	���ñ߽磬���з�����վ
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 200)
				continue;
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
				pPGBlock->m_ConnectivityNodeArray[nNode].bOpen=1;
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��·�Բ���нڵ����
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (pPGBlock->m_SubstationArray[nSub].nParentType != 0 &&
			pPGBlock->m_SubstationArray[nSub].nParentType != PG_SUBSTATIONENTITY)
			continue;

		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 200 || pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage > 250)
				continue;
			for (nNode=pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				if (bNodeProcArray[nNode])
					continue;

				gBuf.fTotLoadP=0;
				gBuf.nSubstation=nSub;
				gBuf.nGroupLoadArray.clear();
				PGTraverseNet(pPGBlock, nNode, nCheckStatus, 0, nNodeNum, pnNodeArray);
				for (i=0; i<nNodeNum; i++)
					bNodeProcArray[pnNodeArray[i]]=1;

				for (i=0; i<nNodeNum; i++)
				{
					for (j=0; j<(int)m_Node2LoadArray[pnNodeArray[i]].nLoadArray.size(); j++)
					{
						gBuf.fTotLoadP += pPGBlock->m_EnergyConsumerArray[m_Node2LoadArray[pnNodeArray[i]].nLoadArray[j]].fPlanP;
						gBuf.nGroupLoadArray.push_back(m_Node2LoadArray[pnNodeArray[i]].nLoadArray[j]);
					}
				}
				if (!gBuf.nGroupLoadArray.empty())
					m_GroupDArray.push_back(gBuf);
			}
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//	��ɨ����
	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)
		pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	free(pnNodeArray);
}
