//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PGLoadAnalysis.rc
//
#define IDD_PGLOADANALYSIS_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_TRACEBOUNDSET_DIALOG        129
#define IDC_TAB                         1000
#define IDC_LOAD_LIST                   1002
#define IDC_LOAD_SOURCE_RADIUS          1003
#define IDC_ALLLOAD_SOURCE_RADIUS       1004
#define IDC_LOAD_GROUPA                 1005
#define IDC_LOAD_GROUPB                 1006
#define IDC_LOAD_GROUPC                 1007
#define IDC_LOAD_GROUPD                 1008
#define IDC_TRACE_TREE                  1009
#define IDC_SETBOUND                    1010
#define IDC_REFRESH                     1011
#define IDC_BOUND_LIST                  1013
#define IDC_SUB_LIST                    1014
#define IDC_SUBCONTROLAREA_COMBO        1015
#define IDC_ADD_BUS                     1017
#define IDC_DEL                         1018
#define IDC_ADD_SUB                     1019
#define IDC_SUBSTATION_COMBO            1021
#define IDC_BUS_LIST                    1022
#define IDC_VOLTAGELEVEL_COMBO          1023
#define IDC_CHECK1                      1023
#define IDC_CHECK_STATUS                1024
#define IDC_SAVEAS_EXCEL                1025
#define IDC_CHECK_STATUS2               1026
#define IDC_GROUP_STATUS                1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
