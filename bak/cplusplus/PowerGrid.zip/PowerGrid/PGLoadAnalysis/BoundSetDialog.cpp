// BoundSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PGLoadAnalysisApp.h"
#include "BoundSetDialog.h"


// CBoundSetDialog �Ի���

static	char*	lpszBoundColumn[]=
{
	"����", 
	"��վ", 
	"��ѹ", 
	"����", 
};

static	char*	lpszBusColumn[]=
{
	"��վ", 
	"��ѹ", 
	"����", 
};

IMPLEMENT_DYNAMIC(CBoundSetDialog, CDialog)

CBoundSetDialog::CBoundSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CBoundSetDialog::IDD, pParent)
{
}

CBoundSetDialog::~CBoundSetDialog()
{
}

void CBoundSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BOUND_LIST, m_wndBoundList);
}


BEGIN_MESSAGE_MAP(CBoundSetDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_SUBCONTROLAREA_COMBO, &CBoundSetDialog::OnCbnSelchangeSubcontrolareaCombo)
	ON_CBN_SELCHANGE(IDC_SUBSTATION_COMBO, &CBoundSetDialog::OnCbnSelchangeSubstationCombo)
	ON_BN_CLICKED(IDC_ADD_SUB, &CBoundSetDialog::OnBnClickedAddSub)
	ON_BN_CLICKED(IDC_ADD_BUS, &CBoundSetDialog::OnBnClickedAddBus)
	ON_BN_CLICKED(IDOK, &CBoundSetDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDC_DEL, &CBoundSetDialog::OnBnClickedDel)
	ON_CBN_SELCHANGE(IDC_VOLTAGELEVEL_COMBO, &CBoundSetDialog::OnCbnSelchangeVoltagelevelCombo)
END_MESSAGE_MAP()


// CBoundSetDialog ��Ϣ��������

BOOL CBoundSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox;
	CComboBox*	pComboBox;

	pListBox=(CListBox*)GetDlgItem(IDC_SUB_LIST);
	pListBox->ResetContent();

	CListCtrl*	pListCtrl;
	
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUND_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszBoundColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBoundColumn[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BUS_LIST);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->DeleteAllItems();
	while (pListCtrl->DeleteColumn(0));
	for (i=0; i<sizeof(lpszBusColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBusColumn[i],	LVCFMT_LEFT,	100);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBCONTROLAREA_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pComboBox->AddString(g_pPGBlock->m_SubcontrolAreaArray[i].szName);

	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBSTATION_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pComboBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	unsigned char	bExist;
	std::vector<std::string>	strVoltArray;
	strVoltArray.clear();
	for (int nBus=0; nBus<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nBus++)
	{
		bExist=0;
		for (i=0; i<(int)strVoltArray.size(); i++)
		{
			if (stricmp(strVoltArray[i].c_str(), g_pPGBlock->m_BusbarSectionArray[nBus].szVolt) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strVoltArray.push_back(g_pPGBlock->m_BusbarSectionArray[nBus].szVolt);
	}
	pComboBox=(CComboBox*)GetDlgItem(IDC_VOLTAGELEVEL_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<(int)strVoltArray.size(); i++)
		pComboBox->AddString(strVoltArray[i].c_str());

	RefreshSubList();
	RefreshBusList();
	RefreshBoundList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CBoundSetDialog::RefreshSubList()
{
	int		iExt;
	char	szArea[MDB_CHARLEN];
	memset(szArea, 0, MDB_CHARLEN);

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBCONTROLAREA_COMBO);
	int			nArea=pComboBox->GetCurSel();
	if (nArea != CB_ERR)
		pComboBox->GetLBText(nArea, szArea);

	register int	i;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUB_LIST);
	pListBox->ResetContent();
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		if (strlen(szArea) > 0)
		{
			if (stricmp(g_pPGBlock->m_SubstationArray[i].szSubcontrolArea, szArea) != 0)
				continue;
		}
		iExt = GetTextLen(g_pPGBlock->m_SubstationArray[i].szName);
		if (iExt > pListBox->GetHorizontalExtent())
			pListBox->SetHorizontalExtent(iExt);
		pListBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);
	}
}

void CBoundSetDialog::RefreshBusList()
{
	register int	i;
	char	szSub[MDB_CHARLEN], szVolt[MDB_CHARLEN_SHORT];
	int		nRow, nCol;

	memset(szSub, 0, MDB_CHARLEN);
	memset(szVolt, 0, MDB_CHARLEN_SHORT);
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BUS_LIST);
	pListCtrl->DeleteAllItems();

	CComboBox*	pComboBox;
	pComboBox=(CComboBox*)GetDlgItem(IDC_SUBSTATION_COMBO);
	int			nSub=pComboBox->GetCurSel();
	if (nSub != CB_ERR)
		pComboBox->GetLBText(nSub, szSub);

	pComboBox=(CComboBox*)GetDlgItem(IDC_VOLTAGELEVEL_COMBO);
	int			nVolt=pComboBox->GetCurSel();
	if (nVolt != CB_ERR)
		pComboBox->GetLBText(nVolt, szVolt);

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
	{
		if (strlen(szSub) > 0)
		{
			if (stricmp(g_pPGBlock->m_BusbarSectionArray[i].szSub, szSub) != 0)
				continue;
		}
		if (strlen(szVolt) > 0)
		{
			if (stricmp(g_pPGBlock->m_BusbarSectionArray[i].szVolt, szVolt) != 0)
				continue;
		}

		pListCtrl->InsertItem(nRow, g_pPGBlock->m_BusbarSectionArray[i].szSub);	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szVolt);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szName);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}

}

void CBoundSetDialog::RefreshBoundList()
{
	register int	i;
	int		nRow, nCol;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUND_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_BoundArray.size(); i++)
	{
		pListCtrl->InsertItem(nRow, PGGetTableDesp(g_BoundArray[i].nDevType));	pListCtrl->SetItemData(nRow, nRow);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_BoundArray[i].strDevSub.c_str());
		pListCtrl->SetItemText(nRow, nCol++, g_BoundArray[i].strDevVolt.c_str());
		pListCtrl->SetItemText(nRow, nCol++, g_BoundArray[i].strDevName.c_str());
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBoundColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CBoundSetDialog::OnCbnSelchangeSubcontrolareaCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshSubList();
}

void CBoundSetDialog::OnCbnSelchangeSubstationCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshBusList();
}

void CBoundSetDialog::OnCbnSelchangeVoltagelevelCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshBusList();
}

void CBoundSetDialog::OnBnClickedAddSub()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	char			szSub[MDB_CHARLEN];
	tagBoundDevice	bndBuf;
	int			nSelArray[5000];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUB_LIST);
	int			nSelNum=pListBox->GetSelItems(5000, nSelArray);
	if (nSelNum <= 0)
		return;

	bndBuf.strDevSub.clear();
	bndBuf.strDevVolt.clear();
	bndBuf.strDevName.clear();

	for (int nSub=0; nSub<nSelNum; nSub++)
	{
		pListBox->GetText(nSelArray[nSub], szSub);

		bExist=0;
		for (i=0; i<(int)g_BoundArray.size(); i++)
		{
			if (g_BoundArray[i].nDevType == PG_SUBSTATION && strcmp(g_BoundArray[i].strDevName.c_str(), szSub) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			bndBuf.nDevType=PG_SUBSTATION;
			bndBuf.strDevName=szSub;
			g_BoundArray.push_back(bndBuf);
		}
	}
	RefreshBoundList();
}

void CBoundSetDialog::OnBnClickedAddBus()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	tagBoundDevice	bndBuf;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BUS_LIST);

	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		int	nItem=pListCtrl->GetNextSelectedItem(pos);

		bndBuf.nDevType=PG_BUSBARSECTION;
		bndBuf.strDevSub=pListCtrl->GetItemText(nItem, 0);
		bndBuf.strDevVolt=pListCtrl->GetItemText(nItem, 1);
		bndBuf.strDevName=pListCtrl->GetItemText(nItem, 2);

		bExist=0;
		for (i=0; i<(int)g_BoundArray.size(); i++)
		{
			if (g_BoundArray[i].nDevType == PG_BUSBARSECTION &&
				strcmp(g_BoundArray[i].strDevSub.c_str(), bndBuf.strDevSub.c_str()) == 0 &&
				strcmp(g_BoundArray[i].strDevVolt.c_str(), bndBuf.strDevVolt.c_str()) == 0 &&
				strcmp(g_BoundArray[i].strDevName.c_str(), bndBuf.strDevName.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			g_BoundArray.push_back(bndBuf);
	}
	RefreshBoundList();
}

void CBoundSetDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nBound, nItem;

	for (i=0; i<(int)g_BoundArray.size(); i++)
		g_BoundArray[i].bFlag=0;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUND_LIST);
	POSITION	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
	{
		nItem=pListCtrl->GetNextSelectedItem(pos);
		nBound=-1;
		for (i=0; i<(int)g_BoundArray.size(); i++)
		{
			if (stricmp(PGGetTableDesp(g_BoundArray[i].nDevType), pListCtrl->GetItemText(nItem, 0)) == 0 &&
				stricmp(g_BoundArray[i].strDevSub.c_str(), pListCtrl->GetItemText(nItem, 1)) == 0 &&
				stricmp(g_BoundArray[i].strDevVolt.c_str(), pListCtrl->GetItemText(nItem, 2)) == 0 &&
				stricmp(g_BoundArray[i].strDevName.c_str(), pListCtrl->GetItemText(nItem, 3)) == 0)
			{
				nBound=i;
				break;
			}
		}
		if (nBound >= 0)
			g_BoundArray[nBound].bFlag=1;
	}

	nItem=0;
	while (nItem < (int)g_BoundArray.size())
	{
		if (g_BoundArray[nItem].bFlag)
			g_BoundArray.erase(g_BoundArray.begin()+nItem);
		else
			nItem++;
	}
	RefreshBoundList();
}

int CBoundSetDialog::GetTextLen(const char* lpszText)
{
	ASSERT(AfxIsValidString(lpszText));

	CDC *pDC = GetDC();
	ASSERT(pDC);

	CSize size;
	CFont* pOldFont = pDC->SelectObject(GetFont());
	if ((GetStyle() & LBS_USETABSTOPS) == 0)
	{
		size = pDC->GetTextExtent(CString(lpszText), (int) strlen(lpszText));
		size.cx += 3;
	}
	else
	{
		// Expand tabs as well
		size = pDC->GetTabbedTextExtent(CString(lpszText), (int) strlen(lpszText), 0, NULL);
		size.cx += 2;
	}
	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	return size.cx;
}

void CBoundSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SaveIni();
	OnOK();
}
