#include "stdafx.h"
#include "NariEData.h"

void CNariEData::putValue(tagPGBlock* pBlock, const int bUseBreakerStatus, const int bUseDisconnectorStatus, const int bUseOffFlag)
{
	register int	i;
	int		nSub, nVolt, nNode, nDev, nData, bFind;
	int		nTranMid;
	char	szBuf[260], szDevName[260];

	//PGMemDBTopo(pBlock);

	char*	lpszToken;
	std::vector<std::string>	strEleArray;

	strEleArray.clear();
	strcpy(szBuf, m_System.szTime);
	lpszToken=strtok(szBuf, " :T-t\t\n");
	while (lpszToken != NULL)
	{
		strEleArray.push_back(lpszToken);
		lpszToken=strtok(NULL, " :T-t\t\n");
	}
	if (strEleArray.size() == 6)
	{
		pBlock->m_System.nDate=10000*atoi(strEleArray[0].c_str())+100*atoi(strEleArray[1].c_str())+atoi(strEleArray[2].c_str());
		pBlock->m_System.nTime=10000*atoi(strEleArray[3].c_str())+100*atoi(strEleArray[4].c_str())+atoi(strEleArray[5].c_str());
	}

	ClearLog();
	for (i=0; i<(int)m_BusbarSectionArray.size(); i++)
		m_BusbarSectionArray[i].bCheckOK=0;
	for (i=0; i<(int)m_ACLineSegmentArray.size(); i++)
		m_ACLineSegmentArray[i].bCheckOK=0;
	for (i=0; i<(int)m_TransformerWindingArray.size(); i++)
		m_TransformerWindingArray[i].bCheckOK=0;
	for (i=0; i<(int)m_SynchronousMachineArray.size(); i++)
		m_SynchronousMachineArray[i].bCheckOK=0;
	for (i=0; i<(int)m_EnergyConsumerArray.size(); i++)
		m_EnergyConsumerArray[i].bCheckOK=0;
	for (i=0; i<(int)m_ShuntCompensatorArray.size(); i++)
		m_ShuntCompensatorArray[i].bCheckOK=0;
	for (i=0; i<(int)m_RectifierInverterArray.size(); i++)
		m_RectifierInverterArray[i].bCheckOK=0;

	for (i=0; i<(int)m_BreakerArray.size(); i++)
		m_BreakerArray[i].bCheckOK=0;
	for (i=0; i<(int)m_DisconnectorArray.size(); i++)
		m_DisconnectorArray[i].bCheckOK=0;
	for (i=0; i<(int)m_GroundDisconnectorArray.size(); i++)
		m_GroundDisconnectorArray[i].bCheckOK=0;

	for (i=0; i<pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]; i++)
		pBlock->m_GroundDisconnectorArray[i].nStatus=1;


	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
		pBlock->m_BusbarSectionArray[nDev].fV=0;
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		pBlock->m_ACLineSegmentArray[nDev].fPi=
			pBlock->m_ACLineSegmentArray[nDev].fQi=
			pBlock->m_ACLineSegmentArray[nDev].fPz=
			pBlock->m_ACLineSegmentArray[nDev].fQz=
			pBlock->m_ACLineSegmentArray[nDev].fA=-999999;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
	{
		pBlock->m_TransformerWindingArray[nDev].fPi=
			pBlock->m_TransformerWindingArray[nDev].fQi=
			pBlock->m_TransformerWindingArray[nDev].fAi=
			pBlock->m_TransformerWindingArray[nDev].fPz=
			pBlock->m_TransformerWindingArray[nDev].fQz=
			pBlock->m_TransformerWindingArray[nDev].fAz=-999999;

		pBlock->m_TransformerWindingArray[nDev].nTapI=0;
		pBlock->m_TransformerWindingArray[nDev].nTapJ=0;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		//	��������þ�ֵ̬
		//pBlock->m_SynchronousMachineArray[nDev].fPlanP=pBlock->m_SynchronousMachineArray[nDev].fPlanQ=pBlock->m_SynchronousMachineArray[nDev].v=0;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		pBlock->m_EnergyConsumerArray[nDev].fP=pBlock->m_EnergyConsumerArray[nDev].fQ=pBlock->m_EnergyConsumerArray[nDev].fA=0;
		pBlock->m_EnergyConsumerArray[nDev].fPlanP=pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; nDev++)
	{
		pBlock->m_ShuntCompensatorArray[nDev].fQ=pBlock->m_ShuntCompensatorArray[nDev].fA=0;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_RECTIFIERINVERTER]; nDev++)
	{
		pBlock->m_RectifierInverterArray[nDev].fP=pBlock->m_RectifierInverterArray[nDev].fQ=0;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_BREAKER]; nDev++)
	{
		pBlock->m_BreakerArray[nDev].fP=pBlock->m_BreakerArray[nDev].fQ=pBlock->m_BreakerArray[nDev].fA=0;
		pBlock->m_BreakerArray[nDev].nStatus=0;
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_DISCONNECTOR]; nDev++)
	{
		pBlock->m_DisconnectorArray[nDev].nStatus=0;
	}

	for (nData=0; nData<(int)m_BusbarSectionArray.size(); nData++)
	{
		//Log("putValue[BusbarSection]: %s.%s \n", m_BusbarSectionArray[nData].szSub, m_BusbarSectionArray[nData].szName);
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_BusbarSectionArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				if (strcmp(pBlock->m_BusbarSectionArray[nDev].szName, m_BusbarSectionArray[nData].szName) == 0)
				{
					//Log("        %.1f[%d] \n", m_BusbarSectionArray[nData].fV, m_BusbarSectionArray[nData].nVOff);

					//if (m_BusbarSectionArray[nData].fV > 1.2*pBlock->m_VoltageLevelArray[nVolt].nominalVoltage ||
					//	m_BusbarSectionArray[nData].fV < 0.8*pBlock->m_VoltageLevelArray[nVolt].nominalVoltage)
					//m_BusbarSectionArray[nData].fV=0;

					if (m_BusbarSectionArray[nData].nVOff || !bUseOffFlag)		pBlock->m_BusbarSectionArray[nDev].fV=m_BusbarSectionArray[nData].fV;
					if (m_BusbarSectionArray[nData].nDOff || !bUseOffFlag)		pBlock->m_BusbarSectionArray[nDev].fD=m_BusbarSectionArray[nData].fD;

					m_BusbarSectionArray[nData].bCheckOK=1;
					goto _LBUS;
				}
			}
		}
_LBUS:	;
	}

	for (nData=0; nData<(int)m_ACLineSegmentArray.size(); nData++)
	{
		//Log("putValue[ACLineSegment](%s %s)\n", m_ACLineSegmentArray[nData].szSub, m_ACLineSegmentArray[nData].szName);
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_ACLineSegmentArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
				{
					if (strcmp(pBlock->m_EdgeACLineSegmentArray[nDev].szName, m_ACLineSegmentArray[nData].szName) == 0)
					{
						//Log("        %.1f[%d] %.1f[%d] \n", m_ACLineSegmentArray[nData].fP, m_ACLineSegmentArray[nData].nPOff, m_ACLineSegmentArray[nData].fQ, m_ACLineSegmentArray[nData].nQOff);
						if (strcmp(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, pBlock->m_SubstationArray[nSub].szName) == 0)
						{
							if (m_ACLineSegmentArray[nData].nPOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPi=m_ACLineSegmentArray[nData].fP;
							if (m_ACLineSegmentArray[nData].nQOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQi=m_ACLineSegmentArray[nData].fQ;
						}
						else
						{
							if (m_ACLineSegmentArray[nData].nPOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPz=m_ACLineSegmentArray[nData].fP;
							if (m_ACLineSegmentArray[nData].nQOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQz=m_ACLineSegmentArray[nData].fQ;
						}
						m_ACLineSegmentArray[nData].bCheckOK=1;

						goto LLINE;
					}
				}
			}
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, m_ACLineSegmentArray[nData].szName) == 0)
				{
					Log("        ����ֵ����·ң��ȷ��: %s.%s \n", m_ACLineSegmentArray[nData].szSub, m_ACLineSegmentArray[nData].szName);
					if (m_ACLineSegmentArray[nData].nPOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanP=m_ACLineSegmentArray[nData].fP;
					if (m_ACLineSegmentArray[nData].nQOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=m_ACLineSegmentArray[nData].fQ;

					if (!checkP(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_ACLineSegmentArray[nData].fP))	pBlock->m_EnergyConsumerArray[nDev].fPlanP=0;
					if (!checkQ(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_ACLineSegmentArray[nData].fQ))	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;

					m_ACLineSegmentArray[nData].bCheckOK=1;
					goto LLINE;
				}
			}
		}
LLINE:	;
	}

	char	szWindH[MDB_CHARLEN], szWindL[MDB_CHARLEN];
	for (nData=0; nData<(int)m_TransformerWindingArray.size(); nData++)
	{
		//Log("putValue[TransformerWinding]: %s.%s\n", m_TransformerWindingArray[nData].szSub, m_TransformerWindingArray[nData].szName);
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_TransformerWindingArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nDev=pBlock->m_SubstationArray[nSub].nPowerTransformerRange; nDev<pBlock->m_SubstationArray[nSub+1].nPowerTransformerRange; nDev++)
		{
			if (pBlock->m_PowerTransformerArray[nDev].nWindNum == 1)
			{
				sprintf(szWindH, "%s-��", pBlock->m_PowerTransformerArray[nDev].szName);
				sprintf(szWindL, "%s-��", pBlock->m_PowerTransformerArray[nDev].szName);

				if (strcmp(szWindH, m_TransformerWindingArray[nData].szName) == 0)
				{
					//Log("        (������%s):%.1f[%d] %.1f[%d] %d[%d]\n", szWindH, 
					//	m_TransformerWindingArray[nData].fP, m_TransformerWindingArray[nData].nPOff, 
					//	m_TransformerWindingArray[nData].fQ, m_TransformerWindingArray[nData].nQOff, 
					//	m_TransformerWindingArray[nData].nTap, m_TransformerWindingArray[nData].nTapOff);
					if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)		pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fPi=m_TransformerWindingArray[nData].fP;
					if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)		pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fQi=m_TransformerWindingArray[nData].fQ;
					if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nTapI=m_TransformerWindingArray[nData].nTap;
					m_TransformerWindingArray[nData].bCheckOK=1;

					goto LTRAN;
				}
				else if (strcmp(szWindL, m_TransformerWindingArray[nData].szName) == 0)
				{
					//Log("        (������%s):%.1f[%d] %.1f[%d] %d[%d]\n", strcmp, 
					//	m_TransformerWindingArray[nData].fP, m_TransformerWindingArray[nData].nPOff, 
					//	m_TransformerWindingArray[nData].fQ, m_TransformerWindingArray[nData].nQOff, 
					//	m_TransformerWindingArray[nData].nTap, m_TransformerWindingArray[nData].nTapOff);
					if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)		pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fPz=m_TransformerWindingArray[nData].fP;
					if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)		pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fQz=m_TransformerWindingArray[nData].fQ;
					if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nTapJ=m_TransformerWindingArray[nData].nTap;
					m_TransformerWindingArray[nData].bCheckOK=1;

					goto LTRAN;
				}
			}
			else
			{
				nTranMid=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].nNodeI ||
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].nNodeJ) ?
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeJ;
				if (strcmp(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].szName, m_TransformerWindingArray[nData].szName) == 0)
				{
					//Log("        (������H): %.1f[%d] %.1f[%d] %d[%d]\n", 
					//	m_TransformerWindingArray[nData].fP, m_TransformerWindingArray[nData].nPOff, 
					//	m_TransformerWindingArray[nData].fQ, m_TransformerWindingArray[nData].nQOff, 
					//	m_TransformerWindingArray[nData].nTap, m_TransformerWindingArray[nData].nTapOff);
					if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nNodeI == nTranMid)
					{
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fPz=-999999;
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fQz=-999999;
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fPz=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fQz=m_TransformerWindingArray[nData].fQ;
						if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
							pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nTapJ=m_TransformerWindingArray[nData].nTap;
					}
					else
					{
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fPi=-999999;
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fQi=-999999;
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fPi=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].fQi=m_TransformerWindingArray[nData].fQ;
						if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
							pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindH].nTapI=m_TransformerWindingArray[nData].nTap;
					}

					m_TransformerWindingArray[nData].bCheckOK=1;
					goto LTRAN;
				}
				else if (strcmp(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].szName, m_TransformerWindingArray[nData].szName) == 0)
				{
					//Log("        (������M): %.1f[%d] %.1f[%d] %d[%d]\n", 
					//	m_TransformerWindingArray[nData].fP, m_TransformerWindingArray[nData].nPOff, 
					//	m_TransformerWindingArray[nData].fQ, m_TransformerWindingArray[nData].nQOff, 
					//	m_TransformerWindingArray[nData].nTap, m_TransformerWindingArray[nData].nTapOff);
					if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].nNodeI == nTranMid)
					{
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fPz=-999999;
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fQz=-999999;
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fPz=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fQz=m_TransformerWindingArray[nData].fQ;
						if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
							pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].nTapJ=m_TransformerWindingArray[nData].nTap;
					}
					else
					{
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fPi=-999999;
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fQi=-999999;
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fPi=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].fQi=m_TransformerWindingArray[nData].fQ;
						if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
							pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindM].nTapI=m_TransformerWindingArray[nData].nTap;
					}
					m_TransformerWindingArray[nData].bCheckOK=1;
					goto LTRAN;
				}
				else if (strcmp(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].szName, m_TransformerWindingArray[nData].szName) == 0)
				{
					//Log("        (������L): %.1f[%d] %.1f[%d] %d[%d]\n", 
					//	m_TransformerWindingArray[nData].fP, m_TransformerWindingArray[nData].nPOff, 
					//	m_TransformerWindingArray[nData].fQ, m_TransformerWindingArray[nData].nQOff, 
					//	m_TransformerWindingArray[nData].nTap, m_TransformerWindingArray[nData].nTapOff);
					if (pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].nNodeI == nTranMid)
					{
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fPz=-999999;
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fQz=-999999;
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fPz=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fQz=m_TransformerWindingArray[nData].fQ;
						if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
							pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].nTapJ=m_TransformerWindingArray[nData].nTap;
					}
					else
					{
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fPi=-999999;
						pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fQi=-999999;
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fPi=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].fQi=m_TransformerWindingArray[nData].fQ;
						if ((m_TransformerWindingArray[nData].nTapOff || !bUseOffFlag) && m_TransformerWindingArray[nData].nTap > 0)
							pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nDev].nWindL].nTapI=m_TransformerWindingArray[nData].nTap;
					}
					m_TransformerWindingArray[nData].bCheckOK=1;
					goto LTRAN;
				}
			}
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, m_TransformerWindingArray[nData].szName) == 0)
				{
					Log("        ����ֵ�ɱ�ѹ��ң��ȷ��: %s.%s \n", m_TransformerWindingArray[nData].szSub, m_TransformerWindingArray[nData].szName);
					if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanP=m_TransformerWindingArray[nData].fP;
					if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=m_TransformerWindingArray[nData].fQ;
					if (!checkP(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_TransformerWindingArray[nData].fP))	pBlock->m_EnergyConsumerArray[nDev].fPlanP=0;
					if (!checkQ(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_TransformerWindingArray[nData].fQ))	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;
					m_TransformerWindingArray[nData].bCheckOK=1;
					goto LTRAN;
				}
			}
		}
LTRAN:	;
	}


	for (nData=0; nData<(int)m_SynchronousMachineArray.size(); nData++)
	{
		//Log("putValue[SynchronousMachine]: %s.%s \n", m_SynchronousMachineArray[nData].szSub, m_SynchronousMachineArray[nData].szName);
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_SynchronousMachineArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
			{
				if (strcmp(pBlock->m_SynchronousMachineArray[nDev].szName, m_SynchronousMachineArray[nData].szName) == 0)
				{
					//Log("        %.1f[%d] %.1f[%d]\n", m_SynchronousMachineArray[nData].fP, m_SynchronousMachineArray[nData].nPOff, m_SynchronousMachineArray[nData].fQ, m_SynchronousMachineArray[nData].nQOff);

					if (m_SynchronousMachineArray[nData].nPOff || !bUseOffFlag)	pBlock->m_SynchronousMachineArray[nDev].fPlanP=m_SynchronousMachineArray[nData].fP;
					if (m_SynchronousMachineArray[nData].nQOff || !bUseOffFlag)	pBlock->m_SynchronousMachineArray[nDev].fPlanQ=m_SynchronousMachineArray[nData].fQ;

					if (m_SynchronousMachineArray[nData].nVOff || !bUseOffFlag)
					{
						pBlock->m_SynchronousMachineArray[nDev].fV=m_SynchronousMachineArray[nData].fV;
						if (pBlock->m_SynchronousMachineArray[nDev].fPMax >= 200)
						{
							pBlock->m_SynchronousMachineArray[nDev].fPlanV=pBlock->m_SynchronousMachineArray[nDev].fV/pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
							if (pBlock->m_SynchronousMachineArray[nDev].fPlanV < 0.9 || pBlock->m_SynchronousMachineArray[nDev].fPlanV > 1.1)
								pBlock->m_SynchronousMachineArray[nDev].fPlanV=1.0;
						}
					}

					if (pBlock->m_SynchronousMachineArray[nDev].fPMax >= 200 && pBlock->m_SynchronousMachineArray[nDev].fPlanP > 10 &&
						(pBlock->m_SynchronousMachineArray[nDev].fPlanV < 0.5 || pBlock->m_SynchronousMachineArray[nDev].fPlanV > 1.5)) 
					{
						pBlock->m_SynchronousMachineArray[nDev].fPlanV=1;
					}

					m_SynchronousMachineArray[nData].bCheckOK=1;
					goto LUNIT;
				}
			}
		}

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
				{
					if (strcmp(pBlock->m_EdgeACLineSegmentArray[nDev].szName, m_SynchronousMachineArray[nData].szName) == 0)
					{
						Log("        �������ɷ������ֵ(%s[%s])    %.1f[%d] %.1f[%d] \n", pBlock->m_EdgeACLineSegmentArray[nDev].szName, pBlock->m_EdgeACLineSegmentArray[nDev].szSub, m_SynchronousMachineArray[nData].fP, m_SynchronousMachineArray[nData].nPOff, m_SynchronousMachineArray[nData].fQ, m_SynchronousMachineArray[nData].nQOff);

						if (strcmp(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, pBlock->m_SubstationArray[nSub].szName) == 0)
						{
							if (m_SynchronousMachineArray[nData].nPOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPi=m_SynchronousMachineArray[nData].fP;
							if (m_SynchronousMachineArray[nData].nQOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQi=m_SynchronousMachineArray[nData].fQ;
						}
						else
						{
							if (m_SynchronousMachineArray[nData].nPOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPz=m_SynchronousMachineArray[nData].fP;
							if (m_SynchronousMachineArray[nData].nQOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQz=m_SynchronousMachineArray[nData].fQ;
						}
						m_SynchronousMachineArray[nData].bCheckOK=1;
						goto LUNIT;
					}
				}
			}
		}
LUNIT:	;
	}

	for (nData=0; nData<(int)m_EnergyConsumerArray.size(); nData++)
	{
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_EnergyConsumerArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, m_EnergyConsumerArray[nData].szName) == 0)
				{
					//Log("putValue[EnergyConsumer]: %s.%s \n", m_EnergyConsumerArray[nData].szSub, m_EnergyConsumerArray[nData].szName);

					if (m_EnergyConsumerArray[nData].nPOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanP=m_EnergyConsumerArray[nData].fP;
					if (m_EnergyConsumerArray[nData].nQOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=m_EnergyConsumerArray[nData].fQ;

					if (!checkP(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_EnergyConsumerArray[nData].fP))	pBlock->m_EnergyConsumerArray[nDev].fPlanP=0;
					if (!checkQ(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_EnergyConsumerArray[nData].fQ))	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;

					m_EnergyConsumerArray[nData].bCheckOK=1;
					goto LLoad;
				}
			}
		}
		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=pBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<pBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=pBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<pBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
				{
					if (strcmp(pBlock->m_EdgeACLineSegmentArray[nDev].szName, m_EnergyConsumerArray[nData].szName) == 0)
					{
						Log("        �������ɸ��ɸ�ֵ(%s[%s])    %.1f[%d] %.1f[%d] \n", pBlock->m_EdgeACLineSegmentArray[nDev].szName, pBlock->m_EdgeACLineSegmentArray[nDev].szSub, m_EnergyConsumerArray[nData].fP, m_EnergyConsumerArray[nData].nPOff, m_EnergyConsumerArray[nData].fQ, m_EnergyConsumerArray[nData].nQOff);

						if (strcmp(pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, pBlock->m_SubstationArray[nSub].szName) == 0)
						{
							pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPi=-999999;
							pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQi=-999999;

							if (m_EnergyConsumerArray[nData].nPOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPi=m_EnergyConsumerArray[nData].fP;
							if (m_EnergyConsumerArray[nData].nQOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQi=m_EnergyConsumerArray[nData].fQ;
						}
						else
						{
							pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPz=-999999;
							pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQz=-999999;

							if (m_EnergyConsumerArray[nData].nPOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fPz=m_EnergyConsumerArray[nData].fP;
							if (m_EnergyConsumerArray[nData].nQOff || !bUseOffFlag)		pBlock->m_ACLineSegmentArray[pBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fQz=m_EnergyConsumerArray[nData].fQ;
						}

						m_EnergyConsumerArray[nData].bCheckOK=1;
						goto LLoad;
					}
				}
			}
		}
LLoad:	;
	}


	for (nData=0; nData<(int)m_ShuntCompensatorArray.size(); nData++)
	{
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_ShuntCompensatorArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nDev++)
			{
				if (strcmp(pBlock->m_ShuntCompensatorArray[nDev].szName, m_ShuntCompensatorArray[nData].szName) == 0)
				{
					if (m_ShuntCompensatorArray[nData].nQOff || !bUseOffFlag)	pBlock->m_ShuntCompensatorArray[nDev].fQ=m_ShuntCompensatorArray[nData].fQ;

					m_ShuntCompensatorArray[nData].bCheckOK=1;
					goto LCAP;
				}
			}
		}
LCAP:	;
	}

	for (nData=0; nData<(int)m_RectifierInverterArray.size(); nData++)
	{
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_RectifierInverterArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nDev=pBlock->m_SubstationArray[nSub].nRectifierInverterRange; nDev<pBlock->m_SubstationArray[nSub+1].nRectifierInverterRange; nDev++)
		{
			if (strcmp(pBlock->m_RectifierInverterArray[nDev].szName, m_RectifierInverterArray[nData].szName) == 0)
			{
				if (m_RectifierInverterArray[nData].nPOff || !bUseOffFlag)	pBlock->m_RectifierInverterArray[nDev].fP=m_RectifierInverterArray[nData].fP;
				if (m_RectifierInverterArray[nData].nQOff || !bUseOffFlag)	pBlock->m_RectifierInverterArray[nDev].fQ=m_RectifierInverterArray[nData].fQ;

				m_RectifierInverterArray[nData].bCheckOK=1;
				goto LRI;
			}
		}
LRI:	;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, m_RectifierInverterArray[nData].szName) == 0)
				{
					Log("        ����ֵ�����������ң��ȷ��putValue[LOAD]: %s.%s \n", m_RectifierInverterArray[nData].szSub, m_RectifierInverterArray[nData].szName);

					pBlock->m_EnergyConsumerArray[nDev].fPlanP=pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;
					if (m_RectifierInverterArray[nData].nPOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanP=m_RectifierInverterArray[nData].fP;
					if (m_RectifierInverterArray[nData].nQOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=m_RectifierInverterArray[nData].fQ;
					if (!checkP(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_RectifierInverterArray[nData].fP))	pBlock->m_EnergyConsumerArray[nDev].fPlanP=0;
					if (!checkQ(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_RectifierInverterArray[nData].fQ))	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;
					m_RectifierInverterArray[nData].bCheckOK=1;

					goto LRILoad;
				}
			}
		}
LRILoad:	;
	}

	if (bUseBreakerStatus)
	{
		for (nData=0; nData<(int)m_BreakerArray.size(); nData++)
		{
			nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_BreakerArray[nData].szSub);
			if (nSub < 0)
				continue;

			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
				{
					if (strcmp(pBlock->m_BreakerArray[nDev].szName, m_BreakerArray[nData].szName) == 0)
					{
						if (m_BreakerArray[nData].nOff || !bUseOffFlag)
						{
							pBlock->m_BreakerArray[nDev].nStatus=(m_BreakerArray[nData].nStat == 0) ? 1 : 0;
							m_BreakerArray[nData].bCheckOK=1;
						}
						goto LBREAKER;
					}
				}
			}
LBREAKER:	;
		}
		for (nData=0; nData<(int)m_DisconnectorArray.size(); nData++)
		{
			nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_DisconnectorArray[nData].szSub);
			if (nSub < 0)
				continue;

			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
				{
					if (strcmp(pBlock->m_BreakerArray[nDev].szName, m_DisconnectorArray[nData].szName) == 0)
					{
						if (m_DisconnectorArray[nData].nOff || !bUseOffFlag)
						{
							pBlock->m_BreakerArray[nDev].nStatus=(m_DisconnectorArray[nData].nStat == 0) ? 1 : 0;
							m_DisconnectorArray[nData].bCheckOK=1;
						}
						goto LSWBreaker;
					}
				}
			}
LSWBreaker:	;
		}
	}

	if (bUseDisconnectorStatus)
	{
		for (nData=0; nData<(int)m_DisconnectorArray.size(); nData++)
		{
			nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_DisconnectorArray[nData].szSub);
			if (nSub < 0)
				continue;

			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
				{
					if (strcmp(pBlock->m_DisconnectorArray[nDev].szName, m_DisconnectorArray[nData].szName) == 0)
					{
						if (m_DisconnectorArray[nData].nOff || !bUseOffFlag)
						{
							pBlock->m_DisconnectorArray[nDev].nStatus=(m_DisconnectorArray[nData].nStat == 0) ? 1 : 0;
							m_DisconnectorArray[nData].bCheckOK=1;
						}

						bFind=1;
						goto LSWITCH;
					}
				}
			}
LSWITCH:	;
		}

		for (nData=0; nData<(int)m_GroundDisconnectorArray.size(); nData++)
		{
			nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_GroundDisconnectorArray[nData].szSub);
			if (nSub < 0)
				continue;

			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
				{
					if (strcmp(pBlock->m_DisconnectorArray[nDev].szName, m_GroundDisconnectorArray[nData].szName) == 0)
					{
						if (m_GroundDisconnectorArray[nData].nOff || !bUseOffFlag)
						{
							pBlock->m_DisconnectorArray[nDev].nStatus=(m_GroundDisconnectorArray[nData].nStat == 0) ? 1 : 0;
							m_GroundDisconnectorArray[nData].bCheckOK=1;
						}

						bFind=1;
						goto LGND;
					}
				}
			}
LGND:		;
		}
	}

	//	�㶫����ƻ���ֵ����
	for (nData=0; nData<(int)m_TransformerWindingArray.size(); nData++)
	{
		if (m_TransformerWindingArray[nData].bCheckOK)
			continue;
		nSub=PGFindRecordbyKey(pBlock, PG_SUBSTATION, m_TransformerWindingArray[nData].szSub);
		if (nSub < 0)
			continue;

		for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			if (pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange-pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange <= 0)	//	����ƻ�����
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
				{
					sprintf(szDevName, "��Ч%s����", m_TransformerWindingArray[nData].szName);
					if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, szDevName) == 0)
					{
						if (m_TransformerWindingArray[nData].nPOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanP=m_TransformerWindingArray[nData].fP;
						if (m_TransformerWindingArray[nData].nQOff || !bUseOffFlag)	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=m_TransformerWindingArray[nData].fQ;

						if (!checkP(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_TransformerWindingArray[nData].fP))	pBlock->m_EnergyConsumerArray[nDev].fPlanP=0;
						if (!checkQ(pBlock->m_VoltageLevelArray[nVolt].nominalVoltage, m_TransformerWindingArray[nData].fQ))	pBlock->m_EnergyConsumerArray[nDev].fPlanQ=0;

						m_TransformerWindingArray[nData].bCheckOK=1;
						Log("����ƻ�����[%s.%s.%s]ֵ�ɱ�ѹ��ң��ȷ��putValue[LOAD]: %s.%s \n", 
							pBlock->m_EnergyConsumerArray[nDev].szSub, pBlock->m_EnergyConsumerArray[nDev].szVolt, pBlock->m_EnergyConsumerArray[nDev].szName, 
							m_TransformerWindingArray[nData].szSub, m_TransformerWindingArray[nData].szName);
						goto LEQLoad;
					}
				}
			}
		}
LEQLoad:	;
	}

	if (!bUseBreakerStatus)
	{
		for (i=0; i<pBlock->m_nRecordNum[PG_BREAKER]; i++)
			pBlock->m_BreakerArray[i].nStatus=0;
	}
	if (!bUseDisconnectorStatus)
	{
		for (i=0; i<pBlock->m_nRecordNum[PG_DISCONNECTOR]; i++)
			pBlock->m_DisconnectorArray[i].nStatus=0;
	}

	clearExcludeSub(pBlock);
}
