#include "stdafx.h"
#include "NariEData.h"

int CNariEData::readFile(const char *lpszFileName, const int bHasID, const int bUseOffFlag)
{
	register int	i;
	int		nChar;
	FILE*	fp;
	char	szLine[1024], szParser[1024];
	char	szClass[260];
	int		nLen, bread;
	int		nContentType;

	fp=fopen(lpszFileName, "r");
	if (fp == NULL)
		return 0;

	ClearLog();
	Clear();

	m_nClassNum=0;
	for (i=0; i<100; i++)
		memset(m_szClassArray[i], 0, 100);

	nContentType=-1;
	while (!feof(fp))
	{
		memset(szLine, 0, 1024);
		fgets(szLine, 1024, fp);
		if (strlen(szLine) <= 0)
			continue;

		nLen=bread=0;
		for (i=0; i<(int)strlen(szLine); i++)
		{
			if (szLine[i] == '\'')
			{
				szLine[i]=' ';
				nChar=i+1;
				bread=(int)strlen(szLine);
				while (nChar < (int)strlen(szLine))
				{
					if (szLine[nChar] == '\'')
					{
						szLine[nChar]=' ';
						break;
					}
					if (szLine[nChar] == ' ')
					{
						szLine[nChar]='_';
					}
					nChar++;
				}
			}
		}
		bread=0;
		for (i=0; i<(int)strlen(szLine); i++)
		{
			if ((szLine[i] == ' ' || szLine[i] == '\t') && !bread)
				continue;
			else
				bread=1;

			szParser[nLen++]=szLine[i];
		}
		szParser[nLen]='\0';

		if (isComment(szParser))
			continue;

		if (strncmp(szParser, "</", 2) == 0)
		{
			nContentType=-1;
		}
		else if (strncmp(szParser, "<", 1) == 0)
		{
			memset(szClass, 0, 260);
			if (readClass(szParser, szClass))
			{
				if (STRICMP(szClass, "system") == 0)
					nContentType=NariEData_System;
				else if (STRICMP(szClass, "Substation") == 0)
					nContentType=NariEData_Substation;
				else if (STRICMP(szClass, "BusbarSection") == 0)
					nContentType=NariEData_BusbarSection;
				else if (STRICMP(szClass, "Breaker") == 0)
					nContentType=NariEData_Breaker;
				else if (STRICMP(szClass, "Disconnector") == 0)
					nContentType=NariEData_Disconnector;
				else if (STRICMP(szClass, "GroundDisconnector") == 0)
					nContentType=NariEData_GroundDisconnector;
				else if (STRICMP(szClass, "ACLineSegment") == 0)
					nContentType=NariEData_ACLineSegment;
				else if (STRICMP(szClass, "TransformerWinding") == 0)
					nContentType=NariEData_TransformerWinding;
				else if (STRICMP(szClass, "SynchronousMachine") == 0)
					nContentType=NariEData_SynchronousMachine;
				else if (STRICMP(szClass, "EnergyConsumer") == 0)
					nContentType=NariEData_EnergyConsumer;
				else if (STRICMP(szClass, "Compensator") == 0)
					nContentType=NariEData_ShuntCompensator;
				else if (STRICMP(szClass, "RectifierInverter") == 0)
					nContentType=NariEData_RectifierInverter;
				else if (STRICMP(szClass, "FacInfo") == 0)
					nContentType=NariEData_FacInfo;
				else if (STRICMP(szClass, "DivInfo") == 0)
					nContentType=NariEData_DivInfo;
				else
					nContentType=-1;
			}
		}
		switch (nContentType)	//	Ŀǰ����DCLINE��CONVERT��COMPENSATOR_S
		{
		case	NariEData_System:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readSystem(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_Substation:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readSubstation(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_BusbarSection:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readBusbarSection(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_ACLineSegment:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readACLineSegment(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_TransformerWinding:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readTransformerWinding(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_SynchronousMachine:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readSynchronousMachine(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_EnergyConsumer:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readEnergyConsumer(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_ShuntCompensator:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readShuntCompensator(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_RectifierInverter:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readRectifierInverter(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_Breaker:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readBreaker(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_Disconnector:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readDisconnector(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_GroundDisconnector:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readGroundDisconnector(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_DivInfo:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readDivInfo(szParser, bHasID, bUseOffFlag);
			break;
		case	NariEData_FacInfo:
			if (isAttribute(szParser))
				readAttributes(nContentType, szParser);
			if (isData(szParser))
				readFacInfo(szParser, bHasID, bUseOffFlag);
			break;
		default:
			break;
		}
	}

	fclose(fp);

	return 1;
}

int CNariEData::isComment(const char *lpszParser)
{
	if (strncmp(lpszParser, "//", 2) == 0)
		return 1;

	return 0;
}

int CNariEData::isAttribute(const char *lpszParser)
{
	if (strncmp(lpszParser, "@", 1) == 0)
		return 1;

	return 0;
}

int CNariEData::isData(const char *lpszParser)
{
	if (strncmp(lpszParser, "#", 1) == 0)
		return 1;

	return 0;
}

void CNariEData::readAttributes(const int nTable, char *lpszParser)
{
}

void CNariEData::readSystem(char* lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*		lpszToken;
	int			nCol, nEle;
	char		szEle[50][100];

	if (strncmp(lpszParser, "#", 1) != 0)
		return;

	memset(&m_System, 0, sizeof(tagSystem));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol)	{	strcpy(m_System.szArea, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)	{	strcpy(m_System.szSystem, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)	{	strcpy(m_System.szTime, szEle[nCol]);	nCol++;	}
}

void CNariEData::readSubstation(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagSubstation	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagSubstation));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol)	{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)	{	vBuf.bExclude=atoi(szEle[nCol]);	nCol++;	}

	m_SubstationArray.push_back(vBuf);
}

void CNariEData::readBusbarSection(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagBusbarSection	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagBusbarSection));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.fV=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nVOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fD=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nDOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	Log("readBusbarSection: %s.%s %.1f(%d) \n", vBuf.szSub, vBuf.szName, vBuf.fV, vBuf.nVOff);
	m_BusbarSectionArray.push_back(vBuf);
}

void CNariEData::readACLineSegment(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagAClineSegment	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagAClineSegment));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.fP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nQOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fI=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nIOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	//Log("readACLineSegment: %s.%s %.1f(%d) %.1f(%d) \n", vBuf.szSub, vBuf.szName, vBuf.fP, vBuf.nPOff, vBuf.fQ, vBuf.nQOff);
	m_ACLineSegmentArray.push_back(vBuf);
}

void CNariEData::readTransformerWinding(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagTransformerWinding	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagTransformerWinding));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.fP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nQOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nTap=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nTapOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	//Log("readTransformerWinding: %s.%s %.1f(%d) %.1f(%d) %d(%d) \n", vBuf.szSub, vBuf.szName, vBuf.fP, vBuf.nPOff, vBuf.fQ, vBuf.nQOff, vBuf.nTap, vBuf.nTapOff);
	m_TransformerWindingArray.push_back(vBuf);
}

void CNariEData::readSynchronousMachine(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagSynchronousMachine	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagSynchronousMachine));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.fP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nQOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fV=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nVOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	//Log("readSynchronousMachine: %s.%s %.1f(%d) %.1f(%d) %.1f(%d) \n", vBuf.szSub, vBuf.szName, vBuf.fP, vBuf.nPOff, vBuf.fQ, vBuf.nQOff, vBuf.fV, vBuf.nVOff);
	m_SynchronousMachineArray.push_back(vBuf);
}

void CNariEData::readEnergyConsumer(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagEnergyConsumer	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagEnergyConsumer));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.fP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nQOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	//Log("readEnergyConsumer: %s.%s %.1f(%d) %.1f(%d) \n", vBuf.szSub, vBuf.szName, vBuf.fP, vBuf.nPOff, vBuf.fQ, vBuf.nQOff);
	m_EnergyConsumerArray.push_back(vBuf);
}

void CNariEData::readShuntCompensator(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagShuntCompensator	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagShuntCompensator));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.fQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nQOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	m_ShuntCompensatorArray.push_back(vBuf);
}


void CNariEData::readRectifierInverter(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagRectifierInverter	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagRectifierInverter));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}

	if (nEle > nCol)			{	vBuf.fV=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nVOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nQOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nTap=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nTapOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fD=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nDOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	m_RectifierInverterArray.push_back(vBuf);
}

void CNariEData::readBreaker(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagYX	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagYX));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nStat=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	//Log("readBreaker: %s.%s %d(%d)\n", vBuf.szSub, vBuf.szName, vBuf.nStat, vBuf.nOff);
	m_BreakerArray.push_back(vBuf);
}

void CNariEData::readDisconnector(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagYX	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagYX));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nStat=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	m_DisconnectorArray.push_back(vBuf);
}

void CNariEData::readGroundDisconnector(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagYX	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagYX));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szSub, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nStat=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	m_GroundDisconnectorArray.push_back(vBuf);
}

void CNariEData::readDivInfo(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagDivInfo	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagDivInfo));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);				nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);			nCol++;	}
	if (nEle > nCol)			{	vBuf.fGenP=(float)atof(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nGenPOff=atoi(szEle[nCol]);			nCol++;	}
	if (nEle > nCol)			{	vBuf.fLoadP=(float)atof(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nLoadPOff=atoi(szEle[nCol]);			nCol++;	}
	if (nEle > nCol)			{	vBuf.fTherimalP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nTherimalPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fHydroP=(float)atof(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.nHydroPOff=atoi(szEle[nCol]);			nCol++;	}
	if (nEle > nCol)			{	vBuf.fWindTurbineP=(float)atof(szEle[nCol]);nCol++;	}
	if (nEle > nCol)			{	vBuf.nWindTurbinePOff=atoi(szEle[nCol]);	nCol++;	}
	vBuf.bCheckOK=0;

	m_DivInfoArray.push_back(vBuf);
}

void CNariEData::readFacInfo(char *lpszParser, const int bHasID, const int bUseOffFlag)
{
	char*	lpszToken;
	int		nCol, nEle;
	char	szEle[50][100];
	tagFacInfo	vBuf;

	if (strncmp(lpszParser, "#", 1) != 0)
		return;
	memset(&vBuf, 0, sizeof(tagFacInfo));

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n#");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n");
	}

	nCol=0;
	if (nEle > nCol && bHasID)	{	strcpy(vBuf.szID, szEle[nCol]);			nCol++;	}
	if (nEle > nCol)			{	strcpy(vBuf.szName, szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fGenP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nGenPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fGenQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nGenQOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fLoadP=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nLoadPOff=atoi(szEle[nCol]);		nCol++;	}
	if (nEle > nCol)			{	vBuf.fLoadQ=(float)atof(szEle[nCol]);	nCol++;	}
	if (nEle > nCol)			{	vBuf.nLoadQOff=atoi(szEle[nCol]);		nCol++;	}
	vBuf.bCheckOK=0;

	m_FacInfoArray.push_back(vBuf);
}

int CNariEData::readClass(char *lpszParser, char *lpszRetClass)
{
	register int	i;
	int		bExist;
	char*	lpszToken;
	int		nEle;
	char	szEle[50][100];

	nEle=0;
	lpszToken=strtok(lpszParser, " \t\n<>:");
	while (lpszToken != NULL)
	{
		strcpy(szEle[nEle++], lpszToken);
		lpszToken=strtok(NULL, " \t\n<>:");
	}
	if (nEle >= 1)
	{
		strcpy(lpszRetClass, szEle[0]);
		bExist=0;
		for (i=0; i<m_nClassNum; i++)
		{
			if (strcmp(m_szClassArray[i], lpszRetClass) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			strcpy(m_szClassArray[m_nClassNum++], lpszRetClass);
		}
	}
	else
	{
		return 0;
	}

	return 1;
}
