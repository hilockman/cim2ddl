#include "../stdafx.h"

tagPGBlock*		g_pBlock;
CNariEData		g_NariEData;

int main(int argc, char** argv)
{
	int		nArg;
	clock_t	dBeg, dEnd;
	int		nDur;

	char	szFileName[260];
	int		bUseBreakerStatus, bUseDisconnectorStatus, bUseOffFlag, bHasID, bTran2LoadFlag;

	bHasID=0;
	if (argc < 4)
	{
		printf("��ȷ�ĺ����÷���: ReadNariEData EFileName UseBreakerStatus UseDisconnectorStatus UseOffFlag[=0��ʾң��״̬ȫ���úϣ�=1��ʾ����EMS��ң��״̬] HasID Tran2Load\n");
		return 0;
	}

	memset(szFileName, 0, 260);
	bUseBreakerStatus=bUseDisconnectorStatus=bUseOffFlag=1;
	bTran2LoadFlag=0;

	nArg=1;
	if (argc > nArg)	strcpy(szFileName, argv[nArg++]);
	if (argc > nArg)	bUseBreakerStatus=atoi(argv[nArg++]);
	if (argc > nArg)	bUseDisconnectorStatus=atoi(argv[nArg++]);
	if (argc > nArg)	bUseOffFlag=atoi(argv[nArg++]);
	if (argc > nArg)	bHasID=atoi(argv[nArg++]);
	if (argc > nArg)	bTran2LoadFlag=atoi(argv[nArg++]);

	dBeg=clock();

	g_pBlock=(tagPGBlock*)Init_PGBlock();
	if (!g_pBlock)
	{
		printf("��ȡ�ڴ�����\n");
		return 0;
	}

	g_NariEData.readFile(szFileName, bHasID, bUseOffFlag);
	g_NariEData.putValue(g_pBlock, bUseBreakerStatus, bUseDisconnectorStatus, bUseOffFlag);
	if (bTran2LoadFlag)
		g_NariEData.Tran2Load(g_pBlock);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	printf("E�ļ�������ϣ���ʱ%d����\n", nDur);

	return 1;
}
