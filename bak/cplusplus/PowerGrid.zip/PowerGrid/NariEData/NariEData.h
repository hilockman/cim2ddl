#pragma	once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <sys/types.h>

#include <vector>
using namespace std;

#include "NariEDataDefine.h"

class CNariEData  
{
public:
	CNariEData();
	virtual ~CNariEData();
	int		readFile(const char* lpszFileName, const int bHasID=0, const int bUseOffFlag=0);
	void	putValue(tagPGBlock* pBlock, const int bUseBreakerStatus=1, const int bUseDisconnectorStatus=0, const int bUseOffFlag=1);
	void	Tran2Load(tagPGBlock* pBlock);
	void	checkObserve(tagPGBlock* pBlock);

	tagSystem							m_System;
	std::vector<tagSubstation>			m_SubstationArray;
	std::vector<tagBusbarSection>		m_BusbarSectionArray;
	std::vector<tagAClineSegment>		m_ACLineSegmentArray;
	std::vector<tagTransformerWinding>	m_TransformerWindingArray;
	std::vector<tagSynchronousMachine>	m_SynchronousMachineArray;
	std::vector<tagEnergyConsumer>		m_EnergyConsumerArray;
	std::vector<tagShuntCompensator>	m_ShuntCompensatorArray;
	std::vector<tagRectifierInverter>	m_RectifierInverterArray;

	std::vector<tagDivInfo>				m_DivInfoArray;
	std::vector<tagFacInfo>				m_FacInfoArray;


	std::vector<tagYX>		m_BreakerArray;
	std::vector<tagYX>		m_DisconnectorArray;
	std::vector<tagYX>		m_GroundDisconnectorArray;
	int		m_nClassNum;
	char	m_szClassArray[100][100];

private:
	void ClearLog();
	void Log(char* pformat, ...);
	int isSubExclude(const char* lpszSub);
	void clearExcludeSub(tagPGBlock* pBlock);
	int checkP(const float fVolt, const float fP);
	int checkQ(const float fVolt, const float fQ);
	int readClass(char *lpszParser, char *lpszRetClass);
	void readAttributes(const int nTable, char *lpszParser);

	void readSystem				(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readSubstation			(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readBusbarSection		(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readACLineSegment		(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readTransformerWinding	(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readSynchronousMachine	(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readEnergyConsumer		(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readShuntCompensator	(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readRectifierInverter	(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readBreaker			(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readDisconnector		(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readGroundDisconnector	(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readDivInfo			(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);
	void readFacInfo			(char *lpszParser, const int bHasID=0, const int bUseOffFlag=1);

	int isData(const char *lpszParser);
	int isAttribute(const char *lpszParser);
	int isComment(const char *lpszParser);

	void Clear();

private:
	unsigned char	IsNodeJointGenerator(tagPGBlock* pBlock, const int nTranNode);
	void TraverseJointLoad(tagPGBlock* pBlock, const int nTranNode, std::vector<int>& nLoadArray);

	int		GetPGTranPQ(tagPGBlock* pBlock, const int bLowToMid, const char* lpszPGWindName, const int nSide, float& fTranP, float& fTranQ);
	int		GetPGLinePQ(tagPGBlock* pBlock, const int bLowToMid, const char* lpszPGLineName, const char* lpszPGSubName, float& fLineP, float& fLineQ);
};
