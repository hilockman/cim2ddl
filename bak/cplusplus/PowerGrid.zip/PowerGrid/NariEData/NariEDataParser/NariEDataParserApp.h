
// NariEDataParser.h : NariEDataParser Ӧ�ó������ͷ�ļ�
//
#pragma once

#ifndef __AFXWIN_H__
#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"       // ������


// CNariEDataParserApp:
// �йش����ʵ�֣������ NariEDataParser.cpp
//

#define		UM_CLASS_CHANGED	WM_APP+100
#define		UM_MESSAGE			WM_APP+101

class CNariEDataParserApp : public CWinAppEx
{
public:
	CNariEDataParserApp();


// ��д
public:
	virtual BOOL InitInstance();

// ʵ��
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();
};

extern	CNariEDataParserApp	theApp;
extern	CNariEData		g_NariEData;
extern	tagPGBlock*		g_pBlock;
extern	unsigned char	g_bHasID;
extern	unsigned char	g_bUseOffFlag;
extern	unsigned char	g_bTran2LoadFlag;

extern	void	PrintMessage(const char*);
extern	void	SaveListAsExcel(CListCtrl* pListCtrl, const char* lpszExcelSheetName, const char* lpszFileName, const unsigned char bShowExcel);
extern	void	ReadIni(void);
extern	void	SaveIni(void);
extern	std::string	toString(const double fBuf);
extern	std::string	toString(const float fBuf);
extern	std::string	toString(const int nBuf);
extern	std::string	toString(const short nBuf);
extern	std::string	toString(const unsigned char bBuf);
