// SetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "NariEDataParserApp.h"
#include "SetDialog.h"


// CSetDialog �Ի���

IMPLEMENT_DYNAMIC(CSetDialog, CDialog)

CSetDialog::CSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSetDialog::IDD, pParent)
{

}

CSetDialog::~CSetDialog()
{
}

void CSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSetDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CSetDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CSetDialog ��Ϣ��������

BOOL CSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CButton*	pButton;
	
	pButton=(CButton*)GetDlgItem(IDC_HASID);
	pButton->SetCheck(g_bHasID);

	pButton=(CButton*)GetDlgItem(IDC_USE_OFFFLAG);
	pButton->SetCheck(g_bUseOffFlag);

	pButton=(CButton*)GetDlgItem(IDC_TRAN2LOAD);
	pButton->SetCheck(g_bTran2LoadFlag);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CSetDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton;
	
	pButton=(CButton*)GetDlgItem(IDC_HASID);
	g_bHasID=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_USE_OFFFLAG);
	g_bUseOffFlag=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_TRAN2LOAD);
	g_bTran2LoadFlag=pButton->GetCheck();

	SaveIni();

	OnOK();
}
