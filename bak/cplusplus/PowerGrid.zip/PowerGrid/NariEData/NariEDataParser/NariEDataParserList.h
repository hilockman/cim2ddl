
// NariEDataParserList.h : CNariEDataParserList ��Ľӿ�
//


#pragma once


class CNariEDataParserList : public CListView
{
protected: // �������л�����
	CNariEDataParserList();
	DECLARE_DYNCREATE(CNariEDataParserList)

// ����
public:
	CNariEDataParserDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
	virtual ~CNariEDataParserList();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg LRESULT OnClassChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSaveasExcel();
	afx_msg void OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult);
	void DrawItem(const int nClass, NMLVDISPINFO* pDispInfo);
	DECLARE_MESSAGE_MAP()
private:
	void Refresh(const int nClass);
	void Refresh_Old(const int nClass);
	int m_nCurClass;
protected:
//	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
};

#ifndef _DEBUG  // NariEDataParserList.cpp �еĵ��԰汾
inline CNariEDataParserDoc* CNariEDataParserList::GetDocument() const
{
	return reinterpret_cast<CNariEDataParserDoc*>(m_pDocument);
}
#endif

