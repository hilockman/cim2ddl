
// NariEDataParserList.cpp : CNariEDataParserList ���ʵ��
//

#include "stdafx.h"
#include "NariEDataParserApp.h"

#include "NariEDataParserDoc.h"
#include "NariEDataParserList.h"

#include "../NariEDataField.h"
#include "../NariEDataTable.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CNariEDataParserList

IMPLEMENT_DYNCREATE(CNariEDataParserList, CListView)

BEGIN_MESSAGE_MAP(CNariEDataParserList, CListView)
	ON_MESSAGE(UM_CLASS_CHANGED,	OnClassChanged)
	ON_COMMAND(ID_SAVEAS_EXCEL, &CNariEDataParserList::OnSaveasExcel)
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, &CNariEDataParserList::OnLvnGetdispinfo)
END_MESSAGE_MAP()

// CNariEDataParserList ����/����

CNariEDataParserList::CNariEDataParserList()
{
	// TODO: �ڴ˴����ӹ������
	m_nCurClass=-1;
}

CNariEDataParserList::~CNariEDataParserList()
{
}

BOOL CNariEDataParserList::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ
	cs.style &= ~LVS_TYPEMASK;
	cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT | LVS_OWNERDATA;// | LVS_OWNERDRAWFIXED;
	return CListView::PreCreateWindow(cs);
}

void CNariEDataParserList::OnInitialUpdate()
{
	CListView::OnInitialUpdate();


	// TODO: ���� GetListCtrl() ֱ�ӷ��� ListView ���б��ؼ���
	//  �Ӷ������������ ListView��
	GetListCtrl().SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void CNariEDataParserList::OnRButtonUp(UINT nFlags, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CNariEDataParserList::OnContextMenu(CWnd* pWnd, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CNariEDataParserList ���

#ifdef _DEBUG
void CNariEDataParserList::AssertValid() const
{
	CListView::AssertValid();
}

void CNariEDataParserList::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CNariEDataParserDoc* CNariEDataParserList::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CNariEDataParserDoc)));
	return (CNariEDataParserDoc*)m_pDocument;
}
#endif //_DEBUG


// CNariEDataParserList ��Ϣ��������

void CNariEDataParserList::Refresh(const int nClass)
{
	register int	i;
	int			nRowNum, nColNum;

	if (nClass < 0)
		return;

	nRowNum=nColNum=0;
	while (GetListCtrl().DeleteColumn(0));
	if (!GetListCtrl().DeleteAllItems())
		return;

	GetListCtrl().InsertColumn(0, "���");
	switch (nClass)
	{
	case	NariEData_System:	//	System
		nRowNum=1;
		nColNum=sizeof(g_lpszSystemAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszSystemAttrArray[i]);
		break;

	case	NariEData_Substation:	//	Substation
		nRowNum=(int)g_NariEData.m_SubstationArray.size();
		nColNum=sizeof(g_lpszSubstationAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszSubstationAttrArray[i]);
		break;

	case	NariEData_BusbarSection:	//	BusbarSection
		nRowNum=(int)g_NariEData.m_BusbarSectionArray.size();
		nColNum=sizeof(g_lpszBusbarSectionAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszBusbarSectionAttrArray[i]);
		break;

	case	NariEData_ACLineSegment:	//	ACLineSegment
		nRowNum=(int)g_NariEData.m_ACLineSegmentArray.size();
		nColNum=sizeof(g_lpszAClineSegmentAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszAClineSegmentAttrArray[i]);
		break;

	case	NariEData_SynchronousMachine:	//	SynchronousMachine
		nRowNum=(int)g_NariEData.m_SynchronousMachineArray.size();
		nColNum=sizeof(g_lpszSynchronousMachineAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszSynchronousMachineAttrArray[i]);
		break;

	case	NariEData_TransformerWinding:	//	TransformerWinding
		nRowNum=(int)g_NariEData.m_TransformerWindingArray.size();
		nColNum=sizeof(g_lpszTransformerWindingAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszTransformerWindingAttrArray[i]);
		break;

	case	NariEData_EnergyConsumer:	//	EnergyConsumer
		nRowNum=(int)g_NariEData.m_EnergyConsumerArray.size();
		nColNum=sizeof(g_lpszEnergyConsumerAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszEnergyConsumerAttrArray[i]);
		break;

	case	NariEData_ShuntCompensator:	//	ShuntCompensator
		nRowNum=(int)g_NariEData.m_ShuntCompensatorArray.size();
		nColNum=sizeof(g_lpszShuntCompensatorAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszShuntCompensatorAttrArray[i]);
		break;

	case	NariEData_RectifierInverter:	//	RectifierInverter
		nRowNum=(int)g_NariEData.m_RectifierInverterArray.size();
		nColNum=sizeof(g_lpszRectifierInverterAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszRectifierInverterAttrArray[i]);
		break;

	case	NariEData_Breaker:	//	Breaker
		nRowNum=(int)g_NariEData.m_BreakerArray.size();
		nColNum=sizeof(g_lpszYXAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszYXAttrArray[i]);
		break;

	case	NariEData_Disconnector:	//	Disconnector
		nRowNum=(int)g_NariEData.m_DisconnectorArray.size();
		nColNum=sizeof(g_lpszYXAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszYXAttrArray[i]);
		break;

	case	NariEData_GroundDisconnector:	//	GroundDisconnector
		nRowNum=(int)g_NariEData.m_GroundDisconnectorArray.size();
		nColNum=sizeof(g_lpszYXAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszYXAttrArray[i]);
		break;

	case	NariEData_DivInfo:	//	DivInfo
		nRowNum=(int)g_NariEData.m_DivInfoArray.size();
		nColNum=sizeof(g_lpszDivInfoAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszDivInfoAttrArray[i]);
		break;

	case	NariEData_FacInfo:	//	FacInfo
		nRowNum=(int)g_NariEData.m_FacInfoArray.size();
		nColNum=sizeof(g_lpszFacInfoAttrArray)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, g_lpszFacInfoAttrArray[i]);
		break;

	default:
		break;
	}

	GetListCtrl().SetItemCount(nRowNum);	//force redraw
	GetListCtrl().SetItemState(0, LVIS_SELECTED, 0xffff);
	GetListCtrl().EnsureVisible(0, FALSE);

	int	nColWidth, nHeaderWidth;
	for (i=0; i<=nColNum; i++)
	{
		nColWidth=nHeaderWidth=0;

		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = GetListCtrl().GetColumnWidth(i);
		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =GetListCtrl().GetColumnWidth(i);

		GetListCtrl().SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

LRESULT CNariEDataParserList::OnClassChanged(WPARAM wParam, LPARAM lParam)
{
	TRACE("ViewOnClassChanged: %d\n", wParam);
	if (m_nCurClass != wParam && wParam >= 0)
	{
		m_nCurClass=(int)wParam;
		Refresh(m_nCurClass);
	}
	return 0;
}

void CNariEDataParserList::OnSaveasExcel()
{
	// TODO: �ڴ�����������������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	SaveListAsExcel(&GetListCtrl(), g_NariEDataTableArray[m_nCurClass].szDesp, dlg.GetPathName(), 1);
}

void CNariEDataParserList::OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DrawItem(m_nCurClass, pDispInfo);
	*pResult = 0;
}

void CNariEDataParserList::DrawItem(const int nClass, NMLVDISPINFO* pDispInfo)
{
	// TODO:  �������Ĵ����Ի���ָ����
	if (nClass < 0)
		return;

	LV_ITEM* pItem= &(pDispInfo)->item;
	if (!(pItem->mask & LVIF_TEXT))
		return;

	int	nRow=pItem->iItem;
	int	nCol=pItem->iSubItem;
	if (nCol == 0)
	{
		strcpy(pItem->pszText, toString(nRow+1).c_str());
	}
	else
	{
		switch (nClass)
		{
		case	NariEData_System:	//	System
			switch (nCol-1)
			{
			case	NariEData_System_Area:		strcpy(pItem->pszText, g_NariEData.m_System.szArea);		break;
			case	NariEData_System_System:	strcpy(pItem->pszText, g_NariEData.m_System.szSystem);	break;
			case	NariEData_System_Time:		strcpy(pItem->pszText, g_NariEData.m_System.szTime);		break;
			}
			break;
		case	NariEData_Substation:	//	Substation
			switch (nCol-1)
			{
			case	NariEData_Substation_Name:		strcpy(pItem->pszText, g_NariEData.m_SubstationArray[nRow].szName);						break;
			case	NariEData_Substation_Exclude:	strcpy(pItem->pszText, toString(g_NariEData.m_SubstationArray[nRow].bExclude).c_str());	break;
			}
			break;

		case	NariEData_BusbarSection:	//	BusbarSection
			switch (nCol-1)
			{
			case	NariEData_BusbarSection_ID:		strcpy(pItem->pszText, g_NariEData.m_BusbarSectionArray[nRow].szID);							break;
			case	NariEData_BusbarSection_Sub:	strcpy(pItem->pszText, g_NariEData.m_BusbarSectionArray[nRow].szSub);						break;
			case	NariEData_BusbarSection_Name:	strcpy(pItem->pszText, g_NariEData.m_BusbarSectionArray[nRow].szName);						break;
			case	NariEData_BusbarSection_V:		strcpy(pItem->pszText, toString(g_NariEData.m_BusbarSectionArray[nRow].fV).c_str());			break;
			case	NariEData_BusbarSection_D:		strcpy(pItem->pszText, toString(g_NariEData.m_BusbarSectionArray[nRow].fD).c_str());			break;
			case	NariEData_BusbarSection_VOff:	strcpy(pItem->pszText, toString(g_NariEData.m_BusbarSectionArray[nRow].nVOff).c_str());		break;
			case	NariEData_BusbarSection_DOff:	strcpy(pItem->pszText, toString(g_NariEData.m_BusbarSectionArray[nRow].nDOff).c_str());		break;
			case	NariEData_BusbarSection_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_BusbarSectionArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_ACLineSegment:	//	ACLineSegment
			switch (nCol-1)
			{
			case	NariEData_AClineSegment_ID:		strcpy(pItem->pszText, g_NariEData.m_ACLineSegmentArray[nRow].szID);							break;
			case	NariEData_AClineSegment_Sub:	strcpy(pItem->pszText, g_NariEData.m_ACLineSegmentArray[nRow].szSub);						break;
			case	NariEData_AClineSegment_Name:	strcpy(pItem->pszText, g_NariEData.m_ACLineSegmentArray[nRow].szName);						break;
			case	NariEData_AClineSegment_P:		strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].fP).c_str());			break;
			case	NariEData_AClineSegment_Q:		strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].fQ).c_str());			break;
			case	NariEData_AClineSegment_I:		strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].fI).c_str());			break;
			case	NariEData_AClineSegment_POff:	strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].nPOff).c_str());		break;
			case	NariEData_AClineSegment_QOff:	strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].nQOff).c_str());		break;
			case	NariEData_AClineSegment_IOff:	strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].nIOff).c_str());		break;
			case	NariEData_AClineSegment_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_ACLineSegmentArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_SynchronousMachine:	//	SynchronousMachine
			switch (nCol-1)
			{
			case	NariEData_SynchronousMachine_ID:	strcpy(pItem->pszText, g_NariEData.m_SynchronousMachineArray[nRow].szID	);						break;
			case	NariEData_SynchronousMachine_Sub:	strcpy(pItem->pszText, g_NariEData.m_SynchronousMachineArray[nRow].szSub);						break;
			case	NariEData_SynchronousMachine_Name:	strcpy(pItem->pszText, g_NariEData.m_SynchronousMachineArray[nRow].szName);						break;
			case	NariEData_SynchronousMachine_P:		strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].fP).c_str());		break;
			case	NariEData_SynchronousMachine_Q:		strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].fQ).c_str());		break;
			case	NariEData_SynchronousMachine_I:		strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].fV).c_str());		break;
			case	NariEData_SynchronousMachine_POff:	strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].nPOff).c_str());		break;
			case	NariEData_SynchronousMachine_QOff:	strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].nQOff).c_str());		break;
			case	NariEData_SynchronousMachine_IOff:	strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].nVOff).c_str());		break;
			case	NariEData_SynchronousMachine_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_SynchronousMachineArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_TransformerWinding:	//	TransformerWinding
			switch (nCol-1)
			{
			case	NariEData_TransformerWinding_ID:		strcpy(pItem->pszText, g_NariEData.m_TransformerWindingArray[nRow].szID);						break;
			case	NariEData_TransformerWinding_Sub:		strcpy(pItem->pszText, g_NariEData.m_TransformerWindingArray[nRow].szSub);						break;
			case	NariEData_TransformerWinding_Name:		strcpy(pItem->pszText, g_NariEData.m_TransformerWindingArray[nRow].szName);						break;
			case	NariEData_TransformerWinding_P:			strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].fP).c_str());		break;
			case	NariEData_TransformerWinding_Q:			strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].fQ).c_str());		break;
			case	NariEData_TransformerWinding_Tap:		strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].nTap).c_str());		break;
			case	NariEData_TransformerWinding_POff:		strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].nPOff).c_str());		break;
			case	NariEData_TransformerWinding_QOff:		strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].nQOff).c_str());		break;
			case	NariEData_TransformerWinding_TapOff:	strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].nTapOff).c_str());	break;
			case	NariEData_TransformerWinding_Check:		strcpy(pItem->pszText, toString(g_NariEData.m_TransformerWindingArray[nRow].bCheckOK).c_str());	break;
			}
			break;
		case	NariEData_EnergyConsumer:	//	EnergyConsumer
			switch (nCol-1)
			{
			case	NariEData_EnergyConsumer_ID:	strcpy(pItem->pszText, g_NariEData.m_EnergyConsumerArray[nRow].szID);						break;
			case	NariEData_EnergyConsumer_Sub:	strcpy(pItem->pszText, g_NariEData.m_EnergyConsumerArray[nRow].szSub);						break;
			case	NariEData_EnergyConsumer_Name:	strcpy(pItem->pszText, g_NariEData.m_EnergyConsumerArray[nRow].szName);						break;
			case	NariEData_EnergyConsumer_P:		strcpy(pItem->pszText, toString(g_NariEData.m_EnergyConsumerArray[nRow].fP).c_str());		break;
			case	NariEData_EnergyConsumer_Q:		strcpy(pItem->pszText, toString(g_NariEData.m_EnergyConsumerArray[nRow].fQ).c_str());		break;
			case	NariEData_EnergyConsumer_POff:	strcpy(pItem->pszText, toString(g_NariEData.m_EnergyConsumerArray[nRow].nPOff).c_str());		break;
			case	NariEData_EnergyConsumer_QOff:	strcpy(pItem->pszText, toString(g_NariEData.m_EnergyConsumerArray[nRow].nQOff).c_str());		break;
			case	NariEData_EnergyConsumer_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_EnergyConsumerArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_ShuntCompensator:	//	ShuntCompensator
			switch (nCol-1)
			{
			case	NariEData_ShuntCompensator_ID:		strcpy(pItem->pszText, g_NariEData.m_ShuntCompensatorArray[nRow].szID);							break;
			case	NariEData_ShuntCompensator_Sub:		strcpy(pItem->pszText, g_NariEData.m_ShuntCompensatorArray[nRow].szSub);							break;
			case	NariEData_ShuntCompensator_Name:	strcpy(pItem->pszText, g_NariEData.m_ShuntCompensatorArray[nRow].szName);						break;
			case	NariEData_ShuntCompensator_Q:		strcpy(pItem->pszText, toString(g_NariEData.m_ShuntCompensatorArray[nRow].fQ).c_str());			break;
			case	NariEData_ShuntCompensator_QOff:	strcpy(pItem->pszText, toString(g_NariEData.m_ShuntCompensatorArray[nRow].nQOff).c_str());		break;
			case	NariEData_ShuntCompensator_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_ShuntCompensatorArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_RectifierInverter:	//	RectifierInverter
			switch (nCol-1)
			{
			case	NariEData_RectifierInverter_ID:		strcpy(pItem->pszText, g_NariEData.m_RectifierInverterArray[nRow].szID);							break;
			case	NariEData_RectifierInverter_Sub:	strcpy(pItem->pszText, g_NariEData.m_RectifierInverterArray[nRow].szSub);						break;
			case	NariEData_RectifierInverter_DCBus:	strcpy(pItem->pszText, g_NariEData.m_RectifierInverterArray[nRow].szName);						break;
			case	NariEData_RectifierInverter_P:		strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].fP).c_str());			break;
			case	NariEData_RectifierInverter_Q:		strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].fQ).c_str());			break;
			case	NariEData_RectifierInverter_Tap:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].nTap).c_str());		break;
			case	NariEData_RectifierInverter_V:		strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].fV).c_str());			break;
			case	NariEData_RectifierInverter_D:		strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].fD).c_str());			break;
			case	NariEData_RectifierInverter_POff:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].nPOff).c_str());		break;
			case	NariEData_RectifierInverter_QOff:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].nQOff).c_str());		break;
			case	NariEData_RectifierInverter_TapOff:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].nTapOff).c_str());	break;
			case	NariEData_RectifierInverter_VOff:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].nVOff).c_str());		break;
			case	NariEData_RectifierInverter_DOff:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].nDOff).c_str());		break;
			case	NariEData_RectifierInverter_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_RectifierInverterArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_Breaker:	//	Breaker
			switch (nCol-1)
			{
			case	NariEData_YX_ID:	strcpy(pItem->pszText, g_NariEData.m_BreakerArray[nRow].szID);						break;
			case	NariEData_YX_Sub:	strcpy(pItem->pszText, g_NariEData.m_BreakerArray[nRow].szSub);						break;
			case	NariEData_YX_Name:	strcpy(pItem->pszText, g_NariEData.m_BreakerArray[nRow].szName);						break;
			case	NariEData_YX_nStat:	strcpy(pItem->pszText, toString(g_NariEData.m_BreakerArray[nRow].nStat).c_str());	break;
			case	NariEData_YX_nOff:	strcpy(pItem->pszText, toString(g_NariEData.m_BreakerArray[nRow].nOff).c_str());		break;
			case	NariEData_YX_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_BreakerArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_Disconnector:	//	Disconnector
			switch (nCol-1)
			{
			case	NariEData_YX_ID:	strcpy(pItem->pszText, g_NariEData.m_DisconnectorArray[nRow].szID);						break;
			case	NariEData_YX_Sub:	strcpy(pItem->pszText, g_NariEData.m_DisconnectorArray[nRow].szSub);						break;
			case	NariEData_YX_Name:	strcpy(pItem->pszText, g_NariEData.m_DisconnectorArray[nRow].szName);					break;
			case	NariEData_YX_nStat:	strcpy(pItem->pszText, toString(g_NariEData.m_DisconnectorArray[nRow].nStat).c_str());	break;
			case	NariEData_YX_nOff:	strcpy(pItem->pszText, toString(g_NariEData.m_DisconnectorArray[nRow].nOff).c_str());	break;
			case	NariEData_YX_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_DisconnectorArray[nRow].bCheckOK).c_str());break;
			}
			break;

		case	NariEData_GroundDisconnector:	//	GroundDisconnector
			switch (nCol-1)
			{
			case	NariEData_YX_ID:	strcpy(pItem->pszText, g_NariEData.m_GroundDisconnectorArray[nRow].szID);						break;
			case	NariEData_YX_Sub:	strcpy(pItem->pszText, g_NariEData.m_GroundDisconnectorArray[nRow].szSub);						break;
			case	NariEData_YX_Name:	strcpy(pItem->pszText, g_NariEData.m_GroundDisconnectorArray[nRow].szName);						break;
			case	NariEData_YX_nStat:	strcpy(pItem->pszText, toString(g_NariEData.m_GroundDisconnectorArray[nRow].nStat).c_str());		break;
			case	NariEData_YX_nOff:	strcpy(pItem->pszText, toString(g_NariEData.m_GroundDisconnectorArray[nRow].nOff).c_str());		break;
			case	NariEData_YX_Check:	strcpy(pItem->pszText, toString(g_NariEData.m_GroundDisconnectorArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		case	NariEData_DivInfo:	//	DivInfo
			switch (nCol-1)
			{
			case	NariEData_DivInfo_ID:				strcpy(pItem->pszText, g_NariEData.m_DivInfoArray[nRow].szID);								break;
			case	NariEData_DivInfo_Name:				strcpy(pItem->pszText, g_NariEData.m_DivInfoArray[nRow].szName);								break;
			case	NariEData_DivInfo_GenP:				strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].fGenP).c_str());			break;
			case	NariEData_DivInfo_LoadP:			strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].fLoadP).c_str());			break;
			case	NariEData_DivInfo_TherimalP:		strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].fTherimalP).c_str());		break;
			case	NariEData_DivInfo_HydroP:			strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].fHydroP).c_str());			break;
			case	NariEData_DivInfo_WindTurbineP:		strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].fWindTurbineP).c_str());	break;
			case	NariEData_DivInfo_LoadPOff:			strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].nGenPOff).c_str());			break;
			case	NariEData_DivInfo_GenPOff:			strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].nLoadPOff).c_str());		break;
			case	NariEData_DivInfo_TherimalPOff:		strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].nTherimalPOff).c_str());	break;
			case	NariEData_DivInfo_HydroPOff:		strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].nHydroPOff).c_str());		break;
			case	NariEData_DivInfo_WindTurbinePOff:	strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].nWindTurbinePOff).c_str());	break;
			case	NariEData_DivInfo_Check:			strcpy(pItem->pszText, toString(g_NariEData.m_DivInfoArray[nRow].bCheckOK).c_str());			break;
			}
			break;

		case	NariEData_FacInfo:	//	DivInfo
			switch (nCol-1)
			{
			case	NariEData_FacInfo_ID:				strcpy(pItem->pszText, g_NariEData.m_FacInfoArray[nRow].szID);							break;
			case	NariEData_FacInfo_Name:				strcpy(pItem->pszText, g_NariEData.m_FacInfoArray[nRow].szName);						break;
			case	NariEData_FacInfo_GenP:				strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].fGenP).c_str());		break;
			case	NariEData_FacInfo_GenQ:				strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].fGenQ).c_str());		break;
			case	NariEData_FacInfo_LoadP:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].fLoadP).c_str());		break;
			case	NariEData_FacInfo_LoadQ:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].fLoadQ).c_str());		break;
			case	NariEData_FacInfo_GenPOff:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].nLoadPOff).c_str());	break;
			case	NariEData_FacInfo_GenQOff:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].nLoadQOff).c_str());	break;
			case	NariEData_FacInfo_LoadPOff:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].nGenPOff).c_str());	break;
			case	NariEData_FacInfo_LoadQOff:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].nGenQOff).c_str());	break;
			case	NariEData_FacInfo_Check:			strcpy(pItem->pszText, toString(g_NariEData.m_FacInfoArray[nRow].bCheckOK).c_str());	break;
			}
			break;

		default:
			break;
		}
	}
}
