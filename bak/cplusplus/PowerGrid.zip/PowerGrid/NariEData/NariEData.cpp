// ENariData.cpp: implementation of the CNariEData class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <Windows.h>
#include "NariEData.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CNariEData::CNariEData()
{
	Clear();
	ClearLog();
}

CNariEData::~CNariEData()
{

}

void CNariEData::Clear()
{
	memset(&m_System, 0, sizeof(tagSystem));
	m_SubstationArray.clear();
	m_BusbarSectionArray.clear();
	m_ACLineSegmentArray.clear();
	m_TransformerWindingArray.clear();
	m_SynchronousMachineArray.clear();
	m_EnergyConsumerArray.clear();
	m_ShuntCompensatorArray.clear();
	m_RectifierInverterArray.clear();
	m_BreakerArray.clear();
	m_DisconnectorArray.clear();
	m_GroundDisconnectorArray.clear();
	m_DivInfoArray.clear();
	m_FacInfoArray.clear();
}


int CNariEData::checkP(const float fVolt, const float fP)
{
	return 1;
	if (fVolt < 30)
	{
		if (fabs(fP) > 50*1.25)
			return 0;
	}
	else if (fVolt < 80)
	{
		if (fabs(fP) > 80*1.25)
			return 0;
	}
	else if (fVolt < 100)
	{
		if (fabs(fP) > 114*1.25)
			return 0;
	}
	else if (fVolt < 200)
	{
		if (fabs(fP) > 305*2)
			return 0;
	}
	else if (fVolt < 400)
	{
		if (fabs(fP) > 686*2)
			return 0;
	}
	else if (fVolt < 600)
	{
		if (fabs(fP) > 1082*2)
			return 0;
	}

	return 1;
}

int CNariEData::checkQ(const float fVolt, const float fQ)
{
	return 1;
	if (fVolt < 30)
	{
		if (fabs(fQ) > 50*1.25)
			return 0;
	}
	else if (fVolt < 80)
	{
		if (fabs(fQ) > 80*1.25)
			return 0;
	}
	else if (fVolt < 100)
	{
		if (fabs(fQ) > 114*1.25)
			return 0;
	}
	else if (fVolt < 200)
	{
		if (fabs(fQ) > 305*2)
			return 0;
	}
	else if (fVolt < 400)
	{
		if (fabs(fQ) > 686*2)
			return 0;
	}
	else if (fVolt < 600)
	{
		if (fabs(fQ) > 1082*2)
			return 0;
	}

	return 1;
}

int CNariEData::isSubExclude(const char *lpszSub)
{
	register int	i;
	for (i=0; i<(int)m_SubstationArray.size(); i++)
	{
		if (strcmp(m_SubstationArray[i].szName, lpszSub) == 0)
			return m_SubstationArray[i].bExclude;
	}

	return 1;
}

void CNariEData::clearExcludeSub(tagPGBlock* pBlock)
{
	register int	i;
	int		nSub, nVolt, nDev, nNode, nLoad, nSubI, nSubJ, bExclude;

	int		nNodeNum, nNodeArray[1000];
	std::vector<int>	nLineArray;

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (isSubExclude(pBlock->m_SubstationArray[nSub].szName))
			Log("��վ���ڼ��㷶Χ��: %s\n", pBlock->m_SubstationArray[nSub].szName);
	}

	nLineArray.clear();
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
	{
		nSubI=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ACLineSegmentArray[nDev].szSubI);
		nSubJ=PGFindRecordbyKey(pBlock, PG_SUBSTATION, pBlock->m_ACLineSegmentArray[nDev].szSubJ);

		if (isSubExclude(pBlock->m_ACLineSegmentArray[nDev].szSubI) == isSubExclude(pBlock->m_ACLineSegmentArray[nDev].szSubJ))
			continue;

		nLineArray.push_back(nDev);
	}

	for (i=0; i<(int)nLineArray.size(); i++)
	{
		Log("clearExcludeSub �ҵ������� %s(%s-%s)\n", pBlock->m_ACLineSegmentArray[nLineArray[i]].szName, pBlock->m_ACLineSegmentArray[nLineArray[i]].szSubI, pBlock->m_ACLineSegmentArray[nLineArray[i]].szSubJ);
	}

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		if (isSubExclude(pBlock->m_SubstationArray[nSub].szName))
		{
			Log("clearExcludeSub �����վ %s ����Ϣ\n", pBlock->m_SubstationArray[nSub].szName);

			for (nVolt=pBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
					pBlock->m_SynchronousMachineArray[nDev].fPlanP=pBlock->m_SynchronousMachineArray[nDev].fPlanP=0;
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
					pBlock->m_EnergyConsumerArray[nDev].fPlanP=pBlock->m_EnergyConsumerArray[nDev].fPlanP=0;
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nBreakerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nBreakerRange; nDev++)
					pBlock->m_BreakerArray[nDev].nStatus=0;
				for (nDev=pBlock->m_VoltageLevelArray[nVolt].nDisconnectorRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nDisconnectorRange; nDev++)
					pBlock->m_DisconnectorArray[nDev].nStatus=0;
			}
		}
	}

	for (nDev=0; nDev<(int)nLineArray.size(); nDev++)
	{
		bExclude=isSubExclude(pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szSubI);
		if (!bExclude)
		{
			bExclude=isSubExclude(pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szSubJ);
			if (bExclude)
				bExclude=2;
		}

		if (bExclude <= 0)
			continue;

		nVolt=-1;
		if (bExclude == 1)
		{
			nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szSubJ, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szVoltJ);
			if (fabs(pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPz) < 0.01 && fabs(pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPz) < 0.01)
				continue;
		}
		else
		{
			nVolt=PGFindRecordbyKey(pBlock, PG_VOLTAGELEVEL, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szSubI, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szVoltI);
			if (fabs(pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPi) < 0.01 && fabs(pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPi) < 0.01)
				continue;
		}
		if (nVolt < 0)
			continue;

		Log("clearExcludeSub ת����·%s(%s-%s)\n", pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szName, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szSubI, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].szSubJ);

		if (bExclude == 2)
		{
			PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].nNodeI, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
			for (nLoad=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nLoad<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nLoad++)
			{
				for (i=0; i<nNodeNum; i++)
				{
					if (pBlock->m_EnergyConsumerArray[nLoad].nNode == nNodeArray[i])
					{
						Log("        ��(%s-%s-%s)����(%.1f %.1f)\n", 
							pBlock->m_EnergyConsumerArray[nLoad].szSub, 
							pBlock->m_EnergyConsumerArray[nLoad].szVolt, 
							pBlock->m_EnergyConsumerArray[nLoad].szName, 
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPi, 
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQi);

						if (pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPi > -9998)
						{
							pBlock->m_EnergyConsumerArray[nLoad].fPlanP += pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPi;
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPi=0;
						}
						if (pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQi > -9998)
						{
							pBlock->m_EnergyConsumerArray[nLoad].fPlanQ += pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQi;
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQi=0;
						}

						goto OUTI;
					}
				}
			}
OUTI:		;
		}
		else
		{
			PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].nNodeJ, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
			for (nLoad=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nLoad<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nLoad++)
			{

				for (i=0; i<nNodeNum; i++)
				{
					if (pBlock->m_EnergyConsumerArray[nLoad].nNode == nNodeArray[i])
					{
						Log("        ��(%s-%s-%s)����(%.1f %.1f)\n", 
							pBlock->m_EnergyConsumerArray[nLoad].szSub, 
							pBlock->m_EnergyConsumerArray[nLoad].szVolt, 
							pBlock->m_EnergyConsumerArray[nLoad].szName, 
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPz, 
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQz);

						if (pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPz > -9998)
						{
							pBlock->m_EnergyConsumerArray[nLoad].fP += pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPz;
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fPz=0;
						}
						if (pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQz > -9998)
						{
							pBlock->m_EnergyConsumerArray[nLoad].fQ += pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQz;
							pBlock->m_ACLineSegmentArray[nLineArray[nDev]].fQz=0;
						}

						goto OUTJ;
					}
				}
			}
OUTJ:		;
		}
	}

	for (nDev=0; nDev<(int)nLineArray.size(); nDev++)
	{
		PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].nNodeI, Y_CheckStatus, Y_CheckStatus, N_BusBound, Y_BreakerBound, nNodeNum, nNodeArray);
		for (nNode=0; nNode<nNodeNum; nNode++)
		{
			for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBreakerRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nBreakerRange; i++)
				pBlock->m_DisconnectorArray[pBlock->m_EdgeBreakerArray[i].nBreaker].nStatus=1;
		}
		PGTraverseVolt(pBlock, pBlock->m_ACLineSegmentArray[nLineArray[nDev]].nNodeJ, Y_CheckStatus, Y_CheckStatus, N_BusBound, Y_BreakerBound, nNodeNum, nNodeArray);
		for (nNode=0; nNode<nNodeNum; nNode++)
		{
			for (i=pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nBreakerRange; i<pBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nBreakerRange; i++)
				pBlock->m_DisconnectorArray[pBlock->m_EdgeBreakerArray[i].nBreaker].nStatus=1;
		}
	}
}

void CNariEData::checkObserve(tagPGBlock* pBlock)
{
	int		nDev, nData, bExist;
	char	szDevName[260];

	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
	{
		bExist=0;
		for (nData=0; nData<(int)m_SynchronousMachineArray.size(); nData++)
		{
			if (strcmp(pBlock->m_SynchronousMachineArray[nDev].szSub, m_SynchronousMachineArray[nData].szSub) == 0 &&
				strcmp(pBlock->m_SynchronousMachineArray[nDev].szName, m_SynchronousMachineArray[nData].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			Log("�������%s.%s.%s��û��ʵ������\n", pBlock->m_SynchronousMachineArray[nDev].szSub, pBlock->m_SynchronousMachineArray[nDev].szVolt, pBlock->m_SynchronousMachineArray[nDev].szName);
		}
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
	{
		bExist=0;
		for (nData=0; nData<(int)m_EnergyConsumerArray.size(); nData++)
		{
			if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szSub, m_EnergyConsumerArray[nData].szSub) == 0 &&
				strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, m_EnergyConsumerArray[nData].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			for (nData=0; nData<(int)m_ACLineSegmentArray.size(); nData++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szSub, m_ACLineSegmentArray[nData].szSub) == 0 &&
					strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, m_ACLineSegmentArray[nData].szName) == 0)
				{
					bExist=1;
					break;
				}
			}
		}
		if (!bExist)
		{
			for (nData=0; nData<(int)m_TransformerWindingArray.size(); nData++)
			{
				sprintf(szDevName, "��Ч%s����", m_TransformerWindingArray[nData].szName);
				if (strcmp(pBlock->m_EnergyConsumerArray[nDev].szSub, m_TransformerWindingArray[nData].szSub) == 0 &&
					strcmp(pBlock->m_EnergyConsumerArray[nDev].szName, szDevName) == 0)
				{
					bExist=1;
					break;
				}
			}
		}
		if (!bExist)
			Log("���ɣ�%s.%s.%s��û��ʵ������\n", pBlock->m_EnergyConsumerArray[nDev].szSub, pBlock->m_EnergyConsumerArray[nDev].szVolt, pBlock->m_EnergyConsumerArray[nDev].szName);
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; nDev++)
	{
		bExist=0;
		for (nData=0; nData<(int)m_ShuntCompensatorArray.size(); nData++)
		{
			if (strcmp(pBlock->m_ShuntCompensatorArray[nDev].szSub, m_ShuntCompensatorArray[nData].szSub) == 0 &&
				strcmp(pBlock->m_ShuntCompensatorArray[nDev].szName, m_ShuntCompensatorArray[nData].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			Log("������%s.%s.%s��û��ʵ������\n", pBlock->m_ShuntCompensatorArray[nDev].szSub, pBlock->m_ShuntCompensatorArray[nDev].szVolt, pBlock->m_ShuntCompensatorArray[nDev].szName);
		}
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_BREAKER]; nDev++)
	{
		bExist=0;
		for (nData=0; nData<(int)m_BreakerArray.size(); nData++)
		{
			if (strcmp(pBlock->m_BreakerArray[nDev].szSub, m_BreakerArray[nData].szSub) == 0 &&
				strcmp(pBlock->m_BreakerArray[nDev].szName, m_BreakerArray[nData].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			Log("���أ�%s.%s.%s��û��ʵ������\n", pBlock->m_BreakerArray[nDev].szSub, pBlock->m_BreakerArray[nDev].szVolt, pBlock->m_BreakerArray[nDev].szName);
		}
	}
	for (nDev=0; nDev<pBlock->m_nRecordNum[PG_DISCONNECTOR]; nDev++)
	{
		bExist=0;
		for (nData=0; nData<(int)m_DisconnectorArray.size(); nData++)
		{
			if (strcmp(pBlock->m_DisconnectorArray[nDev].szSub, m_DisconnectorArray[nData].szSub) == 0 &&
				strcmp(pBlock->m_DisconnectorArray[nDev].szName, m_DisconnectorArray[nData].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			Log("���أ�%s.%s.%s��û��ʵ������\n", pBlock->m_DisconnectorArray[nDev].szSub, pBlock->m_DisconnectorArray[nDev].szVolt, pBlock->m_DisconnectorArray[nDev].szName);
		}
	}
}

void CNariEData::Log(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szTempPath[260], szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260, szTempPath);
#else
	strcpy(szTempPath, "/tmp");
#endif

	sprintf(szFileName, "%s/NariEData.log", szTempPath);
	fp=fopen(szFileName, "a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}

void CNariEData::ClearLog()
{
#ifdef	_DEBUG
	char	szTempPath[260], szFileName[260];

	GetTempPath(260, szTempPath);

	sprintf(szFileName, "%s/NariEData.log", szTempPath);
	unlink(szFileName);
#endif
}

int CNariEData::GetPGTranPQ(tagPGBlock* pBlock, const int bLowToMid, const char* lpszPGWindName, const int nSide, float& fTranP, float& fTranQ)
{
	int		nWind, nTran;
	char	szBuf[260];
	float	fP, fQ;
	unsigned char	bMeasured=1;
	char	szKeyValueArray[g_nConstMaxPrimaryKey][MDB_CHARLEN_LONG];
	char*	lpszToken;

	strcpy(szBuf, lpszPGWindName);

	nWind=0;
	lpszToken=strtok(szBuf, ", ");
	while (lpszToken != NULL)
	{
		strcpy(szKeyValueArray[nWind++], lpszToken);
		lpszToken=strtok(NULL, ", ");
	}

	fTranP=fTranQ=0;

	nWind=PGFindRecordbyKey(pBlock, PG_TRANSFORMERWINDING, szKeyValueArray);
	if (nWind < 0)
		return 0;

	nTran=pBlock->m_TransformerWindingArray[nWind].nTran;
	if (nTran < 0)
		return 0;

	if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 3)
	{
		int	nMidNode=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI ||
			pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeJ) ?
			pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

		if (pBlock->m_PowerTransformerArray[nTran].nWindH == nWind)
		{
			fTranP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPi;
			fTranQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQi;
			if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
			{
				fTranP=fTranQ=0;
				bMeasured=0;
			}
		}
		else if (pBlock->m_PowerTransformerArray[nTran].nWindM == nWind)
		{
			if (bLowToMid)
			{
				bMeasured=2;
				fP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPi;
				fQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQi;
				if (fabs(fP) > 999990 || fabs(fQ) > 999990)
				{
					fP=fQ=0;
					bMeasured--;
					//bMeasured=0;
				}
				fTranP += fP;
				fTranQ += fQ;

				fP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPi;
				fQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQi;
				if (fabs(fP) > 999990 || fabs(fQ) > 999990)
				{
					fP=fQ=0;
					bMeasured--;
					//bMeasured=0;
				}

				fTranP += fP;
				fTranQ += fQ;
				if (bMeasured > 0)
					bMeasured=1;
			}
			else
			{
				fTranP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fPi;
				fTranQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].fQi;
				if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
				{
					fTranP=fTranQ=0;
					bMeasured=0;
				}
			}
		}
		else if (pBlock->m_PowerTransformerArray[nTran].nWindL == nWind)
		{
			if (!bLowToMid)
			{
				fTranP =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fPi;
				fTranQ =(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].nNodeI == nMidNode)  ? -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQz : -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindL].fQi;
				if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
				{
					fTranP=fTranQ=0;
					bMeasured=0;
				}
			}
		}
	}
	else
	{
		if (nSide == 0)
		{
			fTranP = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPi;
			fTranQ = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQi;
			if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
			{
				fTranP=fTranQ=0;
				bMeasured=0;
			}
		}
		else
		{
			fTranP = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fPz;
			fTranQ = -pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].fQz;
			if (fabs(fTranP) > 999990 || fabs(fTranQ) > 999990)
			{
				fTranP=fTranQ=0;
				bMeasured=0;
			}
		}
	}
	return bMeasured;
}

int CNariEData::GetPGLinePQ(tagPGBlock* pBlock, const int bLowToMid, const char* lpszPGLineName, const char* lpszPGSubName, float& fLineP, float& fLineQ)
{
	int		nLine;
	unsigned char	bMeasured=1;

	fLineP=fLineQ=0;

	nLine=PGFindRecordbyKey(pBlock, PG_ACLINESEGMENT, lpszPGLineName);
	if (nLine < 0)
		return 0;

	if (strcmp(pBlock->m_ACLineSegmentArray[nLine].szSubI, lpszPGSubName) == 0)
	{
		fLineP = pBlock->m_ACLineSegmentArray[nLine].fPi;
		fLineQ = pBlock->m_ACLineSegmentArray[nLine].fQi;
		if (fabs(fLineP) > 999990 || fabs(fLineQ) > 999990)
		{
			fLineP = 0;
			fLineQ = 0;
			bMeasured=0;
		}
	}
	else
	{
		fLineP = pBlock->m_ACLineSegmentArray[nLine].fPz;
		fLineQ = pBlock->m_ACLineSegmentArray[nLine].fQz;
		if (fabs(fLineP) > 999990 || fabs(fLineQ) > 999990)
		{
			fLineP = 0;
			fLineQ = 0;
			bMeasured=0;
		}
	}
	return bMeasured;
}
