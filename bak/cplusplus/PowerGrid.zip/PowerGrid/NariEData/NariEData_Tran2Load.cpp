#include "stdafx.h"
#include "NariEData.h"

unsigned char	CNariEData::IsNodeJointGenerator(tagPGBlock* pBlock, const int nStartNode)
{
	register int	i;
	int		nVolt, nDev;
	unsigned char	bHasGenerator;
	int		nNodeNum, nNodeArray[1000];

	nVolt=pBlock->m_ConnectivityNodeArray[nStartNode].nVoltageLevelPtr;
	if (nVolt < 0)
		return 0;

	PGTraverseVolt(pBlock, nStartNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);

	bHasGenerator=0;
	for (nDev=pBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
	{
		for (i=0; i<nNodeNum; i++)
		{
			if (nNodeArray[i] == pBlock->m_SynchronousMachineArray[nDev].nNode)
			{
				return 1;
			}
		}
	}

	return 0;
}

void	CNariEData::TraverseJointLoad(tagPGBlock* pBlock, const int nStartNode, std::vector<int>& nLoadArray)
{
	register int	i;
	int		nVolt, nDev;
	int		nNodeNum, nNodeArray[1000];

	nLoadArray.clear();
	nVolt=pBlock->m_ConnectivityNodeArray[nStartNode].nVoltageLevelPtr;
	if (nVolt < 0)
		return;

	PGTraverseVolt(pBlock, nStartNode, Y_CheckStatus, Y_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
	for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
	{
		for (i=0; i<nNodeNum; i++)
		{
			if (nNodeArray[i] == pBlock->m_EnergyConsumerArray[nDev].nNode)
			{
				nLoadArray.push_back(nDev);
				break;
			}
		}
	}
	if (nLoadArray.empty())
	{
		PGTraverseVolt(pBlock, nStartNode, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
		for (nDev=pBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nDev<pBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nDev++)
		{
			for (i=0; i<nNodeNum; i++)
			{
				if (nNodeArray[i] == pBlock->m_EnergyConsumerArray[nDev].nNode)
				{
					nLoadArray.push_back(nDev);
					break;
				}
			}
		}
	}
}

void	CNariEData::Tran2Load(tagPGBlock* pBlock)
{
	int		nSub, nVolt, nTran, nWind, nTranNode, nTranMid;
	float	fTranP, fTranQ;
	unsigned char	bMeasuredH, bMeasuredM, bMeasuredL;
	std::vector<int>	nLoadArray;

	for (nSub=0; nSub<pBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nTran=pBlock->m_SubstationArray[nSub].nPowerTransformerRange; nTran<pBlock->m_SubstationArray[nSub+1].nPowerTransformerRange; nTran++)
		{
			Log("Tran2Load ��ѹ������ %s %s\n", pBlock->m_PowerTransformerArray[nTran].szSub, pBlock->m_PowerTransformerArray[nTran].szName);

			if (pBlock->m_PowerTransformerArray[nTran].nWindNum == 1)
			{
				nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
				nTranNode=(pBlock->m_TransformerWindingArray[nWind].fRatedkVI > pBlock->m_TransformerWindingArray[nWind].fRatedkVJ) ?
					pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
				nVolt=pBlock->m_ConnectivityNodeArray[nTranNode].nVoltageLevelPtr;
				if (nVolt >= 0)
				{
					if (!IsNodeJointGenerator(pBlock, nTranNode))
					{
						bMeasuredL=0;
						if (pBlock->m_TransformerWindingArray[nWind].fRatedkVI > pBlock->m_TransformerWindingArray[nWind].fRatedkVJ)
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPi) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQi) < 999990)
							{
								fTranP=-pBlock->m_TransformerWindingArray[nWind].fPi;
								fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQi;
								bMeasuredL=1;
							}
							else if (fabs(pBlock->m_TransformerWindingArray[nWind].fPz) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQz) < 999990)
							{
								fTranP=pBlock->m_TransformerWindingArray[nWind].fPz;
								fTranQ=pBlock->m_TransformerWindingArray[nWind].fQz;
								bMeasuredL=1;
							}
						}
						else
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPz) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQz) < 999990)
							{
								fTranP=-pBlock->m_TransformerWindingArray[nWind].fPz;
								fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQz;
								bMeasuredL=1;
							}
							else if (fabs(pBlock->m_TransformerWindingArray[nWind].fPi) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQi) < 999990)
							{
								fTranP=-pBlock->m_TransformerWindingArray[nWind].fPi;
								fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQi;
								bMeasuredL=1;
							}
						}

						if (bMeasuredL)
						{
							TraverseJointLoad(pBlock, nTranNode, nLoadArray);
							if (!nLoadArray.empty())
							{
								Log("        ���ø���[%s %s %s] %.2f %.2f\n", 
									pBlock->m_EnergyConsumerArray[nLoadArray[0]].szSub, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szVolt, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szName, fTranP/nLoadArray.size(), fTranQ/nLoadArray.size());
								pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanP += fTranP/nLoadArray.size();
								pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanQ += fTranQ/nLoadArray.size();
							}
							else
							{
								Log("        û�����Ӹ���\n");
							}
						}
						else
						{
							Log("        û������\n");
						}
					}
					else
					{
						Log("        ���ӷ����\n");
					}
				}
			}
			else
			{
				nTranMid=(pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeI ||
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI == pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindM].nNodeJ) ?
					pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeI : pBlock->m_TransformerWindingArray[pBlock->m_PowerTransformerArray[nTran].nWindH].nNodeJ;

				bMeasuredH=bMeasuredM=bMeasuredL=0;

				nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
				nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
				nVolt=pBlock->m_ConnectivityNodeArray[nTranNode].nVoltageLevelPtr;
				if (nVolt >= 0)
				{
					if (!IsNodeJointGenerator(pBlock, nTranNode))
					{
						if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid)
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPz) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQz) < 999990)
								bMeasuredH=1;
						}
						else
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPi) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQi) < 999990)
								bMeasuredH=1;
						}
					}
					else
					{
						Log("        ���ӷ����\n");
					}
				}

				nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
				nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
				nVolt=pBlock->m_ConnectivityNodeArray[nTranNode].nVoltageLevelPtr;
				if (nVolt >= 0)
				{
					if (!IsNodeJointGenerator(pBlock, nTranNode))
					{
						if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid)
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPz) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQz) < 999990)
								bMeasuredM=1;
						}
						else
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPi) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQi) < 999990)
								bMeasuredM=1;
						}
					}
					else
					{
						Log("        ���ӷ����\n");
					}
				}

				nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
				nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
				nVolt=pBlock->m_ConnectivityNodeArray[nTranNode].nVoltageLevelPtr;
				if (nVolt >= 0)
				{
					Log("Tran2Load ��ѹ������ %s %s\n", pBlock->m_TransformerWindingArray[nWind].szSub, pBlock->m_ConnectivityNodeArray[nTranNode].szVolt, pBlock->m_TransformerWindingArray[nWind].szName);
					if (!IsNodeJointGenerator(pBlock, nTranNode))
					{
						if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid)
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPz) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQz) < 999990)
								bMeasuredL=1;
						}
						else
						{
							if (fabs(pBlock->m_TransformerWindingArray[nWind].fPi) < 999990 && fabs(pBlock->m_TransformerWindingArray[nWind].fQi) < 999990)
								bMeasuredL=1;
						}
					}
					else
					{
						Log("        ���ӷ����\n");
					}
				}

				if (bMeasuredM && bMeasuredL)
				{
					nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
					nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
					if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid)
					{
						fTranP=-pBlock->m_TransformerWindingArray[nWind].fPz;
						fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQz;
					}
					else
					{
						fTranP=-pBlock->m_TransformerWindingArray[nWind].fPi;
						fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQi;
					}
					TraverseJointLoad(pBlock, nTranNode, nLoadArray);
					if (!nLoadArray.empty())
					{
						Log("        ���ø���[%s %s %s] %.2f %.2f\n", 
							pBlock->m_EnergyConsumerArray[nLoadArray[0]].szSub, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szVolt, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szName, fTranP/nLoadArray.size(), fTranQ/nLoadArray.size());
						pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanP += fTranP/nLoadArray.size();
						pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanQ += fTranQ/nLoadArray.size();
// 						for (i=0; i<(int)nLoadArray.size(); i++)
// 						{
// 						}
					}
					else
					{
						Log("        û�����Ӹ���\n");
					}

					nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
					nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
					if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid)
					{
						fTranP=-pBlock->m_TransformerWindingArray[nWind].fPz;
						fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQz;
					}
					else
					{
						fTranP=-pBlock->m_TransformerWindingArray[nWind].fPi;
						fTranQ=-pBlock->m_TransformerWindingArray[nWind].fQi;
					}
					TraverseJointLoad(pBlock, nTranNode, nLoadArray);
					if (!nLoadArray.empty())
					{
						Log("        ���ø���[%s %s %s] %.2f %.2f\n", 
							pBlock->m_EnergyConsumerArray[nLoadArray[0]].szSub, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szVolt, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szName, fTranP/nLoadArray.size(), fTranQ/nLoadArray.size());
						pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanP += fTranP/nLoadArray.size();
						pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanQ += fTranQ/nLoadArray.size();
// 						for (i=0; i<(int)nLoadArray.size(); i++)
// 						{
// 						}
					}
					else
					{
						Log("        û�����Ӹ���\n");
					}
				}
				else if (bMeasuredH)
				{
					nWind=pBlock->m_PowerTransformerArray[nTran].nWindH;
					if (pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid)
					{
						fTranP=pBlock->m_TransformerWindingArray[nWind].fPz;
						fTranQ=pBlock->m_TransformerWindingArray[nWind].fQz;
					}
					else
					{
						fTranP=pBlock->m_TransformerWindingArray[nWind].fPi;
						fTranQ=pBlock->m_TransformerWindingArray[nWind].fQi;
					}

					nWind=pBlock->m_PowerTransformerArray[nTran].nWindM;
					nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
					TraverseJointLoad(pBlock, nTranNode, nLoadArray);
					if (nLoadArray.empty())
					{
						nWind=pBlock->m_PowerTransformerArray[nTran].nWindL;
						nTranNode=(pBlock->m_TransformerWindingArray[nWind].nNodeI == nTranMid) ? pBlock->m_TransformerWindingArray[nWind].nNodeJ : pBlock->m_TransformerWindingArray[nWind].nNodeI;
						TraverseJointLoad(pBlock, nTranNode, nLoadArray);
					}
					if (!nLoadArray.empty())
					{
						Log("        ���ø���[%s %s %s] %.2f %.2f\n", 
							pBlock->m_EnergyConsumerArray[nLoadArray[0]].szSub, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szVolt, pBlock->m_EnergyConsumerArray[nLoadArray[0]].szName, fTranP/nLoadArray.size(), fTranQ/nLoadArray.size());
						pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanP += fTranP/nLoadArray.size();
						pBlock->m_EnergyConsumerArray[nLoadArray[0]].fPlanQ += fTranQ/nLoadArray.size();
// 						for (i=0; i<(int)nLoadArray.size(); i++)
// 						{
// 						}
					}
					else
					{
						Log("        û�����Ӹ���\n");
					}
				}
				else
				{
					Log("        û������\n");
				}
			}
		}
	}
}