#pragma	once

#include "NariEDataDefine.h"

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

static	char*	g_lpszSystemAttrArray[]=
{
	"Area",
	"System",
	"Time",
};

static	char*	g_lpszSubstationAttrArray[]=
{
	"Name",
	"Exclude",
};

static	char*	g_lpszBusbarSectionAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"V",
	"D",
	"VOff",
	"DOff",
	"Check",
};

static	char*	g_lpszAClineSegmentAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"P",
	"Q",
	"I",
	"POff",
	"QOff",
	"IOff",
	"Check",
};

static	char*	g_lpszTransformerWindingAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"P",
	"Q",
	"Tap",
	"POff",
	"QOff",
	"TapOff",
	"Check",
};

static	char*	g_lpszSynchronousMachineAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"P",
	"Q",
	"I",
	"POff",
	"QOff",
	"IOff",
	"Check",
};

static	char*	g_lpszEnergyConsumerAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"P",
	"Q",
	"POff",
	"QOff",
	"Check",
};

static	char*	g_lpszShuntCompensatorAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"Q",
	"QOff",
	"Check",
};

static	char*	g_lpszRectifierInverterAttrArray[]=
{
	"ID",
	"Sub",
	"DCBus",
	"P",
	"Q",
	"Tap",
	"V",
	"D",
	"POff",
	"QOff",
	"TapOff",
	"VOff",
	"DOff",
	"Check",
};

static	char*	g_lpszYXAttrArray[]=
{
	"ID",
	"Sub",
	"Name",
	"nStat",
	"nOff",
	"Check",
};

static	char*	g_lpszDivInfoAttrArray[]=
{
	"ID",
	"Name",
	"GenP",
	"LoadP",
	"TherimalP",
	"HydroP",
	"WindTurbineP",
	"GenPOff",
	"LoadPOff",
	"TherimalPOff",
	"HydroPOff",
	"WindTurbinePOff",
};

static	char*	g_lpszFacInfoAttrArray[]=
{
	"ID",
	"Name",
	"GenP",
	"GenQ",
	"GenPOff",
	"GenQOff",
	"LoadP",
	"LoadQ",
	"LoadPOff",
	"LoadQOff",
};

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(power)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
