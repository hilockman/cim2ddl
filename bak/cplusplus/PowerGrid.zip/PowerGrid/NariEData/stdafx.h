#pragma once

#include "../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif
using namespace PGMemDB;

#include "NariEData.h"
