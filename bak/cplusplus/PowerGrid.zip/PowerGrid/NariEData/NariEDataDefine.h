#pragma	once

#if defined(__GNUG__) || defined(__GNUC__)	// GCC������Ԥ����ĺ�
#	ifndef DISALIGN
#		define DISALIGN __attribute__((packed))
#	endif
#else
#	define DISALIGN
#	if (defined(_AIX) || defined(AIX))
#		pragma align(packed)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(push)
#		endif
#	endif
#	pragma pack(1)
#endif

#define	NARICHARLEN	100

typedef	struct _NameDesp_
{
	int		nID;
	char	szName[100];
	char	szDesp[100];
}	tagNameDesp;

enum	_ENum_NariEData_Table_
{
	NariEData_System=0,
	NariEData_Substation,
	NariEData_Breaker,
	NariEData_Disconnector,
	NariEData_GroundDisconnector,
	NariEData_BusbarSection,
	NariEData_ACLineSegment,
	NariEData_SynchronousMachine,
	NariEData_TransformerWinding,
	NariEData_EnergyConsumer,
	NariEData_ShuntCompensator,
	NariEData_SeriesCompensator,
	NariEData_DClineSegment,
	NariEData_RectifierInverter,
	NariEData_DivInfo,
	NariEData_FacInfo,
};

enum	_ENum_NariEData_System_
{
	NariEData_System_Area=0,
	NariEData_System_System,
	NariEData_System_Time,
};
struct	_NariSystem
{
	char	szArea[NARICHARLEN];
	char	szSystem[NARICHARLEN];
	char	szTime[NARICHARLEN];
}	DISALIGN;
typedef	struct	_NariSystem	tagSystem;

enum	_ENum_NariEData_Substation_
{
	NariEData_Substation_Name=0,
	NariEData_Substation_Exclude,
};
struct	_NariSubstation
{
	char	szName[NARICHARLEN];
	unsigned char	bExclude;
}	DISALIGN;
typedef	struct	_NariSubstation	tagSubstation;

enum	_ENum_NariEData_BusbarSection_
{
	NariEData_BusbarSection_ID=0,
	NariEData_BusbarSection_Sub,
	NariEData_BusbarSection_Name,
	NariEData_BusbarSection_V,
	NariEData_BusbarSection_D,
	NariEData_BusbarSection_VOff,
	NariEData_BusbarSection_DOff,
	NariEData_BusbarSection_Check,
};
struct	_NariBusbarSection
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fV;
	float	fD;
	unsigned char	nVOff;
	unsigned char	nDOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariBusbarSection	tagBusbarSection;

enum	_ENum_NariEData_AClineSegment_
{
	NariEData_AClineSegment_ID=0,
	NariEData_AClineSegment_Sub,
	NariEData_AClineSegment_Name,
	NariEData_AClineSegment_P,
	NariEData_AClineSegment_Q,
	NariEData_AClineSegment_I,
	NariEData_AClineSegment_POff,
	NariEData_AClineSegment_QOff,
	NariEData_AClineSegment_IOff,
	NariEData_AClineSegment_Check,
};
struct	_NariAClineSegment
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fP;
	float	fQ;
	float	fI;
	unsigned char	nPOff;
	unsigned char	nQOff;
	unsigned char	nIOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariAClineSegment	tagAClineSegment;

enum	_ENum_NariEData_TransformerWinding_
{
	NariEData_TransformerWinding_ID=0,
	NariEData_TransformerWinding_Sub,
	NariEData_TransformerWinding_Name,
	NariEData_TransformerWinding_P,
	NariEData_TransformerWinding_Q,
	NariEData_TransformerWinding_Tap,
	NariEData_TransformerWinding_POff,
	NariEData_TransformerWinding_QOff,
	NariEData_TransformerWinding_TapOff,
	NariEData_TransformerWinding_Check,
};
struct	_NariTransformerWinding
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fP;
	float	fQ;
	int		nTap;

	unsigned char	nPOff;
	unsigned char	nQOff;
	unsigned char	nTapOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariTransformerWinding	tagTransformerWinding;

enum	_ENum_NariEData_SynchronousMachine_
{
	NariEData_SynchronousMachine_ID=0,
	NariEData_SynchronousMachine_Sub,
	NariEData_SynchronousMachine_Name,
	NariEData_SynchronousMachine_P,
	NariEData_SynchronousMachine_Q,
	NariEData_SynchronousMachine_I,
	NariEData_SynchronousMachine_POff,
	NariEData_SynchronousMachine_QOff,
	NariEData_SynchronousMachine_IOff,
	NariEData_SynchronousMachine_Check,
};
struct	_NariSynchronousMachine
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fP;
	float	fQ;
	float	fV;
	unsigned char	nPOff;
	unsigned char	nQOff;
	unsigned char	nVOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariSynchronousMachine	tagSynchronousMachine;

enum	_ENum_NariEData_EnergyConsumer_
{
	NariEData_EnergyConsumer_ID=0,
	NariEData_EnergyConsumer_Sub,
	NariEData_EnergyConsumer_Name,
	NariEData_EnergyConsumer_P,
	NariEData_EnergyConsumer_Q,
	NariEData_EnergyConsumer_POff,
	NariEData_EnergyConsumer_QOff,
	NariEData_EnergyConsumer_Check,
};
struct	_NariEnergyConsumer
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fP;
	float	fQ;
	unsigned char	nPOff;
	unsigned char	nQOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariEnergyConsumer	tagEnergyConsumer;

enum	_ENum_NariEData_ShuntCompensator_
{
	NariEData_ShuntCompensator_ID=0,
	NariEData_ShuntCompensator_Sub,
	NariEData_ShuntCompensator_Name,
	NariEData_ShuntCompensator_Q,
	NariEData_ShuntCompensator_QOff,
	NariEData_ShuntCompensator_Check,
};
struct	_NariShuntCompensator
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fQ;
	unsigned char	nQOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariShuntCompensator	tagShuntCompensator;

enum	_ENum_NariEData_RectifierInverter_
{
	NariEData_RectifierInverter_ID=0,
	NariEData_RectifierInverter_Sub,
	NariEData_RectifierInverter_DCBus,
	NariEData_RectifierInverter_P,
	NariEData_RectifierInverter_Q,
	NariEData_RectifierInverter_Tap,
	NariEData_RectifierInverter_V,
	NariEData_RectifierInverter_D,
	NariEData_RectifierInverter_POff,
	NariEData_RectifierInverter_QOff,
	NariEData_RectifierInverter_TapOff,
	NariEData_RectifierInverter_VOff,
	NariEData_RectifierInverter_DOff,
	NariEData_RectifierInverter_Check,
};
struct	_NariRectifierInverter
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fP;
	float	fQ;
	int		nTap;
	float	fV;
	float	fD;
	unsigned char	nPOff;
	unsigned char	nQOff;
	unsigned char	nTapOff;
	unsigned char	nVOff;
	unsigned char	nDOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariRectifierInverter	tagRectifierInverter;

enum	_ENum_NariEData_YX_
{
	NariEData_YX_ID=0,
	NariEData_YX_Sub,
	NariEData_YX_Name,
	NariEData_YX_nStat,
	NariEData_YX_nOff,
	NariEData_YX_Check,
};
struct	_NariYX
{
	char	szID[NARICHARLEN];
	char	szSub[NARICHARLEN];
	char	szName[NARICHARLEN];
	unsigned char	nStat;
	unsigned char	nOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariYX	tagYX;

enum	_ENum_NariEData_DivInfo_
{
	NariEData_DivInfo_ID=0,
	NariEData_DivInfo_Name,
	NariEData_DivInfo_GenP,
	NariEData_DivInfo_LoadP,
	NariEData_DivInfo_TherimalP,
	NariEData_DivInfo_HydroP,
	NariEData_DivInfo_WindTurbineP,
	NariEData_DivInfo_GenPOff,
	NariEData_DivInfo_LoadPOff,
	NariEData_DivInfo_TherimalPOff,
	NariEData_DivInfo_HydroPOff,
	NariEData_DivInfo_WindTurbinePOff,
	NariEData_DivInfo_Check,
};
struct	_NariDivInfo
{
	char	szID[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fGenP;
	float	fLoadP;
	float	fTherimalP;
	float	fHydroP;
	float	fWindTurbineP;
	unsigned char	nGenPOff;
	unsigned char	nLoadPOff;
	unsigned char	nTherimalPOff;
	unsigned char	nHydroPOff;
	unsigned char	nWindTurbinePOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariDivInfo	tagDivInfo;

enum	_ENum_NariEData_FacInfo_
{
	NariEData_FacInfo_ID=0,
	NariEData_FacInfo_Name,
	NariEData_FacInfo_GenP,
	NariEData_FacInfo_GenQ,
	NariEData_FacInfo_GenPOff,
	NariEData_FacInfo_GenQOff,
	NariEData_FacInfo_LoadP,
	NariEData_FacInfo_LoadQ,
	NariEData_FacInfo_LoadPOff,
	NariEData_FacInfo_LoadQOff,
	NariEData_FacInfo_Check,
};
struct	_NariFacInfo
{
	char	szID[NARICHARLEN];
	char	szName[NARICHARLEN];
	float	fGenP;
	float	fGenQ;
	float	fLoadP;
	float	fLoadQ;
	unsigned char	nGenPOff;
	unsigned char	nGenQOff;
	unsigned char	nLoadPOff;
	unsigned char	nLoadQOff;
	unsigned char	bCheckOK;
}	DISALIGN;
typedef	struct	_NariFacInfo	tagFacInfo;

#if !defined(__GNUG__) && !defined(__GNUC__)
#	pragma pack()
#	if (defined(_AIX) || defined(AIX))
#		pragma align(power)
#	else
#		if (!defined(sun) && !defined(__sun) && !defined(__sun__))
#			pragma pack(pop)
#		endif
#	endif
#endif
