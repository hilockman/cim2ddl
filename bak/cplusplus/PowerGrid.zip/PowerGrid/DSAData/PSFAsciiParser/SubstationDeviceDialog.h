#pragma once


// CSubstationDeviceDialog �Ի���

class CSubstationDeviceDialog : public CDialog
{
	DECLARE_DYNAMIC(CSubstationDeviceDialog)

public:
	CSubstationDeviceDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSubstationDeviceDialog();
	void	Refresh();

// �Ի�������
	enum { IDD = IDD_SUBSTATION_DEVICE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedRefresh();
	afx_msg void OnCbnSelchangeOfflinesubstationCombo();
	afx_msg void OnCbnSelchangeRtsubstationCombo();
	DECLARE_MESSAGE_MAP()
private:
	void RefreshOffLineList();
	void RefreshRTLineList();
	void RefreshOffGeneratorList();
	void RefreshRTGeneratorList();
private:
	std::string	m_strOffSubstation;
	std::string	m_strRTSubstation;
public:
	BOOL m_bShowOffNoMatch;
	BOOL m_bShowRTNoMatch;
	afx_msg void OnBnClickedOffsubNomatch();
	afx_msg void OnBnClickedRtsubNomatch();
};
