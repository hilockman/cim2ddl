
// PG2PSFAsciiDlg.h : ͷ�ļ�
//

#pragma once
#include "PGBoundNetDialog.h"
#include "PSFBoundNetDialog.h"


// CPG2PSFAsciiDlg �Ի���
class CPG2PSFAsciiDlg : public CDialog
{
// ����
public:
	CPG2PSFAsciiDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PG2PSFASCII_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedRefresh();
	afx_msg void OnBnClickedLoadBoundline();
	afx_msg void OnBnClickedSaveBoundline();
	afx_msg void OnNMClickPSFLineList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickPGLineList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickBoundlineList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCbnSelchangePGSubstationFilterCombo();
	afx_msg void OnCbnSelchangePGVoltagelevelFilterCombo();
	afx_msg void OnCbnSelchangePSFSubstationFilterCombo();
	afx_msg void OnCbnSelchangePSFVoltagelevelFilterCombo();
	afx_msg void OnBnClickedPGBoundNet();
	afx_msg void OnBnClickedPSFBoundNet();
	afx_msg void OnBnClickedPSFAddButton();
	afx_msg void OnBnClickedPGAddButton();
	afx_msg void OnBnClickedPSFDelButton();
	afx_msg void OnBnClickedPGDelButton();
	afx_msg void OnCbnSelchangePGDeviceTypeCombo();
	afx_msg void OnBnClickedClearMesg();
	afx_msg void OnBnClickedLoadPsfmatch();
	afx_msg void OnBnClickedSetWorkzone();
	afx_msg void OnBnClickedPgsubstationShortname();
	afx_msg void OnBnClickedLoadPGShortName();
	afx_msg void OnBnClickedFormPsfascii();
	DECLARE_MESSAGE_MAP()
private:
	int					m_nCurBoundLine,m_nCurPSFLine,m_nCurPGDevice;

private:
	std::string	m_strFilterPSFSubstation,m_strFilterPSFVoltageLevel;
	std::string	m_strFilterPGSubstation,m_strFilterPGVoltageLevel;

private:
	void	RefreshPSFLineList();
	void	RefreshPGDeviceList();
	void	RefreshBoundLine();
private:
public:
	void	RefreshUI();
	afx_msg void OnEnChangePowernetName();
};
