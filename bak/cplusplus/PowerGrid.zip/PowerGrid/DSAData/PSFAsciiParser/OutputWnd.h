
#pragma once
#define ID_DIALOG_TIMER			180
#define	DIALOG_STEP_PACE		1000

/////////////////////////////////////////////////////////////////////////////
// COutputList ����

class COutputList : public CListBox
{
// ����
public:
	COutputList();

// ʵ��
public:
	virtual ~COutputList();

protected:
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnViewOutput();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);

	DECLARE_MESSAGE_MAP()
private:
	void OnListMenuCmd(UINT nID);
};

class COutputWnd : public CDockablePane
{
// ����
public:
	COutputWnd();

// ����
public:
	COutputList m_wndMesgList;

protected:
	CFont m_Font;
	CMFCTabCtrl	m_wndTabs;

protected:
	void AdjustHorzScroll(CListBox& wndListBox);

// ʵ��
public:
	virtual ~COutputWnd();

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDestroy();

	DECLARE_MESSAGE_MAP()

private:
	UINT			m_nDialogTimer;
	int				m_nDialogCounter;
	int				m_nDialogTimeout;

public:
};

