
// PG2PSFAsciiDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PG2PSFAsciiDlg.h"

#include "PGShortNameDialog.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPG2PSFAsciiDlg �Ի���




CPG2PSFAsciiDlg::CPG2PSFAsciiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2PSFAsciiDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nCurBoundLine=-1;

	m_nCurPSFLine=m_nCurPGDevice=-1;

	m_strFilterPSFSubstation.clear();
	m_strFilterPSFVoltageLevel.clear();
	m_strFilterPGSubstation.clear();
	m_strFilterPGVoltageLevel.clear();
}

void CPG2PSFAsciiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPG2PSFAsciiDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_NOTIFY(NM_CLICK, IDC_PSFLINE_LIST, &CPG2PSFAsciiDlg::OnNMClickPSFLineList)
	ON_NOTIFY(NM_CLICK, IDC_PGDEVICE_LIST, &CPG2PSFAsciiDlg::OnNMClickPGLineList)
	ON_NOTIFY(NM_CLICK, IDC_BOUNDLINE_LIST, &CPG2PSFAsciiDlg::OnNMClickBoundlineList)
	ON_CBN_SELCHANGE(IDC_PSFSUBSTATION_FILTER_COMBO, &CPG2PSFAsciiDlg::OnCbnSelchangePSFSubstationFilterCombo)
	ON_CBN_SELCHANGE(IDC_PSFVOLTAGELEVEL_FILTER_COMBO, &CPG2PSFAsciiDlg::OnCbnSelchangePSFVoltagelevelFilterCombo)
	ON_CBN_SELCHANGE(IDC_PGSUBSTATION_FILTER_COMBO, &CPG2PSFAsciiDlg::OnCbnSelchangePGSubstationFilterCombo)
	ON_CBN_SELCHANGE(IDC_PGVOLTAGELEVEL_FILTER_COMBO, &CPG2PSFAsciiDlg::OnCbnSelchangePGVoltagelevelFilterCombo)
	ON_BN_CLICKED(IDC_REFRESH, &CPG2PSFAsciiDlg::OnBnClickedRefresh)
	ON_BN_CLICKED(IDC_LOAD_BOUNDLINE, &CPG2PSFAsciiDlg::OnBnClickedLoadBoundline)
	ON_BN_CLICKED(IDC_SAVE_BOUNDLINE, &CPG2PSFAsciiDlg::OnBnClickedSaveBoundline)
	ON_BN_CLICKED(IDC_PGBOUNDNET, &CPG2PSFAsciiDlg::OnBnClickedPGBoundNet)
	ON_BN_CLICKED(IDC_PSFBOUNDNET, &CPG2PSFAsciiDlg::OnBnClickedPSFBoundNet)
	ON_BN_CLICKED(IDC_PSFADD_BUTTON, &CPG2PSFAsciiDlg::OnBnClickedPSFAddButton)
	ON_BN_CLICKED(IDC_PGADD_BUTTON, &CPG2PSFAsciiDlg::OnBnClickedPGAddButton)
	ON_BN_CLICKED(IDC_PSFDEL_BUTTON, &CPG2PSFAsciiDlg::OnBnClickedPSFDelButton)
	ON_BN_CLICKED(IDC_PGDEL_BUTTON, &CPG2PSFAsciiDlg::OnBnClickedPGDelButton)
	ON_CBN_SELCHANGE(IDC_PGDEVICE_TYPE_COMBO, &CPG2PSFAsciiDlg::OnCbnSelchangePGDeviceTypeCombo)
	ON_BN_CLICKED(IDC_LOAD_PSFMATCH, &CPG2PSFAsciiDlg::OnBnClickedLoadPsfmatch)
	ON_BN_CLICKED(IDC_PGSUBSTATION_SHORTNAME, &CPG2PSFAsciiDlg::OnBnClickedPgsubstationShortname)
	ON_BN_CLICKED(IDC_LOAD_PGSUBSTATION_SHORTNAME, &CPG2PSFAsciiDlg::OnBnClickedLoadPGShortName)
	ON_BN_CLICKED(IDC_FORM_PSFASCII, &CPG2PSFAsciiDlg::OnBnClickedFormPsfascii)
	ON_EN_CHANGE(IDC_POWERNET_NAME, &CPG2PSFAsciiDlg::OnEnChangePowernetName)
END_MESSAGE_MAP()


// CPG2PSFAsciiDlg ��Ϣ��������

BOOL CPG2PSFAsciiDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	register int	i;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PSFLINE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLine)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLine[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGDEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszLine)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLine[i],	LVCFMT_LEFT,	100);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBoundLine)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBoundLine[i],	LVCFMT_LEFT,	100);

	RefreshUI();

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CPG2PSFAsciiDlg::RefreshUI()
{
	register int	i,j;
	unsigned char	bInZone;
	CComboBox*	pComboBox;
	char		szBuf[260];

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGSUBSTATION_FILTER_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pComboBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGVOLTAGELEVEL_FILTER_COMBO);
	pComboBox->ResetContent();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGDEVICE_TYPE_COMBO);
	pComboBox->ResetContent();
	PGGetTableDesp(PG_ACLINESEGMENT, szBuf);		pComboBox->AddString(szBuf);
	PGGetTableDesp(PG_SYNCHRONOUSMACHINE, szBuf);	pComboBox->AddString(szBuf);
	PGGetTableDesp(PG_ENERGYCONSUMER, szBuf);		pComboBox->AddString(szBuf);
	PGGetTableDesp(PG_BUSBARSECTION, szBuf);		pComboBox->AddString(szBuf);
	pComboBox->SetCurSel(0);

	RefreshPGDeviceList();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PSFSUBSTATION_FILTER_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			bInZone=0;
			for (j=0; j<(int)g_PSFAscii.m_SubstationArray[i].nBusArray.size(); j++)
			{
				for (int nZone=0; nZone<(int)g_strWorkZoneArray.size(); nZone++)
				{
					if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[i].nBusArray[j]].szZoneName, g_strWorkZoneArray[nZone].c_str()) == 0)
					{
						bInZone=1;
						break;
					}
				}
				if (bInZone)	break;
			}
			if (!bInZone)
				continue;
		}
		pComboBox->AddString(g_PSFAscii.m_SubstationArray[i].szName);
	}
	pComboBox=(CComboBox*)GetDlgItem(IDC_PSFVOLTAGELEVEL_FILTER_COMBO);
	pComboBox->ResetContent();

	RefreshPSFLineList();

	GetDlgItem(IDC_POWERNET_NAME)->SetWindowText(g_strPowerNetName.c_str());
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CPG2PSFAsciiDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CPG2PSFAsciiDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CPG2PSFAsciiDlg::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshUI();
}

void CPG2PSFAsciiDlg::OnBnClickedSaveBoundline()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="xml";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����߽���·�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PG2PSF.SaveBoundLine(dlg.GetPathName());
}

void CPG2PSFAsciiDlg::OnBnClickedLoadBoundline()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="xml";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("װ�ر߽���·�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PG2PSF.LoadBoundLine(dlg.GetPathName());

	RefreshBoundLine();
}

void CPG2PSFAsciiDlg::OnNMClickPSFLineList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PSFLINE_LIST);
	int			nItem=pNMItemActivate->iItem;
	if (nItem >= 0 && nItem < pListCtrl->GetItemCount())
		m_nCurPSFLine=nItem;

	*pResult = 0;
}

void CPG2PSFAsciiDlg::OnNMClickPGLineList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGDEVICE_LIST);
	int			nItem=pNMItemActivate->iItem;
	if (nItem >= 0 && nItem < pListCtrl->GetItemCount())
		m_nCurPGDevice=nItem;

	*pResult = 0;
}

void CPG2PSFAsciiDlg::OnNMClickBoundlineList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	int			nItem=pNMItemActivate->iItem;
	if (nItem >= 0 && nItem < pListCtrl->GetItemCount())
		m_nCurBoundLine=nItem;

	*pResult = 0;
}

void CPG2PSFAsciiDlg::OnCbnSelchangePSFSubstationFilterCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i,j;
	unsigned char	bExist;
	CComboBox*	pComboBox;
	int			nSub;
	char		szBuffer[MDB_CHARLEN];
	std::vector<float>	fVoltArray;

	m_strFilterPSFSubstation.clear();
	m_strFilterPSFVoltageLevel.clear();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PSFVOLTAGELEVEL_FILTER_COMBO);
	pComboBox->ResetContent();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PSFSUBSTATION_FILTER_COMBO);
	nSub=pComboBox->GetCurSel();
	if (nSub == CB_ERR)
		return;
	pComboBox->GetLBText(nSub, szBuffer);

	m_strFilterPSFSubstation=szBuffer;
	nSub=-1;
	for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
	{
		if (strcmp(g_PSFAscii.m_SubstationArray[i].szName, szBuffer) == 0)
		{
			nSub=i;
			break;
		}
	}
	if (nSub >= 0)
	{
		fVoltArray.clear();
		pComboBox=(CComboBox*)GetDlgItem(IDC_PSFVOLTAGELEVEL_FILTER_COMBO);
		pComboBox->AddString("");
		for (i=0; i<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); i++)
		{
			bExist=0;
			for (j=0; j<(int)fVoltArray.size(); j++)
			{
				if (fabs(fVoltArray[j]-g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].fkV) < 0.001)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				fVoltArray.push_back(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].fkV);
		}
		for (i=0; i<(int)fVoltArray.size(); i++)
		{
			sprintf(szBuffer, "%.2f", fVoltArray[i]);
			pComboBox->AddString(szBuffer);
		}
	}
	RefreshPSFLineList();
}

void CPG2PSFAsciiDlg::OnCbnSelchangePSFVoltagelevelFilterCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox;
	int			nVolt;
	char		szVoltageLevel[MDB_CHARLEN];

	m_strFilterPSFVoltageLevel.clear();
	pComboBox=(CComboBox*)GetDlgItem(IDC_PSFVOLTAGELEVEL_FILTER_COMBO);
	nVolt=pComboBox->GetCurSel();
	if (nVolt == CB_ERR)
		return;
	pComboBox->GetLBText(nVolt, szVoltageLevel);
	m_strFilterPSFVoltageLevel=szVoltageLevel;

	RefreshPSFLineList();
}

void CPG2PSFAsciiDlg::OnCbnSelchangePGDeviceTypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshPGDeviceList();
}

void CPG2PSFAsciiDlg::OnCbnSelchangePGSubstationFilterCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CComboBox*	pComboBox;
	int			nSub;
	char		szSubstation[MDB_CHARLEN];

	m_strFilterPGSubstation.clear();
	m_strFilterPGVoltageLevel.clear();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGVOLTAGELEVEL_FILTER_COMBO);
	pComboBox->ResetContent();

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGSUBSTATION_FILTER_COMBO);
	nSub=pComboBox->GetCurSel();
	if (nSub == CB_ERR)
		return;
	pComboBox->GetLBText(nSub, szSubstation);

	m_strFilterPGSubstation=szSubstation;
	nSub=PGGetSubIndex(g_pPGBlock, szSubstation);
	if (nSub >= 0)
	{
		pComboBox=(CComboBox*)GetDlgItem(IDC_PGVOLTAGELEVEL_FILTER_COMBO);
		pComboBox->AddString("");
		for (i=g_pPGBlock->m_SubstationArray[nSub].pRkv; i<g_pPGBlock->m_SubstationArray[nSub+1].pRkv; i++)
			pComboBox->AddString(g_pPGBlock->m_VoltageLevelArray[i].szName);
	}
	RefreshPGDeviceList();
}

void CPG2PSFAsciiDlg::OnCbnSelchangePGVoltagelevelFilterCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox;
	int			nVolt;
	char		szVoltageLevel[MDB_CHARLEN];

	m_strFilterPGVoltageLevel.clear();
	pComboBox=(CComboBox*)GetDlgItem(IDC_PGVOLTAGELEVEL_FILTER_COMBO);
	nVolt=pComboBox->GetCurSel();
	if (nVolt == CB_ERR)
		return;
	pComboBox->GetLBText(nVolt, szVoltageLevel);
	m_strFilterPGVoltageLevel=szVoltageLevel;

	RefreshPGDeviceList();
}

void CPG2PSFAsciiDlg::RefreshPSFLineList()
{
	register int	i;
	int		nRow,nCol;
	unsigned char	bInZone;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PSFLINE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PSFAscii.m_PSFLineArray.size(); i++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			bInZone=0;
			for (int nZone=0; nZone<(int)g_strWorkZoneArray.size(); nZone++)
			{
				if (g_PSFAscii.IsBusInZone(g_PSFAscii.m_PSFLineArray[i].nBus1Number, g_strWorkZoneArray[nZone].c_str()) ||
					g_PSFAscii.IsBusInZone(g_PSFAscii.m_PSFLineArray[i].nBus2Number, g_strWorkZoneArray[nZone].c_str()))
				{
					bInZone=1;
					break;
				}
			}
			if (!bInZone)
				continue;
		}
		if (!m_strFilterPSFSubstation.empty())
		{
			if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus1Index].szSubstation, m_strFilterPSFSubstation.c_str()) != 0 &&
				strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus2Index].szSubstation, m_strFilterPSFSubstation.c_str()) != 0)
				continue;

			if (!m_strFilterPSFVoltageLevel.empty())
			{
				if (fabs(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus1Index].fkV-atof(m_strFilterPSFVoltageLevel.c_str())) > 0.001 &&
					fabs(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus2Index].fkV-atof(m_strFilterPSFVoltageLevel.c_str())) > 0.001)
					continue;
			}
		}
		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus1Index].szSubstation);
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus2Index].szSubstation);

		sprintf(szBuf,"%.2f",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[i].nBus1Index].fkV);
		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFLineArray[i].szPSFName);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLine)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPG2PSFAsciiDlg::RefreshPGDeviceList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGDEVICE_LIST);
	pListCtrl->DeleteAllItems();

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_PGDEVICE_TYPE_COMBO);
	int		nDevType=pComboBox->GetCurSel();
	if (nDevType == CB_ERR)
		return;

	nRow=0;
	switch (nDevType)
	{
	case 0:
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (!m_strFilterPGSubstation.empty())
			{
				if (strcmp(g_pPGBlock->m_ACLineSegmentArray[i].szSubI, m_strFilterPGSubstation.c_str()) != 0 && strcmp(g_pPGBlock->m_ACLineSegmentArray[i].szSubZ, m_strFilterPGSubstation.c_str()) != 0)
					continue;

				if (!m_strFilterPGVoltageLevel.empty())
				{
					if (strcmp(g_pPGBlock->m_ACLineSegmentArray[i].szVoltI, m_strFilterPGVoltageLevel.c_str()) != 0 && strcmp(g_pPGBlock->m_ACLineSegmentArray[i].szVoltZ, m_strFilterPGVoltageLevel.c_str()) != 0)
						continue;
				}
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubZ);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szName);

			nRow++;
		}
		break;
	case 1:
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			if (!m_strFilterPGSubstation.empty())
			{
				if (strcmp(g_pPGBlock->m_SynchronousMachineArray[i].szSub, m_strFilterPGSubstation.c_str()) != 0)
					continue;

				if (!m_strFilterPGVoltageLevel.empty())
				{
					if (strcmp(g_pPGBlock->m_SynchronousMachineArray[i].szVolt, m_strFilterPGVoltageLevel.c_str()) != 0)
						continue;
				}
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szName);

			nRow++;
		}
		break;
	case 2:
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
		{
			if (!m_strFilterPGSubstation.empty())
			{
				if (strcmp(g_pPGBlock->m_EnergyConsumerArray[i].szSub, m_strFilterPGSubstation.c_str()) != 0)
					continue;

				if (!m_strFilterPGVoltageLevel.empty())
				{
					if (strcmp(g_pPGBlock->m_EnergyConsumerArray[i].szVolt, m_strFilterPGVoltageLevel.c_str()) != 0)
						continue;
				}
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[i].szName);

			nRow++;
		}
		break;
	case 3:
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		{
			if (!m_strFilterPGSubstation.empty())
			{
				if (strcmp(g_pPGBlock->m_BusbarSectionArray[i].szSub, m_strFilterPGSubstation.c_str()) != 0)
					continue;

				if (!m_strFilterPGVoltageLevel.empty())
				{
					if (strcmp(g_pPGBlock->m_BusbarSectionArray[i].szVolt, m_strFilterPGVoltageLevel.c_str()) != 0)
						continue;
				}
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[i].szName);

			nRow++;
		}
		break;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLine)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPG2PSFAsciiDlg::RefreshBoundLine()
{
	register int	i,j;
	int		nDevice,nRow,nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PG2PSF.m_PG2PSFBoundArray.size(); i++)
	{
		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);
		nCol=1;

		nDevice=-1;
		for (j=0; j<(int)g_PSFAscii.m_PSFLineArray.size(); j++)
		{
			if (strcmp(g_PSFAscii.m_PSFLineArray[j].szPSFName, g_PG2PSF.m_PG2PSFBoundArray[i].szPSFBoundLine) == 0)
			{
				nDevice=j;
				break;
			}
		}
		if (nDevice < 0)
			continue;

		if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDevice].nBus1Index].szSubstation, g_PG2PSF.m_PG2PSFBoundArray[i].szPSFBoundSub) == 0)
		{
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDevice].nBus1Index].szSubstation);
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDevice].nBus2Index].szSubstation);
		}
		else
		{
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDevice].nBus2Index].szSubstation);
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDevice].nBus1Index].szSubstation);
		}

		sprintf(szBuf,"%.2f",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDevice].nBus2Index].fkV);
		pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFLineArray[nDevice].szPSFName);

		PGGetTableDesp(g_PG2PSF.m_PG2PSFBoundArray[i].nPGBoundDevType, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		switch (g_PG2PSF.m_PG2PSFBoundArray[i].nPGBoundDevType)
		{
		case PG_ACLINESEGMENT:
			nDevice=-1;
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; j++)
			{
				if (strcmp(g_pPGBlock->m_ACLineSegmentArray[j].szName, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(g_pPGBlock->m_ACLineSegmentArray[j].szSubI, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 || strcmp(g_pPGBlock->m_ACLineSegmentArray[j].szSubZ, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
			{
				pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevSub);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[nDevice].szVoltI);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[nDevice].szName);
			}
			break;
		case PG_SYNCHRONOUSMACHINE:
			nDevice=-1;
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; j++)
			{
				if (strcmp(g_pPGBlock->m_SynchronousMachineArray[j].szName, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(g_pPGBlock->m_SynchronousMachineArray[j].szSub, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(g_pPGBlock->m_SynchronousMachineArray[j].szVolt, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
			{
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nDevice].szSub);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nDevice].szVolt);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[nDevice].szName);
			}
			break;
		case PG_ENERGYCONSUMER:
			nDevice=-1;
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; j++)
			{
				if (strcmp(g_pPGBlock->m_EnergyConsumerArray[j].szName, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(g_pPGBlock->m_EnergyConsumerArray[j].szSub, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(g_pPGBlock->m_EnergyConsumerArray[j].szVolt, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
			{
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[nDevice].szSub);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[nDevice].szVolt);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_EnergyConsumerArray[nDevice].szName);
			}
			break;
		case PG_BUSBARSECTION:
			nDevice=-1;
			for (j=0; j<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; j++)
			{
				if (strcmp(g_pPGBlock->m_BusbarSectionArray[j].szName, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(g_pPGBlock->m_BusbarSectionArray[j].szSub, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(g_pPGBlock->m_BusbarSectionArray[j].szVolt, g_PG2PSF.m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
			{
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[nDevice].szSub);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[nDevice].szVolt);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_BusbarSectionArray[nDevice].szName);
			}
			break;
		}

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLine)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPG2PSFAsciiDlg::OnBnClickedPGBoundNet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CPGBoundNetDialog	dlg;
	dlg.DoModal();
}

void CPG2PSFAsciiDlg::OnBnClickedPSFBoundNet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CPSFBoundNetDialog	dlg;
	dlg.DoModal();
}

void CPG2PSFAsciiDlg::OnBnClickedPSFAddButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	char		szSubstation[MDB_CHARLEN];
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_PSFSUBSTATION_FILTER_COMBO);
	int		nSub=pComboBox->GetCurSel();
	if (nSub == CB_ERR)
		return;

	pComboBox->GetLBText(nSub, szSubstation);

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PSFLINE_LIST);
	if (m_nCurPSFLine < 0 || m_nCurPSFLine >= pListCtrl->GetItemCount())
		return;
	
	register int	i;
	int			nLine;
	char		szLineName[MDB_CHARLEN];
	strcpy(szLineName, pListCtrl->GetItemText(m_nCurPSFLine, 4));
	nLine=-1;
	for (i=0; i<(int)g_PSFAscii.m_PSFLineArray.size(); i++)
	{
		if (strcmp(g_PSFAscii.m_PSFLineArray[i].szPSFName, szLineName) == 0)
		{
			nLine=i;
			break;
		}
	}
	if (nLine < 0)
		return;
	
	tagPG2PSFBoundLine	bLineBuf;
	UpdateData();
	strcpy(bLineBuf.szPSFBoundLine, g_PSFAscii.m_PSFLineArray[nLine].szPSFName);
	strcpy(bLineBuf.szPSFBoundSub, szSubstation);
	
	nLine=-1;
	for (i=0; i<(int)g_PG2PSF.m_PG2PSFBoundArray.size(); i++)
	{
		if (strcmp(g_PG2PSF.m_PG2PSFBoundArray[i].szPSFBoundLine, bLineBuf.szPSFBoundLine) == 0)
		{
			nLine=i;
			break;
		}
	}
	if (nLine < 0)
		g_PG2PSF.m_PG2PSFBoundArray.push_back(bLineBuf);
	
	RefreshBoundLine();
}

void CPG2PSFAsciiDlg::OnBnClickedPGAddButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl;
	CComboBox*	pComboBox;
	int			nPGDevType;
	char		szInetSubstation[MDB_CHARLEN],szBoundLineName[MDB_CHARLEN];

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGDEVICE_TYPE_COMBO);
	nPGDevType=pComboBox->GetCurSel();
	if (nPGDevType == CB_ERR)
		return;

	pComboBox=(CComboBox*)GetDlgItem(IDC_PGSUBSTATION_FILTER_COMBO);
	int		nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
		return;
	pComboBox->GetLBText(nSel, szInetSubstation);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	if (m_nCurBoundLine < 0 || m_nCurBoundLine >= pListCtrl->GetItemCount())
		return;
	strcpy(szBoundLineName, pListCtrl->GetItemText(m_nCurBoundLine, g_nBoundLineNamePSFColumn));

	register int	i;
	int			nBoundLine;
	nBoundLine=-1;
	for (i=0; i<(int)g_PG2PSF.m_PG2PSFBoundArray.size(); i++)
	{
		if (strcmp(g_PG2PSF.m_PG2PSFBoundArray[i].szPSFBoundLine, szBoundLineName) == 0)
		{
			nBoundLine=i;
			break;
		}
	}
	if (nBoundLine < 0)
		return;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGDEVICE_LIST);
	if (m_nCurPGDevice < 0 || m_nCurPGDevice >= pListCtrl->GetItemCount())
		return;

	switch (nPGDevType)
	{
	case 0:		g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].nPGBoundDevType=PG_ACLINESEGMENT;		break;
	case 1:		g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].nPGBoundDevType=PG_SYNCHRONOUSMACHINE;	break;
	case 2:		g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].nPGBoundDevType=PG_ENERGYCONSUMER;		break;
	case 3:		g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].nPGBoundDevType=PG_BUSBARSECTION;		break;
	default:	return;
	}
	strcpy(g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].szPGBoundDevSub, szInetSubstation);
	strcpy(g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].szPGBoundDevVolt, pListCtrl->GetItemText(m_nCurPGDevice, g_nDeviceVoltColumn));
	strcpy(g_PG2PSF.m_PG2PSFBoundArray[nBoundLine].szPGBoundDevName, pListCtrl->GetItemText(m_nCurPGDevice, g_nDeviceNameColumn));

	RefreshBoundLine();
}

void CPG2PSFAsciiDlg::OnBnClickedPSFDelButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	if (m_nCurBoundLine < 0 || m_nCurBoundLine >= pListCtrl->GetItemCount())
		return;

	char	szLineName[MDB_CHARLEN];
	strcpy(szLineName, pListCtrl->GetItemText(m_nCurBoundLine, g_nBoundLineNamePSFColumn));
	i=0;
	while (i < (int)g_PG2PSF.m_PG2PSFBoundArray.size())
	{
		if (strcmp(g_PG2PSF.m_PG2PSFBoundArray[i].szPSFBoundLine, szLineName) == 0)
		{
			g_PG2PSF.m_PG2PSFBoundArray.erase(g_PG2PSF.m_PG2PSFBoundArray.begin()+i);
		}
		else
		{
			i++;
		}
	}

	RefreshBoundLine();
}

void CPG2PSFAsciiDlg::OnBnClickedPGDelButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	if (m_nCurBoundLine < 0 || m_nCurBoundLine >= pListCtrl->GetItemCount())
		return;

	g_PG2PSF.m_PG2PSFBoundArray[m_nCurBoundLine].nPGBoundDevType=0;
	memset(g_PG2PSF.m_PG2PSFBoundArray[m_nCurBoundLine].szPGBoundDevSub, 0, MDB_CHARLEN);
	memset(g_PG2PSF.m_PG2PSFBoundArray[m_nCurBoundLine].szPGBoundDevVolt, 0, MDB_CHARLEN);
	memset(g_PG2PSF.m_PG2PSFBoundArray[m_nCurBoundLine].szPGBoundDevName, 0, MDB_CHARLEN);
	RefreshBoundLine();
}

void CPG2PSFAsciiDlg::OnBnClickedLoadPsfmatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt)|*.txt;*.TXT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("װ��PG2PSF�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
		g_PSFAscii.ReadPSFAscii2CimMatch(dlg.GetPathName());
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�����ļ���%s��װ����ϣ���ʱ%d����", dlg.GetPathName(), nDur);
		g_PSFAscii.AutoPSFAscii2CimMatch(g_pPGBlock, 1, g_strWorkZoneArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�����ļ���%s���Զ�������ϣ���ʱ%d����", dlg.GetPathName(), nDur);
}

void CPG2PSFAsciiDlg::OnBnClickedPgsubstationShortname()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CPGShortNameDialog	dlg;
	dlg.DoModal();
}

void CPG2PSFAsciiDlg::OnBnClickedLoadPGShortName()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="xml";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("װ�س�վ�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PG2PSF.LoadSubstationShortName(g_pPGBlock, dlg.GetPathName());
}

void CPG2PSFAsciiDlg::OnBnClickedFormPsfascii()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="raw";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.raw)|*.raw;*.RAW|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Ascii�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PG2PSF.PG2PSFAscii(g_pPGBlock, &g_PSFAscii, g_fZIL, g_strPowerNetName.c_str(), dlg.GetPathName(), g_strWorkZoneArray);
}

void CPG2PSFAsciiDlg::OnEnChangePowernetName()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];
	GetDlgItem(IDC_POWERNET_NAME)->GetWindowText(szBuf, 260);
	g_strPowerNetName=szBuf;

	SaveIni();
}
