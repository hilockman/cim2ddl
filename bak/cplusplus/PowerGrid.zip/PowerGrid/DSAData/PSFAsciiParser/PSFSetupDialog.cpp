// PSFSetupDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PSFSetupDialog.h"


// CPSFSetupDialog �Ի���

IMPLEMENT_DYNAMIC(CPSFSetupDialog, CDialog)

CPSFSetupDialog::CPSFSetupDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPSFSetupDialog::IDD, pParent)
{

}

CPSFSetupDialog::~CPSFSetupDialog()
{
}

void CPSFSetupDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPSFSetupDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD, &CPSFSetupDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CPSFSetupDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_CHECK, &CPSFSetupDialog::OnBnClickedCheck)
	ON_BN_CLICKED(IDCANCEL, &CPSFSetupDialog::OnBnClickedCancel)
	ON_BN_CLICKED(IDC_DELALL, &CPSFSetupDialog::OnBnClickedDelall)
END_MESSAGE_MAP()


// CPSFSetupDialog ��Ϣ��������

BOOL CPSFSetupDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox;
	CButton*	pButton;

	pButton=(CButton*)GetDlgItem(IDC_CHECK_WHENIMPORT);
	pButton->SetCheck(g_bCheckValidateWhenImport);

	pButton=(CButton*)GetDlgItem(IDC_SET_PLANT_RTLOAD);
	pButton->SetCheck(g_bSetPlantRTLoad);

	char	szBuf[260];
	sprintf(szBuf,"%f",g_fZIL);
	GetDlgItem(IDC_ZIL)->SetWindowText(szBuf);

	pListBox=(CListBox*)GetDlgItem(IDC_ALLZONE_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)g_PSFAscii.m_PSFZoneArray.size(); i++)
		pListBox->AddString(g_PSFAscii.m_PSFZoneArray[i].szName);

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TIELINE_LIST);
	pListCtrl->SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	while (pListCtrl->DeleteColumn(0));
	if (!pListCtrl->DeleteAllItems())
		return FALSE;
	pListCtrl->InsertColumn(0, "���");
	pListCtrl->SetColumnWidth(0, 50);

	i=1;
	pListCtrl->InsertColumn(i++, "���", LVCFMT_LEFT, 100);
	pListCtrl->InsertColumn(i++, "�յ�", LVCFMT_LEFT, 100);
	pListCtrl->InsertColumn(i++, "ID", LVCFMT_LEFT, 100);
	pListCtrl->InsertColumn(i++, "�����", LVCFMT_LEFT, 100);
	pListCtrl->InsertColumn(i++, "�շ���", LVCFMT_LEFT, 100);

	RefreshWorkArea();
	RefreshTielineList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPSFSetupDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CListBox*	pListBox;
	int			nSelIndexArray[1000];
	unsigned char	bExist;

	char		szDiv[MDB_CHARLEN];

	pListBox=(CListBox*)GetDlgItem(IDC_ALLZONE_LIST);
	int		nSelNum=pListBox->GetSelItems(1000, nSelIndexArray);
	for (int nItem=0; nItem<nSelNum; nItem++)
	{
		pListBox->GetText(nSelIndexArray[nItem], szDiv);

		bExist=0;
		for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
		{
			if (strcmp(g_strWorkZoneArray[i].c_str(), szDiv) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			g_strWorkZoneArray.push_back(szDiv);
		}
	}
	RefreshWorkArea();
	RefreshTielineList();
}

void CPSFSetupDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CListBox*	pListBox;
	char		szDiv[MDB_CHARLEN];
	int			nSelIndexArray[1000];

	pListBox=(CListBox*)GetDlgItem(IDC_SHOWAREA_LIST);
	int		nSelNum=pListBox->GetSelItems(1000, nSelIndexArray);
	for (int nItem=0; nItem<nSelNum; nItem++)
	{
		pListBox->GetText(nSelIndexArray[nItem], szDiv);
		for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
		{
			if (strcmp(g_strWorkZoneArray[i].c_str(), szDiv) == 0)
			{
				g_strWorkZoneArray.erase(g_strWorkZoneArray.begin()+i);
				break;
			}
		}
	}
	RefreshWorkArea();
	RefreshTielineList();
}


void CPSFSetupDialog::OnBnClickedDelall()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_strWorkZoneArray.clear();
	RefreshWorkArea();
	RefreshTielineList();
}

void CPSFSetupDialog::RefreshWorkArea(void)
{
	register int	i;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SHOWAREA_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
		pListBox->AddString(g_strWorkZoneArray[i].c_str());
}

void CPSFSetupDialog::RefreshTielineList()
{
	register int	i;
	int		nLine,nCol;
	char	szBuf[260];
	std::vector<int>			nTLineArray;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_TIELINE_LIST);
	pListCtrl->DeleteAllItems();

	if (g_strWorkZoneArray.empty())
		return;

	g_PSFAscii.GetTieLine(g_strWorkZoneArray, nTLineArray);
	for (nLine=0; nLine<(int)nTLineArray.size(); nLine++)
	{
		sprintf(szBuf,"%d/%d",nLine+1,nTLineArray.size());
		pListCtrl->InsertItem(nLine, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nLine, nCol++, g_PSFAscii.m_PSFLineArray[nTLineArray[nLine]].szBus1Name);
		pListCtrl->SetItemText(nLine, nCol++, g_PSFAscii.m_PSFLineArray[nTLineArray[nLine]].szBus2Name);

		pListCtrl->SetItemText(nLine, nCol++, g_PSFAscii.m_PSFLineArray[nTLineArray[nLine]].szID);

		pListCtrl->SetItemText(nLine, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nTLineArray[nLine]].nBus1Index].szZoneName);
		pListCtrl->SetItemText(nLine, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nTLineArray[nLine]].nBus2Index].szZoneName);
	}

	int		nColWidth,nHeaderWidth;
	nHeaderWidth=0;
	for (i=0; i<6; i++)
	{
		pListCtrl->SetColumnWidth(i+1, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i+1);
		pListCtrl->SetColumnWidth(i+1, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(i+1);

		pListCtrl->SetColumnWidth(i+1, max(nColWidth, nHeaderWidth));
	}
}
void CPSFSetupDialog::OnBnClickedCheck()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nDiv;
	unsigned char	bExist=0;

	nDiv=0;
	while (nDiv<(int)g_strWorkZoneArray.size())
	{
		bExist=0;
		for (i=0; i<(int)g_PSFAscii.m_PSFZoneArray.size(); i++)
		{
			if (strcmp(g_strWorkZoneArray[nDiv].c_str(), g_PSFAscii.m_PSFZoneArray[i].szName) == 0)
			{
				bExist=1;
				break;
			}
		}

		if (!bExist)
			g_strWorkZoneArray.erase(g_strWorkZoneArray.begin()+nDiv);
		else
			nDiv++;
	}

	RefreshWorkArea();
	RefreshTielineList();
}

void CPSFSetupDialog::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton;
	pButton=(CButton*)GetDlgItem(IDC_CHECK_WHENIMPORT);
	g_bCheckValidateWhenImport=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_SET_PLANT_RTLOAD);
	g_bSetPlantRTLoad=pButton->GetCheck();

	char	szBuf[260];
	GetDlgItem(IDC_ZIL)->GetWindowText(szBuf, 260);
	g_fZIL=atof(szBuf);

	SaveIni();
	OnCancel();
}
