// PGShortNameDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PGShortNameDialog.h"


// CPGShortNameDialog �Ի���
static	char*	lpszSubstationNameColumn[]=
{
	"���",
	"��վ����",
	"��վ������",
};

IMPLEMENT_DYNAMIC(CPGShortNameDialog, CDialog)

CPGShortNameDialog::CPGShortNameDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPGShortNameDialog::IDD, pParent)
{
	m_nCurSubstation=-1;
	m_bShowShortNameNull=0;
}

CPGShortNameDialog::~CPGShortNameDialog()
{
}

void CPGShortNameDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPGShortNameDialog, CDialog)
	ON_BN_CLICKED(IDC_SET, &CPGShortNameDialog::OnBnClickedSet)
	ON_BN_CLICKED(IDC_LOAD, &CPGShortNameDialog::OnBnClickedLoad)
	ON_NOTIFY(NM_CLICK, IDC_PGSUBSTATION_LIST, &CPGShortNameDialog::OnNMClickPgsubstationList)
	ON_BN_CLICKED(IDC_SAVE, &CPGShortNameDialog::OnBnClickedSave)
	ON_BN_CLICKED(IDC_INIT, &CPGShortNameDialog::OnBnClickedInit)
	ON_BN_CLICKED(IDC_SHORTNAME_NULL, &CPGShortNameDialog::OnBnClickedShortnameNull)
END_MESSAGE_MAP()


// CPGShortNameDialog ��Ϣ��������

BOOL CPGShortNameDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGSUBSTATION_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	//pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszSubstationNameColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszSubstationNameColumn[i]);

	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHORTNAME_NULL);
	pButton->SetCheck(m_bShowShortNameNull);

	RefreshSubstationList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPGShortNameDialog::OnBnClickedSet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	char	szSubName[MDB_CHARLEN], szSubShortName[MDB_CHARLEN];

	GetDlgItem(IDC_NAME)->GetWindowText(szSubName, MDB_CHARLEN);
	GetDlgItem(IDC_SHORTNAME)->GetWindowText(szSubShortName, MDB_CHARLEN);

	if (strlen(szSubShortName) > 10)
	{
		AfxMessageBox("�����ƹ���");
		return;
	}
	for (i=0; i<(int)g_PG2PSF.m_PGShortNameArray.size(); i++)
	{
		if (strcmp(g_PG2PSF.m_PGShortNameArray[i].strName.c_str(), szSubName) == 0)
		{
			g_PG2PSF.m_PGShortNameArray[i].strShortName=szSubShortName;
			break;
		}
	}

	RefreshSubstationList();

	if (m_nCurSubstation >= 0)
	{
		CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGSUBSTATION_LIST);
		pListCtrl->EnsureVisible(m_nCurSubstation, TRUE);
	}
}

void CPGShortNameDialog::OnBnClickedLoad()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="xml";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("װ�س�վ�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PG2PSF.LoadSubstationShortName(g_pPGBlock, dlg.GetPathName());
	RefreshSubstationList();
}

void CPGShortNameDialog::OnBnClickedSave()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="xml";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("���泧վ�������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	g_PG2PSF.SaveSubstationShortName(dlg.GetPathName());
}

void CPGShortNameDialog::RefreshSubstationList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGSUBSTATION_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_PG2PSF.m_PGShortNameArray.size(); i++)
	{
		if (m_bShowShortNameNull)
		{
			if (!g_PG2PSF.m_PGShortNameArray[i].strShortName.empty())
				continue;
		}
		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGShortNameArray[i].strName.c_str());
		pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGShortNameArray[i].strShortName.c_str());

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszSubstationNameColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGShortNameDialog::OnNMClickPgsubstationList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_PGSUBSTATION_LIST);
	m_nCurSubstation=pNMItemActivate->iItem;
	if (m_nCurSubstation >= 0 && m_nCurSubstation < pListCtrl->GetItemCount())
	{
		GetDlgItem(IDC_NAME)->SetWindowText(pListCtrl->GetItemText(m_nCurSubstation, 1));
		GetDlgItem(IDC_SHORTNAME)->SetWindowText(pListCtrl->GetItemText(m_nCurSubstation, 2));
	}
	*pResult = 0;
}

void CPGShortNameDialog::OnBnClickedInit()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i,j;
	unsigned char	bExist;

	tagPGShortName	subBuf;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		subBuf.strName=g_pPGBlock->m_SubstationArray[i].szName;
		subBuf.strShortName.clear();
		if (subBuf.strName.length() <= 10)
			subBuf.strShortName=subBuf.strName;

		bExist=0;
		for (j=0; j<(int)g_PG2PSF.m_PGShortNameArray.size(); j++)
		{
			if (strcmp(g_PG2PSF.m_PGShortNameArray[j].strName.c_str(), subBuf.strName.c_str()) == 0)
			{
				g_PG2PSF.m_PGShortNameArray[j].strShortName=subBuf.strShortName;
				bExist=1;
				break;
			}
		}
		if (!bExist)
			g_PG2PSF.m_PGShortNameArray.push_back(subBuf);
	}

	RefreshSubstationList();
}

void CPGShortNameDialog::OnBnClickedShortnameNull()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHORTNAME_NULL);
	m_bShowShortNameNull=pButton->GetCheck();

	RefreshSubstationList();
}
