
// PSFAsciiParserList.cpp : CPSFAsciiParserList ���ʵ��
//

#include "stdafx.h"
#include "PSFAsciiParser.h"

#include "PSFAsciiParserDoc.h"
#include "PSFAsciiParserList.h"
#include "PSFSetupDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPSFAsciiParserList

IMPLEMENT_DYNCREATE(CPSFAsciiParserList, CListView)

BEGIN_MESSAGE_MAP(CPSFAsciiParserList, CListView)
	ON_NOTIFY_REFLECT(LVN_ITEMCHANGED, &CPSFAsciiParserList::OnLvnItemchanged)
	ON_COMMAND(ID_SAVEAS_EXCEL, &CPSFAsciiParserList::OnSaveasExcel)
	ON_COMMAND(ID_SEARCH, &CPSFAsciiParserList::OnSearch)
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, &CPSFAsciiParserList::OnLvnGetdispinfo)
END_MESSAGE_MAP()

// CPSFAsciiParserList ����/����

CPSFAsciiParserList::CPSFAsciiParserList()
{
	// TODO: �ڴ˴����ӹ������
}

CPSFAsciiParserList::~CPSFAsciiParserList()
{
}

BOOL CPSFAsciiParserList::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ
	cs.style &= ~LVS_TYPEMASK;
	//cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT;// | LVS_OWNERDATA;// | LVS_OWNERDRAWFIXED;
	cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT | LVS_OWNERDATA;// | LVS_OWNERDRAWFIXED;
	return CListView::PreCreateWindow(cs);
}

void CPSFAsciiParserList::OnInitialUpdate()
{
	CListView::OnInitialUpdate();


	// TODO: ���� GetListCtrl() ֱ�ӷ��� ListView ���б��ؼ���
	//  �Ӷ������������ ListView��
	GetListCtrl().SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void CPSFAsciiParserList::OnRButtonUp(UINT nFlags, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CPSFAsciiParserList::OnContextMenu(CWnd* pWnd, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CPSFAsciiParserList ���

#ifdef _DEBUG
void CPSFAsciiParserList::AssertValid() const
{
	CListView::AssertValid();
}

void CPSFAsciiParserList::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CPSFAsciiParserDoc* CPSFAsciiParserList::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPSFAsciiParserDoc)));
	return (CPSFAsciiParserDoc*)m_pDocument;
}
#endif //_DEBUG


// CPSFAsciiParserList ��Ϣ��������

void CPSFAsciiParserList::OnLvnItemchanged(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	static	int	nOldItem = -1;
	CPSFAsciiParserDoc*	pDoc=GetDocument();

	int	nNewItem=pNMLV->iItem;
	if (pDoc->m_nTable >= 0 && pDoc->m_nTable < sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable) && (nNewItem != -1 && nOldItem != nNewItem || pDoc->m_nRecord <= 0))
	{
 		if (pNMLV->iItem != -1 && (pNMLV->iItem >= 0 && pNMLV->iItem < (int)m_nShowIndexArray.size()))
 		{
 			nOldItem = nNewItem;
 			pDoc->m_nRecord=m_nShowIndexArray[pNMLV->iItem];
 			AfxGetMainWnd()->PostMessage(UM_UPDATEPROPERTIES,1,0);
		}
	}
	*pResult = 0;
}

void CPSFAsciiParserList::RefreshList(const int nTable)
{
// 	int		nField,nRecord;
// 	char	szBuf[260];
// 	std::vector<std::string>	strRecArray;
// 
// 	int		nRecordNum=g_PSFAscii.GetPSFModelRecordNum(nTable);
// 	int		nFieldNum=g_PSFModelTables[nTable].nFieldNum;
// 	for (nRecord=0; nRecord<nRecordNum; nRecord++)
// 	{
// 		sprintf(szBuf, "%d", nRecord+1);
// 		GetListCtrl().InsertItem(nRecord, szBuf);
// 
// 		g_PSFAscii.GetPSFDataStringArray(nTable, nRecord, strRecArray);
// 		for (nField=0; nField<nFieldNum; nField++)
// 		{
// 			if ((int)strRecArray.size() > nField)	GetListCtrl().SetItemText(nRecord, nField+1, strRecArray[nField].c_str());
// 		}
// 	}
}

void CPSFAsciiParserList::UpdateView()
{
	register int	i;
	int		nColWidth,nHeaderWidth;

	CPSFAsciiParserDoc*	pDoc=GetDocument();

	while (GetListCtrl().DeleteColumn(0));
	if (!GetListCtrl().DeleteAllItems())
		return;

	ResolveShowIndex();

	GetListCtrl().InsertColumn(0, "���", LVCFMT_LEFT, 80);
	for (i=0; i<g_PSFModelTables[pDoc->m_nTable].nFieldNum; i++)
		GetListCtrl().InsertColumn(i+1, g_PSFModelTables[pDoc->m_nTable].pFieldArray[i].lpszCnDesp, LVCFMT_LEFT, 100);

	GetListCtrl().SetItemCount(m_nShowIndexArray.size());	//force redraw
	GetListCtrl().SetItemState(pDoc->m_nRecord, LVIS_SELECTED, 0xffff);
	GetListCtrl().EnsureVisible(pDoc->m_nRecord,FALSE);

	for (i=0; i<=g_PSFModelTables[pDoc->m_nTable].nFieldNum; i++)
	{
		nHeaderWidth=0;
		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = GetListCtrl().GetColumnWidth(i);

			GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
			nHeaderWidth =GetListCtrl().GetColumnWidth(i);

		nColWidth=max(nColWidth, nHeaderWidth);
		if (nColWidth < 80)	nColWidth=80;
		GetListCtrl().SetColumnWidth(i, nColWidth);
	}
}

void CPSFAsciiParserList::OnSaveasExcel()
{
	// TODO: �ڴ�����������������
	char	szExcel[260];
	CString	strPath;
	if (theApp.GetShellManager()->BrowseForFolder(strPath,NULL,NULL,"��ȷ��EXCEL����Ŀ¼"))
	{
		CPSFAsciiParserDoc*	pDoc=GetDocument();
		sprintf(szExcel,"%s/%s",strPath,g_PSFModelTables[pDoc->m_nTable].lpszModelDesp);

		SaveListAsExcel(&GetListCtrl(),"", szExcel, 1);
	}
}

void CPSFAsciiParserList::OnSearch()
{
	// TODO: �ڴ�����������������
	int		nItem;
	char	szColumn[MDB_CHARLEN_LONG];
	char	szContent[MDB_CHARLEN_LONG];
	std::vector<std::string>	strElement;
	CMFCToolBarComboBoxButton*	pComboBox;
	CMFCToolBarEditBoxButton*	pEditBox;
	int		nField;

	CPSFAsciiParserDoc*	pDoc=GetDocument();

	nField=-1;
	memset(szColumn, 0, MDB_CHARLEN_LONG);
	memset(szContent, 0, MDB_CHARLEN_LONG);

	nItem = GetToolBar().CommandToIndex(ID_SEARCH_COLUMN);
	pComboBox = (CMFCToolBarComboBoxButton*)GetToolBar().GetButton(nItem);
	if (pComboBox)
	{
		if (pComboBox->GetCount() > 0)
		{
			nField=pComboBox->GetCurSel();
		}
	}
	if (nField < 0)
		return;

	nItem = GetToolBar().CommandToIndex(ID_SEARCH_CONTENT);
	pEditBox = (CMFCToolBarEditBoxButton*)GetToolBar().GetButton(nItem);
	if (pEditBox)
	{
		CEdit*	pEdit=pEditBox->GetEditBox();
		if (pEdit)
			pEdit->GetWindowText(szContent,MDB_CHARLEN_LONG);
	}
	if (strlen(szContent) <= 0)
		return;

	nItem=g_PSFAscii.FindPSFData(pDoc->m_nTable, nField, pDoc->m_nRecord+1, szContent);

	pDoc->m_nRecord=-1;
	if (nItem >= 0)
	{
		register int	i;
		for (i=0; i<(int)m_nShowIndexArray.size(); i++)
		{
			if (nItem == m_nShowIndexArray[i])
			{
				pDoc->m_nRecord=i;
				break;
			}
		}
		UpdateView();
	}
}

void CPSFAsciiParserList::OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DrawItem(pDispInfo);
	*pResult = 0;
}

void CPSFAsciiParserList::DrawItem(NMLVDISPINFO* pDispInfo)
{
	// TODO:  �������Ĵ����Ի���ָ����
	CPSFAsciiParserDoc*	pDoc=GetDocument();
	LV_ITEM* pItem= &(pDispInfo)->item;
	if (pItem->mask & LVIF_TEXT)
	{
		if (pItem->iSubItem == 0)
			sprintf(pItem->pszText,"%5d",pItem->iItem+1);
		else
			strcpy(pItem->pszText, g_PSFAscii.GetPSFDataString(pDoc->m_nTable, pItem->iSubItem-1, m_nShowIndexArray[pItem->iItem]).c_str());
	}
}

void	CPSFAsciiParserList::ResolveShowIndex()
{
	CPSFAsciiParserDoc*	pDoc=GetDocument();
	g_PSFAscii.GetZoneFilterIndexArray(pDoc->m_nTable, g_strWorkZoneArray, m_nShowIndexArray);
}