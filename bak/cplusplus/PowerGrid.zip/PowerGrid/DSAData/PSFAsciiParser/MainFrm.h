
// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once
#include "TableView.h"
#include "OutputWnd.h"
#include "PropertiesWnd.h"
#include "PG2PSFMatchDialog.h"
#include "SubstationDeviceDialog.h"
#include "PG2PSFAsciiDlg.h"

const	int		g_nStatusIcon=0;
const	int		g_nStatusSeperator=1;
const	int		g_nStatusNetStatus=2;
const	int		g_nStatusDBDesp=3;

class CMainFrame : public CFrameWndEx
{
	
protected: // �������л�����
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)
	CMFCToolBar& GetToolBar ()
	{
		return m_wndToolBar;
	}

// ����
protected:
	CSplitterWnd m_wndSplitter;
public:

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	COutputWnd			m_wndOutput;
protected:  // �ؼ���Ƕ���Ա
	CMFCMenuBar			m_wndMenuBar;
	CMFCToolBar			m_wndToolBar;
	CMFCStatusBar		m_wndStatusBar;
	CPropertiesWnd		m_wndProperties;
	CTableView			m_wndTableView;

	CPG2PSFMatchDialog		m_wndRT2OffDialog;
	CSubstationDeviceDialog	m_wndSubDevDialog;
	CPG2PSFAsciiDlg			m_wndPG2PSFDialog;

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg LRESULT OnToolbarCreateNew(WPARAM wp, LPARAM lp);
	afx_msg LRESULT OnToolbarReset(WPARAM,LPARAM);
	afx_msg LRESULT OnUpdateCaptionBar(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnUpdateProperties(WPARAM wParam, LPARAM lParam);
	
	afx_msg void OnApplicationLook(UINT id);
	afx_msg void OnUpdateApplicationLook(CCmdUI* pCmdUI);
	afx_msg void OnViewCaptionBar();
	afx_msg void OnUpdateViewCaptionBar(CCmdUI* pCmdUI);
	afx_msg void OnViewPropertiesWnd();
	afx_msg void OnUpdateViewPropertiesWnd(CCmdUI* pCmdUI);
	afx_msg void OnSearchColumn();
	afx_msg void OnSearchContent();
	afx_msg LRESULT OnTableChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnRt2Offline();
	afx_msg void OnSubstationDevice();
	afx_msg void OnRt2OfflineMatch();
	DECLARE_MESSAGE_MAP()

	BOOL CreateDockingWindows();
	void SetDockingWindowIcons(BOOL bHiColorIcons);
public:
	afx_msg void OnPg2psf();
};


