#pragma once


// CPSFBoundNetDialog �Ի���

class CPSFBoundNetDialog : public CDialog
{
	DECLARE_DYNAMIC(CPSFBoundNetDialog)

public:
	CPSFBoundNetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPSFBoundNetDialog();

// �Ի�������
	enum { IDD = IDD_PSFBOUNDNET_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnCbnSelchangeDeviceTypeCombo();
	afx_msg void OnBnClickedAddButton();
	afx_msg void OnBnClickedDelButton();
	afx_msg void OnBnClickedFormBoundnet();
	DECLARE_MESSAGE_MAP()
private:
	int		m_nCurDeviceType;

private:
	void	RefreshBoundNetDevice(const int nDeviceType);
};
