// PSFBoundNetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PSFBoundNetDialog.h"

// CPSFBoundNetDialog �Ի���

IMPLEMENT_DYNAMIC(CPSFBoundNetDialog, CDialog)

CPSFBoundNetDialog::CPSFBoundNetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPSFBoundNetDialog::IDD, pParent)
{
	m_nCurDeviceType=-1;
}

CPSFBoundNetDialog::~CPSFBoundNetDialog()
{
}

void CPSFBoundNetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPSFBoundNetDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_DEVICE_TYPE_COMBO, &CPSFBoundNetDialog::OnCbnSelchangeDeviceTypeCombo)
	ON_BN_CLICKED(IDC_FORM_BOUNDNET, &CPSFBoundNetDialog::OnBnClickedFormBoundnet)
END_MESSAGE_MAP()


// CPSFBoundNetDialog ��Ϣ��������

BOOL CPSFBoundNetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;
	CComboBox*	pComboBox;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDNET_DEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBoundNetDevice)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBoundNetDevice[i],	LVCFMT_LEFT,	100);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVICE_TYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(lpszPSFDeviceType)/sizeof(char*); i++)
		pComboBox->AddString(lpszPSFDeviceType[i]);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPSFBoundNetDialog::OnCbnSelchangeDeviceTypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox;
	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVICE_TYPE_COMBO);
	int		nType=pComboBox->GetCurSel();
	if (nType == CB_ERR)
		return;

	RefreshBoundNetDevice(nType);
}

void CPSFBoundNetDialog::OnBnClickedFormBoundnet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PG2PSF.FormPSFBoundNet(&g_PSFAscii);
}

void CPSFBoundNetDialog::RefreshBoundNetDevice(const int nDeviceType)
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDNET_DEVICE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	switch (nDeviceType)
	{
	case 0:	//	ĸ��
		for (i=0; i<(int)g_PG2PSF.m_PSFBoundNetBusArray.size(); i++)
		{
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetBusArray[i].szSub);
			nCol++;
			sprintf(szBuf,"%.2f", g_PG2PSF.m_PSFBoundNetBusArray[i].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetBusArray[i].szName);

			nRow++;
		}
		break;
	case 1:	//	������·��
		for (i=0; i<(int)g_PG2PSF.m_PSFBoundNetLineArray.size(); i++)
		{
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[g_PG2PSF.m_PSFBoundNetLineArray[i].nPSFIndex].nBus1Index].szSubstation);
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[g_PG2PSF.m_PSFBoundNetLineArray[i].nPSFIndex].nBus2Index].szSubstation);
			sprintf(szBuf,"%.2f", g_PG2PSF.m_PSFBoundNetLineArray[i].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetLineArray[i].szName);

			nRow++;
		}
		break;
	case 2:	//	��ѹ������
		for (i=0; i<(int)g_PG2PSF.m_PSFBoundNetTranArray.size(); i++)
		{
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetTranArray[i].szSub);
			sprintf(szBuf,"%.2f", g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[g_PG2PSF.m_PSFBoundNetTranArray[i].nPSFIndex].nBus1Index].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%.2f", g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[g_PG2PSF.m_PSFBoundNetTranArray[i].nPSFIndex].nBus2Index].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetTranArray[i].szName);

			nRow++;
		}
		break;
	case 3:	//	�����
		for (i=0; i<(int)g_PG2PSF.m_PSFBoundNetGenArray.size(); i++)
		{
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetGenArray[i].szSub);
			nCol++;
			sprintf(szBuf,"%.2f", g_PG2PSF.m_PSFBoundNetGenArray[i].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetGenArray[i].szName);

			nRow++;
		}
		break;
	case 4:	//	����
		for (i=0; i<(int)g_PG2PSF.m_PSFBoundNetLoadArray.size(); i++)
		{
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetLoadArray[i].szSub);
			nCol++;
			sprintf(szBuf,"%.2f", g_PG2PSF.m_PSFBoundNetLoadArray[i].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetLoadArray[i].szName);

			nRow++;
		}
		break;
	case 5:	//	����
		for (i=0; i<(int)g_PG2PSF.m_PSFBoundNetCapArray.size(); i++)
		{
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetCapArray[i].szSub);
			nCol++;
			sprintf(szBuf,"%.2f", g_PG2PSF.m_PSFBoundNetCapArray[i].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PSFBoundNetCapArray[i].szName);

			nRow++;
		}
		break;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBoundNetDevice)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}
