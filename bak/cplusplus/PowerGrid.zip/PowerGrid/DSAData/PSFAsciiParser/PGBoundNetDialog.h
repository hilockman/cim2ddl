#pragma once
#include "../PG2PSFAscii.h"

// CPGBoundNetDialog �Ի���
class CPGBoundNetDialog : public CDialog
{
	DECLARE_DYNAMIC(CPGBoundNetDialog)

public:
	CPGBoundNetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPGBoundNetDialog();

	void RefreshUI();

// �Ի�������
	enum { IDD = IDD_PGBOUNDNET_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnCbnSelchangeSubstationFilterCombo();
	afx_msg void OnCbnSelchangeVoltagelevelFilterCombo();
	afx_msg void OnCbnSelchangeDeviceTypeCombo();
	afx_msg void OnBnClickedAddButton();
	afx_msg void OnBnClickedDelButton();
	afx_msg void OnBnClickedFormBoundnet();
	afx_msg void OnNMClickLineList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedFormPsfascii();
	DECLARE_MESSAGE_MAP()
private:
	int				m_nCurDeviceType;

	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndListPSFArea,m_wndListPSFZone,m_wndListPSFBus,m_wndListPSFGen,m_wndListPSFLoad,m_wndListPSFCap,m_wndListPSFLine,m_wndListPSFTran;

private:
	void	RefreshBoundNetDevice();
	void	RefreshPSFAreaList();
	void	RefreshPSFZoneList();
	void	RefreshPSFBusList();
	void	RefreshPSFGenList();
	void	RefreshPSFLoadList();
	void	RefreshPSFCapList();
	void	RefreshPSFLineList();
	void	RefreshPSFTranList();
};
