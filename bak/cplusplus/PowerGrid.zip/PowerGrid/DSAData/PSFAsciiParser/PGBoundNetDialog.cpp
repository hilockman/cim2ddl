PGBoundNetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PGBoundNetDialog.h"

// CPGBoundNetDialog �Ի���

IMPLEMENT_DYNAMIC(CPGBoundNetDialog, CDialog)

CPGBoundNetDialog::CPGBoundNetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPGBoundNetDialog::IDD, pParent)
{
	m_nCurDeviceType=-1;
}

CPGBoundNetDialog::~CPGBoundNetDialog()
{
}

void CPGBoundNetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPGBoundNetDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_DEVICE_TYPE_COMBO, &CPGBoundNetDialog::OnCbnSelchangeDeviceTypeCombo)
	ON_BN_CLICKED(IDC_FORM_BOUNDNET, &CPGBoundNetDialog::OnBnClickedFormBoundnet)
	ON_BN_CLICKED(IDC_FORM_PSFASCII, &CPGBoundNetDialog::OnBnClickedFormPsfascii)
END_MESSAGE_MAP()


// CPGBoundNetDialog ��Ϣ��������

BOOL CPGBoundNetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;
	CComboBox*	pComboBox;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDNET_DEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBoundNetDevice)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBoundNetDevice[i],	LVCFMT_LEFT,	100);

	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVICE_TYPE_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<sizeof(lpszPGDeviceType)/sizeof(char*); i++)
		pComboBox->AddString(lpszPGDeviceType[i]);

	int		nColumn;
	CRect	rectBuf;

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndListPSFBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 11))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFBus.SetExtendedStyle(m_wndListPSFBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFBus.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFBusColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFBus.InsertColumn(nColumn+1, g_PSFBusColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFGen.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 12))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFGen.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFGen.SetExtendedStyle(m_wndListPSFGen.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFGen.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFGen.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFGeneratorColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFGen.InsertColumn(nColumn+1, g_PSFGeneratorColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFLoad.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 13))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFLoad.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFLoad.SetExtendedStyle(m_wndListPSFLoad.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFLoad.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFLoad.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFLoadColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFLoad.InsertColumn(nColumn+1, g_PSFLoadColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFCap.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 14))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFCap.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFCap.SetExtendedStyle(m_wndListPSFCap.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFCap.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFCap.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFFixedShuntColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFCap.InsertColumn(nColumn+1, g_PSFFixedShuntColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 15))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFLine.SetExtendedStyle(m_wndListPSFLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFLine.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFLineColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFLine.InsertColumn(nColumn+1, g_PSFLineColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 16))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFTran.SetExtendedStyle(m_wndListPSFTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFTran.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFFixedTransformerColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFTran.InsertColumn(nColumn+1, g_PSFFixedTransformerColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFArea.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 16))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFArea.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFArea.SetExtendedStyle(m_wndListPSFArea.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFArea.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFArea.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFAreaInterchangeColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFArea.InsertColumn(nColumn+1, g_PSFAreaInterchangeColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	if (!m_wndListPSFZone.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT ,rectBuf, &m_wndTab, 16))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndListPSFZone.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndListPSFZone.SetExtendedStyle(m_wndListPSFZone.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndListPSFZone.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndListPSFZone.InsertColumn(0, "���",	LVCFMT_LEFT,	100);
	for (nColumn=0; nColumn<sizeof(g_PSFZoneColumn)/sizeof(tagPSFModelField); nColumn++)
		m_wndListPSFZone.InsertColumn(nColumn+1, g_PSFZoneColumn[nColumn].lpszCnDesp,	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndListPSFArea, g_PSFModelTables[PSFModel_AreaInterchange].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFZone, g_PSFModelTables[PSFModel_Zone].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFBus, g_PSFModelTables[PSFModel_Bus].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFGen, g_PSFModelTables[PSFModel_Generator].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFLoad, g_PSFModelTables[PSFModel_Load].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFCap, g_PSFModelTables[PSFModel_FixedShunt].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFLine, g_PSFModelTables[PSFModel_Line].lpszModelDesp, -1, FALSE);
	m_wndTab.AddTab (&m_wndListPSFTran, g_PSFModelTables[PSFModel_FixedTransformer].lpszModelDesp, -1, FALSE);

	RefreshUI();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPGBoundNetDialog::RefreshUI()
{
	RefreshBoundNetDevice();
	RefreshPSFAreaList();
	RefreshPSFZoneList();
	RefreshPSFBusList();
	RefreshPSFGenList();
	RefreshPSFLoadList();
	RefreshPSFCapList();
	RefreshPSFLineList();
	RefreshPSFTranList();
}

void CPGBoundNetDialog::OnCbnSelchangeDeviceTypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshBoundNetDevice();
}

void CPGBoundNetDialog::OnBnClickedFormBoundnet()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
		g_PG2PSF.FormPGBoundNet(g_pPGBlock);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("FormPGBoundNet��ϣ���ʱ%d����", nDur);
}

void CPGBoundNetDialog::RefreshBoundNetDevice()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDNET_DEVICE_LIST);
	pListCtrl->DeleteAllItems();

	CComboBox*	pComboBox;
	pComboBox=(CComboBox*)GetDlgItem(IDC_DEVICE_TYPE_COMBO);
	int		nType=pComboBox->GetCurSel();
	if (nType == CB_ERR)
		return;

	nRow=0;
	switch (nType)
	{
	case 0:	//	ĸ��
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetBusArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetBusArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetBusArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetBusArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetBusArray[i].szName);

			nRow++;
		}
		break;
	case 1:	//	������·��
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetLineArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetLineArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;

			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[g_PG2PSF.m_PGBoundNetLineArray[i].nPGIndex].szSubI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[g_PG2PSF.m_PGBoundNetLineArray[i].nPGIndex].szSubZ);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetLineArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetLineArray[i].szName);

			nRow++;
		}
		break;
	case 2:	//	��ѹ������
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetTranArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetTranArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetTranArray[i].szSub);
			nCol++;
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetTranArray[i].szName);

			nRow++;
		}
		break;
	case 3:	//	�����
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetGenArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetGenArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetGenArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetGenArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetGenArray[i].szName);

			nRow++;
		}
		break;
	case 4:	//	����
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetLoadArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetLoadArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetLoadArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetLoadArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetLoadArray[i].szName);

			nRow++;
		}
		break;
	case 5:	//	����
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetCapArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetCapArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetCapArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetCapArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetCapArray[i].szName);

			nRow++;
		}
		break;
	case 6:	//	��·��
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetBreakerArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetBreakerArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetBreakerArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetBreakerArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetBreakerArray[i].szName);

			nRow++;
		}
		break;
	case 7:	//	���뿪��
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetDisconnectorArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetDisconnectorArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetDisconnectorArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetDisconnectorArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetDisconnectorArray[i].szName);

			nRow++;
		}
		break;
	case 8:	//	�ӵص�բ
		for (i=0; i<(int)g_PG2PSF.m_PGBoundNetGroundDisconnectorArray.size(); i++)
		{
			sprintf(szBuf,"%d/%d",nRow+1,g_PG2PSF.m_PGBoundNetGroundDisconnectorArray.size());	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetGroundDisconnectorArray[i].szSub);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetGroundDisconnectorArray[i].szVolt);
			pListCtrl->SetItemText(nRow, nCol++, g_PG2PSF.m_PGBoundNetGroundDisconnectorArray[i].szName);

			nRow++;
		}
		break;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBoundNetDevice)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::OnBnClickedFormPsfascii()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	g_PG2PSF.FormPGBoundPSF(g_pPGBlock, &g_PSFAscii, g_strPowerNetName.c_str(), g_strWorkZoneArray);

	RefreshPSFAreaList();
	RefreshPSFZoneList();
	RefreshPSFBusList();
	RefreshPSFGenList();
	RefreshPSFLoadList();
	RefreshPSFCapList();
	RefreshPSFLineList();
	RefreshPSFTranList();
}

void CPGBoundNetDialog::RefreshPSFAreaList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFArea.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFAreaArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFArea.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_AreaInterchange].nFieldNum; nField++)
			m_wndListPSFArea.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_AreaInterchange, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFAreaInterchangeColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFArea.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFArea.GetColumnWidth(nCol);
		m_wndListPSFArea.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFArea.GetColumnWidth(nCol);

		m_wndListPSFArea.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFZoneList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFZone.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFZoneArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFZone.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_Zone].nFieldNum; nField++)
			m_wndListPSFZone.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_Zone, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFZoneColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFZone.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFZone.GetColumnWidth(nCol);
		m_wndListPSFZone.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFZone.GetColumnWidth(nCol);

		m_wndListPSFZone.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFBusList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFBus.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFBusArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFBus.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_Bus].nFieldNum; nField++)
			m_wndListPSFBus.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_Bus, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFBusColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFBus.GetColumnWidth(nCol);
		m_wndListPSFBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFBus.GetColumnWidth(nCol);

		m_wndListPSFBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFGenList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFGen.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFGenArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFGen.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_Generator].nFieldNum; nField++)
			m_wndListPSFGen.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_Generator, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFGeneratorColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFGen.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFGen.GetColumnWidth(nCol);
		m_wndListPSFGen.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFGen.GetColumnWidth(nCol);

		m_wndListPSFGen.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFLoadList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFLoad.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFLoadArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFLoad.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_Load].nFieldNum; nField++)
			m_wndListPSFLoad.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_Load, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFLoadColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFLoad.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFLoad.GetColumnWidth(nCol);
		m_wndListPSFLoad.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFLoad.GetColumnWidth(nCol);

		m_wndListPSFLoad.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFCapList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFCap.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFCapArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFCap.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_FixedShunt].nFieldNum; nField++)
			m_wndListPSFCap.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_FixedShunt, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFFixedShuntColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFCap.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFCap.GetColumnWidth(nCol);
		m_wndListPSFCap.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFCap.GetColumnWidth(nCol);

		m_wndListPSFCap.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFLineList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFLine.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFLineArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFLine.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_Line].nFieldNum; nField++)
			m_wndListPSFLine.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_Line, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFLineColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFLine.GetColumnWidth(nCol);
		m_wndListPSFLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFLine.GetColumnWidth(nCol);

		m_wndListPSFLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPGBoundNetDialog::RefreshPSFTranList()
{
	int		nCol,nDev,nField;
	char	szBuf[260];

	m_wndListPSFTran.DeleteAllItems();

	for (nDev=0; nDev<(int)g_PG2PSF.m_PG2PSFTranArray.size(); nDev++)
	{
		sprintf(szBuf,"%d",nDev+1);
		m_wndListPSFTran.InsertItem(nDev, szBuf);

		nCol=1;
		for (nField=0; nField<g_PSFModelTables[PSFModel_FixedTransformer].nFieldNum; nField++)
			m_wndListPSFTran.SetItemText(nDev, nCol++, g_PG2PSF.GetPG2PSFDataString(PSFModel_FixedTransformer, nField, nDev).c_str());
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_PSFFixedTransformerColumn)/sizeof(tagPSFModelField)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndListPSFTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndListPSFTran.GetColumnWidth(nCol);
		m_wndListPSFTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndListPSFTran.GetColumnWidth(nCol);

		m_wndListPSFTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}
