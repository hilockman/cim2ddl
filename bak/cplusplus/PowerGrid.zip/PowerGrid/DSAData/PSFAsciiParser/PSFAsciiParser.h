
// PSFAsciiParser.h : PSFAsciiParser Ӧ�ó������ͷ�ļ�
//
#pragma once

#ifndef __AFXWIN_H__
	#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"       // ������

#include "../PSFAscii.h"
#include "../PG2PSFAscii.h"

#define UM_TABLE_CHANGED	WM_APP+100
#define	UM_UPDATECAPTIONBAR	WM_APP+101
#define	UM_UPDATEPROPERTIES	WM_APP+102
#define	UM_UPDATEDBASE		WM_APP+103

#define PGMEMVIEWMENUCMD	WM_APP+200

// CPSFAsciiParserApp:
// �йش����ʵ�֣������ PSFAsciiParser.cpp
//

class CPSFAsciiParserApp : public CWinAppEx
{
public:
	CPSFAsciiParserApp();


// ��д
public:
	virtual BOOL InitInstance();

// ʵ��
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CPSFAsciiParserApp	theApp;
extern	CPSFAscii		g_PSFAscii;
extern	CPG2PSFAscii	g_PG2PSF;
extern	tagPGBlock*		g_pPGBlock;
extern	char			g_szRunDir[260];
extern	double			g_fZIL;
extern	std::string		g_strPowerNetName;
extern	std::vector<std::string>	g_strWorkZoneArray;
extern	unsigned char	g_bCheckValidateWhenImport;
extern	unsigned char	g_bSetPlantRTLoad;

extern	void	ReadIni(void);
extern	void	SaveIni(void);
extern	LONG	RegDeleteAllKeys(HKEY hKeyDelete, LPCTSTR pszSubKey);
extern	int		StartProcess(char* lpszCmd, char* lpszPath);
extern	void	SaveListAsExcel(CListCtrl* pListCtrl, const char* lpszExcelSheetName, const char* lpszFileName, const unsigned char bShowExcel);

extern	void	Log(const char* lpszFormat, ...);
extern	void	ClearLog();
extern	void	ClearMessage();
extern	void	PrintMessage(const char* lpszFormat, ...);

extern	void	FormatRealData(char* lpszReal);

