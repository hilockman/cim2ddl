#pragma once


// CPSFSetupDialog �Ի���

class CPSFSetupDialog : public CDialog
{
	DECLARE_DYNAMIC(CPSFSetupDialog)

public:
	CPSFSetupDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPSFSetupDialog();

// �Ի�������
	enum { IDD = IDD_SETUP_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedCheck();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedDelall();

	DECLARE_MESSAGE_MAP()
private:
	void RefreshTielineList();
	void RefreshWorkArea(void);
public:
};
