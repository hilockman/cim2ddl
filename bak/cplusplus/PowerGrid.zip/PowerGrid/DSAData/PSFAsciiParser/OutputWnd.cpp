
#include "stdafx.h"
#include "PSFAsciiParser.h"

#include "OutputWnd.h"
#include "Resource.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COutputBar

COutputWnd::COutputWnd()
{
	m_nDialogCounter=0;
	m_nDialogTimeout=1;
}

COutputWnd::~COutputWnd()
{
}

BEGIN_MESSAGE_MAP(COutputWnd, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

int COutputWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_Font.CreateStockObject(DEFAULT_GUI_FONT);

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// ����ѡ�����:
	if (!m_wndTabs.Create(CMFCTabCtrl::STYLE_FLAT, rectDummy, this, 1))
	{
		TRACE0("δ�ܴ������ѡ�����\n");
		return -1;      // δ�ܴ���
	}

	// �����������:
	const DWORD dwStyle = LBS_NOINTEGRALHEIGHT | WS_CHILD | WS_VISIBLE | WS_HSCROLL | WS_VSCROLL;
	if (!m_wndMesgList.Create(dwStyle, rectDummy, &m_wndTabs, 2))
	{
		TRACE0("δ�ܴ�������б�\n");
		return -1;      // δ�ܴ���
	}

	m_wndMesgList.SetFont(&m_Font);
	m_wndMesgList.ResetContent();

	m_wndTabs.AddTab(&m_wndMesgList, "��Ϣ����", (UINT)0);

	m_nDialogTimer=SetTimer(ID_DIALOG_TIMER,DIALOG_STEP_PACE,NULL);
	if (m_nDialogTimer == 0)
	{
		AfxMessageBox("������ʱ������");
	}

	return 0;
}

void COutputWnd::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	// ѡ��ؼ�Ӧ��������������:
	m_wndTabs.SetWindowPos (NULL, -1, -1, cx, cy, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOZORDER);
}

void COutputWnd::AdjustHorzScroll(CListBox& wndListBox)
{
	CClientDC dc(this);
	CFont* pOldFont = dc.SelectObject(&m_Font);

	int cxExtentMax = 0;

	for (int i = 0; i < wndListBox.GetCount(); i ++)
	{
		CString strItem;
		wndListBox.GetText(i, strItem);

		cxExtentMax = max(cxExtentMax, dc.GetTextExtent(strItem).cx);
	}

	wndListBox.SetHorizontalExtent(cxExtentMax);
	dc.SelectObject(pOldFont);
}

/////////////////////////////////////////////////////////////////////////////
// COutputList1

COutputList::COutputList()
{
}

COutputList::~COutputList()
{
}

BEGIN_MESSAGE_MAP(COutputList, CListBox)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_VIEW_OUTPUTWND, OnViewOutput)
	ON_WM_WINDOWPOSCHANGING()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND_RANGE(PGMEMVIEWMENUCMD+1,	PGMEMVIEWMENUCMD+10,	OnListMenuCmd)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// COutputList ��Ϣ��������

void COutputList::OnContextMenu(CWnd* /*pWnd*/, CPoint point)
{
	CMenu menu;
	menu.LoadMenu(IDR_OUTPUT_POPUP);

	CMenu* pSumMenu = menu.GetSubMenu(0);

	if (AfxGetMainWnd()->IsKindOf(RUNTIME_CLASS(CMDIFrameWndEx)))
	{
		CMFCPopupMenu* pPopupMenu = new CMFCPopupMenu;

		if (!pPopupMenu->Create(this, point.x, point.y, (HMENU)pSumMenu->m_hMenu, FALSE, TRUE))
			return;

		((CMDIFrameWndEx*)AfxGetMainWnd())->OnShowPopupMenu(pPopupMenu);
		UpdateDialogControls(this, FALSE);
	}

	SetFocus();
}

void COutputList::OnViewOutput()
{
	CDockablePane* pParentBar = DYNAMIC_DOWNCAST(CDockablePane, GetOwner());
	CMDIFrameWndEx* pMainFrame = DYNAMIC_DOWNCAST(CMDIFrameWndEx, GetTopLevelFrame());

	if (pMainFrame != NULL && pParentBar != NULL)
	{
		pMainFrame->SetFocus();
		pMainFrame->ShowPane(pParentBar, FALSE, FALSE, FALSE);
		pMainFrame->RecalcLayout();

	}
}

void COutputList::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	CMenu	menu;
	CPoint	pt;

	GetCursorPos(&pt);

	menu.CreatePopupMenu();
	menu.AppendMenu(MF_STRING|MF_ENABLED,	PGMEMVIEWMENUCMD+1,	_T("���"));
	menu.AppendMenu(MF_STRING|MF_ENABLED,	PGMEMVIEWMENUCMD+2,	_T("���"));

	menu.TrackPopupMenu(TPM_LEFTBUTTON|TPM_LEFTALIGN, pt.x, pt.y, this);

	menu.DestroyMenu();

	CListBox::OnRButtonDown(nFlags, point);
}

void COutputList::OnListMenuCmd(UINT nID)
{
	switch (nID)
	{
	case PGMEMVIEWMENUCMD+1:
		{
			ResetContent();
		}
		break;
	case PGMEMVIEWMENUCMD+2:
		{
			register int	i;
			char	szFileName[260],szText[260];
			CString	strPath;
			FILE*	fp;
			theApp.GetShellManager()->BrowseForFolder(strPath,NULL,NULL,"��ȷ���ļ�����Ŀ¼");

			sprintf(szFileName,"%s/DsaPSFAsciiViewMesg.txt",strPath);
			fp=fopen(szFileName,"w");
			if (fp != NULL)
			{
				for (i=0; i<GetCount(); i++)
				{
					GetText(i,szText);
					fprintf(fp,"%s\n",szText);
				}
				fflush(fp);
				fclose(fp);
			}
		}
		break;
	default:
		break;
	}
}


void COutputWnd::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ
	if (nIDEvent == ID_DIALOG_TIMER)
	{
		if (m_nDialogCounter > m_nDialogTimeout)
		{
			m_nDialogCounter=0;
		}
		else
		{
			m_nDialogCounter++;
		}
	}

	CDockablePane::OnTimer(nIDEvent);
}

void COutputWnd::OnDestroy()
{
	CDockablePane::OnDestroy();

	// TODO: �ڴ˴�������Ϣ�����������
	KillTimer(m_nDialogTimer);
}
