// PG2PSFMatchDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PG2PSFMatchDialog.h"
#include "SubstationDeviceDialog.h"

// CPG2PSFMatchDialog �Ի���
static	char*	lpszOfflineColumn[]=
{
	"���",
	"��������",
	"������Ϣ",
	"����ģ��",
};

static	char*	lpszRTColumn[]=
{
	"���",
	"����",
	"������Ϣ",
	"�������",
};

IMPLEMENT_DYNAMIC(CPG2PSFMatchDialog, CDialog)

CPG2PSFMatchDialog::CPG2PSFMatchDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPG2PSFMatchDialog::IDD, pParent)
{
	m_nDeviceType=0;
	memset(m_szFilterOfflineZone, 0, MDB_CHARLEN_TINY);
	memset(m_szFilterOfflineSub, 0, MDB_CHARLEN_SHORT);
	memset(m_szFilterOfflineZone, 0, MDB_CHARLEN_TINY);
	memset(m_szFilterRTSub, 0, MDB_CHARLEN_SHORT);

	m_nCurSearch=-1;
	m_bShowNoMatchOnly=0;
}

CPG2PSFMatchDialog::~CPG2PSFMatchDialog()
{
}

void CPG2PSFMatchDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CPG2PSFMatchDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_OFFLINEZONE_COMBO, &CPG2PSFMatchDialog::OnCbnSelchangeOfflineZoneCombo)
	ON_CBN_SELCHANGE(IDC_PGZONE_COMBO, &CPG2PSFMatchDialog::OnCbnSelchangeRTZoneCombo)
	ON_BN_CLICKED(IDC_DELMATCH, &CPG2PSFMatchDialog::OnBnClickedDelmatch)
	ON_BN_CLICKED(IDC_ADDMATCH, &CPG2PSFMatchDialog::OnBnClickedAddmatch)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_OFFLINEDEVICE_LIST, &CPG2PSFMatchDialog::OnLvnItemchangedOfflineSubList)
	ON_BN_CLICKED(IDC_AUTO_MATCH, &CPG2PSFMatchDialog::OnBnClickedAutoMatch)
	ON_BN_CLICKED(IDC_REFRESH, &CPG2PSFMatchDialog::OnBnClickedRefresh)
	ON_CBN_SELCHANGE(IDC_DEVICETYPE_COMBO, &CPG2PSFMatchDialog::OnCbnSelchangeDevicetypeCombo)
	ON_BN_CLICKED(IDC_SAVE_MATCH, &CPG2PSFMatchDialog::OnBnClickedSaveMatch)
	ON_BN_CLICKED(IDC_SEARCH_BUTTON, &CPG2PSFMatchDialog::OnBnClickedSearchButton)
	ON_BN_CLICKED(IDC_READ_MATCH, &CPG2PSFMatchDialog::OnBnClickedReadMatch)
	ON_CBN_SELCHANGE(IDC_OFFLINESUB_COMBO, &CPG2PSFMatchDialog::OnCbnSelchangeOfflineSubCombo)
	ON_CBN_SELCHANGE(IDC_RTSUB_COMBO, &CPG2PSFMatchDialog::OnCbnSelchangeRTSubCombo)
	ON_BN_CLICKED(IDC_SHOW_NOMATCH_ONLY, &CPG2PSFMatchDialog::OnBnClickedShowNomatchOnly)
END_MESSAGE_MAP()


// CPG2PSFMatchDialog ��Ϣ��������

BOOL CPG2PSFMatchDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFLINEDEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	//pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszOfflineColumn)/sizeof(char*); i++)
	{
		pListCtrl->InsertColumn(i, lpszOfflineColumn[i]);
		pListCtrl->SetColumnWidth(i, 50);
	}

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTDEVICE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	//pListCtrl->SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszRTColumn)/sizeof(char*); i++)
	{
		pListCtrl->InsertColumn(i, lpszRTColumn[i]);
		pListCtrl->SetColumnWidth(i, 50);
	}
	pListCtrl->DeleteAllItems();

	CComboBox*	pCombo;
	pCombo=(CComboBox*)GetDlgItem(IDC_DEVICETYPE_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("��վ");
	pCombo->AddString("��·");
	pCombo->AddString("��ѹ��");
	pCombo->AddString("�����");
	pCombo->SetCurSel(m_nDeviceType);

	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOW_NOMATCH_ONLY);
	pButton->SetCheck(m_bShowNoMatchOnly);

	Refresh();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPG2PSFMatchDialog::Refresh()
{
	register int	i,j;
	CComboBox*	pCombo;
	int		nSub,nFind;

	pCombo=(CComboBox*)GetDlgItem(IDC_OFFLINEZONE_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<(int)g_PSFAscii.m_PSFZoneArray.size(); i++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			nFind=-1;
			for (j=0; j<(int)g_strWorkZoneArray.size(); j++)
			{
				if (strcmp(g_strWorkZoneArray[j].c_str(), g_PSFAscii.m_PSFZoneArray[i].szName) == 0)
				{
					nFind=j;
					break;
				}
			}
			if (nFind < 0)
				continue;
		}
		pCombo->AddString(g_PSFAscii.m_PSFZoneArray[i].szName);
	}
	nFind=pCombo->FindString(-1, m_szFilterOfflineZone);
	if (nFind != CB_ERR)
		pCombo->SetCurSel(nFind);

	pCombo=(CComboBox*)GetDlgItem(IDC_OFFLINESUB_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (nSub=0; nSub<(int)g_PSFAscii.m_SubstationArray.size(); nSub++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); i++)
			{
				for (j=0; j<(int)g_strWorkZoneArray.size(); j++)
				{
					if (strcmp(g_strWorkZoneArray[j].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].szZoneName) == 0)
					{
						nFind=1;
						break;
					}
				}
				if (nFind)	break;
			}
			if (!nFind)
				continue;
		}
		if (strlen(m_szFilterOfflineZone) > 0)
		{
			nFind=0;
			for (i=0; i<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); i++)
			{
				if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].szZoneName, m_szFilterOfflineZone) == 0)
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
				continue;
		}
		pCombo->AddString(g_PSFAscii.m_SubstationArray[nSub].szName);
	}
	nFind=pCombo->FindString(-1, m_szFilterOfflineSub);
	if (nFind != CB_ERR)
		pCombo->SetCurSel(nFind);

	pCombo=(CComboBox*)GetDlgItem(IDC_PGZONE_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pCombo->AddString(g_pPGBlock->m_SubControlAreaArray[i].szName);
	nFind=pCombo->FindString(-1, m_szFilterRTZone);
	if (nFind != CB_ERR)
		pCombo->SetCurSel(nFind);

	pCombo=(CComboBox*)GetDlgItem(IDC_RTSUB_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pCombo->AddString(g_pPGBlock->m_SubstationArray[i].szName);
	nFind=pCombo->FindString(-1, m_szFilterRTSub);
	if (nFind != CB_ERR)
		pCombo->SetCurSel(nFind);

	RefreshRTDeviceList();
	RefreshOfflineDeviceList();
}

void CPG2PSFMatchDialog::OnCbnSelchangeOfflineZoneCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i,j;
	int		nSub;
	unsigned char	bInArea;
	CComboBox*	pCombo;

	memset(m_szFilterOfflineZone, 0, MDB_CHARLEN_TINY);
	memset(m_szFilterOfflineSub, 0, MDB_CHARLEN_TINY);
	
	pCombo=(CComboBox*)GetDlgItem(IDC_OFFLINEZONE_COMBO);
	int			nDiv=pCombo->GetCurSel();
	if (nDiv != CB_ERR)
		pCombo->GetLBText(nDiv, m_szFilterOfflineZone);

	pCombo=(CComboBox*)GetDlgItem(IDC_OFFLINESUB_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (nSub=0; nSub<(int)g_PSFAscii.m_SubstationArray.size(); nSub++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			bInArea=0;
			for (i=0; i<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); i++)
			{
				for (j=0; j<(int)g_strWorkZoneArray.size(); j++)
				{
					if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].szZoneName, g_strWorkZoneArray[j].c_str()) == 0)
					{
						bInArea=1;
						break;
					}
				}
				if (bInArea)	break;
			}
			if (!bInArea)
				continue;
		}

		if (strlen(m_szFilterOfflineZone) > 0)
		{
			bInArea=0;
			for (i=0; i<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); i++)
			{
				if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].szZoneName, m_szFilterOfflineZone) == 0)
				{
					bInArea=1;
					break;
				}
			}
			if (!bInArea)
				continue;
		}
		pCombo->AddString(g_PSFAscii.m_SubstationArray[nSub].szName);
	}

	RefreshOfflineDeviceList();
}

void CPG2PSFMatchDialog::OnCbnSelchangeRTZoneCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CComboBox*	pCombo;
	
	memset(m_szFilterRTZone, 0, MDB_CHARLEN_SHORT);
	memset(m_szFilterRTSub, 0, MDB_CHARLEN_SHORT);
	pCombo=(CComboBox*)GetDlgItem(IDC_PGZONE_COMBO);
	int			nDiv=pCombo->GetCurSel();
	if (nDiv != CB_ERR)
		pCombo->GetLBText(nDiv, m_szFilterRTZone);

	pCombo=(CComboBox*)GetDlgItem(IDC_RTSUB_COMBO);
	pCombo->ResetContent();
	pCombo->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		if (strlen(m_szFilterRTZone) > 0)
		{
			if (strcmp(g_pPGBlock->m_SubstationArray[i].szDiv, m_szFilterRTZone) != 0)
				continue;
		}
		pCombo->AddString(g_pPGBlock->m_SubstationArray[i].szName);
	}

	RefreshRTDeviceList();
}

void CPG2PSFMatchDialog::OnCbnSelchangeOfflineSubCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	memset(m_szFilterOfflineSub, 0, MDB_CHARLEN_TINY);
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_OFFLINESUB_COMBO);
	int			nSub=pCombo->GetCurSel();
	if (nSub != CB_ERR)
		pCombo->GetLBText(nSub, m_szFilterOfflineSub);

	RefreshOfflineDeviceList();
}

void CPG2PSFMatchDialog::OnCbnSelchangeRTSubCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	memset(m_szFilterRTSub, 0, MDB_CHARLEN_SHORT);
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_RTSUB_COMBO);
	int			nSub=pCombo->GetCurSel();
	if (nSub != CB_ERR)
		pCombo->GetLBText(nSub, m_szFilterRTSub);

	RefreshRTDeviceList();
}

void CPG2PSFMatchDialog::OnBnClickedDelmatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nOfflineRecord=-1;
	char	szOfflineRT[MDB_CHARLEN_SHORT];
	CListCtrl*	pListCtrl;
	POSITION pos;
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFLINEDEVICE_LIST);
	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
		nOfflineRecord=pListCtrl->GetNextSelectedItem(pos);
	if (nOfflineRecord < 0)
	{
		AfxMessageBox("��ȷ����ɾ�������������豸");
		return;
	}
	strcpy(szOfflineRT, pListCtrl->GetItemText(nOfflineRecord, 1));

	switch (m_nDeviceType)
	{
	case 0:
		for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_SubstationArray[i].szName) == 0)
			{
				memset(g_PSFAscii.m_SubstationArray[i].szRTName, 0, MDB_CHARLEN);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	case 1:
		for (i=0; i<(int)g_PSFAscii.m_PSFLineArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_PSFLineArray[i].szPSFName) == 0)
			{
				memset(g_PSFAscii.m_PSFLineArray[i].szRTName, 0, MDB_CHARLEN);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	case 2:
		for (i=0; i<(int)g_PSFAscii.m_PSFFixedTranArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_PSFFixedTranArray[i].szPSFName) == 0)
			{
				memset(g_PSFAscii.m_PSFFixedTranArray[i].szRTName, 0, MDB_CHARLEN);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	case 3:
		for (i=0; i<(int)g_PSFAscii.m_PSFGeneratorArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_PSFGeneratorArray[i].szRTName) == 0)
			{
				memset(g_PSFAscii.m_PSFGeneratorArray[i].szRTName, 0, MDB_CHARLEN);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	}
}

void CPG2PSFMatchDialog::OnBnClickedAddmatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nOfflineRecord=-1,nRTRecord=-1;
	char	szOfflineRT[MDB_CHARLEN],szRTRec[MDB_CHARLEN];

	POSITION pos;
	CListCtrl*	pListCtrl;
	
	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTDEVICE_LIST);
	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
		nRTRecord=pListCtrl->GetNextSelectedItem(pos);
	if (nRTRecord < 0)
	{
		AfxMessageBox("��ȷ������������ģ���豸");
		return;
	}
	strcpy(szRTRec, pListCtrl->GetItemText(nRTRecord, 1));

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFLINEDEVICE_LIST);
	pos=pListCtrl->GetFirstSelectedItemPosition();
	while (pos)
		nOfflineRecord=pListCtrl->GetNextSelectedItem(pos);
	if (nOfflineRecord < 0)
	{
		AfxMessageBox("��ȷ���������������豸");
		return;
	}
	strcpy(szOfflineRT, pListCtrl->GetItemText(nOfflineRecord, 1));

	switch (m_nDeviceType)
	{
	case 0:
		for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_SubstationArray[i].szName) == 0)
			{
				strcpy(g_PSFAscii.m_SubstationArray[i].szRTName, szRTRec);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	case 1:
		for (i=0; i<(int)g_PSFAscii.m_PSFLineArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_PSFLineArray[i].szPSFName) == 0)
			{
				strcpy(g_PSFAscii.m_PSFLineArray[i].szRTName, szRTRec);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	case 2:
		for (i=0; i<(int)g_PSFAscii.m_PSFFixedTranArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_PSFFixedTranArray[i].szName) == 0)
			{
				strcpy(g_PSFAscii.m_PSFFixedTranArray[i].szRTName, szRTRec);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	case 3:
		for (i=0; i<(int)g_PSFAscii.m_PSFGeneratorArray.size(); i++)
		{
			if (strcmp(szOfflineRT, g_PSFAscii.m_PSFGeneratorArray[i].szRTName) == 0)
			{
				strcpy(g_PSFAscii.m_PSFGeneratorArray[i].szRTName, szRTRec);
				RefreshOfflineDeviceList();
				pListCtrl->EnsureVisible(nOfflineRecord, TRUE);
				break;
			}
		}
		break;
	}
}

void CPG2PSFMatchDialog::OnLvnItemchangedOfflineSubList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	*pResult = 0;
}

void CPG2PSFMatchDialog::RefreshOfflineDeviceList(void)
{
	register int	i;
	int		nRow,nCol,nSub,nDev;
	unsigned char	bIInArea,bZInArea;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFLINEDEVICE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	switch (m_nDeviceType)
	{
	case 0:
		for (nSub=0; nSub<(int)g_PSFAscii.m_SubstationArray.size(); nSub++)
		{
			if (!g_strWorkZoneArray.empty())
			{
				bIInArea=0;
				for (nDev=0; nDev<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); nDev++)
				{
					for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
					{
						if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[nDev]].szZoneName) == 0)
						{
							bIInArea=1;
							break;
						}
					}
					if (bIInArea)	break;
				}
				if (!bIInArea)
					continue;
			}

			if (strlen(m_szFilterOfflineZone) > 0)
			{
				bIInArea=0;
				for (nDev=0; nDev<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); nDev++)
				{
					if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[nDev]].szZoneName, m_szFilterOfflineZone) == 0)
					{
						bIInArea=1;
						break;
					}
				}
				if (!bIInArea)
					continue;
			}
			if (strlen(m_szFilterOfflineSub) > 0)
			{
				if (strcmp(m_szFilterOfflineSub, g_PSFAscii.m_SubstationArray[nSub].szName) != 0)
					continue;
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_SubstationArray[nSub].szName);
			nCol++;
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_SubstationArray[nSub].szRTName);

			nRow++;
		}
		break;
	case 1:
		for (nDev=0; nDev<(int)g_PSFAscii.m_PSFLineArray.size(); nDev++)
		{
			if (g_PSFAscii.m_PSFLineArray[nDev].nBus1Index < 0 || g_PSFAscii.m_PSFLineArray[nDev].nBus2Index < 0)
				continue;

			if (!g_strWorkZoneArray.empty())
			{
				bIInArea=bZInArea=0;
				for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
				{
					if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szZoneName) == 0)
					{
						bIInArea=1;
						break;
					}
				}
				for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
				{
					if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szZoneName) == 0)
					{
						bZInArea=1;
						break;
					}
				}
				if (!bIInArea && !bZInArea)
					continue;
			}

			if (strlen(m_szFilterOfflineZone) > 0)
			{
				if (strcmp(m_szFilterOfflineZone, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szZoneName) != 0 &&
					strcmp(m_szFilterOfflineZone, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szZoneName) != 0)
					continue;
			}
			if (strlen(m_szFilterOfflineSub) > 0)
			{
				if (strcmp(m_szFilterOfflineSub, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation) != 0 &&
					strcmp(m_szFilterOfflineSub, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation) != 0)
					continue;
			}

			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFLineArray[nDev].szPSFName);
			sprintf(szBuf,"%s <-> %s",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation,g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFLineArray[nDev].szRTName);

			nRow++;
		}
		break;
	case 2:
		for (nDev=0; nDev<(int)g_PSFAscii.m_PSFFixedTranArray.size(); nDev++)
		{
			if (g_PSFAscii.m_PSFFixedTranArray[nDev].nBus1Index < 0 || g_PSFAscii.m_PSFFixedTranArray[nDev].nBus2Index < 0)
				continue;

			if (!g_strWorkZoneArray.empty())
			{
				bIInArea=bZInArea=0;
				for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
				{
					if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus1Index].szZoneName) == 0)
					{
						bIInArea=1;
						break;
					}
				}
				for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
				{
					if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus2Index].szZoneName) == 0)
					{
						bZInArea=1;
						break;
					}
				}
				if (!bIInArea && !bZInArea)
					continue;
			}

			if (strlen(m_szFilterOfflineZone) > 0)
			{
				if (strcmp(m_szFilterOfflineZone, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus1Index].szZoneName) != 0 &&
					strcmp(m_szFilterOfflineZone, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus2Index].szZoneName) != 0)
					continue;
			}
			if (strlen(m_szFilterOfflineSub) > 0)
			{
				if (strcmp(m_szFilterOfflineSub, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus1Index].szSubstation) != 0 &&
					strcmp(m_szFilterOfflineSub, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus2Index].szSubstation) != 0)
					continue;
			}

			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFFixedTranArray[nDev].szPSFName);

			sprintf(szBuf,"%.2f <-> %.2f",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus1Index].fkV,g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFFixedTranArray[nDev].nBus2Index].fkV);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFFixedTranArray[nDev].szRTName);

			nRow++;
		}
		break;
	case 3:
		for (nDev=0; nDev<(int)g_PSFAscii.m_PSFGeneratorArray.size(); nDev++)
		{
			if (!g_strWorkZoneArray.empty())
			{
				bIInArea=0;
				for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
				{
					if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].szZoneName) == 0)
					{
						bIInArea=1;
						break;
					}
				}
				if (!bIInArea)
					continue;
			}

			if (strlen(m_szFilterOfflineSub) > 0)
			{
				nSub=-1;
				for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
				{
					if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].szSubstation, g_PSFAscii.m_SubstationArray[i].szName) == 0)
					{
						nSub=i;
						break;
					}
				}
				if (nSub <= 0)
					continue;

				if (strcmp(m_szFilterOfflineSub, g_PSFAscii.m_SubstationArray[nSub].szName) != 0)
					continue;
			}

			if (strlen(m_szFilterOfflineZone) > 0)
			{
				if (strcmp(m_szFilterOfflineZone, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].szZoneName) != 0)
					continue;
			}

			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);
			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFGeneratorArray[nDev].szBusName);
			sprintf(szBuf,"P=%.1f Q=%.1f PMax=%.1f QMax=%.1f",g_PSFAscii.m_PSFGeneratorArray[nDev].fMW, g_PSFAscii.m_PSFGeneratorArray[nDev].fMva, g_PSFAscii.m_PSFGeneratorArray[nDev].fPMax, g_PSFAscii.m_PSFGeneratorArray[nDev].fQMax);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);
			pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFGeneratorArray[nDev].szRTName);
			nRow++;
		}
		break;
	}
	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszOfflineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPG2PSFMatchDialog::RefreshRTDeviceList(void)
{
	register int	i;
	int		nRow,nCol,nSub,nVolt;
	int		nSubI,nSubJ;
	unsigned char	bMatched;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTDEVICE_LIST);
	pListCtrl->DeleteAllItems();

	m_nCurSearch=-1;

	nRow=0;
	switch (m_nDeviceType)
	{
	case 0:	//	��վ
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		{
			if (strlen(m_szFilterRTZone) > 0)
			{
				if (strcmp(m_szFilterRTZone, g_pPGBlock->m_SubstationArray[i].szDiv) != 0)
					continue;
			}
			if (strlen(m_szFilterRTSub) > 0)
			{
				if (strcmp(m_szFilterRTSub, g_pPGBlock->m_SubstationArray[i].szName) != 0)
					continue;
			}

			bMatched=g_PSFAscii.IsCimDeviceMatched(PSFModel_Substation, g_pPGBlock->m_SubstationArray[i].szName);
			if (m_bShowNoMatchOnly)
			{
				if (bMatched)
					continue;
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SubstationArray[i].szName);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SubstationArray[i].szDiv);

			sprintf(szBuf,"%d",bMatched);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}
		break;
	case 1:	//	��·
		for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (strlen(m_szFilterRTZone) > 0)
			{
				nSubI=PGGetSubIndex(g_pPGBlock, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
				nSubJ=PGGetSubIndex(g_pPGBlock, g_pPGBlock->m_ACLineSegmentArray[i].szSubZ);
				if (strcmp(m_szFilterRTZone, g_pPGBlock->m_SubstationArray[nSubI].szDiv) != 0 && strcmp(m_szFilterRTZone, g_pPGBlock->m_SubstationArray[nSubJ].szDiv) != 0)
					continue;
			}
			if (strlen(m_szFilterRTSub) > 0)
			{
				if (strcmp(m_szFilterRTSub, g_pPGBlock->m_ACLineSegmentArray[i].szSubI) != 0 &&
					strcmp(m_szFilterRTSub, g_pPGBlock->m_ACLineSegmentArray[i].szSubZ) != 0)
					continue;
			}

			bMatched=g_PSFAscii.IsCimDeviceMatched(PSFModel_Line, g_pPGBlock->m_ACLineSegmentArray[i].szName);
			if (m_bShowNoMatchOnly)
			{
				if (bMatched)
					continue;
			}
			sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

			nCol=1;
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szName);
			sprintf(szBuf,"(%s)%s <-> %s",g_pPGBlock->m_ACLineSegmentArray[i].szVoltI,g_pPGBlock->m_ACLineSegmentArray[i].szSubI,g_pPGBlock->m_ACLineSegmentArray[i].szSubZ);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf,"%d",bMatched);																						pListCtrl->SetItemText(nRow, nCol++, szBuf);

			nRow++;
		}

		break;
	case 2:	//	��ѹ��
		for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strlen(m_szFilterRTZone) > 0)
			{
				if (strcmp(m_szFilterRTZone, g_pPGBlock->m_SubstationArray[nSub].szDiv) != 0)
					continue;
			}
			if (strlen(m_szFilterRTSub) > 0)
			{
				if (strcmp(m_szFilterRTSub, g_pPGBlock->m_SubstationArray[nSub].szName) != 0)
					continue;
			}
			for (i=g_pPGBlock->m_SubstationArray[nSub].pRWind; i<g_pPGBlock->m_SubstationArray[nSub+1].pRWind; i++)
			{
				sprintf(szBuf,"%s,%s",g_pPGBlock->m_TransformerWindingArray[i].szSub,g_pPGBlock->m_TransformerWindingArray[i].szName);
				bMatched=g_PSFAscii.IsCimDeviceMatched(PSFModel_FixedTransformer, szBuf);
				if (m_bShowNoMatchOnly)
				{
					if (bMatched)
						continue;
				}

				sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

				nCol=1;
				sprintf(szBuf,"%s,%s",g_pPGBlock->m_TransformerWindingArray[i].szSub,g_pPGBlock->m_TransformerWindingArray[i].szName);
				pListCtrl->SetItemText(nRow, nCol++, szBuf);
				sprintf(szBuf,"%s <-> %s",g_pPGBlock->m_TransformerWindingArray[i].szVoltI,g_pPGBlock->m_TransformerWindingArray[i].szVoltZ);
				pListCtrl->SetItemText(nRow, nCol++, szBuf);

				sprintf(szBuf,"%d",bMatched);
				pListCtrl->SetItemText(nRow, nCol++, szBuf);

				nRow++;
			}
		}
		break;
	case 3:	//	�����
		for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			if (strlen(m_szFilterRTZone) > 0)
			{
				if (strcmp(m_szFilterRTZone, g_pPGBlock->m_SubstationArray[nSub].szDiv) != 0)
					continue;
			}
			if (strlen(m_szFilterRTSub) > 0)
			{
				if (strcmp(m_szFilterRTSub, g_pPGBlock->m_SubstationArray[nSub].szName) != 0)
					continue;
			}
			for (nVolt=g_pPGBlock->m_SubstationArray[nSub].pRkv; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].pRkv; nVolt++)
			{
				for (i=g_pPGBlock->m_VoltageLevelArray[nVolt].pRun; i<g_pPGBlock->m_VoltageLevelArray[nVolt+1].pRun; i++)
				{
					sprintf(szBuf,"%s,%s,%s",g_pPGBlock->m_SynchronousMachineArray[i].szSub,g_pPGBlock->m_SynchronousMachineArray[i].szVolt,g_pPGBlock->m_SynchronousMachineArray[i].szName);
					bMatched=g_PSFAscii.IsCimDeviceMatched(PSFModel_Generator, szBuf);
					if (m_bShowNoMatchOnly)
					{
						if (bMatched)
							continue;
					}

					sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

					nCol=1;
					sprintf(szBuf,"%s,%s,%s",g_pPGBlock->m_SynchronousMachineArray[i].szSub,g_pPGBlock->m_SynchronousMachineArray[i].szVolt,g_pPGBlock->m_SynchronousMachineArray[i].szName);
					pListCtrl->SetItemText(nRow, nCol++, szBuf);

					sprintf(szBuf,"%.1f %.1f %.1f %.3f",g_pPGBlock->m_SynchronousMachineArray[i].pmax,g_pPGBlock->m_SynchronousMachineArray[i].p,g_pPGBlock->m_SynchronousMachineArray[i].q,g_pPGBlock->m_SynchronousMachineArray[i].fPlanV);
					pListCtrl->SetItemText(nRow, nCol++, szBuf);

					sprintf(szBuf,"%d",bMatched);
					pListCtrl->SetItemText(nRow, nCol++, szBuf);

					nRow++;
				}
			}
		}
		break;
	}
	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszRTColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CPG2PSFMatchDialog::OnBnClickedAutoMatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg,dEnd;
	int		nDur;

	//char	szExec[260];

	dBeg=clock();

	g_PSFAscii.AutoPSFAscii2CimMatch(g_pPGBlock, 1, g_strWorkZoneArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�Զ�������ϣ���ʱ%d����\n",nDur);
	RefreshOfflineDeviceList();
}

void CPG2PSFMatchDialog::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Refresh();
}

void CPG2PSFMatchDialog::OnCbnSelchangeDevicetypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pCombo=(CComboBox*)GetDlgItem(IDC_DEVICETYPE_COMBO);
	m_nDeviceType=pCombo->GetCurSel();
	if (m_nDeviceType == CB_ERR)
		return;

	RefreshRTDeviceList();
	RefreshOfflineDeviceList();
}

void CPG2PSFMatchDialog::OnBnClickedReadMatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt *.dat)|*.txt;*.TXT;*.dat;*.DAT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("���ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
		g_PSFAscii.ReadPSFAscii2CimMatch(dlg.GetPathName());
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("������ȡ��ϣ���ʱ%d����\n",nDur);

	RefreshOfflineDeviceList();
}

void CPG2PSFMatchDialog::OnBnClickedSaveMatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt *.dat)|*.txt;*.TXT;*.dat;*.DAT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
		g_PSFAscii.SavePSFAscii2CimMatch(dlg.GetPathName());
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("����������ϣ���ʱ%d����\n",nDur);
}


void CPG2PSFMatchDialog::OnBnClickedSearchButton()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	char	szSearch[260];
	GetDlgItem(IDC_SEARCH_VALUE)->GetWindowText(szSearch, 260);

	unsigned char	bFind;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTDEVICE_LIST);

	if (m_nCurSearch < 0)
	{
		for (i=0; i<pListCtrl->GetItemCount(); i++)
		{
			if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
			{
				pListCtrl->EnsureVisible(i, TRUE);
				m_nCurSearch=i;
				break;
			}
		}
	}
	else
	{
		bFind=0;
		for (i=m_nCurSearch+1; i<pListCtrl->GetItemCount(); i++)
		{
			if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
			{
				pListCtrl->EnsureVisible(i, TRUE);
				bFind=1;
				m_nCurSearch=i;
				break;
			}
		}
		if (!bFind)
		{
			for (i=0; i<m_nCurSearch; i++)
			{
				if (strstr(pListCtrl->GetItemText(i, 1), szSearch) != NULL)
				{
					pListCtrl->EnsureVisible(i, TRUE);
					m_nCurSearch=i;
					break;
				}
			}
		}
	}
}

void CPG2PSFMatchDialog::OnBnClickedShowNomatchOnly()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOW_NOMATCH_ONLY);
	m_bShowNoMatchOnly=pButton->GetCheck();
	RefreshRTDeviceList();
}