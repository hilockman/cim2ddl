
#include "stdafx.h"
#include "Resource.h"
#include "MainFrm.h"
#include "TableView.h"
#include "PSFAsciiParser.h"

//////////////////////////////////////////////////////////////////////
// ����/����
//////////////////////////////////////////////////////////////////////

CTableView::CTableView()
{
}

CTableView::~CTableView()
{
}

BEGIN_MESSAGE_MAP(CTableView, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTableView ��Ϣ��������

int CTableView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
	{
		return -1;
	}

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// ������ͼ:
	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | TVS_HASLINES | TVS_SHOWSELALWAYS | TVS_LINESATROOT | TVS_HASBUTTONS | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

	if (!m_wndTableView.Create(dwViewStyle, rectDummy, this, 2))
	{
		TRACE0("δ�ܴ�������ͼ\n");
		return -1;      // δ�ܴ���
	}

	OnChangeVisualStyle();


	// ����һЩ��̬����ͼ����(�˴�ֻ������������룬�����Ǹ��ӵ�����)
	FillTableView();

	return 0;
}

void CTableView::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void CTableView::FillTableView()
{
	if (!m_wndTableView.DeleteAllItems())
		return;

	FillPSFAsciiTableView();
}

void CTableView::FillPSFAsciiTableView()
{
	register int	i,j;

	TV_INSERTSTRUCT insItem;
	HTREEITEM	hRoot,hTable;

	insItem.hParent=TVI_ROOT;
	insItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
	insItem.item.pszText=_T("PSF����ģ��");
	insItem.item.cchTextMax=24;
	insItem.item.lParam=0;
	insItem.item.state=TVIS_BOLD | TVIS_EXPANDED;
	insItem.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
	hRoot=m_wndTableView.InsertItem(&insItem);
	for (i=0; i<sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable); i++)
	{
		insItem.hParent=hRoot;
		insItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;

		insItem.item.stateMask=TVIS_EXPANDED | TVIS_SELECTED;
		insItem.item.state=0;

		insItem.item.pszText=g_PSFModelTables[i].lpszModelDesp;
		insItem.item.cchTextMax=128;
		insItem.item.lParam=i;
		hTable=m_wndTableView.InsertItem(&insItem);
 		for (j=0; j<g_PSFModelTables[i].nFieldNum; j++)
 		{
 			insItem.hParent=hTable;
 			insItem.item.mask=TVIF_TEXT | TVIF_PARAM;
 			insItem.item.pszText=g_PSFModelTables[i].pFieldArray[j].lpszCnDesp;
 			insItem.item.lParam=-1;
 			insItem.item.cchTextMax=128;
 			m_wndTableView.InsertItem(&insItem);
 		}
	}
}

void CTableView::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient;
	GetClientRect(rectClient);

	int cyTlb=0;
	m_wndTableView.SetWindowPos(NULL, rectClient.left + 1, rectClient.top + cyTlb + 1, rectClient.Width() - 2, rectClient.Height() - cyTlb - 2, SWP_NOACTIVATE | SWP_NOZORDER);
}

BOOL CTableView::PreTranslateMessage(MSG* pMsg)
{
	return CDockablePane::PreTranslateMessage(pMsg);
}


void CTableView::OnPaint()
{
	CPaintDC dc(this); // ���ڻ��Ƶ��豸������

	CRect rectTree;
	m_wndTableView.GetWindowRect(rectTree);
	ScreenToClient(rectTree);

	rectTree.InflateRect(1, 1);
	dc.Draw3dRect(rectTree, ::GetSysColor(COLOR_3DSHADOW), ::GetSysColor(COLOR_3DSHADOW));
}

void CTableView::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);

	m_wndTableView.SetFocus();
}

void CTableView::OnChangeVisualStyle()
{
	m_TableViewImages.DeleteImageList();

	UINT uiBmpId = theApp.m_bHiColorIcons ? IDB_CLASS_VIEW_24 : IDB_CLASS_VIEW;

	CBitmap bmp;
	if (!bmp.LoadBitmap(uiBmpId))
	{
		TRACE(_T("�޷�����λͼ: %x\n"), uiBmpId);
		ASSERT(FALSE);
		return;
	}

	BITMAP bmpObj;
	bmp.GetBitmap(&bmpObj);

	UINT nFlags = ILC_MASK;

	nFlags |= (theApp.m_bHiColorIcons) ? ILC_COLOR24 : ILC_COLOR4;

	m_TableViewImages.Create(16, bmpObj.bmHeight, nFlags, 0, 0);
	m_TableViewImages.Add(&bmp, RGB(255, 0, 0));

	m_wndTableView.SetImageList(&m_TableViewImages, TVSIL_NORMAL);
}
