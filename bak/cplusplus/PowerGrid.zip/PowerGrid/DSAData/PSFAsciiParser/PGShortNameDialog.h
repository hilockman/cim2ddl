#pragma once


// CPGShortNameDialog �Ի���

class CPGShortNameDialog : public CDialog
{
	DECLARE_DYNAMIC(CPGShortNameDialog)

public:
	CPGShortNameDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPGShortNameDialog();

// �Ի�������
	enum { IDD = IDD_PGSHORTNAME_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedSet();
	afx_msg void OnBnClickedLoad();
	afx_msg void OnNMClickPgsubstationList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedSave();
	afx_msg void OnBnClickedInit();
	afx_msg void OnBnClickedShortnameNull();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndListZone,m_wndListSubstation;

	int		m_nCurSubstation;
	int		m_bShowShortNameNull;
private:
	void	RefreshSubstationList();
};
