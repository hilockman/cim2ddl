
// PSFAsciiParserDoc.h : CPSFAsciiParserDoc ��Ľӿ�
//


#pragma once

#include "MainFrm.h"


class CPSFAsciiParserDoc : public CDocument
{
protected: // �������л�����
	CPSFAsciiParserDoc();
	DECLARE_DYNCREATE(CPSFAsciiParserDoc)

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// ʵ��
public:
	virtual ~CPSFAsciiParserDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnOpenPSFAscii();
	afx_msg void OnSaveasPSFAscii();
	afx_msg void OnPsfSetup();

public:
	int m_nTable,m_nRecord;
	void UpdateView();

	CMFCToolBar& GetToolBar () const
	{
		return ((CMainFrame*) AfxGetMainWnd ())->GetToolBar ();
	}

};


