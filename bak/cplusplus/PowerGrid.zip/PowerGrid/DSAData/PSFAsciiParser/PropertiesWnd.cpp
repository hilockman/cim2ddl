
#include "stdafx.h"

#include "PropertiesWnd.h"
#include "Resource.h"
#include "MainFrm.h"
#include "PSFAsciiParser.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

static	char*	lpszColumn[]=
{
	"����",
	"��ֵ",
	"����",
	"����",
};
/////////////////////////////////////////////////////////////////////////////
// CResourceViewBar

CPropertiesWnd::CPropertiesWnd()
{
}

CPropertiesWnd::~CPropertiesWnd()
{
}

BEGIN_MESSAGE_MAP(CPropertiesWnd, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_SETTINGCHANGE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CResourceViewBar ��Ϣ��������

void CPropertiesWnd::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient,rectCombo;
	GetClientRect(rectClient);

	m_wndPropList.SetWindowPos(NULL, rectClient.left, rectClient.top, rectClient.Width(), rectClient.Height(), SWP_NOACTIVATE | SWP_NOZORDER);
}

int CPropertiesWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// �������:
// 	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_BORDER | CBS_SORT | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
// 
// 	if (!m_wndObjectCombo.Create(dwViewStyle, rectDummy, this, 1))
// 	{
// 		TRACE0("δ�ܴ���������� \n");
// 		return -1;      // δ�ܴ���
// 	}
// 
// 	m_wndObjectCombo.AddString(_T("Ӧ�ó���"));
// 	m_wndObjectCombo.AddString(_T("���Դ���"));
// 	m_wndObjectCombo.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
// 	m_wndObjectCombo.SetCurSel(0);

	if (!m_wndPropList.Create(WS_VISIBLE | WS_CHILD, rectDummy, this, 2))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}

	InitPropList();

// 	m_wndToolBar.Create(this, AFX_DEFAULT_TOOLBAR_STYLE, IDR_PROPERTIES);
// 	m_wndToolBar.LoadToolBar(IDR_PROPERTIES, 0, 0, TRUE /* ������*/);
// 	m_wndToolBar.CleanUpLockedImages();
// 	m_wndToolBar.LoadBitmap(theApp.m_bHiColorIcons ? IDB_PROPERTIES_HC : IDR_PROPERTIES, 0, 0, TRUE /* ����*/);
// 
// 	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY);
// 	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() & ~(CBRS_GRIPPER | CBRS_SIZE_DYNAMIC | CBRS_BORDER_TOP | CBRS_BORDER_BOTTOM | CBRS_BORDER_LEFT | CBRS_BORDER_RIGHT));
// 	m_wndToolBar.SetOwner(this);
// 
// 	// �������ͨ���˿ؼ�·�ɣ�������ͨ�������·��:
// 	m_wndToolBar.SetRouteCommandsViaFrame(FALSE);

	AdjustLayout();
	return 0;
}

void CPropertiesWnd::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void CPropertiesWnd::InitPropList()
{
	register int	i;
	HDITEM	hdi;
	char	szBuffer[260];

	hdi.mask = HDI_TEXT;
 	hdi.pszText = szBuffer;
 	hdi.cchTextMax = 260;

	SetPropListFont();

	m_wndPropList.EnableHeaderCtrl(TRUE);
	m_wndPropList.EnableDescriptionArea(TRUE);
	m_wndPropList.SetVSDotNetLook(TRUE);
	m_wndPropList.MarkModifiedProperties(TRUE);
	m_wndPropList.SetShowDragContext(FALSE);

	for (i=0; i<m_wndPropList.GetHeaderCtrl().GetItemCount(); i++)
	{
		m_wndPropList.GetHeaderCtrl().GetItem(i, &hdi);
		strcpy(hdi.pszText, lpszColumn[i]);
		m_wndPropList.GetHeaderCtrl().SetItem(i, &hdi);
	}

	m_wndPropList.RemoveAll();
}

void CPropertiesWnd::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);
	m_wndPropList.SetFocus();
}

void CPropertiesWnd::OnSettingChange(UINT uFlags, LPCTSTR lpszSection)
{
	CDockablePane::OnSettingChange(uFlags, lpszSection);
	SetPropListFont();
}

void CPropertiesWnd::SetPropListFont()
{
	::DeleteObject(m_fntPropList.Detach());

	LOGFONT lf;
	afxGlobalData.fontRegular.GetLogFont(&lf);

	NONCLIENTMETRICS info;
	info.cbSize = sizeof(info);

	afxGlobalData.GetNonClientMetrics(info);

	lf.lfHeight = info.lfMenuFont.lfHeight;
	lf.lfWeight = info.lfMenuFont.lfWeight;
	lf.lfItalic = info.lfMenuFont.lfItalic;

	m_fntPropList.CreateFontIndirect(&lf);

	m_wndPropList.SetFont(&m_fntPropList);
}

void CPropertiesWnd::RefreshPropertyList(const int nTable, const int nRecord)
{
	int		nField;
	CMFCPropertyGridProperty* pProp;
	std::vector<std::string>	strColArray;

	m_wndPropList.RemoveAll();

	if (g_PSFAscii.GetPSFModelRecordNum(nTable) > 0)
		g_PSFAscii.GetPSFDataStringArray(nTable, nRecord, strColArray);
	else
		strColArray.resize(g_PSFModelTables[nTable].nFieldNum, "");
	for (nField=0; nField<g_PSFModelTables[nTable].nFieldNum; nField++)
	{
		pProp=new CMFCPropertyGridProperty(g_PSFModelTables[nTable].pFieldArray[nField].lpszCnDesp,
				(_variant_t)strColArray[nField].c_str(),
				g_PSFModelTables[nTable].pFieldArray[nField].lpszEnDesp);

		m_wndPropList.AddProperty(pProp);
	}
}
