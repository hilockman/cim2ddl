
// MainFrm.cpp : CMainFrame ���ʵ��
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "PSFAsciiParserDoc.h"
#include "PSFAsciiParserList.h"

#include "MainFrm.h"

#include "PG2PSFAsciiDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWndEx)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_REGISTERED_MESSAGE(AFX_WM_RESETTOOLBAR, OnToolbarReset)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_OFF_2007_AQUA, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_OFF_2007_AQUA, &CMainFrame::OnUpdateApplicationLook)

	ON_COMMAND(ID_VIEW_PROPERTIESWND, &CMainFrame::OnViewPropertiesWnd)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PROPERTIESWND, &CMainFrame::OnUpdateViewPropertiesWnd)

	ON_MESSAGE(UM_TABLE_CHANGED,	OnTableChanged)
	ON_MESSAGE(UM_UPDATECAPTIONBAR,	OnUpdateCaptionBar)
	ON_MESSAGE(UM_UPDATEPROPERTIES,	OnUpdateProperties)

	ON_COMMAND(ID_SEARCH_COLUMN, &CMainFrame::OnSearchColumn)
	ON_COMMAND(ID_SEARCH_CONTENT, &CMainFrame::OnSearchContent)
	ON_COMMAND(ID_SUBSTATION_DEVICE, &CMainFrame::OnSubstationDevice)
	ON_COMMAND(ID_RT2PSF, &CMainFrame::OnRt2Offline)
	ON_COMMAND(ID_RT2PSF_MATCH, &CMainFrame::OnRt2OfflineMatch)
	ON_COMMAND(ID_PG2PSF, &CMainFrame::OnPg2psf)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_INDICATOR_ICON,		// status icon
	ID_SEPARATOR,           // ״̬��ָʾ��
	ID_INDICATOR_NETSTATUS,		// text label
	ID_INDICATOR_DBDESP,		// status icon
};

// CMainFrame ����/����

CMainFrame::CMainFrame()
{
	// TODO: �ڴ����ӳ�Ա��ʼ������
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2005);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;
	// ���ڳ־�ֵ�����Ӿ�����������ʽ
	OnApplicationLook(theApp.m_nAppLook);

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("δ�ܴ����˵���\n");
		return -1;      // δ�ܴ���
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ��ֹ�˵����ڼ���ʱ��ý���
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

 	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC | CBRS_BORDER_3D) ||
		//!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
 	{
 		TRACE0("δ�ܴ���������\n");
 		return -1;      // δ�ܴ���
 	}

 	CString strToolBarName;
 	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
 	ASSERT(bNameValid);
 	m_wndToolBar.SetWindowText(strToolBarName);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));
	m_wndStatusBar.SetPaneStyle (g_nStatusIcon,			SBPS_NOBORDERS);
	m_wndStatusBar.SetPaneStyle (g_nStatusSeperator,	SBPS_NOBORDERS);
	m_wndStatusBar.SetPaneStyle (g_nStatusNetStatus,	SBPS_NORMAL);
	m_wndStatusBar.SetPaneStyle (g_nStatusDBDesp,		SBPS_STRETCH);

	HICON hStatusIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(IDI_OUTPUT_WND_HC), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndStatusBar.SetPaneIcon (g_nStatusIcon, hStatusIcon);

	// TODO: �������ϣ���������Ͳ˵�����ͣ������ɾ��������
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// ���� Visual Studio 2005 ��ʽͣ��������Ϊ
	CDockingManager::SetDockingMode(DT_SMART);
	// ���� Visual Studio 2005 ��ʽͣ�������Զ�������Ϊ
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// ����ͣ������
	if (!CreateDockingWindows())
	{
		TRACE0("δ�ܴ���ͣ������\n");
		return -1;
	}

	m_wndTableView.EnableDocking(CBRS_ALIGN_ANY);
	m_wndOutput.EnableDocking(CBRS_ALIGN_ANY);
	m_wndProperties.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndTableView);
	DockPane(&m_wndOutput);
	DockPane(&m_wndProperties);

	if (!m_wndRT2OffDialog.Create(IDD_PG2PSF_MATCH_DIALOG, this))
		return FALSE;
	m_wndRT2OffDialog.ShowWindow(SW_HIDE);

	if (!m_wndSubDevDialog.Create(IDD_SUBSTATION_DEVICE_DIALOG, this))
		return FALSE;
	m_wndSubDevDialog.ShowWindow(SW_HIDE);

	if (!m_wndPG2PSFDialog.Create(IDD_PG2PSFASCII_DIALOG, this))
		return FALSE;
	m_wndPG2PSFDialog.ShowWindow(SW_HIDE);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return TRUE;
}

BOOL CMainFrame::CreateDockingWindows()
{
	BOOL bNameValid;

	// �����ļ���ͼ
	CString strFileView;
	bNameValid = strFileView.LoadString(IDS_TABLE_VIEW);
	ASSERT(bNameValid);
	if (!m_wndTableView.Create(strFileView, this, CRect(0, 0, 200, 200), FALSE, ID_VIEW_FILEVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT| CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ������ļ���ͼ������\n");
		return FALSE; // δ�ܴ���
	}

// 	// �����������
	if (!m_wndOutput.Create("��Ϣ����", this, CRect(0, 0, 100, 100), FALSE, ID_VIEW_OUTPUTWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_BOTTOM | CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ����������\n");
		return FALSE; // δ�ܴ���
	}
	//m_wndOutput.ModifyStyle(WS_CAPTION|WS_SYSMENU,0);

	// �������Դ���
	CString strPropertiesWnd;
	bNameValid = strPropertiesWnd.LoadString(IDS_PROPERTIES_WND);
	ASSERT(bNameValid);
	if (!m_wndProperties.Create(strPropertiesWnd, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_PROPERTIESWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_RIGHT | CBRS_FLOAT_MULTI))
	{
		TRACE0("δ�ܴ��������ԡ�����\n");
		return FALSE; // δ�ܴ���
	}

	SetDockingWindowIcons(theApp.m_bHiColorIcons);
	return TRUE;
}

void CMainFrame::SetDockingWindowIcons(BOOL bHiColorIcons)
{
	HICON hFileViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_FILE_VIEW_HC : IDI_FILE_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndTableView.SetIcon(hFileViewIcon, FALSE);

	HICON hPropertiesBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_PROPERTIES_WND_HC : IDI_PROPERTIES_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndProperties.SetIcon(hPropertiesBarIcon, FALSE);
}

// CMainFrame ���

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame ��Ϣ��������

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}

void CMainFrame::OnViewPropertiesWnd()
{
	m_wndProperties.ShowWindow(m_wndProperties.IsVisible() ? SW_HIDE : SW_SHOW);
	RecalcLayout(FALSE);
}

void CMainFrame::OnUpdateViewPropertiesWnd(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndProperties.IsVisible());
}

LRESULT CMainFrame::OnTableChanged(WPARAM wParam, LPARAM lParam)
{
	TRACE("OnTableChanged: %d\n",wParam);
	CPSFAsciiParserDoc*	pDoc=(CPSFAsciiParserDoc*)GetActiveDocument();
	if (!pDoc)
		return 0;
	TRACE("    pDoc != NULL\n");

	LockWindowUpdate();

	pDoc->m_nTable=wParam;
	if (pDoc->m_nTable >= 0)
	{
		pDoc->m_nRecord=0;
		pDoc->UpdateView();
		OnUpdateCaptionBar(0, 0);
		OnUpdateProperties(0, 0);
	}

	UnlockWindowUpdate();

	return 0;
}
LRESULT CMainFrame::OnUpdateCaptionBar(WPARAM wParam, LPARAM lParam)
{
	CPSFAsciiParserDoc*	pDoc=(CPSFAsciiParserDoc*)GetActiveDocument();
	if (!pDoc)
		return 0;

	if (pDoc->m_nTable >= 0 && pDoc->m_nTable < sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable))
	{
		char	szChar[260];

		sprintf(szChar,"����=%s[%s] �ֶ���=%d",
			g_PSFModelTables[pDoc->m_nTable].lpszModelName,
			g_PSFModelTables[pDoc->m_nTable].lpszModelDesp,
			g_PSFModelTables[pDoc->m_nTable].nFieldNum);
		m_wndStatusBar.SetPaneText(g_nStatusDBDesp, szChar);

		int		nItem;
		char	szCurColumn[MDB_CHARLEN_LONG];
		CMFCToolBarComboBoxButton*	pComboBox;

		memset(szCurColumn, 0, MDB_CHARLEN_LONG);

		nItem = m_wndToolBar.CommandToIndex(ID_SEARCH_COLUMN);
		pComboBox = (CMFCToolBarComboBoxButton*)m_wndToolBar.GetButton(nItem);
		if (pComboBox)
		{
			if (pComboBox->GetCount() > 0)
			{
				strcpy(szCurColumn,pComboBox->GetText());
				pComboBox->RemoveAllItems();
			}

			for (nItem=0; nItem<g_PSFModelTables[pDoc->m_nTable].nFieldNum; nItem++)
			{
				pComboBox->AddItem(g_PSFModelTables[pDoc->m_nTable].pFieldArray[nItem].lpszCnDesp);
			}
			nItem=pComboBox->SelectItem(szCurColumn);
		}
	}

	//CMFCToolBarEditBoxButton*	pComboBox=(CMFCToolBarEditBoxButton*)

	return 0;
}

LRESULT CMainFrame::OnUpdateProperties(WPARAM wParam, LPARAM lParam)
{
	CPSFAsciiParserDoc*	pDoc=(CPSFAsciiParserDoc*)GetActiveDocument();
	if (!pDoc)
		return 0;

	if (pDoc->m_nTable >= 0 && pDoc->m_nTable < sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable))
	{
		m_wndProperties.RefreshPropertyList(pDoc->m_nTable,pDoc->m_nRecord);
	}
	return 0;
}

LRESULT CMainFrame::OnToolbarReset(WPARAM wp,LPARAM)
{
	//----Example----//

	UINT uiToolBarId = (UINT) wp;

	switch (uiToolBarId)
	{
	case IDR_MAINFRAME:
		{
			CMFCToolBarComboBoxButton	cmbSeekColumn(ID_SEARCH_COLUMN,	GetCmdMgr()->GetCmdImage(ID_SEARCH_COLUMN, FALSE), CBS_DROPDOWNLIST, 320);
			cmbSeekColumn.SetDropDownHeight(480);
			cmbSeekColumn.SetFlatMode(FALSE);
			m_wndToolBar.ReplaceButton (ID_SEARCH_COLUMN, cmbSeekColumn);

			CMFCToolBarEditBoxButton	txtSeekContent(ID_SEARCH_CONTENT, GetCmdMgr()->GetCmdImage(ID_SEARCH_CONTENT, FALSE), TBBS_PRESSED|ES_AUTOHSCROLL, 160);
			txtSeekContent.SetFlatMode(FALSE);
			m_wndToolBar.ReplaceButton (ID_SEARCH_CONTENT, txtSeekContent);
		}
		break;
	}

// 	CMFCToolBarEditBoxButton* boxButton = new CMFCToolBarEditBoxButton();
// 	boxButton->CanBeStretched();
// 	boxButton->HaveHotBorder();
// 	boxButton->SetContents(_T("edit box button"));
// 	boxButton->SetFlatMode(true);
// 	boxButton->SetStyle(TBBS_PRESSED);

	//----Example----//

	return 0;
}

void CMainFrame::OnSearchColumn()
{
	// TODO: �ڴ�����������������
}

void CMainFrame::OnSearchContent()
{
	// TODO: �ڴ�����������������
}

void CMainFrame::OnRt2Offline()
{
	// TODO: �ڴ�����������������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt)|*.txt;*.TXT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	matchDlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	matchDlg.m_ofn.lpstrTitle=_T("�򿪶��չ�ϵ�ļ�");
	matchDlg.m_ofn.lpstrInitialDir=_T("");
	matchDlg.m_ofn.lStructSize=sizeof(matchDlg.m_ofn);

	if (matchDlg.DoModal() == IDCANCEL)
		return;

	fileExt="raw";
	defaultFileName=_T("");
	fileFilter="�ı��ļ�(*.raw)|*.raw;*.RAW|�����ļ�(*.*)|*.*||";
	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	psfDlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	psfDlg.m_ofn.lpstrTitle=_T("��PSFAscii����ļ�");
	psfDlg.m_ofn.lpstrInitialDir=_T("");
	psfDlg.m_ofn.lStructSize=sizeof(psfDlg.m_ofn);

	if (psfDlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();
	g_PSFAscii.PGMemDB2PSFAscii(g_pPGBlock, g_bSetPlantRTLoad, matchDlg.GetPathName(), g_strWorkZoneArray);
	g_PSFAscii.ExportPSFFile(psfDlg.GetPathName(), 1);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("PGMemDB2PSFAscii��ϣ���ʱ%d����", nDur);
}

void CMainFrame::OnSubstationDevice()
{
	// TODO: �ڴ�����������������
	if (!m_wndSubDevDialog.IsWindowVisible())
	{
		m_wndSubDevDialog.Refresh();
		m_wndSubDevDialog.ShowWindow(SW_SHOW);
	}
}

void CMainFrame::OnRt2OfflineMatch()
{
	// TODO: �ڴ�����������������
	if (!m_wndRT2OffDialog.IsWindowVisible())
	{
		m_wndRT2OffDialog.Refresh();
		m_wndRT2OffDialog.ShowWindow(SW_SHOW);
	}
}

void CMainFrame::OnPg2psf()
{
	// TODO: �ڴ�����������������
	if (!m_wndPG2PSFDialog.IsWindowVisible())
	{
		m_wndPG2PSFDialog.RefreshUI();
		m_wndPG2PSFDialog.ShowWindow(SW_SHOW);
	}
}
