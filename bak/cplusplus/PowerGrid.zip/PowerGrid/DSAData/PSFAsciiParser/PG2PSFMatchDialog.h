#pragma once


// CPG2PSFMatchDialog �Ի���

class CPG2PSFMatchDialog : public CDialog
{
	DECLARE_DYNAMIC(CPG2PSFMatchDialog)

public:
	CPG2PSFMatchDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPG2PSFMatchDialog();
	void	Refresh();

// �Ի�������
	enum { IDD = IDD_PG2PSF_MATCH_DIALOG };

protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	afx_msg void OnCbnSelchangeOfflineZoneCombo();
	afx_msg void OnCbnSelchangeRTZoneCombo();
	afx_msg void OnBnClickedDelmatch();
	afx_msg void OnBnClickedAddmatch();
	afx_msg void OnLvnItemchangedOfflineSubList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedAutoMatch();
	afx_msg void OnBnClickedRefresh();
	afx_msg void OnCbnSelchangeDevicetypeCombo();
	afx_msg void OnBnClickedSaveMatch();
	afx_msg void OnBnClickedSearchButton();
	afx_msg void OnBnClickedReadMatch();
	afx_msg void OnCbnSelchangeOfflineSubCombo();
	afx_msg void OnCbnSelchangeRTSubCombo();
	afx_msg void OnBnClickedShowNomatchOnly();
	DECLARE_MESSAGE_MAP()
private:
	int		m_nDeviceType;
	char	m_szFilterOfflineZone[MDB_CHARLEN_TINY];
	char	m_szFilterOfflineSub[MDB_CHARLEN_TINY];
	char	m_szFilterRTZone[MDB_CHARLEN_SHORT];
	char	m_szFilterRTSub[MDB_CHARLEN_SHORT];

	int		m_nCurSearch;

	unsigned char	m_bShowNoMatchOnly;

private:
	void RefreshOfflineDeviceList(void);
	void RefreshRTDeviceList(void);
public:
};
