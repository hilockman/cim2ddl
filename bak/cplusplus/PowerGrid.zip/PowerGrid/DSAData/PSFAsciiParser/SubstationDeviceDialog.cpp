// SubstationDeviceDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PSFAsciiParser.h"
#include "SubstationDeviceDialog.h"


// CSubstationDeviceDialog �Ի���
static	char*	lpszLineColumn[]=
{
	"���",
	"����",
	"��ѹ�ȼ�",
	"��վI",
	"��վJ",
	"����",
};

static	char*	lpszGeneratorColumn[]=
{
	"���",
	"��վ",
	"��ѹ�ȼ�",
	"����",
	"����",
	"����",
};

IMPLEMENT_DYNAMIC(CSubstationDeviceDialog, CDialog)

extern	std::string	toString(const double fBuf);
extern	std::string	toString(const float fBuf);
extern	std::string	toString(const int nBuf);
extern	std::string	toString(const short nBuf);

CSubstationDeviceDialog::CSubstationDeviceDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSubstationDeviceDialog::IDD, pParent)
	, m_bShowOffNoMatch(FALSE)
	, m_bShowRTNoMatch(FALSE)
{
	m_strOffSubstation.clear();
	m_strRTSubstation.clear();
}

CSubstationDeviceDialog::~CSubstationDeviceDialog()
{
}

void CSubstationDeviceDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_OFFSUB_NOMATCH, m_bShowOffNoMatch);
	DDX_Check(pDX, IDC_RTSUB_NOMATCH, m_bShowRTNoMatch);
}


BEGIN_MESSAGE_MAP(CSubstationDeviceDialog, CDialog)
	ON_BN_CLICKED(IDC_REFRESH, &CSubstationDeviceDialog::OnBnClickedRefresh)
	ON_CBN_SELCHANGE(IDC_OFFLINESUBSTATION_COMBO, &CSubstationDeviceDialog::OnCbnSelchangeOfflinesubstationCombo)
	ON_CBN_SELCHANGE(IDC_RTSUBSTATION_COMBO, &CSubstationDeviceDialog::OnCbnSelchangeRtsubstationCombo)
	ON_BN_CLICKED(IDC_OFFSUB_NOMATCH, &CSubstationDeviceDialog::OnBnClickedOffsubNomatch)
	ON_BN_CLICKED(IDC_RTSUB_NOMATCH, &CSubstationDeviceDialog::OnBnClickedRtsubNomatch)
END_MESSAGE_MAP()


// CSubstationDeviceDialog ��Ϣ��������

BOOL CSubstationDeviceDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl;

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFLINE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	for (i=0; i<sizeof(lpszLineColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLineColumn[i]);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTLINE_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	for (i=0; i<sizeof(lpszLineColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszLineColumn[i]);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFGENERATOR_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	for (i=0; i<sizeof(lpszGeneratorColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszGeneratorColumn[i]);

	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTGENERATOR_LIST);
	pListCtrl->ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	pListCtrl->SetExtendedStyle(pListCtrl->GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	for (i=0; i<sizeof(lpszGeneratorColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszGeneratorColumn[i]);

	Refresh();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CSubstationDeviceDialog::Refresh()
{
	register int	i,j;
	int		nSub;
	unsigned char	bInArea;
	CComboBox*	pComboBox;

	pComboBox=(CComboBox*)GetDlgItem(IDC_OFFLINESUBSTATION_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (nSub=0; nSub<(int)g_PSFAscii.m_SubstationArray.size(); nSub++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			bInArea=0;
			for (i=0; i<(int)g_PSFAscii.m_SubstationArray[nSub].nBusArray.size(); i++)
			{
				for (j=0; j<(int)g_strWorkZoneArray.size(); j++)
				{
					if (strcmp(g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_SubstationArray[nSub].nBusArray[i]].szZoneName, g_strWorkZoneArray[j].c_str()) == 0)
					{
						bInArea=1;
						break;
					}
				}
				if (bInArea)	break;
			}
			if (!bInArea)
				continue;
		}
		if (m_bShowOffNoMatch)
		{
			if (strlen(g_PSFAscii.m_SubstationArray[nSub].szRTName) > 0)
				continue;
		}

		pComboBox->AddString(g_PSFAscii.m_SubstationArray[nSub].szName);
	}

	pComboBox=(CComboBox*)GetDlgItem(IDC_RTSUBSTATION_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("");
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		if (m_bShowRTNoMatch)
		{
			if (g_PSFAscii.IsCimDeviceMatched(PSFModel_Substation, g_pPGBlock->m_SubstationArray[i].szName))
				continue;
		}
		pComboBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);
	}

	RefreshOffLineList();
	RefreshRTLineList();
	RefreshOffGeneratorList();
	RefreshRTGeneratorList();
}

void CSubstationDeviceDialog::OnBnClickedRefresh()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Refresh();
}

void CSubstationDeviceDialog::RefreshOffLineList()
{
	register int	i;
	int		nRow,nCol,nDev;
	int		nOffSubI,nOffSubJ;
	unsigned char	bIInArea,bZInArea;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFLINE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<(int)g_PSFAscii.m_PSFLineArray.size(); nDev++)
	{
		if (g_PSFAscii.m_PSFLineArray[nDev].nBus1Index < 0 || g_PSFAscii.m_PSFLineArray[nDev].nBus2Index < 0)
			continue;

		if (!g_strWorkZoneArray.empty())
		{
			bIInArea=bZInArea=0;
			for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
			{
				if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szZoneName) == 0)
				{
					bIInArea=1;
					break;
				}
			}
			for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
			{
				if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szZoneName) == 0)
				{
					bZInArea=1;
					break;
				}
			}
			if (!bIInArea && !bZInArea)
				continue;
		}
		if (!m_strOffSubstation.empty())
		{
			if (strcmp(m_strOffSubstation.c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation) != 0 &&
				strcmp(m_strOffSubstation.c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation) != 0)
				continue;
		}

		nOffSubI=nOffSubJ=-1;
		for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
		{
			if (strcmp(g_PSFAscii.m_SubstationArray[i].szRTName, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation) == 0)
			{
				nOffSubI=i;
				break;
			}
		}
		for (i=0; i<(int)g_PSFAscii.m_SubstationArray.size(); i++)
		{
			if (strcmp(g_PSFAscii.m_SubstationArray[i].szRTName, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation) == 0)
			{
				nOffSubJ=i;
				break;
			}
		}

		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFLineArray[nDev].szPSFName);
		sprintf(szBuf,"%f",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].fkV);	FormatRealData(szBuf);
		pListCtrl->SetItemText(nRow, nCol++, szBuf);

		if (strcmp(m_strOffSubstation.c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation) == 0)
		{
			strcpy(szBuf,g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation);
			if (nOffSubI >= 0)
				sprintf(szBuf,"%s[%s]",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation,g_PSFAscii.m_SubstationArray[nOffSubI].szRTName);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);

			strcpy(szBuf,g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation);
			if (nOffSubJ >= 0)
				sprintf(szBuf,"%s[%s]",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation,g_PSFAscii.m_SubstationArray[nOffSubJ].szRTName);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		}
		else
		{
			strcpy(szBuf,g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation);
			if (nOffSubJ >= 0)
				sprintf(szBuf,"%s[%s]",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus2Index].szSubstation,g_PSFAscii.m_SubstationArray[nOffSubJ].szRTName);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);

			strcpy(szBuf,g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation);
			if (nOffSubI >= 0)
				sprintf(szBuf,"%s[%s]",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFLineArray[nDev].nBus1Index].szSubstation,g_PSFAscii.m_SubstationArray[nOffSubI].szRTName);
			pListCtrl->SetItemText(nRow, nCol++, szBuf);
		}
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFLineArray[nDev].szRTName);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CSubstationDeviceDialog::RefreshRTLineList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTLINE_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
	{
		if (!m_strRTSubstation.empty())
		{
			if (strcmp(m_strRTSubstation.c_str(), g_pPGBlock->m_ACLineSegmentArray[i].szSubI) != 0 &&
				strcmp(m_strRTSubstation.c_str(), g_pPGBlock->m_ACLineSegmentArray[i].szSubZ) != 0)
				continue;
		}

		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szName);
		pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szVoltI);
		if (strcmp(m_strRTSubstation.c_str(), g_pPGBlock->m_ACLineSegmentArray[i].szSubI) == 0)
		{
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubZ);
		}
		else
		{
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubZ);
			pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_ACLineSegmentArray[i].szSubI);
		}
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CSubstationDeviceDialog::RefreshOffGeneratorList()
{
	register int	i;
	int		nRow,nCol,nDev;
	unsigned char	bInArea;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_OFFGENERATOR_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<(int)g_PSFAscii.m_PSFGeneratorArray.size(); nDev++)
	{
		if (!g_strWorkZoneArray.empty())
		{
			bInArea=0;
			for (i=0; i<(int)g_strWorkZoneArray.size(); i++)
			{
				if (strcmp(g_strWorkZoneArray[i].c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].szZoneName) == 0)
				{
					bInArea=1;
					break;
				}
			}
			if (!bInArea)
				continue;
		}
		if (!m_strOffSubstation.empty())
		{
			if (strcmp(m_strOffSubstation.c_str(), g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].szSubstation) != 0)
				continue;
		}

		sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);
		nCol=1;
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].szSubstation);
		sprintf(szBuf,"%f",g_PSFAscii.m_PSFBusArray[g_PSFAscii.m_PSFGeneratorArray[nDev].nBusIndex].fkV);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFGeneratorArray[nDev].szBusName);
		sprintf(szBuf,"%f",g_PSFAscii.m_PSFGeneratorArray[nDev].fPMax);	pListCtrl->SetItemText(nRow, nCol++, szBuf);
		pListCtrl->SetItemText(nRow, nCol++, g_PSFAscii.m_PSFGeneratorArray[nDev].szRTName);
		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CSubstationDeviceDialog::RefreshRTGeneratorList()
{
	register int	i;
	int		nRow,nCol,nSub,nVolt;
	char	szBuf[260];
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_RTGENERATOR_LIST);
	pListCtrl->DeleteAllItems();

	nRow=0;
	for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=g_pPGBlock->m_SubstationArray[nSub].pRkv; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].pRkv; nVolt++)
		{
			for (i=g_pPGBlock->m_VoltageLevelArray[nVolt].pRun; i<g_pPGBlock->m_VoltageLevelArray[nVolt+1].pRun; i++)
			{
				if (!m_strRTSubstation.empty())
				{
					if (strcmp(m_strRTSubstation.c_str(), g_pPGBlock->m_SynchronousMachineArray[i].szSub) != 0)
						continue;
				}

				sprintf(szBuf,"%d",nRow+1);	pListCtrl->InsertItem(nRow, szBuf);

				nCol=1;
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szSub);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szVolt);
				pListCtrl->SetItemText(nRow, nCol++, g_pPGBlock->m_SynchronousMachineArray[i].szName);
				sprintf(szBuf,"%f",g_pPGBlock->m_SynchronousMachineArray[i].pmax);	pListCtrl->SetItemText(nRow, nCol++, szBuf);

				nRow++;
			}
		}
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(nCol);
		pListCtrl->SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = pListCtrl->GetColumnWidth(nCol);

		pListCtrl->SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CSubstationDeviceDialog::OnCbnSelchangeOfflinesubstationCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_OFFLINESUBSTATION_COMBO);
	int		nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
		return;

	char	szSub[260];
	pComboBox->GetLBText(nSel, szSub);
	m_strOffSubstation=szSub;

	RefreshOffLineList();
	RefreshOffGeneratorList();
}

void CSubstationDeviceDialog::OnCbnSelchangeRtsubstationCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CComboBox*pComboBox=(CComboBox*)GetDlgItem(IDC_RTSUBSTATION_COMBO);
	int		nSel=pComboBox->GetCurSel();
	if (nSel == CB_ERR)
		return;

	char	szSub[260];
	pComboBox->GetLBText(nSel, szSub);
	m_strRTSubstation=szSub;

	RefreshRTLineList();
	RefreshRTGeneratorList();
}

void CSubstationDeviceDialog::OnBnClickedOffsubNomatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	Refresh();
}

void CSubstationDeviceDialog::OnBnClickedRtsubNomatch()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();
	Refresh();
}
