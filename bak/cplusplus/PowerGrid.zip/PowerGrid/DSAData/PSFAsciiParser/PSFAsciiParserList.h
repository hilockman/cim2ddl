
// PSFAsciiParserList.h : CPSFAsciiParserList ��Ľӿ�
//


#pragma once


class CPSFAsciiParserList : public CListView
{
protected: // �������л�����
	CPSFAsciiParserList();
	DECLARE_DYNCREATE(CPSFAsciiParserList)

// ����
public:
	CPSFAsciiParserDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // ������һ�ε���
	virtual void DrawItem(NMLVDISPINFO* pDispInfo);

// ʵ��
public:
	virtual ~CPSFAsciiParserList();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnLvnItemchanged(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSaveasExcel();
	afx_msg void OnSearch();
	afx_msg void OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
public:

private:
	CMFCToolBar& GetToolBar () const
	{
		return ((CMainFrame*) AfxGetMainWnd ())->GetToolBar ();
	}

private:
	std::vector<int>	m_nShowIndexArray;
	void	ResolveShowIndex();
private:
	void	RefreshList(const int nTable);
public:
	void UpdateView();
};

#ifndef _DEBUG  // PSFAsciiParserList.cpp �еĵ��԰汾
inline CPSFAsciiParserDoc* CPSFAsciiParserList::GetDocument() const
   { return reinterpret_cast<CPSFAsciiParserDoc*>(m_pDocument); }
#endif

