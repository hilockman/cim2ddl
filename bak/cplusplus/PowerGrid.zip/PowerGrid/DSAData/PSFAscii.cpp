#include "StdAfx.h"
#include "PSFAscii.h"

CPSFAscii::CPSFAscii(void)
{
	ArrayInitialize();
	ClearLog();
}

CPSFAscii::~CPSFAscii(void)
{
	ArrayInitialize();
}

void	CPSFAscii::ArrayInitialize()
{
	register int	i;
	for (i=0; i<(int)m_SubstationArray.size(); i++)
		m_SubstationArray[i].nBusArray.clear();
	m_SubstationArray.clear();
	m_PSFBusArray.clear();
	m_PSFGeneratorArray.clear();
	m_PSFLoadArray.clear();
	m_PSFLoadModelArray.clear();
	m_PSFFixedShuntArray.clear();
	m_PSFSwitchableShuntArray.clear();
	m_PSFLineArray.clear();
	m_PSFFixedTranArray.clear();
	m_PSFULTCTranArray.clear();
	m_PSFImpedanceCorrectionTablesArray.clear();
	m_PSFFixedSeriesCompensatorArray.clear();
	m_PSFSwitchableSeriesCompensatorArray.clear();
	m_PSFStaticTapChangerPhaseRegulatorArray.clear();
	m_PSF3WindingTranArray.clear();
	m_PSFAreaInterchangeArray.clear();

	m_PSFLCConvertersArray.clear();
	m_PSFDCLinesArray.clear();
	m_PSFDCBreakersArray.clear();
	m_PSFDCBusesArray.clear();
	m_PSFVSCArray.clear();

	m_PSFZoneArray.clear();
	m_PSFNodeMappingArray.clear();
	m_PSFZeroSequenceMutualCouplingArray.clear();
	m_PSFFileSectionArray.clear();

	for (i=0; i<(int)m_BusNobnArray.size(); i++)
	{
		m_BusNobnArray[i].nGeneratorArray.clear();
		m_BusNobnArray[i].nLoadArray.clear();
		m_BusNobnArray[i].nFixedShuntArray.clear();
		m_BusNobnArray[i].nSwitchableShuntArray.clear();
		m_BusNobnArray[i].nLineArray.clear();
		m_BusNobnArray[i].nFixedTransformerArray.clear();
		m_BusNobnArray[i].nULTCTransformerArray.clear();
		m_BusNobnArray[i].nFixedSeriesCompensatorArray.clear();
		m_BusNobnArray[i].nSwitchableSeriesCompensatorArray.clear();
		m_BusNobnArray[i].nStaticTapChangerPhaseRegulatorArray.clear();
		m_BusNobnArray[i].nPSF3WindingTransformerArray.clear();
		m_BusNobnArray[i].nLineCommutatedConvertersArray.clear();
		m_BusNobnArray[i].nVoltageSourcedConverterArray.clear();
	}
	m_BusNobnArray.clear();

	m_PG2PSFMatchArray.clear();
}

static	char*	lpszLogFile="PSFAscii.log";
void CPSFAscii::ClearLog()
{
	char	szTempPath[260],szFileName[260];

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260,szTempPath);
#else
	strcpy(szTempPath,"/tmp");
#endif

	sprintf(szFileName,"%s/%s",szTempPath,lpszLogFile);
	FILE*	fp=fopen(szFileName,"w");
	fflush(fp);
	fclose(fp);
}

void CPSFAscii::Log(const char* lpszFormat, ...)
{
	va_list args;
	va_start( args, lpszFormat );

	char	szTempPath[260],szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260,szTempPath);
#else
	strcpy(szTempPath,"/tmp");
#endif

	sprintf(szFileName,"%s/%s",szTempPath,lpszLogFile);
	fp=fopen(szFileName,"a");
	if (fp != NULL)
	{
		vfprintf(fp, lpszFormat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}

int		CPSFAscii::ImportPSFFile(const char* lpszFileName, const double fZIL, const unsigned char bCheckValidate)
{
	register int	i;
	int		nSection;
	char	szLine[512];
	std::vector<std::string>	strDataLineArray;
	FILE*	fp;
	fp=fopen(lpszFileName,"r");
	if (fp == NULL)
		return 0;

	strDataLineArray.clear();

	nSection=-1;
	while (!feof(fp))
	{
		memset(szLine, 0, 512);
		fgets(szLine, 512, fp);
		if (strlen(szLine) <= 0)
			continue;

		TrimEnd(szLine);

		strDataLineArray.push_back(szLine);
		for (i=0; i<sizeof(g_lpszPSFAsciiSection)/sizeof(char*); i++)
		{
			if (strstr(szLine, g_lpszPSFAsciiSection[i]) != NULL)
			{
				switch (nSection)
				{
				case PSF_Section_Solution_history_data:					ImportPSFSolutionHistory(bCheckValidate, strDataLineArray);					break;
				case PSF_Section_Bus_data:								ImportPSFBus(bCheckValidate, strDataLineArray);								break;
				case PSF_Section_Generator_data:						ImportPSFGenerator(bCheckValidate, strDataLineArray);						break;
				case PSF_Section_Load_data:								ImportPSFLoad(bCheckValidate, strDataLineArray);							break;
				case PSF_Section_Load_model_data:						ImportPSFLoadModel(bCheckValidate, strDataLineArray);						break;
				case PSF_Section_Fixed_shunt_data:						ImportPSFFixedShunt(bCheckValidate, strDataLineArray);						break;
				case PSF_Section_Switched_shunt_data:					ImportPSFSwitchableShunt(bCheckValidate, strDataLineArray);					break;
				case PSF_Section_Line_data:								ImportPSFLine(bCheckValidate, strDataLineArray);							break;
				case PSF_Section_Fixed_transformer_data:				ImportPSFFixedTransformer(bCheckValidate, strDataLineArray);				break;
				case PSF_Section_ULTC_transformer_data:					ImportPSFULTCTransformer(bCheckValidate, strDataLineArray);					break;
				case PSF_Section_Impedance_correction_tables:			ImportPSFImpedanceCorrectionTables(bCheckValidate, strDataLineArray);		break;
				case PSF_Section_Fixed_series_compensator_data:			ImportPSFFixedSeriesCompensator(bCheckValidate, strDataLineArray);			break;
				case PSF_Section_Switchable_series_compensator_data:	ImportPSFSwitchableSeriesCompensator(bCheckValidate, strDataLineArray);		break;
				case PSF_Section_FACTS_device_data:						ImportPSFStaticTapChangerPhaseRegulator(bCheckValidate, strDataLineArray);	break;
				case PSF_Section_3winding_transformer_data:				ImportPSF3WindingTransformer(bCheckValidate, strDataLineArray);				break;
				case PSF_Section_Area_interchange_data:					ImportPSFAreaInterchange(bCheckValidate, strDataLineArray);					break;
				case PSF_Section_Interface_data:																										break;
				case PSF_Section_Multi_terminal_DC_data:				ImportPSFMultiTerminalDC(bCheckValidate, strDataLineArray);					break;
				case PSF_Section_Zone_data:								ImportPSFZone(bCheckValidate, strDataLineArray);							break;
				case PSF_Section_Node_mapping_data:						ImportPSFNodeMapping(bCheckValidate, strDataLineArray);						break;
				case PSF_Section_Zero_seq_mutual_coupling_data:			ImportPSFZeroSequenceMutualCoupling(bCheckValidate, strDataLineArray);		break;
				case PSF_Section_File_section_data:						ImportPSFFileSection(bCheckValidate, strDataLineArray);						break;
				case PSF_Section_File_End:																												break;
				}

				nSection=i;
				strDataLineArray.clear();
				break;
			}
		}
	}

	fclose(fp);
	strDataLineArray.clear();

	PSFAsciiMaint(fZIL);

	return 1;
}

int		CPSFAscii::ExportPSFFile(const char* lpszFileName, const unsigned char bRTData)
{
	register int	i;
	std::vector<std::string>	strDataLineArray;
	FILE*	fp;
	fp=fopen(lpszFileName,"w");
	if (fp == NULL)
		return 0;

	fprintf(fp,"%s ",lpszDsaFlagReserved);
	fprintf(fp,"%s ",lpszDsaPFBFormatVersion);
	fprintf(fp,"\n");

	for (i=0; i<sizeof(g_lpszPSFAsciiSection)/sizeof(char*); i++)
	{
		fprintf(fp,"%s\n",g_lpszPSFAsciiSection[i]);
		switch (i)
		{
		case PSF_Section_Solution_history_data:					ExportPSFSolutionHistory(fp, bRTData);					break;
		case PSF_Section_Bus_data:								ExportPSFBus(fp, bRTData);								break;
		case PSF_Section_Generator_data:						ExportPSFGenerator(fp, bRTData);						break;
		case PSF_Section_Load_data:								ExportPSFLoad(fp, bRTData);								break;
		case PSF_Section_Load_model_data:						ExportPSFLoadModel(fp, bRTData);						break;
		case PSF_Section_Fixed_shunt_data:						ExportPSFFixedShunt(fp, bRTData);						break;
		case PSF_Section_Switched_shunt_data:					ExportPSFSwitchableShunt(fp, bRTData);					break;
		case PSF_Section_Line_data:								ExportPSFLine(fp, bRTData);								break;
		case PSF_Section_Fixed_transformer_data:				ExportPSFFixedTransformer(fp, bRTData);					break;
		case PSF_Section_ULTC_transformer_data:					ExportPSFULTCTransformer(fp, bRTData);					break;
		case PSF_Section_Impedance_correction_tables:			ExportPSFImpedanceCorrectionTables(fp, bRTData);		break;
		case PSF_Section_Fixed_series_compensator_data:			ExportPSFFixedSeriesCompensator(fp, bRTData);			break;
		case PSF_Section_Switchable_series_compensator_data:	ExportPSFSwitchableSeriesCompensator(fp, bRTData);		break;
		case PSF_Section_FACTS_device_data:						ExportPSFStaticTapChangerPhaseRegulator(fp, bRTData);	break;
		case PSF_Section_3winding_transformer_data:				ExportPSF3WindingTransformer(fp, bRTData);				break;
		case PSF_Section_Area_interchange_data:					ExportPSFAreaInterchange(fp, bRTData);					break;
		case PSF_Section_Interface_data:																					break;
		case PSF_Section_Multi_terminal_DC_data:				ExportPSFMultiTerminalDC(fp, bRTData);					break;
		case PSF_Section_Zone_data:								ExportPSFZone(fp, bRTData);								break;
		case PSF_Section_Node_mapping_data:						ExportPSFNodeMapping(fp, bRTData);						break;
		case PSF_Section_Zero_seq_mutual_coupling_data:			ExportPSFZeroSequenceMutualCoupling(fp, bRTData);		break;
		case PSF_Section_File_section_data:						ExportPSFFileSection(fp, bRTData);						break;
		case PSF_Section_File_End:																							break;
		}
	}

	fflush(fp);
	fclose(fp);

	return 1;
}

int		CPSFAscii::GetPSFModelRecordNum(const int nTable)
{
	switch (nTable)
	{
	case PSFModel_SolutionHistory:					return 1;													break;
	case PSFModel_Substation:							return m_SubstationArray.size();							break;
	case PSFModel_Bus:								return m_PSFBusArray.size();								break;
	case PSFModel_Generator:						return m_PSFGeneratorArray.size();							break;
	case PSFModel_Load:								return m_PSFLoadArray.size();								break;
	case PSFModel_LoadModel:						return m_PSFLoadModelArray.size();							break;
	case PSFModel_FixedShunt:						return m_PSFFixedShuntArray.size();						break;
	case PSFModel_SwitchableShunt:					return m_PSFSwitchableShuntArray.size();					break;
	case PSFModel_Line:								return m_PSFLineArray.size();								break;
	case PSFModel_FixedTransformer:					return m_PSFFixedTranArray.size();					break;
	case PSFModel_ULTCTransformer:					return m_PSFULTCTranArray.size();					break;
	case PSFModel_ImpedanceCorrectionTables:		return m_PSFImpedanceCorrectionTablesArray.size();			break;
	case PSFModel_FixedSeriesCompensator:			return m_PSFFixedSeriesCompensatorArray.size();			break;
	case PSFModel_SwitchableSeriesCompensator:		return m_PSFSwitchableSeriesCompensatorArray.size();		break;
	case PSFModel_StaticTapChangerPhaseRegulator:	return m_PSFStaticTapChangerPhaseRegulatorArray.size();	break;
	case PSFModel_PSF3WindingTransformer:			return m_PSF3WindingTranArray.size();				break;
	case PSFModel_AreaInterchange:					return m_PSFAreaInterchangeArray.size();					break;
	case PSFModel_Interface:																					break;
	case PSFModel_LineCommutatedConverters:				return m_PSFLCConvertersArray.size();				break;
	case PSFModel_DCLines:								return m_PSFDCLinesArray.size();								break;
	case PSFModel_DCBreakers:							return m_PSFDCBreakersArray.size();							break;
	case PSFModel_DCBuses:								return m_PSFDCBusesArray.size();								break;
	case PSFModel_VoltageSourcedConverter:				return m_PSFVSCArray.size();				break;
	case PSFModel_Zone:								return m_PSFZoneArray.size();								break;
	case PSFModel_NodeMapping:						return m_PSFNodeMappingArray.size();						break;
	case PSFModel_ZeroSequenceMutualCoupling:		return m_PSFZeroSequenceMutualCouplingArray.size();		break;
	case PSFModel_FileSection:						return m_PSFFileSectionArray.size();						break;
	}
	return 0;
}

int	CPSFAscii::FindPSFData(const int nTable, const int nField, const int nStartRecord, const char* lpszKeyValue)
{
	int			nRecord;
	const int	nRecordNum=GetPSFModelRecordNum(nTable);
	for (nRecord=nStartRecord; nRecord<nRecordNum; nRecord++)
	{
		if (g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_STRING)
		{
			if (strstr(GetPSFDataString(nTable, nField, nRecord).c_str(),lpszKeyValue) != NULL)
				return nRecord;
		}
		else if (g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_BIT ||
			g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_SHORT ||
			g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_INT)
		{
			if (GetPSFDataInteger(nTable, nField, nRecord)-atoi(lpszKeyValue) == 0)
				return nRecord;
		}
		else if (g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_FLOAT ||
			g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_DOUBLE)
		{
			if (fabs(GetPSFDataDouble(nTable, nField, nRecord)-atof(lpszKeyValue)) < 0.000001)
				return nRecord;
		}
	}
	for (nRecord=0; nRecord<nStartRecord; nRecord++)
	{
		if (g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_STRING)
		{
			if (strstr(GetPSFDataString(nTable, nField, nRecord).c_str(),lpszKeyValue) != NULL)
				return nRecord;
		}
		else if (g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_BIT ||
			g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_SHORT ||
			g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_INT)
		{
			if (GetPSFDataInteger(nTable, nField, nRecord)-atoi(lpszKeyValue) == 0)
				return nRecord;
		}
		else if (g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_FLOAT ||
			g_PSFModelTables[nTable].pFieldArray[nField].nFieldType == MDB_DOUBLE)
		{
			if (fabs(GetPSFDataDouble(nTable, nField, nRecord)-atof(lpszKeyValue)) < 0.000001)
				return nRecord;
		}
	}

	return -1;
}
