#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <locale.h>

#include "PSFAsciiJNIApi.h"

static	CPSFAscii		m_PSFAscii;
static	CPG2PSFAscii	m_PG2PSFAscii;
static	tagPGBlock*		m_pPGBlock=NULL;
static	char*	lpszLogFile="PSFAsciiJNIApi.log";

static JNINativeMethod m_RegMethodArray[] = {
	{	"initPSFAscii",					"()I"																												,	initPSFAscii				},
	{	"exitPSFAscii",					"()V"																												,	exitPSFAscii				},
	{	"readFile",						"(Ljava/lang/String;)I"																								,	readFile					},
	{	"readMatch",					"(Ljava/lang/String;)I"																								,	readMatch					},
	{	"saveMatch",					"(Ljava/lang/String;)V"																								,	saveMatch					},
	{	"autoMatch",					"()V"																												,	autoMatch					},
	{	"getRecordNum",					"(Ljava/lang/String;)I"																								,	getRecordNum				},
	{	"getRecordValue",				"(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;"															,	getRecordValue				},
	{	"setRecordValue",				"(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)I"														,	setRecordValue				},
	{	"getRecordRowValueArray",		"(Ljava/lang/String;I)[Ljava/lang/String;"																			,	getRecordRowValueArray		},
	{	"getRecordIdxRowsValueArray",	"(Ljava/lang/String;[I)[Ljava/lang/String;"																			,	getRecordIdxRowsValueArray	},
	{	"getZoneFilteredIndexArray",	"(Ljava/lang/String;[Ljava/lang/String;)[I"																			,	getZoneFilteredIndexArray	},
	{	"PGMemDB2PSFAscii",				"(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V"														,	PGMemDB2PSFAscii			},
	{	"PG2PSFAscii",					"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V"	,	PG2PSFAscii					},
};

void	ClearLog()
{
	char	szTempPath[260],szFileName[260];

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPathA(260,szTempPath);
#else
	strcpy(szTempPath,"/tmp");
#endif

	sprintf(szFileName,"%s/%s",szTempPath,lpszLogFile);
	FILE*	fp=fopen(szFileName,"w");
	fflush(fp);
	fclose(fp);
}

void	Log(const char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	char	szTempPath[260],szFileName[260];
	FILE*	fp;

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
	GetTempPath(260,szTempPath);
#else
	strcpy(szTempPath,"/tmp");
#endif

	sprintf(szFileName,"%s/%s",szTempPath,lpszLogFile);
	fp=fopen(szFileName,"a");
	if (fp != NULL)
	{
		vfprintf(fp, pformat, args);

		fflush(fp);
		fclose(fp);
	}

	va_end(args);
}

void	PrintMessage(const char* lpszFormat, ...)
{
	va_list args;
	va_start( args, lpszFormat );

	va_end(args);
}

//	��C�ַ�תΪJAVA�ַ���������OnLoad�е�SetLocalʮ�ֹؼ�
jstring CString2JString( JNIEnv * env, const char* lpszInStrCpp)
{
	size_t	nLen;
	wchar_t	wszBuf[10240];

	nLen=mbstowcs(NULL, lpszInStrCpp, 0);
	mbstowcs(wszBuf, lpszInStrCpp, nLen);
	return env->NewString((jchar*)wszBuf, nLen);
}

//	��JAVA�ַ�תΪC�ַ���������OnLoad�е�SetLocalʮ�ֹؼ�
int JString2CString(JNIEnv * env, jstring jstrInJava, char* lpszOutStrCpp )
{
	unsigned char	bRet=0;

	const	jchar* lpszStr = env -> GetStringChars(jstrInJava, &bRet );
	wcstombs(lpszOutStrCpp, (wchar_t*)lpszStr, 1024);
	env -> ReleaseStringChars(jstrInJava, lpszStr );

	return 1;
}

jint JNICALL JNI_OnLoad(JavaVM * jvm, void * reserved )
{
	JNIEnv * env = NULL;

	ClearLog();

	// Get JNI function interface pointer.
	if(jvm -> GetEnv((void**) &env, JNI_VERSION_1_4 ) != JNI_OK )
	{
		Log("JNI_OnLoad GetEnv Error\n");
		return JNI_ERR;
	}

	if ( env -> RegisterNatives(env -> FindClass("Lcom/tsingsoft/PSFAscii/JPSFAsciiApi;"), m_RegMethodArray, sizeof(m_RegMethodArray)/sizeof(JNINativeMethod) ) < 0)
	{
		Log("JNI_OnLoad RegisterNatives Error\n");
		return JNI_ERR;
	}

	setlocale( LC_ALL, ".ACP" );	//Sets the locale to the ANSI code page obtained from the operating system.

	ClearLog();

	//m_pPGBlock=(tagPGBlock*)PGMemDB::Init_PGBlock();

	Log("JNI_OnLoad PSFAsciiApi\n");

	return JNI_VERSION_1_4;
}

void JNICALL JNI_OnUnload(JavaVM * jvm, void * reserved)
{
	Log("JNI_OnUnload\n");

	//if (m_pPGBlock)		PGMemDB::Exit_PGBlock((char*)m_pPGBlock);
}

jint JNICALL	initPSFAscii(JNIEnv *env, jclass cls)
{
	if (!m_pPGBlock)
		m_pPGBlock=(tagPGBlock*)PGMemDB::Init_PGBlock();
	return 1;
}

void JNICALL	exitPSFAscii(JNIEnv *env, jclass cls)
{
}

jint JNICALL readFile(JNIEnv *env, jclass cls, jstring jstrFileName)
{
	char	szFileName[260];
	memset(szFileName,0,260);
	JString2CString(env, jstrFileName, szFileName);

	clock_t	dBeg,dEnd;
	int		nDur;
	dBeg=clock();

	m_PSFAscii.ImportPSFFile(szFileName, 1);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    ImportPSFFile����ʱ%d����\n",nDur);

	return 1;
}

jint JNICALL readMatch(JNIEnv *env, jclass cls, jstring jstrFileName)
{
	char	szFileName[260];
	memset(szFileName,0,260);
	JString2CString(env, jstrFileName, szFileName);

	clock_t	dBeg,dEnd;
	int		nDur;
	dBeg=clock();

	m_PSFAscii.ReadPSFAscii2CimMatch(szFileName);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    ReadPSFAscii2CimMatch����ʱ%d����\n",nDur);

	return 1;
}

void JNICALL saveMatch(JNIEnv *env, jclass cls, jstring jstrFileName)
{
	char	szFileName[260];
	memset(szFileName,0,260);
	JString2CString(env, jstrFileName, szFileName);

	clock_t	dBeg,dEnd;
	int		nDur;
	dBeg=clock();

	m_PSFAscii.SavePSFAscii2CimMatch(szFileName);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    SavePSFAscii2CimMatch����ʱ%d����\n",nDur);
}

void JNICALL autoMatch(JNIEnv *env, jclass cls)
{
	clock_t	dBeg,dEnd;
	int		nDur;
	dBeg=clock();

	std::vector<std::string>	strFilterZoneArray;
	strFilterZoneArray.clear();

	m_PSFAscii.AutoPSFAscii2CimMatch(m_pPGBlock, 1, strFilterZoneArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	Log("    AutoPSFAscii2CimMatch����ʱ%d����\n",nDur);
}

jint JNICALL getRecordNum(JNIEnv *env, jclass cls, const jstring jstrTable)
{
	char	szTable[MDB_CHARLEN];
	memset(szTable,0,MDB_CHARLEN);
	JString2CString(env, jstrTable, szTable);

	Log("    getRecordNum: %s\n", szTable);

	return m_PSFAscii.GetRecordNum(szTable);
}

jstring JNICALL getRecordValue(JNIEnv *env, jclass cls, const jstring jstrTable, const jstring jstrField, const jint nRecord)
{
	char	szTable[MDB_CHARLEN],szField[MDB_CHARLEN];
	char	szRecordValue[MDB_CHARLEN_LONG];
	memset(szTable,0,MDB_CHARLEN);
	memset(szField,0,MDB_CHARLEN);
	memset(szRecordValue,0,MDB_CHARLEN_LONG);
	JString2CString(env, jstrTable, szTable);
	JString2CString(env, jstrField, szField);

	Log("    getRecordValue: Table=%s Field=%s Record=%d\n", szTable, szField, nRecord);

	if (m_PSFAscii.GetRecordValue(szTable, szField, nRecord, szRecordValue))
		return CString2JString(env, szRecordValue);
	return CString2JString(env, NULL);
}

jint JNICALL setRecordValue(JNIEnv *env, jclass cls, const jstring jstrTable, const jstring jstrField, const jint nRecord, jstring jstrValue)
{
	char	szTable[MDB_CHARLEN],szField[MDB_CHARLEN];
	char	szRecordValue[MDB_CHARLEN_LONG];
	memset(szTable,0,MDB_CHARLEN);
	memset(szField,0,MDB_CHARLEN);
	memset(szRecordValue,0,MDB_CHARLEN_LONG);
	JString2CString(env, jstrTable, szTable);
	JString2CString(env, jstrField, szField);
	JString2CString(env, jstrValue, szRecordValue);

	Log("    setRecordValue: Table=%s Field=%s Record=%d Value=%s\n", szTable, szField, nRecord, szRecordValue);

	return m_PSFAscii.SetRecordValue(szTable, szField, nRecord, szRecordValue);
}

jobjectArray JNICALL getRecordRowValueArray	(JNIEnv *env, jclass cls, const jstring jstrTable, const jint nRecord)
{
	register int	i;
	char	szTable[MDB_CHARLEN];
	std::vector<std::string>	strFieldArray;
	jobjectArray jstrRetArray=0;

	memset(szTable,0,MDB_CHARLEN);
	JString2CString(env, jstrTable, szTable);

	Log("getRecordRowValueArray: Table=%s Record=%d\n",szTable, nRecord);
	m_PSFAscii.GetRecordRowValue(szTable, nRecord, strFieldArray);
	for (i=0; i<(int)strFieldArray.size(); i++)
		Log("        Field[%d]=%s\n",i,strFieldArray[i].c_str());

	jstrRetArray=env->NewObjectArray((jsize)strFieldArray.size(), env->FindClass("java/lang/String"), 0);
	for (i=0; i<(int)strFieldArray.size(); i++)
	{
		env->SetObjectArrayElement(jstrRetArray, i, CString2JString(env, strFieldArray[i].c_str()));//�������jstring
	}
	strFieldArray.clear();

	return jstrRetArray;
}

jobjectArray JNICALL getRecordIdxRowsValueArray(JNIEnv *env, jclass cls, const jstring jstrTable, const jintArray nIndexArray)
{
	int		nRow,nCol,nRowNum;
	char	szTable[MDB_CHARLEN];
	std::vector<std::string>	strFieldArray;
	std::string	strValue;
	jobjectArray jstrRetArray=0;

	memset(szTable,0,MDB_CHARLEN);
	JString2CString(env, jstrTable, szTable);

	nRowNum=env->GetArrayLength( nIndexArray );

	Log("getRecordIdxRowsValueArray: Table=%s RowNum=%d\n",szTable, nRowNum);

	jstrRetArray=env->NewObjectArray((jsize)nRowNum, env->FindClass("java/lang/String"), 0);

	jint* iAry=env->GetIntArrayElements(nIndexArray, 0);
	nRow=0;
	while (nRow < nRowNum)
	{
		m_PSFAscii.GetRecordRowValue(szTable, iAry[nRow], strFieldArray);
		strValue.clear();
		for (nCol=0; nCol<(int)strFieldArray.size(); nCol++)
		{
			if (nCol != 0)
				strValue.append("\\");
			strValue.append(strFieldArray[nCol]);
		}
		Log("        Value [RecNo=%d] Value=%s\n",iAry[nRow], strValue.c_str());

		env->SetObjectArrayElement(jstrRetArray, nRow, CString2JString(env, strValue.c_str()));//�������jstring
		nRow++;
	}
	Log("getRecordIdxRowsValueArray Finished RowNum=%d\n", nRow);

	env->ReleaseIntArrayElements(nIndexArray, iAry, 0);

	return jstrRetArray;
}

jintArray JNICALL getZoneFilteredIndexArray(JNIEnv *env, jclass cls, const jstring jstrTable, jobjectArray jstrFilterZoneArray)
{
	register int	i;
	jintArray	jnRetArray=0;
	char		szBuf[MDB_CHARLEN_LONG];
	char	szTable[MDB_CHARLEN];
	std::vector<std::string>	strFilterZoneArray;
	std::vector<int>			nFilterIndexArray;
	strFilterZoneArray.clear();
	nFilterIndexArray.clear();

	memset(szTable,0,MDB_CHARLEN);
	JString2CString(env, jstrTable, szTable);
	int nLen = env->GetArrayLength( jstrFilterZoneArray );

	Log("getZoneFilteredIndexArray: Table=%s\n",szTable);

	for (i=0; i<nLen; i++)
	{
		jobject		jstrBuf = env->GetObjectArrayElement(jstrFilterZoneArray, i);
		JString2CString(env, (jstring)jstrBuf, szBuf);
		Log("        Zone[%d]=%s\n",i,szBuf);
		strFilterZoneArray.push_back(szBuf);
	}

	m_PSFAscii.GetZoneFilterIndexArray(szTable, strFilterZoneArray, nFilterIndexArray);

	if (!nFilterIndexArray.empty())
	{
		jint	jnBuf;
		jnRetArray=env->NewIntArray((jsize)nFilterIndexArray.size());
		for (i=0; i<(int)nFilterIndexArray.size(); i++)
		{
			Log("                RetValue[%d]=%d\n",i,nFilterIndexArray[i]);
			jnBuf=nFilterIndexArray[i];
			env->SetIntArrayRegion(jnRetArray, i, 1, &jnBuf);
		}
	}
	nFilterIndexArray.clear();

	return jnRetArray;
}

void JNICALL PGMemDB2PSFAscii(JNIEnv *env, jclass cls, const jstring jstrMatchFileName, const jstring jstrOutFileName, jobjectArray jstrFilterZoneArray)
{
	register int	i;
	jintArray	jnRetArray=0;
	char	szBuf[MDB_CHARLEN_LONG];
	char	szMatchFileName[260],szOutFileName[260];
	std::vector<std::string>	strFilterZoneArray;
	strFilterZoneArray.clear();

	memset(szMatchFileName,0,260);
	memset(szOutFileName,0,260);
	JString2CString(env, jstrMatchFileName, szMatchFileName);
	JString2CString(env, jstrOutFileName, szOutFileName);

	int nLen = env->GetArrayLength( jstrFilterZoneArray );
	for (i=0; i<nLen; i++)
	{
		jobject		jstrBuf = env->GetObjectArrayElement(jstrFilterZoneArray, i);
		JString2CString(env, (jstring)jstrBuf, szBuf);
		strFilterZoneArray.push_back(szBuf);
	}

	m_PSFAscii.PGMemDB2PSFAscii(m_pPGBlock, 1, szMatchFileName, strFilterZoneArray);
	m_PSFAscii.ExportPSFFile(szOutFileName, 1);

	strFilterZoneArray.clear();
}

void JNICALL PG2PSFAscii(JNIEnv *env, jclass cls, const jstring strPowerNetName, const jstring jstrMatchFileName, const jstring jstrBoundFileName, const jstring jstrShortNameFileName, const jstring jstrOutFileName, jobjectArray jstrFilterZoneArray)
{
	register int	i;
	char	szBuf[MDB_CHARLEN_LONG];
	char	szPowerNet[260],szMatchFileName[260],szBoundFileName[260],szShortNameFileName[260],szOutFileName[260];
	std::vector<std::string>	strFilterZoneArray;
	strFilterZoneArray.clear();
	int nLen = env->GetArrayLength( jstrFilterZoneArray );
	for (i=0; i<nLen; i++)
	{
		jobject		jstrBuf = env->GetObjectArrayElement(jstrFilterZoneArray, i);
		JString2CString(env, (jstring)jstrBuf, szBuf);
		strFilterZoneArray.push_back(szBuf);
	}

	memset(szPowerNet,0,260);
	memset(szMatchFileName,0,260);
	memset(szBoundFileName,0,260);
	memset(szShortNameFileName,0,260);
	memset(szOutFileName,0,260);
	JString2CString(env, strPowerNetName, szPowerNet);
	JString2CString(env, jstrMatchFileName, szMatchFileName);
	JString2CString(env, jstrBoundFileName, szBoundFileName);
	JString2CString(env, jstrShortNameFileName, szShortNameFileName);
	JString2CString(env, jstrOutFileName, szOutFileName);

	m_PSFAscii.ReadPSFAscii2CimMatch(szMatchFileName);
	m_PSFAscii.AutoPSFAscii2CimMatch(m_pPGBlock, 1, strFilterZoneArray);

	m_PG2PSFAscii.LoadBoundLine(szBoundFileName);
	m_PG2PSFAscii.LoadSubstationShortName(m_pPGBlock, szShortNameFileName);

	m_PG2PSFAscii.PG2PSFAscii(m_pPGBlock, &m_PSFAscii, 0.0001, szPowerNet, szOutFileName, strFilterZoneArray);

	strFilterZoneArray.clear();
}
