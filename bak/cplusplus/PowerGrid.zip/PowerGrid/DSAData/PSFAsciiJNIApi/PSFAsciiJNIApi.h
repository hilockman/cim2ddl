/*
 * Copyright (c) 2013, Tsingsoft. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 */

# ifndef _JMEMDBAPI_H_
# define _JMEMDBAPI_H_

# include <jni.h>

#include "../../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif
using namespace	PGMemDB;

#include "../PSFAscii.h"
#include "../PG2PSFAscii.h"

// # ifdef __cplusplus
// extern "C" {
// # endif

///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// JNI Onload and OnUnload Handlers                                          //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

JNIEXPORT jint			JNICALL JNI_OnLoad					(JavaVM*, void*);
JNIEXPORT void			JNICALL JNI_OnUnload				(JavaVM*, void*);

JNIEXPORT jint			JNICALL initPSFAscii				(JNIEnv* env, jclass cls);
JNIEXPORT void			JNICALL exitPSFAscii				(JNIEnv* env, jclass cls);
JNIEXPORT jint			JNICALL readFile					(JNIEnv* env, jclass cls, jstring jstrFileName);
JNIEXPORT jint			JNICALL readMatch					(JNIEnv* env, jclass cls, jstring jstrFileName);
JNIEXPORT void			JNICALL saveMatch					(JNIEnv* env, jclass cls, jstring jstrFileName);
JNIEXPORT void			JNICALL autoMatch					(JNIEnv* env, jclass cls);
JNIEXPORT jint			JNICALL getRecordNum				(JNIEnv* env, jclass cls, const jstring jstrTable);
JNIEXPORT jstring		JNICALL getRecordValue				(JNIEnv* env, jclass cls, const jstring jstrTable, const jstring jstrField, const jint nRecord);
JNIEXPORT jint			JNICALL setRecordValue				(JNIEnv* env, jclass cls, const jstring jstrTable, const jstring jstrField, const jint nRecord, const jstring lpszValue);
JNIEXPORT jobjectArray	JNICALL getRecordRowValueArray		(JNIEnv *env, jclass cls, const jstring jstrTable, const jint nRecord);
JNIEXPORT jobjectArray	JNICALL getRecordIdxRowsValueArray	(JNIEnv *env, jclass cls, const jstring jstrTable, const jintArray nIndexArray);
JNIEXPORT jintArray		JNICALL	getZoneFilteredIndexArray	(JNIEnv *env, jclass cls, const jstring jstrTable, const jobjectArray jstrFilterZoneArray);
JNIEXPORT void			JNICALL PGMemDB2PSFAscii			(JNIEnv* env, jclass cls, const jstring jstrMatchFileName, const jstring jstrOutFileName, const jobjectArray jstrFilterZoneArray);
JNIEXPORT void			JNICALL PG2PSFAscii					(JNIEnv* env, jclass cls, const jstring strPowerNetName, const jstring jstrMatchFileName, const jstring jstrBoundFileName, const jstring jstrShortNameFileName, const jstring jstrOutFileName, const jobjectArray jstrFilterZoneArray);

// # ifdef __cplusplus
// }
// # endif
#endif