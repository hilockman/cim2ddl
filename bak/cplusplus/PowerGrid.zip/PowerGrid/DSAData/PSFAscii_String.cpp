#include "StdAfx.h"
#include "PSFAscii.h"

std::string	toString(const double fBuf)
{
	char	szBuf[MDB_CHARLEN_LONG];
	memset(szBuf,0,MDB_CHARLEN_LONG);

	sprintf(szBuf,"%f",fBuf);
	return szBuf;
}

std::string	toString(const float fBuf)
{
	char	szBuf[MDB_CHARLEN_LONG];
	memset(szBuf,0,MDB_CHARLEN_LONG);

	sprintf(szBuf,"%f",fBuf);
	return szBuf;
}

std::string	toString(const int nBuf)
{
	char	szBuf[MDB_CHARLEN_LONG];
	memset(szBuf,0,MDB_CHARLEN_LONG);

	sprintf(szBuf,"%d",nBuf);
	return szBuf;
}

std::string	toString(const short nBuf)
{
	char	szBuf[MDB_CHARLEN_LONG];
	memset(szBuf,0,MDB_CHARLEN_LONG);

	sprintf(szBuf,"%d",nBuf);
	return szBuf;
}

std::string	toString(const unsigned char bBuf)
{
	char	szBuf[MDB_CHARLEN_LONG];
	memset(szBuf,0,MDB_CHARLEN_LONG);

	sprintf(szBuf,"%d",bBuf);
	return szBuf;
}

double	CPSFAscii::GetPSFDataDouble(const int nTable, const int nField, const int nRecord)
{
	return atof(GetPSFDataString(nTable, nField, nRecord).c_str());
}

int	CPSFAscii::GetPSFDataInteger(const int nTable, const int nField, const int nRecord)
{
	return atoi(GetPSFDataString(nTable, nField, nRecord).c_str());
}

std::string	CPSFAscii::GetPSFDataString(const int nTable, const int nField, const int nRecord)
{
	std::string	strValue="";

	if (nTable < 0 || nTable >= sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable))
		return strValue;

	switch (nTable)
	{
	case PSFModel_SolutionHistory:
		{
			switch (nField)
			{
			case PSFSolutionHistory_Date:			strValue=m_PSFSolution.szDate;										break;
			case PSFSolutionHistory_Time:			strValue=m_PSFSolution.szTime;										break;
			case PSFSolutionHistory_BaseMVA:		strValue=toString(m_PSFSolution.fBaseMVA);							break;
			case PSFSolutionHistory_Method:			strValue=m_PSFSolution.szMethod;									break;
			case PSFSolutionHistory_ITER:			strValue=toString(m_PSFSolution.nITER);							break;
			case PSFSolutionHistory_SOLTOL:			strValue=toString(m_PSFSolution.fSOLTOL);							break;
			case PSFSolutionHistory_BLUP:			strValue=toString(m_PSFSolution.fBLUP);							break;
			case PSFSolutionHistory_ACCFCT:			strValue=toString(m_PSFSolution.fACCFCT);							break;
			case PSFSolutionHistory_ZIL:			strValue=toString(m_PSFSolution.fZIL);								break;
			case PSFSolutionHistory_VTOL:			strValue=toString(m_PSFSolution.fVTOL);							break;
			case PSFSolutionHistory_CONADJ:			strValue=toString(m_PSFSolution.fCONADJ);							break;
			case PSFSolutionHistory_STOPT:			strValue=m_PSFSolution.szSTOPT;									break;
			case PSFSolutionHistory_Flag1:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag1 ];	break;
			case PSFSolutionHistory_Flag2:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag2 ];	break;
			case PSFSolutionHistory_Flag3:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag3 ];	break;
			case PSFSolutionHistory_Flag4:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag4 ];	break;
			case PSFSolutionHistory_Flag5:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag5 ];	break;
			case PSFSolutionHistory_Flag6:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag6 ];	break;
			case PSFSolutionHistory_Flag7:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag7 ];	break;
			case PSFSolutionHistory_Flag8:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag8 ];	break;
			case PSFSolutionHistory_Flag9:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag9 ];	break;
			case PSFSolutionHistory_Flag10:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag10];	break;
			case PSFSolutionHistory_Flag11:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag11];	break;
			case PSFSolutionHistory_Flag12:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag12];	break;
			case PSFSolutionHistory_Flag13:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag13];	break;
			case PSFSolutionHistory_Flag14:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag14];	break;
			case PSFSolutionHistory_Flag15:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag15];	break;
			case PSFSolutionHistory_Flag16:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag16];	break;
			case PSFSolutionHistory_Flag17:			strValue=g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag17];	break;
			case PSFSolutionHistory_Description1:	strValue=m_PSFSolution.szDescription1;								break;
			case PSFSolutionHistory_Description2:	strValue=m_PSFSolution.szDescription2;								break;
			case PSFSolutionHistory_Description3:	strValue=m_PSFSolution.szDescription3;								break;
			}
		}
		break;

	case PSFModel_Substation:
		{
			switch (nField)
			{
			case PSFSubstation_Name:			strValue=m_SubstationArray[nRecord].szName;		break;
			case PSFSubstation_Type:			strValue=toString(m_SubstationArray[nRecord].nType);	break;
			case PSFSubstation_RTName:			strValue=m_SubstationArray[nRecord].szRTName;	break;
			}
		}

		break;

	case PSFModel_Bus:
		{
			switch (nField)
			{
			case PSFBus_Number:			strValue=toString(m_PSFBusArray[nRecord].nNumber);			break;
			case PSFBus_Name:			strValue=m_PSFBusArray[nRecord].szName;					break;
			case PSFBus_Voltage:		strValue=toString(m_PSFBusArray[nRecord].fVoltage);		break;
			case PSFBus_Angle:			strValue=toString(m_PSFBusArray[nRecord].fAngle);			break;
			case PSFBus_kV:				strValue=toString(m_PSFBusArray[nRecord].fkV);				break;
			case PSFBus_Type:			strValue=toString(m_PSFBusArray[nRecord].nType);			break;
			case PSFBus_Status:			strValue=toString(m_PSFBusArray[nRecord].nStatus);			break;
			case PSFBus_Area:			strValue=toString(m_PSFBusArray[nRecord].nArea);			break;
			case PSFBus_Zone:			strValue=toString(m_PSFBusArray[nRecord].nZone);			break;
			case PSFBus_D1:				strValue=toString(m_PSFBusArray[nRecord].nD1);				break;
			case PSFBus_D2:				strValue=toString(m_PSFBusArray[nRecord].nD2);				break;
			case PSFBus_D3:				strValue=toString(m_PSFBusArray[nRecord].nD3);				break;
			case PSFBus_D4:				strValue=toString(m_PSFBusArray[nRecord].nD4);				break;
			case PSFBus_D5:				strValue=toString(m_PSFBusArray[nRecord].nD5);				break;
			case PSFBus_Owner:			strValue=m_PSFBusArray[nRecord].szOwner;					break;
			case PSFBus_EquipmentName:	strValue=m_PSFBusArray[nRecord].szEquipmentName;			break;
			case PSFBus_Latitude:		strValue=toString(m_PSFBusArray[nRecord].fLatitude);		break;
			case PSFBus_Longitude:		strValue=toString(m_PSFBusArray[nRecord].fLongitude);		break;
			case PSFBus_Substation:		strValue=m_PSFBusArray[nRecord].szSubstation;				break;
			case PSFBusEx_RTStatus:		strValue=toString(m_PSFBusArray[nRecord].nRTStatus);		break;
			}
		}

		break;

	case PSFModel_Generator:
		{
			switch (nField)
			{
			case PSFGenerator_BusNumber:				strValue=toString(m_PSFGeneratorArray[nRecord].nBusNumber);				break;
			case PSFGenerator_ID:						strValue=m_PSFGeneratorArray[nRecord].szID;								break;
			case PSFGenerator_Status:					strValue=toString(m_PSFGeneratorArray[nRecord].nStatus);					break;
			case PSFGenerator_MW:						strValue=toString(m_PSFGeneratorArray[nRecord].fMW);						break;
			case PSFGenerator_MVAR:						strValue=toString(m_PSFGeneratorArray[nRecord].fMVar);						break;
			case PSFGenerator_QMAX:						strValue=toString(m_PSFGeneratorArray[nRecord].fQMax);						break;
			case PSFGenerator_QMIN:						strValue=toString(m_PSFGeneratorArray[nRecord].fQMin);						break;
			case PSFGenerator_VHiLimit:					strValue=toString(m_PSFGeneratorArray[nRecord].fVHiLimit);					break;
			case PSFGenerator_VLoLimit:					strValue=toString(m_PSFGeneratorArray[nRecord].fVLoLimit);					break;
			case PSFGenerator_RemoteBus:				strValue=toString(m_PSFGeneratorArray[nRecord].nRemoteBus);				break;
			case PSFGenerator_RemoteBusV:				strValue=toString(m_PSFGeneratorArray[nRecord].fRemoteBusV);				break;
			case PSFGenerator_QContributionPercentCtrl:	strValue=toString(m_PSFGeneratorArray[nRecord].fQContributionPercentCtrl);	break;
			case PSFGenerator_USCHQ:					strValue=toString(m_PSFGeneratorArray[nRecord].nUSCHQ);					break;
			case PSFGenerator_MVA:						strValue=toString(m_PSFGeneratorArray[nRecord].fMva);						break;
			case PSFGenerator_PMAX:						strValue=toString(m_PSFGeneratorArray[nRecord].fPMax);						break;
			case PSFGenerator_PMIN:						strValue=toString(m_PSFGeneratorArray[nRecord].fPMin);						break;
			case PSFGenerator_RS:						strValue=toString(m_PSFGeneratorArray[nRecord].fRS);						break;
			case PSFGenerator_XS:						strValue=toString(m_PSFGeneratorArray[nRecord].fXS);						break;
			case PSFGenerator_RT:						strValue=toString(m_PSFGeneratorArray[nRecord].fRT);						break;
			case PSFGenerator_XT:						strValue=toString(m_PSFGeneratorArray[nRecord].fXT);						break;
			case PSFGenerator_TAP:						strValue=toString(m_PSFGeneratorArray[nRecord].fTAP);						break;
			case PSFGenerator_EquipmentName:			strValue=m_PSFGeneratorArray[nRecord].szEquipmentName;						break;
			case PSFGenerator_Owner:					strValue=m_PSFGeneratorArray[nRecord].szOwner;								break;
			case PSFGenerator_GWMOD:					strValue=toString(m_PSFGeneratorArray[nRecord].nGWMOD);					break;
			case PSFGenerator_GWPF:						strValue=toString(m_PSFGeneratorArray[nRecord].fGWPF);						break;
			case PSFGenerator_GBASLD:					strValue=toString(m_PSFGeneratorArray[nRecord].nGBASLD);					break;
			case PSFGenerator_RP:						strValue=toString(m_PSFGeneratorArray[nRecord].fRP);						break;
			case PSFGenerator_XP:						strValue=toString(m_PSFGeneratorArray[nRecord].fXP);						break;
			case PSFGenerator_RN:						strValue=toString(m_PSFGeneratorArray[nRecord].fRN);						break;
			case PSFGenerator_XN:						strValue=toString(m_PSFGeneratorArray[nRecord].fXN);						break;
			case PSFGenerator_RZ:						strValue=toString(m_PSFGeneratorArray[nRecord].fRZ);						break;
			case PSFGenerator_XZ:						strValue=toString(m_PSFGeneratorArray[nRecord].fXZ);						break;
			case PSFGenerator_RG:						strValue=toString(m_PSFGeneratorArray[nRecord].fRG);						break;
			case PSFGenerator_XG:						strValue=toString(m_PSFGeneratorArray[nRecord].fXG);						break;
			case PSFGeneratorEx_BusName:				strValue=m_PSFGeneratorArray[nRecord].szBusName;							break;
			case PSFGeneratorEx_RTName:					strValue=m_PSFGeneratorArray[nRecord].szRTName;							break;
			case PSFGeneratorEx_RTMW:					strValue=toString(m_PSFGeneratorArray[nRecord].fRTMW);						break;
			case PSFGeneratorEx_RTMVar:					strValue=toString(m_PSFGeneratorArray[nRecord].fRTMVar);					break;
			case PSFGeneratorEx_RTVoltage:				strValue=toString(m_PSFGeneratorArray[nRecord].fRTVoltage);				break;
			case PSFGeneratorEx_RTStatus:				strValue=toString(m_PSFGeneratorArray[nRecord].nRTStatus);					break;
			}
		}
		break;

	case PSFModel_Load:
		{
			switch (nField)
			{
			case PSFLoad_BusNumber:		strValue=toString(m_PSFLoadArray[nRecord].nBusNumber);		break;
			case PSFLoad_RefP:			strValue=toString(m_PSFLoadArray[nRecord].fRefP);			break;
			case PSFLoad_RefQ:			strValue=toString(m_PSFLoadArray[nRecord].fRefQ);			break;
			case PSFLoad_P1:			strValue=toString(m_PSFLoadArray[nRecord].fP1);			break;
			case PSFLoad_Q1:			strValue=toString(m_PSFLoadArray[nRecord].fQ1);			break;
			case PSFLoad_P2:			strValue=toString(m_PSFLoadArray[nRecord].fP2);			break;
			case PSFLoad_Q2:			strValue=toString(m_PSFLoadArray[nRecord].fQ2);			break;
			case PSFLoad_P3:			strValue=toString(m_PSFLoadArray[nRecord].fP3);			break;
			case PSFLoad_Q3:			strValue=toString(m_PSFLoadArray[nRecord].fQ3);			break;
			case PSFLoad_P4:			strValue=toString(m_PSFLoadArray[nRecord].fP4);			break;
			case PSFLoad_Q4:			strValue=toString(m_PSFLoadArray[nRecord].fQ4);			break;
			case PSFLoad_P5:			strValue=toString(m_PSFLoadArray[nRecord].fP5);			break;
			case PSFLoad_Q5:			strValue=toString(m_PSFLoadArray[nRecord].fQ5);			break;
			case PSFLoad_M1:			strValue=toString(m_PSFLoadArray[nRecord].nM1);			break;
			case PSFLoad_M2:			strValue=toString(m_PSFLoadArray[nRecord].nM2);			break;
			case PSFLoad_M3:			strValue=toString(m_PSFLoadArray[nRecord].nM3);			break;
			case PSFLoad_M4:			strValue=toString(m_PSFLoadArray[nRecord].nM4);			break;
			case PSFLoad_M5:			strValue=toString(m_PSFLoadArray[nRecord].nM5);			break;
			case PSFLoad_Type:			strValue=toString(m_PSFLoadArray[nRecord].nType);			break;
			case PSFLoad_Owner:			strValue=m_PSFLoadArray[nRecord].szOwner;					break;
			case PSFLoad_ID:			strValue=m_PSFLoadArray[nRecord].szID;						break;
			case PSFLoad_Scalable:		strValue=toString(m_PSFLoadArray[nRecord].nScalable);		break;
			case PSFLoad_EquipmentName:	strValue=m_PSFLoadArray[nRecord].szEquipmentName;			break;
			case PSFLoad_Area:			strValue=toString(m_PSFLoadArray[nRecord].nArea);			break;
			case PSFLoad_Zone:			strValue=toString(m_PSFLoadArray[nRecord].nZone);			break;
			case PSFLoad_Status:		strValue=toString(m_PSFLoadArray[nRecord].nStatus);		break;
			case PSFLoad_GN:			strValue=toString(m_PSFLoadArray[nRecord].fGN);			break;
			case PSFLoad_BN:			strValue=toString(m_PSFLoadArray[nRecord].fBN);			break;
			case PSFLoad_GZ:			strValue=toString(m_PSFLoadArray[nRecord].fGZ);			break;
			case PSFLoad_BZ:			strValue=toString(m_PSFLoadArray[nRecord].fBZ);			break;
			case PSFLoadEx_BusName:		strValue=m_PSFLoadArray[nRecord].szBusName;				break;
			case PSFLoadEx_RTName:		strValue=m_PSFLoadArray[nRecord].szRTName;					break;
			case PSFLoadEx_RTP:			strValue=toString(m_PSFLoadArray[nRecord].fRTP);			break;
			case PSFLoadEx_RTQ:			strValue=toString(m_PSFLoadArray[nRecord].fRTQ);			break;
			case PSFLoadEx_RTStatus:	strValue=toString(m_PSFLoadArray[nRecord].nRTStatus);		break;
			}
		}
		break;

	case PSFModel_LoadModel:
		{
			switch (nField)
			{
			case PSFLoadModel_ModelNumber:	strValue=toString(m_PSFLoadModelArray[nRecord].nModelNumber);	break;
			case PSFLoadModel_A1:			strValue=toString(m_PSFLoadModelArray[nRecord].fA1);			break;
			case PSFLoadModel_A2:			strValue=toString(m_PSFLoadModelArray[nRecord].fA2);			break;
			case PSFLoadModel_A3:			strValue=toString(m_PSFLoadModelArray[nRecord].fA3);			break;
			case PSFLoadModel_N1:			strValue=toString(m_PSFLoadModelArray[nRecord].fN1);			break;
			case PSFLoadModel_N2:			strValue=toString(m_PSFLoadModelArray[nRecord].fN2);			break;
			case PSFLoadModel_N3:			strValue=toString(m_PSFLoadModelArray[nRecord].fN3);			break;
			case PSFLoadModel_B1:			strValue=toString(m_PSFLoadModelArray[nRecord].fB1);			break;
			case PSFLoadModel_B2:			strValue=toString(m_PSFLoadModelArray[nRecord].fB2);			break;
			case PSFLoadModel_B3:			strValue=toString(m_PSFLoadModelArray[nRecord].fB3);			break;
			case PSFLoadModel_M1:			strValue=toString(m_PSFLoadModelArray[nRecord].fM1);			break;
			case PSFLoadModel_M2:			strValue=toString(m_PSFLoadModelArray[nRecord].fM2);			break;
			case PSFLoadModel_M3:			strValue=toString(m_PSFLoadModelArray[nRecord].fM3);			break;
			}
		}
		break;

	case PSFModel_FixedShunt:
		{
			switch (nField)
			{
			case PSFFixedShunt_BusNumber:		strValue=toString(m_PSFFixedShuntArray[nRecord].nBusNumber);	break;
			case PSFFixedShunt_G:				strValue=toString(m_PSFFixedShuntArray[nRecord].fG);			break;
			case PSFFixedShunt_B:				strValue=toString(m_PSFFixedShuntArray[nRecord].fB);			break;
			case PSFFixedShunt_Type:			strValue=toString(m_PSFFixedShuntArray[nRecord].nType);		break;
			case PSFFixedShunt_Owner:			strValue=m_PSFFixedShuntArray[nRecord].szOwner;				break;
			case PSFFixedShunt_ID:				strValue=m_PSFFixedShuntArray[nRecord].szID;					break;
			case PSFFixedShunt_EquipmentName:	strValue=m_PSFFixedShuntArray[nRecord].szEquipmentName;		break;
			case PSFFixedShunt_Status:			strValue=toString(m_PSFFixedShuntArray[nRecord].nStatus);		break;
			case PSFFixedShunt_GN:				strValue=toString(m_PSFFixedShuntArray[nRecord].fGN);			break;
			case PSFFixedShunt_BN:				strValue=toString(m_PSFFixedShuntArray[nRecord].fBN);			break;
			case PSFFixedShunt_GZ:				strValue=toString(m_PSFFixedShuntArray[nRecord].fGZ);			break;
			case PSFFixedShunt_BZ:				strValue=toString(m_PSFFixedShuntArray[nRecord].fBZ);			break;
			case PSFFixedShuntEx_BusName:		strValue=m_PSFFixedShuntArray[nRecord].szBusName;				break;
			case PSFFixedShuntEx_RTName:		strValue=m_PSFFixedShuntArray[nRecord].szRTName;				break;
			}
		}
		break;

	case PSFModel_SwitchableShunt:
		{
			switch (nField)
			{
			case PSFSwitchableShunt_BusNumber:					strValue=toString(m_PSFSwitchableShuntArray[nRecord].nBusNumber);					break;
			case PSFSwitchableShunt_Mode:						strValue=toString(m_PSFSwitchableShuntArray[nRecord].nMode);						break;
			case PSFSwitchableShunt_Status:						strValue=toString(m_PSFSwitchableShuntArray[nRecord].nStatus);						break;
			case PSFSwitchableShunt_VHiLimit:					strValue=toString(m_PSFSwitchableShuntArray[nRecord].fVHiLimit);					break;
			case PSFSwitchableShunt_VLoLimit:					strValue=toString(m_PSFSwitchableShuntArray[nRecord].fVLoLimit);					break;
			case PSFSwitchableShunt_RemoteBus:					strValue=toString(m_PSFSwitchableShuntArray[nRecord].nRemoteBus);					break;
			case PSFSwitchableShunt_RemoteBusVoltage:			strValue=toString(m_PSFSwitchableShuntArray[nRecord].fRemoteBusVoltage);			break;
			case PSFSwitchableShunt_QContributionPercentCtrl:	strValue=toString(m_PSFSwitchableShuntArray[nRecord].fQContributionPercentCtrl);	break;
			case PSFSwitchableShunt_G0:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fG0);							break;
			case PSFSwitchableShunt_B0:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fB0);							break;
			case PSFSwitchableShunt_Owner:						strValue=m_PSFSwitchableShuntArray[nRecord].szOwner;								break;
			case PSFSwitchableShunt_ID:							strValue=m_PSFSwitchableShuntArray[nRecord].szID;									break;
			case PSFSwitchableShunt_N1:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN1);							break;
			case PSFSwitchableShunt_B1:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN1);							break;
			case PSFSwitchableShunt_N2:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN2);							break;
			case PSFSwitchableShunt_B2:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN2);							break;
			case PSFSwitchableShunt_N3:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN3);							break;
			case PSFSwitchableShunt_B3:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN3);							break;
			case PSFSwitchableShunt_N4:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN4);							break;
			case PSFSwitchableShunt_B4:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN4);							break;
			case PSFSwitchableShunt_N5:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN5);							break;
			case PSFSwitchableShunt_B5:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN5);							break;
			case PSFSwitchableShunt_N6:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN6);							break;
			case PSFSwitchableShunt_B6:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN6);							break;
			case PSFSwitchableShunt_N7:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN7);							break;
			case PSFSwitchableShunt_B7:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN7);							break;
			case PSFSwitchableShunt_N8:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].nN8);							break;
			case PSFSwitchableShunt_B8:							strValue=toString(m_PSFSwitchableShuntArray[nRecord].fN8);							break;
			case PSFSwitchableShunt_IMAX:						strValue=toString(m_PSFSwitchableShuntArray[nRecord].fIMAX);						break;
			case PSFSwitchableShunt_EquipmentName:				strValue=m_PSFSwitchableShuntArray[nRecord].szEquipmentName;						break;
			case PSFSwitchableShunt_RVULimit:					strValue=toString(m_PSFSwitchableShuntArray[nRecord].fRVULimit);					break;
			case PSFSwitchableShunt_RVLLimit:					strValue=toString(m_PSFSwitchableShuntArray[nRecord].fRVLLimit);					break;
			case PSFSwitchableShuntEx_BusName:					strValue=m_PSFSwitchableShuntArray[nRecord].szBusName;								break;
			case PSFSwitchableShuntEx_RTName:					strValue=m_PSFSwitchableShuntArray[nRecord].szRTName;								break;
			}
		}
		break;

	case PSFModel_Line:
		{
			switch (nField)
			{
			case PSFLine_Bus1Number:	strValue=toString(m_PSFLineArray[nRecord].nBus1Number);			break;
			case PSFLine_Bus2Number:	strValue=toString(m_PSFLineArray[nRecord].nBus2Number);			break;
			case PSFLine_ID:			strValue=m_PSFLineArray[nRecord].szID;								break;
			case PSFLine_Section:		strValue=toString(m_PSFLineArray[nRecord].nSection);				break;
			case PSFLine_Status:		strValue=toString(m_PSFLineArray[nRecord].nStatus);				break;
			case PSFLine_MeterEnd:		strValue=g_lpszPSF_MeterEnd[m_PSFLineArray[nRecord].nMeterEnd];	break;
			case PSFLine_R:				strValue=toString(m_PSFLineArray[nRecord].fR);						break;
			case PSFLine_X:				strValue=toString(m_PSFLineArray[nRecord].fX);						break;
			case PSFLine_G:				strValue=toString(m_PSFLineArray[nRecord].fG);						break;
			case PSFLine_B:				strValue=toString(m_PSFLineArray[nRecord].fB);						break;
			case PSFLine_GF:			strValue=toString(m_PSFLineArray[nRecord].fGF);					break;
			case PSFLine_BF:			strValue=toString(m_PSFLineArray[nRecord].fBF);					break;
			case PSFLine_GT:			strValue=toString(m_PSFLineArray[nRecord].fGT);					break;
			case PSFLine_BT:			strValue=toString(m_PSFLineArray[nRecord].fBT);					break;
			case PSFLine_R1:			strValue=toString(m_PSFLineArray[nRecord].fR1);					break;
			case PSFLine_R2:			strValue=toString(m_PSFLineArray[nRecord].fR2);					break;
			case PSFLine_R3:			strValue=toString(m_PSFLineArray[nRecord].fR3);					break;
			case PSFLine_R4:			strValue=toString(m_PSFLineArray[nRecord].fR4);					break;
			case PSFLine_R5:			strValue=toString(m_PSFLineArray[nRecord].fR5);					break;
			case PSFLine_R6:			strValue=toString(m_PSFLineArray[nRecord].fR6);					break;
			case PSFLine_RatingGroup:	strValue=toString(m_PSFLineArray[nRecord].nRatingGroup);			break;
			case PSFLine_Z1:			strValue=toString(m_PSFLineArray[nRecord].fZ1);					break;
			case PSFLine_Z2:			strValue=toString(m_PSFLineArray[nRecord].fZ2);					break;
			case PSFLine_Z3:			strValue=toString(m_PSFLineArray[nRecord].fZ3);					break;
			case PSFLine_Z4:			strValue=toString(m_PSFLineArray[nRecord].fZ4);					break;
			case PSFLine_Z5:			strValue=toString(m_PSFLineArray[nRecord].fZ5);					break;
			case PSFLine_Z6:			strValue=toString(m_PSFLineArray[nRecord].fZ6);					break;
			case PSFLine_Type:			strValue=toString(m_PSFLineArray[nRecord].nType);					break;
			case PSFLine_EquipmentName:	strValue=m_PSFLineArray[nRecord].szEquipmentName;					break;
			case PSFLine_Owner:			strValue=m_PSFLineArray[nRecord].szOwner;							break;
			case PSFLine_Length:		strValue=toString(m_PSFLineArray[nRecord].fLength);				break;
			case PSFLine_RZ:			strValue=toString(m_PSFLineArray[nRecord].fRZ);					break;
			case PSFLine_XZ:			strValue=toString(m_PSFLineArray[nRecord].fXZ);					break;
			case PSFLine_RZC:			strValue=toString(m_PSFLineArray[nRecord].fRZC);					break;
			case PSFLine_XZC:			strValue=toString(m_PSFLineArray[nRecord].fXZC);					break;
			case PSFLine_RZSF:			strValue=toString(m_PSFLineArray[nRecord].fRZSF);					break;
			case PSFLine_XZSF:			strValue=toString(m_PSFLineArray[nRecord].fXZSF);					break;
			case PSFLine_RZST:			strValue=toString(m_PSFLineArray[nRecord].fRZST);					break;
			case PSFLine_XZST:			strValue=toString(m_PSFLineArray[nRecord].fXZST);					break;
			case PSFLineEx_Bus1Name:	strValue=m_PSFLineArray[nRecord].szBus1Name;						break;
			case PSFLineEx_Bus2Name:	strValue=m_PSFLineArray[nRecord].szBus2Name;						break;
			case PSFLineEx_PSFName:		strValue=m_PSFLineArray[nRecord].szPSFName;						break;
			case PSFLineEx_RTName:		strValue=m_PSFLineArray[nRecord].szRTName;							break;
			case PSFLineEx_RTP1:		strValue=toString(m_PSFLineArray[nRecord].fRTP1);					break;
			case PSFLineEx_RTQ1:		strValue=toString(m_PSFLineArray[nRecord].fRTQ1);					break;
			case PSFLineEx_RTP2:		strValue=toString(m_PSFLineArray[nRecord].fRTP2);					break;
			case PSFLineEx_RTQ2:		strValue=toString(m_PSFLineArray[nRecord].fRTQ2);					break;
			case PSFLineEx_RTStatus:	strValue=toString(m_PSFLineArray[nRecord].nRTStatus);				break;
			}
		}
		break;

	case PSFModel_FixedTransformer:
		{
			switch (nField)
			{
			case PSFFixedTransformer_Bus1Number:			strValue=toString(m_PSFFixedTranArray[nRecord].nBus1Number);			break;
			case PSFFixedTransformer_Bus2Number:			strValue=toString(m_PSFFixedTranArray[nRecord].nBus2Number);			break;
			case PSFFixedTransformer_ID:					strValue=m_PSFFixedTranArray[nRecord].szID;								break;
			case PSFFixedTransformer_Section:				strValue=toString(m_PSFFixedTranArray[nRecord].nSection);				break;
			case PSFFixedTransformer_Status:				strValue=toString(m_PSFFixedTranArray[nRecord].nStatus);				break;
			case PSFFixedTransformer_MeterEnd:				strValue=g_lpszPSF_MeterEnd[m_PSFFixedTranArray[nRecord].nMeterEnd];	break;
			case PSFFixedTransformer_ONR:					strValue=toString(m_PSFFixedTranArray[nRecord].fONR);					break;
			case PSFFixedTransformer_Angle:					strValue=toString(m_PSFFixedTranArray[nRecord].fAngle);					break;
			case PSFFixedTransformer_R:						strValue=toString(m_PSFFixedTranArray[nRecord].fR);						break;
			case PSFFixedTransformer_X:						strValue=toString(m_PSFFixedTranArray[nRecord].fX);						break;
			case PSFFixedTransformer_G:						strValue=toString(m_PSFFixedTranArray[nRecord].fG);						break;
			case PSFFixedTransformer_B:						strValue=toString(m_PSFFixedTranArray[nRecord].fB);						break;
			case PSFFixedTransformer_GF:					strValue=toString(m_PSFFixedTranArray[nRecord].fGF);					break;
			case PSFFixedTransformer_BF:					strValue=toString(m_PSFFixedTranArray[nRecord].fBF);					break;
			case PSFFixedTransformer_GT:					strValue=toString(m_PSFFixedTranArray[nRecord].fGT);					break;
			case PSFFixedTransformer_BT:					strValue=toString(m_PSFFixedTranArray[nRecord].fBT);					break;
			case PSFFixedTransformer_R1:					strValue=toString(m_PSFFixedTranArray[nRecord].fR1);					break;
			case PSFFixedTransformer_R2:					strValue=toString(m_PSFFixedTranArray[nRecord].fR2);					break;
			case PSFFixedTransformer_R3:					strValue=toString(m_PSFFixedTranArray[nRecord].fR3);					break;
			case PSFFixedTransformer_R4:					strValue=toString(m_PSFFixedTranArray[nRecord].fR4);					break;
			case PSFFixedTransformer_R5:					strValue=toString(m_PSFFixedTranArray[nRecord].fR5);					break;
			case PSFFixedTransformer_R6:					strValue=toString(m_PSFFixedTranArray[nRecord].fR6);					break;
			case PSFFixedTransformer_RatingGroup:			strValue=toString(m_PSFFixedTranArray[nRecord].nRatingGroup);			break;
			case PSFFixedTransformer_MVA:					strValue=toString(m_PSFFixedTranArray[nRecord].fMVA);					break;
			case PSFFixedTransformer_Z1:					strValue=toString(m_PSFFixedTranArray[nRecord].fZ1);					break;
			case PSFFixedTransformer_Z2:					strValue=toString(m_PSFFixedTranArray[nRecord].fZ2);					break;
			case PSFFixedTransformer_Z3:					strValue=toString(m_PSFFixedTranArray[nRecord].fZ3);					break;
			case PSFFixedTransformer_Z4:					strValue=toString(m_PSFFixedTranArray[nRecord].fZ4);					break;
			case PSFFixedTransformer_Z5:					strValue=toString(m_PSFFixedTranArray[nRecord].fZ5);					break;
			case PSFFixedTransformer_Z6:					strValue=toString(m_PSFFixedTranArray[nRecord].fZ6);					break;
			case PSFFixedTransformer_EquipmentName:			strValue=m_PSFFixedTranArray[nRecord].szEquipmentName;					break;
			case PSFFixedTransformer_Name:					strValue=m_PSFFixedTranArray[nRecord].szName;							break;
			case PSFFixedTransformer_Owner:					strValue=m_PSFFixedTranArray[nRecord].szOwner;							break;
			case PSFFixedTransformer_RZ:					strValue=toString(m_PSFFixedTranArray[nRecord].fRZ);					break;
			case PSFFixedTransformer_XZ:					strValue=toString(m_PSFFixedTranArray[nRecord].fXZ);					break;
			case PSFFixedTransformer_WindConnectionCode:	strValue=toString(m_PSFFixedTranArray[nRecord].nWindConnectionCode);	break;
			case PSFFixedTransformer_RGF:					strValue=toString(m_PSFFixedTranArray[nRecord].fRGF);					break;
			case PSFFixedTransformer_XGF:					strValue=toString(m_PSFFixedTranArray[nRecord].fXGF);					break;
			case PSFFixedTransformer_RGT:					strValue=toString(m_PSFFixedTranArray[nRecord].fRGT);					break;
			case PSFFixedTransformer_XGT:					strValue=toString(m_PSFFixedTranArray[nRecord].fXGT);					break;
			case PSFFixedTransformerEx_Bus1Name:			strValue=m_PSFFixedTranArray[nRecord].szBus1Name;						break;
			case PSFFixedTransformerEx_Bus2Name:			strValue=m_PSFFixedTranArray[nRecord].szBus2Name;						break;
			case PSFFixedTransformerEx_PSFName:				strValue=m_PSFFixedTranArray[nRecord].szPSFName;						break;
			case PSFFixedTransformerEx_RTName:				strValue=m_PSFFixedTranArray[nRecord].szRTName;							break;
			case PSFFixedTransformerEx_RTP1:				strValue=toString(m_PSFFixedTranArray[nRecord].fRTP1);					break;
			case PSFFixedTransformerEx_RTQ1:				strValue=toString(m_PSFFixedTranArray[nRecord].fRTQ1);					break;
			case PSFFixedTransformerEx_RTP2:				strValue=toString(m_PSFFixedTranArray[nRecord].fRTP2);					break;
			case PSFFixedTransformerEx_RTQ2:				strValue=toString(m_PSFFixedTranArray[nRecord].fRTQ2);					break;
			case PSFFixedTransformerEx_RTRatio:				strValue=toString(m_PSFFixedTranArray[nRecord].fRTTap);					break;
			case PSFFixedTransformerEx_RTStatus:			strValue=toString(m_PSFFixedTranArray[nRecord].nRTStatus);				break;
			}
		}
		break;

	case PSFModel_ULTCTransformer:
		{
			switch (nField)
			{
			case PSFULTCTransformer_Bus1Number:			strValue=toString(m_PSFULTCTranArray[nRecord].nBus1Number);								break;
			case PSFULTCTransformer_Bus2Number:			strValue=toString(m_PSFULTCTranArray[nRecord].nBus2Number);								break;
			case PSFULTCTransformer_ID:					strValue=m_PSFULTCTranArray[nRecord].szID;												break;
			case PSFULTCTransformer_Section:			strValue=toString(m_PSFULTCTranArray[nRecord].nSection);								break;
			case PSFULTCTransformer_Status:				strValue=toString(m_PSFULTCTranArray[nRecord].nStatus);									break;
			case PSFULTCTransformer_MeterEnd:			strValue=g_lpszPSF_MeterEnd[m_PSFULTCTranArray[nRecord].nMeterEnd];						break;
			case PSFULTCTransformer_FromRatio:			strValue=toString(m_PSFULTCTranArray[nRecord].fFromRatio);								break;
			case PSFULTCTransformer_ToRatio:			strValue=toString(m_PSFULTCTranArray[nRecord].fToRatio);								break;
			case PSFULTCTransformer_Angle:				strValue=toString(m_PSFULTCTranArray[nRecord].fAngle);									break;
			case PSFULTCTransformer_R:					strValue=toString(m_PSFULTCTranArray[nRecord].fR);										break;
			case PSFULTCTransformer_X:					strValue=toString(m_PSFULTCTranArray[nRecord].fX);										break;
			case PSFULTCTransformer_G:					strValue=toString(m_PSFULTCTranArray[nRecord].fG);										break;
			case PSFULTCTransformer_B:					strValue=toString(m_PSFULTCTranArray[nRecord].fB);										break;
			case PSFULTCTransformer_GF:					strValue=toString(m_PSFULTCTranArray[nRecord].fGF);										break;
			case PSFULTCTransformer_BF:					strValue=toString(m_PSFULTCTranArray[nRecord].fBF);										break;
			case PSFULTCTransformer_GT:					strValue=toString(m_PSFULTCTranArray[nRecord].fGT);										break;
			case PSFULTCTransformer_BT:					strValue=toString(m_PSFULTCTranArray[nRecord].fBT);										break;
			case PSFULTCTransformer_MaxR:				strValue=toString(m_PSFULTCTranArray[nRecord].fMaxR);									break;
			case PSFULTCTransformer_MinR:				strValue=toString(m_PSFULTCTranArray[nRecord].fMinR);									break;
			case PSFULTCTransformer_Step:				strValue=toString(m_PSFULTCTranArray[nRecord].fStep);									break;
			case PSFULTCTransformer_MaxA:				strValue=toString(m_PSFULTCTranArray[nRecord].fMaxA);									break;
			case PSFULTCTransformer_MinA:				strValue=toString(m_PSFULTCTranArray[nRecord].fMinA);									break;
			case PSFULTCTransformer_AStep:				strValue=toString(m_PSFULTCTranArray[nRecord].fAStep);									break;
			case PSFULTCTransformer_CtrlType:			strValue=g_lpszPSFPSFULTCTransformer_CtrlType[m_PSFULTCTranArray[nRecord].nCtrlType];	break;
			case PSFULTCTransformer_CtrlSide:			strValue=g_lpszPSF_CtrlSide[m_PSFULTCTranArray[nRecord].nCtrlSide];						break;
			case PSFULTCTransformer_CtrlFlag:			strValue=toString(m_PSFULTCTranArray[nRecord].nCtrlFlag);								break;
			case PSFULTCTransformer_MaxMW:				strValue=toString(m_PSFULTCTranArray[nRecord].fMaxMW);									break;
			case PSFULTCTransformer_MinMW:				strValue=toString(m_PSFULTCTranArray[nRecord].fMinMW);									break;
			case PSFULTCTransformer_MaxMVar:			strValue=toString(m_PSFULTCTranArray[nRecord].fMaxMVar);								break;
			case PSFULTCTransformer_MinMVar:			strValue=toString(m_PSFULTCTranArray[nRecord].fMinMVar);								break;
			case PSFULTCTransformer_VHiLimit:			strValue=toString(m_PSFULTCTranArray[nRecord].fVHiLimit);								break;
			case PSFULTCTransformer_VLoLimit:			strValue=toString(m_PSFULTCTranArray[nRecord].fVLoLimit);								break;
			case PSFULTCTransformer_CtrlBus:			strValue=toString(m_PSFULTCTranArray[nRecord].nCtrlBus);								break;
			case PSFULTCTransformer_ZCorrTable:			strValue=toString(m_PSFULTCTranArray[nRecord].nZCorrTable);								break;
			case PSFULTCTransformer_R1:					strValue=toString(m_PSFULTCTranArray[nRecord].fR1);										break;
			case PSFULTCTransformer_R2:					strValue=toString(m_PSFULTCTranArray[nRecord].fR2);										break;
			case PSFULTCTransformer_R3:					strValue=toString(m_PSFULTCTranArray[nRecord].fR3);										break;
			case PSFULTCTransformer_R4:					strValue=toString(m_PSFULTCTranArray[nRecord].fR4);										break;
			case PSFULTCTransformer_R5:					strValue=toString(m_PSFULTCTranArray[nRecord].fR5);										break;
			case PSFULTCTransformer_R6:					strValue=toString(m_PSFULTCTranArray[nRecord].fR6);										break;
			case PSFULTCTransformer_RatingGroup:		strValue=toString(m_PSFULTCTranArray[nRecord].nRatingGroup);							break;
			case PSFULTCTransformer_MVA:				strValue=toString(m_PSFULTCTranArray[nRecord].fMVA);									break;
			case PSFULTCTransformer_Z1:					strValue=toString(m_PSFULTCTranArray[nRecord].fZ1);										break;
			case PSFULTCTransformer_Z2:					strValue=toString(m_PSFULTCTranArray[nRecord].fZ2);										break;
			case PSFULTCTransformer_Z3:					strValue=toString(m_PSFULTCTranArray[nRecord].fZ3);										break;
			case PSFULTCTransformer_Z4:					strValue=toString(m_PSFULTCTranArray[nRecord].fZ4);										break;
			case PSFULTCTransformer_Z5:					strValue=toString(m_PSFULTCTranArray[nRecord].fZ5);										break;
			case PSFULTCTransformer_Z6:					strValue=toString(m_PSFULTCTranArray[nRecord].fZ6);										break;
			case PSFULTCTransformer_EquipmentName:		strValue=m_PSFULTCTranArray[nRecord].szEquipmentName;									break;
			case PSFULTCTransformer_Name:				strValue=m_PSFULTCTranArray[nRecord].szName;											break;
			case PSFULTCTransformer_Owner:				strValue=m_PSFULTCTranArray[nRecord].szOwner;											break;
			case PSFULTCTransformer_RZ:					strValue=toString(m_PSFULTCTranArray[nRecord].fRZ);										break;
			case PSFULTCTransformer_XZ:					strValue=toString(m_PSFULTCTranArray[nRecord].fXZ);										break;
			case PSFULTCTransformer_WindConnectionCode:	strValue=toString(m_PSFULTCTranArray[nRecord].nWindConnectionCode);						break;
			case PSFULTCTransformer_RGF:				strValue=toString(m_PSFULTCTranArray[nRecord].fRGF);									break;
			case PSFULTCTransformer_XGF:				strValue=toString(m_PSFULTCTranArray[nRecord].fXGF);									break;
			case PSFULTCTransformer_RGT:				strValue=toString(m_PSFULTCTranArray[nRecord].fRGT);									break;
			case PSFULTCTransformer_XGT:				strValue=toString(m_PSFULTCTranArray[nRecord].fXGT);									break;
			case PSFULTCTransformerEx_Bus1Name:			strValue=m_PSFULTCTranArray[nRecord].szBus1Name;										break;
			case PSFULTCTransformerEx_Bus2Name:			strValue=m_PSFULTCTranArray[nRecord].szBus2Name;										break;
			case PSFULTCTransformerEx_PSFName:			strValue=m_PSFULTCTranArray[nRecord].szPSFName;											break;
			}
		}
		break;

	case PSFModel_ImpedanceCorrectionTables:
		{
			switch (nField)
			{
			case PSFImpedanceCorrectionTables_TableNumber:	strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].nTableNumber);	break;
			case PSFImpedanceCorrectionTables_T1:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT1);			break;
			case PSFImpedanceCorrectionTables_F1:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF1);			break;
			case PSFImpedanceCorrectionTables_T2:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT2);			break;
			case PSFImpedanceCorrectionTables_F2:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF2);			break;
			case PSFImpedanceCorrectionTables_T3:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT3);			break;
			case PSFImpedanceCorrectionTables_F3:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF3);			break;
			case PSFImpedanceCorrectionTables_T4:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT4);			break;
			case PSFImpedanceCorrectionTables_F4:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF4);			break;
			case PSFImpedanceCorrectionTables_T5:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT5);			break;
			case PSFImpedanceCorrectionTables_F5:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF5);			break;
			case PSFImpedanceCorrectionTables_T6:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT6);			break;
			case PSFImpedanceCorrectionTables_F6:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF6);			break;
			case PSFImpedanceCorrectionTables_T7:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT7);			break;
			case PSFImpedanceCorrectionTables_F7:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF7);			break;
			case PSFImpedanceCorrectionTables_T8:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT8);			break;
			case PSFImpedanceCorrectionTables_F8:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF8);			break;
			case PSFImpedanceCorrectionTables_T9:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT9);			break;
			case PSFImpedanceCorrectionTables_F9:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF9);			break;
			case PSFImpedanceCorrectionTables_T10:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT10);			break;
			case PSFImpedanceCorrectionTables_F10:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF10);			break;
			case PSFImpedanceCorrectionTables_T11:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fT11);			break;
			case PSFImpedanceCorrectionTables_F11:			strValue=toString(m_PSFImpedanceCorrectionTablesArray[nRecord].fF11);			break;
			}
		}
		break;

	case PSFModel_FixedSeriesCompensator:
		{
			switch (nField)
			{
			case PSFFixedSeriesCompensator_Bus1Number:		strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].nBus1Number);			break;
			case PSFFixedSeriesCompensator_Bus2Number:		strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].nBus2Number);			break;
			case PSFFixedSeriesCompensator_ID:				strValue=m_PSFFixedSeriesCompensatorArray[nRecord].szID;							break;
			case PSFFixedSeriesCompensator_Section:			strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].nSection);				break;
			case PSFFixedSeriesCompensator_X:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fX);					break;
			case PSFFixedSeriesCompensator_Status:			strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].nStatus);				break;
			case PSFFixedSeriesCompensator_MeterEnd:		strValue=g_lpszPSF_MeterEnd[m_PSFFixedSeriesCompensatorArray[nRecord].nMeterEnd];	break;
			case PSFFixedSeriesCompensator_AMPRating:		strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fAMPRating);			break;
			case PSFFixedSeriesCompensator_kVRating:		strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fkVRating);			break;
			case PSFFixedSeriesCompensator_Z1:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fZ1);					break;
			case PSFFixedSeriesCompensator_Z2:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fZ2);					break;
			case PSFFixedSeriesCompensator_Z3:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fZ3);					break;
			case PSFFixedSeriesCompensator_Z4:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fZ4);					break;
			case PSFFixedSeriesCompensator_Z5:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fZ5);					break;
			case PSFFixedSeriesCompensator_Z6:				strValue=toString(m_PSFFixedSeriesCompensatorArray[nRecord].fZ6);					break;
			case PSFFixedSeriesCompensator_EquipmentName:	strValue=m_PSFFixedSeriesCompensatorArray[nRecord].szEquipmentName;				break;
			case PSFFixedSeriesCompensator_Owner:			strValue=m_PSFFixedSeriesCompensatorArray[nRecord].szOwner;						break;
			case PSFFixedSeriesCompensatorEx_Bus1Name:		strValue=m_PSFFixedSeriesCompensatorArray[nRecord].szBus1Name;						break;
			case PSFFixedSeriesCompensatorEx_Bus2Name:		strValue=m_PSFFixedSeriesCompensatorArray[nRecord].szBus2Name;						break;
			case PSFFixedSeriesCompensatorEx_PSFName:		strValue=m_PSFFixedSeriesCompensatorArray[nRecord].szPSFName;						break;
			}
		}
		break;

	case PSFModel_SwitchableSeriesCompensator:
		{
			switch (nField)
			{
			case PSFSwitchableSeriesCompensator_Bus1Number:		strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].nBus1Number);			break;
			case PSFSwitchableSeriesCompensator_Bus2Number:		strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].nBus2Number);			break;
			case PSFSwitchableSeriesCompensator_ID:				strValue=m_PSFSwitchableSeriesCompensatorArray[nRecord].szID;							break;
			case PSFSwitchableSeriesCompensator_Section:		strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].nSection);			break;
			case PSFSwitchableSeriesCompensator_Status:			strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].nStatus);				break;
			case PSFSwitchableSeriesCompensator_MeterEnd:		strValue=g_lpszPSF_MeterEnd[m_PSFSwitchableSeriesCompensatorArray[nRecord].nMeterEnd];	break;
			case PSFSwitchableSeriesCompensator_X:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fX);					break;
			case PSFSwitchableSeriesCompensator_XMax:			strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fXMax);				break;
			case PSFSwitchableSeriesCompensator_XMin:			strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fXMin);				break;
			case PSFSwitchableSeriesCompensator_Steps:			strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fSteps);				break;
			case PSFSwitchableSeriesCompensator_CtrlFlag:		strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].nCtrlFlag);			break;
			case PSFSwitchableSeriesCompensator_MaxMW:			strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fMaxMW);				break;
			case PSFSwitchableSeriesCompensator_MinMW:			strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fMinMW);				break;
			case PSFSwitchableSeriesCompensator_AMPRating:		strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fAMPRating);			break;
			case PSFSwitchableSeriesCompensator_kVRating:		strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fkVRating);			break;
			case PSFSwitchableSeriesCompensator_Z1:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ1);					break;
			case PSFSwitchableSeriesCompensator_Z2:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ2);					break;
			case PSFSwitchableSeriesCompensator_Z3:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ3);					break;
			case PSFSwitchableSeriesCompensator_Z4:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ4);					break;
			case PSFSwitchableSeriesCompensator_Z5:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ5);					break;
			case PSFSwitchableSeriesCompensator_Z6:				strValue=toString(m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ6);					break;
			case PSFSwitchableSeriesCompensator_EquipmentName:	strValue=m_PSFSwitchableSeriesCompensatorArray[nRecord].szEquipmentName;				break;
			case PSFSwitchableSeriesCompensator_Owner:			strValue=m_PSFSwitchableSeriesCompensatorArray[nRecord].szOwner;						break;
			case PSFSwitchableSeriesCompensatorEx_Bus1Name:		strValue=m_PSFSwitchableSeriesCompensatorArray[nRecord].szBus1Name;					break;
			case PSFSwitchableSeriesCompensatorEx_Bus2Name:		strValue=m_PSFSwitchableSeriesCompensatorArray[nRecord].szBus2Name;					break;
			case PSFSwitchableSeriesCompensatorEx_PSFName:		strValue=m_PSFSwitchableSeriesCompensatorArray[nRecord].szPSFName;						break;
			}
		}
		break;

	case PSFModel_StaticTapChangerPhaseRegulator:
		{
			switch (nField)
			{
			case PSFStaticTapChangerPhaseRegulator_Bus1Number:			strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nBus1Number);			break;
			case PSFStaticTapChangerPhaseRegulator_Bus2Number:			strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nBus2Number);			break;
			case PSFStaticTapChangerPhaseRegulator_ID:					strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szID;							break;
			case PSFStaticTapChangerPhaseRegulator_Section:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nSection);				break;
			case PSFStaticTapChangerPhaseRegulator_Status:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nStatus);				break;
			case PSFStaticTapChangerPhaseRegulator_MeterEnd:			strValue=g_lpszPSF_MeterEnd[m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nMeterEnd];	break;
			case PSFStaticTapChangerPhaseRegulator_R:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR);					break;
			case PSFStaticTapChangerPhaseRegulator_X:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fX);					break;
			case PSFStaticTapChangerPhaseRegulator_G:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fG);					break;
			case PSFStaticTapChangerPhaseRegulator_B:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fB);					break;
			case PSFStaticTapChangerPhaseRegulator_GF:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fGF);					break;
			case PSFStaticTapChangerPhaseRegulator_BF:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fBF);					break;
			case PSFStaticTapChangerPhaseRegulator_GT:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fGT);					break;
			case PSFStaticTapChangerPhaseRegulator_BT:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fBT);					break;
			case PSFStaticTapChangerPhaseRegulator_TCRG:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fTCRG);				break;
			case PSFStaticTapChangerPhaseRegulator_PSRG:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fPSRG);				break;
			case PSFStaticTapChangerPhaseRegulator_TCpsn:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fTCpsn);				break;
			case PSFStaticTapChangerPhaseRegulator_PSpsn:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fPSpsn);				break;
			case PSFStaticTapChangerPhaseRegulator_TCR:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fTCR);					break;
			case PSFStaticTapChangerPhaseRegulator_MaxTCR:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxTCR);				break;
			case PSFStaticTapChangerPhaseRegulator_MinTCR:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinTCR);				break;
			case PSFStaticTapChangerPhaseRegulator_PSR:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fPSR);					break;
			case PSFStaticTapChangerPhaseRegulator_MaxPSR:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxPSR);				break;
			case PSFStaticTapChangerPhaseRegulator_MinPSR:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinPSR);				break;
			case PSFStaticTapChangerPhaseRegulator_CtrlType:			strValue=g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType[m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlType];break;
			case PSFStaticTapChangerPhaseRegulator_CtrlSide:			strValue=g_lpszPSF_CtrlSide[m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlSide];	break;
			case PSFStaticTapChangerPhaseRegulator_CtrlFlag:			strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlFlag);			break;
			case PSFStaticTapChangerPhaseRegulator_MaxP:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxP);				break;
			case PSFStaticTapChangerPhaseRegulator_MinP:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinP);				break;
			case PSFStaticTapChangerPhaseRegulator_MaxQ:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxQ);				break;
			case PSFStaticTapChangerPhaseRegulator_MinQ:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinQ);				break;
			case PSFStaticTapChangerPhaseRegulator_VHiLimit:			strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fVHiLimit);			break;
			case PSFStaticTapChangerPhaseRegulator_VLoLimit:			strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fVLoLimit);			break;
			case PSFStaticTapChangerPhaseRegulator_CtrlBus:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlBus);				break;
			case PSFStaticTapChangerPhaseRegulator_ZCorrTC:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nZCorrTC);				break;
			case PSFStaticTapChangerPhaseRegulator_ZCorrPS:				strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nZCorrPS);				break;
			case PSFStaticTapChangerPhaseRegulator_MVA:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMVA);					break;
			case PSFStaticTapChangerPhaseRegulator_R1:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR1);					break;
			case PSFStaticTapChangerPhaseRegulator_R2:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR2);					break;
			case PSFStaticTapChangerPhaseRegulator_R3:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR3);					break;
			case PSFStaticTapChangerPhaseRegulator_R4:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR4);					break;
			case PSFStaticTapChangerPhaseRegulator_R5:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR5);					break;
			case PSFStaticTapChangerPhaseRegulator_R6:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR6);					break;
			case PSFStaticTapChangerPhaseRegulator_RatingGroup:			strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nRatingGroup);			break;
			case PSFStaticTapChangerPhaseRegulator_Z1:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ1);					break;
			case PSFStaticTapChangerPhaseRegulator_Z2:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ2);					break;
			case PSFStaticTapChangerPhaseRegulator_Z3:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ3);					break;
			case PSFStaticTapChangerPhaseRegulator_Z4:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ4);					break;
			case PSFStaticTapChangerPhaseRegulator_Z5:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ5);					break;
			case PSFStaticTapChangerPhaseRegulator_Z6:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ6);					break;
			case PSFStaticTapChangerPhaseRegulator_EquipmentName:		strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szEquipmentName;				break;
			case PSFStaticTapChangerPhaseRegulator_Name:				strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szName;							break;
			case PSFStaticTapChangerPhaseRegulator_Owner:				strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szOwner;						break;
			case PSFStaticTapChangerPhaseRegulator_RZ:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fRZ);					break;
			case PSFStaticTapChangerPhaseRegulator_XZ:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fXZ);					break;
			case PSFStaticTapChangerPhaseRegulator_WindConnectionCode:	strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nWindConnectionCode);	break;
			case PSFStaticTapChangerPhaseRegulator_RGF:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fRGF);					break;
			case PSFStaticTapChangerPhaseRegulator_XGF:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fXGF);					break;
			case PSFStaticTapChangerPhaseRegulator_RGT:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fRGT);					break;
			case PSFStaticTapChangerPhaseRegulator_XGT:					strValue=toString(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fXGT);					break;
			case PSFStaticTapChangerPhaseRegulatorEx_Bus1Name:			strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szBus1Name;						break;
			case PSFStaticTapChangerPhaseRegulatorEx_Bus2Name:			strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szBus2Name;						break;
			case PSFStaticTapChangerPhaseRegulatorEx_PSFName:			strValue=m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szPSFName;						break;
			}
		}
		break;

	case PSFModel_PSF3WindingTransformer:
		{
			switch (nField)
			{
			case PSF3WindingTransformer_Bus1Number:		strValue=toString(m_PSF3WindingTranArray[nRecord].nBus1Number);				break;
			case PSF3WindingTransformer_Bus2Number:		strValue=toString(m_PSF3WindingTranArray[nRecord].nBus2Number);				break;
			case PSF3WindingTransformer_Bus3Number:		strValue=toString(m_PSF3WindingTranArray[nRecord].nBus3Number);				break;
			case PSF3WindingTransformer_ID:				strValue=m_PSF3WindingTranArray[nRecord].szID;								break;
			case PSF3WindingTransformer_Status:			strValue=toString(m_PSF3WindingTranArray[nRecord].nStatus);					break;
			case PSF3WindingTransformer_NonMeteredEnd:	strValue=g_lpszPSF3WindingTransformer_NonMeteredEnd[m_PSF3WindingTranArray[nRecord].nNonMeteredEnd];	break;
			case PSF3WindingTransformer_Ratio1:			strValue=toString(m_PSF3WindingTranArray[nRecord].fRatio1);					break;
			case PSF3WindingTransformer_Angle1:			strValue=toString(m_PSF3WindingTranArray[nRecord].fAngle1);					break;
			case PSF3WindingTransformer_Ratio2:			strValue=toString(m_PSF3WindingTranArray[nRecord].fRatio2);					break;
			case PSF3WindingTransformer_Angle2:			strValue=toString(m_PSF3WindingTranArray[nRecord].fAngle2);					break;
			case PSF3WindingTransformer_Ratio3:			strValue=toString(m_PSF3WindingTranArray[nRecord].fRatio3);					break;
			case PSF3WindingTransformer_Angle3:			strValue=toString(m_PSF3WindingTranArray[nRecord].fAngle3);					break;
			case PSF3WindingTransformer_R1:				strValue=toString(m_PSF3WindingTranArray[nRecord].fR1);						break;
			case PSF3WindingTransformer_X1:				strValue=toString(m_PSF3WindingTranArray[nRecord].fX1);						break;
			case PSF3WindingTransformer_R2:				strValue=toString(m_PSF3WindingTranArray[nRecord].fR2);						break;
			case PSF3WindingTransformer_X2:				strValue=toString(m_PSF3WindingTranArray[nRecord].fX2);						break;
			case PSF3WindingTransformer_R3:				strValue=toString(m_PSF3WindingTranArray[nRecord].fR3);						break;
			case PSF3WindingTransformer_X3:				strValue=toString(m_PSF3WindingTranArray[nRecord].fX3);						break;
			case PSF3WindingTransformer_G1:				strValue=toString(m_PSF3WindingTranArray[nRecord].fG1);						break;
			case PSF3WindingTransformer_B1:				strValue=toString(m_PSF3WindingTranArray[nRecord].fB1);						break;
			case PSF3WindingTransformer_G2:				strValue=toString(m_PSF3WindingTranArray[nRecord].fG2);						break;
			case PSF3WindingTransformer_B2:				strValue=toString(m_PSF3WindingTranArray[nRecord].fB2);						break;
			case PSF3WindingTransformer_G3:				strValue=toString(m_PSF3WindingTranArray[nRecord].fG3);						break;
			case PSF3WindingTransformer_B3:				strValue=toString(m_PSF3WindingTranArray[nRecord].fB3);						break;
			case PSF3WindingTransformer_PMaxRA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPMaxRA);					break;
			case PSF3WindingTransformer_PMinRA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPMinRA);					break;
			case PSF3WindingTransformer_PStep:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPStep);					break;
			case PSF3WindingTransformer_PCtrlSide:		strValue=g_lpszPSF3WindingTransformer_CtrlSide[m_PSF3WindingTranArray[nRecord].nPCtrlSide];	break;
			case PSF3WindingTransformer_PCtrlFlag:		strValue=toString(m_PSF3WindingTranArray[nRecord].nPCtrlFlag);				break;
			case PSF3WindingTransformer_PMaxCtrl:		strValue=toString(m_PSF3WindingTranArray[nRecord].fPMaxCtrl);				break;
			case PSF3WindingTransformer_PMinCtrl:		strValue=toString(m_PSF3WindingTranArray[nRecord].fPMinCtrl);				break;
			case PSF3WindingTransformer_PCtrlBus:		strValue=toString(m_PSF3WindingTranArray[nRecord].nPCtrlBus);				break;
			case PSF3WindingTransformer_PZCorrTable:	strValue=toString(m_PSF3WindingTranArray[nRecord].nPZCorrTable);			break;
			case PSF3WindingTransformer_SMaxRA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSMaxRA);					break;
			case PSF3WindingTransformer_SMinRA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSMinRA);					break;
			case PSF3WindingTransformer_SStep:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSStep);					break;
			case PSF3WindingTransformer_SCtrlSide:		strValue=g_lpszPSF3WindingTransformer_CtrlSide[m_PSF3WindingTranArray[nRecord].nSCtrlSide];	break;
			case PSF3WindingTransformer_SCtrlFlag:		strValue=toString(m_PSF3WindingTranArray[nRecord].nSCtrlFlag);				break;
			case PSF3WindingTransformer_SMaxCtrl:		strValue=toString(m_PSF3WindingTranArray[nRecord].fSMaxCtrl);				break;
			case PSF3WindingTransformer_SMinCtrl:		strValue=toString(m_PSF3WindingTranArray[nRecord].fSMinCtrl);				break;
			case PSF3WindingTransformer_SCtrlBus:		strValue=toString(m_PSF3WindingTranArray[nRecord].nSCtrlBus);				break;
			case PSF3WindingTransformer_SZCorrTable:	strValue=toString(m_PSF3WindingTranArray[nRecord].nSZCorrTable);			break;
			case PSF3WindingTransformer_TMaxRA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTMaxRA);					break;
			case PSF3WindingTransformer_TMinRA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTMinRA);					break;
			case PSF3WindingTransformer_TStep:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTStep);					break;
			case PSF3WindingTransformer_TCtrlSide:		strValue=g_lpszPSF3WindingTransformer_CtrlSide[m_PSF3WindingTranArray[nRecord].nTCtrlSide];	break;
			case PSF3WindingTransformer_TCtrlFlag:		strValue=toString(m_PSF3WindingTranArray[nRecord].nTCtrlFlag);				break;
			case PSF3WindingTransformer_TMaxCtrl:		strValue=toString(m_PSF3WindingTranArray[nRecord].fTMaxCtrl);				break;
			case PSF3WindingTransformer_TMinCtrl:		strValue=toString(m_PSF3WindingTranArray[nRecord].fTMinCtrl);				break;
			case PSF3WindingTransformer_TCtrlBus:		strValue=toString(m_PSF3WindingTranArray[nRecord].nTCtrlBus);				break;
			case PSF3WindingTransformer_TZCorrTable:	strValue=toString(m_PSF3WindingTranArray[nRecord].nTZCorrTable);			break;
			case PSF3WindingTransformer_PR1:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR1);					break;
			case PSF3WindingTransformer_PR2:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR2);					break;
			case PSF3WindingTransformer_PR3:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR3);					break;
			case PSF3WindingTransformer_PR4:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR4);					break;
			case PSF3WindingTransformer_PR5:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR5);					break;
			case PSF3WindingTransformer_PR6:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR6);					break;
			case PSF3WindingTransformer_RatingGroup:	strValue=toString(m_PSF3WindingTranArray[nRecord].nRatingGroup);			break;
			case PSF3WindingTransformer_MVA:			strValue=toString(m_PSF3WindingTranArray[nRecord].fMVA);					break;
			case PSF3WindingTransformer_SR1:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR1);					break;
			case PSF3WindingTransformer_SR2:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR2);					break;
			case PSF3WindingTransformer_SR3:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR3);					break;
			case PSF3WindingTransformer_SR4:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR4);					break;
			case PSF3WindingTransformer_SR5:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR5);					break;
			case PSF3WindingTransformer_SR6:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR6);					break;
			case PSF3WindingTransformer_TR1:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR1);					break;
			case PSF3WindingTransformer_TR2:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR2);					break;
			case PSF3WindingTransformer_TR3:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR3);					break;
			case PSF3WindingTransformer_TR4:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR4);					break;
			case PSF3WindingTransformer_TR5:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR5);					break;
			case PSF3WindingTransformer_TR6:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR6);					break;
			case PSF3WindingTransformer_EquipmentName:	strValue=m_PSF3WindingTranArray[nRecord].szEquipmentName;					break;
			case PSF3WindingTransformer_Name:			strValue=m_PSF3WindingTranArray[nRecord].szName;							break;
			case PSF3WindingTransformer_Owner:			strValue=m_PSF3WindingTranArray[nRecord].szOwner;							break;
			case PSF3WindingTransformer_PR0:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPR0);					break;
			case PSF3WindingTransformer_PX0:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPX0);					break;
			case PSF3WindingTransformer_SR0:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSR0);					break;
			case PSF3WindingTransformer_SX0:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSX0);					break;
			case PSF3WindingTransformer_TR0:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTR0);					break;
			case PSF3WindingTransformer_TX0:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTX0);					break;
			case PSF3WindingTransformer_GroundingCode:	strValue=toString(m_PSF3WindingTranArray[nRecord].nGroundingCode);			break;
			case PSF3WindingTransformer_PGR:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPGR);					break;
			case PSF3WindingTransformer_PGX:			strValue=toString(m_PSF3WindingTranArray[nRecord].fPGX);					break;
			case PSF3WindingTransformer_SGR:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSGR);					break;
			case PSF3WindingTransformer_SGX:			strValue=toString(m_PSF3WindingTranArray[nRecord].fSGX);					break;
			case PSF3WindingTransformer_TGR:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTGR);					break;
			case PSF3WindingTransformer_TGX:			strValue=toString(m_PSF3WindingTranArray[nRecord].fTGX);					break;
			case PSF3WindingTransformerEx_Bus1Name:		strValue=m_PSF3WindingTranArray[nRecord].szBus1Name;						break;
			case PSF3WindingTransformerEx_Bus2Name:		strValue=m_PSF3WindingTranArray[nRecord].szBus2Name;						break;
			case PSF3WindingTransformerEx_Bus3Name:		strValue=m_PSF3WindingTranArray[nRecord].szBus3Name;						break;
			case PSF3WindingTransformerEx_PSFName:		strValue=m_PSF3WindingTranArray[nRecord].szPSFName;							break;
			}
		}
		break;

	case PSFModel_AreaInterchange:
		{
			switch (nField)
			{
			case PSFAreaInterchange_Number:			strValue=toString(m_PSFAreaInterchangeArray[nRecord].nNumber);			break;
			case PSFAreaInterchange_Name:			strValue=m_PSFAreaInterchangeArray[nRecord].szName;					break;
			case PSFAreaInterchange_DesiredFlow:	strValue=toString(m_PSFAreaInterchangeArray[nRecord].fDesiredFlow);	break;
			case PSFAreaInterchange_Tolerance:		strValue=toString(m_PSFAreaInterchangeArray[nRecord].fTolerance);		break;
			case PSFAreaInterchange_SlackBus:		strValue=toString(m_PSFAreaInterchangeArray[nRecord].nSlackBus);		break;
			case PSFAreaInterchange_Description:	strValue=m_PSFAreaInterchangeArray[nRecord].szDescription;			break;
			case PSFAreaInterchange_Mode:			strValue=toString(m_PSFAreaInterchangeArray[nRecord].nMode);			break;
			case PSFAreaInterchange_Flag:			strValue=toString(m_PSFAreaInterchangeArray[nRecord].nFlag);			break;

			}
		}
		break;

	case PSFModel_Interface:
		break;

	case PSFModel_LineCommutatedConverters:
		{
			switch (nField)
			{
			case PSFLineCommutatedConverters_DCBus1:	strValue=m_PSFLCConvertersArray[nRecord].szDCBus1;				break;
			case PSFLineCommutatedConverters_DCBus2:	strValue=m_PSFLCConvertersArray[nRecord].szDCBus2;				break;
			case PSFLineCommutatedConverters_ACBus:		strValue=toString(m_PSFLCConvertersArray[nRecord].nACBus);		break;
			case PSFLineCommutatedConverters_ID:		strValue=toString(m_PSFLCConvertersArray[nRecord].nID);		break;
			case PSFLineCommutatedConverters_Change:	strValue=g_lpszPSFMultiTerminalDC_Change[m_PSFLCConvertersArray[nRecord].nChange];	break;
			case PSFLineCommutatedConverters_Grp:		strValue=m_PSFLCConvertersArray[nRecord].szGrp;				break;
			case PSFLineCommutatedConverters_Zone:		strValue=toString(m_PSFLCConvertersArray[nRecord].nZone);		break;
			case PSFLineCommutatedConverters_Bridge:	strValue=toString(m_PSFLCConvertersArray[nRecord].nBridge);	break;
			case PSFLineCommutatedConverters_Xc:		strValue=toString(m_PSFLCConvertersArray[nRecord].fXc);		break;
			case PSFLineCommutatedConverters_VR:		strValue=toString(m_PSFLCConvertersArray[nRecord].fVR);		break;
			case PSFLineCommutatedConverters_Tstep:		strValue=toString(m_PSFLCConvertersArray[nRecord].fTstep);		break;
			case PSFLineCommutatedConverters_Tmin:		strValue=toString(m_PSFLCConvertersArray[nRecord].fTmin);		break;
			case PSFLineCommutatedConverters_Tmax:		strValue=toString(m_PSFLCConvertersArray[nRecord].fTmax);		break;
			case PSFLineCommutatedConverters_Amin:		strValue=toString(m_PSFLCConvertersArray[nRecord].fAmin);		break;
			case PSFLineCommutatedConverters_Amax:		strValue=toString(m_PSFLCConvertersArray[nRecord].fAmax);		break;
			case PSFLineCommutatedConverters_Gmin:		strValue=toString(m_PSFLCConvertersArray[nRecord].fGmin);		break;
			case PSFLineCommutatedConverters_Imax:		strValue=toString(m_PSFLCConvertersArray[nRecord].fImax);		break;
			case PSFLineCommutatedConverters_CtrlMode:	strValue=m_PSFLCConvertersArray[nRecord].szCtrlMode;			break;
			case PSFLineCommutatedConverters_SP1:		strValue=toString(m_PSFLCConvertersArray[nRecord].fSP1);		break;
			case PSFLineCommutatedConverters_SP2:		strValue=toString(m_PSFLCConvertersArray[nRecord].fSP2);		break;
			case PSFLineCommutatedConverters_Type:		strValue=g_lpszPSFMultiTerminalDC_Type[m_PSFLCConvertersArray[nRecord].nType];		break;
			case PSFLineCommutatedConverters_MVA:		strValue=toString(m_PSFLCConvertersArray[nRecord].fMVA);		break;
			case PSFLineCommutatedConverters_Pmin:		strValue=toString(m_PSFLCConvertersArray[nRecord].fPmin);		break;
			case PSFLineCommutatedConverters_Pmax:		strValue=toString(m_PSFLCConvertersArray[nRecord].fPmax);		break;
			case PSFLineCommutatedConverters_Qmin:		strValue=toString(m_PSFLCConvertersArray[nRecord].fQmin);		break;
			case PSFLineCommutatedConverters_Qmax:		strValue=toString(m_PSFLCConvertersArray[nRecord].fQmax);		break;
			case PSFLineCommutatedConverters_BiasR:		strValue=toString(m_PSFLCConvertersArray[nRecord].fBiasR);		break;
			case PSFLineCommutatedConverters_kV:		strValue=toString(m_PSFLCConvertersArray[nRecord].fkV);		break;
			case PSFLineCommutatedConvertersEx_ACBusName:	strValue=m_PSFLCConvertersArray[nRecord].szACBusName;		break;
			}
		}
		break;

	case PSFModel_DCLines:
		{
			switch (nField)
			{
			case PSFDCLines_DCBus1:	strValue=m_PSFDCLinesArray[nRecord].szDCBus1;			break;
			case PSFDCLines_DCBus2:	strValue=m_PSFDCLinesArray[nRecord].szDCBus2;			break;
			case PSFDCLines_ID:		strValue=m_PSFDCLinesArray[nRecord].szID;				break;
			case PSFDCLines_Change:	strValue=g_lpszPSFMultiTerminalDC_Change[m_PSFDCLinesArray[nRecord].nChange];	break;
			case PSFDCLines_Grp:	strValue=m_PSFDCLinesArray[nRecord].szGrp;				break;
			case PSFDCLines_Zone:	strValue=toString(m_PSFDCLinesArray[nRecord].nZone);								break;
			case PSFDCLines_Owner:	strValue=m_PSFDCLinesArray[nRecord].szOwner;			break;
			case PSFDCLines_Rdc:	strValue=toString(m_PSFDCLinesArray[nRecord].fRdc);	break;
			case PSFDCLines_Ldc:	strValue=toString(m_PSFDCLinesArray[nRecord].fLdc);	break;
			case PSFDCLines_Cdca:	strValue=toString(m_PSFDCLinesArray[nRecord].fCdca);	break;
			case PSFDCLines_Cdcb:	strValue=toString(m_PSFDCLinesArray[nRecord].fCdcb);	break;
			case PSFDCLines_Imax:	strValue=toString(m_PSFDCLinesArray[nRecord].fImax);	break;
			case PSFDCLines_Mend:	strValue=g_lpszPSFMultiTerminalDC_Mend[m_PSFDCLinesArray[nRecord].nMend];		break;
			}
		}
		break;

	case PSFModel_DCBreakers:
		{
			switch (nField)
			{
			case PSFDCBreakers_DCBus1:	strValue=m_PSFDCBreakersArray[nRecord].szDCBus1;	break;
			case PSFDCBreakers_DCBus2:	strValue=m_PSFDCBreakersArray[nRecord].szDCBus2;	break;
			case PSFDCBreakers_ID:		strValue=m_PSFDCBreakersArray[nRecord].szID;		break;
			case PSFDCBreakers_Change:	strValue=g_lpszPSFMultiTerminalDC_Change[m_PSFDCBreakersArray[nRecord].nChange];	break;
			case PSFDCBreakers_Grp:		strValue=m_PSFDCBreakersArray[nRecord].szGrp;				break;
			case PSFDCBreakers_Zone:	strValue=toString(m_PSFDCBreakersArray[nRecord].nZone);	break;
			case PSFDCBreakers_Owner:	strValue=m_PSFDCBreakersArray[nRecord].szOwner;			break;
			case PSFDCBreakers_Status:	strValue=g_lpszPSFMultiTerminalDC_Status[m_PSFDCBreakersArray[nRecord].nStatus];	break;
			}
		}
		break;

	case PSFModel_DCBuses:
		{
			switch (nField)
			{
			case PSFDCBuses_DCBus:	strValue=m_PSFDCBusesArray[nRecord].szDCBus;			break;
			case PSFDCBuses_Change:	strValue=toString(m_PSFDCBusesArray[nRecord].nArea);	break;
			case PSFDCBuses_Area:	strValue=toString(m_PSFDCBusesArray[nRecord].nZone);	break;
			case PSFDCBuses_Zone:	strValue=g_lpszPSFMultiTerminalDC_Change[m_PSFDCBusesArray[nRecord].nChange];	break;
			}
		}
		break;

	case PSFModel_VoltageSourcedConverter:
		{
			switch (nField)
			{
			case PSFVoltageSourcedConverter_DCBus1:	strValue=m_PSFVSCArray[nRecord].szDCBus1;				break;
			case PSFVoltageSourcedConverter_DCBus2:	strValue=m_PSFVSCArray[nRecord].szDCBus2;				break;
			case PSFVoltageSourcedConverter_ACBus1:	strValue=toString(m_PSFVSCArray[nRecord].nACBus1);		break;
			case PSFVoltageSourcedConverter_ID:		strValue=m_PSFVSCArray[nRecord].szID;					break;
			case PSFVoltageSourcedConverter_DCBus3:	strValue=m_PSFVSCArray[nRecord].szDCBus3;				break;
			case PSFVoltageSourcedConverter_DCBus4:	strValue=m_PSFVSCArray[nRecord].szDCBus4;				break;
			case PSFVoltageSourcedConverter_ACBus2:	strValue=toString(m_PSFVSCArray[nRecord].nACBus2);		break;
			case PSFVoltageSourcedConverter_ID2:	strValue=m_PSFVSCArray[nRecord].szID2;					break;
			case PSFVoltageSourcedConverter_Change:	strValue=g_lpszPSFMultiTerminalDC_Change[m_PSFVSCArray[nRecord].nChange];	break;
			case PSFVoltageSourcedConverter_Grp:	strValue=m_PSFVSCArray[nRecord].szGrp;					break;
			case PSFVoltageSourcedConverter_Zone:	strValue=toString(m_PSFVSCArray[nRecord].nZone);		break;
			case PSFVoltageSourcedConverter_Bridge:	strValue=toString(m_PSFVSCArray[nRecord].nBridge);		break;
			case PSFVoltageSourcedConverter_Xt:		strValue=toString(m_PSFVSCArray[nRecord].fXt);			break;
			case PSFVoltageSourcedConverter_VR:		strValue=toString(m_PSFVSCArray[nRecord].fVR);			break;
			case PSFVoltageSourcedConverter_Step:	strValue=toString(m_PSFVSCArray[nRecord].fStep);		break;
			case PSFVoltageSourcedConverter_Tmin:	strValue=toString(m_PSFVSCArray[nRecord].fTmin);		break;
			case PSFVoltageSourcedConverter_Tmax:	strValue=toString(m_PSFVSCArray[nRecord].fTmax);		break;
			case PSFVoltageSourcedConverter_Amin:	strValue=toString(m_PSFVSCArray[nRecord].fAmin);		break;
			case PSFVoltageSourcedConverter_Amax:	strValue=toString(m_PSFVSCArray[nRecord].fAmax);		break;
			case PSFVoltageSourcedConverter_Gmin:	strValue=toString(m_PSFVSCArray[nRecord].fGmin);		break;
			case PSFVoltageSourcedConverter_Gmax:	strValue=toString(m_PSFVSCArray[nRecord].fGmax);		break;
			case PSFVoltageSourcedConverter_Imax:	strValue=toString(m_PSFVSCArray[nRecord].fImax);		break;
			case PSFVoltageSourcedConverter_Mode:	strValue=m_PSFVSCArray[nRecord].szMode;				break;
			case PSFVoltageSourcedConverter_SP1:	strValue=toString(m_PSFVSCArray[nRecord].fSP1);		break;
			case PSFVoltageSourcedConverter_SP2:	strValue=toString(m_PSFVSCArray[nRecord].fSP2);		break;
			case PSFVoltageSourcedConverter_SP3:	strValue=toString(m_PSFVSCArray[nRecord].fSP3);		break;
			case PSFVoltageSourcedConverter_X1:		strValue=toString(m_PSFVSCArray[nRecord].fX1);			break;
			case PSFVoltageSourcedConverter_Kc:		strValue=toString(m_PSFVSCArray[nRecord].fKc);			break;
			case PSFVoltageSourcedConverter_Type:	strValue=toString(m_PSFVSCArray[nRecord].nType);		break;
			case PSFVoltageSourcedConverter_MVA:	strValue=toString(m_PSFVSCArray[nRecord].fMVA);		break;
			case PSFVoltageSourcedConverter_kV:		strValue=toString(m_PSFVSCArray[nRecord].fkV);			break;
			case PSFVoltageSourcedConverter_Vmin:	strValue=toString(m_PSFVSCArray[nRecord].fVmin);		break;
			case PSFVoltageSourcedConverter_Vmax:	strValue=toString(m_PSFVSCArray[nRecord].fVmax);		break;
			case PSFVoltageSourcedConverter_Vref:	strValue=toString(m_PSFVSCArray[nRecord].fVref);		break;
			case PSFVoltageSourcedConverter_QA0:	strValue=toString(m_PSFVSCArray[nRecord].fQA0);		break;
			case PSFVoltageSourcedConverter_La:		strValue=toString(m_PSFVSCArray[nRecord].fLa);			break;
			case PSFVoltageSourcedConverter_Lb:		strValue=toString(m_PSFVSCArray[nRecord].fLb);			break;
			case PSFVoltageSourcedConverter_Lmin:	strValue=toString(m_PSFVSCArray[nRecord].fLmin);		break;
			case PSFVoltageSourcedConverter_PA0:	strValue=toString(m_PSFVSCArray[nRecord].fPA0);		break;
			case PSFVoltageSourcedConverter_VD0:	strValue=toString(m_PSFVSCArray[nRecord].fVD0);		break;
			case PSFVoltageSourcedConverter_ID0:	strValue=toString(m_PSFVSCArray[nRecord].fID0);		break;
			case PSFVoltageSourcedConverterEx_ACBus1Name:	strValue=m_PSFVSCArray[nRecord].szACBus1Name;		break;
			case PSFVoltageSourcedConverterEx_ACBus2Name:	strValue=m_PSFVSCArray[nRecord].szACBus2Name;		break;
			}
		}
		break;

	case PSFModel_Zone:
		{
			switch (nField)
			{
			case PSFZone_Number:	strValue=toString(m_PSFZoneArray[nRecord].nNumber);	break;
			case PSFZone_Name:		strValue=m_PSFZoneArray[nRecord].szName;				break;
			}
		}
		break;

	case PSFModel_NodeMapping:
		{
			switch (nField)
			{
			case PSFNodeMapping_BusNumber:	strValue=toString(m_PSFNodeMappingArray[nRecord].nBusNumber);	break;
			case PSFNodeMapping_BusName:	strValue=m_PSFNodeMappingArray[nRecord].szBusName;				break;
			case PSFNodeMapping_NodeName:	strValue=m_PSFNodeMappingArray[nRecord].szNodeName;			break;

			}
		}
		break;

	case PSFModel_ZeroSequenceMutualCoupling:
		{
			switch (nField)
			{
			case PSFZeroSequenceMutualCoupling_Bus1L1Number:	strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus1L1Number);	break;
			case PSFZeroSequenceMutualCoupling_Bus2L1Number:	strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus2L1Number);	break;
			case PSFZeroSequenceMutualCoupling_IDL1:			strValue=m_PSFZeroSequenceMutualCouplingArray[nRecord].szIDL1;						break;
			case PSFZeroSequenceMutualCoupling_Bus1L2Number:	strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus1L2Number);	break;
			case PSFZeroSequenceMutualCoupling_Bus2L2Number:	strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus2L2Number);	break;
			case PSFZeroSequenceMutualCoupling_IDL2:			strValue=m_PSFZeroSequenceMutualCouplingArray[nRecord].szIDL2;						break;
			case PSFZeroSequenceMutualCoupling_R:				strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].fR);	break;
			case PSFZeroSequenceMutualCoupling_X:				strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].fX);	break;
			case PSFZeroSequenceMutualCoupling_CF1:				strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].fCF1);	break;
			case PSFZeroSequenceMutualCoupling_CF2:				strValue=toString(m_PSFZeroSequenceMutualCouplingArray[nRecord].fCF2);	break;
			}
		}
		break;

	case PSFModel_FileSection:
		{
			switch (nField)
			{
			case PSFFileSection_FileIdentifier:	strValue=m_PSFFileSectionArray[nRecord].szFileIdentifier;	break;
			case PSFFileSection_FileName:		strValue=m_PSFFileSectionArray[nRecord].szFileName;		break;
			}
		}
		break;
	}

	return strValue;
}

void	CPSFAscii::GetPSFDataStringArray(const int nTable, const int nRecord, std::vector<std::string>& strStringArray)
{
	int		nField;
	strStringArray.clear();

	if (nTable < 0 || nTable >= sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable))
		return;

	for (nField=0; nField<g_PSFModelTables[nTable].nFieldNum; nField++)
		strStringArray.push_back(GetPSFDataString(nTable, nField, nRecord));
}
