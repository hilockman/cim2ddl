#include "StdAfx.h"
#include "PG2PSFAscii.h"

extern	void	PrintMessage(const char* lpszFormat, ...);

void CPG2PSFAscii::ErasePSFBoundNet(CPSFAscii* pPSFAscii)
{
	register int	i;

	i=0;
	while (i < (int)pPSFAscii->m_PSFBusArray.size())
	{
		if (pPSFAscii->m_PSFBusArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFBusArray.erase(pPSFAscii->m_PSFBusArray.begin()+i);
		else
			i++;
	}

	i=0;
	while (i < (int)pPSFAscii->m_PSFGeneratorArray.size())
	{
		if (pPSFAscii->m_PSFGeneratorArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFGeneratorArray.erase(pPSFAscii->m_PSFGeneratorArray.begin()+i);
		else
			i++;
	}

	i=0;
	while (i < (int)pPSFAscii->m_PSFLoadArray.size())
	{
		if (pPSFAscii->m_PSFLoadArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFLoadArray.erase(pPSFAscii->m_PSFLoadArray.begin()+i);
		else
			i++;
	}

	i=0;
	while (i < (int)pPSFAscii->m_PSFFixedShuntArray.size())
	{
		if (pPSFAscii->m_PSFFixedShuntArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFFixedShuntArray.erase(pPSFAscii->m_PSFFixedShuntArray.begin()+i);
		else
			i++;
	}

	i=0;
	while (i < (int)pPSFAscii->m_PSFSwitchableShuntArray.size())
	{
		if (pPSFAscii->m_PSFSwitchableShuntArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFSwitchableShuntArray.erase(pPSFAscii->m_PSFSwitchableShuntArray.begin()+i);
		else
			i++;
	}

	i=0;
	while (i < (int)pPSFAscii->m_PSFLineArray.size())
	{
		if (pPSFAscii->m_PSFLineArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFLineArray.erase(pPSFAscii->m_PSFLineArray.begin()+i);
		else
			i++;
	}

	i=0;
	while (i < (int)pPSFAscii->m_PSFFixedTranArray.size())
	{
		if (pPSFAscii->m_PSFFixedTranArray[i].bPG2PSFDeleteFlag)
			pPSFAscii->m_PSFFixedTranArray.erase(pPSFAscii->m_PSFFixedTranArray.begin()+i);
		else
			i++;
	}
}

void CPG2PSFAscii::AppendPGBoundNet(CPSFAscii* pPSFAscii, const double fZIL)
{
	register int	i;
	int		nDev;
	unsigned char	bExist;
	for (nDev=0; nDev<(int)m_PG2PSFAreaArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<(int)pPSFAscii->m_PSFAreaInterchangeArray.size(); i++)
		{
			if (strcmp(pPSFAscii->m_PSFAreaInterchangeArray[i].szName, m_PG2PSFAreaArray[nDev].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			pPSFAscii->m_PSFAreaInterchangeArray.push_back(m_PG2PSFAreaArray[nDev]);
	}
	for (nDev=0; nDev<(int)m_PG2PSFZoneArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<(int)pPSFAscii->m_PSFZoneArray.size(); i++)
		{
			if (strcmp(pPSFAscii->m_PSFZoneArray[i].szName, m_PG2PSFZoneArray[nDev].szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			pPSFAscii->m_PSFZoneArray.push_back(m_PG2PSFZoneArray[nDev]);
	}
	for (nDev=0; nDev<(int)m_PG2PSFBusArray.size(); nDev++)
	{
		bExist=0;
		for (i=0; i<(int)pPSFAscii->m_PSFBusArray.size(); i++)
		{
			if (pPSFAscii->m_PSFBusArray[i].nNumber == m_PG2PSFBusArray[nDev].nNumber)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			pPSFAscii->m_PSFBusArray.push_back(m_PG2PSFBusArray[nDev]);
	}
	for (nDev=0; nDev<(int)m_PG2PSFGenArray.size(); nDev++)
		pPSFAscii->m_PSFGeneratorArray.push_back(m_PG2PSFGenArray[nDev]);
	for (nDev=0; nDev<(int)m_PG2PSFLoadArray.size(); nDev++)
		pPSFAscii->m_PSFLoadArray.push_back(m_PG2PSFLoadArray[nDev]);
	for (nDev=0; nDev<(int)m_PG2PSFCapArray.size(); nDev++)
		pPSFAscii->m_PSFFixedShuntArray.push_back(m_PG2PSFCapArray[nDev]);
	for (nDev=0; nDev<(int)m_PG2PSFLineArray.size(); nDev++)
		pPSFAscii->m_PSFLineArray.push_back(m_PG2PSFLineArray[nDev]);
	for (nDev=0; nDev<(int)m_PG2PSFTranArray.size(); nDev++)
		pPSFAscii->m_PSFFixedTranArray.push_back(m_PG2PSFTranArray[nDev]);

	pPSFAscii->PSFAsciiMaint(fZIL);
}

void CPG2PSFAscii::FormPSFBoundNet(CPSFAscii* pPSFAscii)
{
	register int	i,j;
	int		nLine,nBus;
	unsigned char	bExist;
	std::vector<int>			nJointNodeArray;
	std::vector<int>			nNetNodeArray;
	std::vector<unsigned char>	bNodeProcArray;
	std::vector<int>			nBoundNodeArray;
	std::vector<unsigned char>	bLineBoundedArray;
	std::vector<unsigned char>	bTranBoundedArray;
	tagPSFBoundNetDevice		devBuf;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	m_PSFBoundNetBusArray.clear();
	m_PSFBoundNetLineArray.clear();
	m_PSFBoundNetTranArray.clear();
	m_PSFBoundNetGenArray.clear();
	m_PSFBoundNetLoadArray.clear();
	m_PSFBoundNetCapArray.clear();

	for (i=0; i<(int)pPSFAscii->m_PSFBusArray.size(); i++)
		pPSFAscii->m_PSFBusArray[i].bPG2PSFDeleteFlag=0;
	for (i=0; i<(int)pPSFAscii->m_PSFGeneratorArray.size(); i++)
		pPSFAscii->m_PSFGeneratorArray[i].bPG2PSFDeleteFlag=0;
	for (i=0; i<(int)pPSFAscii->m_PSFLoadArray.size(); i++)
		pPSFAscii->m_PSFLoadArray[i].bPG2PSFDeleteFlag=0;
	for (i=0; i<(int)pPSFAscii->m_PSFFixedShuntArray.size(); i++)
		pPSFAscii->m_PSFFixedShuntArray[i].bPG2PSFDeleteFlag=0;
	for (i=0; i<(int)pPSFAscii->m_PSFSwitchableShuntArray.size(); i++)
		pPSFAscii->m_PSFSwitchableShuntArray[i].bPG2PSFDeleteFlag=0;
	for (i=0; i<(int)pPSFAscii->m_PSFLineArray.size(); i++)
		pPSFAscii->m_PSFLineArray[i].bPG2PSFDeleteFlag=0;
	for (i=0; i<(int)pPSFAscii->m_PSFFixedTranArray.size(); i++)
		pPSFAscii->m_PSFFixedTranArray[i].bPG2PSFDeleteFlag=0;

	for (i=0; i<(int)pPSFAscii->m_PSFLineArray.size(); i++)
		pPSFAscii->m_PSFLineArray[i].bOpened=0;

	nBoundNodeArray.clear();
	for (i=0; i<(int)m_PG2PSFBoundArray.size(); i++)
	{
		nLine=-1;
		for (j=0; j<(int)pPSFAscii->m_PSFLineArray.size(); j++)
		{
			if (strcmp(pPSFAscii->m_PSFLineArray[j].szPSFName, m_PG2PSFBoundArray[i].szPSFBoundLine) == 0)
			{
				nLine=j;
				break;
			}
		}
		if (nLine >= 0)
		{
			pPSFAscii->m_PSFLineArray[nLine].bOpened=1;
			if (strcmp(pPSFAscii->m_PSFBusArray[pPSFAscii->m_PSFLineArray[nLine].nBus1Index].szSubstation, m_PG2PSFBoundArray[i].szPSFBoundSub) == 0)
				nBoundNodeArray.push_back(pPSFAscii->m_PSFLineArray[nLine].nBus1Index);
			else
				nBoundNodeArray.push_back(pPSFAscii->m_PSFLineArray[nLine].nBus2Index);
		}
	}
	for (i=0; i<(int)nBoundNodeArray.size(); i++)
		PrintMessage("    �߽�ڵ�[%d/%d] %d",i+1,nBoundNodeArray.size(),nBoundNodeArray[i]);

	i=0;
	while (i < (int)nBoundNodeArray.size())
	{
		bExist=0;
		for (j=i+1; j<(int)nBoundNodeArray.size(); j++)
		{
			if (nBoundNodeArray[i] == nBoundNodeArray[j])
			{
				bExist=1;
				break;
			}
		}
		if (bExist)
			nBoundNodeArray.erase(nBoundNodeArray.begin()+i);
		else
			i++;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�߽�ڵ㽨����ϣ���ʱ%d����", nDur);

	bNodeProcArray.resize(pPSFAscii->m_PSFBusArray.size());
	for (i=0; i<(int)bNodeProcArray.size(); i++)
		bNodeProcArray[i]=0;
	nNetNodeArray.clear();
	for (i=0; i<(int)nBoundNodeArray.size(); i++)
	{
		if (bNodeProcArray[nBoundNodeArray[i]])
			continue;

		pPSFAscii->TraverseNet(nBoundNodeArray[i], 0, nJointNodeArray);
		for (j=0; j<(int)nJointNodeArray.size(); j++)
		{
			nNetNodeArray.push_back(nJointNodeArray[j]);
			bNodeProcArray[nJointNodeArray[j]]=1;
		}
	}

	bLineBoundedArray.resize(pPSFAscii->m_PSFLineArray.size());
	bTranBoundedArray.resize(pPSFAscii->m_PSFFixedTranArray.size());
	for (i=0; i<(int)bLineBoundedArray.size(); i++)			bLineBoundedArray[i]=0;
	for (i=0; i<(int)bTranBoundedArray.size(); i++)			bTranBoundedArray[i]=0;
// 	for (i=0; i<(int)m_PG2PSFBoundArray.size(); i++)
// 	{
// 		nLine=-1;
// 		for (j=0; j<(int)pPSFAscii->m_PSFLineArray.size(); j++)
// 		{
// 			if (strcmp(pPSFAscii->m_PSFLineArray[j].szPSFName, m_PG2PSFBoundArray[i].szPSFBoundLine) == 0)
// 			{
// 				nLine=j;
// 				break;
// 			}
// 		}
// 		if (nLine >= 0)
// 			bLineBoundedArray[nLine]=1;
// 	}

	for (nBus=0; nBus<(int)nNetNodeArray.size(); nBus++)
	{
		strcpy(devBuf.szSub,  pPSFAscii->m_PSFBusArray[nNetNodeArray[nBus]].szSubstation);
		devBuf.fkV=pPSFAscii->m_PSFBusArray[nNetNodeArray[nBus]].fkV;
		strcpy(devBuf.szName, pPSFAscii->m_PSFBusArray[nNetNodeArray[nBus]].szName);
		pPSFAscii->m_PSFBusArray[nNetNodeArray[nBus]].bPG2PSFDeleteFlag=1;
		m_PSFBoundNetBusArray.push_back(devBuf);

		for (i=0; i<(int)pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nGeneratorArray.size(); i++)
		{
			strcpy(devBuf.szName, pPSFAscii->m_PSFGeneratorArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nGeneratorArray[i]].szBusName);
			devBuf.nPSFIndex=pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nGeneratorArray[i];
			pPSFAscii->m_PSFGeneratorArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nGeneratorArray[i]].bPG2PSFDeleteFlag=1;
			m_PSFBoundNetGenArray.push_back(devBuf);
		}
		for (i=0; i<(int)pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLoadArray.size(); i++)
		{
			strcpy(devBuf.szName, pPSFAscii->m_PSFLoadArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLoadArray[i]].szBusName);
			devBuf.nPSFIndex=pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLoadArray[i];
			pPSFAscii->m_PSFLoadArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLoadArray[i]].bPG2PSFDeleteFlag=1;
			m_PSFBoundNetLoadArray.push_back(devBuf);
		}
		for (i=0; i<(int)pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedShuntArray.size(); i++)
		{
			strcpy(devBuf.szName, pPSFAscii->m_PSFFixedShuntArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedShuntArray[i]].szBusName);
			devBuf.nPSFIndex=pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedShuntArray[i];
			pPSFAscii->m_PSFFixedShuntArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedShuntArray[i]].bPG2PSFDeleteFlag=1;
			m_PSFBoundNetCapArray.push_back(devBuf);
		}
		for (i=0; i<(int)pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nSwitchableShuntArray.size(); i++)
		{
			pPSFAscii->m_PSFSwitchableShuntArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nSwitchableShuntArray[i]].bPG2PSFDeleteFlag=1;
		}
		for (i=0; i<(int)pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray.size(); i++)
		{
			if (bLineBoundedArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray[i]] ||
				pPSFAscii->m_PSFLineArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray[i]].bOpened)
				continue;

			strcpy(devBuf.szName, pPSFAscii->m_PSFLineArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray[i]].szPSFName);
			devBuf.nPSFIndex=pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray[i];
			pPSFAscii->m_PSFLineArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray[i]].bPG2PSFDeleteFlag=1;
			m_PSFBoundNetLineArray.push_back(devBuf);

			bLineBoundedArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nLineArray[i]]=1;
		}
		for (i=0; i<(int)pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedTransformerArray.size(); i++)
		{
			if (bTranBoundedArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedTransformerArray[i]])
				continue;

			strcpy(devBuf.szName, pPSFAscii->m_PSFFixedTranArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedTransformerArray[i]].szPSFName);
			devBuf.nPSFIndex=pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedTransformerArray[i];
			pPSFAscii->m_PSFFixedTranArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedTransformerArray[i]].bPG2PSFDeleteFlag=1;
			m_PSFBoundNetTranArray.push_back(devBuf);

			bTranBoundedArray[pPSFAscii->m_BusNobnArray[nNetNodeArray[nBus]].nFixedTransformerArray[i]]=1;
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�߽��豸������ϣ���ʱ%d����", nDur);

	for (i=0; i<(int)pPSFAscii->m_PSFLineArray.size(); i++)
		pPSFAscii->m_PSFLineArray[i].bOpened=0;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("������ϣ���ʱ%d����", nDur);
}

void CPG2PSFAscii::FormPGBoundNet(tagPGBlock* pBlock)
{
	register int	i,j;
	int		nDevice,nVolt,nNode;
	unsigned char	bExist;
	int		nJointNodeNum;
	int*	pnJointNodeArray;
	std::vector<int>			nNetNodeArray;
	std::vector<unsigned char>	bNodeProcArray;
	std::vector<int>			nBoundNodeArray;
	std::vector<unsigned char>	bLineBoundedArray;
	std::vector<unsigned char>	bTranBoundedArray;
	std::vector<unsigned char>	bBreakerBoundedArray;
	std::vector<unsigned char>	bDisconnectorBoundedArray;
	tagPGBoundNetDevice	devBuf;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	pnJointNodeArray=(int*)malloc(sizeof(int)*pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	if (!pnJointNodeArray)
		return;

	m_PGBoundNetBusArray.clear();
	m_PGBoundNetLineArray.clear();
	m_PGBoundNetTranArray.clear();
	m_PGBoundNetGenArray.clear();
	m_PGBoundNetLoadArray.clear();
	m_PGBoundNetCapArray.clear();
	m_PGBoundNetBreakerArray.clear();
	m_PGBoundNetDisconnectorArray.clear();
	m_PGBoundNetGroundDisconnectorArray.clear();

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pBlock->m_ACLineSegmentArray[i].open=0;

	nBoundNodeArray.clear();
	for (i=0; i<(int)m_PG2PSFBoundArray.size(); i++)
	{
		switch (m_PG2PSFBoundArray[i].nPGBoundDevType)
		{
		case PG_ACLINESEGMENT:
			nDevice=-1;
			for (j=0; j<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; j++)
			{
				if (strcmp(pBlock->m_ACLineSegmentArray[j].szName, m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_ACLineSegmentArray[j].szSubI, m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 || strcmp(pBlock->m_ACLineSegmentArray[j].szSubZ, m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_ACLineSegmentArray[j].szVoltI, m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0 || strcmp(pBlock->m_ACLineSegmentArray[j].szVoltZ, m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
			{
				pBlock->m_ACLineSegmentArray[nDevice].open=1;
				if (strcmp(pBlock->m_ACLineSegmentArray[nDevice].szSubI, m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0)
					nBoundNodeArray.push_back(pBlock->m_ACLineSegmentArray[nDevice].iRnd);
				else
					nBoundNodeArray.push_back(pBlock->m_ACLineSegmentArray[nDevice].zRnd);
			}
			break;
		case PG_SYNCHRONOUSMACHINE:
			nDevice=-1;
			for (j=0; j<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; j++)
			{
				if (strcmp(pBlock->m_SynchronousMachineArray[j].szName, m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_SynchronousMachineArray[j].szSub, m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_SynchronousMachineArray[j].szVolt, m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
				nBoundNodeArray.push_back(pBlock->m_SynchronousMachineArray[nDevice].iRnd);
			break;
		case PG_ENERGYCONSUMER:
			nDevice=-1;
			for (j=0; j<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; j++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[j].szName, m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_EnergyConsumerArray[j].szSub, m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_EnergyConsumerArray[j].szVolt, m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
				nBoundNodeArray.push_back(pBlock->m_EnergyConsumerArray[nDevice].iRnd);
			break;
		case PG_BUSBARSECTION:
			nDevice=-1;
			for (j=0; j<pBlock->m_nRecordNum[PG_BUSBARSECTION]; j++)
			{
				if (pBlock->m_BusbarSectionArray[nDevice].iRnd < 0)
					continue;

				if (strcmp(pBlock->m_BusbarSectionArray[j].szName, m_PG2PSFBoundArray[i].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_BusbarSectionArray[j].szSub, m_PG2PSFBoundArray[i].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_BusbarSectionArray[j].szVolt, m_PG2PSFBoundArray[i].szPGBoundDevVolt) == 0)
				{
					nDevice=j;
					break;
				}
			}
			if (nDevice >= 0)
				nBoundNodeArray.push_back(pBlock->m_BusbarSectionArray[nDevice].iRnd);
			break;
		}
	}

	i=0;
	while (i < (int)nBoundNodeArray.size())
	{
		bExist=0;
		for (j=i+1; j<(int)nBoundNodeArray.size(); j++)
		{
			if (nBoundNodeArray[i] == nBoundNodeArray[j])
			{
				bExist=1;
				break;
			}
		}
		if (bExist)
			nBoundNodeArray.erase(nBoundNodeArray.begin()+i);
		else
			i++;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�߽�ڵ㽨����ϣ���ʱ%d����", nDur);
	for (i=0; i<(int)nBoundNodeArray.size(); i++)
		PrintMessage("    �߽�ڵ�[%d/%d] %s %s %s",i+1,nBoundNodeArray.size(),
			pBlock->m_ConnectivityNodeArray[nBoundNodeArray[i]].szSub,pBlock->m_ConnectivityNodeArray[nBoundNodeArray[i]].szVolt,pBlock->m_ConnectivityNodeArray[nBoundNodeArray[i]].szName);

	bNodeProcArray.resize(pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	for (i=0; i<(int)bNodeProcArray.size(); i++)
		bNodeProcArray[i]=0;
	nNetNodeArray.clear();
	for (i=0; i<(int)nBoundNodeArray.size(); i++)
	{
		if (bNodeProcArray[nBoundNodeArray[i]])
			continue;
		nJointNodeNum=0;
		PGTraverseNet(pBlock, nBoundNodeArray[i], Y_CheckStatus, 0, nJointNodeNum, pnJointNodeArray);
		for (j=0; j<nJointNodeNum; j++)
		{
			nNetNodeArray.push_back(pnJointNodeArray[j]);
			bNodeProcArray[pnJointNodeArray[j]]=1;
		}
	}
	free(pnJointNodeArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("���������ϣ���ʱ%d����", nDur);
	PrintMessage("    �������нڵ�=%d/%d", nNetNodeArray.size(), pBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);

	bLineBoundedArray.resize(pBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	bTranBoundedArray.resize(pBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	bBreakerBoundedArray.resize(pBlock->m_nRecordNum[PG_BREAKER]);
	bDisconnectorBoundedArray.resize(pBlock->m_nRecordNum[PG_DISCONNECTOR]);
	for (i=0; i<(int)bLineBoundedArray.size(); i++)			bLineBoundedArray[i]=0;
	for (i=0; i<(int)bTranBoundedArray.size(); i++)			bTranBoundedArray[i]=0;
	for (i=0; i<(int)bBreakerBoundedArray.size(); i++)		bBreakerBoundedArray[i]=0;
	for (i=0; i<(int)bDisconnectorBoundedArray.size(); i++)	bDisconnectorBoundedArray[i]=0;

	for (nNode=0; nNode<(int)nNetNodeArray.size(); nNode++)
	{
		if (PGIsTranMidNode(pBlock, nNetNodeArray[nNode]))
			continue;

		nVolt=PGGetVoltIndex(pBlock, pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]].szSub, pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]].szVolt);
		for (i=pBlock->m_VoltageLevelArray[nVolt].pRbus; i<pBlock->m_VoltageLevelArray[nVolt+1].pRbus; i++)
		{
			if (pBlock->m_BusbarSectionArray[i].iRnd == nNetNodeArray[nNode])
			{
				strcpy(devBuf.szSub,  pBlock->m_BusbarSectionArray[i].szSub);
				strcpy(devBuf.szVolt, pBlock->m_BusbarSectionArray[i].szVolt);
				strcpy(devBuf.szName, pBlock->m_BusbarSectionArray[i].szName);
				devBuf.nPGIndex=i;
				m_PGBoundNetBusArray.push_back(devBuf);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].pRun; i<pBlock->m_VoltageLevelArray[nVolt+1].pRun; i++)
		{
			if (pBlock->m_SynchronousMachineArray[i].iRnd == nNetNodeArray[nNode])
			{
				strcpy(devBuf.szSub,  pBlock->m_SynchronousMachineArray[i].szSub);
				strcpy(devBuf.szVolt, pBlock->m_SynchronousMachineArray[i].szVolt);
				strcpy(devBuf.szName, pBlock->m_SynchronousMachineArray[i].szName);
				devBuf.nPGIndex=i;
				m_PGBoundNetGenArray.push_back(devBuf);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].pRld; i<pBlock->m_VoltageLevelArray[nVolt+1].pRld; i++)
		{
			if (pBlock->m_EnergyConsumerArray[i].iRnd == nNetNodeArray[nNode])
			{
				strcpy(devBuf.szSub,  pBlock->m_EnergyConsumerArray[i].szSub);
				strcpy(devBuf.szVolt, pBlock->m_EnergyConsumerArray[i].szVolt);
				strcpy(devBuf.szName, pBlock->m_EnergyConsumerArray[i].szName);
				devBuf.nPGIndex=i;
				m_PGBoundNetLoadArray.push_back(devBuf);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].pRpcp; i<pBlock->m_VoltageLevelArray[nVolt+1].pRpcp; i++)
		{
			if (pBlock->m_ShuntCompensatorArray[i].iRnd == nNetNodeArray[nNode])
			{
				strcpy(devBuf.szSub,  pBlock->m_ShuntCompensatorArray[i].szSub);
				strcpy(devBuf.szVolt, pBlock->m_ShuntCompensatorArray[i].szVolt);
				strcpy(devBuf.szName, pBlock->m_ShuntCompensatorArray[i].szName);
				devBuf.nPGIndex=i;
				m_PGBoundNetCapArray.push_back(devBuf);
			}
		}
		for (i=pBlock->m_VoltageLevelArray[nVolt].pRgdis; i<pBlock->m_VoltageLevelArray[nVolt+1].pRgdis; i++)
		{
			if (pBlock->m_GroundDisconnectorArray[i].iRnd == nNetNodeArray[nNode])
			{
				strcpy(devBuf.szSub,  pBlock->m_GroundDisconnectorArray[i].szSub);
				strcpy(devBuf.szVolt, pBlock->m_GroundDisconnectorArray[i].szVolt);
				strcpy(devBuf.szName, pBlock->m_GroundDisconnectorArray[i].szName);
				devBuf.nPGIndex=i;
				m_PGBoundNetGroundDisconnectorArray.push_back(devBuf);
			}
		}
		for (i=pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]].pRAcln2; i<pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]+1].pRAcln2; i++)
		{
			if (bLineBoundedArray[pBlock->m_ACLineSegment2Array[i].iRln])
				continue;

			strcpy(devBuf.szSub,  pBlock->m_ACLineSegment2Array[i].szSub);
			strcpy(devBuf.szVolt, pBlock->m_ACLineSegment2Array[i].szVolt);
			strcpy(devBuf.szName, pBlock->m_ACLineSegment2Array[i].szName);
			devBuf.nPGIndex=pBlock->m_ACLineSegment2Array[i].iRln;
			bLineBoundedArray[pBlock->m_ACLineSegment2Array[i].iRln]=1;
			m_PGBoundNetLineArray.push_back(devBuf);
		}
		for (i=pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]].pRWind2; i<pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]+1].pRWind2; i++)
		{
			if (bTranBoundedArray[pBlock->m_TransformerWinding2Array[i].iRWind])
				continue;

			strcpy(devBuf.szSub,  pBlock->m_TransformerWinding2Array[i].szSub);
			strcpy(devBuf.szVolt, pBlock->m_TransformerWinding2Array[i].szVolt);
			strcpy(devBuf.szName, pBlock->m_TransformerWinding2Array[i].szName);
			devBuf.nPGIndex=pBlock->m_TransformerWinding2Array[i].iRWind;
			bTranBoundedArray[pBlock->m_TransformerWinding2Array[i].iRWind]=1;
			m_PGBoundNetTranArray.push_back(devBuf);
		}
		for (i=pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]].pRbr2; i<pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]+1].pRbr2; i++)
		{
			if (bBreakerBoundedArray[pBlock->m_Breaker2Array[i].iRbr])
				continue;

			strcpy(devBuf.szSub,  pBlock->m_Breaker2Array[i].szSub);
			strcpy(devBuf.szVolt, pBlock->m_Breaker2Array[i].szVolt);
			strcpy(devBuf.szName, pBlock->m_Breaker2Array[i].szName);
			devBuf.nPGIndex=pBlock->m_Breaker2Array[i].iRbr;
			bBreakerBoundedArray[pBlock->m_Breaker2Array[i].iRbr]=1;
			m_PGBoundNetBreakerArray.push_back(devBuf);
		}
		for (i=pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]].pRsw2; i<pBlock->m_ConnectivityNodeArray[nNetNodeArray[nNode]+1].pRsw2; i++)
		{
			if (bDisconnectorBoundedArray[pBlock->m_Disconnector2Array[i].iRsw])
				continue;

			strcpy(devBuf.szSub,  pBlock->m_Disconnector2Array[i].szSub);
			strcpy(devBuf.szVolt, pBlock->m_Disconnector2Array[i].szVolt);
			strcpy(devBuf.szName, pBlock->m_Disconnector2Array[i].szName);
			devBuf.nPGIndex=pBlock->m_Disconnector2Array[i].iRsw;
			bDisconnectorBoundedArray[pBlock->m_Disconnector2Array[i].iRsw]=1;
			m_PGBoundNetDisconnectorArray.push_back(devBuf);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("�����豸ģ�ͽ�����ϣ���ʱ%d����", nDur);

	for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		pBlock->m_ACLineSegmentArray[i].open=0;

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("������ɣ���ʱ%d����", nDur);

	sortBoundNetBus(0, m_PGBoundNetBusArray.size()-1);
	sortBoundNetLine(0, m_PGBoundNetLineArray.size()-1);
	sortBoundNetTran(0, m_PGBoundNetTranArray.size()-1);
	sortBoundNetGen(0, m_PGBoundNetGenArray.size()-1);
	sortBoundNetLoad(0, m_PGBoundNetLoadArray.size()-1);
	sortBoundNetCap(0, m_PGBoundNetCapArray.size()-1);
	sortBoundNetBreaker(0, m_PGBoundNetBreakerArray.size()-1);
	sortBoundNetDisconnector(0, m_PGBoundNetDisconnectorArray.size()-1);
	sortBoundNetGroundDisconnector(0, m_PGBoundNetGroundDisconnectorArray.size()-1);
}
