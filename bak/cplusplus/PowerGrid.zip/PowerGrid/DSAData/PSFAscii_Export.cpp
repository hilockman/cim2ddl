#include "StdAfx.h"
#include <float.h>
#include "PSFAscii.h"

void	CPSFAscii::ExportPSFSolutionHistory(FILE* fp, const unsigned char bRTData)
{
	std::string	strBuf;
	std::vector<std::string>	strEleArray;

	fprintf(fp,"%s",		m_PSFSolution.szDescription1);
	fprintf(fp,"\n");

	fprintf(fp,"%s",		m_PSFSolution.szDescription2);
	fprintf(fp,"\n");

	fprintf(fp,"%s",		m_PSFSolution.szDescription3);
	fprintf(fp,"\n");

	fprintf(fp,"\'%s\' ",	m_PSFSolution.szDate);
	fprintf(fp,"\'%s\' ",	m_PSFSolution.szTime);
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fBaseMVA));
	fprintf(fp,"\n");

	fprintf(fp,"\'%s\' ",	m_PSFSolution.szMethod);
	fprintf(fp,"%d ",		m_PSFSolution.nITER);
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fSOLTOL));
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fBLUP));
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fACCFCT));
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fZIL));
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fVTOL));
	fprintf(fp,"%s ",		FormularFloatString(m_PSFSolution.fCONADJ));
	fprintf(fp,"\'%s\' ",	m_PSFSolution.szSTOPT);
	fprintf(fp,"\n");

	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag1 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag2 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag3 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag4 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag5 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag6 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag7 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag8 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag9 ]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag10]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag11]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag12]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag13]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag14]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag15]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag16]);
	fprintf(fp,"\'%s\' ",	g_lpszPSFSolutionHistory_Flag[m_PSFSolution.bFlag17]);
	fprintf(fp,"\n");
}

// Number, Name, Voltage, Angle, kV, Type, Status, Area, Zone, D1, D2, D3, D4, D5, Owner
// Equipment name, Latitude, Longitude
void	CPSFAscii::ExportPSFBus(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFBusArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFBusArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFBusArray[i].nNumber);
		fprintf(fp,"\'%s\' ",	m_PSFBusArray[i].szName);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFBusArray[i].fVoltage));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFBusArray[i].fAngle));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFBusArray[i].fkV));
		fprintf(fp,"%d ",		m_PSFBusArray[i].nType);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nStatus);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nArea);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nZone);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nD1);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nD2);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nD3);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nD4);
		fprintf(fp,"%d ",		m_PSFBusArray[i].nD5);
		fprintf(fp,"\'%s\' ",	m_PSFBusArray[i].szOwner);
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFBusArray[i].szEquipmentName);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFBusArray[i].fLatitude));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFBusArray[i].fLongitude));
		fprintf(fp,"\n");
	}
}

// Bus number, ID, Status, MW, MVAR, QMAX, QMIN, V Hi limit, V Lo limit, Remote bus, RMB V, % Ctrl
// USCH Q, MVA, PMAX, PMIN, RS, XS, RT, XT, TAP
// Equipment name, Owner, GWMOD, GWPF, GBASLD
// RP, XP, RN, XN, RZ, XZ, RG, XG
void	CPSFAscii::ExportPSFGenerator(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFGeneratorArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFGeneratorArray[i].nBusNumber);
		fprintf(fp,"\'%s\' ",	m_PSFGeneratorArray[i].szID);
		fprintf(fp,"%d ",		m_PSFGeneratorArray[i].nStatus);
		if (bRTData && m_PSFGeneratorArray[i].bRTDataSetted)
		{
			fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRTMW));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRTMVar));
		}
		else
		{
			fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fMW));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fMVar));
		}

		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fQMax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fQMin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fVHiLimit));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fVLoLimit));
		fprintf(fp,"%d ",		m_PSFGeneratorArray[i].nRemoteBus);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRemoteBusV));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fQContributionPercentCtrl));
		fprintf(fp,"\n");

		fprintf(fp,"%d ",		m_PSFGeneratorArray[i].nUSCHQ);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fMva));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fPMax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fPMin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRS));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fXS));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fXT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fTAP));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFGeneratorArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFGeneratorArray[i].szOwner);
		fprintf(fp,"%d ",		m_PSFGeneratorArray[i].nGWMOD);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fGWPF));
		fprintf(fp,"%d ",		m_PSFGeneratorArray[i].nGBASLD);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRP));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fXP));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRN));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fXN));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fXZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fRG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFGeneratorArray[i].fXG));
		fprintf(fp,"\n");
	}
}

// Bus number, Ref P, Ref Q, P1, Q1, P2, Q2, P3, Q3, P4, Q4
// P5, Q5, M1, M2, M3, M4, M5, Type, Owner, ID, Scalable
// Equipment name, Area, Zone, Status
// GN, BN, GZ, BZ
void	CPSFAscii::ExportPSFLoad(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFLoadArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFLoadArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nBusNumber);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fRefP));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fRefQ));

		if (bRTData && m_PSFLoadArray[i].bRTDataSetted)
		{
			fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fRTP));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fRTQ));
		}
		else
		{
			fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fP1));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fQ1));
		}

		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fP2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fQ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fP3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fQ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fP4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fQ4));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fP5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fQ5));
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nM1);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nM2);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nM3);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nM4);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nM5);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nType);
		fprintf(fp,"\'%s\' ",	m_PSFLoadArray[i].szOwner);
		fprintf(fp,"\'%s\' ",	m_PSFLoadArray[i].szID);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nScalable);
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFLoadArray[i].szEquipmentName);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nArea);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nZone);
		fprintf(fp,"%d ",		m_PSFLoadArray[i].nStatus);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fGN));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fBN));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fGZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadArray[i].fBZ));
		fprintf(fp,"\n");
	}
}

// Model number, A1, A2, A3, N1, N2, N3, B1, B2, B3, M1, M2, M3
void	CPSFAscii::ExportPSFLoadModel(FILE* fp, const unsigned char bRTData)
{
	register int	i;
	for (i=0; i<(int)m_PSFLoadModelArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFLoadModelArray[i].nModelNumber);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fA1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fA2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fA3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fN1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fN2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fN3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fB1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fB2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fB3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fM1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fM2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLoadModelArray[i].fM3));
		fprintf(fp,"\n");
	}
}

// Bus number, G, B, Type, Owner, ID
// Equipment name, Status
// GN, BN, GZ, BZ
void	CPSFAscii::ExportPSFFixedShunt(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFFixedShuntArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFFixedShuntArray[i].nBusNumber);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedShuntArray[i].fG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedShuntArray[i].fB));
		fprintf(fp,"%d ",		m_PSFFixedShuntArray[i].nType);
		fprintf(fp,"\'%s\' ",	m_PSFFixedShuntArray[i].szOwner);
		fprintf(fp,"\'%s\' ",	m_PSFFixedShuntArray[i].szID);
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFFixedShuntArray[i].szEquipmentName);
		fprintf(fp,"%d ",		m_PSFFixedShuntArray[i].nStatus);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedShuntArray[i].fGN));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedShuntArray[i].fBN));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedShuntArray[i].fGZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedShuntArray[i].fBZ));
		fprintf(fp,"\n");
	}
}

// Bus number, Mode, Status, V Hi limit, V Lo limit, Remote bus, RMB voltage, % Contrl, G0, B0, Owner
// ID, N1, B1, N2, B2, N3, B3, N4, B4, N5, B5, N6, B6, N7, B7, N8, B8 (second line of data for SW shunt / SVC)
// ID, IMAX (second line of data for STATSON)
// Equipment name, RV U limit, RV L limit
void	CPSFAscii::ExportPSFSwitchableShunt(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFSwitchableShuntArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nBusNumber);
		fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nMode);
		fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nStatus);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fVHiLimit));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fVLoLimit));
		fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nRemoteBus);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fRemoteBusVoltage));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fQContributionPercentCtrl));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fG0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fB0));
		fprintf(fp,"\'%s\' ",	m_PSFSwitchableShuntArray[i].szOwner);
		fprintf(fp,"\n");

		if (m_PSFSwitchableShuntArray[i].nMode != 4)
		{
			fprintf(fp,"\'%s\' ",	m_PSFSwitchableShuntArray[i].szID);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN1);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN2);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN3);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN4);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN5);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN6);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN7);
			fprintf(fp,"%d ",		m_PSFSwitchableShuntArray[i].nN8);
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN1));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN2));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN3));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN4));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN5));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN6));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN7));
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fN8));
		}
		else
		{
			fprintf(fp,"\'%s\' ",	m_PSFSwitchableShuntArray[i].szID);
			fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fIMAX));
		}
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFSwitchableShuntArray[i].szEquipmentName);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fRVULimit));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableShuntArray[i].fRVLLimit));
		fprintf(fp,"\n");
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, R, X, G, B
// GF, BF, GT, BT, R1, R2, R3, R4, R5, R6, Rating group, Z1, Z2, Z3, Z4, Z5, Z6, Type
// Equipment name, Owner, Length
// RZ, XZ, RZC, XZC, RZSF, XZSF, RZST, XZST
void	CPSFAscii::ExportPSFLine(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFLineArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFLineArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFLineArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSFLineArray[i].nBus2Number);
		fprintf(fp,"\'%s\' ",	m_PSFLineArray[i].szID);
		fprintf(fp,"%d ",		m_PSFLineArray[i].nSection);
		fprintf(fp,"%d ",		m_PSFLineArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_MeterEnd[m_PSFLineArray[i].nMeterEnd]);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fB));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fBF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fBT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fR6));
		fprintf(fp,"%d ",		m_PSFLineArray[i].nRatingGroup);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fZ1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fZ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fZ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fZ4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fZ5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fZ6));
		fprintf(fp,"%d ",		m_PSFLineArray[i].nType);
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFLineArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFLineArray[i].szOwner);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fLength));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fRZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fXZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fRZC));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fXZC));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fRZSF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fXZSF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fRZST));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLineArray[i].fXZST));
		fprintf(fp,"\n");
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, ONR, Angle, R, X, G, B
// GF, BF, GT, BT, R1, R2, R3, R4, R5, R6, Rating group, MVA
// Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Name, Owner
// RZ, XZ, Code, RGF, XGF, RGT, XGT
void	CPSFAscii::ExportPSFFixedTransformer(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
	{
		if (bRTData)
		{
			if (m_PSFFixedTranArray[i].nRTStatus != 0)
				continue;
		}
		fprintf(fp,"%d ",		m_PSFFixedTranArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSFFixedTranArray[i].nBus2Number);
		fprintf(fp,"\'%s\' ",	m_PSFFixedTranArray[i].szID);
		fprintf(fp,"%d ",		m_PSFFixedTranArray[i].nSection);
		fprintf(fp,"%d ",		m_PSFFixedTranArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_MeterEnd[m_PSFFixedTranArray[i].nMeterEnd]);
		if (bRTData && m_PSFFixedTranArray[i].bRTDataSetted)
			fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fRTTap));
		else
			fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fONR));

		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fAngle));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fB));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fBF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fBT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fR6));
		fprintf(fp,"%d ",		m_PSFFixedTranArray[i].nRatingGroup);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fMVA));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fZ1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fZ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fZ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fZ4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fZ5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fZ6));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFFixedTranArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFFixedTranArray[i].szName);
		fprintf(fp,"\'%s\' ",	m_PSFFixedTranArray[i].szOwner);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fRZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fXZ));
		fprintf(fp,"%d ",		m_PSFFixedTranArray[i].nWindConnectionCode);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fRGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fXGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fRGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedTranArray[i].fXGT));
		fprintf(fp,"\n");
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, FROM Ratio, TO Ratio, Angle, R, X, G, B
// GF, BF, GT, BT, Max R, Min R, Step, Max A, Min A, A Steps, Ctrl type, Ctrl side, Ctrl flag, Max MW, Min MW
// Max MVAR, Min MVAR, V Hi limit, V Lo limit, Ctrl Bus, Z Corr Table, R1, R2, R3, R4, R5, R6
// Rating group, MVA, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Name, Owner
// RZ, XZ, Code, RGF, XGF, RGT, XGT
void	CPSFAscii::ExportPSFULTCTransformer(FILE* fp, const unsigned char bRTData)
{
	register int	i;
	for (i=0; i<(int)m_PSFULTCTranArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nBus2Number);
		fprintf(fp,"\'%s\' ",	m_PSFULTCTranArray[i].szID);
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nSection);
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_MeterEnd[m_PSFULTCTranArray[i].nMeterEnd]);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fFromRatio));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fToRatio));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fAngle));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fB));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fBF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fBT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMaxR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMinR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fStep));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMaxA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMinA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fAStep));
		fprintf(fp,"\'%c\' ",	g_lpszPSFPSFULTCTransformer_CtrlType[m_PSFULTCTranArray[i].nCtrlType]);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_CtrlSide[m_PSFULTCTranArray[i].nCtrlSide]);
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nCtrlFlag);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMaxMW));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMinMW));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMaxMVar));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMinMVar));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fVHiLimit));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fVLoLimit));
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nCtrlBus);
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nZCorrTable);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fR6));
		fprintf(fp,"\n");

		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nRatingGroup);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fMVA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fZ1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fZ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fZ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fZ4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fZ5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fZ6));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFULTCTranArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFULTCTranArray[i].szName);
		fprintf(fp,"\'%s\' ",	m_PSFULTCTranArray[i].szOwner);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fRZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fXZ));
		fprintf(fp,"%d ",		m_PSFULTCTranArray[i].nWindConnectionCode);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fRGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fXGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fRGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFULTCTranArray[i].fXGT));
		fprintf(fp,"\n");
	}
}

// Table #, T1, F1, T2, F2, T3, F3, T4, F4, T5, F5, T6, F6
// T7, F7, T8, F8, T9, F9, T10, F10, T11, F11
void	CPSFAscii::ExportPSFImpedanceCorrectionTables(FILE* fp, const unsigned char bRTData)
{
	register int	i;
	for (i=0; i<(int)m_PSFImpedanceCorrectionTablesArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFImpedanceCorrectionTablesArray[i].nTableNumber);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT6));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF6));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT7));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF7));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT8));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF8));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT9));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF9));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT10));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF10));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fT11));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFImpedanceCorrectionTablesArray[i].fF11));
		fprintf(fp,"\n");
	}
}

// BUS1 number, BUS2 number, ID, Section #, X, Status, Meter end, AMP Rating, kV Rating, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Owner
void	CPSFAscii::ExportPSFFixedSeriesCompensator(FILE* fp, const unsigned char bRTData)
{
	register int	i;
	for (i=0; i<(int)m_PSFFixedSeriesCompensatorArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFFixedSeriesCompensatorArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSFFixedSeriesCompensatorArray[i].nBus2Number);
		fprintf(fp,"\'%s\' ",	m_PSFFixedSeriesCompensatorArray[i].szID);
		fprintf(fp,"%d ",		m_PSFFixedSeriesCompensatorArray[i].nSection);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fX));
		fprintf(fp,"%d ",		m_PSFFixedSeriesCompensatorArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_MeterEnd[m_PSFFixedSeriesCompensatorArray[i].nMeterEnd]);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fAMPRating));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fkVRating));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fZ1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fZ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fZ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fZ4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fZ5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFFixedSeriesCompensatorArray[i].fZ6));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFFixedSeriesCompensatorArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFFixedSeriesCompensatorArray[i].szOwner);
		fprintf(fp,"\n");
	}
}

// BUS1 #, BUS2 #, ID, Section #, Status, Meter end, X, X Max, X Min, Steps, Ctrl flag, Max MW, Min MW
// AMP rating, kV rating, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Owner
void	CPSFAscii::ExportPSFSwitchableSeriesCompensator(FILE* fp, const unsigned char bRTData)
{
	register int	i;
	for (i=0; i<(int)m_PSFSwitchableSeriesCompensatorArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFSwitchableSeriesCompensatorArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSFSwitchableSeriesCompensatorArray[i].nBus2Number);
		fprintf(fp,"\'%s\' ",	m_PSFSwitchableSeriesCompensatorArray[i].szID);
		fprintf(fp,"%d ",		m_PSFSwitchableSeriesCompensatorArray[i].nSection);
		fprintf(fp,"%d ",		m_PSFSwitchableSeriesCompensatorArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_MeterEnd[m_PSFSwitchableSeriesCompensatorArray[i].nMeterEnd]);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fXMax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fXMin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fSteps));
		fprintf(fp,"%d ",		m_PSFSwitchableSeriesCompensatorArray[i].nCtrlFlag);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fMaxMW));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fMinMW));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fAMPRating));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fkVRating));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fZ1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fZ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fZ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fZ4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fZ5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFSwitchableSeriesCompensatorArray[i].fZ6));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFSwitchableSeriesCompensatorArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFSwitchableSeriesCompensatorArray[i].szOwner);
		fprintf(fp,"\n");
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, R, X, G, B, Name
// GF, BF, GT, BT, TCRG, PSRG, TC psn, PS psn, TCR, Max TCR, Min TCR, PSR, Max PSR, Min PSR, Ctrl type
// Ctrl side, Ctrl flag, Max P, Min P, Max Q, Min Q, V Hi limit, V Lo limit, Ctrl Bus, Z Corr TC, Z Corr PS, MVA
// R1, R2, R3, R4, R5, R6, Rating group, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Name, Owner
// RZ, XZ, Code, RGF, XGF, RGT, XGT
void	CPSFAscii::ExportPSFStaticTapChangerPhaseRegulator(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFStaticTapChangerPhaseRegulatorArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus2Number);
		fprintf(fp,"\'%s\' ",	m_PSFStaticTapChangerPhaseRegulatorArray[i].szID);
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nSection);
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF_MeterEnd[m_PSFStaticTapChangerPhaseRegulatorArray[i].nMeterEnd]);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fB));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fBF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fBT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fTCRG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fPSRG));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fTCpsn));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fPSpsn));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fTCR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMaxTCR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMinTCR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fPSR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMaxPSR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMinPSR));
		fprintf(fp,"\'%c\' ",	g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType[m_PSFStaticTapChangerPhaseRegulatorArray[i].nCtrlType]);
		fprintf(fp,"\n");

		fprintf(fp,"\'%c\' ",	g_lpszPSF_CtrlSide[m_PSFStaticTapChangerPhaseRegulatorArray[i].nCtrlSide]);
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nCtrlFlag);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMaxP));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMinP));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMaxQ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMinQ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fVHiLimit));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fVLoLimit));
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nCtrlBus);
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nZCorrTC);
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nZCorrPS);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fMVA));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fR6));
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nRatingGroup);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fZ1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fZ2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fZ3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fZ4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fZ5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fZ6));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSFStaticTapChangerPhaseRegulatorArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSFStaticTapChangerPhaseRegulatorArray[i].szName);
		fprintf(fp,"\'%s\' ",	m_PSFStaticTapChangerPhaseRegulatorArray[i].szOwner);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fRZ));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fXZ));
		fprintf(fp,"%d ",		m_PSFStaticTapChangerPhaseRegulatorArray[i].nWindConnectionCode);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fRGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fXGF));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fRGT));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFStaticTapChangerPhaseRegulatorArray[i].fXGT));
		fprintf(fp,"\n");
	}
}

// BUS1 number, BUS2 number, BUS3 number, ID, Status, Non-metered end
// Ratio 1, Angle 1, Ratio 2, Angle 2, Ratio 3, Angle 3
// R1, X1, R2, X2, R3, X3, G1, B1, G2, B2, G3, B3
// Max R/A, Min R/A, Step, Ctrl side, Ctrl flag, Max ctrl, Min ctrl, Ctrl bus, Z Corr table (for the primary winding)
// Max R/A, Min R/A, Step, Ctrl side, Ctrl flag, Max ctrl, Min ctrl, Ctrl bus, Z Corr table (for the secondary winding)
// Max R/A, Min R/A, Step, Ctrl side, Ctrl flag, Max ctrl, Min ctrl, Ctrl bus, Z Corr table (for the tertiary winding)
// G1, B1, G2, B2, G3, B3, PR1, PR2, PR3, PR4, PR5, PR6, Rating group, MVA
// SR1, SR2, SR3, SR4, SR5, SR6, TR1, TR2, TR3, TR4, TR5, TR6
// Equipment name, Name, Owner
// PR0, PX0, SR0, SX0, TR0, TX0
// Code, PGR, PGX, SGR, SGX, TGR, TGX
void	CPSFAscii::ExportPSF3WindingTransformer(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSF3WindingTranArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nBus1Number);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nBus2Number);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nBus3Number);
		fprintf(fp,"\'%s\' ",	m_PSF3WindingTranArray[i].szID);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nStatus);
		fprintf(fp,"\'%c\' ",	g_lpszPSF3WindingTransformer_NonMeteredEnd[m_PSF3WindingTranArray[i].nNonMeteredEnd]);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fRatio1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fAngle1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fRatio2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fAngle2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fRatio3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fAngle3));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fX1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fX2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fX3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fG1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fB1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fG2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fB2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fG3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fB3));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPMaxRA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPMinRA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPStep));
		fprintf(fp,"\'%c\' ",	g_lpszPSF3WindingTransformer_CtrlSide[m_PSF3WindingTranArray[i].nPCtrlSide]);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nPCtrlFlag);
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPMaxCtrl));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPMinCtrl));
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nPCtrlBus);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nPZCorrTable);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSMaxRA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSMinRA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSStep));
		fprintf(fp,"\'%c\' ",	g_lpszPSF3WindingTransformer_CtrlSide[m_PSF3WindingTranArray[i].nSCtrlSide]);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nSCtrlFlag);
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSMaxCtrl));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSMinCtrl));
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nSCtrlBus);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nSZCorrTable);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTMaxRA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTMinRA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTStep));
		fprintf(fp,"\'%c\' ",	g_lpszPSF3WindingTransformer_CtrlSide[m_PSF3WindingTranArray[i].nTCtrlSide]);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nTCtrlFlag);
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTMaxCtrl));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTMinCtrl));
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nTCtrlBus);
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nTZCorrTable);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fG1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fB1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fG2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fB2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fG3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fB3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR6));
		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nRatingGroup);
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fMVA));
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR6));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR4));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR5));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR6));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	m_PSF3WindingTranArray[i].szEquipmentName);
		fprintf(fp,"\'%s\' ",	m_PSF3WindingTranArray[i].szName);
		fprintf(fp,"\'%s\' ",	m_PSF3WindingTranArray[i].szOwner);
		fprintf(fp,"\n");

		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPR0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPX0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSR0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSX0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTR0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTX0));
		fprintf(fp,"\n");

		fprintf(fp,"%d ",		m_PSF3WindingTranArray[i].nGroundingCode);
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPGR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fPGX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSGR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fSGX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTGR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSF3WindingTranArray[i].fTGX));
		fprintf(fp,"\n");
	}
}

//Number, Name, Desired flow, Tolerance, Slack bus, Description, Mode, Flag
void	CPSFAscii::ExportPSFAreaInterchange(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFAreaInterchangeArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFAreaInterchangeArray[i].nNumber);
		fprintf(fp,"\'%s\' ",	m_PSFAreaInterchangeArray[i].szName);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFAreaInterchangeArray[i].fDesiredFlow));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFAreaInterchangeArray[i].fTolerance));
		fprintf(fp,"%d ",		m_PSFAreaInterchangeArray[i].nSlackBus);
		fprintf(fp,"\'%s\' ",	m_PSFAreaInterchangeArray[i].szDescription);
		fprintf(fp,"%d ",		m_PSFAreaInterchangeArray[i].nMode);
		fprintf(fp,"%d ",		m_PSFAreaInterchangeArray[i].nFlag);
		fprintf(fp,"\n");
	}
}

//Code, Change, DCBus1, DCBus2, ACBus, ID, Grp, Zone, B#, Xc, VR, Tstep, Tmin, Tmax, Amin, Amax, Gmin, Imax
//Code, Change, DCBus1, DCBus2, ACBus, ID, Ctrl Mode, SP1, SP2, Type, MVA, Pmin, Pmax, Qmin, Qmax, BiasR, kV
void	CPSFAscii::ExportPSFLineCommutatedConverters(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFLCConvertersArray.size(); i++)
	{
		fprintf(fp,"\'%s\' ",	"BD");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFLCConvertersArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFLCConvertersArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFLCConvertersArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFLCConvertersArray[i].nACBus);
		fprintf(fp,"%d ",		m_PSFLCConvertersArray[i].nID);

		fprintf(fp,"\'%s\' ",	m_PSFLCConvertersArray[i].szGrp);
		fprintf(fp,"%d ",		m_PSFLCConvertersArray[i].nZone);
		fprintf(fp,"%d ",		m_PSFLCConvertersArray[i].nBridge);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fXc));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fVR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fTstep));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fTmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fTmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fAmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fAmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fGmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fImax));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	"BZ");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFLCConvertersArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFLCConvertersArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFLCConvertersArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFLCConvertersArray[i].nACBus);
		fprintf(fp,"%d ",		m_PSFLCConvertersArray[i].nID);

		fprintf(fp,"\'%s\' ",	m_PSFLCConvertersArray[i].szCtrlMode);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fSP1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fSP2));
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Type[m_PSFLCConvertersArray[i].nType]);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fMVA));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fPmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fPmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fQmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fQmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fBiasR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFLCConvertersArray[i].fkV));
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFDCLines(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFDCLinesArray.size(); i++)
	{
		fprintf(fp,"\'%s\' ",	"LD");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFDCLinesArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFDCLinesArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFDCLinesArray[i].szDCBus2);
		fprintf(fp,"\'%s\' ",	m_PSFDCLinesArray[i].szID);
		fprintf(fp,"\'%s\' ",	m_PSFDCLinesArray[i].szGrp);
		fprintf(fp,"%d ",		m_PSFDCLinesArray[i].nZone);
		fprintf(fp,"\'%s\' ",	m_PSFDCLinesArray[i].szOwner);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFDCLinesArray[i].fRdc));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFDCLinesArray[i].fLdc));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFDCLinesArray[i].fCdca));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFDCLinesArray[i].fCdcb));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFDCLinesArray[i].fImax));
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Mend[m_PSFDCLinesArray[i].nMend]);
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFDCBreakers(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFDCBreakersArray.size(); i++)
	{
		fprintf(fp,"\'%s\' ",	"LB");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFDCBreakersArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFDCBreakersArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFDCBreakersArray[i].szDCBus2);
		fprintf(fp,"\'%s\' ",	m_PSFDCBreakersArray[i].szID);
		fprintf(fp,"\'%s\' ",	m_PSFDCBreakersArray[i].szGrp);
		fprintf(fp,"%d ",		m_PSFDCBreakersArray[i].nZone);
		fprintf(fp,"\'%s\' ",	m_PSFDCBreakersArray[i].szOwner);
		fprintf(fp,"\'%s\' ",	g_lpszPSFMultiTerminalDC_Status[m_PSFDCBreakersArray[i].nStatus]);
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFDCBuses(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFDCBusesArray.size(); i++)
	{
		fprintf(fp,"\'%s\' ",	"DA");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFDCBusesArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFDCBusesArray[i].szDCBus);
		fprintf(fp,"%d ",		m_PSFDCBusesArray[i].nArea);
		fprintf(fp,"%d ",		m_PSFDCBusesArray[i].nZone);
		fprintf(fp,"\n");
	}
}

//Code, Change, DCBus1, DCBus2, ACBus1, ID, Grp, Zone, B#, Xt, VR, Step, Tmin, Tmax, Amin, Amax, Gmin, Gmax, Imax
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Mode, SP1, SP2, SP3, X1, Kc, Type, MVA, ACBus2, kV
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Vmin, Vmax, Vref (optional)
//Code, Change, DCBus1, DCBus2, ACBus1, ID, DCBus3, DCBus4, ACBus2, ID2, QA0, La, Lb, Lmin
//Code, Change, DCBus1, DCBus2, ACBus1, ID, PA0, VD0, ID0 (optional)
void	CPSFAscii::ExportPSFVoltageSourcedConverter(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFVSCArray.size(); i++)
	{
		fprintf(fp,"\'%s\' ",	"FD");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFVSCArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus1);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szID);

		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szGrp);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nZone);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nBridge);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fXt));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fVR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fStep));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fTmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fTmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fAmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fAmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fGmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fGmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fImax));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	"FZ");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFVSCArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus1);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szID);

		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szMode);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fSP1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fSP2));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fSP3));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fX1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fKc));
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nType);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fMVA));
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus2);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fkV));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	"FV");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFVSCArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus1);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szID);

		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fVmin));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fVmax));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fVref));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	"FR");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFVSCArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus1);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szID);

		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szDCBus3);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szDCBus4);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus2);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szID2);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fQA0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fLa));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fLb));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fLmin));
		fprintf(fp,"\n");

		fprintf(fp,"\'%s\' ",	"FC");
		fprintf(fp,"\'%c\' ",	g_lpszPSFMultiTerminalDC_Change[m_PSFVSCArray[i].nChange]);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus1);
		fprintf(fp,"\'%s\' ",	m_PSFVSCArray[i].szDCBus2);
		fprintf(fp,"%d ",		m_PSFVSCArray[i].nACBus1);
		fprintf(fp,"\'%s\'",	m_PSFVSCArray[i].szID);

		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fPA0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fVD0));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFVSCArray[i].fID0));
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFMultiTerminalDC(FILE* fp, const unsigned char bRTData)
{
	ExportPSFLineCommutatedConverters(fp, bRTData);
	ExportPSFDCLines(fp, bRTData);
	ExportPSFDCBreakers(fp, bRTData);
	ExportPSFDCBuses(fp, bRTData);
	ExportPSFVoltageSourcedConverter(fp, bRTData);
}

void	CPSFAscii::ExportPSFZone(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFZoneArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFZoneArray[i].nNumber);
		fprintf(fp,"\'%s\' ",	m_PSFZoneArray[i].szName);
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFNodeMapping(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFNodeMappingArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFNodeMappingArray[i].nBusNumber);
		fprintf(fp,"\'%s\' ",	m_PSFNodeMappingArray[i].szBusName);
		fprintf(fp,"\'%s\' ",	m_PSFNodeMappingArray[i].szNodeName);
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFZeroSequenceMutualCoupling(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFZeroSequenceMutualCouplingArray.size(); i++)
	{
		fprintf(fp,"%d ",		m_PSFZeroSequenceMutualCouplingArray[i].nBus1L1Number);
		fprintf(fp,"%d ",		m_PSFZeroSequenceMutualCouplingArray[i].nBus2L1Number);
		fprintf(fp,"\'%s\' ",	m_PSFZeroSequenceMutualCouplingArray[i].szIDL1);
		fprintf(fp,"%d ",		m_PSFZeroSequenceMutualCouplingArray[i].nBus1L2Number);
		fprintf(fp,"%d ",		m_PSFZeroSequenceMutualCouplingArray[i].nBus2L2Number);
		fprintf(fp,"\'%s\' ",	m_PSFZeroSequenceMutualCouplingArray[i].szIDL2);
		fprintf(fp,"%s ",		FormularFloatString(m_PSFZeroSequenceMutualCouplingArray[i].fR));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFZeroSequenceMutualCouplingArray[i].fX));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFZeroSequenceMutualCouplingArray[i].fCF1));
		fprintf(fp,"%s ",		FormularFloatString(m_PSFZeroSequenceMutualCouplingArray[i].fCF2));
		fprintf(fp,"\n");
	}
}

void	CPSFAscii::ExportPSFFileSection(FILE* fp, const unsigned char bRTData)
{
	register int	i;

	for (i=0; i<(int)m_PSFFileSectionArray.size(); i++)
	{
		fprintf(fp,"\'%s\' ",	m_PSFFileSectionArray[i].szFileIdentifier);
		fprintf(fp,"\'%s\' ",	m_PSFFileSectionArray[i].szFileName);
		fprintf(fp,"\n");
	}
}
