#include "StdAfx.h"
#include "PSFAscii.h"

int	CPSFAscii::GetTableIndex(const char* lpszTable)
{
	register int	i;
	for (i=0; i<sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable); i++)
	{
		if (stricmp(g_PSFModelTables[i].lpszModelName,lpszTable) == 0)
			return g_PSFModelTables[i].nModelIndex;
	}

	return -1;
}

int	CPSFAscii::GetFieldIndex(const char* lpszTable, const char* lpszField)
{
	register int	i;
	int		nTable;

	nTable=GetTableIndex(lpszTable);
	if (nTable >= 0)
	{
		for (i=0; i<g_PSFModelTables[nTable].nFieldNum; i++)
		{
			if (stricmp(g_PSFModelTables[nTable].pFieldArray[i].lpszName,lpszField) == 0)
				return i;
		}
	}

	return -1;
}

int	CPSFAscii::GetRecordNum(const char* lpszTable)
{
	int nTable=GetTableIndex(lpszTable);
	return GetRecordNum(nTable);
}

int	CPSFAscii::GetRecordNum(const int nTable)
{
	switch (nTable)
	{
	case	PSFModel_SolutionHistory:					return 1;													break;
	case	PSFModel_Substation:							return m_SubstationArray.size();							break;
	case	PSFModel_Bus:								return m_PSFBusArray.size();								break;
	case	PSFModel_Generator:							return m_PSFGeneratorArray.size();							break;
	case	PSFModel_Load:								return m_PSFLoadArray.size();								break;
	case	PSFModel_LoadModel:							return m_PSFLoadModelArray.size();							break;
	case	PSFModel_FixedShunt:						return m_PSFFixedShuntArray.size();						break;
	case	PSFModel_SwitchableShunt:					return m_PSFSwitchableShuntArray.size();					break;
	case	PSFModel_Line:								return m_PSFLineArray.size();								break;
	case	PSFModel_FixedTransformer:					return m_PSFFixedTranArray.size();					break;
	case	PSFModel_ULTCTransformer:					return m_PSFULTCTranArray.size();					break;
	case	PSFModel_ImpedanceCorrectionTables:			return m_PSFImpedanceCorrectionTablesArray.size();			break;
	case	PSFModel_FixedSeriesCompensator:			return m_PSFFixedSeriesCompensatorArray.size();			break;
	case	PSFModel_SwitchableSeriesCompensator:		return m_PSFSwitchableSeriesCompensatorArray.size();		break;
	case	PSFModel_StaticTapChangerPhaseRegulator:	return m_PSFStaticTapChangerPhaseRegulatorArray.size();	break;
	case	PSFModel_PSF3WindingTransformer:			return m_PSF3WindingTranArray.size();				break;
	case	PSFModel_AreaInterchange:					return m_PSFAreaInterchangeArray.size();					break;
	case	PSFModel_Interface:							return 0;													break;
	case	PSFModel_LineCommutatedConverters:				return m_PSFLCConvertersArray.size();				break;
	case	PSFModel_DCLines:								return m_PSFDCLinesArray.size();								break;
	case	PSFModel_DCBreakers:							return m_PSFDCBreakersArray.size();							break;
	case	PSFModel_DCBuses:								return m_PSFDCBusesArray.size();								break;
	case	PSFModel_VoltageSourcedConverter:				return m_PSFVSCArray.size();				break;
	case	PSFModel_Zone:								return m_PSFZoneArray.size();								break;
	case	PSFModel_NodeMapping:						return m_PSFNodeMappingArray.size();						break;
	case	PSFModel_ZeroSequenceMutualCoupling:		return m_PSFZeroSequenceMutualCouplingArray.size();		break;
	case	PSFModel_FileSection:						return m_PSFFileSectionArray.size();						break;
	}
	return 0;
}

int	CPSFAscii::GetRecordValue(const int nTable, const int nField, const int nRecord, char* lpszRetString)
{
	if (nTable < 0 || nTable >= sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable))
		return 0;
	if (nField < 0 || nField >= g_PSFModelTables[nTable].nFieldNum)
		return 0;
	strcpy(lpszRetString, GetPSFDataString(nTable, nField, nRecord).c_str());
	return 1;
}

int	CPSFAscii::GetRecordValue(const char* lpszTable, const char* lpszField, const int nRecord, char* lpszRetString)
{
	int	nTable=GetTableIndex(lpszTable);
	int	nField=GetFieldIndex(lpszTable, lpszField);

	strcpy(lpszRetString, GetPSFDataString(nTable, nField, nRecord).c_str());

	return 1;
}

int	CPSFAscii::GetRecordRowValue(const char* lpszTable, const int nRecord, std::vector<std::string>& strFieldArray)
{
	std::string	strValue;
	char	szValue[MDB_CHARLEN_LONG];
	int	nField,nTable=GetTableIndex(lpszTable);

	strFieldArray.resize(g_PSFModelTables[nTable].nFieldNum);
	for (nField=0; nField<g_PSFModelTables[nTable].nFieldNum; nField++)
		strFieldArray[nField].clear();

	for (nField=0; nField<g_PSFModelTables[nTable].nFieldNum; nField++)
	{
		GetRecordValue(nTable, nField, nRecord, szValue);
		strFieldArray[nField]=szValue;
	}
	return 1;
}

int	CPSFAscii::SetRecordValue(const char* lpszTable, const char* lpszField, const int nRecord, const char* lpszValue)
{
	unsigned char bCheckValidate=1;
	int	nTable=GetTableIndex(lpszTable);
	int	nField=GetFieldIndex(lpszTable, lpszField);

	switch (nTable)
	{
	case PSFModel_SolutionHistory:					SetPSFSolutionHistory(bCheckValidate, nField, nRecord, lpszValue);					break;
	case PSFModel_Bus:								SetPSFBus(bCheckValidate, nField, nRecord, lpszValue);								break;
	case PSFModel_Generator:						SetPSFGenerator(bCheckValidate, nField, nRecord, lpszValue);						break;
	case PSFModel_Load:								SetPSFLoad(bCheckValidate, nField, nRecord, lpszValue);								break;
	case PSFModel_LoadModel:						SetPSFLoadModel(bCheckValidate, nField, nRecord, lpszValue);						break;
	case PSFModel_FixedShunt:						SetPSFFixedShunt(bCheckValidate, nField, nRecord, lpszValue);						break;
	case PSFModel_SwitchableShunt:					SetPSFSwitchableShunt(bCheckValidate, nField, nRecord, lpszValue);					break;
	case PSFModel_Line:								SetPSFLine(bCheckValidate, nField, nRecord, lpszValue);								break;
	case PSFModel_FixedTransformer:					SetPSFFixedTransformer(bCheckValidate, nField, nRecord, lpszValue);					break;
	case PSFModel_ULTCTransformer:					SetPSFULTCTransformer(bCheckValidate, nField, nRecord, lpszValue);					break;
	case PSFModel_ImpedanceCorrectionTables:		SetPSFImpedanceCorrectionTables(bCheckValidate, nField, nRecord, lpszValue);		break;
	case PSFModel_FixedSeriesCompensator:			SetPSFFixedSeriesCompensator(bCheckValidate, nField, nRecord, lpszValue);			break;
	case PSFModel_SwitchableSeriesCompensator:		SetPSFSwitchableSeriesCompensator(bCheckValidate, nField, nRecord, lpszValue);		break;
	case PSFModel_StaticTapChangerPhaseRegulator:	SetPSFStaticTapChangerPhaseRegulator(bCheckValidate, nField, nRecord, lpszValue);	break;
	case PSFModel_PSF3WindingTransformer:			SetPSF3WindingTransformer(bCheckValidate, nField, nRecord, lpszValue);				break;
	case PSFModel_AreaInterchange:					SetPSFAreaInterchange(bCheckValidate, nField, nRecord, lpszValue);																											break;
	case PSFModel_Interface:																												break;
	case PSFModel_LineCommutatedConverters:				SetPSFLineCommutatedConverters(bCheckValidate, nField, nRecord, lpszValue);				break;
	case PSFModel_DCLines:								SetPSFDCLines(bCheckValidate, nField, nRecord, lpszValue);								break;
	case PSFModel_DCBreakers:							SetPSFDCBreakers(bCheckValidate, nField, nRecord, lpszValue);							break;
	case PSFModel_DCBuses:								SetPSFDCBuses(bCheckValidate, nField, nRecord, lpszValue);								break;
	case PSFModel_VoltageSourcedConverter:				SetPSFVoltageSourcedConverter(bCheckValidate, nField, nRecord, lpszValue);				break;
	case PSFModel_Zone:								SetPSFZone(bCheckValidate, nField, nRecord, lpszValue);								break;
	case PSFModel_NodeMapping:						SetPSFNodeMapping(bCheckValidate, nField, nRecord, lpszValue);						break;
	case PSFModel_ZeroSequenceMutualCoupling:		SetPSFZeroSequenceMutualCoupling(bCheckValidate, nField, nRecord, lpszValue)	;	break;
	case PSFModel_FileSection:						SetPSFFileSection(bCheckValidate, nField, nRecord, lpszValue);						break;
	case PSFModel_Substation:							SetPSFSubstation(bCheckValidate, nField, nRecord, lpszValue);							break;
	}

	return 1;
}
