#pragma once

#include "PSFAscii.h"

const	static	int		g_nDeviceSubColumn=1;
const	static	int		g_nDeviceVoltColumn=3;
const	static	int		g_nDeviceNameColumn=4;
static	char*	lpszLine[]=
{
	"���",
	"��վ",
	"�ճ�վ",
	"��ѹ�ȼ�",
	"�豸����",
};

const	static	int		g_nBoundLineNamePSFColumn=4;
const	static	int		g_nBoundDevNamePGColumn=8;
static	char*	lpszBoundLine[]=
{
	"���",
	"����������վ",
	"����������վ",
	"���ߵ�ѹ�ȼ�",
	"������·����",
	"�����豸����",
	"���ӳ�վ",
	"���ӵ�ѹ�ȼ�",
	"�����豸����",
};

static	char*	lpszBoundNetDevice[]=
{
	"���",
	"��վ",
	"�ճ�վ",
	"��ѹ�ȼ�",
	"����",
};

static	char*	lpszPGDeviceType[]=
{
	"ĸ��",
	"������·��",
	"��ѹ������",
	"�����",
	"����",
	"����",
	"��·��",
	"���뿪��",
	"�ӵص�բ",
};

static	char*	lpszPSFDeviceType[]=
{
	"ĸ��",
	"������·��",
	"��ѹ������",
	"�����",
	"����",
	"����",
};

typedef	struct _BoundLineDefinition 
{
	char	szPSFBoundSub[MDB_CHARLEN];
	char	szPSFBoundLine[MDB_CHARLEN];
	int		nPGBoundDevType;
	char	szPGBoundDevSub[MDB_CHARLEN];
	char	szPGBoundDevVolt[MDB_CHARLEN];
	char	szPGBoundDevName[MDB_CHARLEN];
	int		nPSFBoundBus;
	int		nPGBoundBus;
}	tagPG2PSFBoundLine;

typedef	struct _PGBoundNetDevDefinition 
{
	char	szSub[MDB_CHARLEN];
	char	szVolt[MDB_CHARLEN_TINY];
	char	szName[MDB_CHARLEN];
	int		nPGIndex;
}	tagPGBoundNetDevice;

typedef	struct _PSFBoundNetDevDefinition 
{
	char	szSub[MDB_CHARLEN];
	float	fkV;
	char	szName[MDB_CHARLEN];
	int		nPSFIndex;
}	tagPSFBoundNetDevice;

typedef	struct _PGShortName
{
	int			nTable;
	std::string	strName;
	std::string	strShortName;
}	tagPGShortName;

class CPG2PSFAscii
{
public:
	CPG2PSFAscii(void);
	~CPG2PSFAscii(void);

	void	FormPSFBoundNet(CPSFAscii* pPSFAscii);
	void	FormPGBoundNet(tagPGBlock* pBlock);
	void	FormPGBoundPSF(tagPGBlock* pBlock, CPSFAscii* pPSFAscii, const char* lpszCorp, std::vector<std::string>& strWorkZoneArray);
	void	PG2PSFAscii(tagPGBlock* pBlock, CPSFAscii* pPSFAscii, const double fZIL, const char* lpszPowerNetName, const char* lpszPSFAsciiFileName, std::vector<std::string>& strWorkZoneArray);

	void	LoadBoundLine(const char* lpszFileName);
	void	SaveBoundLine(const char* lpszFileName);
	void	LoadSubstationShortName(tagPGBlock* pBlock, const char* lpszFileName);
	void	SaveSubstationShortName(const char* lpszFileName);

public:
	std::vector<tagPSFBoundNetDevice>	m_PSFBoundNetBusArray;
	std::vector<tagPSFBoundNetDevice>	m_PSFBoundNetLineArray;
	std::vector<tagPSFBoundNetDevice>	m_PSFBoundNetTranArray;
	std::vector<tagPSFBoundNetDevice>	m_PSFBoundNetGenArray;
	std::vector<tagPSFBoundNetDevice>	m_PSFBoundNetLoadArray;
	std::vector<tagPSFBoundNetDevice>	m_PSFBoundNetCapArray;

	std::vector<tagPGBoundNetDevice>	m_PGBoundNetBusArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetLineArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetTranArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetGenArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetLoadArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetCapArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetBreakerArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetDisconnectorArray;
	std::vector<tagPGBoundNetDevice>	m_PGBoundNetGroundDisconnectorArray;

	std::vector<tagPSFAreaInterchange>	m_PG2PSFAreaArray;
	std::vector<tagPSFZone>				m_PG2PSFZoneArray;
	std::vector<tagPSFBus>				m_PG2PSFBusArray;
	std::vector<tagPSFGenerator>		m_PG2PSFGenArray;
	std::vector<tagPSFLoad>				m_PG2PSFLoadArray;
	std::vector<tagPSFFixedShunt>		m_PG2PSFCapArray;
	std::vector<tagPSFLine>				m_PG2PSFLineArray;
	std::vector<tagPSFFixedTransformer>	m_PG2PSFTranArray;

	std::vector<tagPG2PSFBoundLine>		m_PG2PSFBoundArray;
	std::vector<tagPGShortName>			m_PGShortNameArray;

private:
	void	sortBoundNetBus(int nDn0, int nUp0);
	void	sortBoundNetLine(int nDn0, int nUp0);
	void	sortBoundNetTran(int nDn0, int nUp0);
	void	sortBoundNetGen(int nDn0, int nUp0);
	void	sortBoundNetLoad(int nDn0, int nUp0);
	void	sortBoundNetCap(int nDn0, int nUp0);
	void	sortBoundNetBreaker(int nDn0, int nUp0);
	void	sortBoundNetDisconnector(int nDn0, int nUp0);
	void	sortBoundNetGroundDisconnector(int nDn0, int nUp0);

	void	ResolveBoundPG2PSFBus(tagPGBlock* pBlock, CPSFAscii* pPSFAscii);
	int		ResolvePSFBoundTopoBus(const int nBusDeviate, const int nPGBus);
	void	ReplaceSubString(char* lpszWorkString, const char* lpszReplaceString);

	int		ResolvePG2PSFOfflineName(CPSFAscii* pPSFAscii, const int nPSFModel, const char* lpszPGGenerator, char* lpszPSFGeneratorName);
	int		ResolvePG2PSFAreaNumber(CPSFAscii* pPSFAscii, const char* lpszArea);
	int		ResolvePG2PSFZoneNumber(CPSFAscii* pPSFAscii, const char* lpszZone);
	std::string	ResolvePGShortSubName(const char* lpszPGSubstation);
	std::string	ResolvePSFBusName(tagPGBlock* pBlock, const char* lpszPGSub, const char* lpszPGVolt, const char* lpszPGDev, const int nPGTopoBus);

	void	ErasePSFBoundNet(CPSFAscii* pPSFAscii);
	void	AppendPGBoundNet(CPSFAscii* pPSFAscii, const double fZIL);

public:
	std::string	GetPG2PSFDataString(const int nTable, const int nField, const int nRecord);
};
