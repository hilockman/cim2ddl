#pragma once
#include <vector>
using namespace std;

#include "../../MemDB/PGMemDB/PGMemDB.h"
using	namespace	PGMemDB;

#include "PSFAsciiDefine.h"

const	int		g_nPSFSolutionHistoryLines					=6;
const	int		g_nPSFBusLines								=2;
const	int		g_nPSFGeneratorLines						=4;
const	int		g_nLoadDataLines							=4;
const	int		g_nLoadModelDataLines						=1;
const	int		g_nFixedShuntDataLines						=3;
const	int		g_nSwitchableShuntDataLines					=3;
const	int		g_nLineDataLines							=4;
const	int		g_nFixedTransformerDataLines				=5;
const	int		g_nULTCTransformerDataLines					=6;
const	int		g_nImpedanceCorrectionTablesDataLines		=2;
const	int		g_nFixedSeriesCompensatorDataLines			=2;
const	int		g_nSwitchableSeriesCompensatorDataLines		=3;
const	int		g_nStaticTapChangerPhaseRegulatorDataLines	=6;
const	int		g_n3WindingTransformerDataLines				=11;
const	int		g_nAreaInterchangeDataLines					=1;
const	int		g_nLineCommutatedConvertersLines			=2;
const	int		g_nDCLines									=1;
const	int		g_nDCBreakers								=1;
const	int		g_nDCBuses									=1;
const	int		g_nVoltageSourcedConverter					=5;
const	int		g_nZoneDataLines							=1;
const	int		g_nNodeMappingDataLines						=1;
const	int		g_nZeroSequenceMutualCouplingDataLines		=1;
const	int		g_nFileSectionDataLines						=1;

class CPSFAscii
{
public:
	CPSFAscii(void);
	~CPSFAscii(void);

public:
	tagPSFSolutionHistory								m_PSFSolution;
	std::vector<tagPSFBus>								m_PSFBusArray;
	std::vector<tagPSFGenerator>						m_PSFGeneratorArray;
	std::vector<tagPSFLoad>								m_PSFLoadArray;
	std::vector<tagPSFLoadModel>						m_PSFLoadModelArray;
	std::vector<tagPSFFixedShunt>						m_PSFFixedShuntArray;
	std::vector<tagPSFSwitchableShunt>					m_PSFSwitchableShuntArray;
	std::vector<tagPSFLine>								m_PSFLineArray;
	std::vector<tagPSFFixedTransformer>					m_PSFFixedTranArray;
	std::vector<tagPSFULTCTransformer>					m_PSFULTCTranArray;
	std::vector<tagPSFImpedanceCorrectionTables>		m_PSFImpedanceCorrectionTablesArray;
	std::vector<tagPSFFixedSeriesCompensator>			m_PSFFixedSeriesCompensatorArray;
	std::vector<tagPSFSwitchableSeriesCompensator>		m_PSFSwitchableSeriesCompensatorArray;
	std::vector<tagPSFStaticTapChangerPhaseRegulator>	m_PSFStaticTapChangerPhaseRegulatorArray;
	std::vector<tagPSF3WindingTransformer>				m_PSF3WindingTranArray;
	std::vector<tagPSFAreaInterchange>					m_PSFAreaInterchangeArray;

	std::vector<tagPSFLineCommutatedConverters>			m_PSFLCConvertersArray;
	std::vector<tagPSFDCLines>							m_PSFDCLinesArray;
	std::vector<tagPSFDCBreakers>						m_PSFDCBreakersArray;
	std::vector<tagPSFDCBuses>							m_PSFDCBusesArray;
	std::vector<tagPSFVoltageSourcedConverter>			m_PSFVSCArray;

	std::vector<tagPSFZone>								m_PSFZoneArray;
	std::vector<tagPSFNodeMapping>						m_PSFNodeMappingArray;
	std::vector<tagPSFZeroSequenceMutualCoupling>		m_PSFZeroSequenceMutualCouplingArray;
	std::vector<tagPSFFileSection>						m_PSFFileSectionArray;

	std::vector<tagPSFSubstation>						m_SubstationArray;

	std::vector<tagPSFBusNobn>							m_BusNobnArray;
	std::vector<tagPG2PSFMatch>							m_PG2PSFMatchArray;

public:
	int		ImportPSFFile(const char* lpszFileName, const double fZIL, const unsigned char bCheckValidate=0);
	void	PSFAsciiMaint(const double fZIL);
	int		ExportPSFFile(const char* lpszFileName, const unsigned char bRTData=0);
	int		PGMemDB2PSFAscii(tagPGBlock* pBlock, const unsigned char bSetPlantLoad, const char* lpszMatchFileName, std::vector<std::string> strFilterZoneArray);
	int		FindPSFData(const int nTable, const int nField, const int nStartRecord, const char* lpszKeyValue);

	//	����ģ�����뵽PSFģ��
private:
	void	PGMemDBGeneratorYC2PSFAscii(tagPGBlock* pPGBlock, const std::vector<std::string> strFilterZoneArray);
	void	PGMemDBFixedTransformer2PSFAscii(tagPGBlock* pPGBlock, const std::vector<std::string> strFilterZoneArray);
	void	PGMemDBLine2PSFAscii(tagPGBlock* pPGBlock, const std::vector<std::string> strFilterZoneArray);
	void	PSFAsciiTransformer2Load(const unsigned char bPlantNoLoad=0);
	int		IsBusJointGenerator(const int nStartBus);
	void	SetLoadPValue(const int nTranBus, const unsigned char bLineRevise, const float fTranValue);
	void	SetLoadQValue(const int nTranBus, const unsigned char bLineRevise, const float fTranValue);
	void	ResolvePSFAsciiBusGenLoadStatus(std::vector<std::string> strFilterZoneArray);

	//	Misc Block
public:
	int		GetPSFModelRecordNum(const int nTable);
	void	GetPSFDataStringArray(const int nTable, const int nRecord, std::vector<std::string>& strStringArray);
	std::string	GetPSFDataString(const int nTable, const int nField, const int nRecord);
	int		GetPSFDataInteger(const int nTable, const int nField, const int nRecord);
	double	GetPSFDataDouble(const int nTable, const int nField, const int nRecord);
	void	GetZoneFilterIndexArray(const int nTable, const std::vector<std::string> strFilterZoneArray, std::vector<int>& nFilterIndexArray);
	void	GetZoneFilterIndexArray(const char* lpszTable, const std::vector<std::string> strFilterZoneArray, std::vector<int>& nFilterIndexArray);

private:
	void	ArrayInitialize();
	void	CompleteField();

private:
	void	ParseLineString(const char* lpszLine, std::vector<std::string>& strEleArray);
	int		GetEnumValue(const char* lpszEnumName, int nEnumNum, const char* lpszEnumArray[]);
	int		GetEnumValue(const char* lpszEnumName, int nEnumNum, const char cEnumArray[]);

	int isDigitalString(const char* lpszString);
	float str2Float(const unsigned char bCheckValidate, const int nTable, const int nField, const char* lpszString);
	int str2Integer(const unsigned char bCheckValidate, const int nTable, const int nField, const char* lpszString);

	void	ImportPSFSolutionHistory				(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFBus							(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFGenerator						(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFLoad							(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFLoadModel						(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFFixedShunt						(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFSwitchableShunt				(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFLine							(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFFixedTransformer				(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFULTCTransformer				(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFImpedanceCorrectionTables		(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFFixedSeriesCompensator			(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFSwitchableSeriesCompensator	(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFStaticTapChangerPhaseRegulator	(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSF3WindingTransformer			(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFAreaInterchange				(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFMultiTerminalDC				(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFZone							(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFNodeMapping					(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFZeroSequenceMutualCoupling		(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);
	void	ImportPSFFileSection					(const unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray);

	void	ExportPSFSolutionHistory				(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFBus							(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFGenerator						(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFLoad							(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFLoadModel						(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFFixedShunt						(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFSwitchableShunt				(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFLine							(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFFixedTransformer				(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFULTCTransformer				(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFImpedanceCorrectionTables		(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFFixedSeriesCompensator			(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFSwitchableSeriesCompensator	(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFStaticTapChangerPhaseRegulator	(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSF3WindingTransformer			(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFAreaInterchange				(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFMultiTerminalDC				(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFZone							(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFNodeMapping					(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFZeroSequenceMutualCoupling		(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFFileSection					(FILE* fp, const unsigned char bRTData=0);

	void	ExportPSFLineCommutatedConverters	(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFDCLines					(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFDCBreakers					(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFDCBuses					(FILE* fp, const unsigned char bRTData=0);
	void	ExportPSFVoltageSourcedConverter	(FILE* fp, const unsigned char bRTData=0);

private:
	void	ParsePSFLineCommutatedConverters	(const unsigned char bCheckValidate, const char* lpszCode, std::vector<std::string>& strEleArray);
	void	ParsePSFDCLines						(const unsigned char bCheckValidate, std::vector<std::string>& strEleArray);
	void	ParsePSFDCBreakers					(const unsigned char bCheckValidate, std::vector<std::string>& strEleArray);
	void	ParsePSFDCBuses						(const unsigned char bCheckValidate, std::vector<std::string>& strEleArray);
	void	ParsePSFVoltageSourcedConverter		(const unsigned char bCheckValidate, const char* lpszCode, std::vector<std::string>& strEleArray);
	void	ParsePSFSubstation					();

private:
	void	SetPSFSolutionHistory					(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFBus								(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFGenerator							(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFLoad								(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFLoadModel							(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFFixedShunt						(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFSwitchableShunt					(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFLine								(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFFixedTransformer					(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFULTCTransformer					(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFImpedanceCorrectionTables			(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFFixedSeriesCompensator			(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFSwitchableSeriesCompensator		(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFStaticTapChangerPhaseRegulator	(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSF3WindingTransformer				(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFAreaInterchange					(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFZone								(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFNodeMapping						(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFZeroSequenceMutualCoupling		(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFFileSection						(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFLineCommutatedConverters			(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFDCLines							(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFDCBreakers						(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFDCBuses							(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFVoltageSourcedConverter			(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);
	void	SetPSFSubstation						(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue);

private:
	void	sortBusDataByBusNumber(int nDn0, int nUp0);
	int		findBusDataByBusNumber(int nLeft, int nRight, const int nBusNumber);
	void	sortSubstationByName(int nDn0, int nUp0);
	int		findSubstationByName(int nLeft, int nRight, const char* lpszSubstation);
	void	GetSubstationString(std::vector<int>& nBusArray, tagPSFSubstation& subBuffer);
	void	FormSubstation(const double fZIL);

public:
	void	TraverseVolt(const int nStartBus, const double fZIL, const int bCheckRTStatus, std::vector<int>& nBusArray);
	void	TraverseSub(const int nStartBus, const double fZIL, const int bCheckRTStatus, std::vector<int>& nBusArray);
	void	TraverseNet(const int nStartBus, const int bCheckRTStatus, std::vector<int>& nBusArray);

private:
	char*	FormularFloatString(float fValue)	const;
	void	TrimEnd(char* lpszTrim);
	void	Trim(const char* lpszTrim, char* lpszRet);
	void	ClearLog();
	void	Log(const char* lpszFormat, ...);
// 
// 	//	Match
public:
	void	ReadPSFAscii2CimMatch(const char* lpszFileName);
	void	SavePSFAscii2CimMatch(const char* lpszFileName);
	void	AutoPSFAscii2CimMatch(tagPGBlock* pPGBlock, const int bMatchAll);
	void	AutoPSFAscii2CimMatch(tagPGBlock* pPGBlock, const int bMatchAll, std::vector<std::string> strFilterZoneArray);
	int		IsCimDeviceMatched(const int nPSFAsciiTable, const char* lpszPGDev);
private:
	void	CheckPGBusLineMatched(tagPGBlock* pPGBlock);
	void	CheckOffline2RTMatch(tagPGBlock* pPGBlock);

public:
	int		IsBusInZone(const int nBusNumber, const char* lpszZone);
	int		IsBusInZone(const char* lpszBusName, const char* lpszZone);

	void	GetTieLine(std::vector<std::string>& strInAreaArray, std::vector<int>& nTLineArray);
	void	GetTieLine(std::vector<std::string>& strInAreaArray, std::vector<int>& nTLineArray, std::vector<int>& nBoundBusArray);

// public:
// 	std::vector<tagPG2PSFMatch>	m_PG2PSFMatchArray;

	//	JNI��Ӧ��
private:
	int	GetTableIndex(const char* lpszTable);
	int	GetFieldIndex(const char* lpszTable, const char* lpszField);
	int	GetRecordValue(const int nTable, const int nField, const int nRecord, char* lpszRetString);

public:
	int	GetRecordNum(const char* lpszTable);
	int	GetRecordNum(const int nTable);

	int	GetRecordValue(const char* lpszTable, const char* lpszField, const int nRecord, char* lpszRetString);
	int SetRecordValue(const char* lpszTable, const char* lpszField, const int nRecord, const char* lpszValue);
	int	GetRecordRowValue(const char* lpszTable, const int nRecord, std::vector<std::string>& strFieldArray);
};