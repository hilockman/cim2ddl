#include "stdafx.h"
#include "../../MemDB/PGMemDB/PGMemDB.h"
using	namespace	PGMemDB;
#include "PSFAscii.h"

#include <vector>
#include <stack>
using namespace	std;

extern	CPSFAscii	g_PSFAscii;
extern	void		Log(const char* lpszFormat, ...);

BOOL	PSFAsciiUtility(tagPGBlock* pPGBlock, int nArg, int argc, char** argv)
{
	char	szEntry[100];
	clock_t	dBeg,dEnd;
	int		nDur;

	std::vector<std::string>	strFilterZoneArray;
	strFilterZoneArray.clear();

	if (argc > nArg)	{	strcpy(szEntry,argv[nArg++]);		Log("Entry=%s\n",szEntry);		}	else	return FALSE;

	dBeg=clock();
	if (STRICMP(szEntry,"AutoMatch") == 0)
	{
		g_PSFAscii.AutoPSFAscii2CimMatch(pPGBlock, 1, strFilterZoneArray);
	}
	else if (STRICMP(szEntry,"MatchFile") == 0)
	{
		unsigned char	bReadWrite;
		char	szMatchFileName[260];

		if (argc > nArg)	{	bReadWrite=atoi(argv[nArg++]);			}	else	return FALSE;
		if (argc > nArg)	{	strcpy(szMatchFileName,argv[nArg++]);	}	else	return FALSE;

		if (bReadWrite == 0)
			g_PSFAscii.ReadPSFAscii2CimMatch(szMatchFileName);
		else
			g_PSFAscii.SavePSFAscii2CimMatch(szMatchFileName);
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	printf("��ϣ���ʱ%d����\n",nDur);

	return TRUE;
}
