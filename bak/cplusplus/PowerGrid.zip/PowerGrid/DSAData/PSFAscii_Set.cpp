#include "StdAfx.h"
#include "PSFAscii.h"

void	CPSFAscii::SetPSFSolutionHistory(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_SolutionHistory;
	switch (nField)
	{
	case	PSFSolutionHistory_Date:			strcpy(m_PSFSolution.szDate, lpszValue);											break;
	case	PSFSolutionHistory_Time:			strcpy(m_PSFSolution.szTime, lpszValue);											break;
	case	PSFSolutionHistory_BaseMVA:			m_PSFSolution.fBaseMVA	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_Method:			strcpy(m_PSFSolution.szMethod, lpszValue);											break;
	case	PSFSolutionHistory_ITER:			m_PSFSolution.nITER	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_SOLTOL:			m_PSFSolution.fSOLTOL	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_BLUP:			m_PSFSolution.fBLUP	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_ACCFCT:			m_PSFSolution.fACCFCT	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_ZIL:				m_PSFSolution.fZIL		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_VTOL:			m_PSFSolution.fVTOL	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_CONADJ:			m_PSFSolution.fCONADJ	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSolutionHistory_STOPT:			strcpy(m_PSFSolution.szSTOPT, lpszValue);																					break;
	case	PSFSolutionHistory_Flag1:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag2:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag3:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag4:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag5:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag6:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag7:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag8:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag9:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag10:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag11:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag12:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag13:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag14:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag15:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag16:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Flag17:			GetEnumValue(lpszValue, sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);		break;
	case	PSFSolutionHistory_Description1:	strcpy(m_PSFSolution.szDescription1, lpszValue);																			break;
	case	PSFSolutionHistory_Description2:	strcpy(m_PSFSolution.szDescription2, lpszValue);																			break;
	case	PSFSolutionHistory_Description3:	strcpy(m_PSFSolution.szDescription3, lpszValue);																			break;
	}
}

void	CPSFAscii::SetPSFBus(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_Bus;
	switch (nField)
	{
	case	PSFBus_Number:			m_PSFBusArray[nRecord].nNumber		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Name:			strcpy(m_PSFBusArray[nRecord].szName,			lpszValue);										break;
	case	PSFBus_Voltage:			m_PSFBusArray[nRecord].fVoltage	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Angle:			m_PSFBusArray[nRecord].fAngle		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_kV:				m_PSFBusArray[nRecord].fkV			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Type:			m_PSFBusArray[nRecord].nType		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Status:			m_PSFBusArray[nRecord].nStatus		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Area:			m_PSFBusArray[nRecord].nArea		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Zone:			m_PSFBusArray[nRecord].nZone		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_D1:				m_PSFBusArray[nRecord].nD1			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_D2:				m_PSFBusArray[nRecord].nD2			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_D3:				m_PSFBusArray[nRecord].nD3			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_D4:				m_PSFBusArray[nRecord].nD4			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_D5:				m_PSFBusArray[nRecord].nD5			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Owner:			strcpy(m_PSFBusArray[nRecord].szOwner,			lpszValue);										break;
	case	PSFBus_EquipmentName:	strcpy(m_PSFBusArray[nRecord].szEquipmentName,	lpszValue);										break;
	case	PSFBus_Latitude:		m_PSFBusArray[nRecord].fLatitude	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Longitude:		m_PSFBusArray[nRecord].fLongitude	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFBus_Substation:		strcpy(m_PSFBusArray[nRecord].szSubstation,lpszValue);											break;
	case	PSFBusEx_RTStatus:		m_PSFBusArray[nRecord].nRTStatus	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFGenerator(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_Generator;
	switch (nField)
	{
	case	PSFGenerator_BusNumber:					m_PSFGeneratorArray[nRecord].nBusNumber				=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_ID:						strcpy(m_PSFGeneratorArray[nRecord].szID,				lpszValue);													break;
	case	PSFGenerator_Status:					m_PSFGeneratorArray[nRecord].nStatus					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_MW:						m_PSFGeneratorArray[nRecord].fMW						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_MVAR:						m_PSFGeneratorArray[nRecord].fMVar						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_QMAX:						m_PSFGeneratorArray[nRecord].fQMax						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_QMIN:						m_PSFGeneratorArray[nRecord].fQMin						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_VHiLimit:					m_PSFGeneratorArray[nRecord].fVHiLimit					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_VLoLimit:					m_PSFGeneratorArray[nRecord].fVLoLimit					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RemoteBus:					m_PSFGeneratorArray[nRecord].nRemoteBus				=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RemoteBusV:				m_PSFGeneratorArray[nRecord].fRemoteBusV				=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_QContributionPercentCtrl:	m_PSFGeneratorArray[nRecord].fQContributionPercentCtrl	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_USCHQ:						m_PSFGeneratorArray[nRecord].nUSCHQ					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_MVA:						m_PSFGeneratorArray[nRecord].fMva						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_PMAX:						m_PSFGeneratorArray[nRecord].fPMax						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_PMIN:						m_PSFGeneratorArray[nRecord].fPMin						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RS:						m_PSFGeneratorArray[nRecord].fRS						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_XS:						m_PSFGeneratorArray[nRecord].fXS						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RT:						m_PSFGeneratorArray[nRecord].fRT						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_XT:						m_PSFGeneratorArray[nRecord].fXT						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_TAP:						m_PSFGeneratorArray[nRecord].fTAP						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_EquipmentName:				strcpy(m_PSFGeneratorArray[nRecord].szEquipmentName,	lpszValue);													break;
	case	PSFGenerator_Owner:						strcpy(m_PSFGeneratorArray[nRecord].szOwner,			lpszValue);													break;
	case	PSFGenerator_GWMOD:						m_PSFGeneratorArray[nRecord].nGWMOD					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_GWPF:						m_PSFGeneratorArray[nRecord].fGWPF						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_GBASLD:					m_PSFGeneratorArray[nRecord].nGBASLD					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RP:						m_PSFGeneratorArray[nRecord].fRP						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_XP:						m_PSFGeneratorArray[nRecord].fXP						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RN:						m_PSFGeneratorArray[nRecord].fRN						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_XN:						m_PSFGeneratorArray[nRecord].fXN						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RZ:						m_PSFGeneratorArray[nRecord].fRZ						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_XZ:						m_PSFGeneratorArray[nRecord].fXZ						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_RG:						m_PSFGeneratorArray[nRecord].fRG						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGenerator_XG:						m_PSFGeneratorArray[nRecord].fXG						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGeneratorEx_RTName:					strcpy(m_PSFGeneratorArray[nRecord].szRTName,			lpszValue);													break;
	case	PSFGeneratorEx_RTMW:					m_PSFGeneratorArray[nRecord].fRTMW						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFGeneratorEx_RTMVar:					m_PSFGeneratorArray[nRecord].fRTMVar					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFLoad(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_Load;
	switch (nField)
	{
	case	PSFLoad_BusNumber:		m_PSFLoadArray[nRecord].nBusNumber	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_RefP:			m_PSFLoadArray[nRecord].fRefP		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_RefQ:			m_PSFLoadArray[nRecord].fRefQ		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_P1:				m_PSFLoadArray[nRecord].fP1		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Q1:				m_PSFLoadArray[nRecord].fQ1		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_P2:				m_PSFLoadArray[nRecord].fP2		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Q2:				m_PSFLoadArray[nRecord].fQ2		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_P3:				m_PSFLoadArray[nRecord].fP3		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Q3:				m_PSFLoadArray[nRecord].fQ3		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_P4:				m_PSFLoadArray[nRecord].fP4		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Q4:				m_PSFLoadArray[nRecord].fQ4		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_P5:				m_PSFLoadArray[nRecord].fP5		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Q5:				m_PSFLoadArray[nRecord].fQ5		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_M1:				m_PSFLoadArray[nRecord].nM1		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_M2:				m_PSFLoadArray[nRecord].nM2		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_M3:				m_PSFLoadArray[nRecord].nM3		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_M4:				m_PSFLoadArray[nRecord].nM4		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_M5:				m_PSFLoadArray[nRecord].nM5		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Type:			m_PSFLoadArray[nRecord].nType		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Owner:			strcpy(m_PSFLoadArray[nRecord].szOwner,	lpszValue);											break;
	case	PSFLoad_ID:				strcpy(m_PSFLoadArray[nRecord].szID,		lpszValue);											break;
	case	PSFLoad_Scalable:		m_PSFLoadArray[nRecord].nScalable	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_EquipmentName:	strcpy(m_PSFLoadArray[nRecord].szEquipmentName,lpszValue);										break;
	case	PSFLoad_Area:			m_PSFLoadArray[nRecord].nArea		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Zone:			m_PSFLoadArray[nRecord].nZone		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_Status:			m_PSFLoadArray[nRecord].nStatus	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_GN:				m_PSFLoadArray[nRecord].fGN		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_BN:				m_PSFLoadArray[nRecord].fBN		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_GZ:				m_PSFLoadArray[nRecord].fGZ		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoad_BZ:				m_PSFLoadArray[nRecord].fBZ		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadEx_RTName:		strcpy(m_PSFLoadArray[nRecord].szRTName,	lpszValue);											break;
	case	PSFLoadEx_RTP:			m_PSFLoadArray[nRecord].fRTP		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadEx_RTQ:			m_PSFLoadArray[nRecord].fRTQ		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFLoadModel(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_LoadModel;
	switch (nField)
	{
	case	PSFLoadModel_ModelNumber:	m_PSFLoadModelArray[nRecord].nModelNumber	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_A1:			m_PSFLoadModelArray[nRecord].fA1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_A2:			m_PSFLoadModelArray[nRecord].fA2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_A3:			m_PSFLoadModelArray[nRecord].fA3			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_N1:			m_PSFLoadModelArray[nRecord].fN1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_N2:			m_PSFLoadModelArray[nRecord].fN2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_N3:			m_PSFLoadModelArray[nRecord].fN3			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_B1:			m_PSFLoadModelArray[nRecord].fB1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_B2:			m_PSFLoadModelArray[nRecord].fB2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_B3:			m_PSFLoadModelArray[nRecord].fB3			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_M1:			m_PSFLoadModelArray[nRecord].fM1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_M2:			m_PSFLoadModelArray[nRecord].fM2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLoadModel_M3:			m_PSFLoadModelArray[nRecord].fM3			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFFixedShunt(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_FixedShunt;
	switch (nField)
	{
	case	PSFFixedShunt_BusNumber:		m_PSFFixedShuntArray[nRecord].nBusNumber	=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_G:				m_PSFFixedShuntArray[nRecord].fG			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_B:				m_PSFFixedShuntArray[nRecord].fB			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_Type:				m_PSFFixedShuntArray[nRecord].nType		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_Owner:			strcpy(m_PSFFixedShuntArray[nRecord].szOwner,lpszValue);												break;
	case	PSFFixedShunt_ID:				strcpy(m_PSFFixedShuntArray[nRecord].szID,lpszValue);													break;
	case	PSFFixedShunt_EquipmentName:	strcpy(m_PSFFixedShuntArray[nRecord].szEquipmentName,lpszValue);										break;
	case	PSFFixedShunt_Status:			m_PSFFixedShuntArray[nRecord].nStatus		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_GN:				m_PSFFixedShuntArray[nRecord].fGN			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_BN:				m_PSFFixedShuntArray[nRecord].fBN			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_GZ:				m_PSFFixedShuntArray[nRecord].fGZ			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShunt_BZ:				m_PSFFixedShuntArray[nRecord].fBZ			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedShuntEx_RTName:			strcpy(m_PSFFixedShuntArray[nRecord].szRTName,lpszValue);												break;
	}
}

void	CPSFAscii::SetPSFSwitchableShunt(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_SwitchableShunt;
	switch (nField)
	{
	case	PSFSwitchableShunt_BusNumber:					m_PSFSwitchableShuntArray[nRecord].nBusNumber					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_Mode:						m_PSFSwitchableShuntArray[nRecord].nMode						=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_Status:						m_PSFSwitchableShuntArray[nRecord].nStatus						=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_VHiLimit:					m_PSFSwitchableShuntArray[nRecord].fVHiLimit					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_VLoLimit:					m_PSFSwitchableShuntArray[nRecord].fVLoLimit					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_RemoteBus:					m_PSFSwitchableShuntArray[nRecord].nRemoteBus					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_RemoteBusVoltage:			m_PSFSwitchableShuntArray[nRecord].fRemoteBusVoltage			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_QContributionPercentCtrl:	m_PSFSwitchableShuntArray[nRecord].fQContributionPercentCtrl	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_G0:							m_PSFSwitchableShuntArray[nRecord].fG0							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B0:							m_PSFSwitchableShuntArray[nRecord].fB0							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_Owner:						strcpy(m_PSFSwitchableShuntArray[nRecord].szOwner,	lpszValue);																break;
	case	PSFSwitchableShunt_ID:							strcpy(m_PSFSwitchableShuntArray[nRecord].szID,	lpszValue);																break;
	case	PSFSwitchableShunt_N1:							m_PSFSwitchableShuntArray[nRecord].nN1							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B1:							m_PSFSwitchableShuntArray[nRecord].fN1							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N2:							m_PSFSwitchableShuntArray[nRecord].nN2							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B2:							m_PSFSwitchableShuntArray[nRecord].fN2							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N3:							m_PSFSwitchableShuntArray[nRecord].nN3							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B3:							m_PSFSwitchableShuntArray[nRecord].fN3							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N4:							m_PSFSwitchableShuntArray[nRecord].nN4							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B4:							m_PSFSwitchableShuntArray[nRecord].fN4							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N5:							m_PSFSwitchableShuntArray[nRecord].nN5							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B5:							m_PSFSwitchableShuntArray[nRecord].fN5							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N6:							m_PSFSwitchableShuntArray[nRecord].nN6							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B6:							m_PSFSwitchableShuntArray[nRecord].fN6							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N7:							m_PSFSwitchableShuntArray[nRecord].nN7							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B7:							m_PSFSwitchableShuntArray[nRecord].fN7							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_N8:							m_PSFSwitchableShuntArray[nRecord].nN8							=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_B8:							m_PSFSwitchableShuntArray[nRecord].fN8							=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_IMAX:						m_PSFSwitchableShuntArray[nRecord].fIMAX						=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_EquipmentName:				strcpy(m_PSFSwitchableShuntArray[nRecord].szEquipmentName,	lpszValue);														break;
	case	PSFSwitchableShunt_RVULimit:					m_PSFSwitchableShuntArray[nRecord].fRVULimit					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShunt_RVLLimit:					m_PSFSwitchableShuntArray[nRecord].fRVLLimit					=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableShuntEx_RTName:					strcpy(m_PSFSwitchableShuntArray[nRecord].szRTName,		lpszValue);														break;
	}
}

void	CPSFAscii::SetPSFLine(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_Line;
	switch (nField)
	{
	case	PSFLine_Bus1Number:		m_PSFLineArray[nRecord].nBus1Number	=str2Integer(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Bus2Number:		m_PSFLineArray[nRecord].nBus2Number	=str2Integer(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_ID:				strcpy(m_PSFLineArray[nRecord].szID,	lpszValue);																	break;
	case	PSFLine_Section:		m_PSFLineArray[nRecord].nSection		=str2Integer(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Status:			m_PSFLineArray[nRecord].nStatus		=str2Integer(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_MeterEnd:		m_PSFLineArray[nRecord].nMeterEnd=GetEnumValue(lpszValue, sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	break;
	case	PSFLine_R:				m_PSFLineArray[nRecord].fR				=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_X:				m_PSFLineArray[nRecord].fX				=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_G:				m_PSFLineArray[nRecord].fG				=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_B:				m_PSFLineArray[nRecord].fB				=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_GF:				m_PSFLineArray[nRecord].fGF			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_BF:				m_PSFLineArray[nRecord].fBF			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_GT:				m_PSFLineArray[nRecord].fGT			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_BT:				m_PSFLineArray[nRecord].fBT			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_R1:				m_PSFLineArray[nRecord].fR1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_R2:				m_PSFLineArray[nRecord].fR2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_R3:				m_PSFLineArray[nRecord].fR3			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_R4:				m_PSFLineArray[nRecord].fR4			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_R5:				m_PSFLineArray[nRecord].fR5			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_R6:				m_PSFLineArray[nRecord].fR6			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_RatingGroup:	m_PSFLineArray[nRecord].nRatingGroup	=str2Integer(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Z1:				m_PSFLineArray[nRecord].fZ1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Z2:				m_PSFLineArray[nRecord].fZ2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Z3:				m_PSFLineArray[nRecord].fZ3			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Z4:				m_PSFLineArray[nRecord].fZ4			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Z5:				m_PSFLineArray[nRecord].fZ5			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Z6:				m_PSFLineArray[nRecord].fZ6			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_Type:			m_PSFLineArray[nRecord].nType			=str2Integer(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_EquipmentName:	strcpy(m_PSFLineArray[nRecord].szEquipmentName,lpszValue);															break;
	case	PSFLine_Owner:			strcpy(m_PSFLineArray[nRecord].szOwner,		lpszValue);															break;
	case	PSFLine_Length:			m_PSFLineArray[nRecord].fLength		=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_RZ:				m_PSFLineArray[nRecord].fRZ			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_XZ:				m_PSFLineArray[nRecord].fXZ			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_RZC:			m_PSFLineArray[nRecord].fRZC			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_XZC:			m_PSFLineArray[nRecord].fXZC			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_RZSF:			m_PSFLineArray[nRecord].fRZSF			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_XZSF:			m_PSFLineArray[nRecord].fXZSF			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_RZST:			m_PSFLineArray[nRecord].fRZST			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLine_XZST:			m_PSFLineArray[nRecord].fXZST			=str2Float	(bCheckValidate, nTable, nField, lpszValue);					break;
	case	PSFLineEx_RTName:		strcpy(m_PSFLineArray[nRecord].szOwner,	lpszValue);																break;
	case	PSFLineEx_RTP1:			m_PSFLineArray[nRecord].fRTP1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineEx_RTQ1:			m_PSFLineArray[nRecord].fRTQ1			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineEx_RTP2:			m_PSFLineArray[nRecord].fRTP2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineEx_RTQ2:			m_PSFLineArray[nRecord].fRTQ2			=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFFixedTransformer(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_FixedTransformer;
	switch (nField)
	{
	case	PSFFixedTransformer_Bus1Number:			m_PSFFixedTranArray[nRecord].nBus1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Bus2Number:			m_PSFFixedTranArray[nRecord].nBus2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_ID:					strcpy(m_PSFFixedTranArray[nRecord].szID,lpszValue);														break;
	case	PSFFixedTransformer_Section:			m_PSFFixedTranArray[nRecord].nSection	=str2Integer(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Status:				m_PSFFixedTranArray[nRecord].nStatus	=str2Integer(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_MeterEnd:			m_PSFFixedTranArray[nRecord].nMeterEnd=GetEnumValue(lpszValue, sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);		break;
	case	PSFFixedTransformer_ONR:				m_PSFFixedTranArray[nRecord].fONR		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Angle:				m_PSFFixedTranArray[nRecord].fAngle		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R:					m_PSFFixedTranArray[nRecord].fR			=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_X:					m_PSFFixedTranArray[nRecord].fX			=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_G:					m_PSFFixedTranArray[nRecord].fG			=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_B:					m_PSFFixedTranArray[nRecord].fB			=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_GF:					m_PSFFixedTranArray[nRecord].fGF		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_BF:					m_PSFFixedTranArray[nRecord].fBF		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_GT:					m_PSFFixedTranArray[nRecord].fGT		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_BT:					m_PSFFixedTranArray[nRecord].fBT		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R1:					m_PSFFixedTranArray[nRecord].fR1		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R2:					m_PSFFixedTranArray[nRecord].fR2		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R3:					m_PSFFixedTranArray[nRecord].fR3		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R4:					m_PSFFixedTranArray[nRecord].fR4		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R5:					m_PSFFixedTranArray[nRecord].fR5		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_R6:					m_PSFFixedTranArray[nRecord].fR6		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_RatingGroup:		m_PSFFixedTranArray[nRecord].nRatingGroup=str2Integer(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_MVA:				m_PSFFixedTranArray[nRecord].fMVA		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Z1:					m_PSFFixedTranArray[nRecord].fZ1		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Z2:					m_PSFFixedTranArray[nRecord].fZ2		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Z3:					m_PSFFixedTranArray[nRecord].fZ3		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Z4:					m_PSFFixedTranArray[nRecord].fZ4		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Z5:					m_PSFFixedTranArray[nRecord].fZ5		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_Z6:					m_PSFFixedTranArray[nRecord].fZ6		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformer_EquipmentName:		strcpy(m_PSFFixedTranArray[nRecord].szEquipmentName,lpszValue);												break;
	case	PSFFixedTransformer_Name:				strcpy(m_PSFFixedTranArray[nRecord].szName,lpszValue);														break;
	case	PSFFixedTransformer_Owner:				strcpy(m_PSFFixedTranArray[nRecord].szOwner,lpszValue);														break;
	case	PSFFixedTransformer_RZ:					m_PSFFixedTranArray[nRecord].fRZ		=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFFixedTransformer_XZ:					m_PSFFixedTranArray[nRecord].fXZ		=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFFixedTransformer_WindConnectionCode:	m_PSFFixedTranArray[nRecord].nWindConnectionCode=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedTransformer_RGF:				m_PSFFixedTranArray[nRecord].fRGF		=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFFixedTransformer_XGF:				m_PSFFixedTranArray[nRecord].fXGF		=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFFixedTransformer_RGT:				m_PSFFixedTranArray[nRecord].fRGT		=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFFixedTransformer_XGT:				m_PSFFixedTranArray[nRecord].fXGT		=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFFixedTransformerEx_RTName:			strcpy(m_PSFFixedTranArray[nRecord].szRTName,lpszValue);													break;
	case	PSFFixedTransformerEx_RTP1:				m_PSFFixedTranArray[nRecord].fRTP1		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformerEx_RTQ1:				m_PSFFixedTranArray[nRecord].fRTQ1		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformerEx_RTP2:				m_PSFFixedTranArray[nRecord].fRTP2		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFFixedTransformerEx_RTQ2:				m_PSFFixedTranArray[nRecord].fRTQ2		=str2Float	(bCheckValidate, nTable, nField, lpszValue);			break;
	}
}

void	CPSFAscii::SetPSFULTCTransformer(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_ULTCTransformer;
	switch (nField)
	{
	case	PSFULTCTransformer_Bus1Number:			m_PSFULTCTranArray[nRecord].nBus1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Bus2Number:			m_PSFULTCTranArray[nRecord].nBus2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_ID:					strcpy(m_PSFULTCTranArray[nRecord].szID,lpszValue);												break;
	case	PSFULTCTransformer_Section:				m_PSFULTCTranArray[nRecord].nSection=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Status:				m_PSFULTCTranArray[nRecord].nStatus=str2Integer(bCheckValidate, nTable, nField, lpszValue);		break;
	case	PSFULTCTransformer_MeterEnd:			m_PSFULTCTranArray[nRecord].nMeterEnd=GetEnumValue(lpszValue, sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	//atoi(lpszValue);	break;
	case	PSFULTCTransformer_FromRatio:			m_PSFULTCTranArray[nRecord].fFromRatio=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_ToRatio:				m_PSFULTCTranArray[nRecord].fToRatio=str2Float(bCheckValidate, nTable, nField, lpszValue);		break;
	case	PSFULTCTransformer_Angle:				m_PSFULTCTranArray[nRecord].fAngle=str2Float(bCheckValidate, nTable, nField, lpszValue);		break;
	case	PSFULTCTransformer_R:					m_PSFULTCTranArray[nRecord].fR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_X:					m_PSFULTCTranArray[nRecord].fX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_G:					m_PSFULTCTranArray[nRecord].fG=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_B:					m_PSFULTCTranArray[nRecord].fB=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_GF:					m_PSFULTCTranArray[nRecord].fGF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_BF:					m_PSFULTCTranArray[nRecord].fBF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_GT:					m_PSFULTCTranArray[nRecord].fGT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_BT:					m_PSFULTCTranArray[nRecord].fBT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MaxR:				m_PSFULTCTranArray[nRecord].fMaxR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MinR:				m_PSFULTCTranArray[nRecord].fMinR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Step:				m_PSFULTCTranArray[nRecord].fStep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MaxA:				m_PSFULTCTranArray[nRecord].fMaxA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MinA:				m_PSFULTCTranArray[nRecord].fMinA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_AStep:				m_PSFULTCTranArray[nRecord].fAStep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_CtrlType:			m_PSFULTCTranArray[nRecord].nCtrlType=GetEnumValue(lpszValue, sizeof(g_lpszPSFPSFULTCTransformer_CtrlType)/sizeof(char), g_lpszPSFPSFULTCTransformer_CtrlType);	break;
	case	PSFULTCTransformer_CtrlSide:			m_PSFULTCTranArray[nRecord].nCtrlSide=GetEnumValue(lpszValue, sizeof(g_lpszPSF_CtrlSide)/sizeof(char), g_lpszPSF_CtrlSide);	break;
	case	PSFULTCTransformer_CtrlFlag:			m_PSFULTCTranArray[nRecord].nCtrlFlag=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MaxMW:				m_PSFULTCTranArray[nRecord].fMaxMW=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MinMW:				m_PSFULTCTranArray[nRecord].fMinMW=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MaxMVar:				m_PSFULTCTranArray[nRecord].fMaxMVar=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MinMVar:				m_PSFULTCTranArray[nRecord].fMinMVar=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_VHiLimit:			m_PSFULTCTranArray[nRecord].fVHiLimit=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_VLoLimit:			m_PSFULTCTranArray[nRecord].fVLoLimit=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_CtrlBus:				m_PSFULTCTranArray[nRecord].nCtrlBus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_ZCorrTable:			m_PSFULTCTranArray[nRecord].nZCorrTable=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_R1:					m_PSFULTCTranArray[nRecord].fR1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_R2:					m_PSFULTCTranArray[nRecord].fR2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_R3:					m_PSFULTCTranArray[nRecord].fR3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_R4:					m_PSFULTCTranArray[nRecord].fR4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_R5:					m_PSFULTCTranArray[nRecord].fR5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_R6:					m_PSFULTCTranArray[nRecord].fR6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_RatingGroup:			m_PSFULTCTranArray[nRecord].nRatingGroup=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_MVA:					m_PSFULTCTranArray[nRecord].fMVA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Z1:					m_PSFULTCTranArray[nRecord].fZ1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Z2:					m_PSFULTCTranArray[nRecord].fZ2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Z3:					m_PSFULTCTranArray[nRecord].fZ3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Z4:					m_PSFULTCTranArray[nRecord].fZ4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Z5:					m_PSFULTCTranArray[nRecord].fZ5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_Z6:					m_PSFULTCTranArray[nRecord].fZ6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_EquipmentName:		strcpy(m_PSFULTCTranArray[nRecord].szEquipmentName,lpszValue);	break;
	case	PSFULTCTransformer_Name:				strcpy(m_PSFULTCTranArray[nRecord].szName,lpszValue);	break;
	case	PSFULTCTransformer_Owner:				strcpy(m_PSFULTCTranArray[nRecord].szOwner,lpszValue);	break;
	case	PSFULTCTransformer_RZ:					m_PSFULTCTranArray[nRecord].fRZ=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_XZ:					m_PSFULTCTranArray[nRecord].fXZ=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_WindConnectionCode:	m_PSFULTCTranArray[nRecord].nWindConnectionCode=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_RGF:					m_PSFULTCTranArray[nRecord].fRGF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_XGF:					m_PSFULTCTranArray[nRecord].fXGF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_RGT:					m_PSFULTCTranArray[nRecord].fRGT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFULTCTransformer_XGT:					m_PSFULTCTranArray[nRecord].fXGT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFImpedanceCorrectionTables(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_ImpedanceCorrectionTables;
	switch (nField)
	{
	case	PSFImpedanceCorrectionTables_TableNumber:	m_PSFImpedanceCorrectionTablesArray[nRecord].nTableNumber=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFImpedanceCorrectionTables_T1:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT1=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F1:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF1=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T2:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT2=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F2:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF2=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T3:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT3=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F3:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF3=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T4:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT4=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F4:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF4=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T5:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT5=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F5:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF5=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T6:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT6=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F6:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF6=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T7:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT7=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F7:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF7=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T8:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT8=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F8:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF8=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T9:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT9=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_F9:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF9=str2Float(bCheckValidate, nTable, nField, lpszValue);				break;
	case	PSFImpedanceCorrectionTables_T10:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT10=str2Float(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFImpedanceCorrectionTables_F10:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF10=str2Float(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFImpedanceCorrectionTables_T11:			m_PSFImpedanceCorrectionTablesArray[nRecord].fT11=str2Float(bCheckValidate, nTable, nField, lpszValue);			break;
	case	PSFImpedanceCorrectionTables_F11:			m_PSFImpedanceCorrectionTablesArray[nRecord].fF11=str2Float(bCheckValidate, nTable, nField, lpszValue);			break;
	}
}

void	CPSFAscii::SetPSFFixedSeriesCompensator(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_FixedSeriesCompensator;
	switch (nField)
	{
	case	PSFFixedSeriesCompensator_Bus1Number:		m_PSFFixedSeriesCompensatorArray[nRecord].nBus1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Bus2Number:		m_PSFFixedSeriesCompensatorArray[nRecord].nBus2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_ID:				strcpy(m_PSFFixedSeriesCompensatorArray[nRecord].szID,lpszValue);	break;
	case	PSFFixedSeriesCompensator_Section:			m_PSFFixedSeriesCompensatorArray[nRecord].nSection=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_X:				m_PSFFixedSeriesCompensatorArray[nRecord].fX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Status:			m_PSFFixedSeriesCompensatorArray[nRecord].nStatus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_MeterEnd:			m_PSFFixedSeriesCompensatorArray[nRecord].nMeterEnd=GetEnumValue(lpszValue, sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	break;
	case	PSFFixedSeriesCompensator_AMPRating:		m_PSFFixedSeriesCompensatorArray[nRecord].fAMPRating=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_kVRating:			m_PSFFixedSeriesCompensatorArray[nRecord].fkVRating=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Z1:				m_PSFFixedSeriesCompensatorArray[nRecord].fZ1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Z2:				m_PSFFixedSeriesCompensatorArray[nRecord].fZ2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Z3:				m_PSFFixedSeriesCompensatorArray[nRecord].fZ3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Z4:				m_PSFFixedSeriesCompensatorArray[nRecord].fZ4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Z5:				m_PSFFixedSeriesCompensatorArray[nRecord].fZ5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_Z6:				m_PSFFixedSeriesCompensatorArray[nRecord].fZ6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFFixedSeriesCompensator_EquipmentName:	strcpy(m_PSFFixedSeriesCompensatorArray[nRecord].szEquipmentName,lpszValue);	break;
	case	PSFFixedSeriesCompensator_Owner:			strcpy(m_PSFFixedSeriesCompensatorArray[nRecord].szOwner,lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFSwitchableSeriesCompensator(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_SwitchableSeriesCompensator;
	switch (nField)
	{
	case	PSFSwitchableSeriesCompensator_Bus1Number:		m_PSFSwitchableSeriesCompensatorArray[nRecord].nBus1Number				=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Bus2Number:		m_PSFSwitchableSeriesCompensatorArray[nRecord].nBus2Number				=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_ID:				strcpy(m_PSFSwitchableSeriesCompensatorArray[nRecord].szID,			lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Section:			m_PSFSwitchableSeriesCompensatorArray[nRecord].nSection				=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Status:			m_PSFSwitchableSeriesCompensatorArray[nRecord].nStatus					=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_MeterEnd:		m_PSFSwitchableSeriesCompensatorArray[nRecord].nMeterEnd				=GetEnumValue(lpszValue, sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	break;
	case	PSFSwitchableSeriesCompensator_X:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fX						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_XMax:			m_PSFSwitchableSeriesCompensatorArray[nRecord].fXMax					=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_XMin:			m_PSFSwitchableSeriesCompensatorArray[nRecord].fXMin					=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Steps:			m_PSFSwitchableSeriesCompensatorArray[nRecord].fSteps					=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_CtrlFlag:		m_PSFSwitchableSeriesCompensatorArray[nRecord].nCtrlFlag				=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_MaxMW:			m_PSFSwitchableSeriesCompensatorArray[nRecord].fMaxMW					=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_MinMW:			m_PSFSwitchableSeriesCompensatorArray[nRecord].fMinMW					=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_AMPRating:		m_PSFSwitchableSeriesCompensatorArray[nRecord].fAMPRating				=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_kVRating:		m_PSFSwitchableSeriesCompensatorArray[nRecord].fkVRating				=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Z1:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ1						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Z2:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ2						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Z3:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ3						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Z4:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ4						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Z5:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ5						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Z6:				m_PSFSwitchableSeriesCompensatorArray[nRecord].fZ6						=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_EquipmentName:	strcpy(m_PSFSwitchableSeriesCompensatorArray[nRecord].szEquipmentName,	lpszValue);	break;
	case	PSFSwitchableSeriesCompensator_Owner:			strcpy(m_PSFSwitchableSeriesCompensatorArray[nRecord].szOwner,			lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFStaticTapChangerPhaseRegulator(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_StaticTapChangerPhaseRegulator;
	switch (nField)
	{
	case	PSFStaticTapChangerPhaseRegulator_Bus1Number:			m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nBus1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Bus2Number:			m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nBus2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_ID:					strcpy(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szID,	lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Section:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nSection=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Status:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nStatus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MeterEnd:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nMeterEnd		=GetEnumValue(lpszValue, sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	break;
	case	PSFStaticTapChangerPhaseRegulator_R:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_X:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_G:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fG=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_B:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fB=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_GF:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fGF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_BF:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fBF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_GT:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fGT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_BT:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fBT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_TCRG:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fTCRG=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_PSRG:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fPSRG=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_TCpsn:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fTCpsn=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_PSpsn:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fPSpsn=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_TCR:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fTCR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MaxTCR:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxTCR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MinTCR:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinTCR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_PSR:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fPSR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MaxPSR:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxPSR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MinPSR:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinPSR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_CtrlType:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlType=GetEnumValue(lpszValue, sizeof(g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType)/sizeof(char*), g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType);	break;
	case	PSFStaticTapChangerPhaseRegulator_CtrlSide:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlSide=GetEnumValue(lpszValue, sizeof(g_lpszPSF_CtrlSide)/sizeof(char), g_lpszPSF_CtrlSide);	break;
	case	PSFStaticTapChangerPhaseRegulator_CtrlFlag:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlFlag=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MaxP:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxP=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MinP:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinP=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MaxQ:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMaxQ=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MinQ:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMinQ=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_VHiLimit:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fVHiLimit=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_VLoLimit:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fVLoLimit=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_CtrlBus:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nCtrlBus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_ZCorrTC:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nZCorrTC=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_ZCorrPS:				m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nZCorrPS=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_MVA:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fMVA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_R1:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_R2:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_R3:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_R4:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_R5:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_R6:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fR6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_RatingGroup:			m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nRatingGroup=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Z1:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Z2:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Z3:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Z4:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Z5:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Z6:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fZ6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_EquipmentName:		strcpy(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szEquipmentName,	lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Name:					strcpy(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szName,				lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_Owner:				strcpy(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].szOwner,			lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_RZ:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fRZ=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_XZ:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fXZ=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_WindConnectionCode:	m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nWindConnectionCode=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_RGF:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fRGF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_XGF:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fXGF=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_RGT:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fRGT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFStaticTapChangerPhaseRegulator_XGT:					m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].fXGT=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSF3WindingTransformer(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_PSF3WindingTransformer;
	switch (nField)
	{
	case	PSF3WindingTransformer_Bus1Number:		m_PSF3WindingTranArray[nRecord].nBus1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Bus2Number:		m_PSF3WindingTranArray[nRecord].nBus2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Bus3Number:		m_PSF3WindingTranArray[nRecord].nBus3Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_ID:				strcpy(m_PSF3WindingTranArray[nRecord].szID,	lpszValue);	break;
	case	PSF3WindingTransformer_Status:			m_PSF3WindingTranArray[nRecord].nStatus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_NonMeteredEnd:	m_PSF3WindingTranArray[nRecord].nNonMeteredEnd=GetEnumValue(lpszValue, sizeof(g_lpszPSF3WindingTransformer_NonMeteredEnd)/sizeof(char), g_lpszPSF3WindingTransformer_NonMeteredEnd);	break;
	case	PSF3WindingTransformer_Ratio1:			m_PSF3WindingTranArray[nRecord].fRatio1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Angle1:			m_PSF3WindingTranArray[nRecord].fAngle1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Ratio2:			m_PSF3WindingTranArray[nRecord].fRatio2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Angle2:			m_PSF3WindingTranArray[nRecord].fAngle2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Ratio3:			m_PSF3WindingTranArray[nRecord].fRatio3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_Angle3:			m_PSF3WindingTranArray[nRecord].fAngle3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_R1:				m_PSF3WindingTranArray[nRecord].fR1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_X1:				m_PSF3WindingTranArray[nRecord].fX1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_R2:				m_PSF3WindingTranArray[nRecord].fR2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_X2:				m_PSF3WindingTranArray[nRecord].fX2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_R3:				m_PSF3WindingTranArray[nRecord].fR3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_X3:				m_PSF3WindingTranArray[nRecord].fX3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_G1:				m_PSF3WindingTranArray[nRecord].fG1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_B1:				m_PSF3WindingTranArray[nRecord].fB1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_G2:				m_PSF3WindingTranArray[nRecord].fG2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_B2:				m_PSF3WindingTranArray[nRecord].fB2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_G3:				m_PSF3WindingTranArray[nRecord].fG3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_B3:				m_PSF3WindingTranArray[nRecord].fB3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PMaxRA:			m_PSF3WindingTranArray[nRecord].fPMaxRA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PMinRA:			m_PSF3WindingTranArray[nRecord].fPMinRA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PStep:			m_PSF3WindingTranArray[nRecord].fPStep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PCtrlSide:		m_PSF3WindingTranArray[nRecord].nPCtrlSide=GetEnumValue(lpszValue, sizeof(g_lpszPSF3WindingTransformer_CtrlSide)/sizeof(char), g_lpszPSF3WindingTransformer_CtrlSide);	break;
	case	PSF3WindingTransformer_PCtrlFlag:		m_PSF3WindingTranArray[nRecord].nPCtrlFlag=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PMaxCtrl:		m_PSF3WindingTranArray[nRecord].fPMaxCtrl=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PMinCtrl:		m_PSF3WindingTranArray[nRecord].fPMinCtrl=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PCtrlBus:		m_PSF3WindingTranArray[nRecord].nPCtrlBus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PZCorrTable:		m_PSF3WindingTranArray[nRecord].nPZCorrTable=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SMaxRA:			m_PSF3WindingTranArray[nRecord].fSMaxRA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SMinRA:			m_PSF3WindingTranArray[nRecord].fSMinRA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SStep:			m_PSF3WindingTranArray[nRecord].fSStep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SCtrlSide:		m_PSF3WindingTranArray[nRecord].nSCtrlSide=GetEnumValue(lpszValue, sizeof(g_lpszPSF3WindingTransformer_CtrlSide)/sizeof(char), g_lpszPSF3WindingTransformer_CtrlSide);	break;
	case	PSF3WindingTransformer_SCtrlFlag:		m_PSF3WindingTranArray[nRecord].nSCtrlFlag=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SMaxCtrl:		m_PSF3WindingTranArray[nRecord].fSMaxCtrl=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SMinCtrl:		m_PSF3WindingTranArray[nRecord].fSMinCtrl=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SCtrlBus:		m_PSF3WindingTranArray[nRecord].nSCtrlBus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SZCorrTable:		m_PSF3WindingTranArray[nRecord].nSZCorrTable=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TMaxRA:			m_PSF3WindingTranArray[nRecord].fTMaxRA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TMinRA:			m_PSF3WindingTranArray[nRecord].fTMinRA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TStep:			m_PSF3WindingTranArray[nRecord].fTStep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TCtrlSide:		m_PSF3WindingTranArray[nRecord].nTCtrlSide=GetEnumValue(lpszValue, sizeof(g_lpszPSF3WindingTransformer_CtrlSide)/sizeof(char), g_lpszPSF3WindingTransformer_CtrlSide);	break;
	case	PSF3WindingTransformer_TCtrlFlag:		m_PSF3WindingTranArray[nRecord].nTCtrlFlag=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TMaxCtrl:		m_PSF3WindingTranArray[nRecord].fTMaxCtrl=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TMinCtrl:		m_PSF3WindingTranArray[nRecord].fTMinCtrl=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TCtrlBus:		m_PSF3WindingTranArray[nRecord].nTCtrlBus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TZCorrTable:		m_PSF3WindingTranArray[nRecord].nTZCorrTable=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PR1:				m_PSF3WindingTranArray[nRecord].fPR1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PR2:				m_PSF3WindingTranArray[nRecord].fPR2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PR3:				m_PSF3WindingTranArray[nRecord].fPR3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PR4:				m_PSF3WindingTranArray[nRecord].fPR4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PR5:				m_PSF3WindingTranArray[nRecord].fPR5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PR6:				m_PSF3WindingTranArray[nRecord].fPR6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_RatingGroup:		m_PSF3WindingTranArray[nRecord].nRatingGroup=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_MVA:				m_PSF3WindingTranArray[nRecord].fMVA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR1:				m_PSF3WindingTranArray[nRecord].fSR1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR2:				m_PSF3WindingTranArray[nRecord].fSR2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR3:				m_PSF3WindingTranArray[nRecord].fSR3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR4:				m_PSF3WindingTranArray[nRecord].fSR4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR5:				m_PSF3WindingTranArray[nRecord].fSR5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR6:				m_PSF3WindingTranArray[nRecord].fSR6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR1:				m_PSF3WindingTranArray[nRecord].fTR1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR2:				m_PSF3WindingTranArray[nRecord].fTR2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR3:				m_PSF3WindingTranArray[nRecord].fTR3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR4:				m_PSF3WindingTranArray[nRecord].fTR4=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR5:				m_PSF3WindingTranArray[nRecord].fTR5=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR6:				m_PSF3WindingTranArray[nRecord].fTR6=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_EquipmentName:	strcpy(m_PSF3WindingTranArray[nRecord].szEquipmentName,	lpszValue);	break;
	case	PSF3WindingTransformer_Name:			strcpy(m_PSF3WindingTranArray[nRecord].szName,				lpszValue);	break;
	case	PSF3WindingTransformer_Owner:			strcpy(m_PSF3WindingTranArray[nRecord].szOwner,			lpszValue);	break;
	case	PSF3WindingTransformer_PR0:				m_PSF3WindingTranArray[nRecord].fPR0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PX0:				m_PSF3WindingTranArray[nRecord].fPX0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SR0:				m_PSF3WindingTranArray[nRecord].fSR0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SX0:				m_PSF3WindingTranArray[nRecord].fSX0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TR0:				m_PSF3WindingTranArray[nRecord].fTR0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TX0:				m_PSF3WindingTranArray[nRecord].fTX0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_GroundingCode:	m_PSF3WindingTranArray[nRecord].nGroundingCode=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PGR:				m_PSF3WindingTranArray[nRecord].fPGR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_PGX:				m_PSF3WindingTranArray[nRecord].fPGX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SGR:				m_PSF3WindingTranArray[nRecord].fSGR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_SGX:				m_PSF3WindingTranArray[nRecord].fSGX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TGR:				m_PSF3WindingTranArray[nRecord].fTGR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSF3WindingTransformer_TGX:				m_PSF3WindingTranArray[nRecord].fTGX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFAreaInterchange(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_AreaInterchange;
	switch (nField)
	{
	case	PSFAreaInterchange_Number:		m_PSFAreaInterchangeArray[nRecord].nNumber		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFAreaInterchange_Name:		strcpy(m_PSFAreaInterchangeArray[nRecord].szName,			lpszValue);	break;
	case	PSFAreaInterchange_DesiredFlow:	m_PSFAreaInterchangeArray[nRecord].fDesiredFlow	=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFAreaInterchange_Tolerance:	m_PSFAreaInterchangeArray[nRecord].fTolerance		=str2Float	(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFAreaInterchange_SlackBus:	m_PSFAreaInterchangeArray[nRecord].nSlackBus		=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFAreaInterchange_Description:	strcpy(m_PSFAreaInterchangeArray[nRecord].szDescription,	lpszValue);	break;
	case	PSFAreaInterchange_Mode:		m_PSFAreaInterchangeArray[nRecord].nMode			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFAreaInterchange_Flag:		m_PSFAreaInterchangeArray[nRecord].nFlag			=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFLineCommutatedConverters(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_LineCommutatedConverters;
	switch (nField)
	{
	case	PSFLineCommutatedConverters_DCBus1:		strcpy(m_PSFLCConvertersArray[nRecord].szDCBus1,		lpszValue);	break;
	case	PSFLineCommutatedConverters_DCBus2:		strcpy(m_PSFLCConvertersArray[nRecord].szDCBus2,		lpszValue);	break;
	case	PSFLineCommutatedConverters_ACBus:		m_PSFLCConvertersArray[nRecord].nACBus=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_ID:			m_PSFLCConvertersArray[nRecord].nID=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Change:		m_PSFLCConvertersArray[nRecord].nChange=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);	break;
	case	PSFLineCommutatedConverters_Grp:		strcpy(m_PSFLCConvertersArray[nRecord].szGrp,			lpszValue);	break;
	case	PSFLineCommutatedConverters_Zone:		m_PSFLCConvertersArray[nRecord].nZone=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Bridge:		m_PSFLCConvertersArray[nRecord].nBridge=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Xc:			m_PSFLCConvertersArray[nRecord].fXc=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_VR:			m_PSFLCConvertersArray[nRecord].fVR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Tstep:		m_PSFLCConvertersArray[nRecord].fTstep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Tmin:		m_PSFLCConvertersArray[nRecord].fTmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Tmax:		m_PSFLCConvertersArray[nRecord].fTmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Amin:		m_PSFLCConvertersArray[nRecord].fAmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Amax:		m_PSFLCConvertersArray[nRecord].fAmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Gmin:		m_PSFLCConvertersArray[nRecord].fGmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Imax:		m_PSFLCConvertersArray[nRecord].fImax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_CtrlMode:	strcpy(m_PSFLCConvertersArray[nRecord].szCtrlMode,			lpszValue);	break;
	case	PSFLineCommutatedConverters_SP1:		m_PSFLCConvertersArray[nRecord].fSP1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_SP2:		m_PSFLCConvertersArray[nRecord].fSP2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Type:		m_PSFLCConvertersArray[nRecord].nType=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Type)/sizeof(char), g_lpszPSFMultiTerminalDC_Type);	break;
	case	PSFLineCommutatedConverters_MVA:		m_PSFLCConvertersArray[nRecord].fMVA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Pmin:		m_PSFLCConvertersArray[nRecord].fPmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Pmax:		m_PSFLCConvertersArray[nRecord].fPmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Qmin:		m_PSFLCConvertersArray[nRecord].fQmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_Qmax:		m_PSFLCConvertersArray[nRecord].fQmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_BiasR:		m_PSFLCConvertersArray[nRecord].fBiasR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFLineCommutatedConverters_kV:			m_PSFLCConvertersArray[nRecord].fkV=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFDCLines(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_DCLines;
	switch (nField)
	{
	case	PSFDCLines_DCBus1:	strcpy(m_PSFDCLinesArray[nRecord].szDCBus1,		lpszValue);	break;
	case	PSFDCLines_DCBus2:	strcpy(m_PSFDCLinesArray[nRecord].szDCBus2,		lpszValue);	break;
	case	PSFDCLines_ID:		strcpy(m_PSFDCLinesArray[nRecord].szID,			lpszValue);	break;
	case	PSFDCLines_Change:	m_PSFDCLinesArray[nRecord].nChange=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);	break;
	case	PSFDCLines_Grp:		strcpy(m_PSFDCLinesArray[nRecord].szGrp,			lpszValue);	break;
	case	PSFDCLines_Zone:	m_PSFDCLinesArray[nRecord].nZone=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCLines_Owner:	strcpy(m_PSFDCLinesArray[nRecord].szOwner,		lpszValue);	break;
	case	PSFDCLines_Rdc:		m_PSFDCLinesArray[nRecord].fRdc=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCLines_Ldc:		m_PSFDCLinesArray[nRecord].fLdc=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCLines_Cdca:	m_PSFDCLinesArray[nRecord].fCdca=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCLines_Cdcb:	m_PSFDCLinesArray[nRecord].fCdcb=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCLines_Imax:	m_PSFDCLinesArray[nRecord].fImax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCLines_Mend:	m_PSFDCLinesArray[nRecord].nMend=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Mend)/sizeof(char), g_lpszPSFMultiTerminalDC_Mend);	break;
	}
}

void	CPSFAscii::SetPSFDCBreakers(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_DCBreakers;
	switch (nField)
	{
	case	PSFDCBreakers_DCBus1:	strcpy(m_PSFDCBreakersArray[nRecord].szDCBus1,			lpszValue);	break;
	case	PSFDCBreakers_DCBus2:	strcpy(m_PSFDCBreakersArray[nRecord].szDCBus2,			lpszValue);	break;
	case	PSFDCBreakers_ID:		strcpy(m_PSFDCBreakersArray[nRecord].szID,				lpszValue);	break;
	case	PSFDCBreakers_Change:	m_PSFDCBreakersArray[nRecord].nChange=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);	break;
	case	PSFDCBreakers_Grp:		strcpy(m_PSFDCBreakersArray[nRecord].szGrp,				lpszValue);	break;
	case	PSFDCBreakers_Zone:		m_PSFDCBreakersArray[nRecord].nZone=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCBreakers_Owner:	strcpy(m_PSFDCBreakersArray[nRecord].szOwner,			lpszValue);	break;
	case	PSFDCBreakers_Status:	m_PSFDCBreakersArray[nRecord].nStatus=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Status)/sizeof(char*), g_lpszPSFMultiTerminalDC_Status);	break;
	}
}

void	CPSFAscii::SetPSFDCBuses(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_DCBuses;
	switch (nField)
	{
	case	PSFDCBuses_DCBus:	strcpy(m_PSFDCBusesArray[nRecord].szDCBus,			lpszValue);	break;
	case	PSFDCBuses_Change:	m_PSFDCBusesArray[nRecord].nChange=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);	break;
	case	PSFDCBuses_Area:	m_PSFDCBusesArray[nRecord].nArea=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFDCBuses_Zone:	m_PSFDCBusesArray[nRecord].nZone=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFVoltageSourcedConverter(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_VoltageSourcedConverter;
	switch (nField)
	{
	case	PSFVoltageSourcedConverter_DCBus1:	strcpy(m_PSFVSCArray[nRecord].szDCBus1,				lpszValue);	break;
	case	PSFVoltageSourcedConverter_DCBus2:	strcpy(m_PSFVSCArray[nRecord].szDCBus2,				lpszValue);	break;
	case	PSFVoltageSourcedConverter_ACBus1:	m_PSFVSCArray[nRecord].nACBus1=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_ID:		strcpy(m_PSFVSCArray[nRecord].szID,					lpszValue);	break;
	case	PSFVoltageSourcedConverter_DCBus3:	strcpy(m_PSFVSCArray[nRecord].szDCBus3,			lpszValue);	break;
	case	PSFVoltageSourcedConverter_DCBus4:	strcpy(m_PSFVSCArray[nRecord].szDCBus4,			lpszValue);	break;
	case	PSFVoltageSourcedConverter_ACBus2:	m_PSFVSCArray[nRecord].nACBus2=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_ID2:		strcpy(m_PSFVSCArray[nRecord].szID2,				lpszValue);	break;
	case	PSFVoltageSourcedConverter_Change:	m_PSFVSCArray[nRecord].nChange=GetEnumValue(lpszValue, sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);	break;
	case	PSFVoltageSourcedConverter_Grp:		strcpy(m_PSFVSCArray[nRecord].szGrp,				lpszValue);	break;
	case	PSFVoltageSourcedConverter_Zone:	m_PSFVSCArray[nRecord].nZone=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Bridge:	m_PSFVSCArray[nRecord].nBridge=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Xt:		m_PSFVSCArray[nRecord].fXt=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_VR:		m_PSFVSCArray[nRecord].fVR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Step:	m_PSFVSCArray[nRecord].fStep=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Tmin:	m_PSFVSCArray[nRecord].fTmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Tmax:	m_PSFVSCArray[nRecord].fTmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Amin:	m_PSFVSCArray[nRecord].fAmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Amax:	m_PSFVSCArray[nRecord].fAmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Gmin:	m_PSFVSCArray[nRecord].fGmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Gmax:	m_PSFVSCArray[nRecord].fGmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Imax:	m_PSFVSCArray[nRecord].fImax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Mode:	strcpy(m_PSFVSCArray[nRecord].szMode,				lpszValue);	break;
	case	PSFVoltageSourcedConverter_SP1:		m_PSFVSCArray[nRecord].fSP1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_SP2:		m_PSFVSCArray[nRecord].fSP2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_SP3:		m_PSFVSCArray[nRecord].fSP3=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_X1:		m_PSFVSCArray[nRecord].fX1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Kc:		m_PSFVSCArray[nRecord].fKc=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Type:	m_PSFVSCArray[nRecord].nType=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_MVA:		m_PSFVSCArray[nRecord].fMVA=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_kV:		m_PSFVSCArray[nRecord].fkV=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Vmin:	m_PSFVSCArray[nRecord].fVmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Vmax:	m_PSFVSCArray[nRecord].fVmax=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Vref:	m_PSFVSCArray[nRecord].fVref=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_QA0:		m_PSFVSCArray[nRecord].fQA0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_La:		m_PSFVSCArray[nRecord].fLa=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Lb:		m_PSFVSCArray[nRecord].fLb=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_Lmin:	m_PSFVSCArray[nRecord].fLmin=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_PA0:		m_PSFVSCArray[nRecord].fPA0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_VD0:		m_PSFVSCArray[nRecord].fVD0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFVoltageSourcedConverter_ID0:		m_PSFVSCArray[nRecord].fID0=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFZone(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_Zone;
	switch (nField)
	{
	case	PSFZone_Number:	m_PSFZoneArray[nRecord].nNumber=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZone_Name:	strcpy(m_PSFZoneArray[nRecord].szName,			lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFNodeMapping(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_NodeMapping;
	switch (nField)
	{
	case	PSFNodeMapping_BusNumber:	m_PSFNodeMappingArray[nRecord].nBusNumber=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFNodeMapping_BusName:		strcpy(m_PSFNodeMappingArray[nRecord].szBusName,			lpszValue);	break;
	case	PSFNodeMapping_NodeName:	strcpy(m_PSFNodeMappingArray[nRecord].szNodeName,			lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFZeroSequenceMutualCoupling(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	int		nTable=PSFModel_ZeroSequenceMutualCoupling;
	switch (nField)
	{
	case	PSFZeroSequenceMutualCoupling_Bus1L1Number:	m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus1L1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_Bus2L1Number:	m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus2L1Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_IDL1:			strcpy(m_PSFZeroSequenceMutualCouplingArray[nRecord].szIDL1,			lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_Bus1L2Number:	m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus1L2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_Bus2L2Number:	m_PSFZeroSequenceMutualCouplingArray[nRecord].nBus2L2Number=str2Integer(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_IDL2:			strcpy(m_PSFZeroSequenceMutualCouplingArray[nRecord].szIDL2,			lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_R:			m_PSFZeroSequenceMutualCouplingArray[nRecord].fR=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_X:			m_PSFZeroSequenceMutualCouplingArray[nRecord].fX=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_CF1:			m_PSFZeroSequenceMutualCouplingArray[nRecord].fCF1=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	case	PSFZeroSequenceMutualCoupling_CF2:			m_PSFZeroSequenceMutualCouplingArray[nRecord].fCF2=str2Float(bCheckValidate, nTable, nField, lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFFileSection(unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	switch (nField)
	{
	case	PSFFileSection_FileIdentifier:	strcpy(m_PSFFileSectionArray[nRecord].szFileIdentifier,	lpszValue);	break;
	case	PSFFileSection_FileName:		strcpy(m_PSFFileSectionArray[nRecord].szFileName,			lpszValue);	break;
	}
}

void	CPSFAscii::SetPSFSubstation(const unsigned char bCheckValidate, const int nField, const int nRecord, const char* lpszValue)
{
	switch (nField)
	{
	case	PSFSubstation_Name:		strcpy(m_SubstationArray[nRecord].szName,	lpszValue);	break;
	case	PSFSubstation_RTName:	strcpy(m_SubstationArray[nRecord].szRTName,	lpszValue);	break;
	}
}
