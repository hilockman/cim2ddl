#include "StdAfx.h"
#include "PSFAscii.h"

int CPSFAscii::IsCimDeviceMatched(const int nPSFAsciiTable, const char* lpszPGDev)
{
	register int	i;
	switch (nPSFAsciiTable)
	{
	case PSFModel_Substation:
		for (i=0; i<(int)m_SubstationArray.size(); i++)
		{
			if (strcmp(m_SubstationArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case PSFModel_Generator:
		for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
		{
			if (strcmp(m_PSFGeneratorArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;

	case PSFModel_Load:
		for (i=0; i<(int)m_PSFLoadArray.size(); i++)
		{
			if (strcmp(m_PSFLoadArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case PSFModel_FixedShunt:
		for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
		{
			if (strcmp(m_PSFFixedShuntArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case PSFModel_SwitchableShunt:
		for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
		{
			if (strcmp(m_PSFSwitchableShuntArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case PSFModel_Line:
		for (i=0; i<(int)m_PSFLineArray.size(); i++)
		{
			if (strcmp(m_PSFLineArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;
	case PSFModel_FixedTransformer:
		for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
		{
			if (strcmp(m_PSFFixedTranArray[i].szRTName, lpszPGDev) == 0)	
				return 1;
		}
		break;
	}

	return 0;
}

void CPSFAscii::CheckOffline2RTMatch(tagPGBlock* pPGBlock)
{
	register int	i;
	int		nOff,nFind,nSub,nVolt,nDev;
	int		nOffSubI,nOffSubJ;
	char	szBuf[260];

	std::vector<unsigned char>	bLineProc;
	bLineProc.resize(m_PSFLineArray.size(),0);

	for (nOff=0; nOff<(int)m_SubstationArray.size(); nOff++)
	{
		if (strlen(m_SubstationArray[nOff].szRTName) > 0)
		{
			nSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nOff].szRTName);
			if (nSub < 0)
				memset(m_SubstationArray[nOff].szRTName, 0, MDB_CHARLEN);
		}

		if (strlen(m_SubstationArray[nOff].szRTName) <= 0)
		{
			for (i=0; i<(int)m_SubstationArray[nOff].nBusArray.size(); i++)
			{
				for (nDev=0; nDev<(int)m_BusNobnArray[m_SubstationArray[nOff].nBusArray[i]].nGeneratorArray.size(); nDev++)
				{
					memset(m_PSFGeneratorArray[m_BusNobnArray[m_SubstationArray[nOff].nBusArray[i]].nGeneratorArray[nDev]].szRTName, 0, MDB_CHARLEN);
				}
			}
			continue;
		}
	}

	for (nOff=0; nOff<(int)m_PSFGeneratorArray.size(); nOff++)
	{
		if (strlen(m_PSFGeneratorArray[nOff].szRTName) <= 0)
			continue;
		if (m_PSFGeneratorArray[nOff].nBusIndex < 0)
			continue;

		nFind=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].szSubstation);
		if (nFind < 0)	//	һ�㲻����ָ��������ֹ���⡣ȷ��PSFAsciiĸ������PSFAscii��վ��PSFAscii���ݿ��д���
		{
			memset(m_PSFGeneratorArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		nSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nFind].szRTName);
		if (nSub < 0)	//	ȷ��PSFAsciiĸ������PG��վ��PG���ݿ��д��ڣ���������ڳ�վ������Ѿ����ϣ���������Ǳ�������³��
		{
			memset(m_PSFGeneratorArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		//	ȷ���������PG�ڴ���
		nFind=-1;
		for (nVolt=pPGBlock->m_SubstationArray[nSub].pRkv; nVolt<pPGBlock->m_SubstationArray[nSub+1].pRkv; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].pRun; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].pRun; nDev++)
			{
				sprintf(szBuf,"%s,%s,%s",pPGBlock->m_SynchronousMachineArray[nDev].szSub,pPGBlock->m_SynchronousMachineArray[nDev].szVolt,pPGBlock->m_SynchronousMachineArray[nDev].szName);
				if (strcmp(m_PSFGeneratorArray[nOff].szRTName, szBuf) == 0)
				{
					nFind=nDev;
					break;
				}
			}
			if (nFind >= 0)
				break;
		}
		if (nFind < 0)
			memset(m_PSFGeneratorArray[nOff].szRTName, 0, MDB_CHARLEN);
	}

	for (nOff=0; nOff<(int)m_PSFLineArray.size(); nOff++)
	{
		if (strlen(m_PSFLineArray[nOff].szRTName) <= 0)
			continue;
		if (m_PSFLineArray[nOff].nBus1Index < 0 || m_PSFLineArray[nOff].nBus2Index < 0)
		{
			memset(m_PSFLineArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		nFind=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
		{
			if (strcmp(m_PSFLineArray[nOff].szRTName, pPGBlock->m_ACLineSegmentArray[i].szName) == 0)
			{
				nFind=i;
				break;
			}
		}
		if (nFind < 0)	//	ȷ��PSFAscii��·��PG���ݿ��д���
		{
			memset(m_PSFLineArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		nOffSubI=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFLineArray[nOff].nBus1Index].szSubstation);
		nOffSubJ=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFLineArray[nOff].nBus2Index].szSubstation);
		if (nOffSubI < 0 || nOffSubJ < 0)
		{
			memset(m_PSFLineArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		if (strcmp(m_SubstationArray[nOffSubI].szRTName, pPGBlock->m_ACLineSegmentArray[nFind].szSubI) == 0 && strcmp(m_SubstationArray[nOffSubJ].szRTName, pPGBlock->m_ACLineSegmentArray[nFind].szSubZ) == 0 ||
			strcmp(m_SubstationArray[nOffSubI].szRTName, pPGBlock->m_ACLineSegmentArray[nFind].szSubZ) == 0 && strcmp(m_SubstationArray[nOffSubJ].szRTName, pPGBlock->m_ACLineSegmentArray[nFind].szSubI) == 0)
		{

		}
		else
		{
			memset(m_PSFLineArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}
	}
	for (nOff=0; nOff<(int)m_PSFFixedTranArray.size(); nOff++)
	{
		if (strlen(m_PSFFixedTranArray[nOff].szRTName) <= 0)
			continue;
		if (m_PSFFixedTranArray[nOff].nBus1Index < 0 || m_PSFFixedTranArray[nOff].nBus2Index < 0)
		{
			memset(m_PSFFixedTranArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		nSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].szSubstation);
		if (nSub < 0)	//	ȷ��PSFAsciiĸ������PSFAscii��վ��PSFAscii���ݿ��д���
		{
			memset(m_PSFFixedTranArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}

		nFind=-1;
		for (nDev=pPGBlock->m_SubstationArray[nSub].pRWind; nDev<pPGBlock->m_SubstationArray[nSub+1].pRWind; nDev++)
		{
			sprintf(szBuf,"%s,%s",pPGBlock->m_TransformerWindingArray[nDev].szSub,pPGBlock->m_TransformerWindingArray[nDev].szName);
			if (strcmp(m_PSFFixedTranArray[nOff].szRTName, szBuf) == 0)
			{
				nFind=i;
				break;
			}
		}
		if (nFind < 0)
		{
			memset(m_PSFFixedTranArray[nOff].szRTName, 0, MDB_CHARLEN);
			continue;
		}
	}
}


void CPSFAscii::ReadPSFAscii2CimMatch(const char* lpszFileName)
{
	register int	i;
	int		nData;

	tagPG2PSFMatch	dBuf;

	m_PG2PSFMatchArray.clear();

	FILE*	fp;
	fp=fopen(lpszFileName,"r");
	if (fp == NULL)
		return;

	char*	lpszToken;
	char	szLine[1024];
	std::vector<std::string>	strEleArray;
	while (!feof(fp))
	{
		memset(szLine,0,1024);
		fgets(szLine, 1024, fp);

		if (strlen(szLine) <= 0)
			continue;

		strEleArray.clear();

		lpszToken=strtok(szLine, " \t\n");
		while (lpszToken != NULL)
		{
			strEleArray.push_back(lpszToken);
			lpszToken=strtok(NULL, " \t\n");
		}
		if (strEleArray.size() >= 2)
		{
			dBuf.nPSFType=atoi(strEleArray[0].c_str());
			strcpy(dBuf.szPSFKey, strEleArray[1].c_str());
			strcpy(dBuf.szPGKey, strEleArray[2].c_str());
			if (dBuf.nPSFType == PSFModel_Substation || 
				dBuf.nPSFType == PSFModel_Generator ||
				dBuf.nPSFType == PSFModel_Line ||
				dBuf.nPSFType == PSFModel_FixedTransformer)
				m_PG2PSFMatchArray.push_back(dBuf);
		}
	}

	fclose(fp);

	for (i=0; i<(int)m_SubstationArray.size(); i++)
		memset(m_SubstationArray[i].szRTName, 0, MDB_CHARLEN);
	for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
		memset(m_PSFGeneratorArray[i].szRTName, 0, MDB_CHARLEN);
	for (i=0; i<(int)m_PSFLoadArray.size(); i++)
		memset(m_PSFLoadArray[i].szRTName, 0, MDB_CHARLEN);
	for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
		memset(m_PSFFixedShuntArray[i].szRTName, 0, MDB_CHARLEN);
	for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
		memset(m_PSFSwitchableShuntArray[i].szRTName, 0, MDB_CHARLEN);
	for (i=0; i<(int)m_PSFLineArray.size(); i++)
		memset(m_PSFLineArray[i].szRTName, 0, MDB_CHARLEN);
	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
		memset(m_PSFFixedTranArray[i].szRTName, 0, MDB_CHARLEN);

	for (nData=0; nData<(int)m_PG2PSFMatchArray.size(); nData++)
	{
		switch (m_PG2PSFMatchArray[nData].nPSFType)
		{
		case PSFModel_Substation:
			for (i=0; i<(int)m_SubstationArray.size(); i++)
			{
				if (strcmp(m_SubstationArray[i].szName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_SubstationArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		case	PSFModel_Generator:
			for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
			{
				if (strcmp(m_PSFGeneratorArray[i].szBusName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_PSFGeneratorArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		case	PSFModel_Load:
			for (i=0; i<(int)m_PSFLoadArray.size(); i++)
			{
				if (strcmp(m_PSFLoadArray[i].szBusName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_PSFLoadArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		case	PSFModel_FixedShunt:
			for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
			{
				if (strcmp(m_PSFFixedShuntArray[i].szBusName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_PSFFixedShuntArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		case	PSFModel_SwitchableShunt:
			for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
			{
				if (strcmp(m_PSFSwitchableShuntArray[i].szBusName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_PSFSwitchableShuntArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		case	PSFModel_Line:
			for (i=0; i<(int)m_PSFLineArray.size(); i++)
			{
				if (strcmp(m_PSFLineArray[i].szPSFName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_PSFLineArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		case	PSFModel_FixedTransformer:
			for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
			{
				if (strcmp(m_PSFFixedTranArray[i].szPSFName, m_PG2PSFMatchArray[nData].szPSFKey) == 0)
				{
					strcpy(m_PSFFixedTranArray[i].szRTName, m_PG2PSFMatchArray[nData].szPGKey);
					break;
				}
			}
			break;
		}
	}
}

void CPSFAscii::SavePSFAscii2CimMatch(const char* lpszFileName)
{
	register int	i;
	tagPG2PSFMatch	dBuf;

	m_PG2PSFMatchArray.clear();

	memset(&dBuf, 0, sizeof(tagPG2PSFMatch));
	for (i=0; i<(int)m_SubstationArray.size(); i++)
	{
		if (strlen(m_SubstationArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Substation;
			strcpy(dBuf.szPSFKey, m_SubstationArray[i].szName);
			strcpy(dBuf.szPGKey, m_SubstationArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
	{
		if (strlen(m_PSFGeneratorArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Generator;
			strcpy(dBuf.szPSFKey, m_PSFGeneratorArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFGeneratorArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFLoadArray.size(); i++)
	{
		if (strlen(m_PSFLoadArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Load;
			strcpy(dBuf.szPSFKey, m_PSFLoadArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFLoadArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
	{
		if (strlen(m_PSFFixedShuntArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_FixedShunt;
			strcpy(dBuf.szPSFKey, m_PSFFixedShuntArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFFixedShuntArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
	{
		if (strlen(m_PSFSwitchableShuntArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_SwitchableShunt;
			strcpy(dBuf.szPSFKey, m_PSFSwitchableShuntArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFSwitchableShuntArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFLineArray.size(); i++)
	{
		if (strlen(m_PSFLineArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Line;
			strcpy(dBuf.szPSFKey, m_PSFLineArray[i].szPSFName);
			strcpy(dBuf.szPGKey, m_PSFLineArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
	{
		if (strlen(m_PSFFixedTranArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_FixedTransformer;
			strcpy(dBuf.szPSFKey, m_PSFFixedTranArray[i].szPSFName);
			strcpy(dBuf.szPGKey, m_PSFFixedTranArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}

	FILE*	fp;
	fp=fopen(lpszFileName,"w");
	if (fp == NULL)
		return;

	for (i=0; i<(int)m_PG2PSFMatchArray.size(); i++)
	{
		fprintf(fp,"%d ",m_PG2PSFMatchArray[i].nPSFType);
		fprintf(fp,"%s ",m_PG2PSFMatchArray[i].szPSFKey);
		fprintf(fp,"%s ",m_PG2PSFMatchArray[i].szPGKey);
		fprintf(fp,"\n");
	}

	fflush(fp);
	fclose(fp);
}

void CPSFAscii::AutoPSFAscii2CimMatch(tagPGBlock* pPGBlock, const int bMatchAll)
{
	std::vector<std::string>	strFilterZoneArray;
	strFilterZoneArray.clear();
	AutoPSFAscii2CimMatch(pPGBlock, bMatchAll, strFilterZoneArray);
}

void CPSFAscii::AutoPSFAscii2CimMatch(tagPGBlock* pPGBlock, const int bMatchAll, std::vector<std::string> strFilterZoneArray)
{
	register int	i;
	int		nData,nOff,nOffSub,nFind;
	int		nRTSub,nVolt,nSubI,nSubJ,nVoltI,nVoltJ;
	char	szBuf[MDB_CHARLEN_LONG];

	CheckOffline2RTMatch(pPGBlock);

	std::vector<unsigned char>	bBusProcArray,bProcArray;

	bBusProcArray.resize(pPGBlock->m_nRecordNum[PG_BUSBARSECTION]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nData++)
		bBusProcArray[nData]=0;

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nData++)
		bProcArray[nData]=0;

	//	������Զ����գ�
	//		����ͨ��ĸ���ҵ����������Ӧ��PSF��վ
	//		��PSF��վ�ҵ���Ӧ��PG��վ
	//		��PG��վ�з��������ѹ�ȼ���Ӧ��PSF��
	//Log("������Զ���Ӧ\n");
	for (nOff=0; nOff<(int)m_PSFGeneratorArray.size(); nOff++)
	{
		if (m_PSFGeneratorArray[nOff].nBusIndex < 0)
			continue;
		if (!bMatchAll)
		{
			if (strlen(m_PSFGeneratorArray[nOff].szRTName) > 0)
				continue;
		}

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)strFilterZoneArray.size(); i++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].nNumber, strFilterZoneArray[i].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
				continue;
		}

		//Log("    �����=%s\n",m_PSFGeneratorArray[nOff].szBusName);

		nOffSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].szSubstation);
		if (nOffSub < 0)
			continue;
		if (strlen(m_SubstationArray[nOffSub].szRTName) <= 0)
			continue;

		nRTSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nOffSub].szRTName);
		if (nRTSub < 0)
			continue;

		//Log("        PSF��վ=%s RTName=%s\n",m_SubstationArray[nOffSub].szName,m_SubstationArray[nOffSub].szRTName);

		nFind=0;
		for (nVolt=pPGBlock->m_SubstationArray[nRTSub].pRkv; nVolt<pPGBlock->m_SubstationArray[nRTSub+1].pRkv; nVolt++)
		{
			for (i=pPGBlock->m_VoltageLevelArray[nVolt].pRun; i<pPGBlock->m_VoltageLevelArray[nVolt+1].pRun; i++)
			{
				sprintf(szBuf, "%s,%s,%s",pPGBlock->m_SynchronousMachineArray[i].szSub,pPGBlock->m_SynchronousMachineArray[i].szVolt,pPGBlock->m_SynchronousMachineArray[i].szName);
				//Log("            �����=%s PSFVolt=%f PGVolt=%f\n",szBuf,m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].fkV,pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);

				if (fabs(m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].fkV-pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage) > pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage/2)
					continue;
				if (bProcArray[i])
					continue;

				strcpy(m_PSFGeneratorArray[nOff].szRTName, szBuf);
				bProcArray[i]=1;
				nFind=1;
				break;
			}
			if (nFind)
				break;
		}
	}

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nData++)
		bProcArray[nData]=0;

	//Log("��·�Զ���Ӧ\n");
	for (nOff=0; nOff<(int)m_PSFLineArray.size(); nOff++)
	{
		if (m_PSFLineArray[nOff].nBus1Index < 0 || m_PSFLineArray[nOff].nBus2Index < 0)
			continue;
		if (!bMatchAll)
		{
			if (strlen(m_PSFLineArray[nOff].szRTName) > 0)
				continue;
		}

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)strFilterZoneArray.size(); i++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFLineArray[nOff].nBus1Index].nNumber, strFilterZoneArray[i].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
			{
				for (i=0; i<(int)strFilterZoneArray.size(); i++)
				{
					if (IsBusInZone(m_PSFBusArray[m_PSFLineArray[nOff].nBus2Index].nNumber, strFilterZoneArray[i].c_str()))
					{
						nFind=1;
						break;
					}
				}
			}

			if (!nFind)
				continue;
		}

		//Log("    ��·=%s\n",m_PSFLineArray[nOff].szPSFName);

		nSubI=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFLineArray[nOff].nBus1Index].szSubstation);
		nSubJ=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFLineArray[nOff].nBus2Index].szSubstation);
		if (nSubI < 0 || nSubJ < 0)
			continue;
		if (strlen(m_SubstationArray[nSubI].szRTName) <= 0 || strlen(m_SubstationArray[nSubJ].szRTName) <= 0)
			continue;

		//Log("        PSF��վI=%s RTName=%s PSF��վJ=%s RTName=%s\n",m_SubstationArray[nSubI].szName,m_SubstationArray[nSubI].szRTName,m_SubstationArray[nSubJ].szName,m_SubstationArray[nSubJ].szRTName);

		for (nData=0; nData<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nData++)
		{
			if (bProcArray[nData])
				continue;
			if ((strcmp(m_SubstationArray[nSubI].szRTName, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0 && strcmp(m_SubstationArray[nSubJ].szRTName, pPGBlock->m_ACLineSegmentArray[nData].szSubZ) == 0) ||
				(strcmp(m_SubstationArray[nSubI].szRTName, pPGBlock->m_ACLineSegmentArray[nData].szSubZ) == 0 && strcmp(m_SubstationArray[nSubJ].szRTName, pPGBlock->m_ACLineSegmentArray[nData].szSubI) == 0))
			{
				//Log("            ��·��Ӧ=%s\n",pPGBlock->m_ACLineSegmentArray[nData].szName);

				strcpy(m_PSFLineArray[nOff].szRTName, pPGBlock->m_ACLineSegmentArray[nData].szName);
				bProcArray[nData]=1;
				break;
			}
		}
	}

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]);
	for (nData=0; nData<pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nData++)
		bProcArray[nData]=0;

	for (nOff=0; nOff<(int)m_PSFFixedTranArray.size(); nOff++)
	{
		if (m_PSFFixedTranArray[nOff].nBus1Index < 0 || m_PSFFixedTranArray[nOff].nBus2Index < 0)
			continue;
		if (!bMatchAll)
		{
			if (strlen(m_PSFFixedTranArray[nOff].szRTName) > 0)
				continue;
		}

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)strFilterZoneArray.size(); i++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].nNumber, strFilterZoneArray[i].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
			{
				for (i=0; i<(int)strFilterZoneArray.size(); i++)
				{
					if (IsBusInZone(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].nNumber, strFilterZoneArray[i].c_str()))
					{
						nFind=1;
						break;
					}
				}
			}

			if (!nFind)
				continue;
		}

		nOffSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].szSubstation);
		if (nOffSub < 0)
			continue;

		nRTSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nOffSub].szRTName);
		if (nRTSub < 0)
			continue;

		nFind=-1;
		for (nData=pPGBlock->m_SubstationArray[nRTSub].pRWind; nData<pPGBlock->m_SubstationArray[nRTSub+1].pRWind; nData++)
		{
			if (bProcArray[nData])
				continue;

			nVoltI=PGGetVoltIndex(pPGBlock, pPGBlock->m_SubstationArray[nRTSub].szName, pPGBlock->m_TransformerWindingArray[nData].szVoltI);
			nVoltJ=PGGetVoltIndex(pPGBlock, pPGBlock->m_SubstationArray[nRTSub].szName, pPGBlock->m_TransformerWindingArray[nData].szVoltZ);
			if (m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].bTransformerNeutral)
			{
				if (fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV) < m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV/10 ||
					fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV) < m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV/10)
				{
					sprintf(szBuf, "%s,%s", pPGBlock->m_TransformerWindingArray[nData].szSub, pPGBlock->m_TransformerWindingArray[nData].szName);
					strcpy(m_PSFFixedTranArray[nOff].szRTName, szBuf);
					nFind=nData;
					bProcArray[nData]=1;
					break;
				}
			}
			else
			{
				if (fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].fkV) < m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].fkV/10 && fabs(pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV) < m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV/10 ||
					fabs(pPGBlock->m_VoltageLevelArray[nVoltJ].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].fkV) < m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].fkV/10 && fabs(pPGBlock->m_VoltageLevelArray[nVoltI].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV) < m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV/10)
				{
					sprintf(szBuf, "%s,%s", pPGBlock->m_TransformerWindingArray[nData].szSub, pPGBlock->m_TransformerWindingArray[nData].szName);
					strcpy(m_PSFFixedTranArray[nOff].szRTName, szBuf);

					nFind=nData;
					bProcArray[nData]=1;
					break;
				}
			}
		}
	}

	tagPG2PSFMatch	dBuf;
	m_PG2PSFMatchArray.clear();
	memset(&dBuf, 0, sizeof(tagPG2PSFMatch));
	for (i=0; i<(int)m_SubstationArray.size(); i++)
	{
		if (strlen(m_SubstationArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Substation;
			strcpy(dBuf.szPSFKey, m_SubstationArray[i].szName);
			strcpy(dBuf.szPGKey, m_SubstationArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
	{
		if (strlen(m_PSFGeneratorArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Generator;
			strcpy(dBuf.szPSFKey, m_PSFGeneratorArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFGeneratorArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFLoadArray.size(); i++)
	{
		if (strlen(m_PSFLoadArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Load;
			strcpy(dBuf.szPSFKey, m_PSFLoadArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFLoadArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
	{
		if (strlen(m_PSFFixedShuntArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_FixedShunt;
			strcpy(dBuf.szPSFKey, m_PSFFixedShuntArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFFixedShuntArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
	{
		if (strlen(m_PSFSwitchableShuntArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_SwitchableShunt;
			strcpy(dBuf.szPSFKey, m_PSFSwitchableShuntArray[i].szBusName);
			strcpy(dBuf.szPGKey, m_PSFSwitchableShuntArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFLineArray.size(); i++)
	{
		if (strlen(m_PSFLineArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_Line;
			strcpy(dBuf.szPSFKey, m_PSFLineArray[i].szPSFName);
			strcpy(dBuf.szPGKey, m_PSFLineArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
	{
		if (strlen(m_PSFFixedTranArray[i].szRTName) > 0)
		{
			dBuf.nPSFType=PSFModel_FixedTransformer;
			strcpy(dBuf.szPSFKey, m_PSFFixedTranArray[i].szPSFName);
			strcpy(dBuf.szPGKey, m_PSFFixedTranArray[i].szRTName);

			m_PG2PSFMatchArray.push_back(dBuf);
		}
	}
}

void CPSFAscii::CheckPGBusLineMatched(tagPGBlock* pPGBlock)
{
	register int	i;
	int		nSub,nVolt,nDev,nNode;
	int		nNodeNum,nNodeArray[400];
	unsigned char	bHasMatchedLine;

	std::vector<unsigned char> bProcArray;

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_BUSBARSECTION]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		bProcArray[i]=0;
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].pRkv; nVolt<pPGBlock->m_SubstationArray[nSub+1].pRkv; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].pRbus; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].pRbus; nDev++)
			{
				if (pPGBlock->m_BusbarSectionArray[nDev].iRnd < 0)
					continue;
				if (bProcArray[nDev])
					continue;

				bHasMatchedLine=0;
				PGTraverseVolt(pPGBlock, pPGBlock->m_BusbarSectionArray[nDev].iRnd, N_CheckStatus, N_CheckStatus, N_BusBound, N_BreakerBound, nNodeNum, nNodeArray);
				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].pRAcln2; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].pRAcln2; i++)
					{
						if (IsCimDeviceMatched(PSFModel_Line, pPGBlock->m_ACLineSegmentArray[pPGBlock->m_ACLineSegment2Array[i].iRln].szName))
						{
							bHasMatchedLine=1;
							break;
						}
					}
				}

				for (nNode=0; nNode<nNodeNum; nNode++)
				{
					if (pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].iRbus >= 0)
					{
						bProcArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].iRbus]=1;
						if (bHasMatchedLine)
						{
							pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].iRbus].fLoadP=pPGBlock->m_BusbarSectionArray[pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].iRbus].fLoadQ=0;
						}
					}
				}
			}
		}
	}
}
