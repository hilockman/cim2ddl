#include "StdAfx.h"
#include <float.h>
#include "PSFAscii.h"

void	CPSFAscii::PGMemDBGeneratorYC2PSFAscii(tagPGBlock* pPGBlock, const std::vector<std::string> strFilterZoneArray)
{
	register int	i;
	int		nVolt,nDev,nRTSub;
	int		nOff,nOffSub;
	int		nFind;
	char	szDevName[MDB_CHARLEN_LONG];

	for (nOff=0; nOff<(int)m_PSFGeneratorArray.size(); nOff++)
	{
		m_PSFGeneratorArray[nOff].fRTMW=m_PSFGeneratorArray[nOff].fRTMVar=0;
		m_PSFGeneratorArray[nOff].fRTVoltage=1;
		m_PSFGeneratorArray[nOff].nRTStatus=0;
		m_PSFGeneratorArray[nOff].bRTDataSetted=0;
	}

	for (nOff=0; nOff<(int)m_PSFGeneratorArray.size(); nOff++)
	{
		if (m_PSFGeneratorArray[nOff].nBusIndex < 0)
			continue;

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)strFilterZoneArray.size(); i++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].nNumber, strFilterZoneArray[i].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
				continue;
		}

		nOffSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].szSubstation);
		if (nOffSub < 0)
			continue;
		if (strlen(m_SubstationArray[nOffSub].szRTName) <= 0)
			continue;

		nRTSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nOffSub].szRTName);
		if (nRTSub < 0)
			continue;

		//Log("        PSF��վ=%s RTName=%s\n",m_SubstationArray[nOffSub].szName,m_SubstationArray[nOffSub].szRTName);

		nFind=0;
		for (nVolt=pPGBlock->m_SubstationArray[nRTSub].pRkv; nVolt<pPGBlock->m_SubstationArray[nRTSub+1].pRkv; nVolt++)
		{
			for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].pRun; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].pRun; nDev++)
			{
				sprintf(szDevName, "%s,%s,%s",pPGBlock->m_SynchronousMachineArray[nDev].szSub,pPGBlock->m_SynchronousMachineArray[nDev].szVolt,pPGBlock->m_SynchronousMachineArray[nDev].szName);
				if (strcmp(m_PSFGeneratorArray[nOff].szRTName, szDevName) == 0)
				{
					m_PSFGeneratorArray[nOff].fRTMW	=pPGBlock->m_SynchronousMachineArray[nDev].fPlanP;
					m_PSFGeneratorArray[nOff].fRTMVar	=pPGBlock->m_SynchronousMachineArray[nDev].fPlanQ;
					m_PSFGeneratorArray[nOff].bRTDataSetted=1;
					nFind=1;
					break;
				}
			}
			if (nFind)
				break;
		}
	}
}

void	CPSFAscii::PGMemDBFixedTransformer2PSFAscii(tagPGBlock* pPGBlock, const std::vector<std::string> strFilterZoneArray)
{
	register int	i;
	int		nVolt,nDev,nRTSub;
	int		nOff,nOffSub;
	int		nFind;
	char	szDevName[MDB_CHARLEN_LONG];

	for (nOff=0; nOff<(int)m_PSFFixedTranArray.size(); nOff++)
	{
		m_PSFFixedTranArray[nOff].fRTP1=
			m_PSFFixedTranArray[nOff].fRTQ1=
			m_PSFFixedTranArray[nOff].fRTP2=
			m_PSFFixedTranArray[nOff].fRTQ2=-999999;
		m_PSFFixedTranArray[nOff].fRTTap=m_PSFFixedTranArray[nOff].fONR;
		m_PSFFixedTranArray[nOff].nRTStatus=0;
		m_PSFFixedTranArray[nOff].bRTDataSetted=0;
	}
	for (nOff=0; nOff<(int)m_PSFFixedTranArray.size(); nOff++)
	{
		if (m_PSFFixedTranArray[nOff].nBus1Index < 0 || m_PSFFixedTranArray[nOff].nBus2Index < 0)
			continue;

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)strFilterZoneArray.size(); i++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].nNumber, strFilterZoneArray[i].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
			{
				for (i=0; i<(int)strFilterZoneArray.size(); i++)
				{
					if (IsBusInZone(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].nNumber, strFilterZoneArray[i].c_str()))
					{
						nFind=1;
						break;
					}
				}
			}

			if (!nFind)
				continue;
		}

		nOffSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].szSubstation);
		if (nOffSub < 0)
			continue;

		nRTSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nOffSub].szRTName);
		if (nRTSub < 0)
			continue;

		nFind=-1;
		for (nDev=pPGBlock->m_SubstationArray[nRTSub].pRWind; nDev<pPGBlock->m_SubstationArray[nRTSub+1].pRWind; nDev++)
		{
			sprintf(szDevName, "%s,%s", pPGBlock->m_TransformerWindingArray[nDev].szSub, pPGBlock->m_TransformerWindingArray[nDev].szName);
			if (strcmp(m_PSFFixedTranArray[nOff].szRTName, szDevName) == 0)
			{
				nVolt=PGGetVoltIndex(pPGBlock, pPGBlock->m_SubstationArray[nRTSub].szName, pPGBlock->m_TransformerWindingArray[nDev].szVoltI);
				if (pPGBlock->m_TransformerWindingArray[nDev].remove != 0)
				{
					m_PSFFixedTranArray[nOff].nRTStatus=1;
					m_PSFFixedTranArray[nOff].fRTP1=
						m_PSFFixedTranArray[nOff].fRTQ1=
						m_PSFFixedTranArray[nOff].fRTP2=
						m_PSFFixedTranArray[nOff].fRTQ2=0;
				}
				else
				{
					float	fTapRatio;
					if (PGGetTranRatio(pPGBlock, nDev, fTapRatio))
						m_PSFFixedTranArray[nOff].fRTTap=(float)fTapRatio;

					if (fabs(pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage-m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].fkV) < 5)
					{
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].pi) < 999990)	m_PSFFixedTranArray[nOff].fRTP1=pPGBlock->m_TransformerWindingArray[nDev].pi;
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].qi) < 999990)	m_PSFFixedTranArray[nOff].fRTQ1=pPGBlock->m_TransformerWindingArray[nDev].qi;
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].pz) < 999990)	m_PSFFixedTranArray[nOff].fRTP2=pPGBlock->m_TransformerWindingArray[nDev].pz;
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].qz) < 999990)	m_PSFFixedTranArray[nOff].fRTQ2=pPGBlock->m_TransformerWindingArray[nDev].qz;
					}
					else
					{
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].pz) < 999990)	m_PSFFixedTranArray[nOff].fRTP1=pPGBlock->m_TransformerWindingArray[nDev].pz;
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].qz) < 999990)	m_PSFFixedTranArray[nOff].fRTQ1=pPGBlock->m_TransformerWindingArray[nDev].qz;
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].pi) < 999990)	m_PSFFixedTranArray[nOff].fRTP2=pPGBlock->m_TransformerWindingArray[nDev].pi;
						if (fabs(pPGBlock->m_TransformerWindingArray[nDev].qi) < 999990)	m_PSFFixedTranArray[nOff].fRTQ2=pPGBlock->m_TransformerWindingArray[nDev].qi;
					}
				}

				m_PSFFixedTranArray[nOff].bRTDataSetted=1;
				break;
			}
		}
	}
}

void	CPSFAscii::PGMemDBLine2PSFAscii(tagPGBlock* pPGBlock, const std::vector<std::string> strFilterZoneArray)
{
	register int	i;
	int		nDev,nRTSub;
	int		nOff,nOffSub;
	int		nFind;

	for (nOff=0; nOff<(int)m_PSFLineArray.size(); nOff++)
	{
		m_PSFLineArray[nOff].fRTP1=
			m_PSFLineArray[nOff].fRTQ1=
			m_PSFLineArray[nOff].fRTP2=
			m_PSFLineArray[nOff].fRTQ2=-999999;
		m_PSFLineArray[nOff].nRTStatus=0;
		m_PSFLineArray[nOff].bRTDataSetted=0;
	}
	for (nOff=0; nOff<(int)m_PSFLineArray.size(); nOff++)
	{
		if (m_PSFLineArray[nOff].nBus1Index < 0 || m_PSFLineArray[nOff].nBus2Index < 0)
			continue;

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (i=0; i<(int)strFilterZoneArray.size(); i++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFLineArray[nOff].nBus1Index].nNumber, strFilterZoneArray[i].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
			{
				for (i=0; i<(int)strFilterZoneArray.size(); i++)
				{
					if (IsBusInZone(m_PSFBusArray[m_PSFLineArray[nOff].nBus2Index].nNumber, strFilterZoneArray[i].c_str()))
					{
						nFind=1;
						break;
					}
				}
			}

			if (!nFind)
				continue;
		}

		nOffSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFLineArray[nOff].nBus1Index].szSubstation);
		if (nOffSub < 0)
			continue;

		nRTSub=PGGetSubIndex(pPGBlock, m_SubstationArray[nOffSub].szRTName);
		if (nRTSub < 0)
			continue;

		nFind=-1;
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
		{
			if (strcmp(m_PSFLineArray[nOff].szRTName, pPGBlock->m_ACLineSegmentArray[nDev].szName) == 0)
			{
				if (pPGBlock->m_ACLineSegmentArray[nDev].remove != 0)
				{
					m_PSFLineArray[nOff].nRTStatus=1;
					m_PSFLineArray[nOff].fRTP1=
						m_PSFLineArray[nOff].fRTQ1=
						m_PSFLineArray[nOff].fRTP2=
						m_PSFLineArray[nOff].fRTQ2=0;
				}
				else
				{
					if (stricmp(pPGBlock->m_ACLineSegmentArray[nDev].szSubI, pPGBlock->m_SubstationArray[nRTSub].szName) == 0)
					{
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].pi) < 999990)	m_PSFLineArray[nOff].fRTP1=pPGBlock->m_ACLineSegmentArray[nDev].pi;
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].qi) < 999990)	m_PSFLineArray[nOff].fRTQ1=pPGBlock->m_ACLineSegmentArray[nDev].qi;
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].pz) < 999990)	m_PSFLineArray[nOff].fRTP2=pPGBlock->m_ACLineSegmentArray[nDev].pz;
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].qz) < 999990)	m_PSFLineArray[nOff].fRTQ2=pPGBlock->m_ACLineSegmentArray[nDev].qz;
					}
					else
					{
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].pz) < 999990)	m_PSFLineArray[nOff].fRTP1=pPGBlock->m_ACLineSegmentArray[nDev].pz;
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].qz) < 999990)	m_PSFLineArray[nOff].fRTQ1=pPGBlock->m_ACLineSegmentArray[nDev].qz;
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].pi) < 999990)	m_PSFLineArray[nOff].fRTP2=pPGBlock->m_ACLineSegmentArray[nDev].pi;
						if (fabs(pPGBlock->m_ACLineSegmentArray[nDev].qi) < 999990)	m_PSFLineArray[nOff].fRTQ2=pPGBlock->m_ACLineSegmentArray[nDev].qi;
					}
				}
				m_PSFLineArray[nOff].bRTDataSetted=1;
				break;
			}
		}
	}
}

void CPSFAscii::PSFAsciiTransformer2Load(const unsigned char bPlantNoLoad)
{
	register int	i;
	int		nOff,nDev,nTranMid,nOffSub;
	int		nMaxWind,nMidWind;
	float	fMaxVolt,fMidVolt;
	float	fP, fQ;
	std::vector<int>	nTranWindArray;
	std::vector<int>	nTranBusArray;
	std::vector<unsigned char>	bTranPMeasuredArray,bTranQMeasuredArray;
	std::vector<unsigned char>	bTranProcArray;

	bTranProcArray.resize(m_PSFFixedTranArray.size());
	for (i=0; i<(int)bTranProcArray.size(); i++)
		bTranProcArray[i]=0;

	for (nOff=0; nOff<(int)m_PSFFixedTranArray.size(); nOff++)
	{
		if (bTranProcArray[nOff])
			continue;
		bTranProcArray[nOff]=1;

		if (strlen(m_PSFFixedTranArray[nOff].szRTName) <= 0)
			continue;
		if (m_PSFFixedTranArray[nOff].nBus1Index < 0 || m_PSFFixedTranArray[nOff].nBus2Index < 0)
			continue;
		nOffSub=findSubstationByName(0, m_SubstationArray.size()-1, m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].szSubstation);
		if (nOffSub < 0)
			continue;
		if (bPlantNoLoad && m_SubstationArray[nOffSub].nType != 0)
			continue;

		if (m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].bTransformerNeutral || m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].bTransformerNeutral)					//	������
		{
			nTranWindArray.clear();
			nTranBusArray.clear();
			bTranPMeasuredArray.clear();
			bTranQMeasuredArray.clear();
			nTranMid=(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].bTransformerNeutral) ? m_PSFFixedTranArray[nOff].nBus1Index : m_PSFFixedTranArray[nOff].nBus2Index;

			for (nDev=0; nDev<(int)m_BusNobnArray[nTranMid].nFixedTransformerArray.size(); nDev++)
			{
				bTranProcArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]]=1;

				nTranWindArray.push_back(m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]);
				if (nTranMid == m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].nBus1Index)
				{
					nTranBusArray.push_back(m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].nBus2Index);
					if (fabs(m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].fRTP2) > 999990)
						bTranPMeasuredArray.push_back(0);
					else
						bTranPMeasuredArray.push_back(1);

					if (fabs(m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].fRTQ2) > 999990)
						bTranQMeasuredArray.push_back(0);
					else
						bTranQMeasuredArray.push_back(1);
				}
				else
				{
					nTranBusArray.push_back(m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].nBus1Index);
					if (fabs(m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].fRTP1) > 999990)
						bTranPMeasuredArray.push_back(0);
					else
						bTranPMeasuredArray.push_back(1);

					if (fabs(m_PSFFixedTranArray[m_BusNobnArray[nTranMid].nFixedTransformerArray[nDev]].fRTQ1) > 999990)
						bTranQMeasuredArray.push_back(0);
					else
						bTranQMeasuredArray.push_back(1);
				}
			}

			fMaxVolt=fMidVolt=0;
			nMaxWind=nMidWind=-1;
			for (nDev=0; nDev<(int)nTranBusArray.size(); nDev++)
			{
				if (fMaxVolt < m_PSFBusArray[nTranBusArray[nDev]].fkV)
				{
					fMaxVolt=m_PSFBusArray[nTranBusArray[nDev]].fkV;
					nMaxWind=nDev;
				}
			}
			for (nDev=0; nDev<(int)nTranBusArray.size(); nDev++)
			{
				if (nDev == nMaxWind)
					continue;
				if (fMidVolt < m_PSFBusArray[nTranBusArray[nDev]].fkV)
				{
					fMidVolt=m_PSFBusArray[nTranBusArray[nDev]].fkV;
					nMidWind=nDev;
				}
			}

			fP=fQ=0;
			if (bTranPMeasuredArray[nMaxWind])
			{
				fP=(!m_PSFBusArray[m_PSFFixedTranArray[nTranWindArray[nMaxWind]].nBus1Index].bTransformerNeutral) ? m_PSFFixedTranArray[nTranWindArray[nMaxWind]].fRTP1 : m_PSFFixedTranArray[nTranWindArray[nMaxWind]].fRTP2;

				Log("        ���ñ�ѹ�����й�����(H-M): %s [%f]\n",m_PSFFixedTranArray[nOff].szPSFName, fP);
				SetLoadPValue(nTranBusArray[nMidWind], 1, fP);
			}
			else
			{
				for (nDev=0; nDev<(int)nTranWindArray.size(); nDev++)
				{
					if (nDev == nMaxWind)
						continue;
					if (bTranPMeasuredArray[nDev])
					{
						fP=(!m_PSFBusArray[m_PSFFixedTranArray[nTranWindArray[nDev]].nBus1Index].bTransformerNeutral) ? m_PSFFixedTranArray[nTranWindArray[nDev]].fRTP1 : m_PSFFixedTranArray[nTranWindArray[nDev]].fRTP2;

						Log("        ���ñ�ѹ�����й�����(%d): %s [%f]\n",nDev,m_PSFFixedTranArray[nOff].szPSFName, -fP);
						if (!IsBusJointGenerator(nTranBusArray[nDev]))
							SetLoadPValue(nTranBusArray[nDev], 1, -fP);
					}
				}
			}

			if (bTranQMeasuredArray[nMaxWind])
			{
				fQ=(!m_PSFBusArray[m_PSFFixedTranArray[nTranWindArray[nMaxWind]].nBus1Index].bTransformerNeutral) ? m_PSFFixedTranArray[nTranWindArray[nMaxWind]].fRTQ1 : m_PSFFixedTranArray[nTranWindArray[nMaxWind]].fRTQ2;

				Log("        ���ñ�ѹ�����޹�����(H-M): %s [%f %f]\n",m_PSFFixedTranArray[nOff].szPSFName, fQ);
				SetLoadQValue(nTranBusArray[nMidWind], 1, fQ);
			}
			else
			{
				for (nDev=0; nDev<(int)nTranWindArray.size(); nDev++)
				{
					if (nDev == nMaxWind)
						continue;
					if (bTranQMeasuredArray[nDev])
					{
						fQ=(!m_PSFBusArray[m_PSFFixedTranArray[nTranWindArray[nDev]].nBus1Index].bTransformerNeutral) ? m_PSFFixedTranArray[nTranWindArray[nDev]].fRTQ1 : m_PSFFixedTranArray[nTranWindArray[nDev]].fRTQ2;

						Log("        ���ñ�ѹ�����޹�����(%d): %s [%f %f]\n",nDev,m_PSFFixedTranArray[nOff].szPSFName, -fQ);
						if (!IsBusJointGenerator(nTranBusArray[nDev]))
							SetLoadQValue(nTranBusArray[nDev], 1, -fQ);
					}
				}
			}
		}
		else
		{
			if (m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].fkV > m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].fkV)
			{
				fP=fQ=0;
				if (fabs(m_PSFFixedTranArray[nOff].fRTP2) < 999990)
					fP=-m_PSFFixedTranArray[nOff].fRTP2;
				else if (fabs(m_PSFFixedTranArray[nOff].fRTP1) < 999990)
					fP=m_PSFFixedTranArray[nOff].fRTP1;

				if (fabs(m_PSFFixedTranArray[nOff].fRTQ2) < 999990)
					fQ=-m_PSFFixedTranArray[nOff].fRTQ2;
				else if (fabs(m_PSFFixedTranArray[nOff].fRTQ1) < 999990)
					fQ=m_PSFFixedTranArray[nOff].fRTQ1;

				Log("        ���ñ�ѹ���¸���(1): %s [%f %f]\n",m_PSFFixedTranArray[nOff].szPSFName, fP, fQ);
				if (!IsBusJointGenerator(m_PSFFixedTranArray[nOff].nBus2Index))
				{
					SetLoadPValue(m_PSFFixedTranArray[nOff].nBus2Index, 1, fP);
					SetLoadQValue(m_PSFFixedTranArray[nOff].nBus2Index, 1, fQ);
				}
			}
			else
			{
				fP=fQ=0;
				if (fabs(m_PSFFixedTranArray[nOff].fRTP1) < 999990)
					fP=-m_PSFFixedTranArray[nOff].fRTP1;
				else if (fabs(m_PSFFixedTranArray[nOff].fRTP2) < 999990)
					fP=m_PSFFixedTranArray[nOff].fRTP2;

				if (fabs(m_PSFFixedTranArray[nOff].fRTQ1) < 999990)
					fQ=-m_PSFFixedTranArray[nOff].fRTQ1;
				else if (fabs(m_PSFFixedTranArray[nOff].fRTQ2) < 999990)
					fQ=m_PSFFixedTranArray[nOff].fRTQ2;

				Log("        ���ñ�ѹ���¸���(2): %s [%f %f]\n",m_PSFFixedTranArray[nOff].szPSFName, fP, fQ);
				if (!IsBusJointGenerator(m_PSFFixedTranArray[nOff].nBus1Index))
				{
					SetLoadPValue(m_PSFFixedTranArray[nOff].nBus1Index, 1, fP);
					SetLoadQValue(m_PSFFixedTranArray[nOff].nBus1Index, 1, fQ);
				}
			}
		}
	}
}

int CPSFAscii::IsBusJointGenerator(const int nStartBus)
{
	register int	i;
	std::vector<int>	nBusArray;
	TraverseVolt(nStartBus, 0, 0, nBusArray);
	for (i=0; i<(int)nBusArray.size(); i++)
	{
		if (!m_BusNobnArray[nBusArray[i]].nGeneratorArray.empty())
			return 1;
	}

	return 0;
}

void	CPSFAscii::SetLoadPValue(const int nTranBus, const unsigned char bLineRevise, const float fTranValue)
{
	register int	i;
	std::vector<int>	nTranBusArray;
	std::vector<unsigned char>	bProcArray;
	int		nBus;
	float	fLineValue;

	TraverseVolt(nTranBus, 0, 0, nTranBusArray);

	fLineValue=0;
	for (nBus=0; nBus<(int)nTranBusArray.size(); nBus++)
	{
		for (i=0; i<(int)m_BusNobnArray[nTranBusArray[nBus]].nLineArray.size(); i++)
		{
			if (m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].nBus1Index == nBus)
			{
				if (fabs(m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTP1) < 999990)
					fLineValue -= m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTP1;
			}
			else
			{
				if (fabs(m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTP2) < 999990)
					fLineValue -= m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTP2;
			}
		}
	}

	int		nLoadNum=0;
	for (nBus=0; nBus<(int)nTranBusArray.size(); nBus++)
	{
		for (i=0; i<(int)m_BusNobnArray[nTranBusArray[nBus]].nLoadArray.size(); i++)
			nLoadNum++;
	}

	Log("        ��·�����й��ܼ�[%f] ������=%d\n",fLineValue, nLoadNum);
	if (nLoadNum > 0)
	{
		for (nBus=0; nBus<(int)nTranBusArray.size(); nBus++)
		{
			for (i=0; i<(int)m_BusNobnArray[nTranBusArray[nBus]].nLoadArray.size(); i++)
			{
				m_PSFLoadArray[m_BusNobnArray[nTranBusArray[nBus]].nLoadArray[i]].fRTP += (fTranValue+fLineValue)/nLoadNum;
				Log("                ���ø����й�����[%s] [%f]\n",m_PSFLoadArray[m_BusNobnArray[nTranBusArray[nBus]].nLoadArray[i]].szBusName, (fTranValue+fLineValue)/nLoadNum);
			}
		}
	}
}

void	CPSFAscii::SetLoadQValue(const int nTranBus, const unsigned char bLineRevise, const float fTranValue)
{
	register int	i;
	std::vector<int>	nTranBusArray;
	std::vector<unsigned char>	bProcArray;
	int		nBus;
	float	fLineValue;

	TraverseVolt(nTranBus, 0, 0, nTranBusArray);

	fLineValue=0;
	for (nBus=0; nBus<(int)nTranBusArray.size(); nBus++)
	{
		for (i=0; i<(int)m_BusNobnArray[nTranBusArray[nBus]].nLineArray.size(); i++)
		{
			if (m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].nBus1Index == nBus)
			{
				if (fabs(m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTQ1) < 999990)
					fLineValue -= m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTQ1;
			}
			else
			{
				if (fabs(m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTQ2) < 999990)
					fLineValue -= m_PSFLineArray[m_BusNobnArray[nTranBusArray[nBus]].nLineArray[i]].fRTQ2;
			}
		}
	}

	int		nLoadNum=0;
	for (nBus=0; nBus<(int)nTranBusArray.size(); nBus++)
	{
		for (i=0; i<(int)m_BusNobnArray[nTranBusArray[nBus]].nLoadArray.size(); i++)
			nLoadNum++;
	}
	Log("        ��·�����޹��ܼ�[%f] ������=%d\n",fLineValue, nLoadNum);
	if (nLoadNum > 0)
	{
		for (nBus=0; nBus<(int)nTranBusArray.size(); nBus++)
		{
			for (i=0; i<(int)m_BusNobnArray[nTranBusArray[nBus]].nLoadArray.size(); i++)
			{
				m_PSFLoadArray[m_BusNobnArray[nTranBusArray[nBus]].nLoadArray[i]].fRTQ += (fTranValue+fLineValue)/nLoadNum;
				Log("                ���ø����޹�����[%s] [%f]\n",m_PSFLoadArray[m_BusNobnArray[nTranBusArray[nBus]].nLoadArray[i]].szBusName, (fTranValue+fLineValue)/nLoadNum);
			}
		}
	}
}

//	���磬����
//	�����г��õ粻��ԭ�е�
int	CPSFAscii::PGMemDB2PSFAscii(tagPGBlock* pPGBlock, const unsigned char bSetPlantLoad, const char* lpszMatchFileName, std::vector<std::string> strFilterZoneArray)
{
	ReadPSFAscii2CimMatch(lpszMatchFileName);
	AutoPSFAscii2CimMatch(pPGBlock, 1, strFilterZoneArray);

	PGMemDBTopo(pPGBlock);
	PGMemDBStatus(pPGBlock);

	PGMemDBGeneratorYC2PSFAscii		(pPGBlock, strFilterZoneArray);	//	��������ڴ��������������
	PGMemDBFixedTransformer2PSFAscii(pPGBlock, strFilterZoneArray);	//	����ѹ���ڴ��������������
	PGMemDBLine2PSFAscii			(pPGBlock, strFilterZoneArray);	//	����·�ڴ��������������
	PSFAsciiTransformer2Load		(bSetPlantLoad);

	ResolvePSFAsciiBusGenLoadStatus	(strFilterZoneArray);

	return 1;
}


void	CPSFAscii::ResolvePSFAsciiBusGenLoadStatus(std::vector<std::string> strFilterZoneArray)
{
	register int	i,j;
	int		nOff,nFind;
	std::vector<int>	nJointBusArray;
	std::vector<short>	nBusGroupArray;
	int		nGroup,nMaxGroup;
	float	fGroupMva,fMaxGroupMva;

	nBusGroupArray.resize(m_PSFBusArray.size());
	for (i=0; i<(int)nBusGroupArray.size(); i++)
		nBusGroupArray[i]=-1;
	nGroup=1;
	nMaxGroup=-1;
	fMaxGroupMva=0;

	for (nOff=0; nOff<(int)m_PSFGeneratorArray.size(); nOff++)
	{
		if (m_PSFGeneratorArray[nOff].nBusIndex < 0)
			continue;
		if (nBusGroupArray[m_PSFGeneratorArray[nOff].nBusIndex] >= 0)
			continue;

		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (j=0; j<(int)strFilterZoneArray.size(); j++)
			{
				if (IsBusInZone(m_PSFBusArray[m_PSFGeneratorArray[nOff].nBusIndex].nNumber, strFilterZoneArray[j].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
				continue;
		}

		TraverseNet(m_PSFGeneratorArray[nOff].nBusIndex, 1, nJointBusArray);
		fGroupMva=0;
		for (i=0; i<(int)nJointBusArray.size(); i++)
		{
			nBusGroupArray[nJointBusArray[i]]=nGroup;
			for (j=0; j<(int)m_BusNobnArray[nJointBusArray[i]].nGeneratorArray.size(); j++)
				fGroupMva += m_PSFGeneratorArray[m_BusNobnArray[nJointBusArray[i]].nGeneratorArray[j]].fPMax;
		}
		if (fGroupMva > fMaxGroupMva)
		{
			fMaxGroupMva=fGroupMva;
			nMaxGroup=nGroup;
		}

		nGroup++;
	}

	for (i=0; i<(int)m_PSFBusArray.size(); i++)
		m_PSFBusArray[i].nRTStatus=0;
	for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
		m_PSFGeneratorArray[i].nRTStatus=0;
	for (i=0; i<(int)m_PSFLoadArray.size(); i++)
		m_PSFLoadArray[i].nRTStatus=0;
	for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
		m_PSFFixedShuntArray[i].nRTStatus=0;
	for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
		m_PSFSwitchableShuntArray[i].nRTStatus=0;

// 	for (i=0; i<(int)m_PSFLineArray.size(); i++)
// 		m_PSFLineArray[i].nRTStatus=0;
// 	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
// 		m_PSFFixedTranArray[i].nRTStatus=0;

	for (i=0; i<(int)m_PSFBusArray.size(); i++)
	{
		if (!strFilterZoneArray.empty())
		{
			nFind=0;
			for (j=0; j<(int)strFilterZoneArray.size(); j++)
			{
				if (IsBusInZone(m_PSFBusArray[i].nNumber, strFilterZoneArray[j].c_str()))
				{
					nFind=1;
					break;
				}
			}
			if (!nFind)
				continue;
		}
		if (nBusGroupArray[i] != nMaxGroup)
		{
			m_PSFBusArray[i].nRTStatus=1;
			for (j=0; j<(int)m_BusNobnArray[i].nGeneratorArray.size(); j++)
				m_PSFGeneratorArray[m_BusNobnArray[i].nGeneratorArray[j]].nRTStatus=1;
			for (j=0; j<(int)m_BusNobnArray[i].nLoadArray.size(); j++)
				m_PSFLoadArray[m_BusNobnArray[i].nLoadArray[j]].nRTStatus=1;
			for (j=0; j<(int)m_BusNobnArray[i].nFixedShuntArray.size(); j++)
				m_PSFFixedShuntArray[m_BusNobnArray[i].nFixedShuntArray[j]].nRTStatus=1;
			for (j=0; j<(int)m_BusNobnArray[i].nSwitchableShuntArray.size(); j++)
				m_PSFSwitchableShuntArray[m_BusNobnArray[i].nSwitchableShuntArray[j]].nRTStatus=1;

			for (j=0; j<(int)m_BusNobnArray[i].nLineArray.size(); j++)
				m_PSFLineArray[m_BusNobnArray[i].nLineArray[j]].nRTStatus=1;

			for (j=0; j<(int)m_BusNobnArray[i].nFixedTransformerArray.size(); j++)
				m_PSFFixedTranArray[m_BusNobnArray[i].nFixedTransformerArray[j]].nRTStatus=1;
		}
	}

// 	for (i=0; i<(int)m_PSFLineArray.size(); i++)
// 	{
// 		if (m_PSFLineArray[i].nRTStatus != 0)
// 			continue;
// 		if (!strFilterZoneArray.empty())
// 		{
// 			nFind=0;
// 			for (j=0; j<(int)strFilterZoneArray.size(); j++)
// 			{
// 				if (IsBusInZone(m_PSFBusArray[m_PSFLineArray[nOff].nBus1Index].nNumber, strFilterZoneArray[j].c_str()))
// 				{
// 					nFind=1;
// 					break;
// 				}
// 			}
// 			if (!nFind)
// 			{
// 				for (j=0; j<(int)strFilterZoneArray.size(); j++)
// 				{
// 					if (IsBusInZone(m_PSFBusArray[m_PSFLineArray[nOff].nBus2Index].nNumber, strFilterZoneArray[j].c_str()))
// 					{
// 						nFind=1;
// 						break;
// 					}
// 				}
// 			}
// 
// 			if (!nFind)
// 				continue;
// 		}
// 
// 		if (nBusGroupArray[m_PSFLineArray[i].nBus1Index] != nMaxGroup ||
// 			nBusGroupArray[m_PSFLineArray[i].nBus2Index] != nMaxGroup)
// 			m_PSFLineArray[i].nRTStatus=1;
// 	}
// 	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
// 	{
// 		if (m_PSFFixedTranArray[i].nRTStatus != 0)
// 			continue;
// 
// 		if (!strFilterZoneArray.empty())
// 		{
// 			nFind=0;
// 			for (j=0; j<(int)strFilterZoneArray.size(); j++)
// 			{
// 				if (IsBusInZone(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus1Index].nNumber, strFilterZoneArray[j].c_str()))
// 				{
// 					nFind=1;
// 					break;
// 				}
// 			}
// 			if (!nFind)
// 			{
// 				for (j=0; j<(int)strFilterZoneArray.size(); j++)
// 				{
// 					if (IsBusInZone(m_PSFBusArray[m_PSFFixedTranArray[nOff].nBus2Index].nNumber, strFilterZoneArray[j].c_str()))
// 					{
// 						nFind=1;
// 						break;
// 					}
// 				}
// 			}
// 
// 			if (!nFind)
// 				continue;
// 		}
// 		if (nBusGroupArray[m_PSFFixedTranArray[i].nBus1Index] != nMaxGroup ||
// 			nBusGroupArray[m_PSFFixedTranArray[i].nBus2Index] != nMaxGroup)
// 			m_PSFFixedTranArray[i].nRTStatus=1;
// 	}

	nJointBusArray.clear();
	nBusGroupArray.clear();
}
