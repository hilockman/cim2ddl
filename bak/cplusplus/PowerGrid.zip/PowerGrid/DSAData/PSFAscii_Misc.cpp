#include "StdAfx.h"
#include <float.h>
#include "PSFAscii.h"

int	CPSFAscii::isDigitalString(const char* lpszString)
{
	register int	i;
	for (i=0; i<(int)strlen(lpszString); i++)
	{
		if (lpszString[i] != '0' &&
			lpszString[i] != '1' &&
			lpszString[i] != '2' &&
			lpszString[i] != '3' &&
			lpszString[i] != '4' &&
			lpszString[i] != '5' &&
			lpszString[i] != '6' &&
			lpszString[i] != '7' &&
			lpszString[i] != '8' &&
			lpszString[i] != '9' &&
			lpszString[i] != '+' &&
			lpszString[i] != '-' &&
			lpszString[i] != '.')
			return 0;
	}
	return 1;
}

float CPSFAscii::str2Float(const unsigned char bCheckValidate, const int nTable, const int nField, const char* lpszString)
{
	float	fBuf=0;
	unsigned char	bValued=0;
	if (bCheckValidate)
	{
		if (nTable == PSFModel_Generator || nTable == PSFModel_FixedTransformer || nTable == PSFModel_Line)
		{
			if (!isDigitalString(lpszString))
			{
				if (nTable == PSFModel_Generator && nField == PSFGenerator_MW)					{	fBuf=0;	bValued=1;	}
				else if (nTable == PSFModel_Generator && nField == PSFGenerator_MVAR)			{	fBuf=0;	bValued=1;	}
				else if (nTable == PSFModel_FixedTransformer && nField == PSFFixedTransformer_R){	fBuf=0;	bValued=1;	}
				else if (nTable == PSFModel_FixedTransformer && nField == PSFFixedTransformer_X){	fBuf=1;	bValued=1;	}
				else if (nTable == PSFModel_Line && nField == PSFLine_R)						{	fBuf=0;	bValued=1;	}
				else if (nTable == PSFModel_Line && nField == PSFLine_X)						{	fBuf=1;	bValued=1;	}
			}
		}
	}

	if (!bValued)
		fBuf=(float)atof(lpszString);

	return fBuf;
}

int CPSFAscii::str2Integer(const unsigned char bCheckValidate, const int nTable, const int nField, const char* lpszString)
{
	int	nBuf;
	if (bCheckValidate)
	{
		nBuf=atoi(lpszString);
	}
	else
	{
		nBuf=atoi(lpszString);
	}
	return nBuf;
}

int	CPSFAscii::IsBusInZone(const int nBusNumber, const char* lpszZone)
{
	int		nBus=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, nBusNumber);
	if (nBus >= 0)
	{
		if (strcmp(m_PSFBusArray[nBus].szZoneName, lpszZone) == 0)
			return 1;
	}
	return 0;
}

int	CPSFAscii::IsBusInZone(const char* lpszBusName, const char* lpszZone)
{
	int		nBus;
	for (nBus=0; nBus<(int)m_PSFBusArray.size(); nBus++)
	{
		if (strcmp(m_PSFBusArray[nBus].szName, lpszBusName) != 0)
			continue;

		if (strcmp(m_PSFBusArray[nBus].szZoneName, lpszZone) == 0)
			return 1;
	}
	return 0;
}

void CPSFAscii::GetTieLine(std::vector<std::string>& strInAreaArray, std::vector<int>& nTLineArray)
{
	register int	i;
	int		nDev,nInAreaI,nInAreaJ;

	nTLineArray.clear();
	for (nDev=0; nDev<(int)m_PSFLineArray.size(); nDev++)
	{
		if (m_PSFLineArray[nDev].nBus1Index < 0 || m_PSFLineArray[nDev].nBus2Index < 0)
			continue;

		nInAreaI=nInAreaJ=0;
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(m_PSFBusArray[m_PSFLineArray[nDev].nBus1Index].szZoneName,strInAreaArray[i].c_str()) == 0)
			{
				nInAreaI=1;
				break;
			}
		}
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(m_PSFBusArray[m_PSFLineArray[nDev].nBus2Index].szZoneName,strInAreaArray[i].c_str()) == 0)
			{
				nInAreaJ=1;
				break;
			}
		}
		if (nInAreaI != nInAreaJ)
			nTLineArray.push_back(nDev);
	}
}


void CPSFAscii::GetTieLine(std::vector<std::string>& strInAreaArray, std::vector<int>& nTLineArray, std::vector<int>& nBoundBusArray)
{
	register int	i;
	int		nDev,nInAreaI,nInAreaJ;

	nTLineArray.clear();
	nBoundBusArray.clear();
	for (nDev=0; nDev<(int)m_PSFLineArray.size(); nDev++)
	{
		if (m_PSFLineArray[nDev].nBus1Index < 0 || m_PSFLineArray[nDev].nBus2Index < 0)
			continue;

		nInAreaI=nInAreaJ=0;
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(m_PSFBusArray[m_PSFLineArray[nDev].nBus1Index].szZoneName,strInAreaArray[i].c_str()) == 0)
			{
				nInAreaI=1;
				break;
			}
		}
		for (i=0; i<(int)strInAreaArray.size(); i++)
		{
			if (strcmp(m_PSFBusArray[m_PSFLineArray[nDev].nBus2Index].szZoneName,strInAreaArray[i].c_str()) == 0)
			{
				nInAreaJ=1;
				break;
			}
		}
		if (nInAreaI != nInAreaJ)
		{
			nTLineArray.push_back(nDev);
			if (nInAreaI)
				nBoundBusArray.push_back(m_PSFLineArray[nDev].nBus1Index);
			else
				nBoundBusArray.push_back(m_PSFLineArray[nDev].nBus2Index);
		}
	}
}

void	CPSFAscii::ParseLineString(const char* lpszLine, std::vector<std::string>& strEleArray)
{
	register int	i;
	int		nChar;
	unsigned char	bCharSection;
	char	szChar[MDB_CHARLEN_LONG];

	bCharSection=0;
	strEleArray.clear();
	nChar=0;
	i=0;
	while (i < (int)strlen(lpszLine))
	{
		if ((lpszLine[i] == '\0' || lpszLine[i] == ' ' || lpszLine[i] == '\t' || lpszLine[i] == '\r' || lpszLine[i] == '\n') && !bCharSection)
		{
			if (nChar > 0)
			{
				szChar[nChar++]='\0';
				//if (nChar >= MDB_CHARLEN_LONG)
				//	ASSERT(FALSE);
				strEleArray.push_back(szChar);
			}
			nChar=0;
		}
		else
		{
			if (lpszLine[i] == '\'')
			{
				if (bCharSection == 0)
				{
					bCharSection=1;
					nChar=0;
				}
				else
				{
					bCharSection=0;
					szChar[nChar++]='\0';
					//if (nChar >= MDB_CHARLEN_LONG)
					//	ASSERT(FALSE);
					strEleArray.push_back(szChar);
					nChar=0;
				}

			}
			else
			{
				if (!isascii(lpszLine[i]) && i < (int)strlen(lpszLine)-2)
				{
					szChar[nChar++]=lpszLine[i++];
					szChar[nChar++]=lpszLine[i];
				}
				else
				{
					szChar[nChar++]=lpszLine[i];
				}
			}
		}
		i++;
	}
	if (nChar > 0)
	{
		szChar[nChar++]='\0';
		//if (nChar >= MDB_CHARLEN_LONG)
		//	ASSERT(FALSE);
		strEleArray.push_back(szChar);
		nChar=0;
	}

// 	for (nChar=0; nChar<(int)strEleArray.size(); nChar++)
// 	{
// 		for (i=strEleArray[nChar].length()-1; i>=0; i--)
// 		{
// 			if (strEleArray[nChar][i] != ' ')
// 				break;
// 			strEleArray[nChar][i]='\0';
// 		}
// 	}
	// 	TRACE("Line=%s\n",lpszLine);
	// 	for (i=0; i<strEleArray.size(); i++)
	// 		TRACE("    %d/%d = %s\n", i, strEleArray.size(), strEleArray[i].c_str());
}

int		CPSFAscii::GetEnumValue(const char* lpszEnumName, int nEnumNum, const char* lpszEnumArray[])
{
	register int	i;
	char	szBuf[260];

	Trim(lpszEnumName, szBuf);
	for (i=0; i<nEnumNum; i++)
	{
		if (stricmp(lpszEnumArray[i], szBuf) == 0)
			return i;
	}
	return -1;
}

int		CPSFAscii::GetEnumValue(const char* lpszEnumName, int nEnumNum, const char cEnumArray[])
{
	register int	i;
	for (i=0; i<nEnumNum; i++)
	{
		if (cEnumArray[i] == lpszEnumName[0])
			return i;
	}
	return -1;
}

void CPSFAscii::sortBusDataByBusNumber(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	tagPSFBus	tagMid;
	int nDn = nDn0;
	int nUp = nUp0;

	memcpy(&tagMid,&m_PSFBusArray[(nDn0+nUp0)/2],sizeof(tagPSFBus));
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PSFBusArray[nDn].nNumber < tagMid.nNumber)
			++nDn;
		while (nUp > nDn0 && m_PSFBusArray[nUp].nNumber > tagMid.nNumber)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PSFBusArray[nDn],m_PSFBusArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBusDataByBusNumber(nDn0, nUp);

	if (nDn < nUp0 )
		sortBusDataByBusNumber(nDn, nUp0);
}

int	CPSFAscii::findBusDataByBusNumber(int nLeft, int nRight, const int nBusNumber)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (m_PSFBusArray[nMid].nNumber == nBusNumber)
		{
			return nMid;
		}
		else
		{
			if (m_PSFBusArray[nMid].nNumber > nBusNumber)
				return findBusDataByBusNumber(nLeft, nMid-1, nBusNumber);
			else
				return findBusDataByBusNumber(nMid+1, nRight, nBusNumber);
		}
	}
	else
		return -1;

	return -1;
}

void CPSFAscii::sortSubstationByName(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	char	szSubName[MDB_CHARLEN_TINY];
	int nDn = nDn0;
	int nUp = nUp0;

	strcpy(szSubName,m_SubstationArray[(nDn0+nUp0)/2].szName);
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && strcmp(m_SubstationArray[nDn].szName, szSubName) < 0)
			++nDn;
		while (nUp > nDn0 && strcmp(m_SubstationArray[nUp].szName, szSubName) > 0)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_SubstationArray[nDn],m_SubstationArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortSubstationByName(nDn0, nUp);

	if (nDn < nUp0 )
		sortSubstationByName(nDn, nUp0);
}

int	CPSFAscii::findSubstationByName(int nLeft, int nRight, const char* lpszSubstation)
{
	if (nLeft <= nRight)
	{
		int	nMid = (nLeft+nRight)/2;

		if (strcmp(m_SubstationArray[nMid].szName, lpszSubstation) == 0)
		{
			return nMid;
		}
		else
		{
			if (strcmp(m_SubstationArray[nMid].szName, lpszSubstation) > 0)
				return findSubstationByName(nLeft, nMid-1, lpszSubstation);
			else
				return findSubstationByName(nMid+1, nRight, lpszSubstation);
		}
	}
	else
		return -1;

	return -1;
}

void CPSFAscii::Trim(const char* lpszTrim, char* lpszRet)
{
	register int	i;
	int		bBlank,nChar;

	bBlank=1;
	nChar=0;
	for (i=0; i<(int)strlen(lpszTrim); i++)
	{
		if (bBlank)
		{
			if (lpszTrim[i] == ' ' || lpszTrim[i] == '\t' || lpszTrim[i] == '\r' || lpszTrim[i] == '\n')
				continue;
		}

		bBlank=0;
		lpszRet[nChar++]=lpszTrim[i];
	}
	lpszRet[nChar]='\0';

	for (i=strlen(lpszRet); i>=0; i--)
	{
		if (lpszRet[i] == '\0')
			continue;

		if (lpszRet[i] == ' ' || lpszRet[i] == '\t' || lpszRet[i] == '\r' || lpszRet[i] == '\n')
			lpszRet[i]='\0';
		else
			break;
	}
}

void CPSFAscii::TrimEnd(char* lpszTrim)
{
	register int	i;
	for (i=strlen(lpszTrim); i>=0; i--)
	{
		if (lpszTrim[i] == '\0')
			continue;

		if (lpszTrim[i] == ' ' || lpszTrim[i] == '\t' || lpszTrim[i] == '\r' || lpszTrim[i] == '\n')
			lpszTrim[i]='\0';
		else
			break;
	}
}

char*	CPSFAscii::FormularFloatString(float fValue)	const
{
	register int	i;
	unsigned char	bHasPoint;
	static	char	szFloat[260];

	sprintf(szFloat,"%f",fValue);
	bHasPoint=0;
	for (i=0; i<(int)strlen(szFloat); i++)
	{
		if (szFloat[i] == '.')
		{
			bHasPoint=1;
			break;
		}
	}
	if (bHasPoint)
	{
		for (i=strlen(szFloat)-1; i>=0; i--)
		{
			if (szFloat[i] == '0')
			{
				szFloat[i]='\0';
			}
			else if (szFloat[i] == '.')
			{
				szFloat[i]='\0';
				break;
			}
			else
			{
				break;
			}
		}
	}
	return szFloat;
}

void CPSFAscii::CompleteField()
{
	register int	i;
	for (i=0; i<(int)m_PSFLineArray.size(); i++)
	{
		if (m_PSFLineArray[i].szID[0] != ' ' && m_PSFLineArray[i].szID[0] != '\0')
			sprintf(m_PSFLineArray[i].szPSFName,"%s-%s@%s",m_PSFLineArray[i].szBus1Name,m_PSFLineArray[i].szBus2Name,m_PSFLineArray[i].szID);
		else
			sprintf(m_PSFLineArray[i].szPSFName,"%s-%s",m_PSFLineArray[i].szBus1Name,m_PSFLineArray[i].szBus2Name);
	}
	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
	{
		if (m_PSFFixedTranArray[i].szID[0] != ' ' && m_PSFFixedTranArray[i].szID[0] != '\0')
			sprintf(m_PSFFixedTranArray[i].szPSFName,"%s-%s@%s",m_PSFFixedTranArray[i].szBus1Name,m_PSFFixedTranArray[i].szBus2Name,m_PSFFixedTranArray[i].szID);
		else
			sprintf(m_PSFFixedTranArray[i].szPSFName,"%s-%s",m_PSFFixedTranArray[i].szBus1Name,m_PSFFixedTranArray[i].szBus2Name);
	}
	for (i=0; i<(int)m_PSFULTCTranArray.size(); i++)
	{
		if (m_PSFULTCTranArray[i].szID[0] != ' ' && m_PSFULTCTranArray[i].szID[0] != '\0')
			sprintf(m_PSFULTCTranArray[i].szPSFName,"%s-%s@%s",m_PSFULTCTranArray[i].szBus1Name,m_PSFULTCTranArray[i].szBus2Name,m_PSFULTCTranArray[i].szID);
		else
			sprintf(m_PSFULTCTranArray[i].szPSFName,"%s-%s",m_PSFULTCTranArray[i].szBus1Name,m_PSFULTCTranArray[i].szBus2Name);
	}
	for (i=0; i<(int)m_PSFFixedSeriesCompensatorArray.size(); i++)
	{
		if (m_PSFFixedSeriesCompensatorArray[i].szID[0] != ' ' && m_PSFFixedSeriesCompensatorArray[i].szID[0] != '\0')
			sprintf(m_PSFFixedSeriesCompensatorArray[i].szPSFName,"%s-%s@%s",m_PSFFixedSeriesCompensatorArray[i].szBus1Name,m_PSFFixedSeriesCompensatorArray[i].szBus2Name,m_PSFFixedSeriesCompensatorArray[i].szID);
		else
			sprintf(m_PSFFixedSeriesCompensatorArray[i].szPSFName,"%s-%s",m_PSFFixedSeriesCompensatorArray[i].szBus1Name,m_PSFFixedSeriesCompensatorArray[i].szBus2Name);
	}
	for (i=0; i<(int)m_PSFSwitchableSeriesCompensatorArray.size(); i++)
	{
		if (m_PSFSwitchableSeriesCompensatorArray[i].szID[0] != ' ' && m_PSFSwitchableSeriesCompensatorArray[i].szID[0] != '\0')
			sprintf(m_PSFSwitchableSeriesCompensatorArray[i].szPSFName,"%s-%s@%s",m_PSFSwitchableSeriesCompensatorArray[i].szBus1Name,m_PSFSwitchableSeriesCompensatorArray[i].szBus2Name,m_PSFSwitchableSeriesCompensatorArray[i].szID);
		else
			sprintf(m_PSFSwitchableSeriesCompensatorArray[i].szPSFName,"%s-%s",m_PSFSwitchableSeriesCompensatorArray[i].szBus1Name,m_PSFSwitchableSeriesCompensatorArray[i].szBus2Name);
	}
	for (i=0; i<(int)m_PSFStaticTapChangerPhaseRegulatorArray.size(); i++)
	{
		if (m_PSFStaticTapChangerPhaseRegulatorArray[i].szID[0] != ' ' && m_PSFStaticTapChangerPhaseRegulatorArray[i].szID[0] != '\0')
			sprintf(m_PSFStaticTapChangerPhaseRegulatorArray[i].szPSFName,"%s-%s@%s",m_PSFStaticTapChangerPhaseRegulatorArray[i].szBus1Name,m_PSFStaticTapChangerPhaseRegulatorArray[i].szBus2Name,m_PSFStaticTapChangerPhaseRegulatorArray[i].szID);
		else
			sprintf(m_PSFStaticTapChangerPhaseRegulatorArray[i].szPSFName,"%s-%s",m_PSFStaticTapChangerPhaseRegulatorArray[i].szBus1Name,m_PSFStaticTapChangerPhaseRegulatorArray[i].szBus2Name);
	}
	for (i=0; i<(int)m_PSF3WindingTranArray.size(); i++)
	{
		if (m_PSF3WindingTranArray[i].szID[0] != ' ' && m_PSF3WindingTranArray[i].szID[0] != '\0')
			sprintf(m_PSF3WindingTranArray[i].szPSFName,"%s-%s-%s@%s",m_PSF3WindingTranArray[i].szBus1Name,m_PSF3WindingTranArray[i].szBus2Name,m_PSF3WindingTranArray[i].szBus3Name,m_PSF3WindingTranArray[i].szID);
		else
			sprintf(m_PSF3WindingTranArray[i].szPSFName,"%s-%s-%s",m_PSF3WindingTranArray[i].szBus1Name,m_PSF3WindingTranArray[i].szBus2Name,m_PSF3WindingTranArray[i].szBus3Name);
	}
}

void	CPSFAscii::TraverseVolt(const int nStartBus, const double fZIL, const int bCheckRTStatus, std::vector<int>& nBusArray)
{
	register int	i;
	int		nDev,nDevice,nOppBus,nBusNumOfLayer;
	std::vector<unsigned char>	bProcArray;
	std::vector<int> nMidBusArray;

	bProcArray.resize(m_PSFBusArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nBusArray.clear();
	nBusArray.push_back(nStartBus);
	bProcArray[nStartBus]=1;
	nBusNumOfLayer=0;
	while (1)
	{
		nMidBusArray.clear();
		for (i=nBusNumOfLayer; i<(int)nBusArray.size(); i++)
		{
			if (fZIL > FLT_MIN)
			{
				for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nLineArray.size(); nDev++)
				{
					nDevice=m_BusNobnArray[nBusArray[i]].nLineArray[nDev];
					if (m_PSFLineArray[nDevice].nBus1Index < 0 || m_PSFLineArray[nDevice].nBus2Index < 0)
						continue;

					if (sqrt(m_PSFLineArray[nDevice].fR*m_PSFLineArray[nDevice].fR+m_PSFLineArray[nDevice].fX*m_PSFLineArray[nDevice].fX) < fZIL)
					{
						nOppBus=(nBusArray[i] == m_PSFLineArray[nDevice].nBus1Index) ? m_PSFLineArray[nDevice].nBus2Index : m_PSFLineArray[nDevice].nBus1Index;
						if (!bProcArray[nOppBus])
						{
							nMidBusArray.push_back(nOppBus);
							bProcArray[nOppBus]=1;
						}
					}
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nULTCTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nULTCTransformerArray[nDev];
				if (m_PSFULTCTranArray[nDevice].nBus1Index < 0 || m_PSFULTCTranArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFULTCTranArray[nDevice].nBus1Index) ? m_PSFULTCTranArray[nDevice].nBus2Index : m_PSFULTCTranArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nFixedSeriesCompensatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nFixedSeriesCompensatorArray[nDev];
				if (m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index < 0 || m_PSFFixedSeriesCompensatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index) ? m_PSFFixedSeriesCompensatorArray[nDevice].nBus2Index : m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nSwitchableSeriesCompensatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nSwitchableSeriesCompensatorArray[nDev];
				if (m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index < 0 || m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index) ? m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus2Index : m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nStaticTapChangerPhaseRegulatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nStaticTapChangerPhaseRegulatorArray[nDev];
				if (m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index < 0 || m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index) ? m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus2Index : m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nPSF3WindingTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nPSF3WindingTransformerArray[nDev];
				if (m_PSF3WindingTranArray[nDevice].nBus1Index < 0 || m_PSF3WindingTranArray[nDevice].nBus2Index < 0 || m_PSF3WindingTranArray[nDevice].nBus3Index < 0)
					continue;

				if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus1Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus2Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus3Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
				else if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus2Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus3Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
				else if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus3Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus2Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nVoltageSourcedConverterArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nVoltageSourcedConverterArray[nDev];
				if (m_PSFVSCArray[nDevice].nACBus1Index < 0 || m_PSFVSCArray[nDevice].nACBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFVSCArray[nDevice].nACBus1Index) ? m_PSFVSCArray[nDevice].nACBus2Index : m_PSFVSCArray[nDevice].nACBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
		}

		if (nMidBusArray.empty())
			break;
		nBusNumOfLayer=nBusArray.size();
		for (i=0; i<(int)nMidBusArray.size(); i++)
			nBusArray.push_back(nMidBusArray[i]);
	}

	nMidBusArray.clear();
}

void	CPSFAscii::TraverseSub(const int nStartBus, const double fZIL, const int bCheckRTStatus, std::vector<int>& nBusArray)
{
	register int	i;
	int		nDev,nDevice,nOppBus,nBusNumOfLayer;
	std::vector<unsigned char>	bProcArray;
	std::vector<int> nMidBusArray;

	bProcArray.resize(m_PSFBusArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nBusArray.clear();
	nBusArray.push_back(nStartBus);
	bProcArray[nStartBus]=1;
	nBusNumOfLayer=0;
	while (1)
	{
		nMidBusArray.clear();
		for (i=nBusNumOfLayer; i<(int)nBusArray.size(); i++)
		{
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nLineArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nLineArray[nDev];
				if (m_PSFLineArray[nDevice].nBus1Index < 0 || m_PSFLineArray[nDevice].nBus2Index < 0)
					continue;

				if (fZIL > FLT_MIN && sqrt(m_PSFLineArray[nDevice].fR*m_PSFLineArray[nDevice].fR+m_PSFLineArray[nDevice].fX*m_PSFLineArray[nDevice].fX) < fZIL)
				{
					nOppBus=(nBusArray[i] == m_PSFLineArray[nDevice].nBus1Index) ? m_PSFLineArray[nDevice].nBus2Index : m_PSFLineArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nFixedTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nFixedTransformerArray[nDev];
				if (m_PSFFixedTranArray[nDevice].nBus1Index < 0 || m_PSFFixedTranArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFFixedTranArray[nDevice].nBus1Index) ? m_PSFFixedTranArray[nDevice].nBus2Index : m_PSFFixedTranArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nULTCTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nULTCTransformerArray[nDev];
				if (m_PSFULTCTranArray[nDevice].nBus1Index < 0 || m_PSFULTCTranArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFULTCTranArray[nDevice].nBus1Index) ? m_PSFULTCTranArray[nDevice].nBus2Index : m_PSFULTCTranArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nFixedSeriesCompensatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nFixedSeriesCompensatorArray[nDev];
				if (m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index < 0 || m_PSFFixedSeriesCompensatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index) ? m_PSFFixedSeriesCompensatorArray[nDevice].nBus2Index : m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nSwitchableSeriesCompensatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nSwitchableSeriesCompensatorArray[nDev];
				if (m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index < 0 || m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index) ? m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus2Index : m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nStaticTapChangerPhaseRegulatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nStaticTapChangerPhaseRegulatorArray[nDev];
				if (m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index < 0 || m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index) ? m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus2Index : m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nPSF3WindingTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nPSF3WindingTransformerArray[nDev];
				if (m_PSF3WindingTranArray[nDevice].nBus1Index < 0 || m_PSF3WindingTranArray[nDevice].nBus2Index < 0 || m_PSF3WindingTranArray[nDevice].nBus3Index < 0)
					continue;

				if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus1Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus2Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus3Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
				else if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus2Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus3Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
				else if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus3Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus2Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nVoltageSourcedConverterArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nVoltageSourcedConverterArray[nDev];
				if (m_PSFVSCArray[nDevice].nACBus1Index < 0 || m_PSFVSCArray[nDevice].nACBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFVSCArray[nDevice].nACBus1Index) ? m_PSFVSCArray[nDevice].nACBus2Index : m_PSFVSCArray[nDevice].nACBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
		}

		if (nMidBusArray.empty())
			break;
		nBusNumOfLayer=nBusArray.size();
		for (i=0; i<(int)nMidBusArray.size(); i++)
			nBusArray.push_back(nMidBusArray[i]);
	}

	nMidBusArray.clear();
}

void	CPSFAscii::TraverseNet(const int nStartBus, const int bCheckRTStatus, std::vector<int>& nBusArray)
{
	register int	i;
	std::vector<unsigned char>	bProcArray;
	int		nDev,nDevice,nOppBus,nBusNumOfLayer;
	std::vector<int> nMidBusArray;

	bProcArray.resize(m_PSFBusArray.size());
	for (i=0; i<(int)bProcArray.size(); i++)
		bProcArray[i]=0;

	nBusArray.clear();
	nBusArray.push_back(nStartBus);
	bProcArray[nStartBus]=1;
	nBusNumOfLayer=0;
	while (1)
	{
		nMidBusArray.clear();
		for (i=nBusNumOfLayer; i<(int)nBusArray.size(); i++)
		{
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nLineArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nLineArray[nDev];
				if (m_PSFLineArray[nDevice].bOpened)
					continue;
				if (m_PSFLineArray[nDevice].nBus1Index < 0 || m_PSFLineArray[nDevice].nBus2Index < 0)
					continue;
				if (bCheckRTStatus && m_PSFLineArray[nDevice].nRTStatus != 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFLineArray[nDevice].nBus1Index) ? m_PSFLineArray[nDevice].nBus2Index : m_PSFLineArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nFixedTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nFixedTransformerArray[nDev];
				if (m_PSFFixedTranArray[nDevice].bOpened)
					continue;
				if (m_PSFFixedTranArray[nDevice].nBus1Index < 0 || m_PSFFixedTranArray[nDevice].nBus2Index < 0)
					continue;
				if (bCheckRTStatus && m_PSFFixedTranArray[nDevice].nRTStatus != 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFFixedTranArray[nDevice].nBus1Index) ? m_PSFFixedTranArray[nDevice].nBus2Index : m_PSFFixedTranArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nULTCTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nULTCTransformerArray[nDev];
				if (m_PSFULTCTranArray[nDevice].bOpened)
					continue;
				if (m_PSFULTCTranArray[nDevice].nBus1Index < 0 || m_PSFULTCTranArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFULTCTranArray[nDevice].nBus1Index) ? m_PSFULTCTranArray[nDevice].nBus2Index : m_PSFULTCTranArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nFixedSeriesCompensatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nFixedSeriesCompensatorArray[nDev];
				if (m_PSFFixedSeriesCompensatorArray[nDevice].bOpened)
					continue;
				if (m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index < 0 || m_PSFFixedSeriesCompensatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index) ? m_PSFFixedSeriesCompensatorArray[nDevice].nBus2Index : m_PSFFixedSeriesCompensatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nSwitchableSeriesCompensatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nSwitchableSeriesCompensatorArray[nDev];
				if (m_PSFSwitchableSeriesCompensatorArray[nDevice].bOpened)
					continue;
				if (m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index < 0 || m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index) ? m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus2Index : m_PSFSwitchableSeriesCompensatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nStaticTapChangerPhaseRegulatorArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nStaticTapChangerPhaseRegulatorArray[nDev];
				if (m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].bOpened)
					continue;
				if (m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index < 0 || m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index) ? m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus2Index : m_PSFStaticTapChangerPhaseRegulatorArray[nDevice].nBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nPSF3WindingTransformerArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nPSF3WindingTransformerArray[nDev];
				if (m_PSF3WindingTranArray[nDevice].bOpened)
					continue;
				if (m_PSF3WindingTranArray[nDevice].nBus1Index < 0 || m_PSF3WindingTranArray[nDevice].nBus2Index < 0 || m_PSF3WindingTranArray[nDevice].nBus3Index < 0)
					continue;

				if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus1Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus2Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus3Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
				else if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus2Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus3Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
				else if (nBusArray[i] == m_PSF3WindingTranArray[nDevice].nBus3Index)
				{
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus1Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
					nOppBus=m_PSF3WindingTranArray[nDevice].nBus2Index;
					if (!bProcArray[nOppBus])
					{
						nMidBusArray.push_back(nOppBus);
						bProcArray[nOppBus]=1;
					}
				}
			}
			for (nDev=0; nDev<(int)m_BusNobnArray[nBusArray[i]].nVoltageSourcedConverterArray.size(); nDev++)
			{
				nDevice=m_BusNobnArray[nBusArray[i]].nVoltageSourcedConverterArray[nDev];
				if (m_PSFVSCArray[nDevice].nACBus1Index < 0 || m_PSFVSCArray[nDevice].nACBus2Index < 0)
					continue;

				nOppBus=(nBusArray[i] == m_PSFVSCArray[nDevice].nACBus1Index) ? m_PSFVSCArray[nDevice].nACBus2Index : m_PSFVSCArray[nDevice].nACBus1Index;
				if (!bProcArray[nOppBus])
				{
					nMidBusArray.push_back(nOppBus);
					bProcArray[nOppBus]=1;
				}
			}
		}

		if (nMidBusArray.empty())
			break;
		nBusNumOfLayer=nBusArray.size();
		for (i=0; i<(int)nMidBusArray.size(); i++)
			nBusArray.push_back(nMidBusArray[i]);
	}

	nMidBusArray.clear();
}

void CPSFAscii::GetSubstationString(std::vector<int>& nBusArray, tagPSFSubstation& subBuffer)
{
	register int	i;
	double	fMaxBusVolt;
	int		nMaxBusVolt;

	if (nBusArray.empty())
		return;

	nMaxBusVolt=-1;
	fMaxBusVolt=0;
	for (i=0; i<(int)nBusArray.size(); i++)
	{
		if (fMaxBusVolt < m_PSFBusArray[nBusArray[i]].fkV)
		{
			fMaxBusVolt=m_PSFBusArray[nBusArray[i]].fkV;
			nMaxBusVolt=i;
		}
	}
	if (nMaxBusVolt < 0)
		return;

	strcpy(subBuffer.szName, m_PSFBusArray[nBusArray[nMaxBusVolt]].szName);
}

void CPSFAscii::FormSubstation(const double fZIL)
{
	register int	i;
	int		nBus;
	std::vector<unsigned char>	bBusProcArray;
	std::vector<int>			nBusArray;
	tagPSFSubstation			subBuf;
	unsigned char	bHasGenerator;

	m_SubstationArray.clear();

	bBusProcArray.resize(m_PSFBusArray.size());
	for (i=0; i<(int)bBusProcArray.size(); i++)
		bBusProcArray[i]=0;

	for (nBus=0; nBus<(int)m_PSFBusArray.size(); nBus++)
	{
		if (bBusProcArray[nBus])
			continue;
		bBusProcArray[nBus]=1;

		TraverseSub(nBus, fZIL, 0, nBusArray);
		for (i=0; i<(int)nBusArray.size(); i++)
			bBusProcArray[nBusArray[i]]=1;

		//Log("Sub%d Bus=%d\n",m_SubstationArray.size(),nBusArray.size());
		//for (i=0; i<(int)nBusArray.size(); i++)
		//	Log("        %s %.1f\n",m_PSFBusArray[nBusArray[i]].szName,m_PSFBusArray[nBusArray[i]].fkV);
		//Log("\n");

		memset(subBuf.szName, 0, MDB_CHARLEN_TINY);
		subBuf.nType=PSFSubstation_Type_Substation;	//���վ
		memset(subBuf.szRTName, 0, MDB_CHARLEN);
		subBuf.nBusArray.clear();

		bHasGenerator=0;
		GetSubstationString(nBusArray, subBuf);
		for (i=0; i<(int)nBusArray.size(); i++)
		{
			strcpy(m_PSFBusArray[nBusArray[i]].szSubstation, subBuf.szName);
			subBuf.nBusArray.push_back(nBusArray[i]);

			if (!m_BusNobnArray[nBusArray[i]].nGeneratorArray.empty())
				bHasGenerator=1;
		}
		if (bHasGenerator)
			subBuf.nType=PSFSubstation_Type_TherimalPlant;

		m_SubstationArray.push_back(subBuf);
	}

	sortSubstationByName(0, m_SubstationArray.size()-1);

	bBusProcArray.clear();
	nBusArray.clear();
	subBuf.nBusArray.clear();
}

void	CPSFAscii::GetZoneFilterIndexArray(const char* lpszTable, const std::vector<std::string> strFilterZoneArray, std::vector<int>& nFilterIndexArray)
{
	nFilterIndexArray.clear();
	int		nTable=GetTableIndex(lpszTable);
	if (nTable >= 0)
		GetZoneFilterIndexArray(nTable, strFilterZoneArray, nFilterIndexArray);
}

void	CPSFAscii::GetZoneFilterIndexArray(const int nTable, const std::vector<std::string> strFilterZoneArray, std::vector<int>& nFilterIndexArray)
{
	register int	i;
	int		nRecord,nZone;
	unsigned char	bInZone;
	const	int		nRecordNum=GetPSFModelRecordNum(nTable);

	nFilterIndexArray.resize(nRecordNum);
	for (i=0; i<nRecordNum; i++)
		nFilterIndexArray[i]=i;
	if (strFilterZoneArray.empty())
		return;

	switch (nTable)
	{
		case	PSFModel_Substation:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				bInZone=0;
				for (i=0; i<(int)m_SubstationArray[nRecord].nBusArray.size(); i++)
				{
					for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
					{
						if (strcmp(m_PSFBusArray[m_SubstationArray[nRecord].nBusArray[i]].szZoneName, strFilterZoneArray[nZone].c_str()) == 0)
						{
							bInZone=1;
							break;
						}
					}
					if (bInZone)	break;
				}
				if (bInZone)
					nFilterIndexArray.push_back(nRecord);
			}
			break;
		case	PSFModel_Bus:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFBusArray[nRecord].nNumber, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_Generator:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFGeneratorArray[nRecord].nBusNumber, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_Load:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFLoadArray[nRecord].nBusNumber, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_FixedShunt:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFFixedShuntArray[nRecord].nBusNumber, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_SwitchableShunt:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFSwitchableShuntArray[nRecord].nBusNumber, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_Line:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFLineArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFLineArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_FixedTransformer:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFFixedTranArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFFixedTranArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_ULTCTransformer:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFULTCTranArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFULTCTranArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_FixedSeriesCompensator:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFFixedSeriesCompensatorArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFFixedSeriesCompensatorArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_SwitchableSeriesCompensator:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFSwitchableSeriesCompensatorArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFSwitchableSeriesCompensatorArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_StaticTapChangerPhaseRegulator:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFStaticTapChangerPhaseRegulatorArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_PSF3WindingTransformer:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSF3WindingTranArray[nRecord].nBus1Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSF3WindingTranArray[nRecord].nBus2Number, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSF3WindingTranArray[nRecord].nBus3Number, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_LineCommutatedConverters:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFLCConvertersArray[nRecord].nACBus, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_VoltageSourcedConverter:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (IsBusInZone(m_PSFVSCArray[nRecord].nACBus1, strFilterZoneArray[nZone].c_str()) ||
						IsBusInZone(m_PSFVSCArray[nRecord].nACBus2, strFilterZoneArray[nZone].c_str()))
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_Zone:
			nFilterIndexArray.clear();
			for (nRecord=0; nRecord<nRecordNum; nRecord++)
			{
				for (nZone=0; nZone<(int)strFilterZoneArray.size(); nZone++)
				{
					if (strcmp(m_PSFZoneArray[nRecord].szName, strFilterZoneArray[nZone].c_str()) == 0)
					{
						nFilterIndexArray.push_back(nRecord);
						break;
					}
				}
			}
			break;
		case	PSFModel_SolutionHistory:
		case	PSFModel_LoadModel:
		case	PSFModel_ImpedanceCorrectionTables:
		case	PSFModel_AreaInterchange:
		case	PSFModel_Interface:
		case	PSFModel_DCLines:
		case	PSFModel_DCBreakers:
		case	PSFModel_DCBuses:
		case	PSFModel_NodeMapping:
		case	PSFModel_ZeroSequenceMutualCoupling:
		case	PSFModel_FileSection:
			break;
	}
}
