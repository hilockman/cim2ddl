#include "StdAfx.h"
#include <io.h>
#include "PG2PSFAscii.h"
#include "../../Common/TinyXML/tinyxml.h"

extern	void		Log(const char* lpszFormat, ...);
extern	std::string	toString(const double fBuf);
extern	std::string	toString(const float fBuf);
extern	std::string	toString(const int nBuf);
extern	std::string	toString(const short nBuf);
extern	std::string	toString(const unsigned char bBuf);

std::string	CPG2PSFAscii::GetPG2PSFDataString(const int nTable, const int nField, const int nRecord)
{
	std::string	strValue="";

	if (nTable < 0 || nTable >= sizeof(g_PSFModelTables)/sizeof(tagPSFModelTable))
		return strValue;

	switch (nTable)
	{
	case PSFModel_Bus:
		{
			switch (nField)
			{
			case PSFBus_Number:			strValue=toString(m_PG2PSFBusArray[nRecord].nNumber);		break;
			case PSFBus_Name:			strValue=m_PG2PSFBusArray[nRecord].szName;					break;
			case PSFBus_Voltage:		strValue=toString(m_PG2PSFBusArray[nRecord].fVoltage);		break;
			case PSFBus_Angle:			strValue=toString(m_PG2PSFBusArray[nRecord].fAngle);		break;
			case PSFBus_kV:				strValue=toString(m_PG2PSFBusArray[nRecord].fkV);			break;
			case PSFBus_Type:			strValue=toString(m_PG2PSFBusArray[nRecord].nType);			break;
			case PSFBus_Status:			strValue=toString(m_PG2PSFBusArray[nRecord].nStatus);		break;
			case PSFBus_Area:			strValue=toString(m_PG2PSFBusArray[nRecord].nArea);			break;
			case PSFBus_Zone:			strValue=toString(m_PG2PSFBusArray[nRecord].nZone);			break;
			case PSFBus_D1:				strValue=toString(m_PG2PSFBusArray[nRecord].nD1);			break;
			case PSFBus_D2:				strValue=toString(m_PG2PSFBusArray[nRecord].nD2);			break;
			case PSFBus_D3:				strValue=toString(m_PG2PSFBusArray[nRecord].nD3);			break;
			case PSFBus_D4:				strValue=toString(m_PG2PSFBusArray[nRecord].nD4);			break;
			case PSFBus_D5:				strValue=toString(m_PG2PSFBusArray[nRecord].nD5);			break;
			case PSFBus_Owner:			strValue=m_PG2PSFBusArray[nRecord].szOwner;					break;
			case PSFBus_EquipmentName:	strValue=m_PG2PSFBusArray[nRecord].szEquipmentName;			break;
			case PSFBus_Latitude:		strValue=toString(m_PG2PSFBusArray[nRecord].fLatitude);		break;
			case PSFBus_Longitude:		strValue=toString(m_PG2PSFBusArray[nRecord].fLongitude);	break;
			case PSFBus_Substation:		strValue=m_PG2PSFBusArray[nRecord].szSubstation;			break;
			case PSFBusEx_RTStatus:		strValue=toString(m_PG2PSFBusArray[nRecord].nRTStatus);		break;
			}
		}

		break;

	case PSFModel_Generator:
		{
			switch (nField)
			{
			case PSFGenerator_BusNumber:				strValue=toString(m_PG2PSFGenArray[nRecord].nBusNumber);				break;
			case PSFGenerator_ID:						strValue=m_PG2PSFGenArray[nRecord].szID;								break;
			case PSFGenerator_Status:					strValue=toString(m_PG2PSFGenArray[nRecord].nStatus);					break;
			case PSFGenerator_MW:						strValue=toString(m_PG2PSFGenArray[nRecord].fMW);						break;
			case PSFGenerator_MVAR:						strValue=toString(m_PG2PSFGenArray[nRecord].fMVar);						break;
			case PSFGenerator_QMAX:						strValue=toString(m_PG2PSFGenArray[nRecord].fQMax);						break;
			case PSFGenerator_QMIN:						strValue=toString(m_PG2PSFGenArray[nRecord].fQMin);						break;
			case PSFGenerator_VHiLimit:					strValue=toString(m_PG2PSFGenArray[nRecord].fVHiLimit);					break;
			case PSFGenerator_VLoLimit:					strValue=toString(m_PG2PSFGenArray[nRecord].fVLoLimit);					break;
			case PSFGenerator_RemoteBus:				strValue=toString(m_PG2PSFGenArray[nRecord].nRemoteBus);				break;
			case PSFGenerator_RemoteBusV:				strValue=toString(m_PG2PSFGenArray[nRecord].fRemoteBusV);				break;
			case PSFGenerator_QContributionPercentCtrl:	strValue=toString(m_PG2PSFGenArray[nRecord].fQContributionPercentCtrl);	break;
			case PSFGenerator_USCHQ:					strValue=toString(m_PG2PSFGenArray[nRecord].nUSCHQ);					break;
			case PSFGenerator_MVA:						strValue=toString(m_PG2PSFGenArray[nRecord].fMva);						break;
			case PSFGenerator_PMAX:						strValue=toString(m_PG2PSFGenArray[nRecord].fPMax);						break;
			case PSFGenerator_PMIN:						strValue=toString(m_PG2PSFGenArray[nRecord].fPMin);						break;
			case PSFGenerator_RS:						strValue=toString(m_PG2PSFGenArray[nRecord].fRS);						break;
			case PSFGenerator_XS:						strValue=toString(m_PG2PSFGenArray[nRecord].fXS);						break;
			case PSFGenerator_RT:						strValue=toString(m_PG2PSFGenArray[nRecord].fRT);						break;
			case PSFGenerator_XT:						strValue=toString(m_PG2PSFGenArray[nRecord].fXT);						break;
			case PSFGenerator_TAP:						strValue=toString(m_PG2PSFGenArray[nRecord].fTAP);						break;
			case PSFGenerator_EquipmentName:			strValue=m_PG2PSFGenArray[nRecord].szEquipmentName;						break;
			case PSFGenerator_Owner:					strValue=m_PG2PSFGenArray[nRecord].szOwner;								break;
			case PSFGenerator_GWMOD:					strValue=toString(m_PG2PSFGenArray[nRecord].nGWMOD);					break;
			case PSFGenerator_GWPF:						strValue=toString(m_PG2PSFGenArray[nRecord].fGWPF);						break;
			case PSFGenerator_GBASLD:					strValue=toString(m_PG2PSFGenArray[nRecord].nGBASLD);					break;
			case PSFGenerator_RP:						strValue=toString(m_PG2PSFGenArray[nRecord].fRP);						break;
			case PSFGenerator_XP:						strValue=toString(m_PG2PSFGenArray[nRecord].fXP);						break;
			case PSFGenerator_RN:						strValue=toString(m_PG2PSFGenArray[nRecord].fRN);						break;
			case PSFGenerator_XN:						strValue=toString(m_PG2PSFGenArray[nRecord].fXN);						break;
			case PSFGenerator_RZ:						strValue=toString(m_PG2PSFGenArray[nRecord].fRZ);						break;
			case PSFGenerator_XZ:						strValue=toString(m_PG2PSFGenArray[nRecord].fXZ);						break;
			case PSFGenerator_RG:						strValue=toString(m_PG2PSFGenArray[nRecord].fRG);						break;
			case PSFGenerator_XG:						strValue=toString(m_PG2PSFGenArray[nRecord].fXG);						break;
			case PSFGeneratorEx_BusName:				strValue=m_PG2PSFGenArray[nRecord].szBusName;							break;
			case PSFGeneratorEx_RTName:					strValue=m_PG2PSFGenArray[nRecord].szRTName;							break;
			case PSFGeneratorEx_RTMW:					strValue=toString(m_PG2PSFGenArray[nRecord].fRTMW);						break;
			case PSFGeneratorEx_RTMVar:					strValue=toString(m_PG2PSFGenArray[nRecord].fRTMVar);					break;
			case PSFGeneratorEx_RTVoltage:				strValue=toString(m_PG2PSFGenArray[nRecord].fRTVoltage);				break;
			case PSFGeneratorEx_RTStatus:				strValue=toString(m_PG2PSFGenArray[nRecord].nRTStatus);					break;
			}
		}
		break;

	case PSFModel_Load:
		{
			switch (nField)
			{
			case PSFLoad_BusNumber:		strValue=toString(m_PG2PSFLoadArray[nRecord].nBusNumber);		break;
			case PSFLoad_RefP:			strValue=toString(m_PG2PSFLoadArray[nRecord].fRefP);			break;
			case PSFLoad_RefQ:			strValue=toString(m_PG2PSFLoadArray[nRecord].fRefQ);			break;
			case PSFLoad_P1:			strValue=toString(m_PG2PSFLoadArray[nRecord].fP1);				break;
			case PSFLoad_Q1:			strValue=toString(m_PG2PSFLoadArray[nRecord].fQ1);				break;
			case PSFLoad_P2:			strValue=toString(m_PG2PSFLoadArray[nRecord].fP2);				break;
			case PSFLoad_Q2:			strValue=toString(m_PG2PSFLoadArray[nRecord].fQ2);				break;
			case PSFLoad_P3:			strValue=toString(m_PG2PSFLoadArray[nRecord].fP3);				break;
			case PSFLoad_Q3:			strValue=toString(m_PG2PSFLoadArray[nRecord].fQ3);				break;
			case PSFLoad_P4:			strValue=toString(m_PG2PSFLoadArray[nRecord].fP4);				break;
			case PSFLoad_Q4:			strValue=toString(m_PG2PSFLoadArray[nRecord].fQ4);				break;
			case PSFLoad_P5:			strValue=toString(m_PG2PSFLoadArray[nRecord].fP5);				break;
			case PSFLoad_Q5:			strValue=toString(m_PG2PSFLoadArray[nRecord].fQ5);				break;
			case PSFLoad_M1:			strValue=toString(m_PG2PSFLoadArray[nRecord].nM1);				break;
			case PSFLoad_M2:			strValue=toString(m_PG2PSFLoadArray[nRecord].nM2);				break;
			case PSFLoad_M3:			strValue=toString(m_PG2PSFLoadArray[nRecord].nM3);				break;
			case PSFLoad_M4:			strValue=toString(m_PG2PSFLoadArray[nRecord].nM4);				break;
			case PSFLoad_M5:			strValue=toString(m_PG2PSFLoadArray[nRecord].nM5);				break;
			case PSFLoad_Type:			strValue=toString(m_PG2PSFLoadArray[nRecord].nType);			break;
			case PSFLoad_Owner:			strValue=m_PG2PSFLoadArray[nRecord].szOwner;					break;
			case PSFLoad_ID:			strValue=m_PG2PSFLoadArray[nRecord].szID;						break;
			case PSFLoad_Scalable:		strValue=toString(m_PG2PSFLoadArray[nRecord].nScalable);		break;
			case PSFLoad_EquipmentName:	strValue=m_PG2PSFLoadArray[nRecord].szEquipmentName;			break;
			case PSFLoad_Area:			strValue=toString(m_PG2PSFLoadArray[nRecord].nArea);			break;
			case PSFLoad_Zone:			strValue=toString(m_PG2PSFLoadArray[nRecord].nZone);			break;
			case PSFLoad_Status:		strValue=toString(m_PG2PSFLoadArray[nRecord].nStatus);			break;
			case PSFLoad_GN:			strValue=toString(m_PG2PSFLoadArray[nRecord].fGN);				break;
			case PSFLoad_BN:			strValue=toString(m_PG2PSFLoadArray[nRecord].fBN);				break;
			case PSFLoad_GZ:			strValue=toString(m_PG2PSFLoadArray[nRecord].fGZ);				break;
			case PSFLoad_BZ:			strValue=toString(m_PG2PSFLoadArray[nRecord].fBZ);				break;
			case PSFLoadEx_BusName:		strValue=m_PG2PSFLoadArray[nRecord].szBusName;					break;
			case PSFLoadEx_RTName:		strValue=m_PG2PSFLoadArray[nRecord].szRTName;					break;
			case PSFLoadEx_RTP:			strValue=toString(m_PG2PSFLoadArray[nRecord].fRTP);				break;
			case PSFLoadEx_RTQ:			strValue=toString(m_PG2PSFLoadArray[nRecord].fRTQ);				break;
			case PSFLoadEx_RTStatus:	strValue=toString(m_PG2PSFLoadArray[nRecord].nRTStatus);		break;
			}
		}
		break;

	case PSFModel_FixedShunt:
		{
			switch (nField)
			{
			case PSFFixedShunt_BusNumber:		strValue=toString(m_PG2PSFCapArray[nRecord].nBusNumber);	break;
			case PSFFixedShunt_G:				strValue=toString(m_PG2PSFCapArray[nRecord].fG);			break;
			case PSFFixedShunt_B:				strValue=toString(m_PG2PSFCapArray[nRecord].fB);			break;
			case PSFFixedShunt_Type:			strValue=toString(m_PG2PSFCapArray[nRecord].nType);			break;
			case PSFFixedShunt_Owner:			strValue=m_PG2PSFCapArray[nRecord].szOwner;					break;
			case PSFFixedShunt_ID:				strValue=m_PG2PSFCapArray[nRecord].szID;					break;
			case PSFFixedShunt_EquipmentName:	strValue=m_PG2PSFCapArray[nRecord].szEquipmentName;			break;
			case PSFFixedShunt_Status:			strValue=toString(m_PG2PSFCapArray[nRecord].nStatus);		break;
			case PSFFixedShunt_GN:				strValue=toString(m_PG2PSFCapArray[nRecord].fGN);			break;
			case PSFFixedShunt_BN:				strValue=toString(m_PG2PSFCapArray[nRecord].fBN);			break;
			case PSFFixedShunt_GZ:				strValue=toString(m_PG2PSFCapArray[nRecord].fGZ);			break;
			case PSFFixedShunt_BZ:				strValue=toString(m_PG2PSFCapArray[nRecord].fBZ);			break;
			case PSFFixedShuntEx_BusName:		strValue=m_PG2PSFCapArray[nRecord].szBusName;				break;
			case PSFFixedShuntEx_RTName:		strValue=m_PG2PSFCapArray[nRecord].szRTName;				break;
			}
		}
		break;

	case PSFModel_Line:
		{
			switch (nField)
			{
			case PSFLine_Bus1Number:	strValue=toString(m_PG2PSFLineArray[nRecord].nBus1Number);			break;
			case PSFLine_Bus2Number:	strValue=toString(m_PG2PSFLineArray[nRecord].nBus2Number);			break;
			case PSFLine_ID:			strValue=m_PG2PSFLineArray[nRecord].szID;							break;
			case PSFLine_Section:		strValue=toString(m_PG2PSFLineArray[nRecord].nSection);				break;
			case PSFLine_Status:		strValue=toString(m_PG2PSFLineArray[nRecord].nStatus);				break;
			case PSFLine_MeterEnd:		strValue=g_lpszPSF_MeterEnd[m_PG2PSFLineArray[nRecord].nMeterEnd];	break;
			case PSFLine_R:				strValue=toString(m_PG2PSFLineArray[nRecord].fR);					break;
			case PSFLine_X:				strValue=toString(m_PG2PSFLineArray[nRecord].fX);					break;
			case PSFLine_G:				strValue=toString(m_PG2PSFLineArray[nRecord].fG);					break;
			case PSFLine_B:				strValue=toString(m_PG2PSFLineArray[nRecord].fB);					break;
			case PSFLine_GF:			strValue=toString(m_PG2PSFLineArray[nRecord].fGF);					break;
			case PSFLine_BF:			strValue=toString(m_PG2PSFLineArray[nRecord].fBF);					break;
			case PSFLine_GT:			strValue=toString(m_PG2PSFLineArray[nRecord].fGT);					break;
			case PSFLine_BT:			strValue=toString(m_PG2PSFLineArray[nRecord].fBT);					break;
			case PSFLine_R1:			strValue=toString(m_PG2PSFLineArray[nRecord].fR1);					break;
			case PSFLine_R2:			strValue=toString(m_PG2PSFLineArray[nRecord].fR2);					break;
			case PSFLine_R3:			strValue=toString(m_PG2PSFLineArray[nRecord].fR3);					break;
			case PSFLine_R4:			strValue=toString(m_PG2PSFLineArray[nRecord].fR4);					break;
			case PSFLine_R5:			strValue=toString(m_PG2PSFLineArray[nRecord].fR5);					break;
			case PSFLine_R6:			strValue=toString(m_PG2PSFLineArray[nRecord].fR6);					break;
			case PSFLine_RatingGroup:	strValue=toString(m_PG2PSFLineArray[nRecord].nRatingGroup);			break;
			case PSFLine_Z1:			strValue=toString(m_PG2PSFLineArray[nRecord].fZ1);					break;
			case PSFLine_Z2:			strValue=toString(m_PG2PSFLineArray[nRecord].fZ2);					break;
			case PSFLine_Z3:			strValue=toString(m_PG2PSFLineArray[nRecord].fZ3);					break;
			case PSFLine_Z4:			strValue=toString(m_PG2PSFLineArray[nRecord].fZ4);					break;
			case PSFLine_Z5:			strValue=toString(m_PG2PSFLineArray[nRecord].fZ5);					break;
			case PSFLine_Z6:			strValue=toString(m_PG2PSFLineArray[nRecord].fZ6);					break;
			case PSFLine_Type:			strValue=toString(m_PG2PSFLineArray[nRecord].nType);				break;
			case PSFLine_EquipmentName:	strValue=m_PG2PSFLineArray[nRecord].szEquipmentName;				break;
			case PSFLine_Owner:			strValue=m_PG2PSFLineArray[nRecord].szOwner;						break;
			case PSFLine_Length:		strValue=toString(m_PG2PSFLineArray[nRecord].fLength);				break;
			case PSFLine_RZ:			strValue=toString(m_PG2PSFLineArray[nRecord].fRZ);					break;
			case PSFLine_XZ:			strValue=toString(m_PG2PSFLineArray[nRecord].fXZ);					break;
			case PSFLine_RZC:			strValue=toString(m_PG2PSFLineArray[nRecord].fRZC);					break;
			case PSFLine_XZC:			strValue=toString(m_PG2PSFLineArray[nRecord].fXZC);					break;
			case PSFLine_RZSF:			strValue=toString(m_PG2PSFLineArray[nRecord].fRZSF);				break;
			case PSFLine_XZSF:			strValue=toString(m_PG2PSFLineArray[nRecord].fXZSF);				break;
			case PSFLine_RZST:			strValue=toString(m_PG2PSFLineArray[nRecord].fRZST);				break;
			case PSFLine_XZST:			strValue=toString(m_PG2PSFLineArray[nRecord].fXZST);				break;
			case PSFLineEx_Bus1Name:	strValue=m_PG2PSFLineArray[nRecord].szBus1Name;						break;
			case PSFLineEx_Bus2Name:	strValue=m_PG2PSFLineArray[nRecord].szBus2Name;						break;
			case PSFLineEx_PSFName:		strValue=m_PG2PSFLineArray[nRecord].szPSFName;						break;
			case PSFLineEx_RTName:		strValue=m_PG2PSFLineArray[nRecord].szRTName;						break;
			case PSFLineEx_RTP1:		strValue=toString(m_PG2PSFLineArray[nRecord].fRTP1);				break;
			case PSFLineEx_RTQ1:		strValue=toString(m_PG2PSFLineArray[nRecord].fRTQ1);				break;
			case PSFLineEx_RTP2:		strValue=toString(m_PG2PSFLineArray[nRecord].fRTP2);				break;
			case PSFLineEx_RTQ2:		strValue=toString(m_PG2PSFLineArray[nRecord].fRTQ2);				break;
			case PSFLineEx_RTStatus:	strValue=toString(m_PG2PSFLineArray[nRecord].nRTStatus);			break;
			}
		}
		break;

	case PSFModel_FixedTransformer:
		{
			switch (nField)
			{
			case PSFFixedTransformer_Bus1Number:			strValue=toString(m_PG2PSFTranArray[nRecord].nBus1Number);			break;
			case PSFFixedTransformer_Bus2Number:			strValue=toString(m_PG2PSFTranArray[nRecord].nBus2Number);			break;
			case PSFFixedTransformer_ID:					strValue=m_PG2PSFTranArray[nRecord].szID;							break;
			case PSFFixedTransformer_Section:				strValue=toString(m_PG2PSFTranArray[nRecord].nSection);				break;
			case PSFFixedTransformer_Status:				strValue=toString(m_PG2PSFTranArray[nRecord].nStatus);				break;
			case PSFFixedTransformer_MeterEnd:				strValue=g_lpszPSF_MeterEnd[m_PG2PSFTranArray[nRecord].nMeterEnd];	break;
			case PSFFixedTransformer_ONR:					strValue=toString(m_PG2PSFTranArray[nRecord].fONR);					break;
			case PSFFixedTransformer_Angle:					strValue=toString(m_PG2PSFTranArray[nRecord].fAngle);				break;
			case PSFFixedTransformer_R:						strValue=toString(m_PG2PSFTranArray[nRecord].fR);					break;
			case PSFFixedTransformer_X:						strValue=toString(m_PG2PSFTranArray[nRecord].fX);					break;
			case PSFFixedTransformer_G:						strValue=toString(m_PG2PSFTranArray[nRecord].fG);					break;
			case PSFFixedTransformer_B:						strValue=toString(m_PG2PSFTranArray[nRecord].fB);					break;
			case PSFFixedTransformer_GF:					strValue=toString(m_PG2PSFTranArray[nRecord].fGF);					break;
			case PSFFixedTransformer_BF:					strValue=toString(m_PG2PSFTranArray[nRecord].fBF);					break;
			case PSFFixedTransformer_GT:					strValue=toString(m_PG2PSFTranArray[nRecord].fGT);					break;
			case PSFFixedTransformer_BT:					strValue=toString(m_PG2PSFTranArray[nRecord].fBT);					break;
			case PSFFixedTransformer_R1:					strValue=toString(m_PG2PSFTranArray[nRecord].fR1);					break;
			case PSFFixedTransformer_R2:					strValue=toString(m_PG2PSFTranArray[nRecord].fR2);					break;
			case PSFFixedTransformer_R3:					strValue=toString(m_PG2PSFTranArray[nRecord].fR3);					break;
			case PSFFixedTransformer_R4:					strValue=toString(m_PG2PSFTranArray[nRecord].fR4);					break;
			case PSFFixedTransformer_R5:					strValue=toString(m_PG2PSFTranArray[nRecord].fR5);					break;
			case PSFFixedTransformer_R6:					strValue=toString(m_PG2PSFTranArray[nRecord].fR6);					break;
			case PSFFixedTransformer_RatingGroup:			strValue=toString(m_PG2PSFTranArray[nRecord].nRatingGroup);			break;
			case PSFFixedTransformer_MVA:					strValue=toString(m_PG2PSFTranArray[nRecord].fMVA);					break;
			case PSFFixedTransformer_Z1:					strValue=toString(m_PG2PSFTranArray[nRecord].fZ1);					break;
			case PSFFixedTransformer_Z2:					strValue=toString(m_PG2PSFTranArray[nRecord].fZ2);					break;
			case PSFFixedTransformer_Z3:					strValue=toString(m_PG2PSFTranArray[nRecord].fZ3);					break;
			case PSFFixedTransformer_Z4:					strValue=toString(m_PG2PSFTranArray[nRecord].fZ4);					break;
			case PSFFixedTransformer_Z5:					strValue=toString(m_PG2PSFTranArray[nRecord].fZ5);					break;
			case PSFFixedTransformer_Z6:					strValue=toString(m_PG2PSFTranArray[nRecord].fZ6);					break;
			case PSFFixedTransformer_EquipmentName:			strValue=m_PG2PSFTranArray[nRecord].szEquipmentName;				break;
			case PSFFixedTransformer_Name:					strValue=m_PG2PSFTranArray[nRecord].szName;							break;
			case PSFFixedTransformer_Owner:					strValue=m_PG2PSFTranArray[nRecord].szOwner;						break;
			case PSFFixedTransformer_RZ:					strValue=toString(m_PG2PSFTranArray[nRecord].fRZ);					break;
			case PSFFixedTransformer_XZ:					strValue=toString(m_PG2PSFTranArray[nRecord].fXZ);					break;
			case PSFFixedTransformer_WindConnectionCode:	strValue=toString(m_PG2PSFTranArray[nRecord].nWindConnectionCode);	break;
			case PSFFixedTransformer_RGF:					strValue=toString(m_PG2PSFTranArray[nRecord].fRGF);					break;
			case PSFFixedTransformer_XGF:					strValue=toString(m_PG2PSFTranArray[nRecord].fXGF);					break;
			case PSFFixedTransformer_RGT:					strValue=toString(m_PG2PSFTranArray[nRecord].fRGT);					break;
			case PSFFixedTransformer_XGT:					strValue=toString(m_PG2PSFTranArray[nRecord].fXGT);					break;
			case PSFFixedTransformerEx_Bus1Name:			strValue=m_PG2PSFTranArray[nRecord].szBus1Name;						break;
			case PSFFixedTransformerEx_Bus2Name:			strValue=m_PG2PSFTranArray[nRecord].szBus2Name;						break;
			case PSFFixedTransformerEx_PSFName:				strValue=m_PG2PSFTranArray[nRecord].szPSFName;						break;
			case PSFFixedTransformerEx_RTName:				strValue=m_PG2PSFTranArray[nRecord].szRTName;						break;
			case PSFFixedTransformerEx_RTP1:				strValue=toString(m_PG2PSFTranArray[nRecord].fRTP1);				break;
			case PSFFixedTransformerEx_RTQ1:				strValue=toString(m_PG2PSFTranArray[nRecord].fRTQ1);				break;
			case PSFFixedTransformerEx_RTP2:				strValue=toString(m_PG2PSFTranArray[nRecord].fRTP2);				break;
			case PSFFixedTransformerEx_RTQ2:				strValue=toString(m_PG2PSFTranArray[nRecord].fRTQ2);				break;
			case PSFFixedTransformerEx_RTRatio:				strValue=toString(m_PG2PSFTranArray[nRecord].fRTTap);				break;
			case PSFFixedTransformerEx_RTStatus:			strValue=toString(m_PG2PSFTranArray[nRecord].nRTStatus);			break;
			}
		}
		break;
	case PSFModel_AreaInterchange:
		{
			switch (nField)
			{
			case PSFAreaInterchange_Number:			strValue=toString(m_PG2PSFAreaArray[nRecord].nNumber);			break;
			case PSFAreaInterchange_Name:			strValue=m_PG2PSFAreaArray[nRecord].szName;						break;
			case PSFAreaInterchange_DesiredFlow:	strValue=toString(m_PG2PSFAreaArray[nRecord].fDesiredFlow);		break;
			case PSFAreaInterchange_Tolerance:		strValue=toString(m_PG2PSFAreaArray[nRecord].fTolerance);		break;
			case PSFAreaInterchange_SlackBus:		strValue=toString(m_PG2PSFAreaArray[nRecord].nSlackBus);		break;
			case PSFAreaInterchange_Description:	strValue=m_PG2PSFAreaArray[nRecord].szDescription;				break;
			case PSFAreaInterchange_Mode:			strValue=toString(m_PG2PSFAreaArray[nRecord].nMode);			break;
			case PSFAreaInterchange_Flag:			strValue=toString(m_PG2PSFAreaArray[nRecord].nFlag);			break;

			}
		}
		break;
	case PSFModel_Zone:
		{
			switch (nField)
			{
			case PSFZone_Number:	strValue=toString(m_PG2PSFZoneArray[nRecord].nNumber);	break;
			case PSFZone_Name:		strValue=m_PG2PSFZoneArray[nRecord].szName;				break;
			}
		}
		break;
	}

	return strValue;
}

int CPG2PSFAscii::ResolvePG2PSFOfflineName(CPSFAscii* pPSFAscii, const int nPSFModel, const char* lpszPGName, char* lpszPSFName)
{
	register int	i;

	switch (nPSFModel)
	{
	case PSFModel_Generator:
		for (i=0; i<(int)pPSFAscii->m_PSFGeneratorArray.size(); i++)
		{
			if (strcmp(pPSFAscii->m_PSFGeneratorArray[i].szRTName, lpszPGName) == 0)
			{
				strcpy(lpszPSFName, pPSFAscii->m_PSFGeneratorArray[i].szBusName);
				return 1;
			}
		}
		break;

// 	case	PSFModel_Line:
// 		for (i=0; i<(int)pPSFAscii->m_PSFLineArray.size(); i++)
// 		{
// 			if (strcmp(pPSFAscii->m_PSFLineArray[i].szRTName, lpszPGName) == 0)
// 			{
// 				strcpy(lpszPSFName, pPSFAscii->m_PSFLineArray[i].szPSFName);
// 				break;
// 			}
// 		}
// 		break;
// 
// 	case	PSFModel_FixedTransformer:
// 		for (i=0; i<(int)pPSFAscii->m_PSFFixedTranArray.size(); i++)
// 		{
// 			if (strcmp(pPSFAscii->m_PSFFixedTranArray[i].szRTName, lpszPGName) == 0)
// 			{
// 				strcpy(lpszPSFName, pPSFAscii->m_PSFFixedTranArray[i].szPSFName);
// 				break;
// 			}
// 		}
// 		break;
	}

	return 0;
}

void CPG2PSFAscii::sortBoundNetBus(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetBusArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetBusArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetBusArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetBusArray[nDn],m_PGBoundNetBusArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetBus(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetBus(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetLine(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetLineArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetLineArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetLineArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetLineArray[nDn],m_PGBoundNetLineArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetLine(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetLine(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetTran(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetTranArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetTranArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetTranArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetTranArray[nDn],m_PGBoundNetTranArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetTran(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetTran(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetGen(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetGenArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetGenArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetGenArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetGenArray[nDn],m_PGBoundNetGenArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetGen(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetGen(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetLoad(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetLoadArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetLoadArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetLoadArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetLoadArray[nDn],m_PGBoundNetLoadArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetLoad(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetLoad(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetCap(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetCapArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetCapArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetCapArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetCapArray[nDn],m_PGBoundNetCapArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetCap(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetCap(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetBreaker(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetBreakerArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetBreakerArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetBreakerArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetBreakerArray[nDn],m_PGBoundNetBreakerArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetBreaker(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetBreaker(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetDisconnector(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetDisconnectorArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetDisconnectorArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetDisconnectorArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetDisconnectorArray[nDn],m_PGBoundNetDisconnectorArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetDisconnector(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetDisconnector(nDn, nUp0);
}

void CPG2PSFAscii::sortBoundNetGroundDisconnector(int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nDevIndex=m_PGBoundNetGroundDisconnectorArray[(nDn0+nUp0)/2].nPGIndex;
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && m_PGBoundNetGroundDisconnectorArray[nDn].nPGIndex < nDevIndex)
			++nDn;												  
		while (nUp > nDn0 && m_PGBoundNetGroundDisconnectorArray[nUp].nPGIndex > nDevIndex)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(m_PGBoundNetGroundDisconnectorArray[nDn],m_PGBoundNetGroundDisconnectorArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		sortBoundNetGroundDisconnector(nDn0, nUp);

	if (nDn < nUp0 )
		sortBoundNetGroundDisconnector(nDn, nUp0);
}

int CPG2PSFAscii::ResolvePG2PSFAreaNumber(CPSFAscii* pPSFAscii, const char* lpszArea)
{
	register int	i;
	for (i=0; i<(int)m_PG2PSFAreaArray.size(); i++)
	{
		if (strcmp(m_PG2PSFAreaArray[i].szName, lpszArea) == 0)
		{
			return m_PG2PSFAreaArray[i].nNumber;
			break;
		}
	}
	return 0;
}

int CPG2PSFAscii::ResolvePG2PSFZoneNumber(CPSFAscii* pPSFAscii, const char* lpszZone)
{
	register int	i;
	char	szBuffer[260];
	strcpy(szBuffer, lpszZone);
	ReplaceSubString(szBuffer, "����");
	for (i=0; i<(int)m_PG2PSFZoneArray.size(); i++)
	{
		if (strstr(m_PG2PSFZoneArray[i].szName, szBuffer) != NULL)
		{
			return m_PG2PSFZoneArray[i].nNumber;
			break;
		}
	}
	return 0;
}

std::string CPG2PSFAscii::ResolvePGShortSubName(const char* lpszPGSubstationName)
{
	register int	i;
	std::string	strSName;

	strSName=lpszPGSubstationName;
	for (i=0; i<(int)m_PGShortNameArray.size(); i++)
	{
		if (strstr(m_PGShortNameArray[i].strName.c_str(), lpszPGSubstationName) != NULL)
		{
			strSName=m_PGShortNameArray[i].strShortName;
			break;
		}
	}

	return strSName;
}

std::string	CPG2PSFAscii::ResolvePSFBusName(tagPGBlock* pBlock, const char* lpszPGSub, const char* lpszPGVolt, const char* lpszPGDev, const int nPGTopoBus)
{
	register int	i;
	char	szBuf[260];

	std::string	strName=ResolvePGShortSubName(lpszPGSub);

	int		nVolt=PGGetVoltIndex(pBlock, lpszPGSub, lpszPGVolt);
	for (i=pBlock->m_VoltageLevelArray[nVolt].pRbus; i<pBlock->m_VoltageLevelArray[nVolt+1].pRbus; i++)
	{
		if (pBlock->m_BusbarSectionArray[i].iRnd < 0)
			continue;
		if (pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[i].iRnd].iRbs == nPGTopoBus)
		{
			strcpy(szBuf, pBlock->m_BusbarSectionArray[i].szName);
			ReplaceSubString(szBuf, "kv");
			ReplaceSubString(szBuf, "kV");
			ReplaceSubString(szBuf, "KV");
			ReplaceSubString(szBuf, "Kv");
			ReplaceSubString(szBuf, "KM");
			if (strName.length()+strlen(szBuf) < 16)
			{
				strName.append(szBuf);
				return strName;
			}
		}
	}

	if (strName.length()+strlen(lpszPGDev) >= 16)
	{
		sprintf(szBuf,"%d",nPGTopoBus);
		strName.append(szBuf);
	}
	else
	{
		strName.append(lpszPGDev);
	}

	return strName;
}

int CPG2PSFAscii::ResolvePSFBoundTopoBus(const int nBusDeviate, const int nPGBus)
{
	int		nBound;
	for (nBound=0; nBound<(int)m_PG2PSFBoundArray.size(); nBound++)
	{
		if (nPGBus == m_PG2PSFBoundArray[nBound].nPGBoundBus)
		{
			return m_PG2PSFBoundArray[nBound].nPSFBoundBus;
		}
	}

	return nBusDeviate+nPGBus;
}

void CPG2PSFAscii::ResolveBoundPG2PSFBus(tagPGBlock* pBlock, CPSFAscii* pPSFAscii)
{
	register int	i;
	int		nDevice,nBound;
	for (nBound=0; nBound<(int)m_PG2PSFBoundArray.size(); nBound++)
	{
		m_PG2PSFBoundArray[nBound].nPSFBoundBus=m_PG2PSFBoundArray[nBound].nPGBoundBus=-1;

		nDevice=-1;
		for (i=0; i<(int)pPSFAscii->m_PSFLineArray.size(); i++)
		{
			if (strcmp(pPSFAscii->m_PSFLineArray[i].szPSFName, m_PG2PSFBoundArray[nBound].szPSFBoundLine) == 0)
			{
				nDevice=i;
				break;
			}
		}
		if (nDevice >= 0)
		{
			if (strcmp(pPSFAscii->m_PSFBusArray[pPSFAscii->m_PSFLineArray[nDevice].nBus1Index].szSubstation, m_PG2PSFBoundArray[nBound].szPSFBoundSub) == 0)
				m_PG2PSFBoundArray[nBound].nPSFBoundBus=pPSFAscii->m_PSFLineArray[nDevice].nBus1Number;
			else
				m_PG2PSFBoundArray[nBound].nPSFBoundBus=pPSFAscii->m_PSFLineArray[nDevice].nBus2Number;
		}

		switch (m_PG2PSFBoundArray[nBound].nPGBoundDevType)
		{
		case PG_ACLINESEGMENT:
			nDevice=-1;
			for (i=0; i<pBlock->m_nRecordNum[PG_ACLINESEGMENT]; i++)
			{
				if (strcmp(pBlock->m_ACLineSegmentArray[i].szName, m_PG2PSFBoundArray[nBound].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_ACLineSegmentArray[i].szSubI, m_PG2PSFBoundArray[nBound].szPGBoundDevSub) == 0 || strcmp(pBlock->m_ACLineSegmentArray[i].szSubZ, m_PG2PSFBoundArray[nBound].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_ACLineSegmentArray[i].szVoltI, m_PG2PSFBoundArray[nBound].szPGBoundDevVolt) == 0 || strcmp(pBlock->m_ACLineSegmentArray[i].szVoltZ, m_PG2PSFBoundArray[nBound].szPGBoundDevVolt) == 0)
				{
					nDevice=i;
					break;
				}
			}
			if (nDevice >= 0)
			{
				if (strcmp(pBlock->m_ACLineSegmentArray[nDevice].szSubI, m_PG2PSFBoundArray[nBound].szPGBoundDevSub) == 0)
					m_PG2PSFBoundArray[nBound].nPGBoundBus=pBlock->m_ACLineSegmentArray[nDevice].iRbs;
				else
					m_PG2PSFBoundArray[nBound].nPGBoundBus=pBlock->m_ACLineSegmentArray[nDevice].zRbs;
			}
			break;
		case PG_SYNCHRONOUSMACHINE:
			nDevice=-1;
			for (i=0; i<pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
			{
				if (strcmp(pBlock->m_SynchronousMachineArray[i].szName, m_PG2PSFBoundArray[nBound].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_SynchronousMachineArray[i].szSub, m_PG2PSFBoundArray[nBound].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_SynchronousMachineArray[i].szVolt, m_PG2PSFBoundArray[nBound].szPGBoundDevVolt) == 0)
				{
					nDevice=i;
					break;
				}
			}
			if (nDevice >= 0)
				m_PG2PSFBoundArray[nBound].nPGBoundBus=pBlock->m_SynchronousMachineArray[nDevice].iRbs;
			break;
		case PG_ENERGYCONSUMER:
			nDevice=-1;
			for (i=0; i<pBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
			{
				if (strcmp(pBlock->m_EnergyConsumerArray[i].szName, m_PG2PSFBoundArray[nBound].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_EnergyConsumerArray[i].szSub, m_PG2PSFBoundArray[nBound].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_EnergyConsumerArray[i].szVolt, m_PG2PSFBoundArray[nBound].szPGBoundDevVolt) == 0)
				{
					nDevice=i;
					break;
				}
			}
			if (nDevice >= 0)
				m_PG2PSFBoundArray[nBound].nPGBoundBus=pBlock->m_EnergyConsumerArray[nDevice].iRbs;
			break;
		case PG_BUSBARSECTION:
			nDevice=-1;
			for (i=0; i<pBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
			{
				if (pBlock->m_BusbarSectionArray[nDevice].iRnd < 0)
					continue;

				if (strcmp(pBlock->m_BusbarSectionArray[i].szName, m_PG2PSFBoundArray[nBound].szPGBoundDevName) == 0 &&
					strcmp(pBlock->m_BusbarSectionArray[i].szSub, m_PG2PSFBoundArray[nBound].szPGBoundDevSub) == 0 &&
					strcmp(pBlock->m_BusbarSectionArray[i].szVolt, m_PG2PSFBoundArray[nBound].szPGBoundDevVolt) == 0)
				{
					nDevice=i;
					break;
				}
			}
			if (nDevice >= 0)
				m_PG2PSFBoundArray[nBound].nPGBoundBus=pBlock->m_ConnectivityNodeArray[pBlock->m_BusbarSectionArray[nDevice].iRnd].iRbs;
			break;
		}
	}
	for (nBound=0; nBound<(int)m_PG2PSFBoundArray.size(); nBound++)
	{
		for (i=nBound+1; i<(int)m_PG2PSFBoundArray.size(); i++)
		{
			if (strcmp(m_PG2PSFBoundArray[nBound].szPSFBoundSub, m_PG2PSFBoundArray[i].szPSFBoundSub) == 0 && m_PG2PSFBoundArray[nBound].nPGBoundBus == m_PG2PSFBoundArray[i].nPGBoundBus)
			{
				m_PG2PSFBoundArray[i].nPSFBoundBus=m_PG2PSFBoundArray[nBound].nPSFBoundBus;
			}
		}
		Log("Bound[%d/%d] BoundPGBus=%d BoundPSFBus=%d\n",nBound+1,m_PG2PSFBoundArray.size(),m_PG2PSFBoundArray[nBound].nPGBoundBus,m_PG2PSFBoundArray[nBound].nPSFBoundBus);
	}
}

void CPG2PSFAscii::LoadBoundLine(const char* lpszFileName)
{
	TiXmlElement*	pLine;
	TiXmlElement*	pElement;
	TiXmlNode*		pNode;
	tagPG2PSFBoundLine	boundBuffer;
	char	szDevType[MDB_CHARLEN];

	if (access(lpszFileName,0) != 0)
	{
		Log("BoundLineFile = %s ������\n",lpszFileName);
		return;
	}

	TiXmlDocument doc(lpszFileName);
	if (!doc.LoadFile())
	{
		Log("װ�������ļ�ʧ��(BoundLineFile = %s ) XMLError=%s\n",lpszFileName,doc.ErrorDesc());
		return;
	}

	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "PG2PSFBound") != 0)
	{
		//Log("bad pRoot"));
		doc.Clear();
		return;
	}

	m_PG2PSFBoundArray.clear();

	// Traverse children of pRoot, populating the list of lines
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(),"Bound") == 0)
		{
			pElement = pLine->FirstChildElement();
			while (pElement != NULL)
			{
				pNode = pElement->FirstChild();
				if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				{
					if (stricmp(pElement->Value(),"PGBoundDevType") == 0)				{	strcpy(szDevType, pNode->Value());	boundBuffer.nPGBoundDevType=PGGetTableIndex(szDevType);	}
					else if (stricmp(pElement->Value(),"PGBoundDevSubstation") == 0)	{	strcpy(boundBuffer.szPGBoundDevSub,pNode->Value());		}
					else if (stricmp(pElement->Value(),"PGBoundDevVoltageLevel") == 0)	{	strcpy(boundBuffer.szPGBoundDevVolt,pNode->Value());	}
					else if (stricmp(pElement->Value(),"PGBoundDevName") == 0)			{	strcpy(boundBuffer.szPGBoundDevName,pNode->Value());	}
					else if (stricmp(pElement->Value(),"PSFBoundSubstation") == 0)		{	strcpy(boundBuffer.szPSFBoundSub,pNode->Value());		}
					else if (stricmp(pElement->Value(),"PSFBoundLineName") == 0)		{	strcpy(boundBuffer.szPSFBoundLine,pNode->Value());		}
				}
				pElement = pElement->NextSiblingElement();
			}
			m_PG2PSFBoundArray.push_back(boundBuffer);
		}
		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();
}

void CPG2PSFAscii::SaveBoundLine(const char* lpszFileName)
{
	register int	i;
	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement*		pRootElement;
	TiXmlElement*		pSecElement;
	TiXmlElement*		pAttrElement;
	char				szBuf[260];

	pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0","gb2312","no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("PG2PSFBound");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	for (i=0; i<(int)m_PG2PSFBoundArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Bound");					//BusReli Section
		pRootElement->LinkEndChild(pSecElement);

		PGGetTableName(m_PG2PSFBoundArray[i].nPGBoundDevType, szBuf);
		pAttrElement = new TiXmlElement("PGBoundDevType");			pAttrElement->LinkEndChild(new TiXmlText(szBuf));									pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("PGBoundDevSubstation");	pAttrElement->LinkEndChild(new TiXmlText(m_PG2PSFBoundArray[i].szPGBoundDevSub));		pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("PGBoundDevVoltageLevel");	pAttrElement->LinkEndChild(new TiXmlText(m_PG2PSFBoundArray[i].szPGBoundDevVolt));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("PGBoundDevName");			pAttrElement->LinkEndChild(new TiXmlText(m_PG2PSFBoundArray[i].szPGBoundDevName));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("PSFBoundSubstation");		pAttrElement->LinkEndChild(new TiXmlText(m_PG2PSFBoundArray[i].szPSFBoundSub));		pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("PSFBoundLineName");		pAttrElement->LinkEndChild(new TiXmlText(m_PG2PSFBoundArray[i].szPSFBoundLine));		pSecElement->LinkEndChild(pAttrElement);
	}
	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}

void CPG2PSFAscii::LoadSubstationShortName(tagPGBlock* pBlock, const char* lpszFileName)
{
	register int	i;
	TiXmlElement*	pLine;
	TiXmlElement*	pElement;
	TiXmlNode*		pNode;
	tagPGShortName	nameBuf;

	unsigned char	bExist;
	tagPGShortName	subBuf;
	m_PGShortNameArray.clear();
	for (i=0; i<pBlock->m_nRecordNum[PG_SUBSTATION]; i++)
	{
		subBuf.strName=pBlock->m_SubstationArray[i].szName;
		subBuf.strShortName.clear();
		if (subBuf.strName.length() <= 10)
			subBuf.strShortName=subBuf.strName;
		m_PGShortNameArray.push_back(subBuf);
	}

	if (access(lpszFileName,0) != 0)
	{
		Log("SubstationShortNameFile = %s ������\n",lpszFileName);
		return;
	}

	TiXmlDocument doc(lpszFileName);
	if (!doc.LoadFile())
	{
		Log("װ�������ļ�ʧ��(SubstationShortNameFile = %s ) XMLError=%s\n",lpszFileName,doc.ErrorDesc());
		return;
	}

	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "PGSubstationShortName") != 0)
	{
		//Log("bad pRoot"));
		doc.Clear();
		return;
	}

	// Traverse children of pRoot, populating the list of lines
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(),"Substation") == 0)
		{
			nameBuf.strName.clear();
			nameBuf.strShortName.clear();

			pElement = pLine->FirstChildElement();
			while (pElement != NULL)
			{
				pNode = pElement->FirstChild();
				if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				{
					if (stricmp(pElement->Value(),"Name") == 0)				{	nameBuf.strName=pNode->Value();			}
					else if (stricmp(pElement->Value(),"ShortName") == 0)	{	nameBuf.strShortName=pNode->Value();	}
				}
				pElement = pElement->NextSiblingElement();
			}

			if (nameBuf.strShortName.length() <= 10)
			{
				bExist=0;
				for (i=0; i<(int)m_PGShortNameArray.size(); i++)
				{
					if (strcmp(m_PGShortNameArray[i].strName.c_str(), nameBuf.strName.c_str()) == 0)
					{
						m_PGShortNameArray[i].strShortName=nameBuf.strShortName;
						bExist=1;
						break;
					}
				}
				if (!bExist)
					m_PGShortNameArray.push_back(nameBuf);
			}
		}
		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();
}

void CPG2PSFAscii::SaveSubstationShortName(const char* lpszFileName)
{
	register int	i;
	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement*		pRootElement;
	TiXmlElement*		pSecElement;
	TiXmlElement*		pAttrElement;

	pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0","gb2312","no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("PGSubstationShortName");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	for (i=0; i<(int)m_PGShortNameArray.size(); i++)
	{
		pSecElement = new TiXmlElement("Substation");					//BusReli Section
		pRootElement->LinkEndChild(pSecElement);

		pAttrElement = new TiXmlElement("Name");		pAttrElement->LinkEndChild(new TiXmlText(m_PGShortNameArray[i].strName.c_str()));			pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("ShortName");	pAttrElement->LinkEndChild(new TiXmlText(m_PGShortNameArray[i].strShortName.c_str()));	pSecElement->LinkEndChild(pAttrElement);
	}
	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}
