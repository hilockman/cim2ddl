#include "StdAfx.h"
#include "PG2PSFAscii.h"

extern	void	PrintMessage(const char* lpszFormat, ...);

CPG2PSFAscii::CPG2PSFAscii(void)
{
}

CPG2PSFAscii::~CPG2PSFAscii(void)
{
}

void CPG2PSFAscii::PG2PSFAscii(tagPGBlock* pBlock, CPSFAscii* pPSFAscii, const double fZIL, const char* lpszPowerNetName, const char* lpszPSFAsciiFileName, std::vector<std::string>& strWorkZoneArray)
{
	FormPGBoundNet(pBlock);
	FormPSFBoundNet(pPSFAscii);
	FormPGBoundPSF(pBlock, pPSFAscii, lpszPowerNetName, strWorkZoneArray);

	ErasePSFBoundNet(pPSFAscii);
	AppendPGBoundNet(pPSFAscii, fZIL);
	pPSFAscii->ExportPSFFile(lpszPSFAsciiFileName);
}


void CPG2PSFAscii::ReplaceSubString(char* lpszWorkString, const char* lpszReplaceString)
{
	register int	i;
	int		nChar;
	char	szBuffer[260];

	nChar=0;
	i=0;
	while (i < (int)strlen(lpszWorkString))
	{
		if (strncmp(lpszWorkString+i, lpszReplaceString, strlen(lpszReplaceString)) == 0)
		{
			i += strlen(lpszReplaceString);
		}
		else
		{
			szBuffer[nChar++]=lpszWorkString[i++];
		}
	}

	szBuffer[nChar++]='\0';
	strcpy(lpszWorkString, szBuffer);
}

void CPG2PSFAscii::FormPGBoundPSF(tagPGBlock* pBlock, CPSFAscii* pPSFAscii, const char* lpszCorp, std::vector<std::string>& strWorkZoneArray)
{
	register int	i;
	int		nSub,nVolt,nDev,nPGDev,nID;
	int		nMaxPSFAsciiAreaNumber,nMaxPSFAsciiZoneNumber,nMaxPSFAsciiBusNumber;
	unsigned char	bExist;
	char			szBuffer[MDB_CHARLEN],szDevName[MDB_CHARLEN_LONG];
	float	fTranRatio;
	tagPSFBus				busBuffer;
	tagPSFGenerator			genBuffer;
	tagPSFLoad				loadBuffer;
	tagPSFFixedShunt		capBuffer;
	tagPSFLine				lineBuffer;
	tagPSFFixedTransformer	tranBuffer;

	tagPSFAreaInterchange	areaBuffer;
	tagPSFZone				zoneBuffer;

	clock_t	dBeg,dEnd;
	int		nDur;

	dBeg=clock();

	memset(&busBuffer,	0, sizeof(tagPSFBus				));
	memset(&genBuffer,	0, sizeof(tagPSFGenerator		));
	memset(&loadBuffer,	0, sizeof(tagPSFLoad			));
	memset(&capBuffer,	0, sizeof(tagPSFFixedShunt		));
	memset(&lineBuffer,	0, sizeof(tagPSFLine			));
	memset(&tranBuffer,	0, sizeof(tagPSFFixedTransformer));
	memset(&areaBuffer,	0, sizeof(tagPSFAreaInterchange	));
	memset(&zoneBuffer,	0, sizeof(tagPSFZone			));
	strcpy(busBuffer.szOwner,lpszCorp);
	strcpy(genBuffer.szOwner,lpszCorp);
	strcpy(loadBuffer.szOwner,lpszCorp);
	strcpy(capBuffer.szOwner,lpszCorp);
	strcpy(lineBuffer.szOwner,lpszCorp);
	strcpy(tranBuffer.szOwner,lpszCorp);

	m_PG2PSFAreaArray.clear();
	m_PG2PSFZoneArray.clear();
	m_PG2PSFBusArray.clear();
	m_PG2PSFGenArray.clear();
	m_PG2PSFLoadArray.clear();
	m_PG2PSFCapArray.clear();
	m_PG2PSFLineArray.clear();
	m_PG2PSFTranArray.clear();

	PGMemDBTopo(pBlock);
	ResolveBoundPG2PSFBus(pBlock, pPSFAscii);

	nMaxPSFAsciiAreaNumber=0;
	nMaxPSFAsciiZoneNumber=0;
	nMaxPSFAsciiBusNumber=0;
	for (i=0; i<(int)pPSFAscii->m_PSFAreaInterchangeArray.size(); i++)
	{
		if (pPSFAscii->m_PSFAreaInterchangeArray[i].nNumber > nMaxPSFAsciiAreaNumber)
			nMaxPSFAsciiAreaNumber	=pPSFAscii->m_PSFAreaInterchangeArray[i].nNumber;
	}
	areaBuffer.nNumber=nMaxPSFAsciiAreaNumber+1;
	strcpy(areaBuffer.szName, lpszCorp);
	areaBuffer.nMode=0;	//	������
	m_PG2PSFAreaArray.push_back(areaBuffer);

	for (i=0; i<(int)pPSFAscii->m_PSFZoneArray.size(); i++)
	{
		if (pPSFAscii->m_PSFZoneArray[i].nNumber > nMaxPSFAsciiZoneNumber)
			nMaxPSFAsciiZoneNumber=pPSFAscii->m_PSFZoneArray[i].nNumber;
	}

	for (i=0; i<pBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
	{
		strcpy(zoneBuffer.szName, pBlock->m_SubControlAreaArray[i].szName);
		ReplaceSubString(zoneBuffer.szName, "����");
		zoneBuffer.nNumber=nMaxPSFAsciiZoneNumber+1+i;

		bExist=0;
		for (i=0; i<(int)m_PG2PSFZoneArray.size(); i++)
		{
			if (strcmp(m_PG2PSFZoneArray[i].szName, zoneBuffer.szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			m_PG2PSFZoneArray.push_back(zoneBuffer);

		bExist=0;
		for (i=0; i<(int)strWorkZoneArray.size(); i++)
		{
			if (strcmp(strWorkZoneArray[i].c_str(), zoneBuffer.szName) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strWorkZoneArray.push_back(zoneBuffer.szName);
	}

	for (i=0; i<(int)pPSFAscii->m_PSFBusArray.size(); i++)
	{
		if (pPSFAscii->m_PSFBusArray[i].nNumber > nMaxPSFAsciiBusNumber)
			nMaxPSFAsciiBusNumber=pPSFAscii->m_PSFBusArray[i].nNumber;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("��ʼ����ϣ���ʱ%d����", nDur);

	genBuffer.fGWPF=1;
	genBuffer.fQContributionPercentCtrl=100;
	for (nDev=0; nDev<(int)m_PGBoundNetGenArray.size(); nDev++)
	{
		nPGDev=m_PGBoundNetGenArray[nDev].nPGIndex;
		nSub=PGGetSubIndex(pBlock, pBlock->m_SynchronousMachineArray[nPGDev].szSub);
		nVolt=PGGetVoltIndex(pBlock, pBlock->m_SynchronousMachineArray[nPGDev].szSub,pBlock->m_SynchronousMachineArray[nPGDev].szVolt);
		sprintf(szDevName,"%s,%s,%s",pBlock->m_SynchronousMachineArray[nPGDev].szSub,pBlock->m_SynchronousMachineArray[nPGDev].szVolt,pBlock->m_SynchronousMachineArray[nPGDev].szName);

		genBuffer.nBusNumber=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_SynchronousMachineArray[nPGDev].iRbs);
		genBuffer.fMW=pBlock->m_SynchronousMachineArray[nPGDev].fPlanP;
		genBuffer.fMVar=pBlock->m_SynchronousMachineArray[nPGDev].fPlanQ;
		genBuffer.fPMax=pBlock->m_SynchronousMachineArray[nPGDev].pmax;
		genBuffer.fPMin=pBlock->m_SynchronousMachineArray[nPGDev].pmin;
		genBuffer.fQMax=pBlock->m_SynchronousMachineArray[nPGDev].qmax;
		genBuffer.fQMin=pBlock->m_SynchronousMachineArray[nPGDev].qmin;
		genBuffer.fVHiLimit=1.5;
		genBuffer.fVLoLimit=0.5;
		genBuffer.fMva=sqrt(pBlock->m_SynchronousMachineArray[nPGDev].pmax*pBlock->m_SynchronousMachineArray[nPGDev].pmax+pBlock->m_SynchronousMachineArray[nPGDev].qmax*pBlock->m_SynchronousMachineArray[nPGDev].qmax);
		sprintf(genBuffer.szEquipmentName,"%s%s",ResolvePGShortSubName(pBlock->m_SynchronousMachineArray[nPGDev].szSub).c_str(),pBlock->m_SynchronousMachineArray[nPGDev].szName);
		genBuffer.nStatus=PSFGenerator_Status_InService;
		m_PG2PSFGenArray.push_back(genBuffer);

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == genBuffer.nBusNumber)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			busBuffer.nNumber=genBuffer.nBusNumber;

			memset(busBuffer.szName,0,MDB_CHARLEN_TINY+1);
			if (!ResolvePG2PSFOfflineName(pPSFAscii, PSFModel_Generator, szDevName, busBuffer.szName))
				strcpy(busBuffer.szName,ResolvePSFBusName(pBlock, pBlock->m_SynchronousMachineArray[nPGDev].szSub, pBlock->m_SynchronousMachineArray[nPGDev].szVolt, pBlock->m_SynchronousMachineArray[nPGDev].szName, pBlock->m_SynchronousMachineArray[nPGDev].iRbs).c_str()),

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;

			if (strstr(pBlock->m_SubstationArray[nSub].szName,"���") == NULL && strstr(pBlock->m_SubstationArray[nSub].szName,"���") == NULL)
				busBuffer.nType=PSFBus_Type_GeneratorBus;

			strcpy(busBuffer.szEquipmentName,genBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_PG2PSFGenArray.size(); nDev++)
	{
		if (atoi(m_PG2PSFGenArray[nDev].szID) > 0)
			continue;

		nID=1;
		sprintf(m_PG2PSFGenArray[nDev].szID,"%d",nID++);
		for (i=nDev+1; i<(int)m_PG2PSFGenArray.size(); i++)
		{
			if (m_PG2PSFGenArray[nDev].nBusNumber == m_PG2PSFGenArray[i].nBusNumber)
				sprintf(m_PG2PSFGenArray[i].szID,"%d",nID++);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("����������Ϣ������ϣ���ʱ%d����", nDur);

	for (nDev=0; nDev<(int)m_PGBoundNetLoadArray.size(); nDev++)
	{
		nPGDev=m_PGBoundNetLoadArray[nDev].nPGIndex;
		nSub=PGGetSubIndex(pBlock, pBlock->m_EnergyConsumerArray[nPGDev].szSub);
		nVolt=PGGetVoltIndex(pBlock, pBlock->m_EnergyConsumerArray[nPGDev].szSub,pBlock->m_EnergyConsumerArray[nPGDev].szVolt);
		sprintf(szDevName,"%s,%s,%s",pBlock->m_EnergyConsumerArray[nPGDev].szSub,pBlock->m_EnergyConsumerArray[nPGDev].szVolt,pBlock->m_EnergyConsumerArray[nPGDev].szName);

		loadBuffer.nBusNumber=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_EnergyConsumerArray[nPGDev].iRbs);
		loadBuffer.fP1=pBlock->m_EnergyConsumerArray[nPGDev].fPlanP;
		loadBuffer.fQ1=pBlock->m_EnergyConsumerArray[nPGDev].fPlanQ;
		loadBuffer.nType=1;
		loadBuffer.nScalable=0;
		loadBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
		loadBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
		sprintf(loadBuffer.szEquipmentName,"%s%s",ResolvePGShortSubName(pBlock->m_EnergyConsumerArray[nPGDev].szSub).c_str(),pBlock->m_EnergyConsumerArray[nPGDev].szName);
		m_PG2PSFLoadArray.push_back(loadBuffer);

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == loadBuffer.nBusNumber)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			busBuffer.nNumber=loadBuffer.nBusNumber;

			memset(busBuffer.szName,0,MDB_CHARLEN_TINY+1);
			strcpy(busBuffer.szName, ResolvePSFBusName(pBlock, pBlock->m_EnergyConsumerArray[nPGDev].szSub, pBlock->m_EnergyConsumerArray[nPGDev].szVolt, pBlock->m_EnergyConsumerArray[nPGDev].szName, pBlock->m_EnergyConsumerArray[nPGDev].iRbs).c_str());

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;
			strcpy(busBuffer.szEquipmentName,loadBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_PG2PSFLoadArray.size(); nDev++)
	{
		if (atoi(m_PG2PSFLoadArray[nDev].szID) > 0)
			continue;

		nID=1;
		sprintf(m_PG2PSFLoadArray[nDev].szID,"%d",nID++);
		for (i=nDev+1; i<(int)m_PG2PSFLoadArray.size(); i++)
		{
			if (m_PG2PSFLoadArray[nDev].nBusNumber == m_PG2PSFLoadArray[i].nBusNumber)
				sprintf(m_PG2PSFLoadArray[i].szID,"%d",nID++);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("���������Ϣ������ϣ���ʱ%d����", nDur);

	for (nDev=0; nDev<(int)m_PGBoundNetCapArray.size(); nDev++)
	{
		nPGDev=m_PGBoundNetCapArray[nDev].nPGIndex;
		nSub=PGGetSubIndex(pBlock, pBlock->m_ShuntCompensatorArray[nPGDev].szSub);
		nVolt=PGGetVoltIndex(pBlock, pBlock->m_ShuntCompensatorArray[nPGDev].szSub,pBlock->m_ShuntCompensatorArray[nPGDev].szVolt);
		if (pBlock->m_VoltageLevelArray[nVolt].nominalVoltage < 200)	continue;
		sprintf(szDevName,"%s,%s,%s",pBlock->m_ShuntCompensatorArray[nPGDev].szSub,pBlock->m_ShuntCompensatorArray[nPGDev].szVolt,pBlock->m_ShuntCompensatorArray[nPGDev].szName);

		capBuffer.nBusNumber=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_ShuntCompensatorArray[nPGDev].iRbs);
		capBuffer.fB=pBlock->m_ShuntCompensatorArray[nPGDev].fCap;
		capBuffer.nStatus=PSF_Status_InService;
		capBuffer.nType=1;
		sprintf(capBuffer.szEquipmentName,"%s%s",ResolvePGShortSubName(pBlock->m_ShuntCompensatorArray[nPGDev].szSub).c_str(),pBlock->m_ShuntCompensatorArray[nPGDev].szName);
		m_PG2PSFCapArray.push_back(capBuffer);

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == capBuffer.nBusNumber)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			busBuffer.nNumber=capBuffer.nBusNumber;
			memset(busBuffer.szName,0,MDB_CHARLEN_TINY+1);
			strcpy(busBuffer.szName, ResolvePSFBusName(pBlock, pBlock->m_ShuntCompensatorArray[nPGDev].szSub, pBlock->m_ShuntCompensatorArray[nPGDev].szVolt, pBlock->m_ShuntCompensatorArray[nPGDev].szName, pBlock->m_ShuntCompensatorArray[nPGDev].iRbs).c_str());

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;
			strcpy(busBuffer.szEquipmentName,capBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_PG2PSFCapArray.size(); nDev++)
	{
		if (atoi(m_PG2PSFCapArray[nDev].szID) > 0)
			continue;

		nID=1;
		sprintf(m_PG2PSFCapArray[nDev].szID,"%d",nID++);
		for (i=nDev+1; i<(int)m_PG2PSFCapArray.size(); i++)
		{
			if (m_PG2PSFCapArray[nDev].nBusNumber == m_PG2PSFCapArray[i].nBusNumber)
				sprintf(m_PG2PSFCapArray[i].szID,"%d",nID++);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("���������Ϣ������ϣ���ʱ%d����", nDur);

	for (nDev=0; nDev<(int)m_PGBoundNetLineArray.size(); nDev++)
	{
		nPGDev=m_PGBoundNetLineArray[nDev].nPGIndex;
		strcpy(szDevName,pBlock->m_ACLineSegmentArray[nPGDev].szName);
		//if (strcmp(szDevName,"��ú����") == 0)
		//	ASSERT(FALSE);
		//if (strcmp(szDevName,"��ú����") == 0)
		//	ASSERT(FALSE);

		lineBuffer.nBus1Number=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_ACLineSegmentArray[nPGDev].iRbs);
		lineBuffer.nBus2Number=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_ACLineSegmentArray[nPGDev].zRbs);
		lineBuffer.fR=pBlock->m_ACLineSegmentArray[nPGDev].r;
		lineBuffer.fX=pBlock->m_ACLineSegmentArray[nPGDev].x;
		lineBuffer.fG=pBlock->m_ACLineSegmentArray[nPGDev].g;
		lineBuffer.fB=pBlock->m_ACLineSegmentArray[nPGDev].b;
		lineBuffer.nSection=1;
		lineBuffer.nStatus=PSF_Status_InService;
		lineBuffer.nRatingGroup=1;
		lineBuffer.nType=1;
		lineBuffer.fR1=pBlock->m_ACLineSegmentArray[nPGDev].fRateMva;
		strcpy(lineBuffer.szEquipmentName,pBlock->m_ACLineSegmentArray[nPGDev].szName);
		m_PG2PSFLineArray.push_back(lineBuffer);

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == lineBuffer.nBus1Number)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			nSub=PGGetSubIndex(pBlock, pBlock->m_ACLineSegmentArray[nPGDev].szSubI);
			nVolt=PGGetVoltIndex(pBlock, pBlock->m_ACLineSegmentArray[nPGDev].szSubI,pBlock->m_ACLineSegmentArray[nPGDev].szVoltI);

			busBuffer.nNumber=lineBuffer.nBus1Number;
			strcpy(szBuffer, pBlock->m_ACLineSegmentArray[nPGDev].szName);
			ReplaceSubString(szBuffer, "��");
			ReplaceSubString(szBuffer, "��");
			strcpy(busBuffer.szName, ResolvePSFBusName(pBlock, pBlock->m_ACLineSegmentArray[nPGDev].szSubI, pBlock->m_ACLineSegmentArray[nPGDev].szVoltI, szBuffer, pBlock->m_ACLineSegmentArray[nPGDev].iRbs).c_str());

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;
			strcpy(busBuffer.szEquipmentName,lineBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == lineBuffer.nBus2Number)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			nSub=PGGetSubIndex(pBlock, pBlock->m_ACLineSegmentArray[nPGDev].szSubZ);
			nVolt=PGGetVoltIndex(pBlock, pBlock->m_ACLineSegmentArray[nPGDev].szSubZ,pBlock->m_ACLineSegmentArray[nPGDev].szVoltZ);

			busBuffer.nNumber=lineBuffer.nBus2Number;
			memset(busBuffer.szName,0,MDB_CHARLEN_TINY+1);
			strcpy(szBuffer, pBlock->m_ACLineSegmentArray[nPGDev].szName);
			ReplaceSubString(szBuffer, "��");
			ReplaceSubString(szBuffer, "��");
			strcpy(busBuffer.szName, ResolvePSFBusName(pBlock, pBlock->m_ACLineSegmentArray[nPGDev].szSubZ, pBlock->m_ACLineSegmentArray[nPGDev].szVoltZ, szBuffer, pBlock->m_ACLineSegmentArray[nPGDev].zRbs).c_str());

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;
			strcpy(busBuffer.szEquipmentName,lineBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_PG2PSFLineArray.size(); nDev++)
	{
		if (atoi(m_PG2PSFLineArray[nDev].szID) > 0)
			continue;

		nID=1;
		sprintf(m_PG2PSFLineArray[nDev].szID,"%d",nID++);
		for (i=nDev+1; i<(int)m_PG2PSFLineArray.size(); i++)
		{
			if (m_PG2PSFLineArray[nDev].nBus1Number == m_PG2PSFLineArray[i].nBus1Number && m_PG2PSFLineArray[nDev].nBus2Number == m_PG2PSFLineArray[i].nBus2Number ||
				m_PG2PSFLineArray[nDev].nBus1Number == m_PG2PSFLineArray[i].nBus2Number && m_PG2PSFLineArray[nDev].nBus2Number == m_PG2PSFLineArray[i].nBus1Number)
				sprintf(m_PG2PSFLineArray[i].szID,"%d",nID++);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("��·�����Ϣ������ϣ���ʱ%d����", nDur);

	for (nDev=0; nDev<(int)m_PGBoundNetTranArray.size(); nDev++)
	{
		nPGDev=m_PGBoundNetTranArray[nDev].nPGIndex;
		sprintf(szDevName,"%s,%s",pBlock->m_TransformerWindingArray[nPGDev].szSub,pBlock->m_TransformerWindingArray[nPGDev].szName);

		tranBuffer.nBus1Number=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_TransformerWindingArray[nPGDev].iRbs);
		tranBuffer.nBus2Number=ResolvePSFBoundTopoBus(nMaxPSFAsciiBusNumber, pBlock->m_TransformerWindingArray[nPGDev].zRbs);
		tranBuffer.fR=pBlock->m_TransformerWindingArray[nPGDev].r;
		tranBuffer.fX=pBlock->m_TransformerWindingArray[nPGDev].x;
		tranBuffer.fG=pBlock->m_TransformerWindingArray[nPGDev].g;
		tranBuffer.fB=pBlock->m_TransformerWindingArray[nPGDev].b;
		tranBuffer.nSection=1;
		tranBuffer.nStatus=PSF_Status_InService;
		tranBuffer.nMeterEnd=0;
		tranBuffer.nRatingGroup=1;
		tranBuffer.fONR=1.0;
		tranBuffer.fMVA=tranBuffer.fR1=pBlock->m_TransformerWindingArray[nPGDev].fRatedMva;
		if (PGGetTranRatio(pBlock, nPGDev, fTranRatio))
			tranBuffer.fONR=fTranRatio;

		//if (strstr(pBlock->m_TransformerWindingArray[nPGDev].szSub,"�Ŷ�����") != NULL)
		//	ASSERT(FALSE);
		//if (strstr(pBlock->m_TransformerWindingArray[nPGDev].szSub,"������˹") != NULL)
		//	ASSERT(FALSE);
		//if (strstr(pBlock->m_TransformerWindingArray[nPGDev].szSub,"����ľ��") != NULL)
		//	ASSERT(FALSE);
		sprintf(tranBuffer.szEquipmentName,"%s%s",ResolvePGShortSubName(pBlock->m_TransformerWindingArray[nPGDev].szSub).c_str(),pBlock->m_TransformerWindingArray[nPGDev].szName);
		m_PG2PSFTranArray.push_back(tranBuffer);

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == tranBuffer.nBus1Number)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			nSub=PGGetSubIndex(pBlock, pBlock->m_TransformerWindingArray[nPGDev].szSub);
			nVolt=PGGetVoltIndex(pBlock, pBlock->m_TransformerWindingArray[nPGDev].szSub,pBlock->m_TransformerWindingArray[nPGDev].szVoltI);

			busBuffer.nNumber=tranBuffer.nBus1Number;
			memset(busBuffer.szName,0,MDB_CHARLEN_TINY+1);
			if (PGIsTranMidNode(pBlock, pBlock->m_TransformerWindingArray[nPGDev].iRnd))
				sprintf(busBuffer.szName,"%s%st",ResolvePGShortSubName(pBlock->m_TransformerWindingArray[nPGDev].szSub).c_str(),pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nPGDev].iRTran].szName);
			else
				strcpy(busBuffer.szName, ResolvePSFBusName(pBlock, pBlock->m_TransformerWindingArray[nPGDev].szSub, pBlock->m_TransformerWindingArray[nPGDev].szVoltI, pBlock->m_TransformerWindingArray[nPGDev].szName, pBlock->m_TransformerWindingArray[nPGDev].iRbs).c_str());

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;
			strcpy(busBuffer.szEquipmentName,tranBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}

		bExist=0;
		for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
		{
			if (m_PG2PSFBusArray[i].nNumber == tranBuffer.nBus2Number)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			nSub=PGGetSubIndex(pBlock, pBlock->m_TransformerWindingArray[nPGDev].szSub);
			nVolt=PGGetVoltIndex(pBlock, pBlock->m_TransformerWindingArray[nPGDev].szSub,pBlock->m_TransformerWindingArray[nPGDev].szVoltZ);

			busBuffer.nNumber=tranBuffer.nBus2Number;
			memset(busBuffer.szName,0,MDB_CHARLEN_TINY+1);
			if (PGIsTranMidNode(pBlock, pBlock->m_TransformerWindingArray[nPGDev].zRnd))
				sprintf(busBuffer.szName,"%s%st",ResolvePGShortSubName(pBlock->m_TransformerWindingArray[nPGDev].szSub).c_str(),pBlock->m_PowerTransformerArray[pBlock->m_TransformerWindingArray[nPGDev].iRTran].szName);
			else
				strcpy(busBuffer.szName, ResolvePSFBusName(pBlock, pBlock->m_TransformerWindingArray[nPGDev].szSub, pBlock->m_TransformerWindingArray[nPGDev].szVoltZ, pBlock->m_TransformerWindingArray[nPGDev].szName, pBlock->m_TransformerWindingArray[nPGDev].zRbs).c_str());

			busBuffer.fVoltage=1.0;
			busBuffer.fkV=pBlock->m_VoltageLevelArray[nVolt].nominalVoltage;
			busBuffer.nArea=ResolvePG2PSFAreaNumber(pPSFAscii, lpszCorp);
			busBuffer.nZone=ResolvePG2PSFZoneNumber(pPSFAscii, pBlock->m_SubstationArray[nSub].szDiv);
			busBuffer.nType=PSFBus_Type_LoadBus;
			busBuffer.nStatus=PSF_Status_InService;
			strcpy(busBuffer.szEquipmentName,tranBuffer.szEquipmentName);

			m_PG2PSFBusArray.push_back(busBuffer);
		}
	}
	for (nDev=0; nDev<(int)m_PG2PSFTranArray.size(); nDev++)
	{
		if (atoi(m_PG2PSFTranArray[nDev].szID) > 0)
			continue;

		nID=1;
		sprintf(m_PG2PSFTranArray[nDev].szID,"%d",nID++);
		for (i=nDev+1; i<(int)m_PG2PSFTranArray.size(); i++)
		{
			if (m_PG2PSFTranArray[nDev].nBus1Number == m_PG2PSFTranArray[i].nBus1Number && m_PG2PSFTranArray[nDev].nBus2Number == m_PG2PSFTranArray[i].nBus2Number ||
				m_PG2PSFTranArray[nDev].nBus1Number == m_PG2PSFTranArray[i].nBus2Number && m_PG2PSFTranArray[nDev].nBus2Number == m_PG2PSFTranArray[i].nBus1Number)
				sprintf(m_PG2PSFTranArray[i].szID,"%d",nID++);
		}
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("��ѹ�������Ϣ������ϣ���ʱ%d����", nDur);

// 	for (i=0; i<(int)m_PG2PSFBusArray.size(); i++)
// 	{
// 		if (strlen(m_PG2PSFBusArray[i].szName) > 16)
// 			ASSERT(FALSE);
// 	}
// 	for (nDev=0; nDev<(int)m_PG2PSFBusArray.size(); nDev++)
// 	{
// 		for (i=nDev+1; i<(int)m_PG2PSFBusArray.size(); i++)
// 		{
// 			if (strcmp(m_PG2PSFBusArray[nDev].szName, m_PG2PSFBusArray[i].szName) == 0)
// 				ASSERT(FALSE);
// 		}
// 	}
}
