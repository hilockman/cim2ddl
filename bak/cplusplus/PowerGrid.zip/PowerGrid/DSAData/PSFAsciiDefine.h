#pragma once

const	static	char*	lpszDsaFlagReserved="1";
const	static	char*	lpszDsaPFBFormatVersion="10.0";

typedef	struct _PSFModelField_ 
{
	int		nFieldIndex;
	char*	lpszName;
	char*	lpszEnDesp;
	char*	lpszCnDesp;
	unsigned char	nFieldType;
	char*	lpszDefaultValue;
}	tagPSFModelField;

enum	_PSFEnum_Ascii_Section		{
	PSF_Section_Solution_history_data=0,
	PSF_Section_Bus_data,
	PSF_Section_Generator_data,
	PSF_Section_Load_data,
	PSF_Section_Load_model_data,
	PSF_Section_Fixed_shunt_data,
	PSF_Section_Switched_shunt_data,
	PSF_Section_Line_data,
	PSF_Section_Fixed_transformer_data,
	PSF_Section_ULTC_transformer_data,
	PSF_Section_Impedance_correction_tables,
	PSF_Section_Fixed_series_compensator_data,
	PSF_Section_Switchable_series_compensator_data,
	PSF_Section_FACTS_device_data,
	PSF_Section_3winding_transformer_data,
	PSF_Section_Area_interchange_data,
	PSF_Section_Interface_data,
	PSF_Section_Multi_terminal_DC_data,
	PSF_Section_Zone_data,
	PSF_Section_Node_mapping_data,
	PSF_Section_Zero_seq_mutual_coupling_data,
	PSF_Section_File_section_data,
	PSF_Section_File_End,
};

static	const char*	g_lpszPSFAsciiSection[]=
{
	"** SOLUTION HISTORY DATA **",
	"** BUS DATA **",
	"** GENERATOR DATA **",
	"** LOAD DATA **",
	"** LOAD MODEL DATA **",
	"** FIXED SHUNT DATA **",
	"** SWITCHED SHUNT DATA **",
	"** LINE DATA **",
	"** FIXED TRANSFORMER DATA **",
	"** ULTC TRANSFORMER DATA **",
	"** IMPEDANCE CORRECTION TABLES **",
	"** FIXED SERIES COMPENSATOR DATA **",
	"** SWITCHABLE SERIES COMPENSATOR DATA **",
	"** STATIC TAP CHANGER / PHASE REGULATOR DATA **",
	"** 3-WINDING TRANSFORMER DATA **",
	"** AREA INTERCHANGE DATA **",
	"** INTERFACE DATA **",
	"** MULTI TERMINAL DC DATA **",
	"** ZONE DATA **",
	"** NODE MAPPING DATA **",
	"** ZERO SEQ MUTUAL COUPLING DATA **",
	"** FILE SECTION DATA **",
	"** END OF PSF RAW DATA **",
};


static	const char	g_lpszPSF_MeterEnd[]=
{
	'F',
	'T',
};

static	const char	g_lpszPSF_CtrlSide[]=
{
	'F',
	'T',
};

enum	_PSFEnum_Status	{
	PSF_Status_OutOfService=0,
	PSF_Status_InService,
};

//////////////////////////////////////////////////////////////////////////
//	** SOLUTION HISTORY DATA **
//////////////////////////////////////////////////////////////////////////
static	const	char*	g_lpszPSFSolutionHistory_Flag[]=
{
	"ON",
	"OFF",
};
enum	_PSFEnum_SolutionHistory_Flag	{
	PSFSolutionHistory_Flag_ON=0,
	PSFSolutionHistory_Flag_OFF,
};

enum	_PSFEnum_PSFSolutionHistory_Field_	{
	PSFSolutionHistory_Date=0,
	PSFSolutionHistory_Time,
	PSFSolutionHistory_BaseMVA,
	PSFSolutionHistory_Method,
	PSFSolutionHistory_ITER,
	PSFSolutionHistory_SOLTOL,
	PSFSolutionHistory_BLUP,
	PSFSolutionHistory_ACCFCT,
	PSFSolutionHistory_ZIL,
	PSFSolutionHistory_VTOL,
	PSFSolutionHistory_CONADJ,
	PSFSolutionHistory_STOPT,
	PSFSolutionHistory_Flag1,
	PSFSolutionHistory_Flag2,
	PSFSolutionHistory_Flag3,
	PSFSolutionHistory_Flag4,
	PSFSolutionHistory_Flag5,
	PSFSolutionHistory_Flag6,
	PSFSolutionHistory_Flag7,
	PSFSolutionHistory_Flag8,
	PSFSolutionHistory_Flag9,
	PSFSolutionHistory_Flag10,
	PSFSolutionHistory_Flag11,
	PSFSolutionHistory_Flag12,
	PSFSolutionHistory_Flag13,
	PSFSolutionHistory_Flag14,
	PSFSolutionHistory_Flag15,
	PSFSolutionHistory_Flag16,
	PSFSolutionHistory_Flag17,
	PSFSolutionHistory_Description1,
	PSFSolutionHistory_Description2,
	PSFSolutionHistory_Description3,
};
static	tagPSFModelField	g_PSFSolutionHistoryColumn[]=
{
	{	PSFSolutionHistory_Date,			"Date",		"a text string with format ��dd-mmm-yy��.",																						"����(dd-mmm-yy)",			MDB_STRING,		"",			},
	{	PSFSolutionHistory_Time,			"Time",		"a text string with format ��hh:mm:ss��.",																						"ʱ��(hh:mm:ss)",			MDB_STRING,		"",			},
	{	PSFSolutionHistory_BaseMVA,			"BaseMVA",	"a positive real value (100 is taken as default if this is not provided) .",													"��׼����",					MDB_STRING,		"",			},
	{	PSFSolutionHistory_Method,			"Method",	"default powerflow solution algorithm,specified as a character string (default�CAuto).",										"�������㷽��",				MDB_STRING,		"Auto",		},
	{	PSFSolutionHistory_ITER,			"ITER",		"maximum number of iterations (default = 20).",																					"��������",					MDB_STRING,		"20",		},
	{	PSFSolutionHistory_SOLTOL,			"SOLTOL",	"convergence tolerance in terms of maximum MW or MVAR mismatch (default = 1.0).",												"��������",					MDB_FLOAT,		"1.0",		},
	{	PSFSolutionHistory_BLUP,			"BLUP",		"blow up limit in terms of maximum pu voltage magnitude deviations in each iteration (default = 1.0).",							"��ѹ��ֵ�仯����",			MDB_STRING,		"1.0",		},
	{	PSFSolutionHistory_ACCFCT,			"ACCFCT",	"acceleration factor, used to modify the amount of voltage correction when a bus is switched from PQ to PV (default = 1.0).",	"��������",					MDB_SHORT,		"1.0",		},
	{	PSFSolutionHistory_ZIL,				"ZIL",		"zero impedance threshold in pu on system MVA base(default = 0.00001).",														"���迹��ֵ",				MDB_FLOAT,		"0.00001",	},
	{	PSFSolutionHistory_VTOL,			"VTOL",		"voltage tolerance in pu(default = 0.0001).",																					"��ѹ����(pu)",				MDB_FLOAT,		"0.0001",	},
	{	PSFSolutionHistory_CONADJ,			"CONADJ",	"control adjustment threshold. This is used to initiate the control adjustment(default = 0.01).",								"����У����ֵ",				MDB_FLOAT,		"0.01",		},
	{	PSFSolutionHistory_STOPT,			"STOPT",	"hot or flat start option, specified as a character string (default�CHOT).",													"������ʽ",					MDB_STRING,		"HOT",		},
	{	PSFSolutionHistory_Flag1,			"Flag1",	"area interchange control (default = OFF).",																					"���򽻻�����",				MDB_FLOAT,		"OFF",		},
	{	PSFSolutionHistory_Flag2,			"Flag2",	"switchable shunts voltage control (default = OFF).",																			"�ɵ�����������ѹ����",		MDB_FLOAT,		"OFF",		},
	{	PSFSolutionHistory_Flag3,			"Flag3",	"transformers voltage control (default = OFF).",																				"��ѹ����ѹ����",			MDB_STRING,		"OFF",		},
	{	PSFSolutionHistory_Flag4,			"Flag4",	"phase shifters MW control (default = OFF).",																					"�������й�����",			MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag5,			"Flag5",	"transformers MVAR control (default = OFF).",																					"��ѹ���޹�����",			MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag6,			"Flag6",	"series Capacitors MW control (default = OFF).",																				"�����������й�����",		MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag7,			"Flag7",	"static tap changers voltage control (default = OFF).",																			"��̬��ͷ��ѹ����",			MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag8,			"Flag8",	"static tap changers MVAR control (default = OFF).",																			"��̬��ͷ�޹�����",			MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag9,			"Flag9",	"static phase shifters MW control (default = OFF).",																			"��̬�������й�����",		MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag10,			"Flag10",	"limit generator MVAR (default = ON).",																							"������޹���ֵ",			MDB_BIT,		"ON",		},
	{	PSFSolutionHistory_Flag11,			"Flag11",	"three winding transformers voltage control (default = OFF).",																	"�������ѹ����ѹ����",		MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag12,			"Flag12",	"interfaces MW control (default = OFF).",																						"�����й�����",				MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag13,			"Flag13",	"continuous shunts (SVC) voltage control (default = ON).",																		"SVC��ѹ����",				MDB_BIT,		"ON",		},
	{	PSFSolutionHistory_Flag14,			"Flag14",	"generator remote voltage control (default = ON).",																				"�����Զ�˵�ѹ����",		MDB_BIT,		"ON",		},
	{	PSFSolutionHistory_Flag15,			"Flag15",	"three winding transformers MVAR control (default = OFF).",																		"�������ѹ���޹�����",		MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag16,			"Flag16",	"three winding transformers MW control (default = OFF).",																		"�������ѹ���й�����",		MDB_BIT,		"OFF",		},
	{	PSFSolutionHistory_Flag17,			"Flag17",	"limit swing generator MVAR (default = ON).",																					"ƽ����޹���ֵ",			MDB_BIT,		"ON",		},
	{	PSFSolutionHistory_Description1,	"Desp1",	"case descriptions 1.",																											"����1",					MDB_BIT,		"",			},
	{	PSFSolutionHistory_Description2,	"Desp2",	"case descriptions 2.",																											"����2",					MDB_BIT,		"",			},
	{	PSFSolutionHistory_Description3,	"Desp3",	"case descriptions 3.",																											"����3",					MDB_BIT,		"",			},
};

typedef	struct _PSFSolutionHistory_
{
	char			szDescription1[MDB_CHARLEN_LONG];
	char			szDescription2[MDB_CHARLEN_LONG];
	char			szDescription3[MDB_CHARLEN_LONG];

	char			szDate[MDB_CHARLEN_TINY+1];
	char			szTime[MDB_CHARLEN_TINY];
	float			fBaseMVA;

	char			szMethod[MDB_CHARLEN_TINY];
	short			nITER;
	float			fSOLTOL;
	float			fBLUP;
	float			fACCFCT;
	float			fZIL;
	float			fVTOL;
	float			fCONADJ;
	char			szSTOPT[MDB_CHARLEN_TINY/2];

	unsigned char	bFlag1;
	unsigned char	bFlag2;
	unsigned char	bFlag3;
	unsigned char	bFlag4;
	unsigned char	bFlag5;
	unsigned char	bFlag6;
	unsigned char	bFlag7;
	unsigned char	bFlag8;
	unsigned char	bFlag9;
	unsigned char	bFlag10;
	unsigned char	bFlag11;
	unsigned char	bFlag12;
	unsigned char	bFlag13;
	unsigned char	bFlag14;
	unsigned char	bFlag15;
	unsigned char	bFlag16;
	unsigned char	bFlag17;
}	tagPSFSolutionHistory;

//////////////////////////////////////////////////////////////////////////
//	** BUS DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_Bus_Type		{
	PSFBus_Type_None=0,
	PSFBus_Type_LoadBus,
	PSFBus_Type_GeneratorBus,
	PSFBus_Type_SwingBus,
	PSFBus_Type_IsolatedBus,
};

enum	_PSFEnum_PSFBus_Field_	{
	PSFBus_Number=0,
	PSFBus_Name,
	PSFBus_Voltage,
	PSFBus_Angle,
	PSFBus_kV,
	PSFBus_Type,
	PSFBus_Status,
	PSFBus_Area,
	PSFBus_Zone,
	PSFBus_D1,
	PSFBus_D2,
	PSFBus_D3,
	PSFBus_D4,
	PSFBus_D5,
	PSFBus_Owner,
	PSFBus_EquipmentName,
	PSFBus_Latitude,
	PSFBus_Longitude,
	PSFBus_Substation,
	PSFBusEx_RTStatus,
};
static	tagPSFModelField	g_PSFBusColumn[]=
{
	{	PSFBus_Number,			"Number",			"Unique bus number used to identify the bus.",																		"ĸ�߱��",			MDB_INT,	"",		},
	{	PSFBus_Name,			"Name",				"Bus name. This name may not be unique, but unique names are required if bus names are used to identify buses.",	"ĸ������",			MDB_STRING,	"",		},
	{	PSFBus_Voltage,			"Voltage",			"Magnitude of the bus voltage in pu.",																				"ĸ�ߵ�ѹ",			MDB_FLOAT,	"",		},
	{	PSFBus_Angle,			"Angle",			"Angle of the bus voltage in degrees.",																				"ĸ�߹���",			MDB_FLOAT,	"",		},
	{	PSFBus_kV,				"kV",				"Bus rated kV.",																									"ĸ�߶��ѹ",		MDB_FLOAT,	"",		},
	{	PSFBus_Type,			"Type",				"Bus type",																											"ĸ������",			MDB_BIT,	"",		},
	{	PSFBus_Status,			"Status",			"Bus status",																										"ĸ��״̬",			MDB_BIT,	"",		},
	{	PSFBus_Area,			"Area",				"Area number. A bus can belong to only one area.",																	"ĸ������������",	MDB_SHORT,	"",		},
	{	PSFBus_Zone,			"Zone",				"Zone number. A bus can belong to only one zone.",																	"ĸ�����������",	MDB_SHORT,	"",		},
	{	PSFBus_D1,				"D1",				"Dummy parameters not currently used",																				"D1����ʱ����",		MDB_INT,	"0",	},
	{	PSFBus_D2,				"D2",				"Dummy parameters not currently used",																				"D2����ʱ����",		MDB_INT,	"0",	},
	{	PSFBus_D3,				"D3",				"Dummy parameters not currently used",																				"D3����ʱ����",		MDB_INT,	"0",	},
	{	PSFBus_D4,				"D4",				"Dummy parameters not currently used",																				"D4����ʱ����",		MDB_INT,	"0",	},
	{	PSFBus_D5,				"D5",				"Dummy parameters not currently used",																				"D5����ʱ����",		MDB_INT,	"0",	},
	{	PSFBus_Owner,			"Owner",			"bus owner name",																									"ĸ�߹���",			MDB_STRING,	"",		},
	{	PSFBus_EquipmentName,	"EquipmentName",	"bus equipment name.",																								"ĸ���豸��",		MDB_STRING,	"",		},
	{	PSFBus_Latitude,		"Latitude",			"bus owner name",																									"ĸ�߾���λ��",		MDB_FLOAT,	"",		},
	{	PSFBus_Longitude,		"Longitude",		"bus owner name",																									"ĸ��γ��λ��",		MDB_FLOAT,	"",		},
	{	PSFBus_Substation,		"Substation",		"bus belong to Substation Name.",																					"ĸ��������վ��",	MDB_STRING,	"",		},
	{	PSFBusEx_RTStatus,		"RTStatus",			"bus RT status.",																									"ĸ��״̬",			MDB_BIT,	"0",		},
};
typedef	struct _PSFBus_
{
	int				nNumber;
	char			szName[MDB_CHARLEN_TINY+1];
	float			fVoltage;
	float			fAngle;
	float			fkV;
	unsigned char	nType;
	unsigned char	nStatus;
	short			nArea;
	short			nZone;
	int				nD1;
	int				nD2;
	int				nD3;
	int				nD4;
	int				nD5;
	char			szOwner[MDB_CHARLEN_TINY];
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	float			fLatitude;
	float			fLongitude;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szZoneName[MDB_CHARLEN_TINY];
	char			szSubstation[MDB_CHARLEN];
	unsigned char	bTransformerNeutral;
	unsigned char	nRTStatus;

	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFBus;

//////////////////////////////////////////////////////////////////////////
//	** GENERATOR DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_Generator_Status	{
	PSFGenerator_Status_InService=1,		//	1
	PSFGenerator_Status_OutOfService=0,	//	0
	PSFGenerator_Status_NotAvailable=-1,	//	-1
};

enum	_PSFEnum_PSFGenerator_Field_	{
	PSFGeneratorEx_BusName=0,
	PSFGenerator_BusNumber,
	PSFGenerator_ID,
	PSFGenerator_Status,
	PSFGenerator_MW,
	PSFGenerator_MVAR,
	PSFGenerator_QMAX,
	PSFGenerator_QMIN,
	PSFGenerator_VHiLimit,
	PSFGenerator_VLoLimit,
	PSFGenerator_RemoteBus,
	PSFGenerator_RemoteBusV,
	PSFGenerator_QContributionPercentCtrl,
	PSFGenerator_USCHQ,
	PSFGenerator_MVA,
	PSFGenerator_PMAX,
	PSFGenerator_PMIN,
	PSFGenerator_RS,
	PSFGenerator_XS,
	PSFGenerator_RT,
	PSFGenerator_XT,
	PSFGenerator_TAP,
	PSFGenerator_EquipmentName,
	PSFGenerator_Owner,
	PSFGenerator_GWMOD,
	PSFGenerator_GWPF,
	PSFGenerator_GBASLD,
	PSFGenerator_RP,
	PSFGenerator_XP,
	PSFGenerator_RN,
	PSFGenerator_XN,
	PSFGenerator_RZ,
	PSFGenerator_XZ,
	PSFGenerator_RG,
	PSFGenerator_XG,
	PSFGeneratorEx_RTName,
	PSFGeneratorEx_RTMW,	
	PSFGeneratorEx_RTMVar,
	PSFGeneratorEx_RTVoltage,
	PSFGeneratorEx_RTStatus,
};
static	tagPSFModelField	g_PSFGeneratorColumn[]=
{
	{	PSFGeneratorEx_BusName,					"BusName",			"Resolved BusName",																										"�����ĸ������",				MDB_STRING,	"",		},
	{	PSFGenerator_BusNumber,					"BusNumber",		"Number of the bus where the generator is connected.",																	"ĸ�߱��",						MDB_INT,	"",		},
	{	PSFGenerator_ID,						"ID",				"8-character generator identifier which is used to distinguish among multiple generators connected to the same bus.",	"�����ID",						MDB_STRING,	"",		},
	{	PSFGenerator_Status,					"Status",			"Generator status.",																									"�����״̬",					MDB_BIT,	"",		},
	{	PSFGenerator_MW,						"MW",				"Generator active power output in MW.",																					"������й�����",				MDB_FLOAT,	"",		},
	{	PSFGenerator_MVAR,						"MVAR",				"Generator reactive power output in MVAR.",																				"������޹�����",				MDB_FLOAT,	"",		},
	{	PSFGenerator_QMAX,						"QMAX",				"Maximum generator reactive power output in MVAR.",																		"���������޹�",				MDB_FLOAT,	"",		},
	{	PSFGenerator_QMIN,						"QMIN",				"Minimum generator reactive power output in MVAR.",																		"�������С�޹�",				MDB_FLOAT,	"",		},
	{	PSFGenerator_VHiLimit,					"VHiLimit",			"Generator bus voltage upper limit in pu (default 1.5).",																"�����ĸ�ߵ�ѹ����",			MDB_FLOAT,	"1.5",	},
	{	PSFGenerator_VLoLimit,					"VLoLimit",			"Generator bus voltage lower limit in pu (default 0.5).",																"�����ĸ�ߵ�ѹ����",			MDB_FLOAT,	"0.5",	},
	{	PSFGenerator_RemoteBus,					"RemoteBus",		"Remote bus number for voltage control.",																				"����ĸ�߱��",					MDB_INT,	"",		},
	{	PSFGenerator_RemoteBusV,				"RemoteBusV",		"Desired voltage magnitude at the remote bus in pu.",																	"����ĸ��������ѹֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_QContributionPercentCtrl,	"%Ctrl",			"Percentage reactive power contribution of this generator to regulate the voltage at the remote bus (0 =<% Ctrl<=100).","Ϊ����ĸ���ṩ�޹��ٷֱ�",		MDB_FLOAT,	"",		},
	{	PSFGenerator_USCHQ,						"USCHQ",			"Generator reactive power output control flag.",																		"������޹�������Ʒ�ʽ",		MDB_BIT,	"",		},
	{	PSFGenerator_MVA,						"MVA",				"Generator MVA base.",																									"�������׼����",				MDB_FLOAT,	"",		},
	{	PSFGenerator_PMAX,						"PMAX",				"Maximum generator active power output in MW.",																			"���������й�ֵ",				MDB_FLOAT,	"",		},
	{	PSFGenerator_PMIN,						"PMIN",				"Minimum generator active power output in MW.",																			"�������С�й�ֵ",				MDB_FLOAT,	"",		},
	{	PSFGenerator_RS,						"RS",				"Generator internal impedance in pu on generator MVA base.",															"������ڵ���ֵ",				MDB_FLOAT,	"",		},
	{	PSFGenerator_XS,						"XS",				"Generator internal impedance in pu on generator MVA base.",															"������ڵ翹ֵ",				MDB_FLOAT,	"",		},
	{	PSFGenerator_RT,						"RT",				"Generator step-up transformer impedance in pu on generator MVA base.",													"�������ѹ��ѹ������ֵ",		MDB_FLOAT,	"",		},
	{	PSFGenerator_XT,						"XT",				"Generator step-up transformer impedance in pu on generator MVA base.",													"�������ѹ��ѹ���翹ֵ",		MDB_FLOAT,	"",		},
	{	PSFGenerator_TAP,						"TAP",				"Generator step-up transformer off-nominal turns ratio (from high tension to low tension) in pu.",						"�������ѹ��ѹ����ȱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFGenerator_EquipmentName,				"EquipmentName",	"Generator equipment name.",																							"�豸����",						MDB_STRING,	"",		},
	{	PSFGenerator_Owner,						"Owner",			"Generator owner name.",																								"������",						MDB_STRING,	"",		},
	{	PSFGenerator_GWMOD,						"GWMOD",			"Wind generator control mode.",																							"�������ģʽ",					MDB_BIT,	"",		},
	{	PSFGenerator_GWPF,						"GWPF",				"Wind generator power factor.",																							"�����������",					MDB_FLOAT,	"",		},
	{	PSFGenerator_GBASLD,					"GBASLD",			"Base load flag.",																										"�������׼���ɱ�ʶ",			MDB_BIT,	"",		},
	{	PSFGenerator_RP,						"RP",				"Generator positive sequence impedance in pu on generator MVA base.",													"���������������ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_XP,						"XP",				"Generator positive sequence impedance in pu on generator MVA base.",													"���������翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_RN,						"RN",				"Generator negative sequence impedance in pu on generator MVA base.",													"���������������ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_XN,						"XN",				"Generator negative sequence impedance in pu on generator MVA base.",													"���������翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_RZ,						"RZ",				"Generator zero sequence impedance in pu on generator MVA base.",														"���������������ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_XZ,						"XZ",				"Generator zero sequence impedance in pu on generator MVA base.",														"���������翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_RG,						"RG",				"Generator grounding impedance in pu on generator MVA base.",															"������ӵص������ֵ",			MDB_FLOAT,	"",		},
	{	PSFGenerator_XG,						"XG",				"Generator grounding impedance in pu on generator MVA base.",															"������ӵص翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFGeneratorEx_RTName,					"RTName",			"Resolved RTName",																										"�������������",				MDB_STRING,	"",		},
	{	PSFGeneratorEx_RTMW,					"RTMW",				"Resolved RTMW",																										"�й�����",						MDB_FLOAT,	"",		},
	{	PSFGeneratorEx_RTMVar,					"RTMVar",			"Resolved RTMVar",																										"�޹�����",						MDB_FLOAT,	"",		},
	{	PSFGeneratorEx_RTVoltage,				"RTVoltage",		"Resolved RTVoltage",																									"���˵�ѹ����",					MDB_FLOAT,	"",		},
	{	PSFGeneratorEx_RTStatus,				"RTStatus",			"Resolved RTStatus",																									"�����״̬",					MDB_BIT,	"",		},
};
typedef	struct _PSFGenerator_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBusName[MDB_CHARLEN_TINY+1];
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBusNumber;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nStatus;
	float			fMW;
	float			fMVar;
	float			fQMax;
	float			fQMin;
	float			fVHiLimit;
	float			fVLoLimit;
	int				nRemoteBus;
	float			fRemoteBusV;
	float			fQContributionPercentCtrl;
	unsigned char	nUSCHQ;
	float			fMva;
	float			fPMax;
	float			fPMin;
	float			fRS;
	float			fXS;
	float			fRT;
	float			fXT;
	float			fTAP;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szOwner[MDB_CHARLEN_TINY];
	unsigned char	nGWMOD;
	float			fGWPF;
	unsigned char	nGBASLD;
	float			fRP;
	float			fXP;
	float			fRN;
	float			fXN;
	float			fRZ;
	float			fXZ;
	float			fRG;
	float			fXG;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	int				nBusIndex;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	float			fRTMW;
	float			fRTMVar;
	float			fRTVoltage;
	unsigned char	nRTStatus;

	unsigned char	bRTDataSetted;
	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFGenerator;

//////////////////////////////////////////////////////////////////////////
//	** LOAD DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFLoad_Field_	{
	PSFLoadEx_BusName=0,
	PSFLoad_BusNumber,
	PSFLoad_RefP,
	PSFLoad_RefQ,
	PSFLoad_P1,
	PSFLoad_Q1,
	PSFLoad_P2,
	PSFLoad_Q2,
	PSFLoad_P3,
	PSFLoad_Q3,
	PSFLoad_P4,
	PSFLoad_Q4,
	PSFLoad_P5,
	PSFLoad_Q5,
	PSFLoad_M1,
	PSFLoad_M2,
	PSFLoad_M3,
	PSFLoad_M4,
	PSFLoad_M5,
	PSFLoad_Type,
	PSFLoad_Owner,
	PSFLoad_ID,
	PSFLoad_Scalable,
	PSFLoad_EquipmentName,
	PSFLoad_Area,
	PSFLoad_Zone,
	PSFLoad_Status,
	PSFLoad_GN,
	PSFLoad_BN,
	PSFLoad_GZ,
	PSFLoad_BZ,
	PSFLoadEx_RTName,
	PSFLoadEx_RTP,
	PSFLoadEx_RTQ,
	PSFLoadEx_RTStatus,
	PSFLoadEx_AuxLoad,
};
static	tagPSFModelField	g_PSFLoadColumn[]=
{
	{	PSFLoadEx_BusName,		"BusName",			"Resolved BusName",																				"����ĸ������",		MDB_STRING,	"",		},
	{	PSFLoad_BusNumber,		"BusNumber",		"Number of the bus where the load is connected.",												"ĸ�߱��",			MDB_INT,	"",		},
	{	PSFLoad_RefP,			"RefP",				"Reference P in MW.",																			"�й��ο�ֵ",		MDB_FLOAT,	"",		},
	{	PSFLoad_RefQ,			"RefQ",				"Reference P in MVAR.",																			"�޹��ο�ֵ",		MDB_FLOAT,	"",		},
	{	PSFLoad_P1,				"P1",				"active power of load components #1.",															"�������1�й�",	MDB_FLOAT,	"",		},
	{	PSFLoad_Q1,				"Q1",				"reactive power of load components #1.",														"�������1�޹�",	MDB_FLOAT,	"",		},
	{	PSFLoad_P2,				"P2",				"active power of load components #2.",															"�������2�й�",	MDB_FLOAT,	"",		},
	{	PSFLoad_Q2,				"Q2",				"reactive power of load components #2.",														"�������2�޹�",	MDB_FLOAT,	"",		},
	{	PSFLoad_P3,				"P3",				"active power of load components #3.",															"�������3�й�",	MDB_FLOAT,	"",		},
	{	PSFLoad_Q3,				"Q3",				"reactive power of load components #3.",														"�������3�޹�",	MDB_FLOAT,	"",		},
	{	PSFLoad_P4,				"P4",				"active power of load components #4.",															"�������4�й�",	MDB_FLOAT,	"",		},
	{	PSFLoad_Q4,				"Q4",				"reactive power of load components #4.",														"�������4�޹�",	MDB_FLOAT,	"",		},
	{	PSFLoad_P5,				"P5",				"active power of load components #5.",															"�������5�й�",	MDB_FLOAT,	"",		},
	{	PSFLoad_Q5,				"Q5",				"reactive power of load components #5.",														"�������5�޹�",	MDB_FLOAT,	"",		},
	{	PSFLoad_M1,				"M1",				"One of four load models for load components #1 to #5.",										"����ģ��1",		MDB_SHORT,	"",		},
	{	PSFLoad_M2,				"M2",				"One of four load models for load components #1 to #5.",										"����ģ��2",		MDB_SHORT,	"",		},
	{	PSFLoad_M3,				"M3",				"One of four load models for load components #1 to #5.",										"����ģ��3",		MDB_SHORT,	"",		},
	{	PSFLoad_M4,				"M4",				"One of four load models for load components #1 to #5.",										"����ģ��4",		MDB_SHORT,	"",		},
	{	PSFLoad_M5,				"M5",				"One of four load models for load components #1 to #5.",										"����ģ��5",		MDB_SHORT,	"",		},
	{	PSFLoad_Type,			"Type",				"Load type (reserved for future use). Enter 1.",												"��������",			MDB_INT,	"1",	},
	{	PSFLoad_Owner,			"Owner",			"Load owner name.",																				"������",			MDB_STRING,	"",		},
	{	PSFLoad_ID,				"ID",				"Load identifier used to distinguish among multiple loads at the same bus.",					"����ID",			MDB_STRING,	"",		},
	{	PSFLoad_Scalable,		"Scalable",			"Flag to determine if the load can be adjusted when performing load scaling (default is 1).",	"����У��",			MDB_BIT,	"1",	},
	{	PSFLoad_EquipmentName,	"EquipmentName",	"Load equipment name.",																			"�豸����",			MDB_STRING,	"",		},
	{	PSFLoad_Area,			"Area",				"Load area number. Default is bus area.",														"����������",		MDB_SHORT,	"",		},
	{	PSFLoad_Zone,			"Zone",				"Load zone number. Default is bus zone.",														"���ɷ������",		MDB_SHORT,	"",		},
	{	PSFLoad_Status,			"Status",			"Load status (default is 1).",																	"����״̬",			MDB_BIT,	"1",	},
	{	PSFLoad_GN,				"GN",				"Negative sequence admittance of the load in pu on system MVA base.",							"����絼����ֵ",	MDB_FLOAT,	"",		},
	{	PSFLoad_BN,				"BN",				"Negative sequence admittance of the load in pu on system MVA base.",							"������ɱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFLoad_GZ,				"GZ",				"Zero sequence admittance of the load in pu on system MVA base.",								"����絼����ֵ",	MDB_FLOAT,	"",		},
	{	PSFLoad_BZ,				"BZ",				"Zero sequence admittance of the load in pu on system MVA base.",								"������ɱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFLoadEx_RTName,		"RTName",			"Resolved RTName",																				"������������",		MDB_STRING,	"",		},
	{	PSFLoadEx_RTP,			"RTP",				"Resolved RTP",																					"�й�����",			MDB_FLOAT,	"",		},
	{	PSFLoadEx_RTQ,			"RTQ",				"Resolved RTQ",																					"�޹�����",			MDB_FLOAT,	"",		},
	{	PSFLoadEx_RTStatus,		"RTStatus",			"Resolved RTStatus",																			"����״̬",			MDB_BIT,	"0",	},
	{	PSFLoadEx_AuxLoad,		"AuxLoad",			"Auxiliary Load",																				"���õ���",		MDB_BIT,	"0",	},
};
typedef	struct _PSFLoad_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBusName[MDB_CHARLEN_TINY+1];
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBusNumber;
	float			fRefP;
	float			fRefQ;
	float			fP1;
	float			fQ1;
	float			fP2;
	float			fQ2;
	float			fP3;
	float			fQ3;
	float			fP4;
	float			fQ4;
	float			fP5;
	float			fQ5;
	short			nM1;
	short			nM2;
	short			nM3;
	short			nM4;
	short			nM5;
	int				nType;
	char			szOwner[MDB_CHARLEN_TINY];
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nScalable;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	short			nArea;
	short			nZone;
	unsigned char	nStatus;
	float			fGN;
	float			fBN;
	float			fGZ;
	float			fBZ;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	int				nBusIndex;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	float			fRTP;
	float			fRTQ;
	unsigned char	nRTStatus;
	unsigned char	bAuxiliary;

	unsigned char	bRTDataSetted;
	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFLoad;

//////////////////////////////////////////////////////////////////////////
//	** LOAD MODEL DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFLoadModel_Field_	{
	PSFLoadModel_ModelNumber=0,
	PSFLoadModel_A1,
	PSFLoadModel_A2,
	PSFLoadModel_A3,
	PSFLoadModel_N1,
	PSFLoadModel_N2,
	PSFLoadModel_N3,
	PSFLoadModel_B1,
	PSFLoadModel_B2,
	PSFLoadModel_B3,
	PSFLoadModel_M1,
	PSFLoadModel_M2,
	PSFLoadModel_M3,
};
static	tagPSFModelField	g_PSFLoadModelColumn[]=
{
	{	PSFLoadModel_ModelNumber,	"ModelNumber",	"The load model number (+k).",								"����ģ�͸���",		MDB_INT,	"",	},
	{	PSFLoadModel_A1,			"A1",			"a real number specifying the coefficients for P load.",	"�й�����ϵ��1",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_A2,			"A2",			"a real number specifying the coefficients for P load.",	"�й�����ϵ��2",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_A3,			"A3",			"a real number specifying the coefficients for P load.",	"�й�����ϵ��3",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_N1,			"N1",			"a real number specifying the exponents for P load.",		"�й�����ָ��1",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_N2,			"N2",			"a real number specifying the exponents for P load.",		"�й�����ָ��2",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_N3,			"N3",			"a real number specifying the exponents for P load.",		"�й�����ָ��3",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_B1,			"B1",			"a real number specifying the coefficients for Q load.",	"�޹�����ϵ��1",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_B2,			"B2",			"a real number specifying the coefficients for Q load.",	"�޹�����ϵ��2",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_B3,			"B3",			"a real number specifying the coefficients for Q load.",	"�޹�����ϵ��3",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_M1,			"M1",			"a real number specifying the exponents for Q load.",		"�޹�����ָ��1",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_M2,			"M2",			"a real number specifying the exponents for Q load.",		"�޹�����ָ��2",	MDB_FLOAT,	"",	},
	{	PSFLoadModel_M3,			"M3",			"a real number specifying the exponents for Q load.",		"�޹�����ָ��3",	MDB_FLOAT,	"",	},
};
typedef	struct _PSFLoadModel_
{
	int				nModelNumber;
	float			fA1;
	float			fA2;
	float			fA3;
	float			fN1;
	float			fN2;
	float			fN3;
	float			fB1;
	float			fB2;
	float			fB3;
	float			fM1;
	float			fM2;
	float			fM3;
}	tagPSFLoadModel;

//////////////////////////////////////////////////////////////////////////
//	** FIXED SHUNT DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFFixedShunt_Field_	{
	PSFFixedShuntEx_BusName=0,
	PSFFixedShunt_BusNumber,
	PSFFixedShunt_G,
	PSFFixedShunt_B,
	PSFFixedShunt_Type,
	PSFFixedShunt_Owner,
	PSFFixedShunt_ID,
	PSFFixedShunt_EquipmentName,
	PSFFixedShunt_Status,
	PSFFixedShunt_GN,
	PSFFixedShunt_BN,
	PSFFixedShunt_GZ,
	PSFFixedShunt_BZ,
	PSFFixedShuntEx_RTName,
};
static	tagPSFModelField	g_PSFFixedShuntColumn[]=
{
	{	PSFFixedShuntEx_BusName,	"BusName",			"Resolved BusName",																	"����ĸ������",		MDB_STRING,	"",		},
	{	PSFFixedShunt_BusNumber,	"BusNumber",		"Number of the bus where the shunt is connected.",									"ĸ�߱��",			MDB_INT,	"",		},
	{	PSFFixedShunt_G,			"G",				"Shunt admittance in MW and MVAR at unity voltage (positive B for capacitance).",	"�����絼ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedShunt_B,			"B",				"Shunt admittance in MW and MVAR at unity voltage (positive B for capacitance).",	"��������ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedShunt_Type,			"Type",				"Bus shunt type (default is 1).",													"����",				MDB_BIT,	"1",	},
	{	PSFFixedShunt_Owner,		"Owner",			"Fixed shunt owner name.",															"������",			MDB_STRING,	"",		},
	{	PSFFixedShunt_ID,			"ID",				"Fixed shunt identifier to distinguish among multiple shunts at the same bus.",		"�̶�����������ID",	MDB_STRING,	"",		},
	{	PSFFixedShunt_EquipmentName,"EquipmentName",	"Fixed shunt equipment name.",														"�豸����",			MDB_STRING,	"",		},
	{	PSFFixedShunt_Status,		"Status",			"Fixed shunt status (default is 1).",												"״̬",				MDB_BIT,	"1",	},
	{	PSFFixedShunt_GN,			"GN",				"Negative sequence admittance of the fixed shunt in pu on system MVA base.",		"����絼����ֵ",	MDB_FLOAT,	"",		},
	{	PSFFixedShunt_BN,			"BN",				"Negative sequence admittance of the fixed shunt in pu on system MVA base.",		"������ɱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFFixedShunt_GZ,			"GZ",				"Zero sequence admittance of the fixed shunt in pu on system MVA base.",			"����絼����ֵ",	MDB_FLOAT,	"",		},
	{	PSFFixedShunt_BZ,			"BZ",				"Zero sequence admittance of the fixed shunt in pu on system MVA base.",			"������ɱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFFixedShuntEx_RTName,		"RTName",			"Resolved RTName",																	"������������",		MDB_STRING,	"",		},
};
typedef	struct _PSFFixedShunt_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBusName[MDB_CHARLEN_TINY+1];
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBusNumber;
	float			fG;
	float			fB;
	unsigned char	nType;
	char			szOwner[MDB_CHARLEN_TINY];
	char			szID[MDB_CHARLEN_TINY/2];
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	unsigned char	nStatus;
	float			fGN;
	float			fBN;
	float			fGZ;
	float			fBZ;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	int				nBusIndex;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	unsigned char	nRTStatus;
	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFFixedShunt;

//////////////////////////////////////////////////////////////////////////
//	** SWITCHED SHUNT DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_SwitchableShunt_Mode	{
	PSFSwitchableShunt_Mode_Frozen=0,
	PSFSwitchableShunt_Mode_Discrete,
	PSFSwitchableShunt_Mode_Continuous,
	PSFSwitchableShunt_Mode_SVC,
	PSFSwitchableShunt_Mode_STATCON,
};

enum	_PSFEnum_PSFSwitchableShunt_Field_	{
	PSFSwitchableShuntEx_BusName=0,
	PSFSwitchableShunt_BusNumber,
	PSFSwitchableShunt_Mode,
	PSFSwitchableShunt_Status,
	PSFSwitchableShunt_VHiLimit,
	PSFSwitchableShunt_VLoLimit,
	PSFSwitchableShunt_RemoteBus,
	PSFSwitchableShunt_RemoteBusVoltage,
	PSFSwitchableShunt_QContributionPercentCtrl,
	PSFSwitchableShunt_G0,
	PSFSwitchableShunt_B0,
	PSFSwitchableShunt_Owner,
	PSFSwitchableShunt_ID,
	PSFSwitchableShunt_N1,
	PSFSwitchableShunt_B1,
	PSFSwitchableShunt_N2,
	PSFSwitchableShunt_B2,
	PSFSwitchableShunt_N3,
	PSFSwitchableShunt_B3,
	PSFSwitchableShunt_N4,
	PSFSwitchableShunt_B4,
	PSFSwitchableShunt_N5,
	PSFSwitchableShunt_B5,
	PSFSwitchableShunt_N6,
	PSFSwitchableShunt_B6,
	PSFSwitchableShunt_N7,
	PSFSwitchableShunt_B7,
	PSFSwitchableShunt_N8,
	PSFSwitchableShunt_B8,
	PSFSwitchableShunt_IMAX,
	PSFSwitchableShunt_EquipmentName,
	PSFSwitchableShunt_RVULimit,
	PSFSwitchableShunt_RVLLimit,
	PSFSwitchableShuntEx_RTName,
};
static	tagPSFModelField	g_PSFSwitchableShuntColumn[]=
{
	{	PSFSwitchableShuntEx_BusName,	"BusName",			"Resolved BusName",																									"����ĸ������",				MDB_STRING,	"",		},
	{	PSFSwitchableShunt_BusNumber,	"BusNumber",		"Number of the bus where the switchable shunt is connected.",														"ĸ�߱��",					MDB_INT,	"",		},
	{	PSFSwitchableShunt_Mode,		"Mode",				"Switchable shunt control mode.",																					"����ģʽ",					MDB_BIT,	"",		},
	{	PSFSwitchableShunt_Status,		"Status",			"Status of switchable shunt.",																						"״̬",						MDB_BIT,	"",		},
	{	PSFSwitchableShunt_VHiLimit,	"VHiLimit",			"Switchable shunt bus upper voltage limit in pu (default 1.5).",													"��ѹ����ֵ",				MDB_FLOAT,	"1.5",	},
	{	PSFSwitchableShunt_VLoLimit,	"VLoLimit",			"Switchable shunt bus lower voltage limit in pu (default 0.5).",													"��ѹ����ֵ",				MDB_FLOAT,	"0.5",	},
	{	PSFSwitchableShunt_RemoteBus,	"RemoteBus",		"Number of the remote bus whose voltage is to be controlled by the switchable shunt.",								"����ĸ�߱��",				MDB_INT,	"",		},
	{	PSFSwitchableShunt_RemoteBusVoltage,"RemoteBusVoltage",	"Desired voltage magnitude at the remote bus in pu.",															"����ĸ��������ѹ��ֵ",		MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_QContributionPercentCtrl,"%Ctrl",	"Percentage reactive power contribution of this switchable shunt to regulate the voltage at the remote bus.",	"Ϊ����ĸ���ṩ�޹��ٷֱ�",	MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_G0,			"G0",				"Initial switchable shunt admittance in MW and MVAR respectively at unity voltage (positive B0 for capacitance).",	"��ʼ�絼ֵ",				MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_B0,			"B0",				"Initial switchable shunt admittance in MW and MVAR respectively at unity voltage (positive B0 for capacitance).",	"��ʼ����ֵ",				MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_Owner,		"Owner",			"Switchable shunt owner name.",																						"������",					MDB_STRING,	"",		},
	{	PSFSwitchableShunt_ID,			"ID",				"Identifier to distinguish between multiple switchable shunts at the same bus.",									"�ɵ�����������ID",			MDB_STRING,	"",		},
	{	PSFSwitchableShunt_N1,			"N1",				"Number of steps in each shunt block.",																				"ģ��1�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B1,			"B1",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��1��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N2,			"N2",				"Number of steps in each shunt block.",																				"ģ��2�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B2,			"B2",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��2��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N3,			"N3",				"Number of steps in each shunt block.",																				"ģ��3�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B3,			"B3",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��3��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N4,			"N4",				"Number of steps in each shunt block.",																				"ģ��4�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B4,			"B4",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��4��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N5,			"N5",				"Number of steps in each shunt block.",																				"ģ��5�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B5,			"B5",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��5��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N6,			"N6",				"Number of steps in each shunt block.",																				"ģ��6�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B6,			"B6",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��6��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N7,			"N7",				"Number of steps in each shunt block.",																				"ģ��7�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B7,			"B7",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��7��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_N8,			"N8",				"Number of steps in each shunt block.",																				"ģ��8�ɵ��޹�����",		MDB_SHORT,	"",		},
	{	PSFSwitchableShunt_B8,			"B8",				"Susceptance increment for each of the step in a shunt block in MVAR at unity voltage.",							"ģ��8��λ�޹�",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_IMAX,		"IMAX",				"STATCON current limit (in amperes).",																				"��ֹ������������ֵ",		MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_EquipmentName,"EquipmentName",	"Switchable shunt equipment name.",																					"�豸����",					MDB_STRING,	"",		},
	{	PSFSwitchableShunt_RVULimit,	"RVULimit",			"Remote bus voltage upper limit",																					"����ĸ�ߵ�ѹ����",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShunt_RVLLimit,	"RVLLimit",			"Remote bus voltage lower limit.",																					"����ĸ�ߵ�ѹ����",			MDB_FLOAT,	"",		},
	{	PSFSwitchableShuntEx_RTName,	"RTName",			"Resolved RTName",																									"������������",				MDB_STRING,	"",		},
};
typedef	struct _PSFSwitchableShunt_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBusName[MDB_CHARLEN_TINY+1];
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBusNumber;
	unsigned char	nMode;
	unsigned char	nStatus;
	float			fVHiLimit;
	float			fVLoLimit;
	int				nRemoteBus;
	float			fRemoteBusVoltage;
	float			fQContributionPercentCtrl;
	float			fG0;
	float			fB0;

	char			szOwner[MDB_CHARLEN_TINY];
	char			szID[MDB_CHARLEN_TINY/2];
	short			nN1;
	float			fN1;
	short			nN2;
	float			fN2;
	short			nN3;
	float			fN3;
	short			nN4;
	float			fN4;
	short			nN5;
	float			fN5;
	short			nN6;
	float			fN6;
	short			nN7;
	float			fN7;
	short			nN8;
	float			fN8;

	float			fIMAX;

	char			szEquipmentName[MDB_CHARLEN_SHORT];
	float			fRVULimit;
	float			fRVLLimit;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	int				nBusIndex;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	unsigned char	nRTStatus;
	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFSwitchableShunt;

//////////////////////////////////////////////////////////////////////////
//	** LINE DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFLine_Field_	{
	PSFLineEx_PSFName=0,
	PSFLine_Bus1Number,
	PSFLine_Bus2Number,
	PSFLine_ID,
	PSFLine_Section,
	PSFLine_Status,
	PSFLine_MeterEnd,
	PSFLine_R,
	PSFLine_X,
	PSFLine_G,
	PSFLine_B,
	PSFLine_GF,
	PSFLine_BF,
	PSFLine_GT,
	PSFLine_BT,
	PSFLine_R1,
	PSFLine_R2,
	PSFLine_R3,
	PSFLine_R4,
	PSFLine_R5,
	PSFLine_R6,
	PSFLine_RatingGroup,
	PSFLine_Z1,
	PSFLine_Z2,
	PSFLine_Z3,
	PSFLine_Z4,
	PSFLine_Z5,
	PSFLine_Z6,
	PSFLine_Type,
	PSFLine_EquipmentName,
	PSFLine_Owner,
	PSFLine_Length,
	PSFLine_RZ,
	PSFLine_XZ,
	PSFLine_RZC,
	PSFLine_XZC,
	PSFLine_RZSF,
	PSFLine_XZSF,
	PSFLine_RZST,
	PSFLine_XZST,
	PSFLineEx_RTName,
	PSFLineEx_RTP1,
	PSFLineEx_RTQ1,
	PSFLineEx_RTP2,
	PSFLineEx_RTQ2,
	PSFLineEx_RTStatus,
	PSFLineEx_Bus1Name,
	PSFLineEx_Bus2Name,
};
static	tagPSFModelField	g_PSFLineColumn[]=
{
	{	PSFLineEx_PSFName,	"PSFName",			"Resolved PSFName",																					"��װ����",					MDB_STRING,	"",		},
	{	PSFLine_Bus1Number,	"Bus1Number",		"FROM bus number.",																					"���ĸ��",					MDB_INT,	"",		},
	{	PSFLine_Bus2Number,	"Bus2Number",		"TO bus number.",																					"�յ�ĸ��",					MDB_INT,	"",		},
	{	PSFLine_ID,			"ID",				"Line identifier.",																					"��·ID",					MDB_STRING,	"",		},
	{	PSFLine_Section,	"Section",			"Line section number (default 1).",																	"�ֶκ�",					MDB_BIT,	"1",	},
	{	PSFLine_Status,		"Status",			"Fixed transformer status.",																		"״̬",						MDB_BIT,	"",		},
	{	PSFLine_MeterEnd,	"MeterEnd",			"metered end identifier used for area interchange control",											"���򽻻����ʿ��ƵĲ�����",	MDB_BIT,	"",		},
	{	PSFLine_R,			"R",				"Series resistance of the line in pu on system MVA base.",											"�������ֵ",				MDB_FLOAT,	"",		},
	{	PSFLine_X,			"X",				"Series reactance of the line in pu on system MVA base.",											"�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSFLine_G,			"G",				"Conductance of the line charging in pu on system MVA base.",										"�絼����ֵ",				MDB_FLOAT,	"",		},
	{	PSFLine_B,			"B",				"Susceptance of the line charging in pu on system MVA base.",										"���ɱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSFLine_GF,			"GF",				"Conductance of the line shunt connected at the FROM bus in pu on system MVA base.",				"��㲢���絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFLine_BF,			"BF",				"Susceptance of the line shunt connected at the FROM bus in pu on system MVA base.",				"��㲢�����ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFLine_GT,			"GT",				"Conductance of the line shunt connected at the TO bus in pu on system MVA base.",					"�յ㲢���絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFLine_BT,			"BT",				"Susceptance of the line shunt connected at the TO bus in pu on system MVA base.",					"�յ㲢�����ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFLine_R1,			"R1",				"Line MVA ratings at nominal voltage.",																"�����ȼ�1",				MDB_FLOAT,	"",		},
	{	PSFLine_R2,			"R2",				"Line MVA ratings at nominal voltage.",																"�����ȼ�2",				MDB_FLOAT,	"",		},
	{	PSFLine_R3,			"R3",				"Line MVA ratings at nominal voltage.",																"�����ȼ�3",				MDB_FLOAT,	"",		},
	{	PSFLine_R4,			"R4",				"Line MVA ratings at nominal voltage.",																"�����ȼ�4",				MDB_FLOAT,	"",		},
	{	PSFLine_R5,			"R5",				"Line MVA ratings at nominal voltage.",																"�����ȼ�5",				MDB_FLOAT,	"",		},
	{	PSFLine_R6,			"R6",				"Line MVA ratings at nominal voltage.",																"�����ȼ�6",				MDB_FLOAT,	"",		},
	{	PSFLine_RatingGroup,"RatingGroup",		"Line rating group number (default 1).",															"�����ȼ�Ⱥ��",				MDB_SHORT,	"1",	},
	{	PSFLine_Z1,			"Z1",				"Zone number.",																						"�������1",				MDB_FLOAT,	"",		},
	{	PSFLine_Z2,			"Z2",				"Zone number.",																						"�������2",				MDB_FLOAT,	"",		},
	{	PSFLine_Z3,			"Z3",				"Zone number.",																						"�������3",				MDB_FLOAT,	"",		},
	{	PSFLine_Z4,			"Z4",				"Zone number.",																						"�������4",				MDB_FLOAT,	"",		},
	{	PSFLine_Z5,			"Z5",				"Zone number.",																						"�������5",				MDB_FLOAT,	"",		},
	{	PSFLine_Z6,			"Z6",				"Zone number.",																						"�������6",				MDB_FLOAT,	"",		},
	{	PSFLine_Type,		"Type",				"Line type (default is 1).",																		"����",						MDB_BIT,	"1",	},
	{	PSFLine_EquipmentName,	"EquipmentName","Line equipment name.",																				"�豸����",					MDB_STRING,	"",		},
	{	PSFLine_Owner,		"Owner",			"Line owner name.",																					"������",					MDB_STRING,	"",		},
	{	PSFLine_Length,		"Length",			"Line length in miles.",																			"��·����",					MDB_FLOAT,	"",		},
	{	PSFLine_RZ,			"RZ",				"Zero sequence impedance of the line in pu on system MVA base.",									"����������ֵ",			MDB_FLOAT,	"",		},
	{	PSFLine_XZ,			"XZ",				"Zero sequence impedance of the line in pu on system MVA base.",									"����翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFLine_RZC,		"RZC",				"Zero sequence charging admittance of the line in pu on system MVA base.",							"������絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFLine_XZC,		"XZC",				"Zero sequence charging admittance of the line in pu on system MVA base.",							"��������ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFLine_RZSF,		"RZSF",				"Zero sequence admittance of the line shunt connected at the FROM bus in pu on system MVA base.",	"������㲢���絼����ֵ",	MDB_FLOAT,	"",		},
	{	PSFLine_XZSF,		"XZSF",				"Zero sequence admittance of the line shunt connected at the FROM bus in pu on system MVA base.",	"������㲢�����ɱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFLine_RZST,		"RZST",				"Zero sequence admittance of the line shunt connected at the TO bus in pu on system MVA base.",		"�����յ㲢���絼����ֵ",	MDB_FLOAT,	"",		},
	{	PSFLine_XZST,		"XZST",				"Zero sequence admittance of the line shunt connected at the TO bus in pu on system MVA base.",		"�����յ㲢�����ɱ���ֵ",	MDB_FLOAT,	"",		},
	{	PSFLineEx_RTName,	"RTName",			"Resolved RTName",																					"������·����",				MDB_STRING,	"",		},
	{	PSFLineEx_RTP1,		"RTP1",				"Resolved RTP1",																					"����й�����",				MDB_FLOAT,	"",		},
	{	PSFLineEx_RTQ1,		"RTQ1",				"Resolved RTQ1",																					"����޹�����",				MDB_FLOAT,	"",		},
	{	PSFLineEx_RTP2,		"RTP2",				"Resolved RTP2",																					"�յ��й�����",				MDB_FLOAT,	"",		},
	{	PSFLineEx_RTQ2,		"RTQ2",				"Resolved RTQ2",																					"�յ��޹�����",				MDB_FLOAT,	"",		},
	{	PSFLineEx_RTStatus,	"RTStatus",			"Resolved RTStatus",																				"��·״̬",					MDB_BIT,	"",		},
	{	PSFLineEx_Bus1Name,	"Bus1Name",			"Resolved Bus1Name",																				"���ĸ������",				MDB_STRING,	"",		},
	{	PSFLineEx_Bus2Name,	"Bus2Name",			"Resolved Bus2Name",																				"�յ�ĸ������",				MDB_STRING,	"",		},
};
// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, R, X, G, B
// GF, BF, GT, BT, R1, R2, R3, R4, R5, R6, Rating group, Z1, Z2, Z3, Z4, Z5, Z6, Type
// Equipment name, Owner, Length
// RZ, XZ, RZC, XZC, RZSF, XZSF, RZST, XZST
typedef	struct _PSFLine_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szPSFName[MDB_CHARLEN];	//	����
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBus1Number;
	int				nBus2Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nSection;
	unsigned char	nStatus;
	unsigned char	nMeterEnd;
	float			fR;
	float			fX;
	float			fG;
	float			fB;
	float			fGF;
	float			fBF;
	float			fGT;
	float			fBT;
	float			fR1;
	float			fR2;
	float			fR3;
	float			fR4;
	float			fR5;
	float			fR6;
	short			nRatingGroup;
	float			fZ1;
	float			fZ2;
	float			fZ3;
	float			fZ4;
	float			fZ5;
	float			fZ6;
	unsigned char	nType;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szOwner[MDB_CHARLEN_TINY];
	float			fLength;
	float			fRZ;
	float			fXZ;
	float			fRZC;
	float			fXZC;
	float			fRZSF;
	float			fXZSF;
	float			fRZST;
	float			fXZST;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	float			fRTP1;
	float			fRTQ1;
	float			fRTP2;
	float			fRTQ2;
	unsigned char	nRTStatus;

	unsigned char	bRTDataSetted;

	unsigned char	bOpened;
	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFLine;

//////////////////////////////////////////////////////////////////////////
//	** FIXED TRANSFORMER DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFFixedTransformer_Field_	{
	PSFFixedTransformerEx_PSFName=0,
	PSFFixedTransformer_Bus1Number,
	PSFFixedTransformer_Bus2Number,
	PSFFixedTransformer_ID,
	PSFFixedTransformer_Section,
	PSFFixedTransformer_Status,
	PSFFixedTransformer_MeterEnd,
	PSFFixedTransformer_ONR,
	PSFFixedTransformer_Angle,
	PSFFixedTransformer_R,
	PSFFixedTransformer_X,
	PSFFixedTransformer_G,
	PSFFixedTransformer_B,
	PSFFixedTransformer_GF,
	PSFFixedTransformer_BF,
	PSFFixedTransformer_GT,
	PSFFixedTransformer_BT,
	PSFFixedTransformer_R1,
	PSFFixedTransformer_R2,
	PSFFixedTransformer_R3,
	PSFFixedTransformer_R4,
	PSFFixedTransformer_R5,
	PSFFixedTransformer_R6,
	PSFFixedTransformer_RatingGroup,
	PSFFixedTransformer_MVA,
	PSFFixedTransformer_Z1,
	PSFFixedTransformer_Z2,
	PSFFixedTransformer_Z3,
	PSFFixedTransformer_Z4,
	PSFFixedTransformer_Z5,
	PSFFixedTransformer_Z6,
	PSFFixedTransformer_EquipmentName,
	PSFFixedTransformer_Name,
	PSFFixedTransformer_Owner,
	PSFFixedTransformer_RZ,
	PSFFixedTransformer_XZ,
	PSFFixedTransformer_WindConnectionCode,
	PSFFixedTransformer_RGF,
	PSFFixedTransformer_XGF,
	PSFFixedTransformer_RGT,
	PSFFixedTransformer_XGT,
	PSFFixedTransformerEx_Bus1Name,
	PSFFixedTransformerEx_Bus2Name,
	PSFFixedTransformerEx_RTName,
	PSFFixedTransformerEx_RTP1,
	PSFFixedTransformerEx_RTQ1,
	PSFFixedTransformerEx_RTP2,
	PSFFixedTransformerEx_RTQ2,
	PSFFixedTransformerEx_RTRatio,
	PSFFixedTransformerEx_RTStatus,
};
static	tagPSFModelField	g_PSFFixedTransformerColumn[]=
{
	{	PSFFixedTransformerEx_PSFName,	"PSFName",			"Resolved PSFName",																						"��װ����",					MDB_STRING,	"",		},
	{	PSFFixedTransformer_Bus1Number,	"Bus1Number",		"FROM bus number.",																						"���ĸ��",					MDB_INT,	"",		},
	{	PSFFixedTransformer_Bus2Number,	"Bus2Number",		"FROM bus number.",																						"�յ�ĸ��",					MDB_INT,	"",		},
	{	PSFFixedTransformer_ID,			"ID",				"Fixed transformer identifier.",																		"��ѹ��ID",					MDB_STRING,	"",		},
	{	PSFFixedTransformer_Section,	"Section",			"Fixed transformer section number (default 1).",														"�ֶκ�",					MDB_BIT,	"1",	},
	{	PSFFixedTransformer_Status,		"Status",			"Line status.",																							"״̬",						MDB_BIT,	"",		},
	{	PSFFixedTransformer_MeterEnd,	"MeterEnd",			"metered end identifier used for area interchange control",												"���򽻻����ʿ��ƵĲ�����",	MDB_BIT,	"",		},
	{	PSFFixedTransformer_ONR,		"ONR",				"Transformer turns ratio in pu.",																		"��ȱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Angle,		"Angle",			"Transformer phase shift angle in degrees.",															"��λ��",					MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R,			"R",				"Series resistance of the fixed transformer in pu on system MVA base.",									"�������ֵ",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_X,			"X",				"Series reactance of the fixed transformer in pu on system MVA base.",									"�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_G,			"G",				"Conductance of the fixed transformer charging in pu on system MVA base.",								"�絼����ֵ",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_B,			"B",				"Susceptance of the fixed transformer charging in pu on system MVA base.",								"���ɱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_GF,			"GF",				"Conductance of transformer magnetization to be represented at the FROM bus in pu on system MVA base.",	"��㼤�ŵ絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_BF,			"BF",				"Susceptance of transformer magnetization to be represented at the FROM bus in pu on system MVA base.",	"��㼤�ŵ��ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_GT,			"GT",				"Conductance of transformer magnetization to be represented at the TO bus in pu on system MVA base.",	"�յ㼤�ŵ絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_BT,			"BT",				"Susceptance of transformer magnetization to be represented at the TO bus in pu on system MVA base.",	"�յ㼤�ŵ��ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R1,			"R1",				"Transformer MVA ratings at nominal voltage.",															"�����ȼ�1",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R2,			"R2",				"Transformer MVA ratings at nominal voltage.",															"�����ȼ�2",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R3,			"R3",				"Transformer MVA ratings at nominal voltage.",															"�����ȼ�3",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R4,			"R4",				"Transformer MVA ratings at nominal voltage.",															"�����ȼ�4",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R5,			"R5",				"Transformer MVA ratings at nominal voltage.",															"�����ȼ�5",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_R6,			"R6",				"Transformer MVA ratings at nominal voltage.",															"�����ȼ�6",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_RatingGroup,"RatingGroup",		"Fixed transformer rating group number (default 1).",													"�����ȼ�Ⱥ��",				MDB_SHORT,	"1",	},
	{	PSFFixedTransformer_MVA,		"MVA",				"Fixed transformer rated MVA.",																			"�������1",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Z1,			"Z1",				"Zone number.",																							"�������1",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Z2,			"Z2",				"Zone number.",																							"�������2",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Z3,			"Z3",				"Zone number.",																							"�������3",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Z4,			"Z4",				"Zone number.",																							"�������4",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Z5,			"Z5",				"Zone number.",																							"�������5",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_Z6,			"Z6",				"Zone number.",																							"�������6",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_EquipmentName,	"EquipmentName","Fixed transformer equipment name.",																	"�豸����",					MDB_STRING,	"",		},
	{	PSFFixedTransformer_Name,		"Name",				"Fixed transformer name.",																				"��ѹ������",				MDB_STRING,	"",		},
	{	PSFFixedTransformer_Owner,		"Owner",			"Fixed transformer owner name.",																		"������",					MDB_STRING,	"",		},
	{	PSFFixedTransformer_RZ,			"RZ",				"Zero sequence impedance of the transformer in pu on system MVA base.",									"����������ֵ",			MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_XZ,			"XZ",				"Zero sequence impedance of the transformer in pu on system MVA base.",									"����翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_WindConnectionCode,	"Code",		"Transformer winding connection code.",																	"��ѹ�������������",		MDB_BIT,	"",		},
	{	PSFFixedTransformer_RGF,		"RGF",				"Grounding resistance of the transformer at the FROM-bus side in pu on system MVA base.",				"����Եص������ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_XGF,		"XGF",				"Grounding reactance of the transformer at the FROM-bus side in pu on system MVA base.",				"����Եص翹����ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_RGT,		"RGT",				"Grounding resistance of the transformer at the TO-bus side in pu on system MVA base.",					"�յ��Եص������ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformer_XGT,		"XGT",				"Grounding reactance of the transformer at the TO-bus side in pu on system MVA base.",					"�յ��Եص翹����ֵ",		MDB_FLOAT,	"",		},
	{	PSFFixedTransformerEx_Bus1Name,	"Bus1Name",			"Resolved Bus1Name",																					"���ĸ������",				MDB_STRING,	"",		},
	{	PSFFixedTransformerEx_Bus2Name,	"Bus2Name",			"Resolved Bus2Name",																					"�յ�ĸ������",				MDB_STRING,	"",		},
	{	PSFFixedTransformerEx_RTName,	"RTName",			"Resolved RTName",																						"�����豸����",				MDB_STRING,	"",		},
	{	PSFFixedTransformerEx_RTP1,		"RTP1",				"Resolved RTP1",																						"����й�����",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformerEx_RTQ1,		"RTQ1",				"Resolved RTQ1",																						"����޹�����",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformerEx_RTP2,		"RTP2",				"Resolved RTP2",																						"�յ��й�����",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformerEx_RTQ2,		"RTQ2",				"Resolved RTQ2",																						"�յ��޹�����",				MDB_FLOAT,	"",		},
	{	PSFFixedTransformerEx_RTRatio,	"RTRatio",			"Resolved RTRatio",																						"��ѹ���������",			MDB_FLOAT,	"",		},
	{	PSFFixedTransformerEx_RTStatus,	"RTStatus",			"Resolved RTStatus",																					"��ѹ��״̬",				MDB_BIT,	"",		},
};

typedef	struct _PSFFixedTransformer_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szPSFName[MDB_CHARLEN];	//	����
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBus1Number;
	int				nBus2Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nSection;
	unsigned char	nStatus;
	unsigned char	nMeterEnd;
	float			fONR;
	float			fAngle;
	float			fR;
	float			fX;
	float			fG;
	float			fB;
	float			fGF;
	float			fBF;
	float			fGT;
	float			fBT;
	float			fR1;
	float			fR2;
	float			fR3;
	float			fR4;
	float			fR5;
	float			fR6;
	short			nRatingGroup;
	float			fMVA;
	float			fZ1;
	float			fZ2;
	float			fZ3;
	float			fZ4;
	float			fZ5;
	float			fZ6;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szName[MDB_CHARLEN_TINY];
	char			szOwner[MDB_CHARLEN_TINY];
	float			fRZ;
	float			fXZ;
	unsigned char	nWindConnectionCode;
	float			fRGF;
	float			fXGF;
	float			fRGT;
	float			fXGT;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	float			fRTP1;
	float			fRTQ1;
	float			fRTP2;
	float			fRTQ2;
	float			fRTTap;
	unsigned char	nRTStatus;

	unsigned char	bRTDataSetted;
	unsigned char	bOpened;
	unsigned char	bPG2PSFDeleteFlag;
}	tagPSFFixedTransformer;

//////////////////////////////////////////////////////////////////////////
//	** ULTC TRANSFORMER DATA **
//////////////////////////////////////////////////////////////////////////
static	const char	g_lpszPSFPSFULTCTransformer_CtrlType[]=
{
	'V',
	'Q',
	'P',
};

enum	_PSFEnum_PSFULTCTransformer_Field_	{
	PSFULTCTransformerEx_PSFName=0,
	PSFULTCTransformer_Bus1Number,
	PSFULTCTransformer_Bus2Number,
	PSFULTCTransformer_ID,
	PSFULTCTransformer_Section,
	PSFULTCTransformer_Status,
	PSFULTCTransformer_MeterEnd,
	PSFULTCTransformer_FromRatio,
	PSFULTCTransformer_ToRatio,
	PSFULTCTransformer_Angle,
	PSFULTCTransformer_R,
	PSFULTCTransformer_X,
	PSFULTCTransformer_G,
	PSFULTCTransformer_B,
	PSFULTCTransformer_GF,
	PSFULTCTransformer_BF,
	PSFULTCTransformer_GT,
	PSFULTCTransformer_BT,
	PSFULTCTransformer_MaxR,
	PSFULTCTransformer_MinR,
	PSFULTCTransformer_Step,
	PSFULTCTransformer_MaxA,
	PSFULTCTransformer_MinA,
	PSFULTCTransformer_AStep,
	PSFULTCTransformer_CtrlType,
	PSFULTCTransformer_CtrlSide,
	PSFULTCTransformer_CtrlFlag,
	PSFULTCTransformer_MaxMW,
	PSFULTCTransformer_MinMW,
	PSFULTCTransformer_MaxMVar,
	PSFULTCTransformer_MinMVar,
	PSFULTCTransformer_VHiLimit,
	PSFULTCTransformer_VLoLimit,
	PSFULTCTransformer_CtrlBus,
	PSFULTCTransformer_ZCorrTable,
	PSFULTCTransformer_R1,
	PSFULTCTransformer_R2,
	PSFULTCTransformer_R3,
	PSFULTCTransformer_R4,
	PSFULTCTransformer_R5,
	PSFULTCTransformer_R6,
	PSFULTCTransformer_RatingGroup,
	PSFULTCTransformer_MVA,
	PSFULTCTransformer_Z1,
	PSFULTCTransformer_Z2,
	PSFULTCTransformer_Z3,
	PSFULTCTransformer_Z4,
	PSFULTCTransformer_Z5,
	PSFULTCTransformer_Z6,
	PSFULTCTransformer_EquipmentName,
	PSFULTCTransformer_Name,
	PSFULTCTransformer_Owner,
	PSFULTCTransformer_RZ,
	PSFULTCTransformer_XZ,
	PSFULTCTransformer_WindConnectionCode,
	PSFULTCTransformer_RGF,
	PSFULTCTransformer_XGF,
	PSFULTCTransformer_RGT,
	PSFULTCTransformer_XGT,
	PSFULTCTransformerEx_Bus1Name,
	PSFULTCTransformerEx_Bus2Name,
};
static	tagPSFModelField	g_PSFULTCTransformerColumn[]=
{
	{	PSFULTCTransformerEx_PSFName,	"PSFName",			"Resolved PSFName",																						"��װ����",					MDB_STRING,	"",		},
	{	PSFULTCTransformer_Bus1Number,	"Bus1Number",		"FROM bus number.",																						"���ĸ��",					MDB_INT,	"",		},
	{	PSFULTCTransformer_Bus2Number,	"Bus2Number",		"TO bus number.",																						"�յ�ĸ��",					MDB_INT,	"",		},
	{	PSFULTCTransformer_ID,			"ID",				"ULTC transformer identifier.",																			"ULTC��ѹ��ID",				MDB_STRING,	"",		},
	{	PSFULTCTransformer_Section,		"section",			"ULTC transformer section number (default 1).",															"�ֶκ�",					MDB_BIT,	"1",	},
	{	PSFULTCTransformer_Status,		"Status",			"ULTC transformer status.",																				"״̬",						MDB_BIT,	"",		},
	{	PSFULTCTransformer_MeterEnd,	"MeterEnd",			"metered end identifier used for area interchange control.",											"���򽻻����ʿ��ƵĲ�����",	MDB_BIT,	"",		},
	{	PSFULTCTransformer_FromRatio,	"FromRatio",		"Transformer FROM-side (primary) turns ratio in pu.",													"һ�β��ȱ���ֵ",			MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_ToRatio,		"ToRatio",			"Transformer TO-side (secondary) turns ratio in pu.",													"���β��ȱ���ֵ",			MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Angle,		"Angle",			"Transformer phase shift angle in degrees",																"��λ��",					MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_R,			"R",				"Series resistance of the ULTC transformer in pu on system MVA base.",									"�������ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_X,			"X",				"Series reactance of the ULTC transformer in pu on system MVA base.",									"�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_G,			"G",				"Conductance of the ULTC transformer charging in pu on system MVA base.",								"�絼����ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_B,			"B",				"Susceptance of the ULTC transformer charging in pu on system MVA base.",								"���ɱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_GF,			"GF",				"Conductance of transformer magnetization to be represented at the FROM bus in pu on system MVA base.",	"��㼤�ŵ絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_BF,			"BF",				"Susceptance of transformer magnetization to be represented at the FROM bus in pu on system MVA base.",	"��㼤�ŵ��ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_GT,			"GT",				"Conductance of transformer magnetization to be represented at the TO bus in pu on system MVA base.",	"�յ㼤�ŵ絼����ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_BT,			"BT",				"Susceptance of transformer magnetization to be represented at the TO bus in pu on system MVA base.",	"�յ㼤�ŵ��ɱ���ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_MaxR,		"MaxR",				"Upper limit for FROM-side turns ratio in pu (default 1.5).",											"һ�β��ȱ���ֵ����",		MDB_FLOAT,	"1.5",	},
	{	PSFULTCTransformer_MinR,		"MinR",				"lower limit for FROM-side turns ratio in pu (default 0.5).",											"һ�β��ȱ���ֵ����",		MDB_FLOAT,	"0.5",	},
	{	PSFULTCTransformer_Step,		"Step",				"FROM-side turns ratio step size in pu.",																"һ�β��ȱ��۵�λ�仯ֵ",	MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_MaxA,		"MaxA",				"Upper limit for phase shift angle in degrees.",														"��λ������",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_MinA,		"MinA",				"Lower limit for phase shift angle in degrees.",														"��λ������",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_AStep,		"AStep",			"Number of phase shift angle steps.",																	"��λ�ǵ�λ�仯ֵ",			MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_CtrlType,	"CtrlType",			"1-character control type identifier.",																	"��������",					MDB_BIT,	"V",	},
	{	PSFULTCTransformer_CtrlSide,	"CtrlSide",			"1-character text string that specifies the local voltage control location.",							"���Ʋ�",					MDB_BIT,	"F",	},
	{	PSFULTCTransformer_CtrlFlag,	"CtrlFlag",			"Control flag.",																						"���Ʊ�ʶ",					MDB_BIT,	"",		},
	{	PSFULTCTransformer_MaxMW,		"MaxMW",			"Upper limit for active power flow (in MW) through the ULTC transformer.",								"�й�����ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_MinMW,		"MinMW",			"Lower limit for active power flow (in MW) through the ULTC transformer.",								"�й�����ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_MaxMVar,		"MaxMVar",			"Upper limit for reactive power flow (in MVAR) through the ULTC transformer.",							"�޹�����ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_MinMVar,		"MinMVar",			"Lower limit for reactive power flow (in MVAR) through the ULTC transformer.",							"�޹�����ֵ",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_VHiLimit,	"VHiLimit",			"Upper limit for controlled bus voltage in pu (default 1.5).",											"����ĸ�ߵ�ѹ����",			MDB_FLOAT,	"1.5",	},
	{	PSFULTCTransformer_VLoLimit,	"VLoLimit",			"Lower limit for controlled bus voltage in pu (default 0.5).",											"����ĸ�ߵ�ѹ����",			MDB_FLOAT,	"0.5",	},
	{	PSFULTCTransformer_CtrlBus,		"CtrlBus",			"Controlled bus number.",																				"����ĸ�߱��",				MDB_INT,	"",		},
	{	PSFULTCTransformer_ZCorrTable,	"ZCorrTable",		"Number of transformer or phase shifter impedance correction table.",									"�������迹У�������",		MDB_INT,	"",		},
	{	PSFULTCTransformer_R1,			"R1",				"ULTC Transformer MVA ratings at nominal voltage.",														"�����ȼ�1",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_R2,			"R2",				"ULTC Transformer MVA ratings at nominal voltage.",														"�����ȼ�2",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_R3,			"R3",				"ULTC Transformer MVA ratings at nominal voltage.",														"�����ȼ�3",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_R4,			"R4",				"ULTC Transformer MVA ratings at nominal voltage.",														"�����ȼ�4",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_R5,			"R5",				"ULTC Transformer MVA ratings at nominal voltage.",														"�����ȼ�5",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_R6,			"R6",				"ULTC Transformer MVA ratings at nominal voltage.",														"�����ȼ�6",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_RatingGroup,"RatingGroup",		"ULTC transformer rating group number (default 1).",													"�����ȼ�Ⱥ��",				MDB_SHORT,	"1",	},
	{	PSFULTCTransformer_MVA,			"MVA",				"ULTC transformer rated MVA.",																			"�������1",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Z1,			"Z1",				"Zone number.",																							"�������1",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Z2,			"Z2",				"Zone number.",																							"�������2",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Z3,			"Z3",				"Zone number.",																							"�������3",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Z4,			"Z4",				"Zone number.",																							"�������4",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Z5,			"Z5",				"Zone number.",																							"�������5",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_Z6,			"Z6",				"Zone number.",																							"�������6",				MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_EquipmentName,	"EquipmentName","ULTC transformer equipment name.",																		"�豸����",					MDB_STRING,	"",		},
	{	PSFULTCTransformer_Name,		"Name",				"ULTC transformer name.",																				"��ѹ������",				MDB_STRING,	"",		},
	{	PSFULTCTransformer_Owner,		"Owner",			"ULTC transformer owner name.",																			"������",					MDB_STRING,	"",		},
	{	PSFULTCTransformer_RZ,			"RZ",				"Zero sequence impedance of the transformer in pu on system MVA base.",									"����������ֵ",			MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_XZ,			"XZ",				"Zero sequence impedance of the transformer in pu on system MVA base.",									"����翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_WindConnectionCode,	"Code",		"ULTC Transformer winding connection code.",															"��ѹ�������������",		MDB_BIT,	"",		},
	{	PSFULTCTransformer_RGF,			"RGF",				"Grounding resistance of the ULTC transformer at the FROM-bus side in pu on system MVA base.",			"����Եص������ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_XGF,			"XGF",				"Grounding reactance of the ULTC transformer at the FROM-bus side in pu on system MVA base.",			"����Եص翹����ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_RGT,			"RGT",				"Grounding resistance of the ULTC transformer at the TO-bus side in pu on system MVA base.",			"�յ��Եص������ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformer_XGT,			"XGT",				"Grounding reactance of the ULTC transformer at the TO-bus side in pu on system MVA base.",				"�յ��Եص翹����ֵ",		MDB_FLOAT,	"",		},
	{	PSFULTCTransformerEx_Bus1Name,	"Bus1Name",			"Resolved Bus1Name",																					"���ĸ������",				MDB_STRING,	"",		},
	{	PSFULTCTransformerEx_Bus2Name,	"Bus2Name",			"Resolved Bus2Name",																					"�յ�ĸ������",				MDB_STRING,	"",		},
};
typedef	struct _PSFULTCTransformer_
{
	char			szPSFName[MDB_CHARLEN];	//	����
	int				nBus1Number;
	int				nBus2Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nSection;
	unsigned char	nStatus;
	unsigned char	nMeterEnd;
	float			fFromRatio;
	float			fToRatio;
	float			fAngle;
	float			fR;
	float			fX;
	float			fG;
	float			fB;
	float			fGF;
	float			fBF;
	float			fGT;
	float			fBT;
	float			fMaxR;
	float			fMinR;
	float			fStep;
	float			fMaxA;
	float			fMinA;
	float			fAStep;
	unsigned char	nCtrlType;
	unsigned char	nCtrlSide;
	unsigned char	nCtrlFlag;
	float			fMaxMW;
	float			fMinMW;
	float			fMaxMVar;
	float			fMinMVar;
	float			fVHiLimit;
	float			fVLoLimit;
	int				nCtrlBus;
	int				nZCorrTable;
	float			fR1;
	float			fR2;
	float			fR3;
	float			fR4;
	float			fR5;
	float			fR6;
	short			nRatingGroup;
	float			fMVA;
	float			fZ1;
	float			fZ2;
	float			fZ3;
	float			fZ4;
	float			fZ5;
	float			fZ6;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szName[MDB_CHARLEN_TINY];
	char			szOwner[MDB_CHARLEN_TINY];
	float			fRZ;
	float			fXZ;
	unsigned char	nWindConnectionCode;
	float			fRGF;
	float			fXGF;
	float			fRGT;
	float			fXGT;
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	unsigned char	nRTStatus;
	unsigned char	bOpened;
}	tagPSFULTCTransformer;

//////////////////////////////////////////////////////////////////////////
//	** IMPEDANCE CORRECTION TABLES **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFImpedanceCorrectionTables_Field_	{
	PSFImpedanceCorrectionTables_TableNumber=0,
	PSFImpedanceCorrectionTables_T1,
	PSFImpedanceCorrectionTables_F1,
	PSFImpedanceCorrectionTables_T2,
	PSFImpedanceCorrectionTables_F2,
	PSFImpedanceCorrectionTables_T3,
	PSFImpedanceCorrectionTables_F3,
	PSFImpedanceCorrectionTables_T4,
	PSFImpedanceCorrectionTables_F4,
	PSFImpedanceCorrectionTables_T5,
	PSFImpedanceCorrectionTables_F5,
	PSFImpedanceCorrectionTables_T6,
	PSFImpedanceCorrectionTables_F6,
	PSFImpedanceCorrectionTables_T7,
	PSFImpedanceCorrectionTables_F7,
	PSFImpedanceCorrectionTables_T8,
	PSFImpedanceCorrectionTables_F8,
	PSFImpedanceCorrectionTables_T9,
	PSFImpedanceCorrectionTables_F9,
	PSFImpedanceCorrectionTables_T10,
	PSFImpedanceCorrectionTables_F10,
	PSFImpedanceCorrectionTables_T11,
	PSFImpedanceCorrectionTables_F11,
};
static	tagPSFModelField	g_PSFImpedanceCorrectionTablesColumn[]=
{
	{	PSFImpedanceCorrectionTables_TableNumber,	"Table#",	"Impedance correction table number.",			"��",			MDB_INT,	"",	},
	{	PSFImpedanceCorrectionTables_T1,			"T1",		"ONR in pu or phase shift angle in degrees.",	"��λ��1",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F1,			"F1",		"Correction factor.",							"У������1",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T2,			"T2",		"ONR in pu or phase shift angle in degrees.",	"��λ��2",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F2,			"F2",		"Correction factor.",							"У������2",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T3,			"T3",		"ONR in pu or phase shift angle in degrees.",	"��λ��3",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F3,			"F3",		"Correction factor.",							"У������3",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T4,			"T4",		"ONR in pu or phase shift angle in degrees.",	"��λ��4",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F4,			"F4",		"Correction factor.",							"У������4",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T5,			"T5",		"ONR in pu or phase shift angle in degrees.",	"��λ��5",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F5,			"F5",		"Correction factor.",							"У������5",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T6,			"T6",		"ONR in pu or phase shift angle in degrees.",	"��λ��6",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F6,			"F6",		"Correction factor.",							"У������6",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T7,			"T7",		"ONR in pu or phase shift angle in degrees.",	"��λ��7",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F7,			"F7",		"Correction factor.",							"У������7",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T8,			"T8",		"ONR in pu or phase shift angle in degrees.",	"��λ��8",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F8,			"F8",		"Correction factor.",							"У������8",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T9,			"T9",		"ONR in pu or phase shift angle in degrees.",	"��λ��9",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F9,			"F9",		"Correction factor.",							"У������9",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T10,			"T10",		"ONR in pu or phase shift angle in degrees.",	"��λ��10",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F10,			"F10",		"Correction factor.",							"У������10",	MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_T11,			"T11",		"ONR in pu or phase shift angle in degrees.",	"��λ��11",		MDB_FLOAT,	"",	},
	{	PSFImpedanceCorrectionTables_F11,			"F11",		"Correction factor.",							"У������11",	MDB_FLOAT,	"",	},
};
typedef	struct _PSFImpedanceCorrectionTables_
{
	int				nTableNumber;
	float			fT1;
	float			fF1;
	float			fT2;
	float			fF2;
	float			fT3;
	float			fF3;
	float			fT4;
	float			fF4;
	float			fT5;
	float			fF5;
	float			fT6;
	float			fF6;
	float			fT7;
	float			fF7;
	float			fT8;
	float			fF8;
	float			fT9;
	float			fF9;
	float			fT10;
	float			fF10;
	float			fT11;
	float			fF11;
}	tagPSFImpedanceCorrectionTables;

//////////////////////////////////////////////////////////////////////////
//	** FIXED SERIES COMPENSATOR DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFFixedSeriesCompensator_Field_	{
	PSFFixedSeriesCompensatorEx_PSFName=0,
	PSFFixedSeriesCompensator_Bus1Number,
	PSFFixedSeriesCompensator_Bus2Number,
	PSFFixedSeriesCompensator_ID,
	PSFFixedSeriesCompensator_Section,
	PSFFixedSeriesCompensator_X,
	PSFFixedSeriesCompensator_Status,
	PSFFixedSeriesCompensator_MeterEnd,
	PSFFixedSeriesCompensator_AMPRating,
	PSFFixedSeriesCompensator_kVRating,
	PSFFixedSeriesCompensator_Z1,
	PSFFixedSeriesCompensator_Z2,
	PSFFixedSeriesCompensator_Z3,
	PSFFixedSeriesCompensator_Z4,
	PSFFixedSeriesCompensator_Z5,
	PSFFixedSeriesCompensator_Z6,
	PSFFixedSeriesCompensator_EquipmentName,
	PSFFixedSeriesCompensator_Owner,
	PSFFixedSeriesCompensatorEx_Bus1Name,
	PSFFixedSeriesCompensatorEx_Bus2Name,
};
static	tagPSFModelField	g_PSFFixedSeriesCompensatorColumn[]=
{
	{	PSFFixedSeriesCompensatorEx_PSFName,	"PSFName",			"Resolved PSFName",												"��װ����",					MDB_STRING,	"",		},
	{	PSFFixedSeriesCompensator_Bus1Number,	"Bus1Number",		"FROM bus number.",												"���ĸ��",					MDB_INT,	"",		},
	{	PSFFixedSeriesCompensator_Bus2Number,	"Bus2Number",		"TO bus number.",												"�յ�ĸ��",					MDB_INT,	"",		},
	{	PSFFixedSeriesCompensator_ID,			"ID",				"Fixed series compensator identifier.",							"�̶�����������ID",			MDB_STRING,	"",		},
	{	PSFFixedSeriesCompensator_Section,		"Section",			"Fixed series compensator section number (default 1).",			"�ֶκ�",					MDB_BIT,	"1",	},
	{	PSFFixedSeriesCompensator_X,			"X",				"Fixed series compensator reactance in pu.",					"�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Status,		"Status",			"Fixed series compensator status.",								"״̬",						MDB_BIT,	"",		},
	{	PSFFixedSeriesCompensator_MeterEnd,		"MeterEnd",			"metered end identifier used for area interchange control.",	"���򽻻����ʿ��ƵĲ�����",	MDB_BIT,	"",		},
	{	PSFFixedSeriesCompensator_AMPRating,	"AMPRating",		"Fixed series compensator current rating in amperes.",			"�����",					MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_kVRating,		"kVRating",			"Fixed series compensator kV rating.",							"���ѹ",					MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Z1,			"Z1",				"zone number.",													"�������1",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Z2,			"Z2",				"zone number.",													"�������2",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Z3,			"Z3",				"zone number.",													"�������3",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Z4,			"Z4",				"zone number.",													"�������4",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Z5,			"Z5",				"zone number.",													"�������5",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_Z6,			"Z6",				"zone number.",													"�������6",				MDB_FLOAT,	"",		},
	{	PSFFixedSeriesCompensator_EquipmentName,"EquipmentName",	"Fixed series compensator equipment name.",						"�豸����",					MDB_STRING,	"",		},
	{	PSFFixedSeriesCompensator_Owner,		"Owner",			"Fixed series compensator owner name.",							"������",					MDB_STRING,	"",		},
	{	PSFFixedSeriesCompensatorEx_Bus1Name,	"Bus1Name",			"Resolved Bus1Name",											"���ĸ������",				MDB_STRING,	"",		},
	{	PSFFixedSeriesCompensatorEx_Bus2Name,	"Bus2Name",			"Resolved Bus2Name",											"�յ�ĸ������",				MDB_STRING,	"",		},
};
typedef	struct _PSFFixedSeriesCompensator_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szPSFName[MDB_CHARLEN];	//	����
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBus1Number;
	int				nBus2Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nSection;
	float			fX;
	unsigned char	nStatus;
	unsigned char	nMeterEnd;
	float			fAMPRating;
	float			fkVRating;
	float			fZ1;
	float			fZ2;
	float			fZ3;
	float			fZ4;
	float			fZ5;
	float			fZ6;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szOwner[MDB_CHARLEN_TINY];

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	unsigned char	nRTStatus;
	unsigned char	bOpened;
}	tagPSFFixedSeriesCompensator;

//////////////////////////////////////////////////////////////////////////
//	** SWITCHABLE SERIES COMPENSATOR DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFSwitchableSeriesCompensator_Field_	{
	PSFSwitchableSeriesCompensatorEx_PSFName=0,
	PSFSwitchableSeriesCompensator_Bus1Number,
	PSFSwitchableSeriesCompensator_Bus2Number,
	PSFSwitchableSeriesCompensator_ID,
	PSFSwitchableSeriesCompensator_Section,
	PSFSwitchableSeriesCompensator_Status,
	PSFSwitchableSeriesCompensator_MeterEnd,
	PSFSwitchableSeriesCompensator_X,
	PSFSwitchableSeriesCompensator_XMax,
	PSFSwitchableSeriesCompensator_XMin,
	PSFSwitchableSeriesCompensator_Steps,
	PSFSwitchableSeriesCompensator_CtrlFlag,
	PSFSwitchableSeriesCompensator_MaxMW,
	PSFSwitchableSeriesCompensator_MinMW,
	PSFSwitchableSeriesCompensator_AMPRating,
	PSFSwitchableSeriesCompensator_kVRating,
	PSFSwitchableSeriesCompensator_Z1,
	PSFSwitchableSeriesCompensator_Z2,
	PSFSwitchableSeriesCompensator_Z3,
	PSFSwitchableSeriesCompensator_Z4,
	PSFSwitchableSeriesCompensator_Z5,
	PSFSwitchableSeriesCompensator_Z6,
	PSFSwitchableSeriesCompensator_EquipmentName,
	PSFSwitchableSeriesCompensator_Owner,
	PSFSwitchableSeriesCompensatorEx_Bus1Name,
	PSFSwitchableSeriesCompensatorEx_Bus2Name,
};
static	tagPSFModelField	g_PSFSwitchableSeriesCompensatorColumn[]=
{
	{	PSFSwitchableSeriesCompensatorEx_PSFName,	"PSFName",			"Resolved PSFName",													"��װ����",					MDB_STRING,	"",		},
	{	PSFSwitchableSeriesCompensator_Bus1Number,	"Bus1Number",		"FROM bus number.",													"���ĸ��",					MDB_INT,	"",		},
	{	PSFSwitchableSeriesCompensator_Bus2Number,	"Bus2Number",		"TO bus number.",													"�յ�ĸ��",					MDB_INT,	"",		},
	{	PSFSwitchableSeriesCompensator_ID,			"ID",				"8-character fixed series compensator identifier.",					"�ɵ�����������ID",			MDB_STRING,	"",		},
	{	PSFSwitchableSeriesCompensator_Section,		"Section",			"Switchable series compensator section number (default 1).",		"�ֶκ�",					MDB_BIT,	"1",	},
	{	PSFSwitchableSeriesCompensator_Status,		"Status",			"Switchable series compensator status.",							"״̬",						MDB_BIT,	"",		},
	{	PSFSwitchableSeriesCompensator_MeterEnd,	"MeterEnd",			"metered end identifier used for area interchange control.",		"���򽻻����ʿ��ƵĲ�����",	MDB_BIT,	"",		},
	{	PSFSwitchableSeriesCompensator_X,			"X",				"Initial compensator reactance in pu on system MVA base.",			"�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_XMax,		"XMax",				"Maximum series compensator reactance in pu on system MVA base.",	"���翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_XMin,		"XMin",				"Minimum series compensator reactance in pu on system MVA base.",	"��С�翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Steps,		"Steps",			"Number of steps between X Min and X Max.",							"�翹ֵ��λ�仯ֵ",			MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_CtrlFlag,	"CtrFlag",			"Control flag",														"���Ʊ�ʶ",					MDB_BIT,	"",		},
	{	PSFSwitchableSeriesCompensator_MaxMW,		"MaxMW",			"Upper limit for active power flow (in MW).",						"�й�����ֵ",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_MinMW,		"MinMW",			"Lower limit for active power flow (in MW).",						"�й�����ֵ",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_AMPRating,	"AMPRating",		"Switchable series compensator current rating in amperes.",			"�����",					MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_kVRating,	"kVRating",			"Switchable series compensator kV rating.",							"���ѹ",					MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Z1,			"Z1",				"zone number.",														"�������1",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Z2,			"Z2",				"zone number.",														"�������2",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Z3,			"Z3",				"zone number.",														"�������3",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Z4,			"Z4",				"zone number.",														"�������4",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Z5,			"Z5",				"zone number.",														"�������5",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_Z6,			"Z6",				"zone number.",														"�������6",				MDB_FLOAT,	"",		},
	{	PSFSwitchableSeriesCompensator_EquipmentName,	"EquipmentName","32-character switchable series compensator equipment name.",		"�豸����",					MDB_STRING,	"",		},
	{	PSFSwitchableSeriesCompensator_Owner,		"Owner",			"16-character switchable series compensator owner name.",			"������",					MDB_STRING,	"",		},
	{	PSFSwitchableSeriesCompensatorEx_Bus1Name,	"Bus1Name",			"Resolved Bus1Name",												"���ĸ������",				MDB_STRING,	"",		},
	{	PSFSwitchableSeriesCompensatorEx_Bus2Name,	"Bus2Name",			"Resolved Bus2Name",												"�յ�ĸ������",				MDB_STRING,	"",		},
};
typedef	struct _PSFSwitchableSeriesCompensator_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szPSFName[MDB_CHARLEN];	//	����
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBus1Number;
	int				nBus2Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nSection;
	unsigned char	nStatus;
	unsigned char	nMeterEnd;
	float			fX;
	float			fXMax;
	float			fXMin;
	float			fSteps;
	unsigned char	nCtrlFlag;
	float			fMaxMW;
	float			fMinMW;
	float			fAMPRating;
	float			fkVRating;
	float			fZ1;
	float			fZ2;
	float			fZ3;
	float			fZ4;
	float			fZ5;
	float			fZ6;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szOwner[MDB_CHARLEN_TINY];

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	char			szRTName[MDB_CHARLEN];
	unsigned char	nRTStatus;
	unsigned char	bOpened;
}	tagPSFSwitchableSeriesCompensator;

//////////////////////////////////////////////////////////////////////////
//	** STATIC TAP CHANGER / PHASE REGULATOR DATA **
//////////////////////////////////////////////////////////////////////////
static	const	char*	g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType[]=
{
	"V",
	"Q",
	"P",
	"PV",
	"PQ",
};
enum	_PSFEnum_StaticTapChangerPhaseRegulator_CtrlType	{
	PSFStaticTapChangerPhaseRegulator_CtrlType_V=0,
	PSFStaticTapChangerPhaseRegulator_CtrlType_Q,
	PSFStaticTapChangerPhaseRegulator_CtrlType_P,
	PSFStaticTapChangerPhaseRegulator_CtrlType_PV,
	PSFStaticTapChangerPhaseRegulator_CtrlType_PQ,
};

enum	_PSFEnum_PSFStaticTapChangerPhaseRegulator_Field_	{
	PSFStaticTapChangerPhaseRegulatorEx_PSFName=0,
	PSFStaticTapChangerPhaseRegulator_Bus1Number,
	PSFStaticTapChangerPhaseRegulator_Bus2Number,
	PSFStaticTapChangerPhaseRegulator_ID,
	PSFStaticTapChangerPhaseRegulator_Section,
	PSFStaticTapChangerPhaseRegulator_Status,
	PSFStaticTapChangerPhaseRegulator_MeterEnd,
	PSFStaticTapChangerPhaseRegulator_R,
	PSFStaticTapChangerPhaseRegulator_X,
	PSFStaticTapChangerPhaseRegulator_G,
	PSFStaticTapChangerPhaseRegulator_B,
	PSFStaticTapChangerPhaseRegulator_GF,
	PSFStaticTapChangerPhaseRegulator_BF,
	PSFStaticTapChangerPhaseRegulator_GT,
	PSFStaticTapChangerPhaseRegulator_BT,
	PSFStaticTapChangerPhaseRegulator_TCRG,
	PSFStaticTapChangerPhaseRegulator_PSRG,
	PSFStaticTapChangerPhaseRegulator_TCpsn,
	PSFStaticTapChangerPhaseRegulator_PSpsn,
	PSFStaticTapChangerPhaseRegulator_TCR,
	PSFStaticTapChangerPhaseRegulator_MaxTCR,
	PSFStaticTapChangerPhaseRegulator_MinTCR,
	PSFStaticTapChangerPhaseRegulator_PSR,
	PSFStaticTapChangerPhaseRegulator_MaxPSR,
	PSFStaticTapChangerPhaseRegulator_MinPSR,
	PSFStaticTapChangerPhaseRegulator_CtrlType,
	PSFStaticTapChangerPhaseRegulator_CtrlSide,
	PSFStaticTapChangerPhaseRegulator_CtrlFlag,
	PSFStaticTapChangerPhaseRegulator_MaxP,
	PSFStaticTapChangerPhaseRegulator_MinP,
	PSFStaticTapChangerPhaseRegulator_MaxQ,
	PSFStaticTapChangerPhaseRegulator_MinQ,
	PSFStaticTapChangerPhaseRegulator_VHiLimit,
	PSFStaticTapChangerPhaseRegulator_VLoLimit,
	PSFStaticTapChangerPhaseRegulator_CtrlBus,
	PSFStaticTapChangerPhaseRegulator_ZCorrTC,
	PSFStaticTapChangerPhaseRegulator_ZCorrPS,
	PSFStaticTapChangerPhaseRegulator_MVA,
	PSFStaticTapChangerPhaseRegulator_R1,
	PSFStaticTapChangerPhaseRegulator_R2,
	PSFStaticTapChangerPhaseRegulator_R3,
	PSFStaticTapChangerPhaseRegulator_R4,
	PSFStaticTapChangerPhaseRegulator_R5,
	PSFStaticTapChangerPhaseRegulator_R6,
	PSFStaticTapChangerPhaseRegulator_RatingGroup,
	PSFStaticTapChangerPhaseRegulator_Z1,
	PSFStaticTapChangerPhaseRegulator_Z2,
	PSFStaticTapChangerPhaseRegulator_Z3,
	PSFStaticTapChangerPhaseRegulator_Z4,
	PSFStaticTapChangerPhaseRegulator_Z5,
	PSFStaticTapChangerPhaseRegulator_Z6,
	PSFStaticTapChangerPhaseRegulator_EquipmentName,
	PSFStaticTapChangerPhaseRegulator_Name,
	PSFStaticTapChangerPhaseRegulator_Owner,
	PSFStaticTapChangerPhaseRegulator_RZ,
	PSFStaticTapChangerPhaseRegulator_XZ,
	PSFStaticTapChangerPhaseRegulator_WindConnectionCode,
	PSFStaticTapChangerPhaseRegulator_RGF,
	PSFStaticTapChangerPhaseRegulator_XGF,
	PSFStaticTapChangerPhaseRegulator_RGT,
	PSFStaticTapChangerPhaseRegulator_XGT,
	PSFStaticTapChangerPhaseRegulatorEx_Bus1Name,
	PSFStaticTapChangerPhaseRegulatorEx_Bus2Name,
};
static	tagPSFModelField	g_PSFStaticTapChangerPhaseRegulatorColumn[]=
{
	{	PSFStaticTapChangerPhaseRegulatorEx_PSFName,	"PSFName",			"Resolved PSFName",																												"��װ����",						MDB_STRING,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Bus1Number,	"Bus1Number",		"FROM bus number.",																												"���ĸ��",						MDB_INT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Bus2Number,	"Bus2Number",		"TO bus number.",																												"�յ�ĸ��",						MDB_INT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_ID,			"ID",				"8-character static tap changer / phase regulator identifier.",																	"��̬�ֽ�ͷ�任��/������ID",	MDB_STRING,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Section,		"Section",			"Static tap changer / phase regulator section number (default 1).",																"�ֶκ�",						MDB_BIT,	"1",		},
	{	PSFStaticTapChangerPhaseRegulator_Status,		"Status",			"Static tap changer / phase regulator status.",																					"״̬",							MDB_BIT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MeterEnd,		"MeterEnd",			"metered end identifier used for area interchange control.",																	"���򽻻����ʿ��ƵĲ�����",		MDB_BIT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R,			"R",				"Series resistance of the static tap changer/phase regulator in pu on system MVA base.",										"�������ֵ",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_X,			"X",				"Series reactance of the static tap changer/phase regulator in pu on system MVA base.",											"�翹����ֵ",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_G,			"G",				"Conductance of the static tap changer / phase regulator charging in pu on system MVA base.",									"�絼����ֵ",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_B,			"B",				"Susceptance of the static tap changer / phase regulator charging in pu on system MVA base.",									"���ɱ���ֵ",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_GF,			"GF",				"Conductance of static tap changer/phase regulator magnetization to be represented at the FROM bus in pu on system MVA base.",	"��㼤�ŵ絼����ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_BF,			"BF",				"Susceptance of static tap changer/phase regulator magnetization to be represented at the FROM bus in pu on system MVA base.",	"��㼤�ŵ��ɱ���ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_GT,			"GT",				"Conductance of static tap changer/phase regulator magnetization to be represented at the TO bus in pu on system MVA base.",	"�յ㼤�ŵ絼����ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_BT,			"BT",				"Susceptance of static tap changer/phase regulator magnetization to be represented at the TO bus in pu on system MVA base.",	"�յ㼤�ŵ��ɱ���ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_TCRG,			"TCRG",				"Tap changer range (factor) in pu.",																							"�ֽ�ͷ����ֵ��Χ",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_PSRG,			"PSRG",				"Phase shifter range (factor) in pu.",																							"����������ֵ��Χ",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_TCpsn,		"TCpsn",			"Tap changer winding position (split) (between 0.0 and 1.0).",																	"�ֽ�ͷ����λ��",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_PSpsn,		"PSpsn",			"Phase Shifter winding position (split) (between 0.0 and 1.0).",																"����������λ��",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_TCR,			"TCR",				"Tap changer ratio in pu.",																										"�ֽ�ͷ��ȱ���ֵ",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MaxTCR,		"MaxTCR",			"Maximum tap changer ratio in pu.",																								"�ֽ�ͷ����ȱ���ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MinTCR,		"MinTCR",			"Minimum tap changer ratio in pu.",																								"�ֽ�ͷ��С��ȱ���ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_PSR,			"PSR",				"Phase shifter ratio in pu.",																									"��������ȱ���ֵ",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MaxPSR,		"MaxPSR",			"Maximum phase shifter ratio in pu.",																							"����������ȱ���ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MinPSR,		"MinPSR",			"Minimum phase shifter ratio in pu.",																							"��������С��ȱ���ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_CtrlType,		"CtrlType",			"2-character text string to indicate control type.",																			"��������",						MDB_BIT,	"V",		},
	{	PSFStaticTapChangerPhaseRegulator_CtrlSide,		"CtrlSide",			"1-character text string to indicate the control side.",																		"���Ʋ�",						MDB_BIT,	"F",		},
	{	PSFStaticTapChangerPhaseRegulator_CtrlFlag,		"CtrlFlag",			"Control flag.",																												"���Ʊ�ʶ",						MDB_BIT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MaxP,			"MaxP",				"Upper limit for active power flow.",																							"�й�����ֵ",					MDB_FLOAT,	"9999",		},
	{	PSFStaticTapChangerPhaseRegulator_MinP,			"MinP",				"Lower limit for active power flow.",																							"�й�����ֵ",					MDB_FLOAT,	"-9999",	},
	{	PSFStaticTapChangerPhaseRegulator_MaxQ,			"MaxQ",				"Upper limit for reactive power flow.",																							"�޹�����ֵ",					MDB_FLOAT,	"9999",		},
	{	PSFStaticTapChangerPhaseRegulator_MinQ,			"MinQ",				"Lower limit for reactive power flow.",																							"�޹�����ֵ",					MDB_FLOAT,	"-9999",	},
	{	PSFStaticTapChangerPhaseRegulator_VHiLimit,		"VHiLimit",			"Upper limit for controlled bus voltage in pu (default 1.5).",																	"����ĸ�ߵ�ѹ��������ֵ",		MDB_FLOAT,	"1.5",		},
	{	PSFStaticTapChangerPhaseRegulator_VLoLimit,		"VLoLimit",			"Lower limit for controlled bus voltage in pu (default 0.5).",																	"����ĸ�ߵ�ѹ��������ֵ",		MDB_FLOAT,	"0.5",		},
	{	PSFStaticTapChangerPhaseRegulator_CtrlBus,		"CtrlBus",			"Controlled bus number.",																										"����ĸ�߱��",					MDB_INT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_ZCorrTC,		"ZCorrTC",			"Number of transformer or phase shifter impedance correction table to be used for the tap changer.",							"�������迹У�������",			MDB_SHORT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_ZCorrPS,		"ZCorrPS",			"Number of transformer or phase shifter impedance correction table to be used for the phase shifter.",							"�������迹У�������",			MDB_SHORT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_MVA,			"MVA",				"Rated MVA of the static tap changer / phase regulator.",																		"�����",						MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R1,			"R1",				"Static tap changer / phase regulator MVA ratings at nominal voltage.",															"�����ȼ�1",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R2,			"R2",				"Static tap changer / phase regulator MVA ratings at nominal voltage.",															"�����ȼ�2",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R3,			"R3",				"Static tap changer / phase regulator MVA ratings at nominal voltage.",															"�����ȼ�3",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R4,			"R4",				"Static tap changer / phase regulator MVA ratings at nominal voltage.",															"�����ȼ�4",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R5,			"R5",				"Static tap changer / phase regulator MVA ratings at nominal voltage.",															"�����ȼ�5",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_R6,			"R6",				"Static tap changer / phase regulator MVA ratings at nominal voltage.",															"�����ȼ�6",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_RatingGroup,	"RatingGroup",		"static tap changer / phase regulator rating group number (default 1).",														"�����ȼ�Ⱥ��",					MDB_SHORT,	"1",		},
	{	PSFStaticTapChangerPhaseRegulator_Z1,			"Z1",				"Zone number.",																													"�������1",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Z2,			"Z2",				"Zone number.",																													"�������2",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Z3,			"Z3",				"Zone number.",																													"�������3",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Z4,			"Z4",				"Zone number.",																													"�������4",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Z5,			"Z5",				"Zone number.",																													"�������5",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Z6,			"Z6",				"Zone number.",																													"�������6",					MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_EquipmentName,	"EquipmentName","32-character static tap changer / phase regulator equipment name.",															"�豸����",						MDB_STRING,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Name,			"Name",				"16-character static tap changer / phase regulator name.",																		"�ֽ�ͷ�任��/����������",		MDB_STRING,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_Owner,		"Owner",			"16-character static tap changer / phase regulator name.",																		"������",						MDB_STRING,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_RZ,			"RZ",				"Zero sequence impedance of the static tap changer / phase regulator in pu on system MVA base.",								"����������ֵ",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_XZ,			"XZ",				"Zero sequence impedance of the static tap changer / phase regulator in pu on system MVA base.",								"����翹����ֵ",				MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_WindConnectionCode,	"Code",		"Static tap changer / phase regulator winding connection code.",																"�����������",					MDB_BIT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_RGF,			"RGF",				"Grounding resistance of the static tap changer / phase regulator at the FROM-bus side in pu on system MVA base.",				"����Եص������ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_XGF,			"XGF",				"Grounding reactance of the static tap changer / phase regulator at the FROM-bus side in pu on system MVA base.",				"����Եص翹����ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_RGT,			"RGT",				"Grounding resistance of the static tap changer / phase regulator at the TO-bus side in pu on system MVA base.",				"�յ��Եص������ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulator_XGT,			"XGT",				"Grounding reactance of the static tap changer / phase regulator at the TO-bus side in pu on system MVA base.",					"�յ��Եص翹����ֵ",			MDB_FLOAT,	"",			},
	{	PSFStaticTapChangerPhaseRegulatorEx_Bus1Name,	"Bus1Name",			"Resolved Bus1Name",																											"���ĸ������",					MDB_STRING,	"",			},
	{	PSFStaticTapChangerPhaseRegulatorEx_Bus2Name,	"Bus2Name",			"Resolved Bus2Name",																											"�յ�ĸ������",					MDB_STRING,	"",			},
};																													
typedef	struct _PSFStaticTapChangerPhaseRegulator_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szPSFName[MDB_CHARLEN];	//	����
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBus1Number;
	int				nBus2Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nSection;
	unsigned char	nStatus;
	unsigned char	nMeterEnd;
	float			fR;
	float			fX;
	float			fG;
	float			fB;
	float			fGF;
	float			fBF;
	float			fGT;
	float			fBT;
	float			fTCRG;
	float			fPSRG;
	float			fTCpsn;
	float			fPSpsn;
	float			fTCR;
	float			fMaxTCR;
	float			fMinTCR;
	float			fPSR;
	float			fMaxPSR;
	float			fMinPSR;
	unsigned char	nCtrlType;
	unsigned char	nCtrlSide;
	unsigned char	nCtrlFlag;
	float			fMaxP;
	float			fMinP;
	float			fMaxQ;
	float			fMinQ;
	float			fVHiLimit;
	float			fVLoLimit;
	int				nCtrlBus;
	short			nZCorrTC;
	short			nZCorrPS;
	float			fMVA;
	float			fR1;
	float			fR2;
	float			fR3;
	float			fR4;
	float			fR5;
	float			fR6;
	short			nRatingGroup;
	float			fZ1;
	float			fZ2;
	float			fZ3;
	float			fZ4;
	float			fZ5;
	float			fZ6;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szName[MDB_CHARLEN_TINY];
	char			szOwner[MDB_CHARLEN_TINY];
	float			fRZ;
	float			fXZ;
	unsigned char	nWindConnectionCode;
	float			fRGF;
	float			fXGF;
	float			fRGT;
	float			fXGT;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	unsigned char	bOpened;
}	tagPSFStaticTapChangerPhaseRegulator;

//////////////////////////////////////////////////////////////////////////
//	** 3-WINDING TRANSFORMER DATA **
//////////////////////////////////////////////////////////////////////////

static	char	g_lpszPSF3WindingTransformer_NonMeteredEnd[]=
{
	'P',
	'S',
	'T',
};
enum	_PSFEnum_3WindingTransformer_NonMeteredEnd{
	PSF3WindingTransformer_NonMeteredEnd_Primary,
	PSF3WindingTransformer_NonMeteredEnd_Secondary,
	PSF3WindingTransformer_NonMeteredEnd_Tertiary,
};
static	char	g_lpszPSF3WindingTransformer_CtrlSide[]=
{
	'T',
	'Z',
};
enum	_PSFEnum_3WindingTransformer_CtrlSide	{
	PSF3WindingTransformer_CtrlSide_T=0,
	PSF3WindingTransformer_CtrlSide_Z,
};
enum	_PSFEnum_PSF3WindingTransformer_Field_	{
	PSF3WindingTransformerEx_PSFName=0,
	PSF3WindingTransformer_Bus1Number,
	PSF3WindingTransformer_Bus2Number,
	PSF3WindingTransformer_Bus3Number,
	PSF3WindingTransformer_ID,
	PSF3WindingTransformer_Status,
	PSF3WindingTransformer_NonMeteredEnd,
	PSF3WindingTransformer_Ratio1,
	PSF3WindingTransformer_Angle1,
	PSF3WindingTransformer_Ratio2,
	PSF3WindingTransformer_Angle2,
	PSF3WindingTransformer_Ratio3,
	PSF3WindingTransformer_Angle3,
	PSF3WindingTransformer_R1,
	PSF3WindingTransformer_X1,
	PSF3WindingTransformer_R2,
	PSF3WindingTransformer_X2,
	PSF3WindingTransformer_R3,
	PSF3WindingTransformer_X3,
	PSF3WindingTransformer_G1,
	PSF3WindingTransformer_B1,
	PSF3WindingTransformer_G2,
	PSF3WindingTransformer_B2,
	PSF3WindingTransformer_G3,
	PSF3WindingTransformer_B3,
	PSF3WindingTransformer_PMaxRA,
	PSF3WindingTransformer_PMinRA,
	PSF3WindingTransformer_PStep,
	PSF3WindingTransformer_PCtrlSide,
	PSF3WindingTransformer_PCtrlFlag,
	PSF3WindingTransformer_PMaxCtrl,
	PSF3WindingTransformer_PMinCtrl,
	PSF3WindingTransformer_PCtrlBus,
	PSF3WindingTransformer_PZCorrTable,
	PSF3WindingTransformer_SMaxRA,
	PSF3WindingTransformer_SMinRA,
	PSF3WindingTransformer_SStep,
	PSF3WindingTransformer_SCtrlSide,
	PSF3WindingTransformer_SCtrlFlag,
	PSF3WindingTransformer_SMaxCtrl,
	PSF3WindingTransformer_SMinCtrl,
	PSF3WindingTransformer_SCtrlBus,
	PSF3WindingTransformer_SZCorrTable,
	PSF3WindingTransformer_TMaxRA,
	PSF3WindingTransformer_TMinRA,
	PSF3WindingTransformer_TStep,
	PSF3WindingTransformer_TCtrlSide,
	PSF3WindingTransformer_TCtrlFlag,
	PSF3WindingTransformer_TMaxCtrl,
	PSF3WindingTransformer_TMinCtrl,
	PSF3WindingTransformer_TCtrlBus,
	PSF3WindingTransformer_TZCorrTable,
	PSF3WindingTransformer_PR1,
	PSF3WindingTransformer_PR2,
	PSF3WindingTransformer_PR3,
	PSF3WindingTransformer_PR4,
	PSF3WindingTransformer_PR5,
	PSF3WindingTransformer_PR6,
	PSF3WindingTransformer_RatingGroup,
	PSF3WindingTransformer_MVA,
	PSF3WindingTransformer_SR1,
	PSF3WindingTransformer_SR2,
	PSF3WindingTransformer_SR3,
	PSF3WindingTransformer_SR4,
	PSF3WindingTransformer_SR5,
	PSF3WindingTransformer_SR6,
	PSF3WindingTransformer_TR1,
	PSF3WindingTransformer_TR2,
	PSF3WindingTransformer_TR3,
	PSF3WindingTransformer_TR4,
	PSF3WindingTransformer_TR5,
	PSF3WindingTransformer_TR6,
	PSF3WindingTransformer_EquipmentName,
	PSF3WindingTransformer_Name,
	PSF3WindingTransformer_Owner,
	PSF3WindingTransformer_PR0,
	PSF3WindingTransformer_PX0,
	PSF3WindingTransformer_SR0,
	PSF3WindingTransformer_SX0,
	PSF3WindingTransformer_TR0,
	PSF3WindingTransformer_TX0,
	PSF3WindingTransformer_GroundingCode,
	PSF3WindingTransformer_PGR,
	PSF3WindingTransformer_PGX,
	PSF3WindingTransformer_SGR,
	PSF3WindingTransformer_SGX,
	PSF3WindingTransformer_TGR,
	PSF3WindingTransformer_TGX,
	PSF3WindingTransformerEx_Bus1Name,
	PSF3WindingTransformerEx_Bus2Name,
	PSF3WindingTransformerEx_Bus3Name,
};
static	tagPSFModelField	g_PSF3WindingTransformerColumn[]=
{
	{	PSF3WindingTransformerEx_PSFName,		"PSFName",			"Resolved PSFName",																	"��װ����",						MDB_STRING,	"",		},
	{	PSF3WindingTransformer_Bus1Number,		"Bus1Number",		"Primary bus number.",																"һ�β�ĸ��",					MDB_INT,	"",		},
	{	PSF3WindingTransformer_Bus2Number,		"Bus2Number",		"Secondary bus number.",															"���β�ĸ��",					MDB_INT,	"",		},
	{	PSF3WindingTransformer_Bus3Number,		"Bus3Number",		"Tertiary bus number.",																"���β�ĸ��",					MDB_INT,	"",		},
	{	PSF3WindingTransformer_ID,				"ID",				"16-character three winding transformer identifier.",								"�������ѹ��ID",				MDB_STRING,	"",		},
	{	PSF3WindingTransformer_Status,			"Status",			"Three winding transformer status.",												"״̬",							MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_NonMeteredEnd,	"NonMeterEnd",		"metered end identifier used for area interchange control.",						"���򽻻����ʿ��ƵĲ�����",		MDB_FLOAT,	"P",	},
	{	PSF3WindingTransformer_Ratio1,			"Ratio1",			"Turns ratio in pu for the primary winding.",										"һ�β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_Angle1,			"Angle1",			"Phase shift angle in degrees for the primary winding.",							"һ�β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_Ratio2,			"Ratio2",			"Turns ratio in pu for the secondary winding.",										"���β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_Angle2,			"Angle2",			"Phase shift angle in degrees for the secondary winding.",							"���β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_Ratio3,			"Ratio3",			"Turns ratio in pu for the tertiary winding.",										"���β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_Angle3,			"Angle3",			"Phase shift angle in degrees for the tertiary winding.",							"���β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_R1,				"R1",				"Series resistance of the primary winding in pu on system MVA base.",				"һ�β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_X1,				"X1",				"Series reactance of the primary winding in pu on system MVA base.",				"һ�β�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_R2,				"R2",				"Series resistance of the secondary winding in pu on system MVA base.",				"���β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_X2,				"X2",				"Series reactance of the secondary winding in pu on system MVA base.",				"���β�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_R3,				"R3",				"Series resistance of the tertiary winding in pu on system MVA base.",				"���β�������ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_X3,				"X3",				"Series reactance of the tertiary winding in pu on system MVA base.",				"���β�翹����ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_G1,				"G1",				"Conductance of magnetization for the primary winding in pu on system MVA base.",	"һ�β�絼����ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_B1,				"B1",				"Susceptance of magnetization for the primary winding in pu on system MVA base.",	"һ�β���ɱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_G2,				"G2",				"Conductance of magnetization for the secondary winding in pu on system MVA base.",	"���β�絼����ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_B2,				"B2",				"Susceptance of magnetization for the secondary winding in pu on system MVA base.",	"���β���ɱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_G3,				"G3",				"Conductance of magnetization for the tertiary winding in pu on system MVA base.",	"���β�絼����ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_B3,				"B3",				"Susceptance of magnetization for the tertiary winding in pu on system MVA base.",	"���β���ɱ���ֵ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PMaxRA,			"PMaxRA",			"Upper limit for turns ratio (pu) or phase shift angle (degrees).",					"һ�β��Ȼ���λ������ֵ",		MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PMinRA,			"PMinRA",			"Lower limit for turns ratio (pu) or phase shift angle (degrees).",					"һ�β��Ȼ���λ������ֵ",		MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PStep,			"PStep",			"Turns ratio step size in pu.",														"һ�β��ȵ�λ����ֵ�仯ֵ",	MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PCtrlSide,		"PCtrlSide",		"1-character text string to indicate the location of the controlled bus.",			"һ�β���Ʋ�",					MDB_FLOAT,	"T",	},
	{	PSF3WindingTransformer_PCtrlFlag,		"PCtrlFlag",		"Control flag.",																	"һ�β���Ʊ�ʶ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PMaxCtrl,		"PMaxCtrl",			"Upper limit for controlled variable in appropriate unit.",							"���β���Ʊ�������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PMinCtrl,		"PMinCtrl",			"Lower limit for controlled variable in appropriate unit.",							"���β���Ʊ�������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PCtrlBus,		"PCtrlBus",			"Controlled bus number.",															"���β౻��ĸ�߱��",			MDB_INT,	"",		},
	{	PSF3WindingTransformer_PZCorrTable,		"PZCorrTable",		"Number of transformer impedance correction table",									"���β��迹У�������",			MDB_INT,	"",		},
	{	PSF3WindingTransformer_SMaxRA,			"SMaxRA",			"Upper limit for turns ratio (pu) or phase shift angle (degrees).",					"���β��Ȼ���λ������ֵ",		MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SMinRA,			"SMinRA",			"Lower limit for turns ratio (pu) or phase shift angle (degrees).",					"���β��Ȼ���λ������ֵ",		MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SStep,			"SStep",			"Turns ratio step size in pu.",														"���β��ȵ�λ����ֵ�仯ֵ",	MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SCtrlSide,		"SCtrlSide",		"1-character text string to indicate the location of the controlled bus.",			"���β���Ʋ�",					MDB_FLOAT,	"T",	},
	{	PSF3WindingTransformer_SCtrlFlag,		"SCtrlFlag",		"Control flag.",																	"���β���Ʊ�ʶ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SMaxCtrl,		"SMaxCtrl",			"Upper limit for controlled variable in appropriate unit.",							"���β���Ʊ�������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SMinCtrl,		"SMinCtrl",			"Lower limit for controlled variable in appropriate unit.",							"���β���Ʊ�������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SCtrlBus,		"SCtrlBus",			"Controlled bus number.",															"���β౻��ĸ�߱��",			MDB_INT,	"",		},
	{	PSF3WindingTransformer_SZCorrTable,		"SZCorrTable",		"Number of transformer impedance correction table",									"���β��迹У�������",			MDB_INT,	"",		},
	{	PSF3WindingTransformer_TMaxRA,			"TMaxRA",			"Upper limit for turns ratio (pu) or phase shift angle (degrees).",					"���β��Ȼ���λ������ֵ",		MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TMinRA,			"TMinRA",			"Lower limit for turns ratio (pu) or phase shift angle (degrees).",					"���β��Ȼ���λ������ֵ",		MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TStep,			"TStep",			"Turns ratio step size in pu.",														"���β��ȵ�λ����ֵ�仯ֵ",	MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TCtrlSide,		"TCtrlSide",		"1-character text string to indicate the location of the controlled bus.",			"���β���Ʋ�",					MDB_FLOAT,	"T",	},
	{	PSF3WindingTransformer_TCtrlFlag,		"TCtrlFlag",		"Control flag.",																	"���β���Ʊ�ʶ",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TMaxCtrl,		"TMaxCtrl",			"Upper limit for controlled variable in appropriate unit.",							"���β���Ʊ�������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TMinCtrl,		"TMinCtrl",			"Lower limit for controlled variable in appropriate unit.",							"���β���Ʊ�������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TCtrlBus,		"TCtrlBus",			"Controlled bus number.",															"���β౻��ĸ�߱��",			MDB_INT,	"",		},
	{	PSF3WindingTransformer_TZCorrTable,		"TZCorrTable",		"Number of transformer impedance correction table",									"���β��迹У�������",			MDB_INT,	"",		},
	{	PSF3WindingTransformer_PR1,				"PR1",				"MVA ratings for the primary winding.",												"һ�β������ȼ�1",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PR2,				"PR2",				"MVA ratings for the primary winding.",												"һ�β������ȼ�2",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PR3,				"PR3",				"MVA ratings for the primary winding.",												"һ�β������ȼ�3",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PR4,				"PR4",				"MVA ratings for the primary winding.",												"һ�β������ȼ�4",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PR5,				"PR5",				"MVA ratings for the primary winding.",												"һ�β������ȼ�5",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PR6,				"PR6",				"MVA ratings for the primary winding.",												"һ�β������ȼ�6",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_RatingGroup,		"RatingGroup",		"Transformer rating group (default 1).",											"�����ȼ�Ⱥ��",					MDB_SHORT,	"1",	},
	{	PSF3WindingTransformer_MVA,				"MVA",				"Transformer rated MVA.",															"�����",						MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR1,				"SR1",				"MVA ratings for the secondary winding.",											"���β������ȼ�1",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR2,				"SR2",				"MVA ratings for the secondary winding.",											"���β������ȼ�2",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR3,				"SR3",				"MVA ratings for the secondary winding.",											"���β������ȼ�3",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR4,				"SR4",				"MVA ratings for the secondary winding.",											"���β������ȼ�4",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR5,				"SR5",				"MVA ratings for the secondary winding.",											"���β������ȼ�5",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR6,				"SR6",				"MVA ratings for the secondary winding.",											"���β������ȼ�6",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR1,				"TR1",				"MVA ratings for the tertiary winding.",											"���β������ȼ�1",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR2,				"TR2",				"MVA ratings for the tertiary winding.",											"���β������ȼ�2",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR3,				"TR3",				"MVA ratings for the tertiary winding.",											"���β������ȼ�3",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR4,				"TR4",				"MVA ratings for the tertiary winding.",											"���β������ȼ�4",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR5,				"TR5",				"MVA ratings for the tertiary winding.",											"���β������ȼ�5",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR6,				"TR6",				"MVA ratings for the tertiary winding.",											"���β������ȼ�6",				MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_EquipmentName,	"EquipmentName",	"32-character three winding transformer equipment name.",							"�豸����",						MDB_STRING,	"",		},
	{	PSF3WindingTransformer_Name,			"Name",				"16-character three winding transformer name.",										"�������ѹ������",				MDB_STRING,	"",		},
	{	PSF3WindingTransformer_Owner,			"Owner",			"16-character three winding transformer owner name.",								"������",						MDB_STRING,	"",		},
	{	PSF3WindingTransformer_PR0,				"PR0",				"Zero sequence impedance of the primary winding in pu on system MVA base.",			"һ�β�����������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PX0,				"PX0",				"Zero sequence impedance of the primary winding in pu on system MVA base.",			"һ�β�����翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SR0,				"SR0",				"Zero sequence impedance of the secondary winding in pu on system MVA base.",		"���β�����������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SX0,				"SX0",				"Zero sequence impedance of the secondary winding in pu on system MVA base.",		"���β�����翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TR0,				"TR0",				"Zero sequence impedance of the tertiary winding in pu on system MVA base.",		"���β�����������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TX0,				"TX0",				"Zero sequence impedance of the tertiary winding in pu on system MVA base.",		"���β�����翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_GroundingCode,	"Code",				"Three winding transformer grounding code.",										"�������ѹ���������",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PGR,				"PGR",				"Grounding resistance of the primary winding in pu on system MVA base.",			"һ�β�Եص������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_PGX,				"PGX",				"Grounding reactance of the primary winding in pu on system MVA base.",				"һ�β�Եص翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SGR,				"SGR",				"Grounding resistance of the secondary winding in pu on system MVA base.",			"���β�Եص������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_SGX,				"SGX",				"Grounding reactance of the secondary winding in pu on system MVA base.",			"���β�Եص翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TGR,				"TGR",				"Grounding resistance of the tertiary winding in pu on system MVA base.",			"���β�Եص������ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformer_TGX,				"TGX",				"Grounding reactance of the tertiary winding in pu on system MVA base.",			"���β�Եص翹����ֵ",			MDB_FLOAT,	"",		},
	{	PSF3WindingTransformerEx_Bus1Name,		"Bus1Name",			"Resolved Bus1Name",																"һ�β�ĸ������",				MDB_STRING,	"",		},
	{	PSF3WindingTransformerEx_Bus2Name,		"Bus2Name",			"Resolved Bus2Name",																"���β�ĸ������",				MDB_STRING,	"",		},
	{	PSF3WindingTransformerEx_Bus3Name,		"Bus3Name",			"Resolved Bus3Name",																"���β�ĸ������",				MDB_STRING,	"",		},
};
typedef	struct _PSF3WindingTransformer_
{
	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szPSFName[3*MDB_CHARLEN_TINY];	//	����
	//////////////////////////////////////////////////////////////////////////
	//	��������
	int				nBus1Number;
	int				nBus2Number;
	int				nBus3Number;
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nStatus;
	unsigned char	nNonMeteredEnd;
	float			fRatio1;
	float			fAngle1;
	float			fRatio2;
	float			fAngle2;
	float			fRatio3;
	float			fAngle3;
	float			fR1;
	float			fX1;
	float			fR2;
	float			fX2;
	float			fR3;
	float			fX3;
	float			fG1;
	float			fB1;
	float			fG2;
	float			fB2;
	float			fG3;
	float			fB3;
	float			fPMaxRA;
	float			fPMinRA;
	float			fPStep;
	unsigned char	nPCtrlSide;
	unsigned char	nPCtrlFlag;
	float			fPMaxCtrl;
	float			fPMinCtrl;
	int				nPCtrlBus;
	int				nPZCorrTable;
	float			fSMaxRA;
	float			fSMinRA;
	float			fSStep;
	unsigned char	nSCtrlSide;
	unsigned char	nSCtrlFlag;
	float			fSMaxCtrl;
	float			fSMinCtrl;
	int				nSCtrlBus;
	int				nSZCorrTable;
	float			fTMaxRA;
	float			fTMinRA;
	float			fTStep;
	unsigned char	nTCtrlSide;
	unsigned char	nTCtrlFlag;
	float			fTMaxCtrl;
	float			fTMinCtrl;
	int				nTCtrlBus;
	int				nTZCorrTable;
	float			fPR1;
	float			fPR2;
	float			fPR3;
	float			fPR4;
	float			fPR5;
	float			fPR6;
	short			nRatingGroup;
	float			fMVA;
	float			fSR1;
	float			fSR2;
	float			fSR3;
	float			fSR4;
	float			fSR5;
	float			fSR6;
	float			fTR1;
	float			fTR2;
	float			fTR3;
	float			fTR4;
	float			fTR5;
	float			fTR6;
	char			szEquipmentName[MDB_CHARLEN_SHORT];
	char			szName[MDB_CHARLEN_TINY];
	char			szOwner[MDB_CHARLEN_TINY];
	float			fPR0;
	float			fPX0;
	float			fSR0;
	float			fSX0;
	float			fTR0;
	float			fTX0;
	unsigned char	nGroundingCode;
	float			fPGR;
	float			fPGX;
	float			fSGR;
	float			fSGX;
	float			fTGR;
	float			fTGX;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szBus1Name[MDB_CHARLEN_TINY+1];
	char			szBus2Name[MDB_CHARLEN_TINY+1];
	char			szBus3Name[MDB_CHARLEN_TINY+1];
	int				nBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nBus3Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	unsigned char	bOpened;
}	tagPSF3WindingTransformer;

//////////////////////////////////////////////////////////////////////////
//	** AREA INTERCHANGE DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFAreaInterchange_Field_	{
	PSFAreaInterchange_Number=0,
	PSFAreaInterchange_Name,
	PSFAreaInterchange_DesiredFlow,
	PSFAreaInterchange_Tolerance,
	PSFAreaInterchange_SlackBus,
	PSFAreaInterchange_Description,
	PSFAreaInterchange_Mode,
	PSFAreaInterchange_Flag,
};
static	tagPSFModelField	g_PSFAreaInterchangeColumn[]=
{
	{	PSFAreaInterchange_Number,		"Number",		"Area number.",																		"������",				MDB_INT,	"",		},
	{	PSFAreaInterchange_Name,		"Name",			"Area name (16 characters).",														"��������",				MDB_STRING,	"",		},
	{	PSFAreaInterchange_DesiredFlow,	"DesiredFlow",	"Desired total active power export from the area in MW.",							"����������й�",		MDB_FLOAT,	"",		},
	{	PSFAreaInterchange_Tolerance,	"Tolerance",	"Active power interchange tolerance for powerflow solution in MW (default 10.0).",	"�����й�����",			MDB_FLOAT,	"10.0",	},
	{	PSFAreaInterchange_SlackBus,	"SlackBus",		"Number of the area slack bus for area interchange control.",						"ƽ���ĸ�߱��",		MDB_INT,	"",		},
	{	PSFAreaInterchange_Description,	"Description",	"60 character text description of area interchange.",								"����",					MDB_STRING,	"",		},
	{	PSFAreaInterchange_Mode,		"Mode",			"Mode of the area interchange control.",											"�����ʽ�������ģʽ",	MDB_BIT,	"",		},
	{	PSFAreaInterchange_Flag,		"Flag",			"A dummy flag for future use (enter 0).",											"α��ʶ",				MDB_INT,	"0",	},
};
typedef	struct _PSFAreaInterchange_
{
	int				nNumber;
	char			szName[MDB_CHARLEN_TINY];
	float			fDesiredFlow;
	float			fTolerance;
	int				nSlackBus;
	char			szDescription[3*MDB_CHARLEN_TINY];
	unsigned char	nMode;
	int				nFlag;
}	tagPSFAreaInterchange;

//////////////////////////////////////////////////////////////////////////
//	** INTERFACE DATA **
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
//	** MULTI TERMINAL DC DATA **
//////////////////////////////////////////////////////////////////////////

static	const char	g_lpszPSFMultiTerminalDC_Type[]=
{
	'R',
	'I',
};

static	const char	g_lpszPSFMultiTerminalDC_Change[]=
{
	' ',
	'D',
	'M',
};

static	const char	g_lpszPSFMultiTerminalDC_Mend[]=
{
	'F',
	'T',
};

static	const char*	g_lpszPSFMultiTerminalDC_Status[]=
{
	"CLOSED",
	"OPEN",
};

enum	_PSFEnum_PSFLineCommutatedConverters_Field_	{
	PSFLineCommutatedConverters_DCBus1=0,
	PSFLineCommutatedConverters_DCBus2,
	PSFLineCommutatedConverters_ACBus,
	PSFLineCommutatedConverters_ID,
	PSFLineCommutatedConverters_Change,
	PSFLineCommutatedConverters_Grp,
	PSFLineCommutatedConverters_Zone,
	PSFLineCommutatedConverters_Bridge,
	PSFLineCommutatedConverters_Xc,
	PSFLineCommutatedConverters_VR,
	PSFLineCommutatedConverters_Tstep,
	PSFLineCommutatedConverters_Tmin,
	PSFLineCommutatedConverters_Tmax,
	PSFLineCommutatedConverters_Amin,
	PSFLineCommutatedConverters_Amax,
	PSFLineCommutatedConverters_Gmin,
	PSFLineCommutatedConverters_Imax,
	PSFLineCommutatedConverters_CtrlMode,
	PSFLineCommutatedConverters_SP1,
	PSFLineCommutatedConverters_SP2,
	PSFLineCommutatedConverters_Type,
	PSFLineCommutatedConverters_MVA,
	PSFLineCommutatedConverters_Pmin,
	PSFLineCommutatedConverters_Pmax,
	PSFLineCommutatedConverters_Qmin,
	PSFLineCommutatedConverters_Qmax,
	PSFLineCommutatedConverters_BiasR,
	PSFLineCommutatedConverters_kV,
	PSFLineCommutatedConvertersEx_ACBusName,	
};
//Code, Change, DCBus1, DCBus2, ACBus, ID, Grp, Zone, B#, Xc, VR, Tstep, Tmin, Tmax, Amin, Amax, Gmin, Imax
//Code, Change, DCBus1, DCBus2, ACBus, ID, Ctrl Mode, SP1, SP2, Type, MVA, Pmin, Pmax, Qmin, Qmax, BiasR, kV
static	tagPSFModelField	g_PSFLineCommutatedConvertersColumn[]=
{
	{	PSFLineCommutatedConverters_DCBus1,			"DCBus1",		"Name of the first DC terminal.",																				"ֱ���˵�1",			MDB_STRING,	"",		},
	{	PSFLineCommutatedConverters_DCBus2,			"DCBus2",		"Name of the second DC terminal.",																				"ֱ���˵�2",			MDB_STRING,	"",		},
	{	PSFLineCommutatedConverters_ACBus,			"ACBus",		"AC bus number.",																								"����ĸ�ߺ�",			MDB_INT,	"",		},
	{	PSFLineCommutatedConverters_ID,				"ID",			"Converter ID.",																								"ID",					MDB_STRING,	"",		},
	{	PSFLineCommutatedConverters_Change,			"Change",		"change code.",																									"�޸���",				MDB_BIT,	"0",	},
	{	PSFLineCommutatedConverters_Grp,			"Grp",			"group identifier which is used for solution reporting purposes.",												"������",				MDB_STRING,	"",		},
	{	PSFLineCommutatedConverters_Zone,			"Zone",			"Converter zone number.",																						"������",				MDB_SHORT,	"",		},
	{	PSFLineCommutatedConverters_Bridge,			"B#",			"Number of series bridges.",																					"����",					MDB_SHORT,	"",		},
	{	PSFLineCommutatedConverters_Xc,				"Xc",			"Commutating reactance.",																						"ƽ���翹",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_VR,				"VR",			"Nominal ratio of the secondary voltage (DC side) of converter transformer to the primary voltage (AC side).",	"ֱ�������",			MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Tstep,			"Tstep",		"Tap step in percent.",																							"��ͷ����",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Tmin,			"Tmin",			"Minimum tap setting in pu.",																					"��С��ͷ",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Tmax,			"Tmax",			"Maximum tap setting in pu.",																					"����ͷ",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Amin,			"Amin",			"Minimum alpha in degrees.",																					"��С������",			MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Amax,			"Amax",			"Maximum alpha in degrees.",																					"��󴥷���",			MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Gmin,			"Gmin",			"Minimum gamma in degrees.",																					"��С�ضϽ�",			MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Imax,			"Imax",			"Maximum DC current in amps.",																					"������",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_CtrlMode,		"CtrlMode",		"Control Mode.",																								"����ģʽ",				MDB_STRING,	"",		},
	{	PSFLineCommutatedConverters_SP1,			"SP1",			"Converter set-point 1.",																						"����ֵ1",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_SP2,			"SP2",			"Converter set-point 2.",																						"����ֵ2",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Type,			"Type",			"identify the converter as a rectifier or an inverter.",														"����������",		MDB_BIT,	"",		},
	{	PSFLineCommutatedConverters_MVA,			"MVA",			"Transformer MVA rating.",																						"��ѹ������",			MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Pmin,			"Pmin",			"Minimum active power in MW.",																					"��С�й�",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Pmax,			"Pmax",			"Maximum active power in MW.",																					"����й�",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Qmin,			"Qmin",			"Minimum reactive power in MVAR.",																				"��С�޹�",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_Qmax,			"Qmax",			"Maximum reactive power in MVAR.",																				"����޹�",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_BiasR,			"BiasR",		"Voltage compounding resistance in Ohms.",																		"�ŵ���",				MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConverters_kV,				"kV",			"Base voltage of transformer primary side in kV.",																"��ѹ����׼��ѹ",		MDB_FLOAT,	"",		},
	{	PSFLineCommutatedConvertersEx_ACBusName,	"ACBusName",	"Resolved ACBusName",																							"����ĸ������",			MDB_STRING,	"",		},
};
typedef	struct _PSFLineCommutatedConverters_
{
	char			szDCBus1[MDB_CHARLEN_TINY/2+1];
	char			szDCBus2[MDB_CHARLEN_TINY/2+1];
	int				nACBus;
	short			nID;
	unsigned char	nChange;

	char			szGrp[MDB_CHARLEN_TINY/4];
	short			nZone;
	short			nBridge;
	float			fXc;
	float			fVR;
	float			fTstep;
	float			fTmin;
	float			fTmax;
	float			fAmin;
	float			fAmax;
	float			fGmin;
	float			fImax;

	char			szCtrlMode[MDB_CHARLEN_TINY/2];
	float			fSP1;
	float			fSP2;
	unsigned char	nType;
	float			fMVA;
	float			fPmin;
	float			fPmax;
	float			fQmin;
	float			fQmax;
	float			fBiasR;
	float			fkV;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szACBusName[MDB_CHARLEN_TINY+1];
	int				nACBusIndex;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
}	tagPSFLineCommutatedConverters;

enum	_PSFEnum_PSFDCLines_Field_	{
	PSFDCLines_DCBus1=0,
	PSFDCLines_DCBus2,
	PSFDCLines_ID,
	PSFDCLines_Change,
	PSFDCLines_Grp,
	PSFDCLines_Zone,
	PSFDCLines_Owner,
	PSFDCLines_Rdc,
	PSFDCLines_Ldc,
	PSFDCLines_Cdca,
	PSFDCLines_Cdcb,
	PSFDCLines_Imax,
	PSFDCLines_Mend,
};
//Code, Change, DCBus1, DCBus2, ID, Grp, Zone, Owner, Rdc, Ldc, Cdca, Cdcb, Imax, Mend
static	tagPSFModelField	g_PSFDCLinesColumn[]=
{
	{	PSFDCLines_DCBus1,	"DCBus1",	"Name of the first DC terminal.",									"ֱ���˵�1",			MDB_STRING,	"",		},
	{	PSFDCLines_DCBus2,	"DCBus2",	"Name of the second DC terminal.",									"ֱ���˵�2",			MDB_STRING,	"",		},
	{	PSFDCLines_ID,		"ID",		"Converter ID.",													"ID",					MDB_STRING,	"",		},
	{	PSFDCLines_Change,	"Change",	"change code.",														"�޸���",				MDB_BIT,	"0",	},
	{	PSFDCLines_Grp,		"Grp",		"group identifier which is used for solution reporting purposes.",	"������",				MDB_STRING,	"",		},
	{	PSFDCLines_Zone,	"Zone",		"Converter zone number.",											"������",				MDB_SHORT,	"",		},
	{	PSFDCLines_Owner,	"Owner",	"converter owner code.",											"������",				MDB_STRING,	"",		},
	{	PSFDCLines_Rdc,		"Rdc",		"Line resistance in Ohms.",											"����(ŷķ)",			MDB_FLOAT,	"",		},
	{	PSFDCLines_Ldc,		"Ldc",		"Line inductance in mH.",											"���(����)",			MDB_FLOAT,	"",		},
	{	PSFDCLines_Cdca,	"Cdca",		"Capacitance at DCBus1.",											"1ĸ����(E-6����)",		MDB_FLOAT,	"",		},
	{	PSFDCLines_Cdcb,	"Cdcb",		"Capacitance at DCBus2.",											"2ĸ����(E-6����)",		MDB_FLOAT,	"",		},
	{	PSFDCLines_Imax,	"Imax",		"Maximum current.",													"������",				MDB_FLOAT,	"",		},
	{	PSFDCLines_Mend,	"Mend",		"metered end identifier.",											"�����",				MDB_BIT,	"",		},
};
typedef	struct _PSFDCLines_
{
	char			szDCBus1[MDB_CHARLEN_TINY/2+1];
	char			szDCBus2[MDB_CHARLEN_TINY/2+1];
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nChange;

	char			szGrp[MDB_CHARLEN_TINY/4];
	short			nZone;
	char			szOwner[MDB_CHARLEN_TINY/4];
	float			fRdc;
	float			fLdc;
	float			fCdca;
	float			fCdcb;
	float			fImax;
	unsigned char	nMend;
}	tagPSFDCLines;

enum	_PSFEnum_PSFDCBreakers_Field_	{
	PSFDCBreakers_DCBus1=0,
	PSFDCBreakers_DCBus2,
	PSFDCBreakers_ID,
	PSFDCBreakers_Change,
	PSFDCBreakers_Grp,
	PSFDCBreakers_Zone,
	PSFDCBreakers_Owner,
	PSFDCBreakers_Status,
};
//Code, Change, DCBus1, DCBus2, ID, Grp, Zone, Owner, Status
static	tagPSFModelField	g_PSFDCBreakersColumn[]=
{
	{	PSFDCBreakers_DCBus1,	"DCBus1",	"Name of the first DC terminal.",									"ֱ���˵�1",	MDB_STRING,	"",		},
	{	PSFDCBreakers_DCBus2,	"DCBus2",	"Name of the second DC terminal.",									"ֱ���˵�2",	MDB_STRING,	"",		},
	{	PSFDCBreakers_ID,		"ID",		"Converter ID.",													"ID",			MDB_STRING,	"",		},
	{	PSFDCBreakers_Change,	"Change",	"change code.",														"�޸���",		MDB_BIT,	"0",	},
	{	PSFDCBreakers_Grp,		"Grp",		"group identifier which is used for solution reporting purposes.",	"������",		MDB_STRING,	"",		},
	{	PSFDCBreakers_Zone,		"Zone",		"Converter zone number.",											"������",		MDB_SHORT,	"",		},
	{	PSFDCBreakers_Owner,	"Owner",	"converter owner code.",											"������",		MDB_STRING,	"",		},
	{	PSFDCBreakers_Status,	"Status",	"Status.",															"״̬",			MDB_BIT,	"",		},
};
typedef	struct _PSFDCBreakers_
{
	char			szDCBus1[MDB_CHARLEN_TINY/2+1];
	char			szDCBus2[MDB_CHARLEN_TINY/2+1];
	char			szID[MDB_CHARLEN_TINY/2];
	unsigned char	nChange;

	char			szGrp[MDB_CHARLEN_TINY/4];
	short			nZone;
	char			szOwner[MDB_CHARLEN_TINY/4];
	unsigned char	nStatus;
}	tagPSFDCBreakers;

enum	_PSFEnum_PSFDCBuses_Field_	{
	PSFDCBuses_DCBus=0,
	PSFDCBuses_Change,
	PSFDCBuses_Area,
	PSFDCBuses_Zone,
};
//Code, Change, DCBus, Area, Zone
static	tagPSFModelField	g_PSFDCBusesColumn[]=
{
	{	PSFDCBuses_DCBus,	"DCBus",	"Name of the DC bus.",			"ֱ��ĸ����",	MDB_STRING,	"",		},
	{	PSFDCBuses_Change,	"Change",	"change code.",					"�޸���",		MDB_BIT,	"0",	},
	{	PSFDCBuses_Area,	"Area",		"Area number of the bus.",		"�����",		MDB_SHORT,	"",		},
	{	PSFDCBuses_Zone,	"Zone",		"Zone number of the bus.",		"������",		MDB_SHORT,	"",		},
};
typedef	struct _PSFDCBuses_
{
	char			szDCBus[MDB_CHARLEN_TINY/2+1];
	unsigned char	nChange;
	short			nArea;
	short			nZone;
	char			szSubstation[MDB_CHARLEN];
}	tagPSFDCBuses;

enum	_PSFEnum_PSFVoltageSourcedConverter_Field_	{
	PSFVoltageSourcedConverter_DCBus1=0,
	PSFVoltageSourcedConverter_DCBus2,
	PSFVoltageSourcedConverter_ACBus1,
	PSFVoltageSourcedConverter_ID,
	PSFVoltageSourcedConverter_DCBus3,
	PSFVoltageSourcedConverter_DCBus4,
	PSFVoltageSourcedConverter_ACBus2,
	PSFVoltageSourcedConverter_ID2,
	PSFVoltageSourcedConverter_Change,
	PSFVoltageSourcedConverter_Grp,
	PSFVoltageSourcedConverter_Zone,
	PSFVoltageSourcedConverter_Bridge,
	PSFVoltageSourcedConverter_Xt,
	PSFVoltageSourcedConverter_VR,
	PSFVoltageSourcedConverter_Step,
	PSFVoltageSourcedConverter_Tmin,
	PSFVoltageSourcedConverter_Tmax,
	PSFVoltageSourcedConverter_Amin,
	PSFVoltageSourcedConverter_Amax,
	PSFVoltageSourcedConverter_Gmin,
	PSFVoltageSourcedConverter_Gmax,
	PSFVoltageSourcedConverter_Imax,
	PSFVoltageSourcedConverter_Mode,
	PSFVoltageSourcedConverter_SP1,
	PSFVoltageSourcedConverter_SP2,
	PSFVoltageSourcedConverter_SP3,
	PSFVoltageSourcedConverter_X1,
	PSFVoltageSourcedConverter_Kc,
	PSFVoltageSourcedConverter_Type,
	PSFVoltageSourcedConverter_MVA,
	PSFVoltageSourcedConverter_kV,
	PSFVoltageSourcedConverter_Vmin,
	PSFVoltageSourcedConverter_Vmax,
	PSFVoltageSourcedConverter_Vref,
	PSFVoltageSourcedConverter_QA0,
	PSFVoltageSourcedConverter_La,
	PSFVoltageSourcedConverter_Lb,
	PSFVoltageSourcedConverter_Lmin,
	PSFVoltageSourcedConverter_PA0,
	PSFVoltageSourcedConverter_VD0,
	PSFVoltageSourcedConverter_ID0,
	PSFVoltageSourcedConverterEx_ACBus1Name,
	PSFVoltageSourcedConverterEx_ACBus2Name,
};
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Grp, Zone, B#, Xt, VR, Step, Tmin, Tmax, Amin, Amax, Gmin, Gmax, Imax
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Mode, SP1, SP2, SP3, X1, Kc, Type, MVA, ACBus2, kV
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Vmin, Vmax, Vref (optional)
//Code, Change, DCBus1, DCBus2, ACBus1, ID, DCBus3, DCBus4, ACBus2, ID2, QA0, La, Lb, Lmin
//Code, Change, DCBus1, DCBus2, ACBus1, ID, PA0, VD0, ID0 (optional)
static	tagPSFModelField	g_PSFVoltageSourcedConverterColumn[]=
{
	{	PSFVoltageSourcedConverter_DCBus1,		"DCBus1",		"Name of the first DC terminal.",																				"ֱ���˵�1",			MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_DCBus2,		"DCBus2",		"Name of the second DC terminal.",																				"ֱ���˵�2",			MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_ACBus1,		"ACBus1",		"AC bus1 number.",																								"����ĸ�ߺ�1",			MDB_INT,	"",		},
	{	PSFVoltageSourcedConverter_ID,			"ID",			"Converter ID.",																								"ID",					MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_DCBus3,		"DCBus3",		"Name of the first Alternative converter DC terminal.",															"ֱ���˵�",				MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_DCBus4,		"DCBus4",		"Name of the second Alternative converter DC terminal.",														"ֱ���˵�",				MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_ACBus2,		"ACBus2",		"Alternative converter AC bus number.",																			"����ĸ�ߺ�",			MDB_INT,	"",		},
	{	PSFVoltageSourcedConverter_ID2,			"ID2",			"Alternative converter ID.",																					"ID",					MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_Change,		"Change",		"change code.",																									"�޸���",				MDB_BIT,	"0",	},
	{	PSFVoltageSourcedConverter_Grp,			"Grp",			"group identifier which is used for solution reporting purposes.",												"������",				MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_Zone,		"Zone",			"Converter zone number.",																						"������",				MDB_SHORT,	"",		},
	{	PSFVoltageSourcedConverter_Bridge,		"B#",			"Number of series bridges.",																					"����",					MDB_SHORT,	"",		},
	{	PSFVoltageSourcedConverter_Xt,			"Xt",			"Transformer reactance in ohms per bridge.",																	"�ŵ翹",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_VR,			"VR",			"Nominal ratio of the secondary voltage (DC side) of converter transformer to the primary voltage (AC side).",	"ֱ�������",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Step,		"Step",			"Tap step in percent.",																							"��ͷ����",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Tmin,		"Tmin",			"Minimum tap setting in pu.",																					"��С��ͷ",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Tmax,		"Tmax",			"Maximum tap setting in pu.",																					"����ͷ",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Amin,		"Amin",			"Minimum alpha in degrees.",																					"��С������",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Amax,		"Amax",			"Maximum alpha in degrees.",																					"��󴥷���",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Gmin,		"Gmin",			"Minimum gamma in degrees.",																					"��С�ضϽ�",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Gmax,		"Gmax",			"Maximum gamma in degrees.",																					"���ضϽ�",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Imax,		"Imax",			"Maximum DC current in amps.",																					"������",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Mode,		"Mode",			"control model.",																								"����ģʽ",				MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverter_SP1,			"SP1",			"Converter set-point 1.",																						"����ֵ1",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_SP2,			"SP2",			"Converter set-point 2.",																						"����ֵ2",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_SP3,			"SP3",			"Converter set-point 3.",																						"����ֵ2",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_X1,			"X1",			"Line reactance in ohms.",																						"��·�翹",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Kc,			"Kc",			"Code for the DC to AC gain of the converter.",																	"ֱ������������",		MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Type,		"Type",			"identify the converter as a rectifier or an inverter.",														"����������",		MDB_BIT,	"",		},
	{	PSFVoltageSourcedConverter_MVA,			"MVA",			"Transformer MVA rating.",																						"��ѹ������",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_kV,			"kV",			"Base voltage of transformer AC side in kV.",																	"��ѹ����׼��ѹ",		MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Vmin,		"Vmin",			"Lower limit for the voltage of the first AC bus.",																"����ĸ��1��ѹ��ֵ",	MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Vmax,		"Vmax",			"Upper limit for the voltage of the second AC bus.",															"����ĸ��2��ѹ��ֵ1",	MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Vref,		"Vref",			"Estimated UPFC terminal voltage.",																				"���Ƶ��ѹ",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_QA0,			"QA0",			"AC reactive power solution in MVAr.",																			"�������޹�",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_La,			"La",			"Loss coefficient A.",																							"���ϵ��A",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Lb,			"Lb",			"Loss coefficient B.",																							"���ϵ��B",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_Lmin,		"Lmin",			"Minimal active power loss.",																					"����й�",				MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_PA0,			"PA0",			"AC active power solution in MW.",																				"�����๦�ʳ���",		MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_VD0,			"VD0",			"DC voltage solution in kV.",																					"ֱ����ѹ����",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverter_ID0,			"ID0",			"DC current solution in kA.",																					"ֱ����������",			MDB_FLOAT,	"",		},
	{	PSFVoltageSourcedConverterEx_ACBus1Name,	"ACBus1Name",	"Resolved ACBus1Name",																					"����ĸ��1����",		MDB_STRING,	"",		},
	{	PSFVoltageSourcedConverterEx_ACBus2Name,	"ACBus2Name",	"Resolved ACBus2Name",																					"����ĸ��2����",		MDB_STRING,	"",		},
};
typedef	struct _PSFVoltageSourcedConverter_
{
	char			szDCBus1[MDB_CHARLEN_TINY/2+1];
	char			szDCBus2[MDB_CHARLEN_TINY/2+1];
	int				nACBus1;
	char			szID[MDB_CHARLEN_TINY/2];

	char			szDCBus3[MDB_CHARLEN_TINY/2+1];
	char			szDCBus4[MDB_CHARLEN_TINY/2+1];
	int				nACBus2;
	char			szID2[MDB_CHARLEN_TINY/2];

	unsigned char	nChange;

	char			szGrp[MDB_CHARLEN_TINY/4];
	short			nZone;
	short			nBridge;
	float			fXt;
	float			fVR;
	float			fStep;
	float			fTmin;
	float			fTmax;
	float			fAmin;
	float			fAmax;
	float			fGmin;
	float			fGmax;
	float			fImax;

	char			szMode[MDB_CHARLEN_TINY/2];
	float			fSP1;
	float			fSP2;
	float			fSP3;
	float			fX1;
	float			fKc;
	unsigned char	nType;
	float			fMVA;
	float			fkV;

	float			fVmin;
	float			fVmax;
	float			fVref;

	float			fQA0;
	float			fLa;
	float			fLb;
	float			fLmin;

	float			fPA0;
	float			fVD0;
	float			fID0;

	//////////////////////////////////////////////////////////////////////////
	//	��չ����
	char			szACBus1Name[MDB_CHARLEN_TINY+1];
	char			szACBus2Name[MDB_CHARLEN_TINY+1];
	int				nACBus1Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
	int				nACBus2Index;				//	��¼ĸ����ĸ�������е���ţ�һ����BusNumber����ֹ������
}	tagPSFVoltageSourcedConverter;

//////////////////////////////////////////////////////////////////////////
//	** ZONE DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFZone_Field_	{
	PSFZone_Number=0,
	PSFZone_Name,
};
static	tagPSFModelField	g_PSFZoneColumn[]=
{
	{	PSFZone_Number,	"Number",	"Zone number.",				"�������",	MDB_INT,	"",	},
	{	PSFZone_Name,	"Name",		"zone name.",				"��������",	MDB_STRING,	"",	},
};

typedef	struct _PSFZone_
{
	int				nNumber;
	char			szName[MDB_CHARLEN_TINY];
}	tagPSFZone;

//////////////////////////////////////////////////////////////////////////
//	** NODE MAPPING DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFNodeMapping_Field_	{
	PSFNodeMapping_BusNumber=0,
	PSFNodeMapping_BusName,
	PSFNodeMapping_NodeName,
};
static	tagPSFModelField	g_PSFNodeMappingColumn[]=
{
	{	PSFNodeMapping_BusNumber,	"BusNumber",	"Number of the bus which contains the node.",	"ĸ�߱��",		MDB_INT,	"",	},
	{	PSFNodeMapping_BusName,		"BusName",		"Name of the bus which contains the node.",		"ĸ������",		MDB_STRING,	"",	},
	{	PSFNodeMapping_NodeName,	"NodeName",		"node equipment name.",							"�ڵ��豸����",	MDB_STRING,	"",	},
};
typedef	struct _PSFNodeMapping_
{
	int				nBusNumber;
	char			szBusName[MDB_CHARLEN_TINY+1];
	char			szNodeName[MDB_CHARLEN_SHORT];
}	tagPSFNodeMapping;

//////////////////////////////////////////////////////////////////////////
//	** ZERO SEQ MUTUAL COUPLING DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFZeroSequenceMutualCoupling_Field_	{
	PSFZeroSequenceMutualCoupling_Bus1L1Number=0,
	PSFZeroSequenceMutualCoupling_Bus2L1Number,
	PSFZeroSequenceMutualCoupling_IDL1,
	PSFZeroSequenceMutualCoupling_Bus1L2Number,
	PSFZeroSequenceMutualCoupling_Bus2L2Number,
	PSFZeroSequenceMutualCoupling_IDL2,
	PSFZeroSequenceMutualCoupling_R,
	PSFZeroSequenceMutualCoupling_X,
	PSFZeroSequenceMutualCoupling_CF1,
	PSFZeroSequenceMutualCoupling_CF2,
};
static	tagPSFModelField	g_PSFZeroSequenceMutualCouplingColumn[]=
{
	{	PSFZeroSequenceMutualCoupling_Bus1L1Number,	"Bus1L1Number",	"FROM bus number of the first line.",										"��·1���ĸ��",	MDB_INT,	"",	},
	{	PSFZeroSequenceMutualCoupling_Bus2L1Number,	"Bus2L1Number",	"TO bus number of the first line.",											"��·1�յ�ĸ��",	MDB_INT,	"",	},
	{	PSFZeroSequenceMutualCoupling_IDL1,			"IDL1",			"8-character line identifier of the first line.",							"��·1ID",			MDB_STRING,	"",	},
	{	PSFZeroSequenceMutualCoupling_Bus1L2Number,	"Bus1L2Number",	"FROM bus number of the second line.",										"��·2���ĸ��",	MDB_INT,	"",	},
	{	PSFZeroSequenceMutualCoupling_Bus2L2Number,	"Bus2L2Number",	"TO bus number of the second line.",										"��·2�յ�ĸ��",	MDB_INT,	"",	},
	{	PSFZeroSequenceMutualCoupling_IDL2,			"IDL2",			"8-character line identifier of the second line.",							"��·2ID",			MDB_STRING,	"",	},
	{	PSFZeroSequenceMutualCoupling_R,			"R",			"Mutual coupling impedance between two lines in pu on system MVA base.",	"��ϵ���",			MDB_FLOAT,	"",	},
	{	PSFZeroSequenceMutualCoupling_X,			"X",			"Mutual coupling impedance between two lines in pu on system MVA base.",	"��ϵ翹",			MDB_FLOAT,	"",	},
	{	PSFZeroSequenceMutualCoupling_CF1,			"CF1",			"Coupling factor of the first line.",										"��·1��ϲ���",	MDB_FLOAT,	"",	},
	{	PSFZeroSequenceMutualCoupling_CF2,			"CF2",			"Coupling factor of the second line.",										"��·2��ϲ���",	MDB_FLOAT,	"",	},
};

typedef	struct _PSFZeroSequenceMutualCoupling_
{
	int				nBus1L1Number;
	int				nBus2L1Number;
	char			szIDL1[MDB_CHARLEN_TINY/2];

	int				nBus1L2Number;
	int				nBus2L2Number;
	char			szIDL2[MDB_CHARLEN_TINY/2];

	float			fR;
	float			fX;
	float			fCF1;
	float			fCF2;
}	tagPSFZeroSequenceMutualCoupling;

//////////////////////////////////////////////////////////////////////////
//	** FILE SECTION DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_PSFFileSection_Field_	{
	PSFFileSection_FileIdentifier=0,
	PSFFileSection_FileName,
};
static	tagPSFModelField	g_PSFFileSectionColumn[]=
{
	{	PSFFileSection_FileIdentifier,	"FileIdentifier",	"A 4-character file identifier.",			"�ļ�ID",	MDB_STRING,	"",	},
	{	PSFFileSection_FileName,		"FileName",			"File name (maximum of 60 characters).",	"�ļ�����",	MDB_STRING,	"",	},
};
typedef	struct _PSFFileSection_
{
	char	szFileIdentifier[5];
	char	szFileName[61];
}	tagPSFFileSection;

//////////////////////////////////////////////////////////////////////////
//	** Psedo Substation DATA **
//////////////////////////////////////////////////////////////////////////
enum	_PSFEnum_Substation_PlantType	{
	PSFSubstation_Type_Substation=0,	//	���վ
	PSFSubstation_Type_TherimalPlant,	//	��糧
	PSFSubstation_Type_HydroPlant,		//	ˮ�糧
	PSFSubstation_Type_GasPlant,		//	ȼ���糧
	PSFSubstation_Type_NuclearPlant,	//	�˵糧
	PSFSubstation_Type_WindPlant,		//	��糡
	PSFSubstation_Type_PVPlant,		//	�����վ
	PSFSubstation_Type_RectifierInverterSubstation,		//	�������վ
};
enum	_PSFEnum_PSFSubstation_Field_	{
	PSFSubstation_Name=0,
	PSFSubstation_Type,
	PSFSubstation_RTName,
};
static	tagPSFModelField	g_PSFSubstationColumn[]=
{
	{	PSFSubstation_Name,			"Name",				"Substation name.",			"��վ����",			MDB_STRING,	"",		},
	{	PSFSubstation_Type,			"Type",				"Plant Type",				"��վ����",			MDB_BIT,	"",		},
	{	PSFSubstation_RTName,		"RTName",			"RealTime Substation Name",	"������վ����",		MDB_STRING,	"",		},
};
typedef	struct _PSFSubstation_
{
	char			szName[MDB_CHARLEN_TINY+1];
	unsigned char	nType;
	char			szRTName[MDB_CHARLEN];
	std::vector<int>	nBusArray;
}	tagPSFSubstation;

typedef	struct _PSFModel_Table_
{
	int		nModelIndex;
	char*	lpszModelName;
	char*	lpszModelDesp;

	short	nFieldNum;
	tagPSFModelField*	pFieldArray;
}	tagPSFModelTable;

enum	_PSFEnum_Table	{
	PSFModel_SolutionHistory=0,
	PSFModel_Substation,
	PSFModel_Bus,
	PSFModel_Generator,
	PSFModel_Load,
	PSFModel_LoadModel,
	PSFModel_FixedShunt,
	PSFModel_SwitchableShunt,
	PSFModel_Line,
	PSFModel_FixedTransformer,
	PSFModel_ULTCTransformer,
	PSFModel_ImpedanceCorrectionTables,
	PSFModel_FixedSeriesCompensator,
	PSFModel_SwitchableSeriesCompensator,
	PSFModel_StaticTapChangerPhaseRegulator,
	PSFModel_PSF3WindingTransformer,
	PSFModel_AreaInterchange,
	PSFModel_Interface,
	PSFModel_LineCommutatedConverters,
	PSFModel_DCLines,
	PSFModel_DCBreakers,
	PSFModel_DCBuses,
	PSFModel_VoltageSourcedConverter,
	PSFModel_Zone,
	PSFModel_NodeMapping,
	PSFModel_ZeroSequenceMutualCoupling,
	PSFModel_FileSection,
};

static	tagPSFModelTable	g_PSFModelTables[]=
{
	{	PSFModel_SolutionHistory,					"HistoryData",							"�������",					sizeof(g_PSFSolutionHistoryColumn)					/sizeof(tagPSFModelField),		g_PSFSolutionHistoryColumn,					},
	{	PSFModel_Substation,						"Substation",							"��վ",						sizeof(g_PSFSubstationColumn)						/sizeof(tagPSFModelField),		g_PSFSubstationColumn,						},
	{	PSFModel_Bus,								"BusData",								"ĸ������",					sizeof(g_PSFBusColumn)								/sizeof(tagPSFModelField),		g_PSFBusColumn,							},
	{	PSFModel_Generator,							"GeneratorData",						"���������",				sizeof(g_PSFGeneratorColumn)						/sizeof(tagPSFModelField),		g_PSFGeneratorColumn,					},
	{	PSFModel_Load,								"LoadData",								"��������",					sizeof(g_PSFLoadColumn)								/sizeof(tagPSFModelField),		g_PSFLoadColumn,						},
	{	PSFModel_LoadModel,							"LoadModelData",						"����ģ��",					sizeof(g_PSFLoadModelColumn)						/sizeof(tagPSFModelField),		g_PSFLoadModelColumn,					},
	{	PSFModel_FixedShunt,						"FixedShuntData",						"��������",					sizeof(g_PSFFixedShuntColumn)						/sizeof(tagPSFModelField),		g_PSFFixedShuntColumn,					},
	{	PSFModel_SwitchableShunt,					"SwitchedShuntData",					"��Ͷ�в���",				sizeof(g_PSFSwitchableShuntColumn)					/sizeof(tagPSFModelField),		g_PSFSwitchableShuntColumn,				},
	{	PSFModel_Line,								"LineData",								"��·����",					sizeof(g_PSFLineColumn)								/sizeof(tagPSFModelField),		g_PSFLineColumn,						},
	{	PSFModel_FixedTransformer,					"FixedTransformerData",					"��ѹ������",				sizeof(g_PSFFixedTransformerColumn)					/sizeof(tagPSFModelField),		g_PSFFixedTransformerColumn,			},
	{	PSFModel_ULTCTransformer,					"ULTCTransformerData",					"�ɵ���ѹ��",				sizeof(g_PSFULTCTransformerColumn)					/sizeof(tagPSFModelField),		g_PSFULTCTransformerColumn,				},
	{	PSFModel_ImpedanceCorrectionTables,			"ImpedanceCorrectionTables",			"�迹�޸ı�",				sizeof(g_PSFImpedanceCorrectionTablesColumn)		/sizeof(tagPSFModelField),		g_PSFImpedanceCorrectionTablesColumn,		},
	{	PSFModel_FixedSeriesCompensator,			"FixedSeriesCompensatorData",			"��������",					sizeof(g_PSFFixedSeriesCompensatorColumn)			/sizeof(tagPSFModelField),		g_PSFFixedSeriesCompensatorColumn,		},
	{	PSFModel_SwitchableSeriesCompensator,		"SwitchableSeriesCompensatorData",		"�ɵ���������",				sizeof(g_PSFSwitchableSeriesCompensatorColumn)		/sizeof(tagPSFModelField),		g_PSFSwitchableSeriesCompensatorColumn,		},
	{	PSFModel_StaticTapChangerPhaseRegulator,	"StaticTapChangerPhaseRegulatorData",	"��ֹ�ֽ�ͷ�任��/������",	sizeof(g_PSFStaticTapChangerPhaseRegulatorColumn)	/sizeof(tagPSFModelField),		g_PSFStaticTapChangerPhaseRegulatorColumn,	},
	{	PSFModel_PSF3WindingTransformer,			"3-WindingTransformerData",				"�������ѹ��",				sizeof(g_PSF3WindingTransformerColumn)				/sizeof(tagPSFModelField),		g_PSF3WindingTransformerColumn,				},
	{	PSFModel_AreaInterchange,					"AreaInterchangeData",					"�����ʽ�������",			sizeof(g_PSFAreaInterchangeColumn)					/sizeof(tagPSFModelField),		g_PSFAreaInterchangeColumn,					},
	{	PSFModel_Interface,							"InterfaceData",						"��������",					0,																					NULL,										},
	{	PSFModel_LineCommutatedConverters,			"LineCommutatedConverters",				"ֱ���任��",				sizeof(g_PSFLineCommutatedConvertersColumn)			/sizeof(tagPSFModelField),		g_PSFLineCommutatedConvertersColumn,		},
	{	PSFModel_DCLines,							"DCLines",								"ֱ����·",					sizeof(g_PSFDCLinesColumn)							/sizeof(tagPSFModelField),		g_PSFDCLinesColumn,							},
	{	PSFModel_DCBreakers,						"DCBreakers",							"ֱ����·��",				sizeof(g_PSFDCBreakersColumn)						/sizeof(tagPSFModelField),		g_PSFDCBreakersColumn,						},
	{	PSFModel_DCBuses,							"DCBuses",								"ֱ��ĸ��",					sizeof(g_PSFDCBusesColumn)							/sizeof(tagPSFModelField),		g_PSFDCBusesColumn,							},
	{	PSFModel_VoltageSourcedConverter,			"VoltageSourcedConverter",				"ֱ����ѹԴ�任��",			sizeof(g_PSFVoltageSourcedConverterColumn)			/sizeof(tagPSFModelField),		g_PSFVoltageSourcedConverterColumn,			},
	{	PSFModel_Zone,								"ZoneData",								"��������",					sizeof(g_PSFZoneColumn)								/sizeof(tagPSFModelField),		g_PSFZoneColumn,						},
	{	PSFModel_NodeMapping,						"NodeMappingData",						"�ڵ�ӳ������",				sizeof(g_PSFNodeMappingColumn)						/sizeof(tagPSFModelField),		g_PSFNodeMappingColumn,						},
	{	PSFModel_ZeroSequenceMutualCoupling,		"ZeroSeqMutualCouplingData",			"���򻥸��迹",				sizeof(g_PSFZeroSequenceMutualCouplingColumn)		/sizeof(tagPSFModelField),		g_PSFZeroSequenceMutualCouplingColumn,		},
	{	PSFModel_FileSection,						"FileSectionData",						"�ⲿ�ļ�",					sizeof(g_PSFFileSectionColumn)						/sizeof(tagPSFModelField),		g_PSFFileSectionColumn,					},
};

typedef	struct _PSFBusNobn_ 
{
	std::vector<int>	nGeneratorArray;
	std::vector<int>	nLoadArray;
	std::vector<int>	nFixedShuntArray;
	std::vector<int>	nSwitchableShuntArray;

	std::vector<int>	nLineArray;
	std::vector<int>	nFixedTransformerArray;
	std::vector<int>	nULTCTransformerArray;
	std::vector<int>	nFixedSeriesCompensatorArray;
	std::vector<int>	nSwitchableSeriesCompensatorArray;
	std::vector<int>	nStaticTapChangerPhaseRegulatorArray;
	std::vector<int>	nPSF3WindingTransformerArray;

	std::vector<int>	nLineCommutatedConvertersArray;
	std::vector<int>	nVoltageSourcedConverterArray;
}	tagPSFBusNobn;

typedef	struct	_PG2PSFMatch_
{
	short	nPSFType;
	char	szPSFKey[MDB_CHARLEN_LONG];
	char	szPGKey[MDB_CHARLEN_LONG];
}	tagPG2PSFMatch;

