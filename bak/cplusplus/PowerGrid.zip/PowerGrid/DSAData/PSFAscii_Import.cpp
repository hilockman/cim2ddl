#include "StdAfx.h"
#include "PSFAscii.h"

void	CPSFAscii::ImportPSFSolutionHistory(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	std::string	strBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;

	memset(&m_PSFSolution, 0, sizeof(tagPSFSolutionHistory));

	strBuf.clear();
	if ((int)strDataLineArray.size() > nLine)	strcpy(m_PSFSolution.szDescription1, strDataLineArray[nLine++].c_str());
	if ((int)strDataLineArray.size() > nLine)	strcpy(m_PSFSolution.szDescription2, strDataLineArray[nLine++].c_str());
	if ((int)strDataLineArray.size() > nLine)	strcpy(m_PSFSolution.szDescription3, strDataLineArray[nLine++].c_str());
	
	if ((int)strDataLineArray.size() > nLine)
	{
		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(m_PSFSolution.szDate, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(m_PSFSolution.szTime, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fBaseMVA=str2Float(bCheckValidate, PSFModel_SolutionHistory, 0, strEleArray[nEle++].c_str());
	}

	if ((int)strDataLineArray.size() > nLine)
	{
		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(m_PSFSolution.szMethod, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.nITER	=str2Integer(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_ITER, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fSOLTOL	=str2Float	(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_SOLTOL, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fBLUP	=str2Float	(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_BLUP, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fACCFCT	=str2Float	(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_ACCFCT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fZIL		=str2Float	(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_ZIL, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fVTOL	=str2Float	(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_VTOL, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.fCONADJ	=str2Float	(bCheckValidate, PSFModel_SolutionHistory, PSFSolutionHistory_CONADJ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(m_PSFSolution.szSTOPT, strEleArray[nEle++].c_str());
	}

	if ((int)strDataLineArray.size() > nLine)
	{
		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag1 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag2 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag3 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag4 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag5 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag6 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag7 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag8 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag9 =GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag10=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag11=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag12=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag13=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag14=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag15=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag16=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
		if ((int)strEleArray.size() > nEle)	m_PSFSolution.bFlag17=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFSolutionHistory_Flag)/sizeof(char*),	g_lpszPSFSolutionHistory_Flag);
	}
	//if (strEleArray.size() != g_PSFModelTables[PSFModel_SwitchableSeriesCompensator].nFieldNum)
	//	ASSERT(FALSE);
}

// Number, Name, Voltage, Angle, kV, Type, Status, Area, Zone, D1, D2, D3, D4, D5, Owner
// Equipment name, Latitude, Longitude
void	CPSFAscii::ImportPSFBus(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFBus	busBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFBusArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nPSFBusLines)
	{
		memset(&busBuf, 0, sizeof(tagPSFBus));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	busBuf.nNumber	=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_Number, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(busBuf.szName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.fVoltage	=str2Float	(bCheckValidate, PSFModel_Bus, PSFBus_Voltage, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.fAngle	=str2Float	(bCheckValidate, PSFModel_Bus, PSFBus_Angle, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.fkV		=str2Float	(bCheckValidate, PSFModel_Bus, PSFBus_kV, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nType	=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_Type, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nStatus	=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_Status, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nArea	=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_Area, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nZone	=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_Zone, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nD1		=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_D1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nD2		=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_D2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nD3		=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_D3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nD4		=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_D4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.nD5		=str2Integer(bCheckValidate, PSFModel_Bus, PSFBus_D5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(busBuf.szOwner,strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(busBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.fLatitude	=str2Float(bCheckValidate, PSFModel_Bus, PSFBus_Latitude, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	busBuf.fLongitude	=str2Float(bCheckValidate, PSFModel_Bus, PSFBus_Longitude, strEleArray[nEle++].c_str());

		m_PSFBusArray.push_back(busBuf);
	}
}

// Bus number, ID, Status, MW, MVAR, QMAX, QMIN, V Hi limit, V Lo limit, Remote bus, RMB V, % Ctrl
// USCH Q, MVA, PMAX, PMIN, RS, XS, RT, XT, TAP
// Equipment name, Owner, GWMOD, GWPF, GBASLD
// RP, XP, RN, XN, RZ, XZ, RG, XG
void	CPSFAscii::ImportPSFGenerator(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFGenerator	genBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFGeneratorArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nPSFGeneratorLines)
	{
		memset(&genBuf, 0, sizeof(tagPSFGenerator));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	genBuf.nBusNumber				=str2Integer(bCheckValidate, PSFModel_Generator, PSFGenerator_BusNumber, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(genBuf.szID,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.nStatus					=str2Integer(bCheckValidate, PSFModel_Generator, PSFGenerator_Status, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fMW						=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_MW, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fMVar					=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_MVAR, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fQMax					=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_QMAX, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fQMin					=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_QMIN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fVHiLimit				=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_VHiLimit, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fVLoLimit				=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_VLoLimit, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.nRemoteBus				=str2Integer(bCheckValidate, PSFModel_Generator, PSFGenerator_RemoteBus, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fRemoteBusV				=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RemoteBusV, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fQContributionPercentCtrl=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_QContributionPercentCtrl, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	genBuf.nUSCHQ	=str2Integer(bCheckValidate, PSFModel_Generator, PSFGenerator_USCHQ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fMva		=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_MVA, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fPMax	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_PMAX, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fPMin	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_PMIN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fRS		=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RS, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fXS		=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_XS, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fRT		=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fXT		=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_XT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fTAP		=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_TAP, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(genBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(genBuf.szOwner,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.nGWMOD	=str2Integer(bCheckValidate, PSFModel_Generator, PSFGenerator_GWMOD, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fGWPF	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_GWPF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.nGBASLD	=str2Integer(bCheckValidate, PSFModel_Generator, PSFGenerator_GBASLD, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	genBuf.fRP	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RP, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fXP	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_XP, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fRN	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fXN	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_XN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fRZ	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fXZ	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_XZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fRG	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_RG, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	genBuf.fXG	=str2Float	(bCheckValidate, PSFModel_Generator, PSFGenerator_XG, strEleArray[nEle++].c_str());

		m_PSFGeneratorArray.push_back(genBuf);
	}
}

// Bus number, Ref P, Ref Q, P1, Q1, P2, Q2, P3, Q3, P4, Q4
// P5, Q5, M1, M2, M3, M4, M5, Type, Owner, ID, Scalable
// Equipment name, Area, Zone, Status
// GN, BN, GZ, BZ
void	CPSFAscii::ImportPSFLoad(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFLoad	loadBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFLoadArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nLoadDataLines)
	{
		memset(&loadBuf, 0, sizeof(tagPSFLoad));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	loadBuf.nBusNumber	=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_BusNumber, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fRefP		=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_RefP, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fRefQ		=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_RefQ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fP1			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_P1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fQ1			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_Q1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fP2			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_P2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fQ2			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_Q2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fP3			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_P3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fQ3			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_Q3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fP4			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_P4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fQ4			=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_Q4, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	loadBuf.fP5		=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_P5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fQ5		=str2Float	(bCheckValidate, PSFModel_Load, PSFLoad_Q5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nM1		=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_M1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nM2		=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_M2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nM3		=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_M3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nM4		=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_M4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nM5		=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_M5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nType	=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_Type, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(loadBuf.szOwner,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(loadBuf.szID,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nScalable=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_Scalable, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(loadBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nArea	=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_Area, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nZone	=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_Zone, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.nStatus	=str2Integer(bCheckValidate, PSFModel_Load, PSFLoad_Status, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	loadBuf.fGN=str2Float(bCheckValidate, PSFModel_Load, PSFLoad_GN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fBN=str2Float(bCheckValidate, PSFModel_Load, PSFLoad_BN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fGZ=str2Float(bCheckValidate, PSFModel_Load, PSFLoad_GZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fBZ=str2Float(bCheckValidate, PSFModel_Load, PSFLoad_BZ, strEleArray[nEle++].c_str());

		m_PSFLoadArray.push_back(loadBuf);
	}
}

// Model number, A1, A2, A3, N1, N2, N3, B1, B2, B3, M1, M2, M3
void	CPSFAscii::ImportPSFLoadModel(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFLoadModel	loadBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFLoadModelArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nLoadModelDataLines)
	{
		memset(&loadBuf, 0, sizeof(tagPSFLoadModel));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	loadBuf.nModelNumber	=str2Integer(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_ModelNumber, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fA1				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_A1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fA2				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_A2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fA3				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_A3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fN1				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_N1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fN2				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_N2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fN3				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_N3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fB1				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_B1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fB2				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_B2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fB3				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_B3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fM1				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_M1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fM2				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_M2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	loadBuf.fM3				=str2Float	(bCheckValidate, PSFModel_LoadModel, PSFLoadModel_M3, strEleArray[nEle++].c_str());

		m_PSFLoadModelArray.push_back(loadBuf);
	}
}

// Bus number, G, B, Type, Owner, ID
// Equipment name, Status
// GN, BN, GZ, BZ
void	CPSFAscii::ImportPSFFixedShunt(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFFixedShunt	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFFixedShuntArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nFixedShuntDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFFixedShunt));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBusNumber	=str2Integer(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_BusNumber, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG			=str2Float	(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_G, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB			=str2Float	(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_B, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nType		=str2Integer(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_Type, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nStatus=str2Integer(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_Status, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fGN=str2Float(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_GN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fBN=str2Float(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_BN, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fGZ=str2Float(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_GZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fBZ=str2Float(bCheckValidate, PSFModel_FixedShunt, PSFFixedShunt_BZ, strEleArray[nEle++].c_str());

		m_PSFFixedShuntArray.push_back(dBuf);
	}
}

// Bus number, Mode, Status, V Hi limit, V Lo limit, Remote bus, RMB voltage, % Contrl, G0, B0, Owner
// ID, N1, B1, N2, B2, N3, B3, N4, B4, N5, B5, N6, B6, N7, B7, N8, B8 (second line of data for SW shunt / SVC)
// ID, IMAX (second line of data for STATSON)
// Equipment name, RV U limit, RV L limit
void	CPSFAscii::ImportPSFSwitchableShunt(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFSwitchableShunt	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFSwitchableShuntArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nSwitchableShuntDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFSwitchableShunt));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBusNumber					=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_BusNumber, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nMode						=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_Mode, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nStatus					=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_Status, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVHiLimit					=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_VHiLimit, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVLoLimit					=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_VLoLimit, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nRemoteBus					=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_RemoteBus, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRemoteBusVoltage			=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_RemoteBusVoltage, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fQContributionPercentCtrl	=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_QContributionPercentCtrl, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG0						=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_G0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB0						=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if (dBuf.nMode != 4)
		{
			if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN1=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N1, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN1=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B1, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN2=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N2, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN2=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B2, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN3=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N3, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN3=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B3, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN4=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N4, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN4=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B4, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN5=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N5, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN5=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B5, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN6=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N6, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN6=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B6, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN7=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N7, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN7=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B7, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.nN8=str2Integer(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_N8, strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fN8=str2Float	(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_B8, strEleArray[nEle++].c_str());
		}
		else
		{
			if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,strEleArray[nEle++].c_str());
			if ((int)strEleArray.size() > nEle)	dBuf.fIMAX=str2Float(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_IMAX, strEleArray[nEle++].c_str());
		}

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRVULimit=str2Float(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_RVULimit, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRVLLimit=str2Float(bCheckValidate, PSFModel_SwitchableShunt, PSFSwitchableShunt_RVLLimit, strEleArray[nEle++].c_str());

		m_PSFSwitchableShuntArray.push_back(dBuf);
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, R, X, G, B
// GF, BF, GT, BT, R1, R2, R3, R4, R5, R6, Rating group, Z1, Z2, Z3, Z4, Z5, Z6, Type
// Equipment name, Owner, Length
// RZ, XZ, RZC, XZC, RZSF, XZSF, RZST, XZST
void	CPSFAscii::ImportPSFLine(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFLine	lineBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFLineArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nLineDataLines)
	{
		memset(&lineBuf, 0, sizeof(tagPSFLine));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	lineBuf.nBus1Number	=str2Integer(bCheckValidate, PSFModel_Line, PSFLine_Bus1Number, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.nBus2Number	=str2Integer(bCheckValidate, PSFModel_Line, PSFLine_Bus2Number, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(lineBuf.szID,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.nSection	=str2Integer(bCheckValidate, PSFModel_Line, PSFLine_Section, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.nStatus		=str2Integer(bCheckValidate, PSFModel_Line, PSFLine_Status, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.nMeterEnd=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	//atoi(strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fX			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_X, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fG			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_G, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fB			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_B, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	lineBuf.fGF			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_GF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fBF			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_BF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fGT			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_GT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fBT			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_BT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR1			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR2			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR3			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR4			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR5			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fR6			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_R6, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.nRatingGroup=str2Integer(bCheckValidate, PSFModel_Line, PSFLine_RatingGroup, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fZ1			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_Z1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fZ2			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_Z2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fZ3			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_Z3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fZ4			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_Z4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fZ5			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_Z5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fZ6			=str2Float	(bCheckValidate, PSFModel_Line, PSFLine_Z6, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.nType		=str2Integer(bCheckValidate, PSFModel_Line, PSFLine_Type, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(lineBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(lineBuf.szOwner,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fLength		=str2Float(bCheckValidate, PSFModel_Line, PSFLine_Length, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	lineBuf.fRZ		=str2Float(bCheckValidate, PSFModel_Line, PSFLine_RZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fXZ		=str2Float(bCheckValidate, PSFModel_Line, PSFLine_XZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fRZC	=str2Float(bCheckValidate, PSFModel_Line, PSFLine_RZC, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fXZC	=str2Float(bCheckValidate, PSFModel_Line, PSFLine_XZC, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fRZSF	=str2Float(bCheckValidate, PSFModel_Line, PSFLine_RZSF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fXZSF	=str2Float(bCheckValidate, PSFModel_Line, PSFLine_XZSF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fRZST	=str2Float(bCheckValidate, PSFModel_Line, PSFLine_RZST, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	lineBuf.fXZST	=str2Float(bCheckValidate, PSFModel_Line, PSFLine_XZST, strEleArray[nEle++].c_str());

		m_PSFLineArray.push_back(lineBuf);
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, ONR, Angle, R, X, G, B
// GF, BF, GT, BT, R1, R2, R3, R4, R5, R6, Rating group, MVA
// Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Name, Owner
// RZ, XZ, Code, RGF, XGF, RGT, XGT
void	CPSFAscii::ImportPSFFixedTransformer(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFFixedTransformer	tranBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFFixedTranArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nFixedTransformerDataLines)
	{
		memset(&tranBuf, 0, sizeof(tagPSFFixedTransformer));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.nBus1Number	=str2Integer(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Bus1Number, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nBus2Number	=str2Integer(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Bus2Number, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szID,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nSection	=str2Integer(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Section, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nStatus		=str2Integer(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Status, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nMeterEnd=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	//atoi(strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fONR		=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_ONR, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fAngle		=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Angle, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fX			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_X, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fG			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_G, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fB			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_B, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.fGF			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_GF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fBF			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_BF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fGT			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_GT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fBT			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_BT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR1			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR2			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR3			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR4			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR5			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR6			=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_R6, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nRatingGroup=str2Integer(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_RatingGroup, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMVA		=str2Float	(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_MVA, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ1=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Z1, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ2=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Z2, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ3=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Z3, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ4=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Z4, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ5=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Z5, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ6=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_Z6, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szOwner,strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.fRZ	=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_RZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fXZ	=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_XZ, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nWindConnectionCode=str2Integer(bCheckValidate, PSFModel_FixedTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fRGF=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_RGF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fXGF=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_XGF, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fRGT=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_RGT, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fXGT=str2Float(bCheckValidate, PSFModel_FixedTransformer, PSFFixedTransformer_XGT, strEleArray[nEle++].c_str());

		m_PSFFixedTranArray.push_back(tranBuf);
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, FROM Ratio, TO Ratio, Angle, R, X, G, B
// GF, BF, GT, BT, Max R, Min R, Step, Max A, Min A, A Steps, Ctrl type, Ctrl side, Ctrl flag, Max MW, Min MW
// Max MVAR, Min MVAR, V Hi limit, V Lo limit, Ctrl Bus, Z Corr Table, R1, R2, R3, R4, R5, R6
// Rating group, MVA, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Name, Owner
// RZ, XZ, Code, RGF, XGF, RGT, XGT
void	CPSFAscii::ImportPSFULTCTransformer(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFULTCTransformer	tranBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFULTCTranArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nULTCTransformerDataLines)
	{
		memset(&tranBuf, 0, sizeof(tagPSFULTCTransformer));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.nBus1Number=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nBus2Number=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szID,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nSection=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nStatus=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nMeterEnd=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	//atoi(strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fFromRatio=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fToRatio=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fAngle=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fX=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fG=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fB=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.fGF=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fBF=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fGT=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fBT=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMaxR=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMinR=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fStep=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMaxA=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMinA=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fAStep=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nCtrlType=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFPSFULTCTransformer_CtrlType)/sizeof(char), g_lpszPSFPSFULTCTransformer_CtrlType);
		if ((int)strEleArray.size() > nEle)	tranBuf.nCtrlSide=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_CtrlSide)/sizeof(char), g_lpszPSF_CtrlSide);
		if ((int)strEleArray.size() > nEle)	tranBuf.nCtrlFlag=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMaxMW=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMinMW=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.fMaxMVar=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMinMVar=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fVHiLimit=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fVLoLimit=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nCtrlBus=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nZCorrTable=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR1=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR2=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR3=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR4=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR5=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fR6=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.nRatingGroup=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fMVA=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ1=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ2=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ3=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ4=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ5=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fZ6=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(tranBuf.szOwner,strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	tranBuf.fRZ=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fXZ=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.nWindConnectionCode=str2Integer(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fRGF=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fXGF=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fRGT=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	tranBuf.fXGT=str2Float(bCheckValidate, PSFModel_ULTCTransformer, 0, strEleArray[nEle++].c_str());

		m_PSFULTCTranArray.push_back(tranBuf);
	}
}

// Table #, T1, F1, T2, F2, T3, F3, T4, F4, T5, F5, T6, F6
// T7, F7, T8, F8, T9, F9, T10, F10, T11, F11
void	CPSFAscii::ImportPSFImpedanceCorrectionTables(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFImpedanceCorrectionTables	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFImpedanceCorrectionTablesArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nImpedanceCorrectionTablesDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFImpedanceCorrectionTables));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nTableNumber=str2Integer(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT1=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF1=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT2=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF2=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT3=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF3=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT4=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF4=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT5=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF5=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT6=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF6=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fT7=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF7=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT8=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF8=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT9=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF9=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT10=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF10=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fT11=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fF11=str2Float(bCheckValidate, PSFModel_ImpedanceCorrectionTables, 0, strEleArray[nEle++].c_str());

		m_PSFImpedanceCorrectionTablesArray.push_back(dBuf);
	}
}

// BUS1 number, BUS2 number, ID, Section #, X, Status, Meter end, AMP Rating, kV Rating, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Owner
void	CPSFAscii::ImportPSFFixedSeriesCompensator(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFFixedSeriesCompensator	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFFixedSeriesCompensatorArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nFixedSeriesCompensatorDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFFixedSeriesCompensator));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBus1Number=str2Integer(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus2Number=str2Integer(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSection=str2Integer(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nStatus=str2Integer(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nMeterEnd=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);
		if ((int)strEleArray.size() > nEle)	dBuf.fAMPRating=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fkVRating=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ1=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ2=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ3=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ4=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ5=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ6=str2Float(bCheckValidate, PSFModel_FixedSeriesCompensator, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szEquipmentName,strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,strEleArray[nEle++].c_str());

		m_PSFFixedSeriesCompensatorArray.push_back(dBuf);
	}
}

// BUS1 #, BUS2 #, ID, Section #, Status, Meter end, X, X Max, X Min, Steps, Ctrl flag, Max MW, Min MW
// AMP rating, kV rating, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Owner
void	CPSFAscii::ImportPSFSwitchableSeriesCompensator(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFSwitchableSeriesCompensator	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFSwitchableSeriesCompensatorArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nSwitchableSeriesCompensatorDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFSwitchableSeriesCompensator));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBus1Number				=str2Integer(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus2Number				=str2Integer(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,				strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSection					=str2Integer(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nStatus					=str2Integer(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nMeterEnd					=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	//atoi(strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX							=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXMax						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXMin						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSteps						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nCtrlFlag					=str2Integer(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMaxMW						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMinMW						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fAMPRating					=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fkVRating					=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ1						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ2						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ3						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ4						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ5						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ6						=str2Float(bCheckValidate, PSFModel_SwitchableSeriesCompensator, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szEquipmentName,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,			strEleArray[nEle++].c_str());

		m_PSFSwitchableSeriesCompensatorArray.push_back(dBuf);

		//if (strEleArray.size() != g_PSFModelTables[PSFModel_SwitchableSeriesCompensator].nFieldNum)
		//	ASSERT(FALSE);
	}
}

// BUS1 number, BUS2 number, ID, Section #, Status, Meter end, R, X, G, B, Name
// GF, BF, GT, BT, TCRG, PSRG, TC psn, PS psn, TCR, Max TCR, Min TCR, PSR, Max PSR, Min PSR, Ctrl type
// Ctrl side, Ctrl flag, Max P, Min P, Max Q, Min Q, V Hi limit, V Lo limit, Ctrl Bus, Z Corr TC, Z Corr PS, MVA
// R1, R2, R3, R4, R5, R6, Rating group, Z1, Z2, Z3, Z4, Z5, Z6
// Equipment name, Name, Owner
// RZ, XZ, Code, RGF, XGF, RGT, XGT
void	CPSFAscii::ImportPSFStaticTapChangerPhaseRegulator(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFStaticTapChangerPhaseRegulator	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFStaticTapChangerPhaseRegulatorArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nStaticTapChangerPhaseRegulatorDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFStaticTapChangerPhaseRegulator));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBus1Number=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus2Number=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSection=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nStatus=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nMeterEnd		=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_MeterEnd)/sizeof(char), g_lpszPSF_MeterEnd);	//atoi(strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fGF=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fBF=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fGT=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fBT=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTCRG=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPSRG=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTCpsn=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPSpsn=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTCR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMaxTCR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMinTCR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPSR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMaxPSR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMinPSR=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nCtrlType=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType)/sizeof(char*), g_lpszPSFStaticTapChangerPhaseRegulator_CtrlType);

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nCtrlSide=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF_CtrlSide)/sizeof(char), g_lpszPSF_CtrlSide);
		if ((int)strEleArray.size() > nEle)	dBuf.nCtrlFlag=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMaxP=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMinP=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMaxQ=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMinQ=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVHiLimit=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVLoLimit=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nCtrlBus=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nZCorrTC=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nZCorrPS=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMVA=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fR1=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR2=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR3=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR4=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR5=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR6=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nRatingGroup=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ1=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ2=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ3=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ4=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ5=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fZ6=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szEquipmentName,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szName,				strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,			strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fRZ=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXZ=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nWindConnectionCode=str2Integer(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRGF=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXGF=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRGT=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXGT=str2Float(bCheckValidate, PSFModel_StaticTapChangerPhaseRegulator, 0, strEleArray[nEle++].c_str());

		m_PSFStaticTapChangerPhaseRegulatorArray.push_back(dBuf);
	}
}

// BUS1 number, BUS2 number, BUS3 number, ID, Status, Non-metered end
// Ratio 1, Angle 1, Ratio 2, Angle 2, Ratio 3, Angle 3
// R1, X1, R2, X2, R3, X3, G1, B1, G2, B2, G3, B3
// Max R/A, Min R/A, Step, Ctrl side, Ctrl flag, Max ctrl, Min ctrl, Ctrl bus, Z Corr table (for the primary winding)
// Max R/A, Min R/A, Step, Ctrl side, Ctrl flag, Max ctrl, Min ctrl, Ctrl bus, Z Corr table (for the secondary winding)
// Max R/A, Min R/A, Step, Ctrl side, Ctrl flag, Max ctrl, Min ctrl, Ctrl bus, Z Corr table (for the tertiary winding)
// G1, B1, G2, B2, G3, B3, PR1, PR2, PR3, PR4, PR5, PR6, Rating group, MVA
// SR1, SR2, SR3, SR4, SR5, SR6, TR1, TR2, TR3, TR4, TR5, TR6
// Equipment name, Name, Owner
// PR0, PX0, SR0, SX0, TR0, TX0
// Code, PGR, PGX, SGR, SGX, TGR, TGX
void	CPSFAscii::ImportPSF3WindingTransformer(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSF3WindingTransformer	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSF3WindingTranArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_n3WindingTransformerDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSF3WindingTransformer));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBus1Number=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus2Number=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus3Number=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nStatus=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nNonMeteredEnd=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF3WindingTransformer_NonMeteredEnd)/sizeof(char), g_lpszPSF3WindingTransformer_NonMeteredEnd);

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fRatio1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAngle1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRatio2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAngle2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fRatio3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAngle3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fR1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fR3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fPMaxRA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPMinRA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPStep=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nPCtrlSide=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF3WindingTransformer_CtrlSide)/sizeof(char), g_lpszPSF3WindingTransformer_CtrlSide);
		if ((int)strEleArray.size() > nEle)	dBuf.nPCtrlFlag=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPMaxCtrl=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPMinCtrl=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nPCtrlBus=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nPZCorrTable=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fSMaxRA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSMinRA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSStep=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSCtrlSide=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF3WindingTransformer_CtrlSide)/sizeof(char), g_lpszPSF3WindingTransformer_CtrlSide);
		if ((int)strEleArray.size() > nEle)	dBuf.nSCtrlFlag=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSMaxCtrl=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSMinCtrl=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSCtrlBus=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSZCorrTable=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fTMaxRA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTMinRA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTStep=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nTCtrlSide=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSF3WindingTransformer_CtrlSide)/sizeof(char), g_lpszPSF3WindingTransformer_CtrlSide);
		if ((int)strEleArray.size() > nEle)	dBuf.nTCtrlFlag=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTMaxCtrl=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTMinCtrl=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nTCtrlBus=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nTZCorrTable=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fG1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fG3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fB3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPR1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPR2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPR3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPR4=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPR5=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPR6=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nRatingGroup=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMVA=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fSR1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSR2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSR3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSR4=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSR5=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSR6=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR1=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR2=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR3=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR4=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR5=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR6=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szEquipmentName,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szName,				strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,			strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.fPR0=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPX0=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSR0=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSX0=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTR0=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTX0=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nGroundingCode=str2Integer(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPGR=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPGX=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSGR=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSGX=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTGR=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTGX=str2Float(bCheckValidate, PSFModel_PSF3WindingTransformer, 0, strEleArray[nEle++].c_str());

		m_PSF3WindingTranArray.push_back(dBuf);
	}
}

//Number, Name, Desired flow, Tolerance, Slack bus, Description, Mode, Flag
void	CPSFAscii::ImportPSFAreaInterchange(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFAreaInterchange	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFAreaInterchangeArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nAreaInterchangeDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFAreaInterchange));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;

		if ((int)strEleArray.size() > nEle)	dBuf.nNumber		=str2Integer(bCheckValidate, PSFModel_AreaInterchange, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szName,			strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fDesiredFlow	=str2Float	(bCheckValidate, PSFModel_AreaInterchange, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTolerance		=str2Float	(bCheckValidate, PSFModel_AreaInterchange, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nSlackBus		=str2Integer(bCheckValidate, PSFModel_AreaInterchange, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDescription,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nMode			=str2Integer(bCheckValidate, PSFModel_AreaInterchange, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nFlag			=str2Integer(bCheckValidate, PSFModel_AreaInterchange, 0, strEleArray[nEle++].c_str());

		m_PSFAreaInterchangeArray.push_back(dBuf);
	}
}

//Code, Change, DCBus1, DCBus2, ACBus, ID, Grp, Zone, B#, Xc, VR, Tstep, Tmin, Tmax, Amin, Amax, Gmin, Imax
//Code, Change, DCBus1, DCBus2, ACBus, ID, Ctrl Mode, SP1, SP2, Type, MVA, Pmin, Pmax, Qmin, Qmax, BiasR, kV
void	CPSFAscii::ParsePSFLineCommutatedConverters(const unsigned char bCheckValidate, const char* lpszCode, std::vector<std::string>& strEleArray)
{
	register int	i;
	int		nEle,nFind;
	tagPSFLineCommutatedConverters	dBuf;

	memset(&dBuf, 0, sizeof(tagPSFLineCommutatedConverters));

	nEle=1;
	if ((int)strEleArray.size() > nEle)	dBuf.nChange=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus1,		strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus2,		strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nACBus=str2Integer(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nID=str2Integer(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());

	if (stricmp(lpszCode,"BD") == 0)
	{
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szGrp,			strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nZone=str2Integer(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBridge=str2Integer(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXc=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVR=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTstep=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTmin=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTmax=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAmin=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAmax=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fGmin=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fImax=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
	}
	else if (stricmp(lpszCode,"BZ") == 0)
	{
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szCtrlMode,			strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSP1=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSP2=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nType=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Type)/sizeof(char), g_lpszPSFMultiTerminalDC_Type);
		if ((int)strEleArray.size() > nEle)	dBuf.fMVA=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPmin=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fPmax=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fQmin=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fQmax=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fBiasR=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fkV=str2Float(bCheckValidate, PSFModel_LineCommutatedConverters, 0, strEleArray[nEle++].c_str());
	}

	nFind=-1;
	for (i=0; i<(int)m_PSFLCConvertersArray.size(); i++)
	{
		if (strcmp(m_PSFLCConvertersArray[i].szDCBus1, dBuf.szDCBus1) == 0 && strcmp(m_PSFLCConvertersArray[i].szDCBus2,dBuf.szDCBus2) == 0 && 
			m_PSFLCConvertersArray[i].nACBus == dBuf.nACBus && m_PSFLCConvertersArray[i].nID == dBuf.nID)
		{
			nFind=i;
			break;
		}
	}
	if (nFind >= 0)
	{
		if (stricmp(lpszCode,"BD") == 0)
		{
			strcpy(m_PSFLCConvertersArray[nFind].szGrp,		dBuf.szGrp);
			m_PSFLCConvertersArray[nFind].nZone	=	dBuf.nZone	;
			m_PSFLCConvertersArray[nFind].nBridge	=	dBuf.nBridge;
			m_PSFLCConvertersArray[nFind].fXc		=	dBuf.fXc	;
			m_PSFLCConvertersArray[nFind].fVR		=	dBuf.fVR	;
			m_PSFLCConvertersArray[nFind].fTstep	=	dBuf.fTstep	;
			m_PSFLCConvertersArray[nFind].fTmin	=	dBuf.fTmin	;
			m_PSFLCConvertersArray[nFind].fTmax	=	dBuf.fTmax	;
			m_PSFLCConvertersArray[nFind].fAmin	=	dBuf.fAmin	;
			m_PSFLCConvertersArray[nFind].fAmax	=	dBuf.fAmax	;
			m_PSFLCConvertersArray[nFind].fGmin	=	dBuf.fGmin	;
			m_PSFLCConvertersArray[nFind].fImax	=	dBuf.fImax	;
		}
		else if (stricmp(lpszCode,"BZ") == 0)
		{
			strcpy(m_PSFLCConvertersArray[nFind].szCtrlMode,	dBuf.szCtrlMode);
			m_PSFLCConvertersArray[nFind].fSP1		=dBuf.fSP1	;
			m_PSFLCConvertersArray[nFind].fSP2		=dBuf.fSP2	;
			m_PSFLCConvertersArray[nFind].nType	=dBuf.nType	;
			m_PSFLCConvertersArray[nFind].fMVA		=dBuf.fMVA	;	
			m_PSFLCConvertersArray[nFind].fPmin	=dBuf.fPmin	;
			m_PSFLCConvertersArray[nFind].fPmax	=dBuf.fPmax	;
			m_PSFLCConvertersArray[nFind].fQmin	=dBuf.fQmin	;
			m_PSFLCConvertersArray[nFind].fQmax	=dBuf.fQmax	;
			m_PSFLCConvertersArray[nFind].fBiasR	=dBuf.fBiasR;
			m_PSFLCConvertersArray[nFind].fkV		=dBuf.fkV	;
		}
	}
	else
	{
		m_PSFLCConvertersArray.push_back(dBuf);
	}
}

void	CPSFAscii::ParsePSFDCLines(unsigned char bCheckValidate, std::vector<std::string>& strEleArray)
{
	register int	i;
	int		nFind,nEle;
	tagPSFDCLines		dBuf;

	memset(&dBuf, 0, sizeof(tagPSFDCLines));

	nEle=1;
	if ((int)strEleArray.size() > nEle)	dBuf.nChange=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus1,		strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus2,		strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,			strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szGrp,			strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nZone=str2Integer(bCheckValidate, PSFModel_DCLines, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,		strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.fRdc=str2Float(bCheckValidate, PSFModel_DCLines, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.fLdc=str2Float(bCheckValidate, PSFModel_DCLines, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.fCdca=str2Float(bCheckValidate, PSFModel_DCLines, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.fCdcb=str2Float(bCheckValidate, PSFModel_DCLines, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.fImax=str2Float(bCheckValidate, PSFModel_DCLines, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nMend=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Mend)/sizeof(char), g_lpszPSFMultiTerminalDC_Mend);

	nFind=-1;
	for (i=0; i<(int)m_PSFDCLinesArray.size(); i++)
	{
		if (strcmp(m_PSFDCLinesArray[i].szDCBus1,dBuf.szDCBus1) == 0 &&
			strcmp(m_PSFDCLinesArray[i].szDCBus2,dBuf.szDCBus2) == 0 &&
			strcmp(m_PSFDCLinesArray[i].szID,dBuf.szID) == 0)
		{
			nFind=i;
			break;
		}
	}
	if (nFind >= 0)
	{
		m_PSFDCLinesArray[nFind].nChange=dBuf.nChange;
		strcpy(m_PSFDCLinesArray[nFind].szDCBus1,		dBuf.szDCBus1);
		strcpy(m_PSFDCLinesArray[nFind].szDCBus2,		dBuf.szDCBus2);
		strcpy(m_PSFDCLinesArray[nFind].szID,			dBuf.szID);
		strcpy(m_PSFDCLinesArray[nFind].szGrp,			dBuf.szGrp);

		m_PSFDCLinesArray[nFind].nZone	=dBuf.nZone	;
		strcpy(m_PSFDCLinesArray[nFind].szOwner,		dBuf.szOwner);
		m_PSFDCLinesArray[nFind].fRdc	=dBuf.fRdc	;
		m_PSFDCLinesArray[nFind].fLdc	=dBuf.fLdc	;
		m_PSFDCLinesArray[nFind].fCdca	=dBuf.fCdca	;
		m_PSFDCLinesArray[nFind].fCdcb	=dBuf.fCdcb	;
		m_PSFDCLinesArray[nFind].fImax	=dBuf.fImax	;
		m_PSFDCLinesArray[nFind].nMend	=dBuf.nMend	;
	}
	else
	{
		m_PSFDCLinesArray.push_back(dBuf);
	}
}

void	CPSFAscii::ParsePSFDCBreakers(unsigned char bCheckValidate, std::vector<std::string>& strEleArray)
{
	register int	i;
	int		nFind,nEle;
	tagPSFDCBreakers	dBuf;

	memset(&dBuf, 0, sizeof(tagPSFDCBreakers));
	nEle=1;
	if ((int)strEleArray.size() > nEle)	dBuf.nChange=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus1,			strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus2,			strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,				strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szGrp,				strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nZone=str2Integer(bCheckValidate, PSFModel_DCBreakers, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szOwner,			strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nStatus=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Status)/sizeof(char*), g_lpszPSFMultiTerminalDC_Status);

	nFind=-1;
	for (i=0; i<(int)m_PSFDCBreakersArray.size(); i++)
	{
		if (strcmp(m_PSFDCBreakersArray[i].szDCBus1,dBuf.szDCBus1) == 0 &&
			strcmp(m_PSFDCBreakersArray[i].szDCBus2,dBuf.szDCBus2) == 0 &&
			strcmp(m_PSFDCBreakersArray[i].szID,dBuf.szID) == 0)
		{
			nFind=i;
			break;
		}
	}
	if (nFind >= 0)
	{
		m_PSFDCBreakersArray[nFind].nChange=dBuf.nChange;
		strcpy(m_PSFDCBreakersArray[nFind].szDCBus1,		dBuf.szDCBus1);
		strcpy(m_PSFDCBreakersArray[nFind].szDCBus2,		dBuf.szDCBus2);
		strcpy(m_PSFDCBreakersArray[nFind].szID,			dBuf.szID	);
		strcpy(m_PSFDCBreakersArray[nFind].szGrp,			dBuf.szGrp	);

		m_PSFDCBreakersArray[nFind].nZone		=dBuf.nZone;
		strcpy(m_PSFDCBreakersArray[nFind].szOwner,		dBuf.szOwner);
		m_PSFDCBreakersArray[nFind].nStatus	=dBuf.nStatus;
	}
	else
	{
		m_PSFDCBreakersArray.push_back(dBuf);
	}
}

void	CPSFAscii::ParsePSFDCBuses(unsigned char bCheckValidate, std::vector<std::string>& strEleArray)
{
	register int	i;
	int		nFind,nEle;
	tagPSFDCBuses		dBuf;

	memset(&dBuf, 0, sizeof(tagPSFDCBuses));

	nEle=1;
	if ((int)strEleArray.size() > nEle)	dBuf.nChange=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus,			strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nArea=str2Integer(bCheckValidate, PSFModel_DCBuses, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nZone=str2Integer(bCheckValidate, PSFModel_DCBuses, 0, strEleArray[nEle++].c_str());
	nFind=-1;
	for (i=0; i<(int)m_PSFDCBusesArray.size(); i++)
	{
		if (strcmp(m_PSFDCBusesArray[i].szDCBus,dBuf.szDCBus) == 0)
		{
			nFind=i;
			break;
		}
	}
	if (nFind >= 0)
	{
		m_PSFDCBusesArray[nFind].nChange=dBuf.nChange;
		strcpy(m_PSFDCBusesArray[nFind].szDCBus,	dBuf.szDCBus);
		m_PSFDCBusesArray[nFind].nArea=dBuf.nArea;
		m_PSFDCBusesArray[nFind].nZone=dBuf.nZone;
	}
	else
	{
		m_PSFDCBusesArray.push_back(dBuf);
	}
}

//Code, Change, DCBus1, DCBus2, ACBus1, ID, Grp, Zone, B#, Xt, VR, Step, Tmin, Tmax, Amin, Amax, Gmin, Gmax, Imax
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Mode, SP1, SP2, SP3, X1, Kc, Type, MVA, ACBus2, kV
//Code, Change, DCBus1, DCBus2, ACBus1, ID, Vmin, Vmax, Vref (optional)
//Code, Change, DCBus1, DCBus2, ACBus1, ID, DCBus3, DCBus4, ACBus2, ID2, QA0, La, Lb, Lmin
//Code, Change, DCBus1, DCBus2, ACBus1, ID, PA0, VD0, ID0 (optional)
void	CPSFAscii::ParsePSFVoltageSourcedConverter(const unsigned char bCheckValidate, const char* lpszCode, std::vector<std::string>& strEleArray)
{
	register int	i;
	int		nFind,nEle;
	tagPSFVoltageSourcedConverter	dBuf;

	nEle=1;
	if ((int)strEleArray.size() > nEle)	dBuf.nChange=GetEnumValue(strEleArray[nEle++].c_str(), sizeof(g_lpszPSFMultiTerminalDC_Change)/sizeof(char), g_lpszPSFMultiTerminalDC_Change);
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus1,				strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus2,				strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	dBuf.nACBus1=str2Integer(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
	if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID,					strEleArray[nEle++].c_str());
	if (stricmp(lpszCode, "FD") == 0)
	{
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szGrp,				strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nZone=str2Integer(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBridge=str2Integer(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fXt=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVR=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fStep=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTmin=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fTmax=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAmin=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fAmax=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fGmin=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fGmax=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fImax=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
	}
	else if (stricmp(lpszCode, "FZ") == 0)
	{
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szMode,				strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSP1=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSP2=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fSP3=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX1=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fKc=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nType=str2Integer(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fMVA=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nACBus2=str2Integer(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fkV=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
	}
	else if (stricmp(lpszCode, "FV") == 0)
	{
		if ((int)strEleArray.size() > nEle)	dBuf.fVmin=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVmax=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVref=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
	}
	else if (stricmp(lpszCode, "FR") == 0)
	{
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus3,			strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szDCBus4,			strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nACBus2=str2Integer(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szID2,				strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fQA0=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fLa=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fLb=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fLmin=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
	}
	else if (stricmp(lpszCode, "FC") == 0)
	{
		if ((int)strEleArray.size() > nEle)	dBuf.fPA0=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fVD0=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fID0=str2Float(bCheckValidate, PSFModel_VoltageSourcedConverter, 0, strEleArray[nEle++].c_str());
	}

	nFind=-1;
	for (i=0; i<(int)m_PSFVSCArray.size(); i++)
	{
		if (strcmp(m_PSFVSCArray[i].szDCBus1, dBuf.szDCBus1) == 0 &&
			strcmp(m_PSFVSCArray[i].szDCBus2, dBuf.szDCBus2) == 0 && 
			m_PSFVSCArray[i].nACBus1 == dBuf.nACBus1 && 
			strcmp(m_PSFVSCArray[i].szID,dBuf.szID) == 0)
		{
			nFind=i;
			break;
		}
	}
	if (nFind >= 0)
	{
		if (stricmp(lpszCode, "FD") == 0)
		{
			strcpy(m_PSFVSCArray[nFind].szGrp,			dBuf.szGrp);
			m_PSFVSCArray[nFind].nZone	=dBuf.nZone	;
			m_PSFVSCArray[nFind].nBridge=dBuf.nBridge;
			m_PSFVSCArray[nFind].fXt	=dBuf.fXt	;
			m_PSFVSCArray[nFind].fVR	=dBuf.fVR	;
			m_PSFVSCArray[nFind].fStep	=dBuf.fStep	;
			m_PSFVSCArray[nFind].fTmin	=dBuf.fTmin	;
			m_PSFVSCArray[nFind].fTmax	=dBuf.fTmax	;
			m_PSFVSCArray[nFind].fAmin	=dBuf.fAmin	;
			m_PSFVSCArray[nFind].fAmax	=dBuf.fAmax	;
			m_PSFVSCArray[nFind].fGmin	=dBuf.fGmin	;
			m_PSFVSCArray[nFind].fGmax	=dBuf.fGmax	;
			m_PSFVSCArray[nFind].fImax	=dBuf.fImax	;
		}
		else if (stricmp(lpszCode, "FZ") == 0)
		{
			strcpy(m_PSFVSCArray[nFind].szMode,		dBuf.szMode);
			m_PSFVSCArray[nFind].fSP1	=dBuf.fSP1	;
			m_PSFVSCArray[nFind].fSP2	=dBuf.fSP2	;
			m_PSFVSCArray[nFind].fSP3	=dBuf.fSP3	;
			m_PSFVSCArray[nFind].fX1	=dBuf.fX1	;
			m_PSFVSCArray[nFind].fKc	=dBuf.fKc	;
			m_PSFVSCArray[nFind].nType	=dBuf.nType	;
			m_PSFVSCArray[nFind].fMVA	=dBuf.fMVA	;
			m_PSFVSCArray[nFind].nACBus2=dBuf.nACBus2;
			m_PSFVSCArray[nFind].fkV	=dBuf.fkV	;
		}
		else if (stricmp(lpszCode, "FV") == 0)
		{
			m_PSFVSCArray[nFind].fVmin=dBuf.fVmin;
			m_PSFVSCArray[nFind].fVmax=dBuf.fVmax;
			m_PSFVSCArray[nFind].fVref=dBuf.fVref;
		}
		else if (stricmp(lpszCode, "FR") == 0)
		{
			strcpy(m_PSFVSCArray[nFind].szDCBus3,		dBuf.szDCBus3);
			strcpy(m_PSFVSCArray[nFind].szDCBus4,		dBuf.szDCBus4);
			m_PSFVSCArray[nFind].nACBus2	=dBuf.nACBus2;
			strcpy(m_PSFVSCArray[nFind].szID2,			dBuf.szID2);
			m_PSFVSCArray[nFind].fQA0	=dBuf.fQA0	;
			m_PSFVSCArray[nFind].fLa	=dBuf.fLa	;
			m_PSFVSCArray[nFind].fLb	=dBuf.fLb	;
			m_PSFVSCArray[nFind].fLmin	=dBuf.fLmin	;
		}
		else if (stricmp(lpszCode, "FC") == 0)
		{
			m_PSFVSCArray[nFind].fPA0=dBuf.fPA0;
			m_PSFVSCArray[nFind].fVD0=dBuf.fVD0;
			m_PSFVSCArray[nFind].fID0=dBuf.fID0;
		}
	}
	else
	{
		m_PSFVSCArray.push_back(dBuf);
	}
}

void	CPSFAscii::ImportPSFMultiTerminalDC(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine, nEle;
	std::vector<std::string>	strEleArray;

	m_PSFLCConvertersArray.clear();
	m_PSFDCLinesArray.clear();
	m_PSFDCBreakersArray.clear();
	m_PSFDCBusesArray.clear();
	m_PSFVSCArray.clear();

	nLine=nEle=0;
	while ((int)strDataLineArray.size() > nLine+1)
	{
		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		if (stricmp(strEleArray[nEle].c_str(),"BD") == 0 || stricmp(strEleArray[nEle].c_str(),"BZ") == 0)
		{
			ParsePSFLineCommutatedConverters(bCheckValidate, strEleArray[nEle].c_str(), strEleArray);
		}
		else if (stricmp(strEleArray[nEle].c_str(),"LD") == 0)
		{
			ParsePSFDCLines(bCheckValidate, strEleArray);
		}
		else if (stricmp(strEleArray[nEle].c_str(),"LB") == 0)
		{
			ParsePSFDCBreakers(bCheckValidate, strEleArray);
		}
		else if (stricmp(strEleArray[nEle].c_str(),"DA") == 0)
		{
			ParsePSFDCBuses(bCheckValidate, strEleArray);
		}
		else if (stricmp(strEleArray[nEle].c_str(),"FD") == 0 ||
			stricmp(strEleArray[nEle].c_str(),"FZ") == 0 ||
			stricmp(strEleArray[nEle].c_str(),"FV") == 0 ||
			stricmp(strEleArray[nEle].c_str(),"FR") == 0 ||
			stricmp(strEleArray[nEle].c_str(),"FC") == 0)
		{
			ParsePSFVoltageSourcedConverter(bCheckValidate, strEleArray[nEle].c_str(), strEleArray);
		}
	}
}

void	CPSFAscii::ImportPSFZone(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFZone	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFZoneArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nZoneDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFZone));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nNumber=str2Integer(bCheckValidate, PSFModel_Zone, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szName,			strEleArray[nEle++].c_str());

		m_PSFZoneArray.push_back(dBuf);
	}
}

void	CPSFAscii::ImportPSFNodeMapping(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFNodeMapping	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFNodeMappingArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nNodeMappingDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFNodeMapping));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBusNumber=str2Integer(bCheckValidate, PSFModel_NodeMapping, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szBusName,			strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szNodeName,			strEleArray[nEle++].c_str());

		m_PSFNodeMappingArray.push_back(dBuf);
	}
}

void	CPSFAscii::ImportPSFZeroSequenceMutualCoupling(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFZeroSequenceMutualCoupling	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFZeroSequenceMutualCouplingArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nZeroSequenceMutualCouplingDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFZeroSequenceMutualCoupling));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	dBuf.nBus1L1Number=str2Integer(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus2L1Number=str2Integer(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szIDL1,			strEleArray[nEle++].c_str());

		if ((int)strEleArray.size() > nEle)	dBuf.nBus1L2Number=str2Integer(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.nBus2L2Number=str2Integer(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szIDL2,			strEleArray[nEle++].c_str());

		if ((int)strEleArray.size() > nEle)	dBuf.fR=str2Float(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fX=str2Float(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fCF1=str2Float(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	dBuf.fCF2=str2Float(bCheckValidate, PSFModel_ZeroSequenceMutualCoupling, 0, strEleArray[nEle++].c_str());

		m_PSFZeroSequenceMutualCouplingArray.push_back(dBuf);
	}
}

void	CPSFAscii::ImportPSFFileSection(unsigned char bCheckValidate, std::vector<std::string>& strDataLineArray)
{
	int		nLine,nEle;
	tagPSFFileSection	dBuf;
	std::vector<std::string>	strEleArray;

	nLine=0;
	m_PSFFileSectionArray.clear();

	while ((int)strDataLineArray.size() > nLine+g_nFileSectionDataLines)
	{
		memset(&dBuf, 0, sizeof(tagPSFFileSection));

		ParseLineString(strDataLineArray[nLine++].c_str(), strEleArray);
		nEle=0;
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szFileIdentifier,	strEleArray[nEle++].c_str());
		if ((int)strEleArray.size() > nEle)	strcpy(dBuf.szFileName,			strEleArray[nEle++].c_str());

		m_PSFFileSectionArray.push_back(dBuf);
	}
}

void	CPSFAscii::PSFAsciiMaint(const double fZIL)
{
	register int	i;
	int		nData;
	tagPSFBusNobn	nobnBuf;
	nobnBuf.nGeneratorArray.clear();
	nobnBuf.nLoadArray.clear();
	nobnBuf.nFixedShuntArray.clear();
	nobnBuf.nSwitchableShuntArray.clear();
	nobnBuf.nLineArray.clear();
	nobnBuf.nFixedTransformerArray.clear();
	nobnBuf.nULTCTransformerArray.clear();
	nobnBuf.nFixedSeriesCompensatorArray.clear();
	nobnBuf.nSwitchableSeriesCompensatorArray.clear();
	nobnBuf.nStaticTapChangerPhaseRegulatorArray.clear();
	nobnBuf.nPSF3WindingTransformerArray.clear();
	nobnBuf.nLineCommutatedConvertersArray.clear();
	nobnBuf.nVoltageSourcedConverterArray.clear();

	sortBusDataByBusNumber(0, m_PSFBusArray.size()-1);

	m_BusNobnArray.clear();
	for (i=0; i<(int)m_PSFBusArray.size(); i++)
		m_BusNobnArray.push_back(nobnBuf);

	for (i=0; i<(int)m_PSFBusArray.size(); i++)
	{
		for (nData=0; nData<(int)m_PSFZoneArray.size(); nData++)
		{
			if (m_PSFBusArray[i].nZone == m_PSFZoneArray[nData].nNumber)
			{
				strcpy(m_PSFBusArray[i].szZoneName, m_PSFZoneArray[nData].szName);
				break;
			}
		}
	}

	for (i=0; i<(int)m_PSFGeneratorArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFGeneratorArray[i].nBusNumber);
		if (nData >= 0)
		{
			strcpy(m_PSFGeneratorArray[i].szBusName, m_PSFBusArray[nData].szName);
			m_PSFGeneratorArray[i].nBusIndex=nData;
			m_BusNobnArray[nData].nGeneratorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ������ҽ�ĸ����ĸ�߱��в�����: %d\n",m_PSFGeneratorArray[i].nBusNumber);
	}

	for (i=0; i<(int)m_PSFLoadArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFLoadArray[i].nBusNumber);
		if (nData >= 0)
		{
			strcpy(m_PSFLoadArray[i].szBusName, m_PSFBusArray[nData].szName);
			m_PSFLoadArray[i].nBusIndex=nData;
			m_BusNobnArray[nData].nLoadArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ���ɹҽ�ĸ����ĸ�߱��в�����: %d\n",m_PSFLoadArray[i].nBusNumber);
	}

	for (i=0; i<(int)m_PSFFixedShuntArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFFixedShuntArray[i].nBusNumber);
		if (nData >= 0)
		{
			strcpy(m_PSFFixedShuntArray[i].szBusName, m_PSFBusArray[nData].szName);
			m_PSFFixedShuntArray[i].nBusIndex=nData;
			m_BusNobnArray[nData].nFixedShuntArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �̶������ҽ�ĸ����ĸ�߱��в�����: %d\n",m_PSFFixedShuntArray[i].nBusNumber);
	}

	for (i=0; i<(int)m_PSFSwitchableShuntArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFSwitchableShuntArray[i].nBusNumber);
		if (nData >= 0)
		{
			strcpy(m_PSFSwitchableShuntArray[i].szBusName, m_PSFBusArray[nData].szName);
			m_PSFSwitchableShuntArray[i].nBusIndex=nData;
			m_BusNobnArray[nData].nSwitchableShuntArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �ɵ������ҽ�ĸ����ĸ�߱��в�����: %d\n",m_PSFSwitchableShuntArray[i].nBusNumber);
	}

	for (i=0; i<(int)m_PSFLineArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFLineArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSFLineArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSFLineArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nLineArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ��·���ĸ����ĸ�߱��в�����: %d\n",m_PSFLineArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFLineArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSFLineArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSFLineArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nLineArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ��·�յ�ĸ����ĸ�߱��в�����: %d\n",m_PSFLineArray[i].nBus2Number);
	}

	for (i=0; i<(int)m_PSFFixedTranArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFFixedTranArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSFFixedTranArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSFFixedTranArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nFixedTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �̶���ѹ�����ĸ����ĸ�߱��в�����: %d\n",m_PSFFixedTranArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFFixedTranArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSFFixedTranArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSFFixedTranArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nFixedTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �̶���ѹ���յ�ĸ����ĸ�߱��в�����: %d\n",m_PSFFixedTranArray[i].nBus2Number);
	}

	for (i=0; i<(int)m_PSFULTCTranArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFULTCTranArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSFULTCTranArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSFULTCTranArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nULTCTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ULTC��ѹ�����ĸ����ĸ�߱��в�����: %d\n",m_PSFULTCTranArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFULTCTranArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSFULTCTranArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSFULTCTranArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nULTCTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ULTC��ѹ���յ�ĸ����ĸ�߱��в�����: %d\n",m_PSFULTCTranArray[i].nBus2Number);
	}

	for (i=0; i<(int)m_PSFFixedSeriesCompensatorArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFFixedSeriesCompensatorArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSFFixedSeriesCompensatorArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSFFixedSeriesCompensatorArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nFixedSeriesCompensatorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �̶������������ĸ����ĸ�߱��в�����: %d\n",m_PSFFixedSeriesCompensatorArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFFixedSeriesCompensatorArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSFFixedSeriesCompensatorArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSFFixedSeriesCompensatorArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nFixedSeriesCompensatorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �̶����������յ�ĸ����ĸ�߱��в�����: %d\n",m_PSFFixedSeriesCompensatorArray[i].nBus2Number);
	}

	for (i=0; i<(int)m_PSFSwitchableSeriesCompensatorArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFSwitchableSeriesCompensatorArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSFSwitchableSeriesCompensatorArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSFSwitchableSeriesCompensatorArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nSwitchableSeriesCompensatorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �ɵ������������ĸ����ĸ�߱��в�����: %d\n",m_PSFSwitchableSeriesCompensatorArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFSwitchableSeriesCompensatorArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSFSwitchableSeriesCompensatorArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSFSwitchableSeriesCompensatorArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nSwitchableSeriesCompensatorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint �ɵ����������յ�ĸ����ĸ�߱��в�����: %d\n",m_PSFSwitchableSeriesCompensatorArray[i].nBus2Number);
	}

	for (i=0; i<(int)m_PSFStaticTapChangerPhaseRegulatorArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSFStaticTapChangerPhaseRegulatorArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nStaticTapChangerPhaseRegulatorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ��ѹ���������ĸ����ĸ�߱��в�����: %d\n",m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSFStaticTapChangerPhaseRegulatorArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nStaticTapChangerPhaseRegulatorArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ��ѹ�������յ�ĸ����ĸ�߱��в�����: %d\n",m_PSFStaticTapChangerPhaseRegulatorArray[i].nBus2Number);
	}

	for (i=0; i<(int)m_PSF3WindingTranArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSF3WindingTranArray[i].nBus1Number);
		if (nData >= 0)
		{
			strcpy(m_PSF3WindingTranArray[i].szBus1Name, m_PSFBusArray[nData].szName);
			m_PSF3WindingTranArray[i].nBus1Index=nData;
			m_BusNobnArray[nData].nPSF3WindingTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ������һ�β�ĸ����ĸ�߱��в�����: %d\n",m_PSF3WindingTranArray[i].nBus1Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSF3WindingTranArray[i].nBus2Number);
		if (nData >= 0)
		{
			strcpy(m_PSF3WindingTranArray[i].szBus2Name, m_PSFBusArray[nData].szName);
			m_PSF3WindingTranArray[i].nBus2Index=nData;
			m_BusNobnArray[nData].nPSF3WindingTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ��������β�ĸ����ĸ�߱��в�����: %d\n",m_PSF3WindingTranArray[i].nBus2Number);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSF3WindingTranArray[i].nBus3Number);
		if (nData >= 0)
		{
			strcpy(m_PSF3WindingTranArray[i].szBus3Name, m_PSFBusArray[nData].szName);
			m_PSF3WindingTranArray[i].nBus3Index=nData;
			m_BusNobnArray[nData].nPSF3WindingTransformerArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ���������β�ĸ����ĸ�߱��в�����: %d\n",m_PSF3WindingTranArray[i].nBus3Number);
	}

	for (i=0; i<(int)m_PSFLCConvertersArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFLCConvertersArray[i].nACBus);
		if (nData >= 0)
		{
			strcpy(m_PSFLCConvertersArray[i].szACBusName, m_PSFBusArray[nData].szName);
			m_PSFLCConvertersArray[i].nACBusIndex=nData;
			m_BusNobnArray[nData].nLineCommutatedConvertersArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint ���������������ĸ����ĸ�߱��в�����: %d\n",m_PSFLCConvertersArray[i].nACBus);
	}

	for (i=0; i<(int)m_PSFVSCArray.size(); i++)
	{
		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFVSCArray[i].nACBus1);
		if (nData >= 0)
		{
			strcpy(m_PSFVSCArray[i].szACBus1Name, m_PSFBusArray[nData].szName);
			m_PSFVSCArray[i].nACBus1Index=nData;
			m_BusNobnArray[nData].nVoltageSourcedConverterArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint VSCDC������ĸ��1��ĸ�߱��в�����: %d\n",m_PSFVSCArray[i].nACBus1);

		nData=findBusDataByBusNumber(0, m_PSFBusArray.size()-1, m_PSFVSCArray[i].nACBus2);
		if (nData >= 0)
		{
			strcpy(m_PSFVSCArray[i].szACBus2Name, m_PSFBusArray[nData].szName);
			m_PSFVSCArray[i].nACBus2Index=nData;
			m_BusNobnArray[nData].nVoltageSourcedConverterArray.push_back(i);
		}
		else
			Log("PSFAsciiMaint VSCDC������ĸ��2��ĸ�߱��в�����: %d\n",m_PSFVSCArray[i].nACBus2);
	}

	CompleteField();
	FormSubstation(0.0000);

	for (nData=0; nData<(int)m_PSFBusArray.size(); nData++)
		m_PSFBusArray[nData].bTransformerNeutral=0;
	for (nData=0; nData<(int)m_PSFBusArray.size(); nData++)
	{
		if (m_BusNobnArray[nData].nFixedTransformerArray.size() == 3 && m_BusNobnArray[nData].nLineArray.empty())
		{
			if (m_BusNobnArray[nData].nGeneratorArray.empty() && m_BusNobnArray[nData].nLoadArray.empty() && m_BusNobnArray[nData].nFixedShuntArray.empty() && m_BusNobnArray[nData].nSwitchableShuntArray.empty())
				m_PSFBusArray[nData].bTransformerNeutral=1;
		}
	}
}