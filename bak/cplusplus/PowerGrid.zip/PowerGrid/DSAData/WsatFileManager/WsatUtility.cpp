#include "stdafx.h"
#include "WsatFileManagerApp.h"
#include "../../../Common/TinyXML/tinyxml.h"

void LoadWsatCase(const char* lpszFileName)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	TiXmlElement*	pLine;
	TiXmlElement*	pElement;
	TiXmlNode*		pNode;
	tagTsatTsaDefinition	tBuf;
	tagVsatSnrDefinition	vBuf;

	TiXmlDocument doc(lpszFileName);
	if (!doc.LoadFile())
		return;

	TiXmlElement* pRoot = doc.RootElement();
	if (stricmp(pRoot->Value(), "WsatCaseDefinition") != 0)
	{
		doc.Clear();
		return;
	}

	g_WsatDefinition.strWsatDesp.clear();
	g_WsatDefinition.strWRawFile.clear();
	g_WsatDefinition.strWItfFile.clear();
	g_WsatDefinition.strDynFileArray.clear();
	g_WsatDefinition.TsatTsaArray.clear();
	g_WsatDefinition.VsatSnrArray.clear();

	// Traverse children of pRoot, populating the list of lines
	pLine = pRoot->FirstChildElement();
	while (pLine != NULL)
	{
		if (stricmp(pLine->Value(),"WsatDesp") == 0)
		{
			pNode = pLine->FirstChild();
			if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				g_WsatDefinition.strWsatDesp=pNode->Value();
		}
		else if (stricmp(pLine->Value(),"WRawFile") == 0)
		{
			pNode = pLine->FirstChild();
			if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				g_WsatDefinition.strWRawFile=pNode->Value();
		}
		else if (stricmp(pLine->Value(),"WItfFile") == 0)
		{
			pNode = pLine->FirstChild();
			if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				g_WsatDefinition.strWItfFile=pNode->Value();
		}
		else if (stricmp(pLine->Value(),"WDynFile") == 0)
		{
			pNode = pLine->FirstChild();
			if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				g_WsatDefinition.strDynFileArray.push_back(pNode->Value());
		}
		else if (stricmp(pLine->Value(),"TsatTsa") == 0)
		{
			tBuf.strTsaName.clear();
			tBuf.strTPrmFile.clear();
			tBuf.strTCrtFile.clear();
			tBuf.strTTrfFile.clear();
			tBuf.strTSwtFile.clear();
			tBuf.strTMonFile.clear();
			tBuf.strTGccFile.clear();
			tBuf.bBaseCase=0;

			pElement = pLine->FirstChildElement();
			while (pElement != NULL)
			{
				pNode = pElement->FirstChild();
				if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				{
					if (stricmp(pElement->Value(),"TsaName") == 0)			{	tBuf.strTsaName=pNode->Value();			}
					else if (stricmp(pElement->Value(),"TPrmFile") == 0)	{	tBuf.strTPrmFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"TCrtFile") == 0)	{	tBuf.strTCrtFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"TTrfFile") == 0)	{	tBuf.strTTrfFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"TSwtFile") == 0)	{	tBuf.strTSwtFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"TMonFile") == 0)	{	tBuf.strTMonFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"TGccFile") == 0)	{	tBuf.strTGccFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"TBaseCase") == 0)	{	tBuf.bBaseCase=atoi(pNode->Value());	}
				}
				pElement = pElement->NextSiblingElement();
			}
			g_WsatDefinition.TsatTsaArray.push_back(tBuf);
		}
		else if (stricmp(pLine->Value(),"VsatSnr") == 0)
		{
			vBuf.strSnrName.clear();
			vBuf.strVPrmFile.clear();
			vBuf.strVCrtFile.clear();
			vBuf.strVTrfFile.clear();
			vBuf.strVCtgFile.clear();
			vBuf.strVMonFile.clear();
			vBuf.strVSpsFile.clear();
			vBuf.strVGccFile.clear();
			vBuf.strVGvrFile.clear();
			vBuf.strVAgcFile.clear();
			vBuf.strVMdpFile.clear();
			vBuf.strVCmfFile.clear();
			vBuf.bBaseCase=0;

			pElement = pLine->FirstChildElement();
			while (pElement != NULL)
			{
				pNode = pElement->FirstChild();
				if (pNode && pNode->Type() == TiXmlNode::TINYXML_TEXT)
				{
					if (stricmp(pElement->Value(),"SnrName") == 0)			{	vBuf.strSnrName=pNode->Value();			}
					else if (stricmp(pElement->Value(),"VPrmFile") == 0)	{	vBuf.strVPrmFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VCrtFile") == 0)	{	vBuf.strVCrtFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VTrfFile") == 0)	{	vBuf.strVTrfFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VCtgFile") == 0)	{	vBuf.strVCtgFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VMonFile") == 0)	{	vBuf.strVMonFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VSpsFile") == 0)	{	vBuf.strVSpsFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VGccFile") == 0)	{	vBuf.strVGccFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VGvrFile") == 0)	{	vBuf.strVGvrFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VAgcFile") == 0)	{	vBuf.strVAgcFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VMdpFile") == 0)	{	vBuf.strVMdpFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VCmfFile") == 0)	{	vBuf.strVCmfFile=pNode->Value();		}
					else if (stricmp(pElement->Value(),"VBaseCase") == 0)	{	vBuf.bBaseCase=atoi(pNode->Value());	}
				}
				pElement = pElement->NextSiblingElement();
			}
			g_WsatDefinition.VsatSnrArray.push_back(vBuf);
		}
		pLine = pLine->NextSiblingElement();
	}

	doc.Clear();
}

void SaveWsatCase(const char* lpszFileName)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int		i;
	TiXmlDeclaration*	pDeclare;
	TiXmlDocument*		pDocument;
	TiXmlElement*		pRootElement;
	TiXmlElement*		pSecElement;
	TiXmlElement*		pAttrElement;
	char				szBuf[260];

	pDocument = new TiXmlDocument();								//����һ��XML���ĵ�����

	pDeclare = new TiXmlDeclaration("1.0","gb2312","no");
	pDocument->LinkEndChild(pDeclare);

	pRootElement = new TiXmlElement("WsatCaseDefinition");			//����һ����Ԫ�ز����ӡ�
	pDocument->LinkEndChild(pRootElement);

	pSecElement = new TiXmlElement("WsatDesp");	pSecElement->LinkEndChild(new TiXmlText(g_WsatDefinition.strWsatDesp.c_str()));	pRootElement->LinkEndChild(pSecElement);
	pSecElement = new TiXmlElement("WRawFile");	pSecElement->LinkEndChild(new TiXmlText(g_WsatDefinition.strWRawFile.c_str()));	pRootElement->LinkEndChild(pSecElement);
	pSecElement = new TiXmlElement("WItfFile");	pSecElement->LinkEndChild(new TiXmlText(g_WsatDefinition.strWItfFile.c_str()));	pRootElement->LinkEndChild(pSecElement);

	for (i=0; i<(int)g_WsatDefinition.strDynFileArray.size(); i++)
	{
		pSecElement = new TiXmlElement("WDynFile");	pSecElement->LinkEndChild(new TiXmlText(g_WsatDefinition.strDynFileArray[i].c_str()));	pRootElement->LinkEndChild(pSecElement);
	}

	for (i=0; i<(int)g_WsatDefinition.TsatTsaArray.size(); i++)
	{
		pSecElement = new TiXmlElement("TsatTsa");					//BusReli Section
		pRootElement->LinkEndChild(pSecElement);

		pAttrElement = new TiXmlElement("TsaName");		pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTsaName.c_str()));		pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TPrmFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTPrmFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TCrtFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTCrtFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TTrfFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTTrfFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TSwtFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTSwtFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TMonFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTMonFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TGccFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.TsatTsaArray[i].strTGccFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("TBaseCase");	sprintf(szBuf,"%d",g_WsatDefinition.TsatTsaArray[i].bBaseCase);	pAttrElement->LinkEndChild(new TiXmlText(szBuf));	pSecElement->LinkEndChild(pAttrElement);
	}

	for (i=0; i<(int)g_WsatDefinition.VsatSnrArray.size(); i++)
	{
		pSecElement = new TiXmlElement("VsatSnr");					//BusReli Section
		pRootElement->LinkEndChild(pSecElement);

		pAttrElement = new TiXmlElement("SnrName");		pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strSnrName.c_str()));		pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VPrmFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVPrmFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VCrtFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVCrtFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VTrfFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVTrfFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VCtgFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVCtgFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VMonFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVMonFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VSpsFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVSpsFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VGccFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVGccFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VGvrFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVGvrFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VAgcFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVAgcFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VMdpFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVMdpFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VCmfFile");	pAttrElement->LinkEndChild(new TiXmlText(g_WsatDefinition.VsatSnrArray[i].strVCmfFile.c_str()));	pSecElement->LinkEndChild(pAttrElement);
		pAttrElement = new TiXmlElement("VBaseCase");	sprintf(szBuf,"%d",g_WsatDefinition.VsatSnrArray[i].bBaseCase);	pAttrElement->LinkEndChild(new TiXmlText(szBuf));	pSecElement->LinkEndChild(pAttrElement);
	}

	pDocument->SaveFile(lpszFileName);					//���浽�ļ�

	pDocument->Clear();
	delete pDocument;
}

int AmendFileName(std::string& strFileName)
{
	register int	i;

	if (strFileName.empty())
		return 0;

	if (access(strFileName.c_str(), 0) != 0)
	{
		PrintMessage("�ļ� ��%s�� ������",strFileName.c_str());
		return 0;
	}

	for (i=0; i<(int)strFileName.length(); i++)
	{
		if (strFileName[i] == '\\')
		{
			strFileName[i]='/';
		}
	}
	return 1;
}

void TrimName(char* lpszName)
{
	register int	i;
	int		nChar;
	char	szChar[260];

	nChar=0;
	memset(szChar, 0, 260);
	for (i=0; i<(int)strlen(lpszName); i++)
	{
		if (lpszName[i] == ' ')
		{
		}
		else
		{
			szChar[nChar++]=lpszName[i];
		}
	}
	szChar[nChar++]='\0';
	strcpy(lpszName, szChar);
}

int PrepareWsatCaseForm(const char* lpszDateTime, const char* lpszDestDir)
{
	register int	i;
	int				nFile;
	unsigned char	bExist;

	if (strlen(lpszDestDir) <= 0)
	{
		PrintMessage("����Ŀ¼Ϊ��");
		return 0;
	}
	if (access(lpszDestDir,0) != 0)
	{
		PrintMessage("����Ŀ¼ ��%s�� ������",lpszDestDir);
		return 0;
	}
	if (g_WsatDefinition.TsatTsaArray.empty() && g_WsatDefinition.VsatSnrArray.empty())
	{
		PrintMessage("TSAT �� VSAT ���㳡��ȫ��");
		return 0;
	}

	std::vector<std::string>	strFileArray;
	strFileArray.clear();

	if (!AmendFileName(g_WsatDefinition.strWRawFile))
		return 0;
	bExist=0;
	for (i=0; i<(int)strFileArray.size(); i++)
	{
		if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.strWRawFile.c_str()) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		strFileArray.push_back(g_WsatDefinition.strWRawFile.c_str());

	if (!AmendFileName(g_WsatDefinition.strWItfFile))
		return 0;
	bExist=0;
	for (i=0; i<(int)strFileArray.size(); i++)
	{
		if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.strWItfFile.c_str()) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		strFileArray.push_back(g_WsatDefinition.strWItfFile.c_str());

	for (nFile=0; nFile<(int)g_WsatDefinition.strDynFileArray.size(); nFile++)
	{
		if (!AmendFileName(g_WsatDefinition.strDynFileArray[nFile]))
			return 0;
		bExist=0;
		for (i=0; i<(int)strFileArray.size(); i++)
		{
			if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.strDynFileArray[nFile].c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strFileArray.push_back(g_WsatDefinition.strDynFileArray[nFile].c_str());
	}

	for (nFile=0; nFile<(int)g_WsatDefinition.TsatTsaArray.size(); nFile++)
	{
		if (!g_WsatDefinition.TsatTsaArray[nFile].strTPrmFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.TsatTsaArray[nFile].strTPrmFile))
				return 0;

			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.TsatTsaArray[nFile].strTPrmFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.TsatTsaArray[nFile].strTPrmFile.c_str());
		}

		if (!g_WsatDefinition.TsatTsaArray[nFile].strTCrtFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.TsatTsaArray[nFile].strTCrtFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.TsatTsaArray[nFile].strTCrtFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.TsatTsaArray[nFile].strTCrtFile.c_str());
		}

		if (!g_WsatDefinition.TsatTsaArray[nFile].strTTrfFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.TsatTsaArray[nFile].strTTrfFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.TsatTsaArray[nFile].strTTrfFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.TsatTsaArray[nFile].strTTrfFile.c_str());
		}

		if (!AmendFileName(g_WsatDefinition.TsatTsaArray[nFile].strTSwtFile))
			return 0;
		bExist=0;
		for (i=0; i<(int)strFileArray.size(); i++)
		{
			if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.TsatTsaArray[nFile].strTSwtFile.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strFileArray.push_back(g_WsatDefinition.TsatTsaArray[nFile].strTSwtFile.c_str());

		if (!AmendFileName(g_WsatDefinition.TsatTsaArray[nFile].strTMonFile))
			return 0;
		bExist=0;
		for (i=0; i<(int)strFileArray.size(); i++)
		{
			if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.TsatTsaArray[nFile].strTMonFile.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strFileArray.push_back(g_WsatDefinition.TsatTsaArray[nFile].strTMonFile.c_str());

		if (!g_WsatDefinition.TsatTsaArray[nFile].strTGccFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.TsatTsaArray[nFile].strTGccFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.TsatTsaArray[nFile].strTGccFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.TsatTsaArray[nFile].strTGccFile.c_str());
		}
	}

	for (nFile=0; nFile<(int)g_WsatDefinition.VsatSnrArray.size(); nFile++)
	{
		if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVPrmFile))
			return 0;
		bExist=0;
		for (i=0; i<(int)strFileArray.size(); i++)
		{
			if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVPrmFile.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVPrmFile.c_str());

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVCrtFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVCrtFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVCrtFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVCrtFile.c_str());
		}

		if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVTrfFile))
			return 0;
		bExist=0;
		for (i=0; i<(int)strFileArray.size(); i++)
		{
			if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVTrfFile.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVTrfFile.c_str());

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVCtgFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVCtgFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVCtgFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVCtgFile.c_str());
		}

		if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVMonFile))
			return 0;
		bExist=0;
		for (i=0; i<(int)strFileArray.size(); i++)
		{
			if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVMonFile.c_str()) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVMonFile.c_str());

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVSpsFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVSpsFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVSpsFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVSpsFile.c_str());
		}

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVGccFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVGccFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVGccFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVGccFile.c_str());
		}

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVGvrFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVGvrFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVGvrFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVGvrFile.c_str());
		}

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVAgcFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVAgcFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVAgcFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVAgcFile.c_str());
		}

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVMdpFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVMdpFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVMdpFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVMdpFile.c_str());
		}

		if (!g_WsatDefinition.VsatSnrArray[nFile].strVCmfFile.empty())
		{
			if (!AmendFileName(g_WsatDefinition.VsatSnrArray[nFile].strVCmfFile))
				return 0;
			bExist=0;
			for (i=0; i<(int)strFileArray.size(); i++)
			{
				if (stricmp(strFileArray[i].c_str(), g_WsatDefinition.VsatSnrArray[nFile].strVCmfFile.c_str()) == 0)
				{
					bExist=1;
					break;
				}
			}
			if (!bExist)
				strFileArray.push_back(g_WsatDefinition.VsatSnrArray[nFile].strVCmfFile.c_str());
		}
	}

	char	szDrive[_MAX_DRIVE];
	char	szDir[_MAX_DIR];
	char	szFname[_MAX_FNAME];
	char	szExt[_MAX_EXT];
	char	szWsatBuffer[260];
	for (nFile=0; nFile<(int)strFileArray.size(); nFile++)
	{
		_splitpath(strFileArray[nFile].c_str(), szDrive, szDir, szFname, szExt );
		sprintf(szWsatBuffer,"%s/%s-%s%s",lpszDestDir, lpszDateTime, szFname, szExt);
		CopyFile(strFileArray[nFile].c_str(), szWsatBuffer, FALSE);
	}

	return 1;
}

void FormTsatScenario(const int nTsat, const char* lpszDateTime, const char* lpszDestDir, const char* lpszScenario)
{
	char szDrive[_MAX_DRIVE];
	char szDir[_MAX_DIR];
	char szFname[_MAX_FNAME];
	char szExt[_MAX_EXT];

	int		nFile;
	char	szWsatBuffer[260];
	FILE*	fp;

	sprintf(szWsatBuffer,"%s/%s-%s.tsa",lpszDestDir,lpszDateTime,lpszScenario);
	fp=fopen(szWsatBuffer, "w");
	if (fp == NULL)
		return;

	fprintf(fp,"[TSAT 8.0]\n\n");
	fprintf(fp,"[Scenario]\n\n");

	fprintf(fp,"{Scenario Description}\n");
	fprintf(fp,"Title = %s\n",lpszScenario);
	fprintf(fp,"{End Scenario Description}\n\n");

	fprintf(fp,"{Scenario Parameters}\n");
	fprintf(fp,"Common frequency base = 50.000000\n");
	fprintf(fp,"Threshold value of zero impedance line= 0.00015\n");
	fprintf(fp,"{End Scenario Parameters}\n\n");

	fprintf(fp,"{Dynamic data}\n");
	fprintf(fp,"Format = BPA\n");
	for (nFile=0; nFile<(int)g_WsatDefinition.strDynFileArray.size(); nFile++)
	{
		_splitpath(g_WsatDefinition.strDynFileArray[nFile].c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	fprintf(fp,"{End Dynamic data}\n\n");

	fprintf(fp,"{Monitor data}\n");
	fprintf(fp,"Name Option = 1\n");
	_splitpath(g_WsatDefinition.TsatTsaArray[nTsat].strTMonFile.c_str(), szDrive, szDir, szFname, szExt );
	fprintf(fp,"File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	fprintf(fp,"{End Monitor data}\n\n");

	fprintf(fp,"{Switching data}\n");
	fprintf(fp,"Name Option = 1\n");
	_splitpath(g_WsatDefinition.TsatTsaArray[nTsat].strTSwtFile.c_str(), szDrive, szDir, szFname, szExt );
	fprintf(fp,"File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	fprintf(fp,"{End Switching data}\n\n");

	fprintf(fp,"{Criteria data}\n");
	fprintf(fp,"Name Option = 1\n");
	if (!g_WsatDefinition.TsatTsaArray[nTsat].strTCrtFile.empty())
	{
		_splitpath(g_WsatDefinition.TsatTsaArray[nTsat].strTCrtFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"File = \n");
	}
	fprintf(fp,"{End Criteria data}\n\n");


	fprintf(fp,"{Transaction data}\n");
	fprintf(fp,"Name Option = 1\n");
	if (!g_WsatDefinition.TsatTsaArray[nTsat].strTTrfFile.empty())
	{
		_splitpath(g_WsatDefinition.TsatTsaArray[nTsat].strTTrfFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Transfer File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Transfer File = \n");
	}

	if (!g_WsatDefinition.TsatTsaArray[nTsat].strTPrmFile.empty())
	{
		_splitpath(g_WsatDefinition.TsatTsaArray[nTsat].strTPrmFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Parameter File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Parameter File = \n");
	}

	if (!g_WsatDefinition.strWItfFile.empty())
	{
		_splitpath(g_WsatDefinition.strWItfFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Interface And Circuit File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Interface And Circuit File = \n");
	}

	if (!g_WsatDefinition.TsatTsaArray[nTsat].strTGccFile.empty())
	{
		_splitpath(g_WsatDefinition.TsatTsaArray[nTsat].strTGccFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Generator Capability File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Generator Capability File = \n");
	}

	fprintf(fp,"{End Transaction data}\n\n");

	fprintf(fp,"[End Scenario]\n");

	fflush(fp);
	fclose(fp);
}

void	FormVsatScenario(const int nVsat, const int nBaseVsat, const char* lpszDateTime, const char* lpszDestDir, const char* lpszScenario)
{
	char szDrive[_MAX_DRIVE];
	char szDir[_MAX_DIR];
	char szFname[_MAX_FNAME];
	char szExt[_MAX_EXT];

	char	szWsatBuffer[260];
	FILE*	fp;

	sprintf(szWsatBuffer,"%s/%s-%s.snr",lpszDestDir,lpszDateTime,lpszScenario);
	fp=fopen(szWsatBuffer, "w");
	if (fp == NULL)
		return;

	fprintf(fp,"[VSAT 5.x Scenario]\n\n");

	fprintf(fp,"{Description}\n");
	fprintf(fp,"%s\n",lpszScenario);
	fprintf(fp,"{End Description}\n\n");

	if (!g_WsatDefinition.VsatSnrArray[nVsat].strVPrmFile.empty())
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nVsat].strVPrmFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Parameter File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		if (!g_WsatDefinition.VsatSnrArray[nBaseVsat].strVPrmFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[nBaseVsat].strVPrmFile.c_str(), szDrive, szDir, szFname, szExt );
			fprintf(fp,"Parameter File = %s-%s%s\n",lpszDateTime, szFname, szExt);
		}
		else
		{
			fprintf(fp,"Parameter File = \n");
		}
	}

	if (!g_WsatDefinition.VsatSnrArray[nVsat].strVTrfFile.empty())
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nVsat].strVTrfFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Transfer File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Transfer File = \n");
	}

	if (!g_WsatDefinition.VsatSnrArray[nVsat].strVCrtFile.empty())
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nVsat].strVCrtFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Criteria File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Criteria File = \n");
	}

	if (!g_WsatDefinition.VsatSnrArray[nVsat].strVMonFile.empty())
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nVsat].strVMonFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Monitored Variable File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Monitored Variable File = \n");
	}

	if (!g_WsatDefinition.VsatSnrArray[nVsat].strVCtgFile.empty())
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nVsat].strVCtgFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Contingency File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Contingency File = \n");
	}

	if (!g_WsatDefinition.strWItfFile.empty())
	{
		_splitpath(g_WsatDefinition.strWItfFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Interface and Circuit File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Interface and Circuit File = \n");
	}

	if (!g_WsatDefinition.VsatSnrArray[nVsat].strVGccFile.empty())
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nVsat].strVGccFile.c_str(), szDrive, szDir, szFname, szExt );
		fprintf(fp,"Generator Capability File = %s-%s%s\n",lpszDateTime, szFname, szExt);
	}
	else
	{
		fprintf(fp,"Generator Capability File = \n");
	}

	fprintf(fp,"\n[End]\n");

	fflush(fp);
	fclose(fp);
}

void	FormWsatCaseFiles(const char* lpszDateTime, const char* lpszDestDir)
{
	char szDrive[_MAX_DRIVE];
	char szDir[_MAX_DIR];
	char szFname[_MAX_FNAME];
	char szExt[_MAX_EXT];

	int		nFile, nBaseVsat, nBaseTsat, nScenarioNum;
	char	szWsatBuffer[260];
	FILE*	fp;

	sprintf(szWsatBuffer,"%s/%s.wsat",lpszDestDir,lpszDateTime);
	fp=fopen(szWsatBuffer, "w");
	if (fp == NULL)
		return;

	fprintf(fp,"[WSAT 13.0 CASE DEFINITION]\n\n");

	fprintf(fp,"{Description}\n");
	fprintf(fp,"%s\n",g_WsatDefinition.strWsatDesp.c_str());
	fprintf(fp,"{End description}\n\n");

	nBaseVsat=nBaseTsat=-1;
	if (!g_WsatDefinition.TsatTsaArray.empty())
	{
		fprintf(fp,"{TSAT Basecase Scenario}\n");
		for (nFile=0; nFile<(int)g_WsatDefinition.TsatTsaArray.size(); nFile++)
		{
			if (g_WsatDefinition.TsatTsaArray[nFile].bBaseCase)
			{
				nBaseTsat=nFile;
				break;
			}
		}
		fprintf(fp,"{End TSAT Basecase Scenario}\n\n");
	}

	if (!g_WsatDefinition.VsatSnrArray.empty())
	{
		fprintf(fp,"{VSAT Basecase Scenario}\n");
		for (nFile=0; nFile<(int)g_WsatDefinition.VsatSnrArray.size(); nFile++)
		{
			if (g_WsatDefinition.VsatSnrArray[nFile].bBaseCase)
			{
				nBaseVsat=nFile;
				break;
			}
		}
		fprintf(fp,"{End VSAT Basecase Scenario}\n\n");
	}

	if (nBaseVsat >= 0)
	{
		_splitpath(g_WsatDefinition.VsatSnrArray[nBaseVsat].strVPrmFile.c_str(), szDrive, szDir, szFname, szExt );
		sprintf(szWsatBuffer,"%s-%s%s",lpszDateTime, szFname, szExt);
		fprintf(fp,"Basecase Powerflow Solution Parameters = %s\n\n",szWsatBuffer);
	}

	if (nBaseTsat >= 0)
	{
		fprintf(fp,"{TSAT Basecase Scenario}\n");

		strcpy(szWsatBuffer, g_WsatDefinition.TsatTsaArray[nBaseTsat].strTsaName.c_str());
		TrimName(szWsatBuffer);
		fprintf(fp,"%s-%s.tsa\n",lpszDateTime,szWsatBuffer);
		FormTsatScenario(nBaseTsat, lpszDateTime, lpszDestDir, szWsatBuffer);

		fprintf(fp,"{End TSAT Basecase Scenario}\n\n");
	}

	if (nBaseVsat >= 0)
	{
		fprintf(fp,"{VSAT Basecase Scenario}\n");

		strcpy(szWsatBuffer, g_WsatDefinition.VsatSnrArray[nBaseVsat].strSnrName.c_str());
		TrimName(szWsatBuffer);
		fprintf(fp,"%s-%s.snr\n",lpszDateTime,szWsatBuffer);
		FormVsatScenario(nBaseTsat, nBaseVsat, lpszDateTime, lpszDestDir, szWsatBuffer);

		fprintf(fp,"{End VSAT Basecase Scenario}\n\n");
	}

	nScenarioNum=0;
	for (nFile=0; nFile<(int)g_WsatDefinition.TsatTsaArray.size(); nFile++)
	{
		if (g_WsatDefinition.TsatTsaArray[nFile].bBaseCase)
			continue;

		nScenarioNum++;
	}
	if (nScenarioNum > 0)
	{
		fprintf(fp,"{TSAT Transfer Scenario}\n");
		for (nFile=0; nFile<(int)g_WsatDefinition.TsatTsaArray.size(); nFile++)
		{
			if (g_WsatDefinition.TsatTsaArray[nFile].bBaseCase)
				continue;

			strcpy(szWsatBuffer, g_WsatDefinition.TsatTsaArray[nFile].strTsaName.c_str());
			TrimName(szWsatBuffer);
			fprintf(fp,"%s-%s.tsa\n",lpszDateTime,szWsatBuffer);
			FormTsatScenario(nFile, lpszDateTime, lpszDestDir, szWsatBuffer);
		}
		fprintf(fp,"{End TSAT Transfer Scenario}\n\n");
	}

	nScenarioNum=0;
	for (nFile=0; nFile<(int)g_WsatDefinition.VsatSnrArray.size(); nFile++)
	{
		if (g_WsatDefinition.VsatSnrArray[nFile].bBaseCase)
			continue;

		nScenarioNum++;
	}
	if (nScenarioNum > 0)
	{
		fprintf(fp,"{VSAT Transfer Scenario}\n");
		for (nFile=0; nFile<(int)g_WsatDefinition.VsatSnrArray.size(); nFile++)
		{
			if (g_WsatDefinition.VsatSnrArray[nFile].bBaseCase)
				continue;

			strcpy(szWsatBuffer, g_WsatDefinition.VsatSnrArray[nFile].strSnrName.c_str());
			TrimName(szWsatBuffer);
			fprintf(fp,"%s-%s.snr\n",lpszDateTime,szWsatBuffer);
			FormVsatScenario(nFile, nBaseVsat, lpszDateTime, lpszDestDir, szWsatBuffer);
		}
		fprintf(fp,"{End VSAT Transfer Scenario}\n\n");
	}

	fprintf(fp,"[END]\n");

	fflush(fp);
	fclose(fp);
}

void FormWsatNormalCase(const char* lpszDestDir)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	time_t		now;
	struct tm	when;
	time(&now);
	when = *localtime( &now );

	char	szDateTime[260];
	sprintf(szDateTime,"%.4d-%.2d-%.2d-%.2d-%.2d-%.2d-CST",when.tm_year+1900,when.tm_mon+1,when.tm_mday,when.tm_hour,when.tm_min,when.tm_sec);

	if (!PrepareWsatCaseForm(szDateTime, lpszDestDir))
		return;

	FormWsatCaseFiles(szDateTime, lpszDestDir);

	FILE*	fp;
	char	szWsatBuffer[260];

	sprintf(szWsatBuffer,"%s/%s-Run.trg",lpszDestDir,szDateTime);
	fp=fopen(szWsatBuffer, "w");
	fflush(fp);
	fclose(fp);
	PrintMessage("%s Wsat �����������",szDateTime);
}

void FormWsatEmergencyCase(const char* lpszDestDir)
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	time_t		now;
	struct tm	when;
	time(&now);
	when = *localtime( &now );

	char	szDateTime[260];
	sprintf(szDateTime,"%.4d-%.2d-%.2d-%.2d-%.2d-%.2d-CST",when.tm_year+1900,when.tm_mon+1,when.tm_mday,when.tm_hour,when.tm_min,when.tm_sec);

	if (!PrepareWsatCaseForm(szDateTime, lpszDestDir))
		return;

	FormWsatCaseFiles(szDateTime, lpszDestDir);

	FILE*	fp;
	char	szWsatBuffer[260];

	sprintf(szWsatBuffer,"%s/%s-Run-Emergency.trg",lpszDestDir,szDateTime);
	fp=fopen(szWsatBuffer, "w");
	fflush(fp);
	fclose(fp);
	PrintMessage("%s Wsat ���������������",szDateTime);
}
