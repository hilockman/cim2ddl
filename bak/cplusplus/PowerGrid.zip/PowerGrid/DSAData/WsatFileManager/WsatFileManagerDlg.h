
// WsatFileManagerDlg.h : ͷ�ļ�
//

#pragma once
#include "VsatSnrDefineDialog.h"
#include "TsatTsaDefineDialog.h"


// CWsatFileManagerDlg �Ի���
class CWsatFileManagerDlg : public CDialog
{
// ����
public:
	CWsatFileManagerDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_WSATFILEMANAGER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnEnChangeWsatDesp();
	afx_msg void OnBnClickedRawBrowse();
	afx_msg void OnBnClickedItfBrowse();
	afx_msg void OnBnClickedDynAdd();
	afx_msg void OnBnClickedDynDel();
	afx_msg void OnBnClickedLoadCase();
	afx_msg void OnBnClickedSaveCase();
	afx_msg void OnBnClickedDestDirBrowse();
	afx_msg void OnBnClickedFormNormalCase();
	afx_msg void OnBnClickedFormEmergencyCase();
	afx_msg	LRESULT	OnMessage(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	CMFCTabCtrl				m_wndTab;
	CTsatTsaDefineDialog	m_wndTsatTsa;
	CVsatSnrDefineDialog	m_wndVsatSnr;
	CString					m_strWsatDestFolder;

private:
	void	RefreshUI();
};
