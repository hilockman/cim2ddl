#pragma once
#include "afxcmn.h"
//#include "../../../Common/ListCtrlEx/ListCtrlEx.h"
//using namespace ListCtrlEx;

// CTsatTsaDefineDialog �Ի���

class CTsatTsaDefineDialog : public CDialog
{
	DECLARE_DYNAMIC(CTsatTsaDefineDialog)

public:
	CTsatTsaDefineDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CTsatTsaDefineDialog();

public:
	void	RefreshTsaList();
// �Ի�������
	enum { IDD = IDD_TSATFILE_DEFINE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedTprmBrowse();
	afx_msg void OnBnClickedTcrtBrowse();
	afx_msg void OnBnClickedTtrfBrowse();
	afx_msg void OnBnClickedTswtBrowse();
	afx_msg void OnBnClickedTmonBrowse();
	afx_msg void OnBnClickedTgccBrowse();
	afx_msg void OnNMClickTsatTsaList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedMod();
	afx_msg void OnBnClickedBaseCase();
	DECLARE_MESSAGE_MAP()

private:
	int				m_nCurTsatTsa;
	CMFCListCtrl	m_wndTsaList;
public:
};
