// TsatTsaDefineDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WsatFileManagerApp.h"
#include "TsatTsaDefineDialog.h"


// CTsatTsaDefineDialog �Ի���

IMPLEMENT_DYNAMIC(CTsatTsaDefineDialog, CDialog)

CTsatTsaDefineDialog::CTsatTsaDefineDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CTsatTsaDefineDialog::IDD, pParent)
{
	m_nCurTsatTsa=-1;
}

CTsatTsaDefineDialog::~CTsatTsaDefineDialog()
{
}

void CTsatTsaDefineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TSAT_TSA_LIST, m_wndTsaList);
}


BEGIN_MESSAGE_MAP(CTsatTsaDefineDialog, CDialog)
	ON_BN_CLICKED(IDC_TPRM_BROWSE, &CTsatTsaDefineDialog::OnBnClickedTprmBrowse)
	ON_BN_CLICKED(IDC_TCRT_BROWSE, &CTsatTsaDefineDialog::OnBnClickedTcrtBrowse)
	ON_BN_CLICKED(IDC_TTRF_BROWSE, &CTsatTsaDefineDialog::OnBnClickedTtrfBrowse)
	ON_BN_CLICKED(IDC_TSWT_BROWSE, &CTsatTsaDefineDialog::OnBnClickedTswtBrowse)
	ON_BN_CLICKED(IDC_TMON_BROWSE, &CTsatTsaDefineDialog::OnBnClickedTmonBrowse)
	ON_NOTIFY(NM_CLICK, IDC_TSAT_TSA_LIST, &CTsatTsaDefineDialog::OnNMClickTsatTsaList)
	ON_BN_CLICKED(IDC_ADD, &CTsatTsaDefineDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CTsatTsaDefineDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_MOD, &CTsatTsaDefineDialog::OnBnClickedMod)
	ON_BN_CLICKED(IDC_BASE_CASE, &CTsatTsaDefineDialog::OnBnClickedBaseCase)
	ON_BN_CLICKED(IDC_TGCC_BROWSE, &CTsatTsaDefineDialog::OnBnClickedTgccBrowse)
END_MESSAGE_MAP()


// CTsatTsaDefineDialog ��Ϣ��������

BOOL CTsatTsaDefineDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int			nColumn;

	m_wndTsaList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndTsaList.SetExtendedStyle(m_wndTsaList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndTsaList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndTsaList.InsertColumn(0, "���");
	for (nColumn=0; nColumn<sizeof(g_lpszTsatTsaColumn)/sizeof(char*); nColumn++)
		m_wndTsaList.InsertColumn(nColumn+1, g_lpszTsatTsaColumn[nColumn]);

// 	m_wndTsaList.InsertColumn(0, "���",	100, ListCtrlEx::Normal, LVCFMT_LEFT, ListCtrlEx::SortByDigit);
// 	for (nColumn=0; nColumn<sizeof(g_lpszTsatTsaColumn)/sizeof(char*); nColumn++)
// 	{
// 		if (nColumn == 1)
// 			m_wndTsaList.InsertColumn(nColumn+1, g_lpszTsatTsaColumn[nColumn], 100, ListCtrlEx::RadioBox, LVCFMT_CENTER, ListCtrlEx::SortByString);
// 		else
// 			m_wndTsaList.InsertColumn(nColumn+1, g_lpszTsatTsaColumn[nColumn], 100, ListCtrlEx::Normal, LVCFMT_LEFT, ListCtrlEx::SortByString);
// 	}
// 	m_wndTsaList.SetSupportSort(FALSE);

	RefreshTsaList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CTsatTsaDefineDialog::RefreshTsaList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];

	m_wndTsaList.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_WsatDefinition.TsatTsaArray.size(); i++)
	{
		sprintf(szBuf,"%d",nRow+1);	m_wndTsaList.InsertItem(nRow, szBuf);

		nCol=1;

		m_wndTsaList.SetItemText(nRow, nCol++, g_WsatDefinition.TsatTsaArray[i].strTsaName.c_str());

		if (g_WsatDefinition.TsatTsaArray[i].bBaseCase)
			strcpy(szBuf,"��");
		else
			strcpy(szBuf,"��");
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (!g_WsatDefinition.TsatTsaArray[i].strTPrmFile.empty())
		{
			_splitpath(g_WsatDefinition.TsatTsaArray[i].strTPrmFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (!g_WsatDefinition.TsatTsaArray[i].strTCrtFile.empty())
		{
			_splitpath(g_WsatDefinition.TsatTsaArray[i].strTCrtFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (!g_WsatDefinition.TsatTsaArray[i].strTTrfFile.empty())
		{
			_splitpath(g_WsatDefinition.TsatTsaArray[i].strTTrfFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (!g_WsatDefinition.TsatTsaArray[i].strTSwtFile.empty())
		{
			_splitpath(g_WsatDefinition.TsatTsaArray[i].strTSwtFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (!g_WsatDefinition.TsatTsaArray[i].strTMonFile.empty())
		{
			_splitpath(g_WsatDefinition.TsatTsaArray[i].strTMonFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf,0,260);
		if (!g_WsatDefinition.TsatTsaArray[i].strTGccFile.empty())
		{
			_splitpath(g_WsatDefinition.TsatTsaArray[i].strTGccFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndTsaList.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_lpszVsatSnrColumn)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndTsaList.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndTsaList.GetColumnWidth(nCol);
		m_wndTsaList.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndTsaList.GetColumnWidth(nCol);

		m_wndTsaList.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CTsatTsaDefineDialog::OnBnClickedTprmBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="prm";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.prm)|*.prm;*.PRM|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪲����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_TPRM_FILE)->SetWindowText(dlg.GetPathName());
}

void CTsatTsaDefineDialog::OnBnClickedTcrtBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="crt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.crt)|*.crt;*.CRT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪱�׼�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_TCRT_FILE)->SetWindowText(dlg.GetPathName());
}

void CTsatTsaDefineDialog::OnBnClickedTtrfBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="trf";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.trf)|*.trf;*.TRF|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪴����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_TTRF_FILE)->SetWindowText(dlg.GetPathName());
}

void CTsatTsaDefineDialog::OnBnClickedTswtBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="swi";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.swi;*.swt)|*.swi;*.SWI;*.swt;*.SWT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪹����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_TSWT_FILE)->SetWindowText(dlg.GetPathName());
}

void CTsatTsaDefineDialog::OnBnClickedTmonBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="mon";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.mon)|*.mon;*.MON|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪼����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_TMON_FILE)->SetWindowText(dlg.GetPathName());
}

void CTsatTsaDefineDialog::OnBnClickedTgccBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="gcc";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.gcc)|*.gcc;*.GCC|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪼����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_TGCC_FILE)->SetWindowText(dlg.GetPathName());
}

void CTsatTsaDefineDialog::OnNMClickTsatTsaList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_nCurTsatTsa=pNMItemActivate->iItem;
	if (m_nCurTsatTsa >= 0 && m_nCurTsatTsa < m_wndTsaList.GetItemCount())
	{
		GetDlgItem(IDC_TSA_NAME)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTsaName.c_str());
		GetDlgItem(IDC_TPRM_FILE)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTPrmFile.c_str());
		GetDlgItem(IDC_TCRT_FILE)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTCrtFile.c_str());
		GetDlgItem(IDC_TTRF_FILE)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTTrfFile.c_str());
		GetDlgItem(IDC_TSWT_FILE)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTSwtFile.c_str());
		GetDlgItem(IDC_TMON_FILE)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTMonFile.c_str());
		GetDlgItem(IDC_TGCC_FILE)->SetWindowText(g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTGccFile.c_str());
	}
	*pResult = 0;
}

void CTsatTsaDefineDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	char			szBuf[260];
	tagTsatTsaDefinition	tBuf;

	GetDlgItem(IDC_TSA_NAME)->GetWindowText(szBuf, 260);	tBuf.strTsaName=szBuf;
	GetDlgItem(IDC_TPRM_FILE)->GetWindowText(szBuf, 260);	tBuf.strTPrmFile=szBuf;
	GetDlgItem(IDC_TCRT_FILE)->GetWindowText(szBuf, 260);	tBuf.strTCrtFile=szBuf;
	GetDlgItem(IDC_TTRF_FILE)->GetWindowText(szBuf, 260);	tBuf.strTTrfFile=szBuf;
	GetDlgItem(IDC_TSWT_FILE)->GetWindowText(szBuf, 260);	tBuf.strTSwtFile=szBuf;
	GetDlgItem(IDC_TMON_FILE)->GetWindowText(szBuf, 260);	tBuf.strTMonFile=szBuf;
	GetDlgItem(IDC_TGCC_FILE)->GetWindowText(szBuf, 260);	tBuf.strTGccFile=szBuf;
	if (g_WsatDefinition.TsatTsaArray.empty())
		tBuf.bBaseCase=1;
	else
		tBuf.bBaseCase=0;

	if (tBuf.strTsaName.empty())
	{
		AfxMessageBox("��Ϊ�����ӳ�������");
		return;
	}
	bExist=0;
	for (i=0; i<(int)g_WsatDefinition.TsatTsaArray.size(); i++)
	{
		if (stricmp(g_WsatDefinition.TsatTsaArray[i].strTsaName.c_str(), tBuf.strTsaName.c_str()) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
	{
		g_WsatDefinition.TsatTsaArray.push_back(tBuf);
		RefreshTsaList();
	}
	else
	{
		AfxMessageBox("�����ӳ����Ѿ�����");
	}
}

void CTsatTsaDefineDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nCurTsatTsa < 0 || m_nCurTsatTsa >= m_wndTsaList.GetItemCount())
		return;

	if (AfxMessageBox("��ȷ��ɾ��ѡ������?",MB_SYSTEMMODAL|MB_YESNO) == IDNO)
		return;

	g_WsatDefinition.TsatTsaArray.erase(g_WsatDefinition.TsatTsaArray.begin()+m_nCurTsatTsa);
	m_nCurTsatTsa=-1;
	RefreshTsaList();
}

void CTsatTsaDefineDialog::OnBnClickedMod()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nCurTsatTsa < 0 || m_nCurTsatTsa >= m_wndTsaList.GetItemCount())
		return;

	register int	i;
	unsigned char	bExist;
	char			szBuf[260];
	tagTsatTsaDefinition	tBuf;
	GetDlgItem(IDC_TSA_NAME)->GetWindowText(szBuf, 260);	tBuf.strTsaName=szBuf;
	GetDlgItem(IDC_TPRM_FILE)->GetWindowText(szBuf, 260);	tBuf.strTPrmFile=szBuf;
	GetDlgItem(IDC_TCRT_FILE)->GetWindowText(szBuf, 260);	tBuf.strTCrtFile=szBuf;
	GetDlgItem(IDC_TTRF_FILE)->GetWindowText(szBuf, 260);	tBuf.strTTrfFile=szBuf;
	GetDlgItem(IDC_TSWT_FILE)->GetWindowText(szBuf, 260);	tBuf.strTSwtFile=szBuf;
	GetDlgItem(IDC_TMON_FILE)->GetWindowText(szBuf, 260);	tBuf.strTMonFile=szBuf;
	GetDlgItem(IDC_TGCC_FILE)->GetWindowText(szBuf, 260);	tBuf.strTGccFile=szBuf;

	if (tBuf.strTsaName.empty())
	{
		AfxMessageBox("��Ϊ���޸ĳ�������");
		return;
	}
	bExist=0;
	for (i=0; i<(int)g_WsatDefinition.TsatTsaArray.size(); i++)
	{
		if (i == m_nCurTsatTsa)
			continue;
		if (stricmp(g_WsatDefinition.TsatTsaArray[i].strTsaName.c_str(), tBuf.strTsaName.c_str()) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
	{
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTsaName=tBuf.strTsaName;
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTPrmFile=tBuf.strTPrmFile;
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTCrtFile=tBuf.strTCrtFile;
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTTrfFile=tBuf.strTTrfFile;
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTSwtFile=tBuf.strTSwtFile;
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTMonFile=tBuf.strTMonFile;
		g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].strTGccFile=tBuf.strTGccFile;
		RefreshTsaList();
	}
	else
	{
		AfxMessageBox("���޸ĳ��������Ѿ�����");
	}
}

void CTsatTsaDefineDialog::OnBnClickedBaseCase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nCurTsatTsa < 0 || m_nCurTsatTsa >= m_wndTsaList.GetItemCount())
		return;

	register int	i;
	for (i=0; i<(int)g_WsatDefinition.TsatTsaArray.size(); i++)
		g_WsatDefinition.TsatTsaArray[i].bBaseCase=0;
	g_WsatDefinition.TsatTsaArray[m_nCurTsatTsa].bBaseCase=1;
	RefreshTsaList();
}
