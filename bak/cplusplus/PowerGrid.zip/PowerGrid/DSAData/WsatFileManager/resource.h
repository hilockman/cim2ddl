//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WsatFileManager.rc
//
#define IDD_WSATFILEMANAGER_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDD_VSATFILE_DEFINE_DIALOG      129
#define IDD_TSATFILE_DEFINE_DIALOG      130
#define IDC_WSAT_DESP                   1000
#define IDC_RAW_FILE                    1003
#define IDC_RAW_BROWSE                  1004
#define IDC_ITF_FILE                    1005
#define IDC_ITF_BROWSE                  1006
#define IDC_VSAT_SNR_LIST               1007
#define IDC_VCTG_FILE                   1008
#define IDC_VCTG_BROWSE                 1009
#define IDC_VPRM_FILE                   1010
#define IDC_VPRM_BROWSE                 1011
#define IDC_VTRF_FILE                   1012
#define IDC_VTRF_BROWSE                 1013
#define IDC_VMON_FILE                   1014
#define IDC_VMON_BROWSE                 1015
#define IDC_VCRT_FILE                   1016
#define IDC_VCRT_BROWSE                 1017
#define IDC_ADD                         1018
#define IDC_DEL                         1019
#define IDC_TAB                         1019
#define IDC_MOD                         1020
#define IDC_DYN_ADD                     1021
#define IDC_SNR_NAME                    1021
#define IDC_DYN_DEL                     1022
#define IDC_VGCC_FILE                   1022
#define IDC_VGCC_BROWSE                 1023
#define IDC_VSPS_FILE                   1024
#define IDC_TPRM_FILE                   1025
#define IDC_VSPS_BROWSE                 1025
#define IDC_TCRT_FILE                   1026
#define IDC_VGVR_FILE                   1026
#define IDC_TTRF_FILE                   1027
#define IDC_VGVR_BROWSE                 1027
#define IDC_TSWT_FILE                   1028
#define IDC_VAGC_FILE                   1028
#define IDC_TMON_FILE                   1029
#define IDC_VAGC_BROWSE                 1029
#define IDC_TPRM_BROWSE                 1030
#define IDC_VMDP_FILE                   1030
#define IDC_TCRT_BROWSE                 1031
#define IDC_VMDP_BROWSE                 1031
#define IDC_TTRF_BROWSE                 1032
#define IDC_VCMF_FILE                   1032
#define IDC_TSWT_BROWSE                 1033
#define IDC_VCMF_BROWSE                 1033
#define IDC_TMON_BROWSE                 1034
#define IDC_DYNFILE_LIST                1035
#define IDC_TGCC_FILE                   1035
#define IDC_TSAT_TSA_LIST               1036
#define IDC_FORM_NORMAL_CASE            1037
#define IDC_TGCC_BROWSE                 1037
#define IDC_DEST_DIR_BROWSE             1038
#define IDC_DEST_DIR                    1039
#define IDC_FORM_EMERGENCY_CASE         1040
#define IDC_LOAD_CASE                   1041
#define IDC_BASE_CASE                   1042
#define IDC_SAVE_CASE                   1042
#define IDC_TSA_NAME                    1043
#define IDC_MESG_LIST                   1045

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
