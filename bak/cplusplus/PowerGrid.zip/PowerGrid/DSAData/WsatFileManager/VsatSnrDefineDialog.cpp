// VsatSnrDefineDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "WsatFileManagerApp.h"
#include "VsatSnrDefineDialog.h"


// CVsatSnrDefineDialog �Ի���

IMPLEMENT_DYNAMIC(CVsatSnrDefineDialog, CDialog)

CVsatSnrDefineDialog::CVsatSnrDefineDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CVsatSnrDefineDialog::IDD, pParent)
{
	m_nCurVsatSnr=-1;
}

CVsatSnrDefineDialog::~CVsatSnrDefineDialog()
{
}

void CVsatSnrDefineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_VSAT_SNR_LIST, m_wndSnrList);
}


BEGIN_MESSAGE_MAP(CVsatSnrDefineDialog, CDialog)
	ON_BN_CLICKED(IDC_VPRM_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVprmBrowse)
	ON_BN_CLICKED(IDC_VCRT_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVcrtBrowse)
	ON_BN_CLICKED(IDC_VTRF_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVtrfBrowse)
	ON_BN_CLICKED(IDC_VCTG_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVctgBrowse)
	ON_BN_CLICKED(IDC_VMON_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVmonBrowse)
	ON_BN_CLICKED(IDC_ADD, &CVsatSnrDefineDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CVsatSnrDefineDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_MOD, &CVsatSnrDefineDialog::OnBnClickedMod)
	ON_NOTIFY(NM_CLICK, IDC_VSAT_SNR_LIST, &CVsatSnrDefineDialog::OnNMClickVsatSnrList)
	ON_BN_CLICKED(IDC_BASE_CASE, &CVsatSnrDefineDialog::OnBnClickedBaseCase)
	ON_BN_CLICKED(IDC_VSPS_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVspsBrowse)
	ON_BN_CLICKED(IDC_VGCC_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVgccBrowse)
	ON_BN_CLICKED(IDC_VGVR_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVgvrBrowse)
	ON_BN_CLICKED(IDC_VAGC_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVagcBrowse)
	ON_BN_CLICKED(IDC_VMDP_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVmdpBrowse)
	ON_BN_CLICKED(IDC_VCMF_BROWSE, &CVsatSnrDefineDialog::OnBnClickedVcmfBrowse)
END_MESSAGE_MAP()


// CVsatSnrDefineDialog ��Ϣ��������

BOOL CVsatSnrDefineDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	int			nColumn;
	m_wndSnrList.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndSnrList.SetExtendedStyle(m_wndSnrList.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndSnrList.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	m_wndSnrList.InsertColumn(0, "���");
	for (nColumn=0; nColumn<sizeof(g_lpszVsatSnrColumn)/sizeof(char*); nColumn++)
		m_wndSnrList.InsertColumn(nColumn+1, g_lpszVsatSnrColumn[nColumn]);

// 	m_wndSnrList.InsertColumn(0, "���",	100, ListCtrlEx::Normal, LVCFMT_LEFT, ListCtrlEx::SortByDigit);
// 	for (nColumn=0; nColumn<sizeof(g_lpszVsatSnrColumn)/sizeof(char*); nColumn++)
// 	{
// 		if (nColumn == 1)
// 			m_wndSnrList.InsertColumn(nColumn+1, g_lpszVsatSnrColumn[nColumn], 100, ListCtrlEx::RadioBox, LVCFMT_LEFT, ListCtrlEx::SortByString);
// 		else
// 			m_wndSnrList.InsertColumn(nColumn+1, g_lpszVsatSnrColumn[nColumn], 100, ListCtrlEx::Normal, LVCFMT_LEFT, ListCtrlEx::SortByString);
// 	}
// 	m_wndSnrList.SetSupportSort(FALSE);

	RefreshSnrList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CVsatSnrDefineDialog::RefreshSnrList()
{
	register int	i;
	int		nRow,nCol;
	char	szBuf[260];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];

	m_wndSnrList.DeleteAllItems();

	nRow=0;
	for (i=0; i<(int)g_WsatDefinition.VsatSnrArray.size(); i++)
	{
		sprintf(szBuf,"%d",nRow+1);	m_wndSnrList.InsertItem(nRow, szBuf);

		nCol=1;
		m_wndSnrList.SetItemText(nRow, nCol++, g_WsatDefinition.VsatSnrArray[i].strSnrName.c_str());

		if (g_WsatDefinition.VsatSnrArray[i].bBaseCase)
			strcpy(szBuf,"��");
		else
			strcpy(szBuf,"��");
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVPrmFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVPrmFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVCrtFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVCrtFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVTrfFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVTrfFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVCtgFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVCtgFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVMonFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVMonFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVSpsFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVSpsFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVGccFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVGccFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVGvrFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVGvrFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVAgcFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVAgcFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVMdpFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVMdpFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		memset(szBuf, 0, 260);
		if (!g_WsatDefinition.VsatSnrArray[i].strVCmfFile.empty())
		{
			_splitpath(g_WsatDefinition.VsatSnrArray[i].strVCmfFile.c_str(), drive, dir, fname, ext);
			sprintf(szBuf,"%s%s",fname,ext);
		}
		m_wndSnrList.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth,nHeaderWidth;
	for (nCol=0; nCol<sizeof(g_lpszVsatSnrColumn)/sizeof(char*)+1; nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndSnrList.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndSnrList.GetColumnWidth(nCol);
		m_wndSnrList.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndSnrList.GetColumnWidth(nCol);

		m_wndSnrList.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CVsatSnrDefineDialog::OnBnClickedBaseCase()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nCurVsatSnr < 0 || m_nCurVsatSnr >= m_wndSnrList.GetItemCount())
		return;

	register int	i;
	for (i=0; i<(int)g_WsatDefinition.VsatSnrArray.size(); i++)
		g_WsatDefinition.VsatSnrArray[i].bBaseCase=0;
	g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].bBaseCase=1;
	RefreshSnrList();
}

void CVsatSnrDefineDialog::OnBnClickedVprmBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="prm";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.prm)|*.prm;*.PRM|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪲����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VPRM_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVcrtBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="crt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.crt)|*.crt;*.CRT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪱�׼�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VCRT_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVtrfBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="trf";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.trf)|*.trf;*.TRF|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪴����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VTRF_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVctgBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="ctg";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.ctg)|*.ctg;*.CTG|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪹����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VCTG_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVmonBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="mon";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.mon)|*.mon;*.MON|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪼����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VMON_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVspsBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="sps";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.sps)|*.sps;*.SPS|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪱�����ȫ�Զ�װ�ö����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VSPS_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVgccBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="gcc";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.gcc)|*.gcc;*.GCC|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪷������߶����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VGCC_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVgvrBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="gvr";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.gvr)|*.gvr;*.GVR|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪵�������Ӧ�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VGVR_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVagcBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="agc";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.agc)|*.agc;*.AGC|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("��AGC�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VAGC_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVmdpBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="mdp";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.mdp)|*.mdp;*.MDP|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("��ģ̬���������ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VMDP_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedVcmfBrowse()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="cmf";
	CString	defaultFileName=_T("");
	CString	fileFilter="�����ļ�(*.cmf)|*.cmf;*.CMF|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE,fileExt,
		defaultFileName,
		dwFlags,
		fileFilter,
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�򿪿����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	GetDlgItem(IDC_VCMF_FILE)->SetWindowText(dlg.GetPathName());
}

void CVsatSnrDefineDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	char			szBuf[260];
	tagVsatSnrDefinition	vBuf;

	GetDlgItem(IDC_SNR_NAME)->GetWindowText(szBuf, 260);	vBuf.strSnrName=szBuf;
	GetDlgItem(IDC_VPRM_FILE)->GetWindowText(szBuf, 260);	vBuf.strVPrmFile=szBuf;
	GetDlgItem(IDC_VCRT_FILE)->GetWindowText(szBuf, 260);	vBuf.strVCrtFile=szBuf;
	GetDlgItem(IDC_VTRF_FILE)->GetWindowText(szBuf, 260);	vBuf.strVTrfFile=szBuf;
	GetDlgItem(IDC_VCTG_FILE)->GetWindowText(szBuf, 260);	vBuf.strVCtgFile=szBuf;
	GetDlgItem(IDC_VMON_FILE)->GetWindowText(szBuf, 260);	vBuf.strVMonFile=szBuf;
	GetDlgItem(IDC_VSPS_FILE)->GetWindowText(szBuf, 260);	vBuf.strVSpsFile=szBuf;
	GetDlgItem(IDC_VGCC_FILE)->GetWindowText(szBuf, 260);	vBuf.strVGccFile=szBuf;
	GetDlgItem(IDC_VGVR_FILE)->GetWindowText(szBuf, 260);	vBuf.strVGvrFile=szBuf;
	GetDlgItem(IDC_VAGC_FILE)->GetWindowText(szBuf, 260);	vBuf.strVAgcFile=szBuf;
	GetDlgItem(IDC_VMDP_FILE)->GetWindowText(szBuf, 260);	vBuf.strVMdpFile=szBuf;
	GetDlgItem(IDC_VCMF_FILE)->GetWindowText(szBuf, 260);	vBuf.strVCmfFile=szBuf;
	if (g_WsatDefinition.VsatSnrArray.empty())
		vBuf.bBaseCase=1;
	else
		vBuf.bBaseCase=0;

	if (vBuf.strSnrName.empty())
	{
		AfxMessageBox("��Ϊ�����ӳ�������");
		return;
	}
	bExist=0;
	for (i=0; i<(int)g_WsatDefinition.VsatSnrArray.size(); i++)
	{
		if (stricmp(g_WsatDefinition.VsatSnrArray[i].strSnrName.c_str(), vBuf.strSnrName.c_str()) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
	{
		g_WsatDefinition.VsatSnrArray.push_back(vBuf);
		RefreshSnrList();
	}
	else
	{
		AfxMessageBox("�����ӳ����Ѿ�����");
	}
}

void CVsatSnrDefineDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nCurVsatSnr < 0 || m_nCurVsatSnr >= m_wndSnrList.GetItemCount())
		return;

	if (AfxMessageBox("��ȷ��ɾ��ѡ������?",MB_SYSTEMMODAL|MB_YESNO) == IDNO)
		return;

	g_WsatDefinition.VsatSnrArray.erase(g_WsatDefinition.VsatSnrArray.begin()+m_nCurVsatSnr);
	m_nCurVsatSnr=-1;
	RefreshSnrList();
}

void CVsatSnrDefineDialog::OnBnClickedMod()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (m_nCurVsatSnr < 0 || m_nCurVsatSnr >= m_wndSnrList.GetItemCount())
		return;

	register int	i;
	unsigned char	bExist;
	char			szBuf[260];
	tagVsatSnrDefinition	vBuf;

	GetDlgItem(IDC_SNR_NAME)->GetWindowText(szBuf, 260);	vBuf.strSnrName=szBuf;
	GetDlgItem(IDC_VPRM_FILE)->GetWindowText(szBuf, 260);	vBuf.strVPrmFile=szBuf;
	GetDlgItem(IDC_VCRT_FILE)->GetWindowText(szBuf, 260);	vBuf.strVCrtFile=szBuf;
	GetDlgItem(IDC_VTRF_FILE)->GetWindowText(szBuf, 260);	vBuf.strVTrfFile=szBuf;
	GetDlgItem(IDC_VCTG_FILE)->GetWindowText(szBuf, 260);	vBuf.strVCtgFile=szBuf;
	GetDlgItem(IDC_VMON_FILE)->GetWindowText(szBuf, 260);	vBuf.strVMonFile=szBuf;
	GetDlgItem(IDC_VSPS_FILE)->GetWindowText(szBuf, 260);	vBuf.strVSpsFile=szBuf;
	GetDlgItem(IDC_VGCC_FILE)->GetWindowText(szBuf, 260);	vBuf.strVGccFile=szBuf;
	GetDlgItem(IDC_VGVR_FILE)->GetWindowText(szBuf, 260);	vBuf.strVGvrFile=szBuf;
	GetDlgItem(IDC_VAGC_FILE)->GetWindowText(szBuf, 260);	vBuf.strVAgcFile=szBuf;
	GetDlgItem(IDC_VMDP_FILE)->GetWindowText(szBuf, 260);	vBuf.strVMdpFile=szBuf;
	GetDlgItem(IDC_VCMF_FILE)->GetWindowText(szBuf, 260);	vBuf.strVCmfFile=szBuf;

	if (vBuf.strSnrName.empty())
	{
		AfxMessageBox("��Ϊ���޸ĳ�������");
		return;
	}
	bExist=0;
	for (i=0; i<(int)g_WsatDefinition.VsatSnrArray.size(); i++)
	{
		if (i == m_nCurVsatSnr)
			continue;
		if (stricmp(g_WsatDefinition.VsatSnrArray[i].strSnrName.c_str(), vBuf.strSnrName.c_str()) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
	{
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strSnrName=vBuf.strSnrName;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVPrmFile=vBuf.strVPrmFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVCrtFile=vBuf.strVCrtFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVTrfFile=vBuf.strVTrfFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVCtgFile=vBuf.strVCtgFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVMonFile=vBuf.strVMonFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVSpsFile=vBuf.strVSpsFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVGccFile=vBuf.strVGccFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVGvrFile=vBuf.strVGvrFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVAgcFile=vBuf.strVAgcFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVMdpFile=vBuf.strVMdpFile;
		g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVCmfFile=vBuf.strVCmfFile;
		RefreshSnrList();
	}
	else
	{
		AfxMessageBox("���޸ĳ��������Ѿ�����");
	}
}

void CVsatSnrDefineDialog::OnNMClickVsatSnrList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_nCurVsatSnr=pNMItemActivate->iItem;
	if (m_nCurVsatSnr >= 0 && m_nCurVsatSnr < m_wndSnrList.GetItemCount())
	{
		GetDlgItem(IDC_SNR_NAME)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strSnrName.c_str());
		GetDlgItem(IDC_VPRM_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVPrmFile.c_str());
		GetDlgItem(IDC_VCRT_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVCrtFile.c_str());
		GetDlgItem(IDC_VTRF_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVTrfFile.c_str());
		GetDlgItem(IDC_VCTG_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVCtgFile.c_str());
		GetDlgItem(IDC_VMON_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVMonFile.c_str());
		GetDlgItem(IDC_VSPS_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVSpsFile.c_str());
		GetDlgItem(IDC_VGCC_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVGccFile.c_str());
		GetDlgItem(IDC_VGVR_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVGvrFile.c_str());
		GetDlgItem(IDC_VAGC_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVAgcFile.c_str());
		GetDlgItem(IDC_VMDP_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVMdpFile.c_str());
		GetDlgItem(IDC_VCMF_FILE)->SetWindowText(g_WsatDefinition.VsatSnrArray[m_nCurVsatSnr].strVCmfFile.c_str());
	}
	*pResult = 0;
}
