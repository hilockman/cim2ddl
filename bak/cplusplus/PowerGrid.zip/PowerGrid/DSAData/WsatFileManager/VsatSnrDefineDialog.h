#pragma once
#include "afxcmn.h"
//#include "../../../Common/ListCtrlEx/ListCtrlEx.h"
//using namespace ListCtrlEx;

// CVsatSnrDefineDialog �Ի���

class CVsatSnrDefineDialog : public CDialog
{
	DECLARE_DYNAMIC(CVsatSnrDefineDialog)

public:
	CVsatSnrDefineDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CVsatSnrDefineDialog();

public:
	void	RefreshSnrList();
// �Ի�������
	enum { IDD = IDD_VSATFILE_DEFINE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedBaseCase();
	afx_msg void OnBnClickedVprmBrowse();
	afx_msg void OnBnClickedVcrtBrowse();
	afx_msg void OnBnClickedVtrfBrowse();
	afx_msg void OnBnClickedVctgBrowse();
	afx_msg void OnBnClickedVmonBrowse();
	afx_msg void OnBnClickedVspsBrowse();
	afx_msg void OnBnClickedVgccBrowse();
	afx_msg void OnBnClickedVgvrBrowse();
	afx_msg void OnBnClickedVagcBrowse();
	afx_msg void OnBnClickedVmdpBrowse();
	afx_msg void OnBnClickedVcmfBrowse();
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedMod();
	afx_msg void OnNMClickVsatSnrList(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()

private:
	int				m_nCurVsatSnr;
	CMFCListCtrl	m_wndSnrList;
public:
};
