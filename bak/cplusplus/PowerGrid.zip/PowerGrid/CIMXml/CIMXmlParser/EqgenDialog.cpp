// EqgenDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CIMXmlParser.h"
#include "EqgenDialog.h"


// CEqgenDialog �Ի���

IMPLEMENT_DYNAMIC(CEqgenDialog, CDialog)

CEqgenDialog::CEqgenDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CEqgenDialog::IDD, pParent)
	, m_nEqgenType(1)
{
}

CEqgenDialog::~CEqgenDialog()
{
}

void CEqgenDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_EQGEN_BUS, m_nEqgenType);
}


BEGIN_MESSAGE_MAP(CEqgenDialog, CDialog)
	ON_LBN_SELCHANGE(IDC_SUB_LIST, &CEqgenDialog::OnLbnSelchangeSubList)
	ON_BN_CLICKED(IDOK, &CEqgenDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CEqgenDialog ��Ϣ��������

BOOL CEqgenDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox;
	
	pListBox=(CListBox*)GetDlgItem(IDC_SUB_LIST);
	pListBox->ResetContent();
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; i++)
		pListBox->AddString(g_pPGBlock->m_SubstationArray[i].szName);

	pListBox=(CListBox*)GetDlgItem(IDC_BOUNDBUS_LIST);
	pListBox->ResetContent();

	pListBox=(CListBox*)GetDlgItem(IDC_TIELINE_LIST);
	pListBox->ResetContent();

	CButton*	pButton=(CButton*)GetDlgItem(IDC_UNITAT_OUTNET);
	pButton->SetCheck(1);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CEqgenDialog::OnLbnSelchangeSubList()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nSelArray[100];
	char	szBuf[260];
	m_strSubArray.clear();

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUB_LIST);
	pListBox->GetSelItems(100, nSelArray);
	for (i=0; i<pListBox->GetSelCount(); i++)
	{
		pListBox->GetText(nSelArray[i], szBuf);
		m_strSubArray.push_back(szBuf);
	}
	RefreshBusList();
	RefreshLineList();
}

void CEqgenDialog::RefreshBusList(void)
{
	register int	i;
	int			nSub, nVolt, nDev;
	char		szBuf[260];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_BOUNDBUS_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)m_strSubArray.size(); i++)
	{
		nSub=PGFindRecordbyKey(g_pPGBlock, PG_SUBSTATION, m_strSubArray[i].c_str());
		for (nVolt=g_pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nDev=g_pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<g_pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
			{
				sprintf(szBuf, "%s.%s.%s", g_pPGBlock->m_BusbarSectionArray[nDev].szSub, g_pPGBlock->m_BusbarSectionArray[nDev].szVolt, g_pPGBlock->m_BusbarSectionArray[nDev].szName);
				pListBox->AddString(szBuf);
			}
		}
	}
}

void CEqgenDialog::RefreshLineList(void)
{
	register int	i;
	int			nSub, nVolt, nNode, nDev;
	char		szBuf[260];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_TIELINE_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)m_strSubArray.size(); i++)
	{
		nSub=PGFindRecordbyKey(g_pPGBlock, PG_SUBSTATION, m_strSubArray[i].c_str());
		for (nVolt=g_pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nNode=g_pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<g_pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
			{
				for (nDev=g_pPGBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<g_pPGBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
				{
					sprintf(szBuf, "%s.%s.%s", g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szSub, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szVolt, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szName);
					pListBox->AddString(szBuf);
				}
			}
		}
	}
}

void CEqgenDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	CButton*	pButton=(CButton*)GetDlgItem(IDC_UNITAT_OUTNET);
	unsigned char	bSetUnOutnet=pButton->GetCheck();

	register int	i;
	int			nSub, nVolt, nNode, nDev, nSelArray[100];
	unsigned char	bFind;
	char		szBuf[260];
	std::vector<std::string>	strSelArray;
	char	szField[MAXMDBFIELDNUM][MDB_CHARLEN_LONG];
	CListBox*	pListBox;

	strSelArray.clear();
	if (m_nEqgenType == 0)
	{
		pListBox=(CListBox*)GetDlgItem(IDC_BOUNDBUS_LIST);
		if (pListBox->GetSelCount() > 0)
		{
			pListBox->GetSelItems(100, nSelArray);
			for (i=0; i<pListBox->GetSelCount(); i++)
			{
				pListBox->GetText(nSelArray[i], szBuf);
				strSelArray.push_back(szBuf);
			}
		}
		else
		{
			for (i=0; i<pListBox->GetCount(); i++)
			{
				pListBox->GetText(i, szBuf);
				strSelArray.push_back(szBuf);
			}
		}

		for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			for (nVolt=g_pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nDev=g_pPGBlock->m_VoltageLevelArray[nVolt].nBusbarSectionRange; nDev<g_pPGBlock->m_VoltageLevelArray[nVolt+1].nBusbarSectionRange; nDev++)
				{
					if (g_pPGBlock->m_BusbarSectionArray[nDev].nNode < 0)
						continue;

					bFind=0;
					sprintf(szBuf, "%s.%s.%s", g_pPGBlock->m_BusbarSectionArray[nDev].szSub, g_pPGBlock->m_BusbarSectionArray[nDev].szVolt, g_pPGBlock->m_BusbarSectionArray[nDev].szName);
					for (i=0; i<(int)strSelArray.size(); i++)
					{
						if (strcmp(strSelArray[i].c_str(), szBuf) == 0)
						{
							bFind=1;
							break;
						}
					}
					if (bFind)
					{
						memset(&g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]], 0, sizeof(tagPGSynchronousMachine));
						strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, g_pPGBlock->m_BusbarSectionArray[nDev].szSub);
						strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, g_pPGBlock->m_BusbarSectionArray[nDev].szVolt);
						strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szName, g_pPGBlock->m_BusbarSectionArray[nDev].szName);
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanP=10;
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanQ=0;
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=9999;
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=-9999;
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=9999;
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=-9999;
						strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, g_pPGBlock->m_BusbarSectionArray[nDev].szNode);
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanV=1.02f;
						g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].nType=PGGetFieldEnumValue(PG_SYNCHRONOUSMACHINE, PG_SYNCHRONOUSMACHINE_TYPE, "��ֵ����");
						g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]++;
					}
				}
			}
		}
	}
	else
	{
		double	fBuf, fFactor=0.85;
		pListBox=(CListBox*)GetDlgItem(IDC_TIELINE_LIST);
		if (pListBox->GetSelCount() > 0)
		{
			pListBox->GetSelItems(100, nSelArray);
			for (i=0; i<pListBox->GetSelCount(); i++)
			{
				pListBox->GetText(nSelArray[i], szBuf);
				strSelArray.push_back(szBuf);
			}
		}
		else
		{
			for (i=0; i<pListBox->GetCount(); i++)
			{
				pListBox->GetText(i, szBuf);
				strSelArray.push_back(szBuf);
			}
		}

		for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
		{
			for (nVolt=g_pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<g_pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
			{
				for (nNode=g_pPGBlock->m_VoltageLevelArray[nVolt].nConnecivityNodeRange; nNode<g_pPGBlock->m_VoltageLevelArray[nVolt+1].nConnecivityNodeRange; nNode++)
				{
					for (nDev=g_pPGBlock->m_ConnectivityNodeArray[nNode].nACLineSegmentRange; nDev<g_pPGBlock->m_ConnectivityNodeArray[nNode+1].nACLineSegmentRange; nDev++)
					{
						bFind=0;
						sprintf(szBuf, "%s.%s.%s", g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szSub, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szVolt, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szName);
						for (i=0; i<(int)strSelArray.size(); i++)
						{
							if (strcmp(strSelArray[i].c_str(), szBuf) == 0)
							{
								bFind=1;
								break;
							}
						}
						if (bFind)
						{
							memset(&g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]], 0, sizeof(tagPGSynchronousMachine));
							if (bSetUnOutnet)
							{
								if (strcmp(g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szSub) == 0)
								{
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeI);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltI);
								}
								else
								{
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubJ);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeJ);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltJ);
								}
							}
							else
							{
								if (strcmp(g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szSub) == 0)
								{
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubJ);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeJ);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltJ);
								}
								else
								{
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szSub, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szSubI);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szNode, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szNodeI);
									strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szVolt, g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].szVoltI);
								}
							}


							strcpy(g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].szName, g_pPGBlock->m_EdgeACLineSegmentArray[nDev].szName);
							g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanP=10;
							g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanQ=0;

							if (g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fRatedCur > 0.1)
							{
								fBuf=1.732*g_pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage*g_pPGBlock->m_ACLineSegmentArray[g_pPGBlock->m_EdgeACLineSegmentArray[nDev].nACLineSegment].fRatedCur/1000;
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=(float)fBuf;
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=(float)-fBuf;
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=(float)(fBuf*sqrt(1-fFactor*fFactor)/fFactor);
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=(float)(-fBuf*sqrt(1-fFactor*fFactor)/fFactor);
							}
							else
							{
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMax=9999;
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPMin=-9999;
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMax=9999;
								g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fQMin=-9999;
							}
							g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].fPlanV=1.02f;
							g_pPGBlock->m_SynchronousMachineArray[g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]].nType=PGGetFieldEnumValue(PG_SYNCHRONOUSMACHINE, PG_SYNCHRONOUSMACHINE_TYPE, "��ֵ����");
							g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]++;
						}
					}
				}
			}
		}
	}

	for (i=0; i<MAXMDBFIELDNUM; i++)
		memset(szField[i], 0, MDB_CHARLEN_LONG);
	strcpy(szField[PG_COMPANY_NAME], "����");
	PGAppendRecord(g_pPGBlock, MDB_NeedCheckData, PG_COMPANY, szField);

	strcpy(szField[PG_SUBCONTROLAREA_COMPANY], "����");
	strcpy(szField[PG_SUBCONTROLAREA_NAME], "����");
	PGAppendRecord(g_pPGBlock, MDB_NeedCheckData, PG_SUBCONTROLAREA, szField);

	for (nSub=0; nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (i=0; i<(int)m_strSubArray.size(); i++)
		{
			if (strcmp(g_pPGBlock->m_SubstationArray[nSub].szName, m_strSubArray[i].c_str()) == 0)
			{
				strcpy(g_pPGBlock->m_SubstationArray[nSub].szCompany, "����");
				strcpy(g_pPGBlock->m_SubstationArray[nSub].szSubcontrolArea, "����");
				break;
			}
		}
	}

	nDev=0;
	while (nDev < g_pPGBlock->m_nRecordNum[PG_BREAKER])
	{
		bFind=0;
		for (i=0; i<(int)m_strSubArray.size(); i++)
		{
			if (strcmp(g_pPGBlock->m_BreakerArray[nDev].szSub, m_strSubArray[i].c_str()) == 0)
			{
				PGRemoveRecord(g_pPGBlock, PG_BREAKER, nDev);
				bFind=1;
				break;
			}
		}
		if (!bFind)
			nDev++;
	}

	nDev=0;
	while (nDev < g_pPGBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		bFind=0;
		for (i=0; i<(int)m_strSubArray.size(); i++)
		{
			if (strcmp(g_pPGBlock->m_DisconnectorArray[nDev].szSub, m_strSubArray[i].c_str()) == 0)
			{
				PGRemoveRecord(g_pPGBlock, PG_DISCONNECTOR, nDev);
				bFind=1;
				break;
			}
		}
		if (!bFind)
			nDev++;
	}

	nDev=0;
	while (nDev < g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		bFind=0;
		for (i=0; i<(int)m_strSubArray.size(); i++)
		{
			if (strcmp(g_pPGBlock->m_TransformerWindingArray[nDev].szSub, m_strSubArray[i].c_str()) == 0)
			{
				PGRemoveRecord(g_pPGBlock, PG_TRANSFORMERWINDING, nDev);
				bFind=1;
				break;
			}
		}
		if (!bFind)
			nDev++;
	}

	PGMaint(g_pPGBlock);

	OnOK();
}
