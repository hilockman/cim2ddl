
#pragma once

#include "ViewTree.h"
class CTableView : public CDockablePane
{
public:
	CTableView();
	virtual ~CTableView();

	void AdjustLayout();
	void OnChangeVisualStyle();

protected:
	CViewTree m_wndTableView;
	CImageList m_TableViewImages;

	void FillTableView();

// ��д
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);

	DECLARE_MESSAGE_MAP()
private:
};

