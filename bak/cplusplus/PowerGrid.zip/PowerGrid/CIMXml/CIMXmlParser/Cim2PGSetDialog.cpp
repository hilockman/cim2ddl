// Cim2PGSetDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CIMXmlParser.h"
#include "Cim2PGSetDialog.h"

// CCim2PGSetDialog �Ի���

static	char*	lpszBoundLineColumn[]=
{
	("���"), 
	("ResourceID"), 
	("��վ"), 
	("��վ"), 
	("��ѹ"), 
	("��ѹ"), 
	("����"), 
};


IMPLEMENT_DYNAMIC(CCim2PGSetDialog, CDialog)

CCim2PGSetDialog::CCim2PGSetDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CCim2PGSetDialog::IDD, pParent)
{
	m_bClearMemDB=TRUE;

	m_bTranPuRXVoltageHigh=FALSE;
	m_fLowVThreshold=120;
}

CCim2PGSetDialog::~CCim2PGSetDialog()
{
}

void CCim2PGSetDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CLEAR_MEMDB, m_bClearMemDB);
	DDX_Check(pDX, IDC_TRANSFORMERWINDING_PUVOLTAGEHIGH, m_bTranPuRXVoltageHigh);
	DDX_Text(pDX, IDC_LOWV_THRESHOLD, m_fLowVThreshold);
}


BEGIN_MESSAGE_MAP(CCim2PGSetDialog, CDialog)
	ON_LBN_SELCHANGE(IDC_SUBCONTROLAREA_LIST, &CCim2PGSetDialog::OnLbnSelchangeSubcontrolareaList)
	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CCim2PGSetDialog::OnBnClickedSaveasExcel)
	ON_BN_CLICKED(IDC_ADD_SUBCONTROLAREA, &CCim2PGSetDialog::OnBnClickedAddSubcontrolarea)
	ON_BN_CLICKED(IDC_DEL_SUBCONTROLAREA, &CCim2PGSetDialog::OnBnClickedDelSubcontrolarea)
	ON_BN_CLICKED(IDC_ADD_SUBSTATION, &CCim2PGSetDialog::OnBnClickedAddSubstation)
	ON_BN_CLICKED(IDC_DEL_SUBSTATION, &CCim2PGSetDialog::OnBnClickedDelSubstation)
	ON_BN_CLICKED(IDC_ADDALL_SUBSTATION, &CCim2PGSetDialog::OnBnClickedAddallSubstation)
	ON_BN_CLICKED(IDC_SHOWONLY_INCLUDEAREA, &CCim2PGSetDialog::OnBnClickedShowonlyIncludearea)
	ON_BN_CLICKED(IDC_SHOWONLY_INCLUDESUB, &CCim2PGSetDialog::OnBnClickedShowonlyIncludesub)
END_MESSAGE_MAP()


// CCim2PGSetDialog ��Ϣ��������

BOOL CCim2PGSetDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	pListCtrl->SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	for (i=0; i<sizeof(lpszBoundLineColumn)/sizeof(char*); i++)
		pListCtrl->InsertColumn(i, lpszBoundLineColumn[i]);

	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);
	g_CimDataParser.formBound(g_bNameByDesp);

	RefreshSubcontrolAreaList();
	RefreshExSubcontrolAreaList();
	RefreshExSubstationList();
	RefreshBoundLineList();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CCim2PGSetDialog::OnBnClickedAddSubcontrolarea()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nItem;
	unsigned char	bExist;
	char		szItem[128];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUBCONTROLAREA_LIST);
	nItem=pListBox->GetCurSel();
	if (nItem == LB_ERR)
		return;

	pListBox->GetText(nItem, szItem);

	bExist=0;
	for (i=0; i<(int)g_strExcludeSubcontrolAreaArray.size(); i++)
	{
		if (strcmp(g_strExcludeSubcontrolAreaArray[i].c_str(), szItem) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		g_strExcludeSubcontrolAreaArray.push_back(szItem);

	RefreshExSubcontrolAreaList();

	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);
	g_CimDataParser.formBound(g_bNameByDesp);
	RefreshBoundLineList();
	SaveIni();
}

void CCim2PGSetDialog::OnBnClickedDelSubcontrolarea()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nItem;
	char		szItem[128];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_EXSUBCONTROLAREA_LIST);
	nItem=pListBox->GetCurSel();
	if (nItem == LB_ERR)
		return;

	pListBox->GetText(nItem, szItem);
	for (i=0; i<(int)g_strExcludeSubcontrolAreaArray.size(); i++)
	{
		if (strcmp(g_strExcludeSubcontrolAreaArray[i].c_str(), szItem) == 0)
		{
			g_strExcludeSubcontrolAreaArray.erase(g_strExcludeSubcontrolAreaArray.begin()+i);
			break;
		}
	}

	RefreshExSubcontrolAreaList();

	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);
	g_CimDataParser.formBound(g_bNameByDesp);
	RefreshBoundLineList();
	SaveIni();
}

void CCim2PGSetDialog::OnBnClickedAddSubstation()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nItem, nSelNum;
	unsigned char	bExist;
	int			nSelIndexArray[1000];
	char		szSub[128];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUBSTATION_LIST);
	nSelNum=pListBox->GetSelItems(1000, nSelIndexArray);
	for (nItem=0; nItem<nSelNum; nItem++)
	{
		pListBox->GetText(nSelIndexArray[nItem], szSub);

		bExist=0;
		for (i=0; i<(int)g_strExcludeSubstationArray.size(); i++)
		{
			if (strcmp(g_strExcludeSubstationArray[i].c_str(), szSub) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			g_strExcludeSubstationArray.push_back(szSub);
	}
	RefreshExSubstationList();

	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);
	g_CimDataParser.formBound(g_bNameByDesp);
	RefreshBoundLineList();
	SaveIni();
}

void CCim2PGSetDialog::OnBnClickedDelSubstation()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CListBox*	pListBox;
	char		szSub[MDB_CHARLEN];
	int			nSelIndexArray[1000];

	pListBox=(CListBox*)GetDlgItem(IDC_EXSUBSTATION_LIST);
	int		nSelNum=pListBox->GetSelItems(1000, nSelIndexArray);
	for (int nItem=0; nItem<nSelNum; nItem++)
	{
		pListBox->GetText(nSelIndexArray[nItem], szSub);
		for (i=0; i<(int)g_strExcludeSubstationArray.size(); i++)
		{
			if (strcmp(g_strExcludeSubstationArray[i].c_str(), szSub) == 0)
			{
				g_strExcludeSubstationArray.erase(g_strExcludeSubstationArray.begin()+i);
				break;
			}
		}
	}
	RefreshExSubstationList();

	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);
	g_CimDataParser.formBound(g_bNameByDesp);
	RefreshBoundLineList();
	SaveIni();
}

void CCim2PGSetDialog::OnBnClickedAddallSubstation()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int			nItem;
	unsigned char	bExist;
	char		szSub[128];
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUBSTATION_LIST);
	for (nItem=0; nItem<pListBox->GetCount(); nItem++)
	{
		pListBox->GetText(nItem, szSub);

		bExist=0;
		for (i=0; i<(int)g_strExcludeSubstationArray.size(); i++)
		{
			if (strcmp(g_strExcludeSubstationArray[i].c_str(), szSub) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
			g_strExcludeSubstationArray.push_back(szSub);
	}
	RefreshExSubstationList();

	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);
	g_CimDataParser.formBound(g_bNameByDesp);
	RefreshBoundLineList();
	SaveIni();
}

void CCim2PGSetDialog::RefreshBoundLineList(void)
{
	register int	i, j;
	int			nSub;
	char		szBuf[260];
	int			nCol, nColWidth, nHeaderWidth;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	if (!pListCtrl->DeleteAllItems())
		return;

	for (i=0; i<(int)g_CimDataParser.m_BoundLineArray.size(); i++)
	{
		nCol=1;
		sprintf(szBuf, "%d", i+1);
		pListCtrl->InsertItem(i, szBuf);

		pListCtrl->SetItemText(i, nCol++, g_CimDataParser.m_BoundLineArray[i].szResourceID);

		nSub=-1;
		for (j=0; j<(int)g_CimDataParser.m_SubstationArray.size(); j++)
		{
			if (g_bNameByDesp)
			{
				if (strcmp(g_CimDataParser.m_BoundLineArray[i].szSub[0], g_CimDataParser.m_SubstationArray[j].szDesp) == 0)
				{
					nSub=j;
					break;
				}
			}
			else
			{
				if (strcmp(g_CimDataParser.m_BoundLineArray[i].szSub[0], g_CimDataParser.m_SubstationArray[j].szName) == 0)
				{
					nSub=j;
					break;
				}
			}
		}
		if (nSub >= 0)
			sprintf(szBuf, "%s(%s)", g_CimDataParser.m_BoundLineArray[i].szSub[0], g_CimDataParser.m_SubstationArray[nSub].strSubcontrolArea.c_str());
		else
			strcpy(szBuf, g_CimDataParser.m_BoundLineArray[i].szSub[0]);

		pListCtrl->SetItemText(i, nCol++, szBuf);
		nSub=-1;
		for (j=0; j<(int)g_CimDataParser.m_SubstationArray.size(); j++)
		{
			if (g_bNameByDesp)
			{
				if (strcmp(g_CimDataParser.m_BoundLineArray[i].szSub[1], g_CimDataParser.m_SubstationArray[j].szDesp) == 0)
				{
					nSub=j;
					break;
				}
			}
			else
			{
				if (strcmp(g_CimDataParser.m_BoundLineArray[i].szSub[1], g_CimDataParser.m_SubstationArray[j].szName) == 0)
				{
					nSub=j;
					break;
				}
			}
		}
		if (nSub >= 0)
			sprintf(szBuf, "%s(%s)", g_CimDataParser.m_BoundLineArray[i].szSub[1], g_CimDataParser.m_SubstationArray[nSub].strSubcontrolArea.c_str());
		else
			strcpy(szBuf, g_CimDataParser.m_BoundLineArray[i].szSub[1]);

		pListCtrl->SetItemText(i, nCol++, szBuf);

		pListCtrl->SetItemText(i, nCol++, g_CimDataParser.m_BoundLineArray[i].szVolt[0]);
		pListCtrl->SetItemText(i, nCol++, g_CimDataParser.m_BoundLineArray[i].szVolt[1]);
		pListCtrl->SetItemText(i, nCol++, g_CimDataParser.m_BoundLineArray[i].szName);
	}

	for (i=0; i<sizeof(lpszBoundLineColumn)/sizeof(char*); i++)
	{
		nColWidth=nHeaderWidth=0;

		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = pListCtrl->GetColumnWidth(i);
		pListCtrl->SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =pListCtrl->GetColumnWidth(i);

		pListCtrl->SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

void CCim2PGSetDialog::RefreshSubcontrolAreaList()
{
	register int	i;

	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOWONLY_INCLUDEAREA);
	unsigned char	bShowOnly=pButton->GetCheck();

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_SUBCONTROLAREA_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)g_CimDataParser.m_SubcontrolAreaArray.size(); i++)
	{
		if (bShowOnly)
		{
			if (g_CimDataParser.m_SubcontrolAreaArray[i].bExclude)
				continue;
		}
		if (g_bNameByDesp)
			pListBox->AddString(g_CimDataParser.m_SubcontrolAreaArray[i].szDesp);
		else
			pListBox->AddString(g_CimDataParser.m_SubcontrolAreaArray[i].szName);
	}
}

void CCim2PGSetDialog::RefreshExSubcontrolAreaList()
{
	register int	i;

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_EXSUBCONTROLAREA_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)g_strExcludeSubcontrolAreaArray.size(); i++)
		pListBox->AddString(g_strExcludeSubcontrolAreaArray[i].c_str());
}

void CCim2PGSetDialog::RefreshExSubstationList()
{
	register int	i;

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_EXSUBSTATION_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)g_strExcludeSubstationArray.size(); i++)
		pListBox->AddString(g_strExcludeSubstationArray[i].c_str());
}

void CCim2PGSetDialog::OnLbnSelchangeSubcontrolareaList()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	int		nSel;
	char	szArea[MDB_CHARLEN];
	CListBox*	pListBox;
	
	pListBox=(CListBox*)GetDlgItem(IDC_SUBCONTROLAREA_LIST);
	nSel=pListBox->GetCurSel();
	if (nSel == LB_ERR)
		return;
	pListBox->GetText(nSel, szArea);

	CButton*	pButton=(CButton*)GetDlgItem(IDC_SHOWONLY_INCLUDESUB);
	unsigned char	bShowOnly=pButton->GetCheck();
	pListBox=(CListBox*)GetDlgItem(IDC_SUBSTATION_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)g_CimDataParser.m_SubstationArray.size(); i++)
	{
		if (strcmp(szArea, g_CimDataParser.m_SubstationArray[i].strSubcontrolArea.c_str()) != 0)
			continue;

		if (bShowOnly)
		{
			if (g_CimDataParser.m_SubstationArray[i].bExclude)
				continue;
		}
		if (g_bNameByDesp)
			pListBox->AddString(g_CimDataParser.m_SubstationArray[i].szDesp);
		else
			pListBox->AddString(g_CimDataParser.m_SubstationArray[i].szName);
	}
}

void CCim2PGSetDialog::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	CListCtrl*	pListCtrl=(CListCtrl*)GetDlgItem(IDC_BOUNDLINE_LIST);
	SaveListAsExcel(pListCtrl, "BoundLine", dlg.GetPathName(), 1);
}

void CCim2PGSetDialog::OnBnClickedShowonlyIncludearea()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshSubcontrolAreaList();
}

void CCim2PGSetDialog::OnBnClickedShowonlyIncludesub()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnLbnSelchangeSubcontrolareaList();
}
