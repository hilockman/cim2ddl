#pragma once


// CSubcontrolAreaDeleteDialog �Ի���

class CSubcontrolAreaDeleteDialog : public CDialog
{
	DECLARE_DYNAMIC(CSubcontrolAreaDeleteDialog)

public:
	CSubcontrolAreaDeleteDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSubcontrolAreaDeleteDialog();

// �Ի�������
	enum { IDD = IDD_DELETE_SUBCONTROLAREA_DIALOG };

protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	afx_msg void OnBnClickedDelete();
	DECLARE_MESSAGE_MAP()
public:
private:
	void EraseSubstation(tagPGBlock* pBlock, const char* lpszSubName);
private:
	std::vector<std::string>	m_strDelSubcontroalAreaArray;
	void RefreshDelSubcontrolArea(void);
};
