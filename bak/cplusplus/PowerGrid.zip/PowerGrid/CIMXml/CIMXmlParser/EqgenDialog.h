#pragma once


// CEqgenDialog �Ի���

class CEqgenDialog : public CDialog
{
	DECLARE_DYNAMIC(CEqgenDialog)

public:
	CEqgenDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CEqgenDialog();

// �Ի�������
	enum { IDD = IDD_EQGEN_DIALOG };

protected:
	virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	afx_msg void OnLbnSelchangeSubList();
	DECLARE_MESSAGE_MAP()

private:
	int m_nEqgenType;
	std::vector<std::string>	m_strSubArray;
private:
	void RefreshBusList(void);
	void RefreshLineList(void);
public:
	afx_msg void OnBnClickedOk();
};
