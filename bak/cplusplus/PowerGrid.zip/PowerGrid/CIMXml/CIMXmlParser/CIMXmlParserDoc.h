
// CIMXmlParserDoc.h : CCIMXmlParserDoc ��Ľӿ�
//


#pragma once

class CCIMXmlParserDoc : public CDocument
{
protected: // �������л�����
	CCIMXmlParserDoc();
	DECLARE_DYNCREATE(CCIMXmlParserDoc)

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// ʵ��
public:
	virtual ~CCIMXmlParserDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFileOpen();
	afx_msg void OnInputBlock();
	afx_msg void OnFormMeasurementTable();
	afx_msg void OnReadMeavalue();
	afx_msg void OnAddOuteqgen();
	afx_msg void OnNetTailor();
	afx_msg void OnPg2cimxml();
	DECLARE_MESSAGE_MAP()
public:
};


