
// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// CIMXmlParser.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#	pragma message("CIMXmlParser Link LibX86 PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#	pragma message("CIMXmlParser Link LibX64 PGMemDB.lib")
#endif

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/CIMDataApi.lib")
#else					 
#	pragma comment(lib, "../../../lib_x64/CIMDataApi.lib")
#endif

#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif
