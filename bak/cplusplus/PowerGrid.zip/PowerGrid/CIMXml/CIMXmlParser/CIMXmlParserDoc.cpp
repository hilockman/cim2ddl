
// CIMXmlParserDoc.cpp : CCIMXmlParserDoc ���ʵ��
//

#include "stdafx.h"
#include "CIMXmlParser.h"
#include "CIMXmlParserDoc.h"
#include "EqgenDialog.h"
#include "SubcontrolAreaDeleteDialog.h"
#include "Cim2PGSetDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCIMXmlParserDoc

IMPLEMENT_DYNCREATE(CCIMXmlParserDoc, CDocument)

BEGIN_MESSAGE_MAP(CCIMXmlParserDoc, CDocument)
	ON_COMMAND(ID_FILE_OPEN, &CCIMXmlParserDoc::OnFileOpen)
	ON_COMMAND(ID_INPUT_BLOCK, &CCIMXmlParserDoc::OnInputBlock)
	ON_COMMAND(ID_FORM_MEASUREMENT_TABLE, &CCIMXmlParserDoc::OnFormMeasurementTable)
	ON_COMMAND(ID_READ_MEAVALUE, &CCIMXmlParserDoc::OnReadMeavalue)
	ON_COMMAND(ID_ADD_OUTEQGEN, &CCIMXmlParserDoc::OnAddOuteqgen)
	ON_COMMAND(ID_NET_TAILOR, &CCIMXmlParserDoc::OnNetTailor)
	ON_COMMAND(ID_PG2CIMXML, &CCIMXmlParserDoc::OnPg2cimxml)
END_MESSAGE_MAP()


// CCIMXmlParserDoc ����/����

CCIMXmlParserDoc::CCIMXmlParserDoc()
{
	// TODO: �ڴ�����һ���Թ������
}

CCIMXmlParserDoc::~CCIMXmlParserDoc()
{
}

BOOL CCIMXmlParserDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
	{
		return FALSE;
	}

	// TODO: �ڴ��������³�ʼ������
	// (SDI �ĵ������ø��ĵ�)

	return TRUE;
}


// CCIMXmlParserDoc ���л�

void CCIMXmlParserDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: �ڴ����Ӵ洢����
	}
	else
	{
		// TODO: �ڴ����Ӽ��ش���
	}
}


// CCIMXmlParserDoc ���

#ifdef _DEBUG
void CCIMXmlParserDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCIMXmlParserDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CCIMXmlParserDoc ����

void CCIMXmlParserDoc::OnFileOpen()
{
	// TODO: �ڴ�����������������
	clock_t	dBeg, dEnd;
	int		nDur;
	char	szFileName[260];
	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("CIM/XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
	                defaultFileName, 
	                dwFlags, 
	                fileFilter, 
	                NULL);

	dlg.m_ofn.lpstrTitle=_T("��CIM/XML�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
	{
		return;
	}

	dBeg=clock();
	strcpy(szFileName, (LPCTSTR)dlg.GetPathName());

	g_CimDataParser.Parse(&g_CimDataParser, dlg.GetPathName(), g_bParserMeasurement, g_bParseBySax, g_bNameByDesp, g_bSubstationNamePrefixSubcontrolArea);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("CIM/XMLװ����ϣ���ʱ%d����", nDur);
}

void CCIMXmlParserDoc::OnInputBlock()
{
	// TODO: �ڴ�����������������
	int		bClearDB, bTranPuRXVoltageHigh;
	float	fLowVThreshold;
	clock_t	dBeg, dEnd;
	int		nDur;

	CCim2PGSetDialog	dlg;
	if (dlg.DoModal() != IDOK)
		return;

	bClearDB=dlg.m_bClearMemDB;
	bTranPuRXVoltageHigh=dlg.m_bTranPuRXVoltageHigh;
	fLowVThreshold=dlg.m_fLowVThreshold;

	dBeg=clock();
	g_CimDataParser.SetExcludeSubcontrolArea(g_bNameByDesp, g_strExcludeSubcontrolAreaArray);
	g_CimDataParser.SetExcludeSubstation(g_strExcludeSubstationArray);

	g_CimDataParser.formBound(g_bNameByDesp);

	g_CimDataParser.FillMemDB(g_pPGBlock, bClearDB, g_bNameByDesp, fLowVThreshold, bTranPuRXVoltageHigh);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);

	PrintMessage("�����ϣ���ʱ%d����", nDur);
}

void CCIMXmlParserDoc::OnFormMeasurementTable()
{
	// TODO: �ڴ�����������������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt *.dat)|*.txt;*.TXT;*.dat;*.DAT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("�����ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	int	bOutSwitchYX=0, bOutCurrent=0;
	if (AfxMessageBox("�Ƿ������բң��", MB_YESNO|MB_SYSTEMMODAL) == IDYES)
		bOutSwitchYX=1;
	if (AfxMessageBox("�Ƿ��������ң��", MB_YESNO|MB_SYSTEMMODAL) == IDYES)
		bOutCurrent=1;

	g_CimDataParser.FormMeasurementTable(dlg.GetPathName(), bOutSwitchYX, bOutCurrent);
}

void CCIMXmlParserDoc::OnReadMeavalue()
{
	// TODO: �ڴ�����������������
	CString	fileExt="txt";
	CString	defaultFileName=_T("");
	CString	fileFilter="�ı��ļ�(*.txt *.dat)|*.txt;*.TXT;*.dat;*.DAT|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("���ı��ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	clock_t	dBeg, dEnd;
	int		nDur;
	dBeg=clock();
		g_CimDataParser.ReadMeasurementFile(dlg.GetPathName());
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("    ReadMeasurementFile����ʱ%d����\n", nDur);
}

void CCIMXmlParserDoc::OnAddOuteqgen()
{
	// TODO: �ڴ�����������������
	CEqgenDialog	dlg;
	dlg.DoModal();
}

void CCIMXmlParserDoc::OnNetTailor()
{
	// TODO: �ڴ�����������������
	CSubcontrolAreaDeleteDialog	dlg;
	dlg.DoModal();
}

void CCIMXmlParserDoc::OnPg2cimxml()
{
	// TODO: �ڴ�����������������
// 	int		nDev;
// 
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_COMPANY]; nDev++)
// 		memset(g_pPGBlock->m_CompanyArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDev++)
// 		memset(g_pPGBlock->m_SubcontrolAreaArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
// 		memset(g_pPGBlock->m_ACLineSegmentArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_DCLINESEGMENT]; nDev++)
// 		memset(g_pPGBlock->m_DCLineSegmentArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_LINE]; nDev++)
// 		memset(g_pPGBlock->m_LineArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nDev++)
// 		memset(g_pPGBlock->m_PowerTransformerArray[nDev].szResID, 0, MDB_CHARLEN);
// 
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_SUBSTATION]; nDev++)
// 		memset(g_pPGBlock->m_SubstationArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_TRANSFORMERWINDING]; nDev++)
// 		memset(g_pPGBlock->m_TransformerWindingArray[nDev].szResID, 0, MDB_CHARLEN);
// 
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_VOLTAGELEVEL]; nDev++)
// 		memset(g_pPGBlock->m_VoltageLevelArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nDev++)
// 		memset(g_pPGBlock->m_BusbarSectionArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; nDev++)
// 		memset(g_pPGBlock->m_SynchronousMachineArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; nDev++)
// 		memset(g_pPGBlock->m_EnergyConsumerArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; nDev++)
// 		memset(g_pPGBlock->m_ShuntCompensatorArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nDev++)
// 		memset(g_pPGBlock->m_SeriesCompensatorArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_BREAKER]; nDev++)
// 		memset(g_pPGBlock->m_BreakerArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_DISCONNECTOR]; nDev++)
// 		memset(g_pPGBlock->m_DisconnectorArray[nDev].szResID, 0, MDB_CHARLEN);
// 	for (nDev=0; nDev<g_pPGBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR]; nDev++)
// 		memset(g_pPGBlock->m_GroundDisconnectorArray[nDev].szResID, 0, MDB_CHARLEN);

 	clock_t	dBeg, dEnd;
 	int		nDur;
// 	dBeg=clock();
// 		PGFillResourceId(g_pPGBlock);
// 	dEnd=clock();
// 	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 	PrintMessage("    PGFormResourceId����ʱ %d ����\n", nDur);

	CString	fileExt=_T("xml");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("CIM/XML�ļ�(*.xml)|*.xml;*.XML|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����CIM/XML�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	dBeg=clock();
	char	szExec[260];
	sprintf(szExec, "%s/MemDBExport CimXml %s", g_szRunDir, dlg.GetPathName());
	StartProcess(szExec, g_szRunDir, SW_HIDE);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	PrintMessage("    MemDBExport����ʱ %d ����\n", nDur);
}
