#pragma once


// CCim2PGSetDialog �Ի���

class CCim2PGSetDialog : public CDialog
{
	DECLARE_DYNAMIC(CCim2PGSetDialog)

public:
	CCim2PGSetDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CCim2PGSetDialog();

// �Ի�������
	enum { IDD = IDD_CIM2PGSET_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedAddSubcontrolarea();
	afx_msg void OnBnClickedDelSubcontrolarea();
	afx_msg void OnBnClickedAddSubstation();
	afx_msg void OnBnClickedDelSubstation();
	afx_msg void OnBnClickedAddallSubstation();
	afx_msg void OnLbnSelchangeSubcontrolareaList();
	afx_msg void OnBnClickedSaveasExcel();

	DECLARE_MESSAGE_MAP()

private:
	void RefreshBoundLineList(void);
	void RefreshSubcontrolAreaList();
	void RefreshExSubcontrolAreaList();
	void RefreshExSubstationList();
public:
	BOOL m_bClearMemDB;
	BOOL m_bTranPuRXVoltageHigh;
	float m_fLowVThreshold;
	afx_msg void OnBnClickedShowonlyIncludearea();
	afx_msg void OnBnClickedShowonlyIncludesub();
};
