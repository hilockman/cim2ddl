// SetupDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CIMXmlParser.h"
#include "SetupDialog.h"


// CSetupDialog �Ի���

IMPLEMENT_DYNAMIC(CSetupDialog, CDialog)

CSetupDialog::CSetupDialog(CWnd* pParent /*=NULL*/) : CDialog(CSetupDialog::IDD, pParent)
{

}

CSetupDialog::~CSetupDialog()
{
}

void CSetupDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CSetupDialog, CDialog)
	ON_WM_DRAWITEM()
	ON_BN_CLICKED(IDC_PARSE_MEASUREMENT, &CSetupDialog::OnResolveSetupParam)
	ON_BN_CLICKED(IDC_PARSE_BYSAX, &CSetupDialog::OnResolveSetupParam)
	ON_BN_CLICKED(IDC_NAME_BYDESP, &CSetupDialog::OnResolveSetupParam)
	ON_BN_CLICKED(IDC_SUBSTATION_PREFIXSUBCONTROLAREA, &CSetupDialog::OnResolveSetupParam)
	ON_BN_CLICKED(IDCANCEL, &CSetupDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CSetupDialog ��Ϣ��������
BOOL CSetupDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CButton*	pButton;
	
	pButton=(CButton*)GetDlgItem(IDC_PARSE_MEASUREMENT);
	pButton->SetCheck(g_bParserMeasurement);

	pButton=(CButton*)GetDlgItem(IDC_PARSE_BYSAX);
	pButton->SetCheck(g_bParseBySax);

	pButton=(CButton*)GetDlgItem(IDC_NAME_BYDESP);
	pButton->SetCheck(g_bNameByDesp);

	pButton=(CButton*)GetDlgItem(IDC_SUBSTATION_PREFIXSUBCONTROLAREA);
	pButton->SetCheck(g_bSubstationNamePrefixSubcontrolArea);

	pButton=(CButton*)GetDlgItem(IDC_VOLTAGELEVEL_SHORTNAME);
	pButton->SetCheck(g_bVoltageLevelShortName);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CSetupDialog::OnResolveSetupParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton;

	pButton=(CButton*)GetDlgItem(IDC_PARSE_MEASUREMENT);
	g_bParserMeasurement=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_PARSE_BYSAX);
	g_bParseBySax=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_NAME_BYDESP);
	g_bNameByDesp=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_SUBSTATION_PREFIXSUBCONTROLAREA);
	g_bSubstationNamePrefixSubcontrolArea=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_VOLTAGELEVEL_SHORTNAME);
	g_bVoltageLevelShortName=pButton->GetCheck();

	SaveIni();
}

void CSetupDialog::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnCancel();
}
