// SubcontrolAreaDeleteDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CIMXmlParser.h"
#include "SubcontrolAreaDeleteDialog.h"


// CSubcontrolAreaDeleteDialog �Ի���

IMPLEMENT_DYNAMIC(CSubcontrolAreaDeleteDialog, CDialog)

CSubcontrolAreaDeleteDialog::CSubcontrolAreaDeleteDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CSubcontrolAreaDeleteDialog::IDD, pParent)
{
	m_strDelSubcontroalAreaArray.clear();
}

CSubcontrolAreaDeleteDialog::~CSubcontrolAreaDeleteDialog()
{
}

void CSubcontrolAreaDeleteDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CSubcontrolAreaDeleteDialog, CDialog)
	ON_BN_CLICKED(IDC_ADD, &CSubcontrolAreaDeleteDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CSubcontrolAreaDeleteDialog::OnBnClickedDel)
	ON_BN_CLICKED(IDC_DELETE, &CSubcontrolAreaDeleteDialog::OnBnClickedDelete)
END_MESSAGE_MAP()


// CSubcontrolAreaDeleteDialog ��Ϣ��������

BOOL CSubcontrolAreaDeleteDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CListBox*	pListBox;

	pListBox=(CListBox*)GetDlgItem(IDC_ALLDIV_LIST);
	pListBox->ResetContent();
	for (i=0; i<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; i++)
		pListBox->AddString(g_pPGBlock->m_SubcontrolAreaArray[i].szName);

	pListBox=(CListBox*)GetDlgItem(IDC_DELDIV_LIST);
	pListBox->ResetContent();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CSubcontrolAreaDeleteDialog::EraseSubstation(tagPGBlock* pBlock, const char* lpszSubName)
{
	register int	i;
	int		nRec;

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SUBSTATION])
	{
		if (strcmp(pBlock->m_SubstationArray[nRec].szName, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SUBSTATION, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_VOLTAGELEVEL])
	{
		if (strcmp(pBlock->m_VoltageLevelArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_VOLTAGELEVEL, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_BUSBARSECTION])
	{
		if (strcmp(pBlock->m_BusbarSectionArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_BUSBARSECTION, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE])
	{
		if (strcmp(pBlock->m_SynchronousMachineArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SYNCHRONOUSMACHINE, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_ENERGYCONSUMER])
	{
		if (strcmp(pBlock->m_EnergyConsumerArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_ENERGYCONSUMER, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR])
	{
		if (strcmp(pBlock->m_ShuntCompensatorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SHUNTCOMPENSATOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_SERIESCOMPENSATOR])
	{
		if (strcmp(pBlock->m_SeriesCompensatorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_SERIESCOMPENSATOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_BREAKER])
	{
		if (strcmp(pBlock->m_BreakerArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_BREAKER, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_DISCONNECTOR])
	{
		if (strcmp(pBlock->m_DisconnectorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_DISCONNECTOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_GROUNDDISCONNECTOR])
	{
		if (strcmp(pBlock->m_GroundDisconnectorArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_GROUNDDISCONNECTOR, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_TRANSFORMERWINDING])
	{
		if (strcmp(pBlock->m_TransformerWindingArray[nRec].szSub, lpszSubName) == 0)
		{
			PGRemoveRecord(pBlock, PG_TRANSFORMERWINDING, nRec);
		}
		else
		{
			nRec++;
		}
	}

	nRec=0;
	while (nRec < pBlock->m_nRecordNum[PG_ACLINESEGMENT])
	{
		if (strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubI, lpszSubName) == 0 || strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubJ, lpszSubName) == 0)
		{
			i=0;
			while (i < pBlock->m_nRecordNum[PG_LINEVERTEX])
			{
				if (strcmp(pBlock->m_LineVertexArray[i].szParent, pBlock->m_ACLineSegmentArray[nRec].szResID) == 0)
					PGRemoveRecord(pBlock, PG_LINEVERTEX, i);
				else
					i++;
			}

			i=0;
			while (i < pBlock->m_nRecordNum[PG_GRAPHATTR])
			{
				if (strcmp(pBlock->m_GraphAttrArray[i].szParentID, pBlock->m_ACLineSegmentArray[nRec].szResID) == 0)
					PGRemoveRecord(pBlock, PG_GRAPHATTR, i);
				else
					i++;
			}
		}

		if (strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubI, lpszSubName) == 0)
			memset(pBlock->m_ACLineSegmentArray[nRec].szSubI, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_ISUBSTATION));

		if (strcmp(pBlock->m_ACLineSegmentArray[nRec].szSubJ, lpszSubName) == 0)
			memset(pBlock->m_ACLineSegmentArray[nRec].szSubJ, 0, PGGetFieldLen(PG_ACLINESEGMENT, PG_ACLINESEGMENT_JSUBSTATION));

		if (strlen(pBlock->m_ACLineSegmentArray[nRec].szSubI) <= 0 && strlen(pBlock->m_ACLineSegmentArray[nRec].szSubJ) <= 0)
		{
			PGRemoveRecord(pBlock, PG_ACLINESEGMENT, nRec);
		}
		else
		{
			nRec++;
		}
	}
}

void CSubcontrolAreaDeleteDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CListBox*	pListBox;
	char		szSubcontrolArea[MDB_CHARLEN];
	int			nSelArray[1000];
	unsigned char	bExist=0;

	pListBox=(CListBox*)GetDlgItem(IDC_ALLDIV_LIST);
	int		nSelNum=pListBox->GetSelItems(1000, nSelArray);
	if (nSelNum <= 0)
		return;

	for (int nDiv=0; nDiv<nSelNum; nDiv++)
	{
		pListBox->GetText(nSelArray[nDiv], szSubcontrolArea);

		bExist=0;
		for (i=0; i<(int)m_strDelSubcontroalAreaArray.size(); i++)
		{
			if (strcmp(m_strDelSubcontroalAreaArray[i].c_str(), szSubcontrolArea) == 0)
			{
				bExist=1;
				break;
			}
		}
		if (!bExist)
		{
			m_strDelSubcontroalAreaArray.push_back(szSubcontrolArea);
		}
	}
	RefreshDelSubcontrolArea();
}

void CSubcontrolAreaDeleteDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	CListBox*	pListBox;
	char		szSubcontrolArea[MDB_CHARLEN];
	int			nSelArray[1000];

	pListBox=(CListBox*)GetDlgItem(IDC_DELDIV_LIST);
	int		nSelNum=pListBox->GetSelItems(1000, nSelArray);
	if (nSelNum <= 0)
		return;

	for (int nDiv=0; nDiv<nSelNum; nDiv++)
	{
		pListBox->GetText(nSelArray[nDiv], szSubcontrolArea);
		for (i=0; i<(int)m_strDelSubcontroalAreaArray.size(); i++)
		{
			if (strcmp(m_strDelSubcontroalAreaArray[i].c_str(), szSubcontrolArea) == 0)
			{
				m_strDelSubcontroalAreaArray.erase(m_strDelSubcontroalAreaArray.begin()+i);
				break;
			}
		}
	}
	RefreshDelSubcontrolArea();
}

void CSubcontrolAreaDeleteDialog::OnBnClickedDelete()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (AfxMessageBox("��ȷ��ɾ��ָ������", MB_YESNO|MB_SYSTEMMODAL) == IDNO)
		return;

	int		nDel, nDiv, nSub;
	char	szSub[MDB_CHARLEN];
	for (nDel=0; nDel<(int)m_strDelSubcontroalAreaArray.size(); nDel++)
	{
		for (nDiv=0; nDiv<g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA]; nDiv++)
		{
			if (strcmp(m_strDelSubcontroalAreaArray[nDel].c_str(), g_pPGBlock->m_SubcontrolAreaArray[nDiv].szName) != 0)
				continue;

			nSub=0;
			while (nSub<g_pPGBlock->m_nRecordNum[PG_SUBSTATION])
			{
				if (strcmp(g_pPGBlock->m_SubcontrolAreaArray[nDiv].szName, g_pPGBlock->m_SubstationArray[nSub].szSubcontrolArea) == 0)
				{
					PrintMessage("ɾ����վ:%s", g_pPGBlock->m_SubstationArray[nSub].szName);
					strcpy(szSub, g_pPGBlock->m_SubstationArray[nSub].szName);
					EraseSubstation(g_pPGBlock, szSub);
				}
				else
				{
					nSub++;
				}
			}
		}
	}

	for (nDel=0; nDel<(int)m_strDelSubcontroalAreaArray.size(); nDel++)
	{
		nDiv=0;
		while (nDiv < g_pPGBlock->m_nRecordNum[PG_SUBCONTROLAREA])
		{
			if (strcmp(g_pPGBlock->m_SubcontrolAreaArray[nDiv].szName, m_strDelSubcontroalAreaArray[nDel].c_str()) == 0)
			{
				PGRemoveRecord(g_pPGBlock, PG_SUBCONTROLAREA, nDiv);
			}
			else
			{
				nDiv++;
			}
		}
	}

	PGMaint(g_pPGBlock, 1);
}

void CSubcontrolAreaDeleteDialog::RefreshDelSubcontrolArea(void)
{
	register int	i;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_DELDIV_LIST);
	pListBox->ResetContent();

	for (i=0; i<(int)m_strDelSubcontroalAreaArray.size(); i++)
		pListBox->AddString(m_strDelSubcontroalAreaArray[i].c_str());
}
