
// CIMXmlParserView.h : CCIMXmlParserView ��Ľӿ�
//


#pragma once

class CCIMXmlParserView : public CListView
{
protected: // �������л�����
	CCIMXmlParserView();
	DECLARE_DYNCREATE(CCIMXmlParserView)

// ����
public:
	CCIMXmlParserDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
	virtual ~CCIMXmlParserView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg LRESULT OnClassChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSaveasExcel();
	afx_msg void OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
private:
	void Refresh(const int nClass);
	void DrawItem(const int nClass, NMLVDISPINFO* pDispInfo);
private:
	int m_nCurClass;
protected:
//	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
};

#ifndef _DEBUG  // CIMXmlParserView.cpp �еĵ��԰汾
inline CCIMXmlParserDoc* CCIMXmlParserView::GetDocument() const
{
	return reinterpret_cast<CCIMXmlParserDoc*>(m_pDocument);
}
#endif

