#pragma once

typedef	struct
{
	char	szResourceID[MDB_CHARLEN];
	char	szName[MDB_CHARLEN];
	char	szDesp[MDB_CHARLEN];

	char	szEquimentType[MDB_CHARLEN];
	char	szEquimentName[MDB_CHARLEN];			//	ʹ���豸��װ����
	char	szMeasurementType[MDB_CHARLEN];
	char	szMeasurementValue[MDB_CHARLEN];
}	tagMeasurementExchange;