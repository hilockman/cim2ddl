
// CIMXmlParser.cpp : ����Ӧ�ó��������Ϊ��
//

#include "stdafx.h"
#include <stdio.h>
#include "afxwinappex.h"
#include "CIMXmlParser.h"
#include "MainFrm.h"

#include "CIMXmlParserDoc.h"
#include "CIMXmlParserView.h"
#include "../../../Common/Excel/ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

static	char*	lpszIniFile="CIMXml2PGBlock.ini";

// CCIMXmlParserApp

BEGIN_MESSAGE_MAP(CCIMXmlParserApp, CWinAppEx)
	// �����ļ��ı�׼�ĵ�����
	ON_COMMAND(ID_FILE_NEW, &CWinAppEx::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, &CWinAppEx::OnFileOpen)
END_MESSAGE_MAP()


// CCIMXmlParserApp ����

CCIMXmlParserApp::CCIMXmlParserApp()
{

	m_bHiColorIcons = TRUE;

	// TODO: �ڴ˴����ӹ�����룬
	// ��������Ҫ�ĳ�ʼ�������� InitInstance ��
}

// Ψһ��һ�� CCIMXmlParserApp ����

CCIMXmlParserApp	theApp;
CCIMData			g_CimDataParser;
tagPGBlock*			g_pPGBlock;
char				g_szRunDir[260];

unsigned char				g_bParserMeasurement;
unsigned char				g_bParseBySax;
unsigned char				g_bNameByDesp;
unsigned char				g_bVoltageLevelShortName;
unsigned char				g_bSubstationNamePrefixSubcontrolArea;

std::vector<std::string>	g_strExcludeSubcontrolAreaArray;
std::vector<std::string>	g_strExcludeSubstationArray;
const	char*	g_lpszLogFile="CIMXmlParser.log";

// CCIMXmlParserApp ��ʼ��
extern	void	ClearLog(const char* lpszLogFile);

BOOL CCIMXmlParserApp::InitInstance()
{
	// ���һ�������� Windows XP �ϵ�Ӧ�ó����嵥ָ��Ҫ
	// ʹ�� ComCtl32.dll �汾 6 ����߰汾�����ÿ��ӻ���ʽ��
	//����Ҫ InitCommonControlsEx()�����򣬽��޷��������ڡ�
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// ��������Ϊ��������Ҫ��Ӧ�ó�����ʹ�õ�
	// �����ؼ��ࡣ
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();

	ClearLog(g_lpszLogFile);

	int		nArg=1;
	int		nMemID=0;
	unsigned char	bNameByDesp, bParseMeasurement, bUseSax, bEQGenOutnet, bSubstationNamePrefixBySubcontrolArea;
	char	szFileName[260];
	float	fLowVThreshold;
	std::vector<std::string>	strOutnetSubstationArray;

	bSubstationNamePrefixBySubcontrolArea=1;
	strOutnetSubstationArray.clear();
	if (__argc > nArg)	{	nMemID=atoi(__argv[nArg++]);				printf("nMemID=%d\n", nMemID);		}
	if (__argc > nArg)	{	strcpy(szFileName, __argv[nArg++]);			printf("szFileName=%s\n", szFileName);		}
	if (__argc > nArg)	{	bNameByDesp=atoi(__argv[nArg++]);			printf("bNameByDesp=%d\n", bNameByDesp);		}
	if (__argc > nArg)	{	bParseMeasurement=atoi(__argv[nArg++]);		printf("bParseMeasurement=%d\n", bParseMeasurement);		}
	if (__argc > nArg)	{	bUseSax=atoi(__argv[nArg++]);				printf("bUseSax=%d\n", bUseSax);		}
	if (__argc > nArg)	{	fLowVThreshold=(float)atof(__argv[nArg++]);	printf("VThread=%f\n", fLowVThreshold);	}
	if (__argc > nArg)	{	bEQGenOutnet=atoi(__argv[nArg++]);			printf("EQGenOutnet=%d\n", bEQGenOutnet);	}
	while (__argc > nArg)
		strOutnetSubstationArray.push_back(__argv[nArg++]);

	g_pPGBlock=(tagPGBlock*)Init_PGBlock(nMemID, 1);
	if (!g_pPGBlock)
	{
		AfxMessageBox("��ȡ�ڴ�����");
		return 0;
	}

	if (__argc > 1)
	{
		clock_t	dBeg, dEnd;
		int		nDur;
		dBeg=clock();

		if (g_CimDataParser.Parse(&g_CimDataParser, szFileName, bParseMeasurement, bUseSax, bNameByDesp))
		{
			dEnd=clock();
			nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
			printf("����CIM��ɣ���ʱ%d����\n", nDur);

			g_CimDataParser.FillMemDB(g_pPGBlock, 1, bNameByDesp, fLowVThreshold);
			g_CimDataParser.AddOutnetEQGen(g_pPGBlock, bEQGenOutnet, strOutnetSubstationArray);
			printf("���CIM��ɣ���ʱ%d����\n", nDur);
		}
		else
		{
			printf("����CIM����\n");
		}
		return FALSE;
	}

	GetCurrentDirectory(260, g_szRunDir);
	// ��ʼ�� OLE ��
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	ReadIni();

	AfxEnableControlContainer();

	HKEY	hAppKey;
	CString	strPrefix="software\\CIMXmlParser";
	int		nErr = RegOpenKeyEx(HKEY_CURRENT_USER, 
		strPrefix, 
		0, 
		KEY_ALL_ACCESS, 
		&hAppKey);
	if (ERROR_SUCCESS == nErr)
	{
		if (RegDeleteAllKeys(hAppKey, "CIMXmlParser") == ERROR_SUCCESS)
		{
			TRACE("Delete KEY: %s\n", "CIMXmlParser");
		}
	}
	RegCloseKey(hAppKey);

	// ��׼��ʼ��
	// ���δʹ����Щ���ܲ�ϣ����С
	// ���տ�ִ���ļ��Ĵ�С����Ӧ�Ƴ�����
	// ����Ҫ���ض���ʼ������
	// �������ڴ洢���õ�ע�����
	// TODO: Ӧ�ʵ��޸ĸ��ַ�����
	// �����޸�Ϊ��˾����֯��
	SetRegistryKey(_T("CIMXmlParser"));
	LoadStdProfileSettings(4);  // ���ر�׼ INI �ļ�ѡ��(���� MRU)

	InitContextMenuManager();

	InitKeyboardManager();

	InitTooltipManager();
	CMFCToolTipInfo ttParams;
	ttParams.m_bVislManagerTheme = TRUE;
	theApp.GetTooltipManager()->SetTooltipParams(AFX_TOOLTIP_TYPE_ALL, RUNTIME_CLASS(CMFCToolTipCtrl), &ttParams);

	// ע��Ӧ�ó�����ĵ�ģ�塣�ĵ�ģ��
	// �������ĵ�����ܴ��ں���ͼ֮�������
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
	    IDR_MAINFRAME, 
	    RUNTIME_CLASS(CCIMXmlParserDoc), 
	    RUNTIME_CLASS(CMainFrame),       // �� SDI ��ܴ���
	    RUNTIME_CLASS(CCIMXmlParserView));
	if (!pDocTemplate)
	{
		return FALSE;
	}
	AddDocTemplate(pDocTemplate);



	// ������׼������DDE�����ļ�������������
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);


	// ��������������ָ����������
	// �� /RegServer��/Register��/Unregserver �� /Unregister ����Ӧ�ó����򷵻� FALSE��
	if (!ProcessShellCommand(cmdInfo))
	{
		return FALSE;
	}

	// Ψһ��һ�������ѳ�ʼ���������ʾ����������и���
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	// �������к�׺ʱ�ŵ��� DragAcceptFiles
	//  �� SDI Ӧ�ó����У���Ӧ�� ProcessShellCommand ֮����
	return TRUE;
}


// CCIMXmlParserApp �Զ������/���淽��

void CCIMXmlParserApp::PreLoadState()
{
	BOOL bNameValid;
	CString strName;
	bNameValid = strName.LoadString(IDS_EDIT_MENU);
	ASSERT(bNameValid);
	GetContextMenuManager()->AddMenu(strName, IDR_POPUP_EDIT);
	bNameValid = strName.LoadString(IDS_EXPLORER);
	ASSERT(bNameValid);
	GetContextMenuManager()->AddMenu(strName, IDR_POPUP_EXPLORER);
}

void CCIMXmlParserApp::LoadCustomState()
{
}

void CCIMXmlParserApp::SaveCustomState()
{
}

// CCIMXmlParserApp ��Ϣ��������




int CCIMXmlParserApp::ExitInstance()
{
	// TODO: �ڴ�����ר�ô����/����û���
	Exit_PGBlock((char*)g_pPGBlock);

	return CWinAppEx::ExitInstance();
}

void	PrintMessage(char* pformat, ...)
{
	va_list args;
	va_start( args, pformat );

	CMainFrame*	pFrame=(CMainFrame*)theApp.GetMainWnd();

	char	szBuf[1024];
	vsprintf(szBuf, pformat, args);
	pFrame->m_wndOutput.AddString(szBuf);

	va_end(args);
}


int		ReadIni()
{
	char	szFileName[260];
	char	szLine[512];
	char*	lpszToken;
	int		nReadContent;
	FILE*	fp;


	g_bParserMeasurement=0;
	g_bVoltageLevelShortName=0;
	g_bParseBySax=0;
	g_bNameByDesp=0;
	g_bSubstationNamePrefixSubcontrolArea=0;
	g_strExcludeSubcontrolAreaArray.clear();
	g_strExcludeSubstationArray.clear();

	sprintf(szFileName, "%s/%s", g_szRunDir, lpszIniFile);
	fp=fopen(szFileName, "r");
	if (fp == NULL)
		return 0;

	nReadContent=0;
	while (!feof(fp))
	{
		memset(szLine, 0, 512);
		fgets(szLine, 512, fp);
		if (strstr(szLine, "<MainConfig>") != NULL)
		{
			nReadContent=1;
			continue;
		}
		if (strstr(szLine, "<SubcontrolAreaConfig>") != NULL)
		{
			nReadContent=2;
			continue;
		}
		if (strstr(szLine, "<SubstationConfig>") != NULL)
		{
			nReadContent=3;
			continue;
		}
		if (strstr(szLine, "<AC2DCLineConfig>") != NULL)
		{
			nReadContent=4;
			continue;
		}
		else if (strstr(szLine, "</MainConfig>") != NULL ||
			strstr(szLine, "</SubcontrolAreaConfig>") != NULL ||
			strstr(szLine, "</SubstationConfig>") != NULL ||
			strstr(szLine, "</AC2DCLineConfig>") != NULL)
		{
			nReadContent=0;
			continue;
		}

		if (nReadContent == 1)
		{
			if (strstr(szLine, "ParserMeasurement") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_bParserMeasurement=atoi(lpszToken);
					}
				}
			}
			if (strstr(szLine, "ParseBySax") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_bParseBySax=atoi(lpszToken);
					}
				}
			}
			if (strstr(szLine, "VoltageLevelShortName") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_bVoltageLevelShortName=atoi(lpszToken);
					}
				}
			}
			if (strstr(szLine, "NameByDesp") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_bNameByDesp=atoi(lpszToken);
					}
				}
			}
			if (strstr(szLine, "SubstationNamePrefixBySubcontrolArea") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_bSubstationNamePrefixSubcontrolArea=atoi(lpszToken);
					}
				}
			}
			continue;
		}
		if (nReadContent == 2)
		{
			if (strstr(szLine, "ExcludeSubcontrolArea") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_strExcludeSubcontrolAreaArray.push_back(lpszToken);
					}
				}
			}
			continue;
		}
		if (nReadContent == 3)
		{
			if (strstr(szLine, "ExcludeSubstation") != NULL)
			{
				lpszToken=strtok(szLine, " \t\n=");
				if (lpszToken != NULL)
				{
					lpszToken=strtok(NULL, " \t\n=");
					if (lpszToken != NULL)
					{
						g_strExcludeSubstationArray.push_back(lpszToken);
					}
				}
			}
			continue;
		}
	}
	fclose(fp);

	return 1;
}

void	SaveIni()
{
	register int	i;
	char	szFileName[260];
	FILE*	fp;

	sprintf(szFileName, "%s/%s", g_szRunDir, lpszIniFile);
	fp=fopen(szFileName, "w");
	if (fp == NULL)
		return;

	fprintf(fp, "<MainConfig>\n");
	fprintf(fp, "ParserMeasurement=%d\n",	g_bParserMeasurement);
	fprintf(fp, "ParseBySax=%d\n",			g_bParseBySax);
	fprintf(fp, "VoltageLevelShortName=%d\n", g_bVoltageLevelShortName);
	fprintf(fp, "NameByDesp=%d\n",			g_bNameByDesp);
	fprintf(fp, "SubstationNamePrefixBySubcontrolArea=%d\n",			g_bSubstationNamePrefixSubcontrolArea);
	fprintf(fp, "</MainConfig>\n");


	fprintf(fp, "<SubcontrolAreaConfig>\n");
	for (i=0; i<(int)g_strExcludeSubcontrolAreaArray.size(); i++)
		fprintf(fp, "ExcludeSubcontrolArea%d=%s\n", i+1, g_strExcludeSubcontrolAreaArray[i].c_str());
	fprintf(fp, "</SubcontrolAreaConfig>\n");

	fprintf(fp, "<SubstationConfig>\n");
	for (i=0; i<(int)g_strExcludeSubstationArray.size(); i++)
		fprintf(fp, "ExcludeSubstation%d=%s\n", i+1, g_strExcludeSubstationArray[i].c_str());
	fprintf(fp, "</SubstationConfig>\n");

	fflush(fp);
	fclose(fp);
}