
// CIMXmlParser.h : CIMXmlParser Ӧ�ó������ͷ�ļ�
//
#pragma once

#ifndef __AFXWIN_H__
#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"       // ������


// CCIMXmlParserApp:
// �йش����ʵ�֣������ CIMXmlParser.cpp
//

#define		UM_CLASS_CHANGED	WM_APP+100
#define		UM_MESSAGE			WM_APP+101

class CCIMXmlParserApp : public CWinAppEx
{
public:
	CCIMXmlParserApp();


// ��д
public:
	virtual BOOL InitInstance();

// ʵ��
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();
};

extern	CCIMXmlParserApp	theApp;
extern	CCIMData			g_CimDataParser;
extern	tagPGBlock*			g_pPGBlock;
extern	char				g_szRunDir[260];

extern	unsigned char				g_bParserMeasurement;
extern	unsigned char				g_bParseBySax;
extern	unsigned char				g_bNameByDesp;
extern	unsigned char				g_bVoltageLevelShortName;
extern	unsigned char				g_bSubstationNamePrefixSubcontrolArea;

extern	std::vector<std::string>	g_strExcludeSubcontrolAreaArray;
extern	std::vector<std::string>	g_strExcludeSubstationArray;

extern	void	PrintMessage(char* pformat, ...);
extern	int		ReadIni();
extern	void	SaveIni();
extern	void	SaveListAsExcel(CListCtrl* pListCtrl, const char* lpszExcelSheetName, const char* lpszFileName, const unsigned char bShowExcel);

extern	LONG	RegDeleteAllKeys(HKEY hKeyDelete, LPCTSTR pszSubKey);
extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);

extern	void	Log(const char* lpszLogFile, char* pformat, ...);
