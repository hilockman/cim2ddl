#pragma once
#include "afxwin.h"


// CSetupDialog �Ի���

class CSetupDialog : public CDialog
{
	DECLARE_DYNAMIC(CSetupDialog)

public:
	CSetupDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CSetupDialog();

private:
// �Ի�������
	enum { IDD = IDC_SETUP_DIALOG };
	CCheckListBox m_ExSubstationListBox;
	CCheckListBox m_SubcontrolAreaListBox;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnResolveSetupParam();
	afx_msg void OnBnClickedCancel();
	DECLARE_MESSAGE_MAP()
public:
};
