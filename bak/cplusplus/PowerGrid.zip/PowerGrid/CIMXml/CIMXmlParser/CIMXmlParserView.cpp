
// CIMXmlParserView.cpp : CCIMXmlParserView ���ʵ��
//

#include "stdafx.h"
#include "CIMXmlParser.h"

#include "CIMXmlParserDoc.h"
#include "CIMXmlParserView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCIMXmlParserView

IMPLEMENT_DYNCREATE(CCIMXmlParserView, CListView)

BEGIN_MESSAGE_MAP(CCIMXmlParserView, CListView)
	ON_MESSAGE(UM_CLASS_CHANGED,	OnClassChanged)
	ON_COMMAND(ID_SAVEAS_EXCEL, &CCIMXmlParserView::OnSaveasExcel)
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, &CCIMXmlParserView::OnLvnGetdispinfo)
END_MESSAGE_MAP()

// CCIMXmlParserView ����/����

CCIMXmlParserView::CCIMXmlParserView()
{
	// TODO: �ڴ˴����ӹ������
	m_nCurClass=-1;
}

CCIMXmlParserView::~CCIMXmlParserView()
{
}

BOOL CCIMXmlParserView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ
	cs.style &= ~LVS_TYPEMASK;
	cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT | LVS_OWNERDATA;// | LVS_OWNERDRAWFIXED;
	return CListView::PreCreateWindow(cs);
}

void CCIMXmlParserView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();


	// TODO: ���� GetListCtrl() ֱ�ӷ��� ListView ���б��ؼ���
	//  �Ӷ������������ ListView��

	GetListCtrl().SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void CCIMXmlParserView::OnRButtonUp(UINT nFlags, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CCIMXmlParserView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CCIMXmlParserView ���

#ifdef _DEBUG
void CCIMXmlParserView::AssertValid() const
{
	CListView::AssertValid();
}

void CCIMXmlParserView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CCIMXmlParserDoc* CCIMXmlParserView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCIMXmlParserDoc)));
	return (CCIMXmlParserDoc*)m_pDocument;
}
#endif //_DEBUG


// CCIMXmlParserView ��Ϣ��������

void CCIMXmlParserView::Refresh(const int nClass)
{
	register int	i;
	int			nColWidth, nHeaderWidth;
	int			nRowNum, nColNum;

	nRowNum=nColNum=0;
	while (GetListCtrl().DeleteColumn(0));
	if (!GetListCtrl().DeleteAllItems())
		return;

	GetListCtrl().InsertColumn(0, "���");
	GetListCtrl().SetColumnWidth(0, 50);
	switch (nClass)
	{
	case	CIM_BasePower:	//	BaseVoltage
		nRowNum=1;
		break;
	case	CIM_BaseVoltage:	//	BaseVoltage
		nRowNum=(int)g_CimDataParser.m_BaseVoltageArray.size();
		break;
	case	CIM_SubcontrolArea:	//	SubControlArea
		nRowNum=(int)g_CimDataParser.m_SubcontrolAreaArray.size();
		break;
	case	CIM_Substation:	//	Substation
		nRowNum=(int)g_CimDataParser.m_SubstationArray.size();
		break;
	case	CIM_VoltageLevel:	//	VoltageLevel
		nRowNum=(int)g_CimDataParser.m_VoltageLevelArray.size();
		break;
	case	CIM_Bay:	//	Bay
		nRowNum=(int)g_CimDataParser.m_BayArray.size();
		break;
	case	CIM_ACLineSegment:	//	ACLineSegment
		nRowNum=(int)g_CimDataParser.m_ACLineSegmentArray.size();
		break;
	case	CIM_DCLineSegment:	//	DCLineSegment
		nRowNum=(int)g_CimDataParser.m_DCLineSegmentArray.size();
		break;
	case	CIM_RectifierInverter:	//	RectifierInverter
		nRowNum=(int)g_CimDataParser.m_RectifierInverterArray.size();
		break;
	case	CIM_TransformerWinding:	//	TransformerWinding
		nRowNum=(int)g_CimDataParser.m_TransformerWindingArray.size();
		break;
	case	CIM_PowerTransformer:	//	PowerTransformer
		nRowNum=(int)g_CimDataParser.m_PowerTransformerArray.size();
	case	CIM_TapChanger:	//	TapChanger
		nRowNum=(int)g_CimDataParser.m_TapChangerArray.size();
		break;
	case	CIM_SynchronousMachine:	//	SynchronousMachine
		nRowNum=(int)g_CimDataParser.m_SynchronousMachineArray.size();
		break;
	case	CIM_ThermalGeneratingUnit:	//	ThermalGeneratingUnit
		nRowNum=(int)g_CimDataParser.m_ThermalGeneratingUnitArray.size();
		break;
	case	CIM_HydroGeneratingUnit:	//	HydroGeneratingUnit
		nRowNum=(int)g_CimDataParser.m_HydroGeneratingUnitArray.size();
		break;
	case	CIM_EnergyConsumer:	//	EnergyConsumer
		nRowNum=(int)g_CimDataParser.m_EnergyConsumerArray.size();
		break;
	case	CIM_Compensator:	//	Compensator
		nRowNum=(int)g_CimDataParser.m_CompensatorArray.size();
		break;
	case	CIM_BusbarSection:	//	BusbarSection
		nRowNum=(int)g_CimDataParser.m_BusbarSectionArray.size();
		break;
	case	CIM_Breaker:	//	Breaker
		nRowNum=(int)g_CimDataParser.m_BreakerArray.size();
		break;
	case	CIM_DCSwitch:
	case	CIM_Disconnector:	//	Disconnector
		nRowNum=(int)g_CimDataParser.m_DisconnectorArray.size();
		break;
	case	CIM_GroundDisconnector:	//	GroundDisconnector
		nRowNum=(int)g_CimDataParser.m_GroundDisconnectorArray.size();
		break;
	case	CIM_Terminal:	//	Terminal
		nRowNum=(int)g_CimDataParser.m_TerminalArray.size();
		break;
	case	CIM_ConnectivityNode:	//	ConnectivityNode
		nRowNum=(int)g_CimDataParser.m_ConnectivityNodeArray.size();
		break;
	case	CIM_MeasurementType:	//	��������
		nRowNum=(int)g_CimDataParser.m_MeasurementTypeArray.size();
		break;
	case	CIM_MeasurementSource:	//	������Դ
		nRowNum=(int)g_CimDataParser.m_MeasurementSourceArray.size();
		break;
	case	CIM_MeasurementValue:	//	����ֵ
		nRowNum=(int)g_CimDataParser.m_MeasurementValueArray.size();
		break;
	case	CIM_Measurement:	//	����
		nRowNum=(int)g_CimDataParser.m_MeasurementArray.size();
		break;
	case	CIM_Analog:	//	ң��
		nRowNum=(int)g_CimDataParser.m_AnalogArray.size();
		break;
	case	CIM_Discrete:	//	ң��
		nRowNum=(int)g_CimDataParser.m_DiscreteArray.size();
		break;
	case	CIM_LimitSet:	//	LimitSets
		nRowNum=(int)g_CimDataParser.m_LimitSetArray.size();
		break;
	case	CIM_Limit:	//	Limits
		nRowNum=(int)g_CimDataParser.m_LimitArray.size();
		break;
	default:
		break;
	}

	nColNum=g_CimDataParser.GetCIMTableFieldNum(nClass);
	for (i=0; i<nColNum; i++)
		GetListCtrl().InsertColumn(i+1, g_CimDataParser.GetCIMTableFieldDesp(nClass, i));

	GetListCtrl().SetItemCount(nRowNum);	//force redraw
	GetListCtrl().SetItemState(0, LVIS_SELECTED, 0xffff);
	GetListCtrl().EnsureVisible(0, FALSE);

	for (i=1; i<=nColNum; i++)
	{
		nColWidth=nHeaderWidth=0;
		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = GetListCtrl().GetColumnWidth(i);
		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =GetListCtrl().GetColumnWidth(i);
		GetListCtrl().SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}

}
// 
// void CCIMXmlParserView::Refresh(const int nClass)
// {
// 	register int	i;
// 	char		szBuf[260];
// 	int			nCol, nColWidth, nHeaderWidth;
// 	int			nRowNum, nColNum;
// 
// 	if (nClass < 0)
// 	{
// 		return;
// 	}
// 
// 	nRowNum=nColNum=0;
// 	while (GetListCtrl().DeleteColumn(0));
// 	if (!GetListCtrl().DeleteAllItems())
// 	{
// 		return;
// 	}
// 
// 	GetListCtrl().InsertColumn(0, "���");
// 	GetListCtrl().SetColumnWidth(0, 50);
// 	switch (nClass)
// 	{
// 	case	CIM_BasePower:	//	BaseVoltage
// 		nRowNum=1;
// 		nColNum=sizeof(g_BasePowerAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_BasePowerAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<nRowNum; i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BasePower.szResourceID);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_BasePower.fBasePower);					GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 
// 		break;
// 	case	CIM_BaseVoltage:	//	BaseVoltage
// 		nRowNum=(int)g_CimDataParser.m_BaseVoltageArray.size();
// 		nColNum=sizeof(g_BaseVoltageAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_BaseVoltageAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<nRowNum; i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BaseVoltageArray[i].szResourceID);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_BaseVoltageArray[i].fNominalVoltage);				GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 
// 		break;
// 	case	CIM_SubcontrolArea:	//	SubControlArea
// 		nRowNum=(int)g_CimDataParser.m_SubcontrolAreaArray.size();
// 		nColNum=sizeof(g_SubcontrolAreaAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_SubcontrolAreaAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_SubcontrolAreaArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubcontrolAreaArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubcontrolAreaArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubcontrolAreaArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubcontrolAreaArray[i].szAlias);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_SubcontrolAreaArray[i].bExclude);				GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_Substation:	//	Substation
// 		nRowNum=(int)g_CimDataParser.m_SubstationArray.size();
// 		nColNum=sizeof(g_SubstationAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_SubstationAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_SubstationArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubstationArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubstationArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubstationArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SubstationArray[i].szAlias);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_SubstationArray[i].szSubcontrolAreaTag, g_CimDataParser.m_SubstationArray[i].szSubcontrolArea);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_SubstationArray[i].bExclude);																GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_VoltageLevel:	//	VoltageLevel
// 		nRowNum=(int)g_CimDataParser.m_VoltageLevelArray.size();
// 		nColNum=sizeof(g_VoltageLevelAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_VoltageLevelAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_VoltageLevelArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_VoltageLevelArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_VoltageLevelArray[i].szName);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_VoltageLevelArray[i].fHLimit);															GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_VoltageLevelArray[i].fLLimit);															GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_VoltageLevelArray[i].szSubstationTag, g_CimDataParser.m_VoltageLevelArray[i].szSub);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%.1f]", g_CimDataParser.m_VoltageLevelArray[i].szBaseVoltageTag, g_CimDataParser.m_VoltageLevelArray[i].fNominal);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_Bay:	//	Bay
// 		nRowNum=(int)g_CimDataParser.m_BayArray.size();
// 		nColNum=sizeof(g_BayAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_BayAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_BayArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BayArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BayArray[i].szName);
// 
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_BayArray[i].szSubstationTag, g_CimDataParser.m_BayArray[i].szSub);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_BayArray[i].szVoltageTag, g_CimDataParser.m_BayArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_ACLineSegment:	//	ACLineSegment
// 		nRowNum=(int)g_CimDataParser.m_ACLineSegmentArray.size();
// 		nColNum=sizeof(g_ACLineSegmentAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_ACLineSegmentAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_ACLineSegmentArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szAlias);
// 
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fR);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fX);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fG);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fB);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fR0);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fX0);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fG0);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_ACLineSegmentArray[i].fB0);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szParentTag);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_ACLineSegmentArray[i].szTerminalTag[0], g_CimDataParser.m_ACLineSegmentArray[i].szNode[0]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_ACLineSegmentArray[i].szTerminalTag[1], g_CimDataParser.m_ACLineSegmentArray[i].szNode[1]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szSub[0]);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szSub[1]);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szVolt[0]);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ACLineSegmentArray[i].szVolt[1]);
// 		}
// 		break;
// 	case	CIM_DCLineSegment:	//	DCLineSegment
// 		nRowNum=(int)g_CimDataParser.m_DCLineSegmentArray.size();
// 		nColNum=sizeof(g_DCLineSegmentAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_DCLineSegmentAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_DCLineSegmentArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szAlias);
// 
// 			sprintf(szBuf, "%f", g_CimDataParser.m_DCLineSegmentArray[i].fL);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_DCLineSegmentArray[i].fR);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szParentTag);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_DCLineSegmentArray[i].szTerminalTag[0], g_CimDataParser.m_DCLineSegmentArray[i].szNode[0]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_DCLineSegmentArray[i].szTerminalTag[1], g_CimDataParser.m_DCLineSegmentArray[i].szNode[1]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szSub[0]);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szSub[1]);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szVolt[0]);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DCLineSegmentArray[i].szVolt[1]);
// 		}
// 		break;
// 	case	CIM_RectifierInverter:	//	RectifierInverter
// 		nRowNum=(int)g_CimDataParser.m_RectifierInverterArray.size();
// 		nColNum=sizeof(g_RectifierInverterAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_RectifierInverterAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_RectifierInverterArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_RectifierInverterArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_RectifierInverterArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_RectifierInverterArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_RectifierInverterArray[i].szAlias);
// 
// 			sprintf(szBuf, "%f", g_CimDataParser.m_RectifierInverterArray[i].fRatedKV);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_RectifierInverterArray[i].nBridges);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			sprintf(szBuf, "%f", g_CimDataParser.m_RectifierInverterArray[i].fCommutatingReactance);																									GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_RectifierInverterArray[i].szParentTag, g_CimDataParser.m_RectifierInverterArray[i].szSub);																GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_RectifierInverterArray[i].szTerminalTag[0], g_CimDataParser.m_RectifierInverterArray[i].szVolt[0], g_CimDataParser.m_RectifierInverterArray[i].szNode[0]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_RectifierInverterArray[i].szTerminalTag[1], g_CimDataParser.m_RectifierInverterArray[i].szVolt[1], g_CimDataParser.m_RectifierInverterArray[i].szNode[1]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_RectifierInverterArray[i].szTerminalTag[2], g_CimDataParser.m_RectifierInverterArray[i].szVolt[2], g_CimDataParser.m_RectifierInverterArray[i].szNode[2]);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_TransformerWinding:	//	TransformerWinding
// 		nRowNum=(int)g_CimDataParser.m_TransformerWindingArray.size();
// 		nColNum=sizeof(g_TransformerWindingAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_TransformerWindingAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_TransformerWindingArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TransformerWindingArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TransformerWindingArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TransformerWindingArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TransformerWindingArray[i].szAlias);
// 
// 			sprintf(szBuf, "%f", g_CimDataParser.m_TransformerWindingArray[i].fR);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_TransformerWindingArray[i].fX);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_TransformerWindingArray[i].fX0);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_TransformerWindingArray[i].fRatedKV);GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_TransformerWindingArray[i].fRatedMW);GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_TransformerWindingArray[i].szParentTag, g_CimDataParser.m_TransformerWindingArray[i].szSub, g_CimDataParser.m_TransformerWindingArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_TransformerWindingArray[i].szPowerTransformerTag, g_CimDataParser.m_TransformerWindingArray[i].szPowerTransformer);								GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_TransformerWindingArray[i].szTerminalTag, g_CimDataParser.m_TransformerWindingArray[i].szNode);													GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TransformerWindingArray[i].szTapChanger);
// 		}
// 		break;
// 	case	CIM_PowerTransformer:	//	PowerTransformer
// 		nRowNum=(int)g_CimDataParser.m_PowerTransformerArray.size();
// 		nColNum=sizeof(g_PowerTransformerAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_PowerTransformerAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_PowerTransformerArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_PowerTransformerArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_PowerTransformerArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_PowerTransformerArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_PowerTransformerArray[i].szAlias);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_PowerTransformerArray[i].szParentTag, g_CimDataParser.m_PowerTransformerArray[i].szSub);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_TapChanger:	//	TapChanger
// 		nRowNum=(int)g_CimDataParser.m_TapChangerArray.size();
// 		nColNum=sizeof(g_TapChangerAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_TapChangerAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_TapChangerArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TapChangerArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TapChangerArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TapChangerArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TapChangerArray[i].szAlias);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_TapChangerArray[i].nHighStep);				GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_TapChangerArray[i].nLowStep);				GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_TapChangerArray[i].nNeutralStep);			GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_TapChangerArray[i].nNormalStep);				GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%f", g_CimDataParser.m_TapChangerArray[i].fStepVoltageIncrement);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TapChangerArray[i].szTransformerWindingTag);
// 		}
// 		break;
// 	case	CIM_SynchronousMachine:	//	SynchronousMachine
// 		nRowNum=(int)g_CimDataParser.m_SynchronousMachineArray.size();
// 		nColNum=sizeof(g_SynchronousMachineAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_SynchronousMachineAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_SynchronousMachineArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SynchronousMachineArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SynchronousMachineArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SynchronousMachineArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SynchronousMachineArray[i].szAlias);
// 
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_SynchronousMachineArray[i].szParentTag, g_CimDataParser.m_SynchronousMachineArray[i].szSub, g_CimDataParser.m_SynchronousMachineArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_SynchronousMachineArray[i].fMvrate);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_SynchronousMachineArray[i].fMaxQ);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_SynchronousMachineArray[i].szUnitTag);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_SynchronousMachineArray[i].szTerminalTag, g_CimDataParser.m_SynchronousMachineArray[i].szNode);													GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_EnergyConsumer:	//	EnergyConsumer
// 		nRowNum=(int)g_CimDataParser.m_EnergyConsumerArray.size();
// 		nColNum=sizeof(g_EnergyConsumerAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_EnergyConsumerAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_EnergyConsumerArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_EnergyConsumerArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_EnergyConsumerArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_EnergyConsumerArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_EnergyConsumerArray[i].szAlias);
// 
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_EnergyConsumerArray[i].pfixedPct);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_EnergyConsumerArray[i].qfixedPct);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_EnergyConsumerArray[i].pFexp);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_EnergyConsumerArray[i].qFexp);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_EnergyConsumerArray[i].szParentTag, g_CimDataParser.m_EnergyConsumerArray[i].szSub, g_CimDataParser.m_EnergyConsumerArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_EnergyConsumerArray[i].szTerminalTag, g_CimDataParser.m_EnergyConsumerArray[i].szNode);												GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_Compensator:	//	Compensator
// 		nRowNum=(int)g_CimDataParser.m_CompensatorArray.size();
// 		nColNum=sizeof(g_CompensatorAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_CompensatorAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_CompensatorArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_CompensatorArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_CompensatorArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_CompensatorArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_CompensatorArray[i].szAlias);
// 
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_CompensatorArray[i].fMvar);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_CompensatorArray[i].fNomV);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_CompensatorArray[i].szParentTag, g_CimDataParser.m_CompensatorArray[i].szSub, g_CimDataParser.m_CompensatorArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_CompensatorArray[i].szTerminalTag, g_CimDataParser.m_CompensatorArray[i].szNode[0]);												GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_BusbarSection:	//	BusbarSection
// 		nRowNum=(int)g_CimDataParser.m_BusbarSectionArray.size();
// 		nColNum=sizeof(g_BusbarSectionAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_BusbarSectionAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_BusbarSectionArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BusbarSectionArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BusbarSectionArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BusbarSectionArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BusbarSectionArray[i].szAlias);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_BusbarSectionArray[i].szParentTag, g_CimDataParser.m_BusbarSectionArray[i].szSub, g_CimDataParser.m_BusbarSectionArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_BusbarSectionArray[i].szTerminalTag, g_CimDataParser.m_BusbarSectionArray[i].szNode);											GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_Breaker:	//	Breaker
// 		nRowNum=(int)g_CimDataParser.m_BreakerArray.size();
// 		nColNum=sizeof(g_BreakerAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_BreakerAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_BreakerArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BreakerArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BreakerArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BreakerArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_BreakerArray[i].szAlias);
// 
// 			sprintf(szBuf, "%d", g_CimDataParser.m_BreakerArray[i].bOpen);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_BreakerArray[i].szParentTag, g_CimDataParser.m_BreakerArray[i].szSub, g_CimDataParser.m_BreakerArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_BreakerArray[i].szTerminalTag[0], g_CimDataParser.m_BreakerArray[i].szNode[0]);									GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_BreakerArray[i].szTerminalTag[1], g_CimDataParser.m_BreakerArray[i].szNode[1]);									GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_Disconnector:	//	Disconnector
// 		nRowNum=(int)g_CimDataParser.m_DisconnectorArray.size();
// 		nColNum=sizeof(g_DisconnectorAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_DisconnectorAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_DisconnectorArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DisconnectorArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DisconnectorArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DisconnectorArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DisconnectorArray[i].szAlias);
// 
// 			sprintf(szBuf, "%d", g_CimDataParser.m_DisconnectorArray[i].bOpen);			GetListCtrl().SetItemText(i, nCol++, szBuf);
// 
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_DisconnectorArray[i].szParentTag, g_CimDataParser.m_DisconnectorArray[i].szSub, g_CimDataParser.m_DisconnectorArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_DisconnectorArray[i].szTerminalTag[0], g_CimDataParser.m_DisconnectorArray[i].szNode[0]);									GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_DisconnectorArray[i].szTerminalTag[1], g_CimDataParser.m_DisconnectorArray[i].szNode[1]);									GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_GroundDisconnector:	//	GroundDisconnector
// 		nRowNum=(int)g_CimDataParser.m_GroundDisconnectorArray.size();
// 		nColNum=sizeof(g_GroundDisconnectorAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_GroundDisconnectorAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_GroundDisconnectorArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_GroundDisconnectorArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_GroundDisconnectorArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_GroundDisconnectorArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_GroundDisconnectorArray[i].szAlias);
// 			sprintf(szBuf, "%d", g_CimDataParser.m_GroundDisconnectorArray[i].bOpen);		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_GroundDisconnectorArray[i].szParentTag, g_CimDataParser.m_GroundDisconnectorArray[i].szSub, g_CimDataParser.m_GroundDisconnectorArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_GroundDisconnectorArray[i].szTerminalTag, g_CimDataParser.m_GroundDisconnectorArray[i].szNode);													GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_Terminal:	//	Terminal
// 		nRowNum=(int)g_CimDataParser.m_TerminalArray.size();
// 		nColNum=sizeof(g_TerminalAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_TerminalAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_TerminalArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TerminalArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_TerminalArray[i].szName);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_TerminalArray[i].szParentTag, g_CimDataParser.m_TerminalArray[i].szSub, g_CimDataParser.m_TerminalArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_TerminalArray[i].szNodeTag, g_CimDataParser.m_TerminalArray[i].szNode);											GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	case	CIM_ConnectivityNode:	//	ConnectivityNode
// 		nRowNum=(int)g_CimDataParser.m_ConnectivityNodeArray.size();
// 		nColNum=sizeof(g_ConnectivityNodeAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_ConnectivityNodeAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_ConnectivityNodeArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ConnectivityNodeArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_ConnectivityNodeArray[i].szName);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_ConnectivityNodeArray[i].szParentTag, g_CimDataParser.m_ConnectivityNodeArray[i].szSub, g_CimDataParser.m_ConnectivityNodeArray[i].szVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 
// 	case	CIM_MeasurementType:	//	��������
// 		nRowNum=(int)g_CimDataParser.m_MeasurementTypeArray.size();
// 		nColNum=sizeof(g_MeasurementTypeAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_MeasurementTypeAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_MeasurementTypeArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementTypeArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementTypeArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementTypeArray[i].szDesp);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementTypeArray[i].szAlias);
// 		}
// 		break;
// 	case	CIM_MeasurementSource:	//	������Դ
// 		nRowNum=(int)g_CimDataParser.m_MeasurementSourceArray.size();
// 		nColNum=sizeof(g_MeasurementSourceAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_MeasurementSourceAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_MeasurementSourceArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementSourceArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementSourceArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementSourceArray[i].szDesp);
// 		}
// 		break;
// 	case	CIM_MeasurementValue:	//	����ֵ
// 		nRowNum=(int)g_CimDataParser.m_MeasurementValueArray.size();
// 		nColNum=sizeof(g_MeasurementValueAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_MeasurementValueAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_MeasurementValueArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementValueArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementValueArray[i].szMeasurementValue);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementValueArray[i].szMeasurementTag);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementValueArray[i].szMeasurementSourceTag);
// 		}
// 		break;
// 	case	CIM_Measurement:	//	����
// 		nRowNum=(int)g_CimDataParser.m_MeasurementArray.size();
// 		nColNum=sizeof(g_MeasurementAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_MeasurementAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_MeasurementArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementArray[i].szDesp);
// 			sprintf(szBuf, "%s[%s.%s.%s]", g_CimDataParser.m_MeasurementArray[i].szTerminalTag, g_CimDataParser.m_MeasurementArray[i].szSub, g_CimDataParser.m_MeasurementArray[i].szVolt, g_CimDataParser.m_MeasurementArray[i].szTerminal);GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_MeasurementArray[i].szEquimentTag, g_CimDataParser.m_MeasurementArray[i].szEquimentType, g_CimDataParser.m_MeasurementArray[i].szEquimentName);								GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_MeasurementArray[i].szMeasurementTypeTag, g_CimDataParser.m_MeasurementArray[i].szMeasurementType);																		GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_MeasurementArray[i].szMeasurementValue);
// 		}
// 		break;
// 	case	CIM_Analog:	//	ң��
// 		nRowNum=(int)g_CimDataParser.m_AnalogArray.size();
// 		nColNum=sizeof(g_AnalogAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_AnalogAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_AnalogArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_AnalogArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_AnalogArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_AnalogArray[i].szDesp);
// 			sprintf(szBuf, "%s[%s.%s.%s]", g_CimDataParser.m_AnalogArray[i].szTerminalTag, g_CimDataParser.m_AnalogArray[i].szSub, g_CimDataParser.m_AnalogArray[i].szVolt, g_CimDataParser.m_AnalogArray[i].szTerminal);GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_AnalogArray[i].szEquimentTag, g_CimDataParser.m_AnalogArray[i].szEquimentType, g_CimDataParser.m_AnalogArray[i].szEquimentName);						GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_AnalogArray[i].szMeasurementTypeTag, g_CimDataParser.m_AnalogArray[i].szMeasurementType);															GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_AnalogArray[i].szMeasurementValue);
// 		}
// 		break;
// 	case	CIM_Discrete:	//	ң��
// 		nRowNum=(int)g_CimDataParser.m_DiscreteArray.size();
// 		nColNum=sizeof(g_DiscreteAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_DiscreteAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_DiscreteArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DiscreteArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DiscreteArray[i].szName);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DiscreteArray[i].szDesp);
// 			sprintf(szBuf, "%s[%s.%s.%s]", g_CimDataParser.m_DiscreteArray[i].szTerminalTag, g_CimDataParser.m_DiscreteArray[i].szSub, g_CimDataParser.m_DiscreteArray[i].szVolt, g_CimDataParser.m_DiscreteArray[i].szTerminal);GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s.%s]", g_CimDataParser.m_DiscreteArray[i].szEquimentTag, g_CimDataParser.m_DiscreteArray[i].szEquimentType, g_CimDataParser.m_DiscreteArray[i].szEquimentName);							GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_DiscreteArray[i].szMeasurementTypeTag, g_CimDataParser.m_DiscreteArray[i].szMeasurementType);																GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_DiscreteArray[i].szMeasurementValue);
// 		}
// 		break;
// 	case	CIM_LimitSet:	//	LimitSets
// 		nRowNum=(int)g_CimDataParser.m_LimitSetArray.size();
// 		nColNum=sizeof(g_LimitSetAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_LimitSetAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_LimitSetArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_LimitSetArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_LimitSetArray[i].szName);
// 		}
// 		break;
// 	case	CIM_Limit:	//	Limits
// 		nRowNum=(int)g_CimDataParser.m_LimitArray.size();
// 		nColNum=sizeof(g_LimitAttrArray)/sizeof(tagCIMXmlEleDesp);
// 		for (i=0; i<nColNum; i++)
// 		{
// 			GetListCtrl().InsertColumn(i+1, g_LimitAttrArray[i].szDesp);
// 		}
// 		for (i=0; i<(int)g_CimDataParser.m_LimitArray.size(); i++)
// 		{
// 			nCol=1;
// 			sprintf(szBuf, "%d", i+1);
// 			GetListCtrl().InsertItem(i, szBuf);
// 
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_LimitArray[i].szResourceID);
// 			GetListCtrl().SetItemText(i, nCol++, g_CimDataParser.m_LimitArray[i].szName);
// 			sprintf(szBuf, "%.2f", g_CimDataParser.m_LimitArray[i].fValue);													GetListCtrl().SetItemText(i, nCol++, szBuf);
// 			sprintf(szBuf, "%s[%s]", g_CimDataParser.m_LimitArray[i].szLimitSetTag, g_CimDataParser.m_LimitArray[i].szLimitSet);	GetListCtrl().SetItemText(i, nCol++, szBuf);
// 		}
// 		break;
// 	default:
// 		break;
// 	}
// 	for (i=1; i<=nColNum; i++)
// 	{
// 		nColWidth=nHeaderWidth=0;
// 
// 		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
// 		nColWidth = GetListCtrl().GetColumnWidth(i);
// 		if (nRowNum <= 0)
// 		{
// 			GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
// 			nHeaderWidth =GetListCtrl().GetColumnWidth(i);
// 		}
// 
// 		GetListCtrl().SetColumnWidth(i, max(nColWidth, nHeaderWidth));
// 	}
// }

LRESULT CCIMXmlParserView::OnClassChanged(WPARAM wParam, LPARAM lParam)
{
	TRACE("ViewOnClassChanged: %d\n", wParam);
	if (m_nCurClass != wParam && wParam >= 0)
	{
		m_nCurClass=(int)wParam;
		Refresh(m_nCurClass);
	}
	return 0;
}

void CCIMXmlParserView::OnSaveasExcel()
{
	// TODO: �ڴ�����������������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	SaveListAsExcel(&GetListCtrl(), g_CimDataParser.GetCIMTableDesp(m_nCurClass), dlg.GetPathName(), 1);

	PrintMessage("EXCEL�������");
}

void CCIMXmlParserView::OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DrawItem(m_nCurClass, pDispInfo);
	*pResult = 0;
}

void CCIMXmlParserView::DrawItem(const int nClass, NMLVDISPINFO* pDispInfo)
{
	if (nClass < 0)
		return;

	LV_ITEM* pItem= &(pDispInfo)->item;
 	if (!(pItem->mask & LVIF_TEXT))
 		return;

	int	nRow=pItem->iItem;
	int	nCol=pItem->iSubItem;
	switch (nClass)
	{
	case	CIM_BasePower:	//	BaseVoltage
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);									break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_BasePower.szResourceID);		break;
		case	2:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_BasePower.fBasePower);	break;
		}
		break;
	case	CIM_BaseVoltage:	//	BaseVoltage
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_BaseVoltageArray[nRow].szResourceID);			break;
		case	2:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_BaseVoltageArray[nRow].fNominalVoltage);	break;
		}
		break;
	case	CIM_SubcontrolArea:	//	SubControlArea
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_SubcontrolAreaArray[nRow].szResourceID);		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_SubcontrolAreaArray[nRow].szName);				break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_SubcontrolAreaArray[nRow].szDesp);				break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_SubcontrolAreaArray[nRow].szAlias);				break;
		case	5:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_SubcontrolAreaArray[nRow].bExclude);		break;
		}
		break;
	case	CIM_Substation:	//	Substation
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_SubstationArray[nRow].szResourceID);																			break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_SubstationArray[nRow].szName);																					break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_SubstationArray[nRow].szDesp);																					break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_SubstationArray[nRow].szAlias);																					break;
		case	5:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_SubstationArray[nRow].szSubcontrolAreaTag, g_CimDataParser.m_SubstationArray[nRow].strSubcontrolArea.c_str());	break;
		case	6:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_SubstationArray[nRow].bExclude);																			break;
		}
		break;
	case	CIM_VoltageLevel:	//	VoltageLevel
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																												break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_VoltageLevelArray[nRow].szResourceID);																		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_VoltageLevelArray[nRow].szName);																			break;
		case	3:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_VoltageLevelArray[nRow].fHLimit);																		break;
		case	4:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_VoltageLevelArray[nRow].fLLimit);																		break;
		case	5:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_VoltageLevelArray[nRow].szSubstationTag, g_CimDataParser.m_VoltageLevelArray[nRow].szSub);			break;
		case	6:	sprintf(pItem->pszText, "%s[%.1f]", g_CimDataParser.m_VoltageLevelArray[nRow].szBaseVoltageTag, g_CimDataParser.m_VoltageLevelArray[nRow].fNominal);	break;
		}
		break;
	case	CIM_Bay:	//	Bay
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																						break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_BayArray[nRow].szResourceID);														break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_BayArray[nRow].szName);																break;
		case	3:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_BayArray[nRow].szSubstationTag, g_CimDataParser.m_BayArray[nRow].szSub);	break;
		case	4:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_BayArray[nRow].szVoltageTag, g_CimDataParser.m_BayArray[nRow].szVolt);		break;
		}
		break;
	case	CIM_ACLineSegment:	//	ACLineSegment
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																												break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szResourceID);																		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szName);																			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szDesp);																			break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szAlias);																			break;
		case	5:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fR);																			break;
		case	6:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fX);																			break;
		case	7:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fG);																			break;
		case	8:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fB);																			break;
		case	9:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fR0);																		break;
		case	10:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fX0);																		break;
		case	11:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fG0);																		break;
		case	12:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_ACLineSegmentArray[nRow].fB0);																		break;
		case	13:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szParentTag);																		break;
		case	14:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_ACLineSegmentArray[nRow].szTerminalTag[0], g_CimDataParser.m_ACLineSegmentArray[nRow].szNode[0]);	break;
		case	15:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_ACLineSegmentArray[nRow].szTerminalTag[1], g_CimDataParser.m_ACLineSegmentArray[nRow].szNode[1]);	break;
		case	16:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szSub[0]);																			break;
		case	17:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szSub[1]);																			break;
		case	18:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szVolt[0]);																		break;
		case	19:	strcpy(pItem->pszText, g_CimDataParser.m_ACLineSegmentArray[nRow].szVolt[1]);																		break;
		}
		break;
	case	CIM_DCLineSegment:	//	DCLineSegment
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																												break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szResourceID);																		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szName);																			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szDesp);																			break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szAlias);																			break;
		case	5:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_DCLineSegmentArray[nRow].fL);																			break;
		case	6:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_DCLineSegmentArray[nRow].fR);																			break;
		case	7:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szParentTag);																		break;
		case	8:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_DCLineSegmentArray[nRow].szTerminalTag[0], g_CimDataParser.m_DCLineSegmentArray[nRow].szNode[0]);	break;
		case	9:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_DCLineSegmentArray[nRow].szTerminalTag[1], g_CimDataParser.m_DCLineSegmentArray[nRow].szNode[1]);	break;
		case	10:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szSub[0]);																			break;
		case	11:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szSub[1]);																			break;
		case	12:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szVolt[0]);																		break;
		case	13:	strcpy(pItem->pszText, g_CimDataParser.m_DCLineSegmentArray[nRow].szVolt[1]);																		break;
		}
		break;
	case	CIM_RectifierInverter:	//	RectifierInverter
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																																													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_RectifierInverterArray[nRow].szResourceID);																																		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_RectifierInverterArray[nRow].szName);																																			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_RectifierInverterArray[nRow].szDesp);																																			break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_RectifierInverterArray[nRow].szAlias);																																			break;
		case	5:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_RectifierInverterArray[nRow].fRatedKV);																																	break;
		case	6:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_RectifierInverterArray[nRow].nBridges);																																	break;
		case	7:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_RectifierInverterArray[nRow].fCommutatingReactance);																														break;
		case	8:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_RectifierInverterArray[nRow].szParentTag, g_CimDataParser.m_RectifierInverterArray[nRow].szSub);																		break;
		case	9:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_RectifierInverterArray[nRow].szTerminalTag[0], g_CimDataParser.m_RectifierInverterArray[nRow].szVolt[0], g_CimDataParser.m_RectifierInverterArray[nRow].szNode[0]);	break;
		case	10:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_RectifierInverterArray[nRow].szTerminalTag[1], g_CimDataParser.m_RectifierInverterArray[nRow].szVolt[1], g_CimDataParser.m_RectifierInverterArray[nRow].szNode[1]);	break;
		case	11:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_RectifierInverterArray[nRow].szTerminalTag[2], g_CimDataParser.m_RectifierInverterArray[nRow].szVolt[2], g_CimDataParser.m_RectifierInverterArray[nRow].szNode[2]);	break;
		}
		break;
	case	CIM_TransformerWinding:	//	TransformerWinding
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																																											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_TransformerWindingArray[nRow].szResourceID);																															break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_TransformerWindingArray[nRow].szName);																																	break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_TransformerWindingArray[nRow].szDesp);																																	break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_TransformerWindingArray[nRow].szAlias);																																	break;
		case	5:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_TransformerWindingArray[nRow].fR);																																break;
		case	6:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_TransformerWindingArray[nRow].fX);																																break;
		case	7:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_TransformerWindingArray[nRow].fX0);																																break;
		case	8:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_TransformerWindingArray[nRow].fRatedKV);																															break;
		case	9:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_TransformerWindingArray[nRow].fRatedMW);																															break;
		case	10:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_TransformerWindingArray[nRow].szParentTag, g_CimDataParser.m_TransformerWindingArray[nRow].szSub, g_CimDataParser.m_TransformerWindingArray[nRow].szVolt);	break;
		case	11:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_TransformerWindingArray[nRow].szPowerTransformerTag, g_CimDataParser.m_TransformerWindingArray[nRow].szPowerTransformer);										break;
		case	12:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_TransformerWindingArray[nRow].szTerminalTag, g_CimDataParser.m_TransformerWindingArray[nRow].szNode);															break;
		case	13:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_TransformerWindingArray[nRow].szTapChangerTag, g_CimDataParser.m_TransformerWindingArray[nRow].szTapChanger);																															break;
		}
		break;
	case	CIM_PowerTransformer:	//	PowerTransformer
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_PowerTransformerArray[nRow].szResourceID);																break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_PowerTransformerArray[nRow].szName);																	break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_PowerTransformerArray[nRow].szDesp);																	break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_PowerTransformerArray[nRow].szAlias);																	break;
		case	5:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_PowerTransformerArray[nRow].szParentTag, g_CimDataParser.m_PowerTransformerArray[nRow].szSub);	break;
		}
		break;
	case	CIM_TapChanger:	//	TapChanger
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);														break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_TapChangerArray[nRow].szResourceID);				break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_TapChangerArray[nRow].szName);						break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_TapChangerArray[nRow].szDesp);						break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_TapChangerArray[nRow].szAlias);						break;
		case	5:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_TapChangerArray[nRow].nHighStep);				break;
		case	6:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_TapChangerArray[nRow].nLowStep);				break;
		case	7:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_TapChangerArray[nRow].nNeutralStep);			break;
		case	8:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_TapChangerArray[nRow].nNormalStep);			break;
		case	9:	sprintf(pItem->pszText, "%f", g_CimDataParser.m_TapChangerArray[nRow].fStepVoltageIncrement);	break;
		case	10:	strcpy(pItem->pszText, g_CimDataParser.m_TapChangerArray[nRow].szTransformerWindingTag);		break;
		}
		break;
	case	CIM_SynchronousMachine:	//	SynchronousMachine
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																																											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_SynchronousMachineArray[nRow].szResourceID);																															break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_SynchronousMachineArray[nRow].szName);																																	break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_SynchronousMachineArray[nRow].szDesp);																																	break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_SynchronousMachineArray[nRow].szAlias);																																	break;
		case	5:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_SynchronousMachineArray[nRow].szParentTag, g_CimDataParser.m_SynchronousMachineArray[nRow].szSub, g_CimDataParser.m_SynchronousMachineArray[nRow].szVolt);	break;
		case	6:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_SynchronousMachineArray[nRow].fMvrate);																															break;
		case	7:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_SynchronousMachineArray[nRow].fMaxQ);																															break;
		case	8:	strcpy(pItem->pszText, g_CimDataParser.m_SynchronousMachineArray[nRow].szUnitTag);																																break;
		case	9:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_SynchronousMachineArray[nRow].szTerminalTag, g_CimDataParser.m_SynchronousMachineArray[nRow].szNode);															break;
		}
		break;
	case	CIM_ThermalGeneratingUnit:	//	ThermalGeneratingUnit
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																																											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_ThermalGeneratingUnitArray[nRow].szResourceID);																															break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_ThermalGeneratingUnitArray[nRow].szName);																																break;
		case	3:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_ThermalGeneratingUnitArray[nRow].fInitP);																														break;
		case	4:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_ThermalGeneratingUnitArray[nRow].fMaxP);																														break;
		case	5:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_ThermalGeneratingUnitArray[nRow].fMinP);																														break;
		}
		break;
	case	CIM_HydroGeneratingUnit:	//	HydroGeneratingUnit
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																																											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_HydroGeneratingUnitArray[nRow].szResourceID);																															break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_HydroGeneratingUnitArray[nRow].szName);																																	break;
		case	3:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_HydroGeneratingUnitArray[nRow].fInitP);																															break;
		case	4:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_HydroGeneratingUnitArray[nRow].fMaxP);																															break;
		case	5:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_HydroGeneratingUnitArray[nRow].fMinP);																															break;
		}
		break;
	case	CIM_EnergyConsumer:	//	EnergyConsumer
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_EnergyConsumerArray[nRow].szResourceID);		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_EnergyConsumerArray[nRow].szName);				break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_EnergyConsumerArray[nRow].szDesp);				break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_EnergyConsumerArray[nRow].szAlias);				break;
		case	5:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_EnergyConsumerArray[nRow].pfixedPct);	break;
		case	6:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_EnergyConsumerArray[nRow].qfixedPct);	break;
		case	7:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_EnergyConsumerArray[nRow].pFexp);		break;
		case	8:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_EnergyConsumerArray[nRow].qFexp);		break;
		case	9:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_EnergyConsumerArray[nRow].szParentTag, g_CimDataParser.m_EnergyConsumerArray[nRow].szSub, g_CimDataParser.m_EnergyConsumerArray[nRow].szVolt);	break;
		case	10:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_EnergyConsumerArray[nRow].szTerminalTag, g_CimDataParser.m_EnergyConsumerArray[nRow].szNode);														break;
		}
		break;
	case	CIM_Compensator:	//	Compensator
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);												break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_CompensatorArray[nRow].szResourceID);		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_CompensatorArray[nRow].szName);				break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_CompensatorArray[nRow].szDesp);				break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_CompensatorArray[nRow].szAlias);			break;
		case	5:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_CompensatorArray[nRow].fMvar);		break;
		case	6:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_CompensatorArray[nRow].fNomV);		break;
		case	7:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_CompensatorArray[nRow].szParentTag, g_CimDataParser.m_CompensatorArray[nRow].szSub, g_CimDataParser.m_CompensatorArray[nRow].szVolt);	break;
		case	8:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_CompensatorArray[nRow].szTerminalTag1, g_CimDataParser.m_CompensatorArray[nRow].szNode1);													break;
		case	9:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_CompensatorArray[nRow].szTerminalTag2, g_CimDataParser.m_CompensatorArray[nRow].szNode2);													break;
		}
		break;
	case	CIM_BusbarSection:	//	BusbarSection
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_BusbarSectionArray[nRow].szResourceID);			break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_BusbarSectionArray[nRow].szName);				break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_BusbarSectionArray[nRow].szDesp);				break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_BusbarSectionArray[nRow].szAlias);				break;
		case	5:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_BusbarSectionArray[nRow].szParentTag, g_CimDataParser.m_BusbarSectionArray[nRow].szSub, g_CimDataParser.m_BusbarSectionArray[nRow].szVolt);	break;
		case	6:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_BusbarSectionArray[nRow].szTerminalTag, g_CimDataParser.m_BusbarSectionArray[nRow].szNode);													break;
		}
		break;
	case	CIM_Breaker:	//	Breaker
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_BreakerArray[nRow].strResourceID.c_str());		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_BreakerArray[nRow].strName.c_str());			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_BreakerArray[nRow].strDesp.c_str());			break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_BreakerArray[nRow].strAlias.c_str());			break;
		case	5:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_BreakerArray[nRow].bOpen);				break;
		case	6:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_BreakerArray[nRow].strParentTag.c_str(), g_CimDataParser.m_BreakerArray[nRow].strSub.c_str(), g_CimDataParser.m_BreakerArray[nRow].strVolt.c_str());	break;
		case	7:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_BreakerArray[nRow].strTerminalTag[0].c_str(), g_CimDataParser.m_BreakerArray[nRow].strNode[0].c_str());											break;
		case	8:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_BreakerArray[nRow].strTerminalTag[1].c_str(), g_CimDataParser.m_BreakerArray[nRow].strNode[1].c_str());											break;
		}
		break;
	case	CIM_DCSwitch:
	case	CIM_Disconnector:	//	Disconnector
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_DisconnectorArray[nRow].strResourceID.c_str());	break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_DisconnectorArray[nRow].strName.c_str());		break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_DisconnectorArray[nRow].strDesp.c_str());		break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_DisconnectorArray[nRow].strAlias.c_str());		break;
		case	5:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_DisconnectorArray[nRow].bOpen);			break;
		case	6:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_DisconnectorArray[nRow].strParentTag.c_str(), g_CimDataParser.m_DisconnectorArray[nRow].strSub.c_str(), g_CimDataParser.m_DisconnectorArray[nRow].strVolt.c_str());	break;
		case	7:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_DisconnectorArray[nRow].strTerminalTag[0].c_str(), g_CimDataParser.m_DisconnectorArray[nRow].strNode[0].c_str());														break;
		case	8:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_DisconnectorArray[nRow].strTerminalTag[1].c_str(), g_CimDataParser.m_DisconnectorArray[nRow].strNode[1].c_str());														break;
		}
		break;
	case	CIM_GroundDisconnector:	//	GroundDisconnector
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);															break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_GroundDisconnectorArray[nRow].strResourceID.c_str());	break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_GroundDisconnectorArray[nRow].strName.c_str());			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_GroundDisconnectorArray[nRow].strDesp.c_str());			break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_GroundDisconnectorArray[nRow].strAlias.c_str());		break;
		case	5:	sprintf(pItem->pszText, "%d", g_CimDataParser.m_GroundDisconnectorArray[nRow].bOpen);				break;
		case	6:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_GroundDisconnectorArray[nRow].strParentTag.c_str(), g_CimDataParser.m_GroundDisconnectorArray[nRow].strSub.c_str(), g_CimDataParser.m_GroundDisconnectorArray[nRow].strVolt.c_str());	break;
		case	7:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_GroundDisconnectorArray[nRow].strTerminalTag.c_str(), g_CimDataParser.m_GroundDisconnectorArray[nRow].strNode.c_str());																	break;
		}
		break;
	case	CIM_Terminal:	//	Terminal
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_TerminalArray[nRow].strResourceID.c_str());		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_TerminalArray[nRow].strName.c_str());			break;
		case	3:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_TerminalArray[nRow].strParentTag.c_str(), g_CimDataParser.m_TerminalArray[nRow].strSub.c_str(), g_CimDataParser.m_TerminalArray[nRow].strVolt.c_str());	break;
		case	4:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_TerminalArray[nRow].strNodeTag.c_str(), g_CimDataParser.m_TerminalArray[nRow].strNode.c_str());															break;
		}
		break;
	case	CIM_ConnectivityNode:	//	ConnectivityNode
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);														break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_ConnectivityNodeArray[nRow].strResourceID.c_str());	break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_ConnectivityNodeArray[nRow].strName.c_str());		break;
		case	3:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_ConnectivityNodeArray[nRow].strParentTag.c_str(), g_CimDataParser.m_ConnectivityNodeArray[nRow].strSub.c_str(), g_CimDataParser.m_ConnectivityNodeArray[nRow].strVolt.c_str());	break;
		}
		break;

	case	CIM_MeasurementType:	//	��������
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);												break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementTypeArray[nRow].szResourceID);	break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementTypeArray[nRow].szName);			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementTypeArray[nRow].szDesp);			break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementTypeArray[nRow].szAlias);		break;
		}
		break;
	case	CIM_MeasurementSource:	//	������Դ
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);												break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementSourceArray[nRow].szResourceID);	break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementSourceArray[nRow].szName);		break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementSourceArray[nRow].szDesp);		break;
		}
		break;
	case	CIM_MeasurementValue:	//	����ֵ
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);																break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementValueArray[nRow].strResourceID.c_str());			break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementValueArray[nRow].strMeasurementValue.c_str());	break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementValueArray[nRow].strMeasurementTag.c_str());		break;
		case	4:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementValueArray[nRow].strMeasurementSourceTag.c_str());break;
		}
		break;
	case	CIM_Measurement:	//	����
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);														break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementArray[nRow].strResourceID.c_str());		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementArray[nRow].strName.c_str());			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementArray[nRow].strDesp.c_str());			break;
		case	4:	sprintf(pItem->pszText, "%s[%s.%s.%s]", g_CimDataParser.m_MeasurementArray[nRow].strTerminalTag.c_str(), g_CimDataParser.m_MeasurementArray[nRow].strSub.c_str(), g_CimDataParser.m_MeasurementArray[nRow].strVolt.c_str(), g_CimDataParser.m_MeasurementArray[nRow].strTerminal.c_str());	break;
		case	5:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_MeasurementArray[nRow].strEquimentTag.c_str(), g_CimDataParser.m_MeasurementArray[nRow].strEquimentType.c_str(), g_CimDataParser.m_MeasurementArray[nRow].strEquimentName.c_str());											break;
		case	6:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_MeasurementArray[nRow].strMeasurementTypeTag.c_str(), g_CimDataParser.m_MeasurementArray[nRow].strMeasurementType.c_str());																							break;
		case	8:	strcpy(pItem->pszText, g_CimDataParser.m_MeasurementArray[nRow].strMeasurementValue.c_str());	break;
		}
		break;
	case	CIM_Analog:	//	ң��
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_AnalogArray[nRow].strResourceID.c_str());		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_AnalogArray[nRow].strName.c_str());				break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_AnalogArray[nRow].strDesp.c_str());				break;
		case	4:	sprintf(pItem->pszText, "%s[%s.%s.%s]", g_CimDataParser.m_AnalogArray[nRow].strTerminalTag.c_str(), g_CimDataParser.m_AnalogArray[nRow].strSub.c_str(), g_CimDataParser.m_AnalogArray[nRow].strVolt.c_str(), g_CimDataParser.m_AnalogArray[nRow].strTerminal.c_str());	break;
		case	5:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_AnalogArray[nRow].strEquimentTag.c_str(), g_CimDataParser.m_AnalogArray[nRow].strEquimentType.c_str(), g_CimDataParser.m_AnalogArray[nRow].strEquimentName.c_str());									break;
		case	6:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_AnalogArray[nRow].strMeasurementTypeTag.c_str(), g_CimDataParser.m_AnalogArray[nRow].strMeasurementType.c_str());																				break;
		case	8:	strcpy(pItem->pszText, g_CimDataParser.m_AnalogArray[nRow].strMeasurementValue.c_str());	break;
		}
		break;
	case	CIM_Discrete:	//	ң��
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);													break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_DiscreteArray[nRow].strResourceID.c_str());		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_DiscreteArray[nRow].strName.c_str());			break;
		case	3:	strcpy(pItem->pszText, g_CimDataParser.m_DiscreteArray[nRow].strDesp.c_str());			break;
		case	4:	sprintf(pItem->pszText, "%s[%s.%s.%s]", g_CimDataParser.m_DiscreteArray[nRow].strTerminalTag.c_str(), g_CimDataParser.m_DiscreteArray[nRow].strSub.c_str(), g_CimDataParser.m_DiscreteArray[nRow].strVolt.c_str(), g_CimDataParser.m_DiscreteArray[nRow].strTerminal.c_str());	break;
		case	5:	sprintf(pItem->pszText, "%s[%s.%s]", g_CimDataParser.m_DiscreteArray[nRow].strEquimentTag.c_str(), g_CimDataParser.m_DiscreteArray[nRow].strEquimentType.c_str(), g_CimDataParser.m_DiscreteArray[nRow].strEquimentName.c_str());										break;
		case	6:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_DiscreteArray[nRow].strMeasurementTypeTag.c_str(), g_CimDataParser.m_DiscreteArray[nRow].strMeasurementType.c_str());																					break;
		case	8:	strcpy(pItem->pszText, g_CimDataParser.m_DiscreteArray[nRow].strMeasurementValue.c_str());break;
		}
		break;
	case	CIM_LimitSet:	//	LimitSets
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_LimitSetArray[nRow].szResourceID);		break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_LimitSetArray[nRow].szName);			break;
		}
		break;
	case	CIM_Limit:	//	Limits
		switch (nCol)
		{
		case	0:	sprintf(pItem->pszText, "%d", nRow+1);											break;
		case	1:	strcpy(pItem->pszText, g_CimDataParser.m_LimitArray[nRow].szResourceID);			break;
		case	2:	strcpy(pItem->pszText, g_CimDataParser.m_LimitArray[nRow].szName);				break;
		case	3:	sprintf(pItem->pszText, "%.2f", g_CimDataParser.m_LimitArray[nRow].fValue);															break;
		case	4:	sprintf(pItem->pszText, "%s[%s]", g_CimDataParser.m_LimitArray[nRow].szLimitSetTag, g_CimDataParser.m_LimitArray[nRow].szLimitSet);	break;
		}
		break;
	default:
		break;
	}
}