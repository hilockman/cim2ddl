#pragma once

#include "../../../MemDB/PGMemDB/PGMemDB.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif
using namespace PGMemDB;

#include "../../CIMDataApi/CIMDataApi.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/CIMDataApi.lib")
#else
#	pragma comment(lib, "../../../lib_x64/CIMDataApi.lib")
#endif

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/xerces-c_3.lib")
#else					 
#	pragma comment(lib, "../../../lib_x64/xerces-c_3.lib")
#endif

