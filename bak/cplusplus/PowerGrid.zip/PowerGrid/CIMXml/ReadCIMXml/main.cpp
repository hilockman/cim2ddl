#include "stdafx.h"

tagPGBlock*		g_pBlock;
CCIMData		g_CimParser;

const char*	g_lpszLogFile="ReadCimXml.log";
extern	void	ClearLog(const char* lpszLogFile);

int main(int argc, char** argv)
{
	int		nArg;
	clock_t	dBeg, dEnd;
	int		nDur;

	register int	i;
	int		nMemID;
	unsigned char	nParseFlag, bParseMeasurement, bUseSax, bEQGenOutnet;
	unsigned char	bNameByDesp, bSubstatioNamePrefixSubcontrolArea;
	char	szFileName[260];
	float	fLowVThreshold;
	int		nOutnetSubNum, nDelSubcontrolAreaNum;
	std::vector<std::string>	strOutnetSubstationArray;
	std::vector<std::string>	strDelSubcontrolAreaArray;

	if (argc < 7)
	{
		printf("��ȷ�ĺ����÷���: ReadCIMXml MemID CIMXmlFileName NameByDesp bParseMeasurement bUseSax fLowVThreshold ...\n");
		return 0;
	}

	nMemID=0;
	nParseFlag=1;			//	XY	Y=1��ʾNameByDesp, Y=0��֮��X=1��ʾSubstatioNamePrefixSubcontrolArea��X=0����֮��
	bParseMeasurement=0;
	bUseSax=1;
	fLowVThreshold=0;
	bEQGenOutnet=0;

	nArg=1;
	nOutnetSubNum=nDelSubcontrolAreaNum=0;
	strOutnetSubstationArray.clear();
	strDelSubcontrolAreaArray.clear();

	if (argc > nArg)	{	nMemID=atoi(argv[nArg++]);					printf("MemID=%d\n", nMemID);						}
	if (argc > nArg)	{	strcpy(szFileName, argv[nArg++]);			printf("FileName=%s\n", szFileName);					}
	if (argc > nArg)	{	nParseFlag=atoi(argv[nArg++]);				printf("ParseFlag=%d\n", nParseFlag);				}
	if (argc > nArg)	{	bParseMeasurement=atoi(argv[nArg++]);		printf("ParseMeasurement=%d\n", bParseMeasurement);	}
	if (argc > nArg)	{	bUseSax=atoi(argv[nArg++]);					printf("UseSax=%d\n", bUseSax);						}
	if (argc > nArg)	{	fLowVThreshold=(float)atof(argv[nArg++]);	printf("VThread=%f\n", fLowVThreshold);				}

	if (argc > nArg)	{	bEQGenOutnet=atoi(argv[nArg++]);			printf("EQGenOutnet=%d\n", bEQGenOutnet);			}
	if (argc > nArg)	{	nOutnetSubNum=atoi(argv[nArg++]);			printf("OutnetSubNum=%d\n", nOutnetSubNum);			}
	if (argc > nArg)	{	nDelSubcontrolAreaNum=atoi(argv[nArg++]);	printf("DelSubcontrolAreaNum=%d\n", nDelSubcontrolAreaNum);	}
	for (i=0; i<nOutnetSubNum; i++)
		strOutnetSubstationArray.push_back(argv[nArg++]);
	for (i=0; i<nDelSubcontrolAreaNum; i++)
		strDelSubcontrolAreaArray.push_back(argv[nArg++]);

	for (i=0; i<(int)strOutnetSubstationArray.size(); i++)
		printf("OutnetSub[%d]=%s\n", i+1, strOutnetSubstationArray[i].c_str());
	for (i=0; i<(int)strDelSubcontrolAreaArray.size(); i++)
		printf("DelSubcontrolArea[%d]=%s\n", i+1, strDelSubcontrolAreaArray[i].c_str());

	bNameByDesp=bSubstatioNamePrefixSubcontrolArea=0;
	if (nParseFlag > 10)		bSubstatioNamePrefixSubcontrolArea=1;
	if (nParseFlag % 10 != 0)	bNameByDesp=1;

	dBeg=clock();

	g_pBlock=(tagPGBlock*)Init_PGBlock(nMemID, 1);
	if (!g_pBlock)
	{
		printf("��ȡ�ڴ�����\n");
		return 0;
	}

	ClearLog(g_lpszLogFile);
	if (g_CimParser.Parse(&g_CimParser, szFileName, bParseMeasurement, bUseSax, bNameByDesp, bSubstatioNamePrefixSubcontrolArea))
	{
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		printf("����CIM��ɣ���ʱ%d����\n", nDur);

		g_CimParser.FillMemDB(g_pBlock, 1, bNameByDesp, fLowVThreshold, bSubstatioNamePrefixSubcontrolArea);
		if (!strOutnetSubstationArray.empty())
		{
			g_CimParser.AddOutnetEQGen(g_pBlock, bEQGenOutnet, strOutnetSubstationArray);

			dEnd=clock();
			nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
			printf("����������ֵ�������ɣ���ʱ%d����\n", nDur);
		}
		if (!strDelSubcontrolAreaArray.empty())
		{
			g_CimParser.EraseSubcontrolArea(g_pBlock, strDelSubcontrolAreaArray);

			dEnd=clock();
			nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
			printf("ɾ��������ɣ���ʱ%d����\n", nDur);
		}

		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		printf("���CIM��ɣ���ʱ%d����\n", nDur);
	}
	else
	{
		printf("����CIM����\n");
	}

	return 1;
}

