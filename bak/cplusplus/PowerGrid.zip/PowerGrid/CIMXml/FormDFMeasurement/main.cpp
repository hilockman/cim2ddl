#include "../../CIMDataApi/CIMDataApi.h"
#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/CIMDataApi.lib")
#else					 
#	pragma comment(lib, "../../../lib_x64/CIMDataApi.lib")
#endif

CCIMData	g_CimDataParser;

const	char*	lpszLogFileName="FormDFMeasurement.log";
extern	void ClearLog(const char* lpszLogFile);
extern	void Log(const char* lpszLogFile, char* pformat, ...);

int main(int argc, char** argv)
{
	int		nArg;
	clock_t	dBeg,dEnd;
	int		nDur;

	unsigned char	bNameByDesp;
	unsigned char	bOutBreakerYX,bOutSwitchYX,bOutCurrentYC;
	char	szCimXmlFileName[260],szOutTxtFileName[260];

	if (argc < 7)
	{
		printf("��ȷ�ĺ����÷���: FormDFMeasurement CIMXmlFileName OutTxtFileName NameByDesp bOutBreakerYX bOutSwitchYX bOutCurrentYC\n");
		return 0;
	}

	bOutBreakerYX=1;
	bOutSwitchYX=1;
	bOutCurrentYC=1;

	nArg=1;
	if (argc > nArg)	strcpy(szCimXmlFileName,argv[nArg++]);
	if (argc > nArg)	strcpy(szOutTxtFileName,argv[nArg++]);
	if (argc > nArg)	bNameByDesp=atoi(argv[nArg++]);
	if (argc > nArg)	bOutBreakerYX=atoi(argv[nArg++]);
	if (argc > nArg)	bOutSwitchYX=atoi(argv[nArg++]);
	if (argc > nArg)	bOutCurrentYC=atoi(argv[nArg++]);

	dBeg=clock();
	if (g_CimDataParser.Parse(&g_CimDataParser, szCimXmlFileName, 1, 1, bNameByDesp))
	{
		dEnd=clock();
		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		printf("CIM/XML������ϣ���ʱ%d����\n",nDur);

		g_CimDataParser.FormMeasurementTable(szOutTxtFileName,bOutSwitchYX,bOutCurrentYC);
	}
	else
		printf("Error in ParserXML\n");

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	printf("������ϣ���ʱ%d����\n",nDur);

	return 1;
}

