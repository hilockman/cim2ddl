
// GISXmlParserDoc.h : CGISXmlParserDoc ��Ľӿ�
//


#pragma once

class CGISXmlParserDoc : public CDocument
{
protected: // �������л�����
	CGISXmlParserDoc();
	DECLARE_DYNCREATE(CGISXmlParserDoc)

// ����
public:

// ����
public:

// ��д
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// ʵ��
public:
	virtual ~CGISXmlParserDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFileOpen();
	afx_msg void OnInputBlock();
	afx_msg void OnDirectoryOpen();
	afx_msg void OnLoadgisFromfile();
	afx_msg void OnSavegisAsfile();
	DECLARE_MESSAGE_MAP()
public:
};


