
// GISXmlParserView.h : CGISXmlParserView ��Ľӿ�
//


#pragma once

class CGISXmlParserView : public CListView
{
protected: // �������л�����
	CGISXmlParserView();
	DECLARE_DYNCREATE(CGISXmlParserView)

// ����
public:
	CGISXmlParserDoc* GetDocument() const;

// ����
public:
	void Refresh();

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
	virtual ~CGISXmlParserView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg LRESULT OnClassChanged(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSaveasExcel();
	afx_msg void OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult);
	DECLARE_MESSAGE_MAP()
private:
	void DrawItem(const int nClass, NMLVDISPINFO* pDispInfo);
private:
	int m_nCurClass;
protected:
//	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
};

#ifndef _DEBUG  // GISXmlParserView.cpp �еĵ��԰汾
inline CGISXmlParserDoc* CGISXmlParserView::GetDocument() const
{
	return reinterpret_cast<CGISXmlParserDoc*>(m_pDocument);
}
#endif

