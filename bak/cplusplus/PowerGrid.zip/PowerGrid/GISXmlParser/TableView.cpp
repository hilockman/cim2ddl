
#include "stdafx.h"
#include "MainFrm.h"
#include "TableView.h"
#include "Resource.h"
#include "GISXmlParserApp.h"
//#include "../GISDataTable.h"

//////////////////////////////////////////////////////////////////////
// ����/����
//////////////////////////////////////////////////////////////////////

CTableView::CTableView()
{
}

CTableView::~CTableView()
{
}

BEGIN_MESSAGE_MAP(CTableView, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTableView ��Ϣ��������

int CTableView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
	{
		return -1;
	}

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// ������ͼ:
	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | TVS_HASLINES | TVS_SHOWSELALWAYS | TVS_LINESATROOT | TVS_HASBUTTONS | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

	if (!m_wndTableView.Create(dwViewStyle, rectDummy, this, 2))
	{
		TRACE0("δ�ܴ�������ͼ\n");
		return -1;      // δ�ܴ���
	}

	OnChangeVisualStyle();


	// ����һЩ��̬����ͼ����(�˴�ֻ������������룬�����Ǹ��ӵ�����)
	FillTableView();

	return 0;
}

void CTableView::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void CTableView::FillTableView()
{
	register int	i;
	char			szGTableDesp[260];
	TV_INSERTSTRUCT TreeItem;
	HTREEITEM hTreeItemTable;
	HTREEITEM hTreeItemRoot;

	if (!m_wndTableView.DeleteAllItems())
		return;

	TreeItem.hParent=TVI_ROOT;
	TreeItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
	TreeItem.item.pszText=_T("CIM ��");
	TreeItem.item.cchTextMax=12;
	TreeItem.item.lParam=-1;
	TreeItem.item.iImage=1;
	TreeItem.item.state=TVIS_BOLD | TVIS_EXPANDED;
	TreeItem.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
	hTreeItemRoot=m_wndTableView.InsertItem(&TreeItem);
	for (i=0; i<g_GISData.GetGISTableNum(); i++)
	{
		strcpy(szGTableDesp, g_GISData.GetGISTableDesp(i));

		TreeItem.hParent=hTreeItemRoot;
		TreeItem.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;

		TreeItem.item.stateMask=TVIS_EXPANDED | TVIS_SELECTED;
		TreeItem.item.state=0;

		TreeItem.item.pszText=szGTableDesp;
		TreeItem.item.cchTextMax=100;
		TreeItem.item.lParam=g_GISData.GetGISTableID(i);
		TreeItem.item.iImage=6;
		hTreeItemTable=m_wndTableView.InsertItem(&TreeItem);
	}
	m_wndTableView.Expand(hTreeItemRoot, TVE_EXPAND);
}

void CTableView::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient;
	GetClientRect(rectClient);

	int cyTlb=0;
	m_wndTableView.SetWindowPos(NULL, rectClient.left + 1, rectClient.top + cyTlb + 1, rectClient.Width() - 2, rectClient.Height() - cyTlb - 2, SWP_NOACTIVATE | SWP_NOZORDER);
}

BOOL CTableView::PreTranslateMessage(MSG* pMsg)
{
	return CDockablePane::PreTranslateMessage(pMsg);
}


void CTableView::OnPaint()
{
	CPaintDC dc(this); // ���ڻ��Ƶ��豸������

	CRect rectTree;
	m_wndTableView.GetWindowRect(rectTree);
	ScreenToClient(rectTree);

	rectTree.InflateRect(1, 1);
	dc.Draw3dRect(rectTree, ::GetSysColor(COLOR_3DSHADOW), ::GetSysColor(COLOR_3DSHADOW));
}

void CTableView::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);

	m_wndTableView.SetFocus();
}

void CTableView::OnChangeVisualStyle()
{
	m_TableViewImages.DeleteImageList();

	UINT uiBmpId = theApp.m_bHiColorIcons ? IDB_CLASS_VIEW_24 : IDB_CLASS_VIEW;

	CBitmap bmp;
	if (!bmp.LoadBitmap(uiBmpId))
	{
		TRACE(_T("�޷�����λͼ: %x\n"), uiBmpId);
		ASSERT(FALSE);
		return;
	}

	BITMAP bmpObj;
	bmp.GetBitmap(&bmpObj);

	UINT nFlags = ILC_MASK;

	nFlags |= (theApp.m_bHiColorIcons) ? ILC_COLOR24 : ILC_COLOR4;

	m_TableViewImages.Create(16, bmpObj.bmHeight, nFlags, 0, 0);
	m_TableViewImages.Add(&bmp, RGB(255, 0, 0));

	m_wndTableView.SetImageList(&m_TableViewImages, TVSIL_NORMAL);
}
