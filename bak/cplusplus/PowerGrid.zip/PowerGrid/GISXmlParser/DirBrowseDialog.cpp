// DirBrowseDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "GISXmlParserApp.h"
#include "DirBrowseDialog.h"

// CDirBrowseDialog �Ի���

IMPLEMENT_DYNAMIC(CDirBrowseDialog, CDialog)

CDirBrowseDialog::CDirBrowseDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CDirBrowseDialog::IDD, pParent)
{
	m_bClearData = TRUE;
	m_bCoordNormalize = TRUE;
	m_strSrc1Folder=_T("");
	m_strSrc2Folder=_T("");
	m_bDataWash=TRUE;
	m_bJointReserve=FALSE;

	m_strFilterMark=_T("");
	m_strFilterKeyArray.clear();
}

CDirBrowseDialog::~CDirBrowseDialog()
{
}

void CDirBrowseDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_SRC1_DIRECTORY, m_strSrc1Folder);
	DDX_Text(pDX, IDC_SRC2_DIRECTORY, m_strSrc2Folder);
	DDX_Check(pDX, IDC_CLEAR_DATA, m_bClearData);
	DDX_Check(pDX, IDC_COORD_NORMALIZE, m_bCoordNormalize);
	DDX_Check(pDX, IDC_DATAWASH, m_bDataWash);
	DDX_Check(pDX, IDC_JOINT_RESERVE, m_bJointReserve);
}


BEGIN_MESSAGE_MAP(CDirBrowseDialog, CDialog)
	ON_BN_CLICKED(IDC_BROWSE_SRC1, &CDirBrowseDialog::OnBnClickedBrowseSrc1)
	ON_BN_CLICKED(IDC_BROWSE_SRC2, &CDirBrowseDialog::OnBnClickedBrowseSrc2)
	ON_BN_CLICKED(IDOK, &CDirBrowseDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDC_ADD, &CDirBrowseDialog::OnBnClickedAdd)
	ON_BN_CLICKED(IDC_DEL, &CDirBrowseDialog::OnBnClickedDel)
END_MESSAGE_MAP()


// CDirBrowseDialog ��Ϣ��������

BOOL CDirBrowseDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	UpdateData(FALSE);

	m_strXmlFileArray.clear();

	RefreshFilterKey();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDirBrowseDialog::OnBnClickedBrowseSrc1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (theApp.GetShellManager()->BrowseForFolder(m_strSrc1Folder, this, m_strSrc1Folder))
		UpdateData(FALSE);
	SeekFile();
}

void CDirBrowseDialog::OnBnClickedBrowseSrc2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	if (theApp.GetShellManager()->BrowseForFolder(m_strSrc2Folder, this, m_strSrc2Folder))
		UpdateData(FALSE);
	SeekFile();
}

void CDirBrowseDialog::RefreshFilterKey()
{
	register int	i;
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_KEY_LIST);
	pListBox->ResetContent();
	for (i=0; i<(int)m_strFilterKeyArray.size(); i++)
		pListBox->AddString(m_strFilterKeyArray[i].c_str());
}

void CDirBrowseDialog::SeekFile()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	char	szFilter[260], szBuf[260];

	std::vector<std::string>	strFolderArray;
	std::vector<std::string>	strNewFolderArray;

	WIN32_FIND_DATA	FindFileData;
	HANDLE	hFind;
	LARGE_INTEGER filesize;
	DWORD	dwError=0;

	memset(szFilter, 0, 260);
	GetDlgItem(IDC_FILE_FILTER)->GetWindowText(szFilter, 260);

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_FILE_LIST);
	pListBox->ResetContent();

	//SetCurrentDirectory(m_strSrc1Folder);
	if (m_strSrc1Folder.GetLength() > 0)	strFolderArray.push_back(m_strSrc1Folder.GetBuffer());
	if (m_strSrc2Folder.GetLength() > 0)	strFolderArray.push_back(m_strSrc2Folder.GetBuffer());
	strNewFolderArray.clear();
	m_strXmlFileArray.clear();

	char	drive[260];
	char	dir[260];
	char	fname[260];
	char	ext[260];

	while (TRUE)
	{
		for (i=0; i<(int)strFolderArray.size(); i++)
		{
			sprintf(szBuf, "%s\\*", strFolderArray[i].c_str());
			hFind = FindFirstFile(szBuf, &FindFileData);
			if (hFind == INVALID_HANDLE_VALUE) 
			{
				sprintf (szBuf, "FindFirstFile failed (%d)\n", GetLastError());
				pListBox->AddString(szBuf);
				return;
			} 

			do
			{
				if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
				{
					if (stricmp(FindFileData.cFileName, ".") != 0 && stricmp(FindFileData.cFileName, "..") != 0)
					{
						sprintf(szBuf, "%s\\%s", strFolderArray[i].c_str(), FindFileData.cFileName);
						strNewFolderArray.push_back(szBuf);
					}
				}
				else
				{
					_splitpath(FindFileData.cFileName, drive, dir, fname, ext);
					if (stricmp(ext, ".xml") != 0)
						continue;

					if (strlen(szFilter) > 0 && strcmp(szFilter, "*") != 0)
					{
						strcpy(szBuf, FindFileData.cFileName);
						if (strstr(strupr(szBuf), strupr(szFilter)) == NULL)
							continue;
					}

					filesize.LowPart = FindFileData.nFileSizeLow;
					filesize.HighPart = FindFileData.nFileSizeHigh;

					sprintf(szBuf, "%s\\%s%s  �ļ���С=%f", strFolderArray[i].c_str(), fname, ext, filesize.QuadPart/1024.0);
					pListBox->AddString(szBuf);

					sprintf(szBuf, "%s\\%s%s", strFolderArray[i].c_str(), fname, ext);
					m_strXmlFileArray.push_back(szBuf);
				}
			}
			while (FindNextFile(hFind, &FindFileData) != 0);
		}

		if (strNewFolderArray.empty())
			break;
		strFolderArray.assign(strNewFolderArray.begin(), strNewFolderArray.end());
		strNewFolderArray.clear();
	}

	dwError = GetLastError();
	if (dwError != ERROR_NO_MORE_FILES) 
	{
	}

	FindClose(hFind);
}

void CDirBrowseDialog::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	UpdateData();

	char	szMark[260];
	GetDlgItem(IDC_FILTER_MARK)->GetWindowText(szMark, 260);
	m_strFilterMark=szMark;

	OnOK();
}

void CDirBrowseDialog::OnBnClickedAdd()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	register int	i;
	unsigned char	bExist;
	char	szKey[260];

	GetDlgItem(IDC_FILTER_KEY)->GetWindowText(szKey, 260);
	if (strlen(szKey) <= 0)
		return;

	bExist=0;
	for (i=0; i<(int)m_strFilterKeyArray.size(); i++)
	{
		if (stricmp(m_strFilterKeyArray[i].c_str(), szKey) == 0)
		{
			bExist=1;
			break;
		}
	}
	if (bExist)
		return;

	m_strFilterKeyArray.push_back(szKey);
	RefreshFilterKey();
}

void CDirBrowseDialog::OnBnClickedDel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_KEY_LIST);
	int			nKey=pListBox->GetCurSel();
	if (nKey != LB_ERR)
	{
		m_strFilterKeyArray.erase(m_strFilterKeyArray.begin()+nKey);
		RefreshFilterKey();
	}
}
