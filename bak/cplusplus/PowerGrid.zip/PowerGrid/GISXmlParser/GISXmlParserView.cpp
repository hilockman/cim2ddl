
// GISXmlParserView.cpp : CGISXmlParserView ���ʵ��
//

#include "stdafx.h"
#include "GISXmlParserApp.h"
#include "GISXmlParserDoc.h"
#include "GISXmlParserView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGISXmlParserView

IMPLEMENT_DYNCREATE(CGISXmlParserView, CListView)

BEGIN_MESSAGE_MAP(CGISXmlParserView, CListView)
	ON_MESSAGE(UM_CLASS_CHANGED,	OnClassChanged)
	ON_COMMAND(ID_SAVEAS_EXCEL, &CGISXmlParserView::OnSaveasExcel)
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, &CGISXmlParserView::OnLvnGetdispinfo)
END_MESSAGE_MAP()

// CGISXmlParserView ����/����

CGISXmlParserView::CGISXmlParserView()
{
	// TODO: �ڴ˴����ӹ������
	m_nCurClass=-1;
}

CGISXmlParserView::~CGISXmlParserView()
{
}

BOOL CGISXmlParserView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ
	cs.style &= ~LVS_TYPEMASK;
	cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT | LVS_OWNERDATA;// | LVS_OWNERDRAWFIXED;
	return CListView::PreCreateWindow(cs);
}

void CGISXmlParserView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();


	// TODO: ���� GetListCtrl() ֱ�ӷ��� ListView ���б��ؼ���
	//  �Ӷ������������ ListView��
	GetListCtrl().SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void CGISXmlParserView::OnRButtonUp(UINT nFlags, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CGISXmlParserView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CGISXmlParserView ���

#ifdef _DEBUG
void CGISXmlParserView::AssertValid() const
{
	CListView::AssertValid();
}

void CGISXmlParserView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CGISXmlParserDoc* CGISXmlParserView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGISXmlParserDoc)));
	return (CGISXmlParserDoc*)m_pDocument;
}
#endif //_DEBUG


// CGISXmlParserView ��Ϣ��������

void CGISXmlParserView::Refresh()
{
	register int	i;
	int			nColWidth, nHeaderWidth;
	int			nRowNum, nColNum;

	nRowNum=nColNum=0;
	while (GetListCtrl().DeleteColumn(0));
	if (!GetListCtrl().DeleteAllItems())
		return;

	GetListCtrl().InsertColumn(0, "���");
	GetListCtrl().SetColumnWidth(0, 50);
	nRowNum=g_GISData.GetGISTableRecordNum(m_nCurClass);
	nColNum=g_GISData.GetGISTableFieldNum(m_nCurClass);
	for (i=0; i<nColNum; i++)
		GetListCtrl().InsertColumn(i+1, g_GISData.GetGISTableFieldDesp(m_nCurClass, i));

	GetListCtrl().SetItemCount(nRowNum);	//force redraw
	GetListCtrl().SetItemState(0, LVIS_SELECTED, 0xffff);
	GetListCtrl().EnsureVisible(0, FALSE);

	CString			strItem;
	LVCOLUMN		lvc;
	lvc.mask = LVCF_TEXT;
	lvc.pszText = strItem.GetBufferSetLength(260);
	lvc.cchTextMax = 260;
	for (i=1; i<=nColNum; i++)
	{
		nColWidth=nHeaderWidth=0;
		GetListCtrl().GetColumn(i, &lvc);
		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = GetListCtrl().GetColumnWidth(i);
		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth =GetListCtrl().GetColumnWidth(i);
		if (STRICMP(strItem, "Coordinate") == 0)
			nColWidth=0;
		GetListCtrl().SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

LRESULT CGISXmlParserView::OnClassChanged(WPARAM wParam, LPARAM lParam)
{
	TRACE("ViewOnClassChanged: %d\n", wParam);
	if (m_nCurClass != wParam && wParam >= 0)
	{
		m_nCurClass=wParam;
		Refresh();
	}
	return 0;
}

void CGISXmlParserView::OnSaveasExcel()
{
	// TODO: �ڴ�����������������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	SaveListAsExcel(&GetListCtrl(), g_GISData.GetGISTableDesp(m_nCurClass), dlg.GetPathName(), 1);

	PrintMessage("EXCEL�������");
}

void CGISXmlParserView::OnLvnGetdispinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	DrawItem(m_nCurClass, pDispInfo);
	*pResult = 0;
}

void CGISXmlParserView::DrawItem(const int nClass, NMLVDISPINFO* pDispInfo)
{
	if (nClass < 0)
		return;

	LV_ITEM* pItem= &(pDispInfo)->item;
 	if (!(pItem->mask & LVIF_TEXT))
 		return;

	int	nRow=pItem->iItem;
	int	nCol=pItem->iSubItem;
	if (nCol == 0)
	{
		sprintf(pItem->pszText, "%d", nRow+1);
	}
	else
	{
		if (g_GISData.GetGISRecordValue(nClass, nCol-1, nRow).length() > 260)
			strncpy(pItem->pszText, g_GISData.GetGISRecordValue(nClass, nCol-1, nRow).c_str(), 250);
		else
			strcpy(pItem->pszText, g_GISData.GetGISRecordValue(nClass, nCol-1, nRow).c_str());
	}
}