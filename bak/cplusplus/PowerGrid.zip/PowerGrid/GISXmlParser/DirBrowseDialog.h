#pragma once


// CDirBrowseDialog �Ի���
class CDirBrowseDialog : public CDialog
{
	DECLARE_DYNAMIC(CDirBrowseDialog)

public:
	CDirBrowseDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDirBrowseDialog();

// �Ի�������
	enum { IDD = IDD_FILE_BROWSE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnBnClickedBrowseSrc1();
	afx_msg void OnBnClickedBrowseSrc2();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedAdd();
	afx_msg void OnBnClickedDel();
	DECLARE_MESSAGE_MAP()

private:
	CString m_strSrc1Folder;
	CString m_strSrc2Folder;
	CString m_strExt;
	void SeekFile();

public:
	std::vector<std::string>	m_strXmlFileArray;
	BOOL m_bClearData;
	BOOL m_bCoordNormalize;
	BOOL m_bDataWash;
	BOOL m_bJointReserve;

public:
	std::string m_strFilterMark;
	std::vector<std::string>	m_strFilterKeyArray;

private:
	void	RefreshFilterKey();
};
