
// GISXmlParserApp.h : GISXmlParser Ӧ�ó������ͷ�ļ�
//
#pragma once

#ifndef __AFXWIN_H__
#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"       // ������
#include "../GISDataApi/GISData.h"
#include "../GISDataApi/GISXmlParser.h"
#include "../GISDataApi/GISDataFile.h"
#include "../GISDataApi/GISData2PGMemDB.h"

#define	PopupMenuCmd	WM_APP+1000

// CGISXmlParserApp:
// �йش����ʵ�֣������ GISXmlParser.cpp
//

#define		UM_CLASS_CHANGED	WM_APP+100
#define		UM_MESSAGE			WM_APP+101

class CGISXmlParserApp : public CWinAppEx
{
public:
	CGISXmlParserApp();


// ��д
public:
	virtual BOOL InitInstance();

// ʵ��
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();
};

extern	CGISXmlParserApp	theApp;
extern	CGISData			g_GISData;
extern	CGISXmlParser		g_GISXmlParser;
extern	CGISDataFile		g_GISDataFile;
extern	CGISData2PGMemDB	g_GISData2PGMemDB;
extern	tagPGBlock*			g_pBlock;
extern	char				g_szRunDir[260];

extern	void	PrintMessage(char* pformat, ...);
extern	void	SaveListAsExcel(CListCtrl* pListCtrl, const char* lpszExcelSheetName, const char* lpszFileName, const unsigned char bShowExcel);
extern	LONG	RegDeleteAllKeys(HKEY hKeyDelete, LPCTSTR pszSubKey);
