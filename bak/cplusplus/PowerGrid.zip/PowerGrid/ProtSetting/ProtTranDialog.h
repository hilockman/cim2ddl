#pragma once

#include "../../Common/Excel/ExcelAccessor.h"

// CProtTranDialog �Ի���

class CProtTranDialog : public CDialog
{
	DECLARE_DYNAMIC(CProtTranDialog)

public:
	CProtTranDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProtTranDialog();
	void InitProt(CProtParam* pProtParam, CProtTran* pProtTran)
	{
		m_pProtParam = pProtParam;
		m_pProtTran = pProtTran;
	};

	void Refresh(CProtGraph* pGraph, const unsigned char bFilter)
	{
		RefreshBaseTranList(pGraph);
		RefreshProtTranIkList(bFilter);
		RefreshProtTranI0List(bFilter);
	};
	void	ExcelOut(ExcelAccessor* pExcel);

// �Ի�������
	enum { IDD = IDD_PROTTRAN_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndBaseTran, m_wndProtTranIk, m_wndProtTranI0;

private:
	void RefreshBaseTranList(CProtGraph* pGraph);
	void RefreshProtTranIkList(const unsigned char bFilter);
	void RefreshProtTranI0List(const unsigned char bFilter);
private:
	CProtParam*	m_pProtParam;
	CProtTran*	m_pProtTran;
};
