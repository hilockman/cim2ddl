// ProtTranDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtTranDialog.h"


// CProtTranDialog �Ի���
#define		IDC_BASETRAN_LIST	10002
#define		IDC_PROTTRANIK_LIST	10011
#define		IDC_PROTTRANI0_LIST	10012

static	char*	lpszBaseTranColumn[]=
{
	"���", 
	"�豸��", 
	"�ն˱�", 
	"��ѹ", 
	"����", 
	"��Դ", 
	"��Դĸ��", 
	"��Դ�������豸", 
};

static	char*	lpszProtTranIkColumn[]=
{
	"���", 
	"�豸��", 
	"��ѹ", 

	"�ڲ�������", 
	"�ڲ���С����", 

	"�ⲿ������", 
	"�ⲿ��С����", 

	"�ⲿ����������", 
	"�ⲿ������С����", 

	"�Բ�ĸ��������", 
	"�Բ�ĸ����С����", 
	"��ƽ�����", 

	"������ζ�ֵ", 
	"������ζ�ֵ", 
	"������ѹ", 

	"��������ϵ��", 
};

static	char*	lpszProtTranI0Column[]=
{
	"���", 
	"�豸��", 
	"��ѹ", 

	"�ڲ�������", 
	"�ڲ���С����", 

	"�ⲿ������", 
	"�ⲿ��С����", 

	"����������", 
	"������С����", 

	"�����ζ�ֵ", 
	"�����ζ�ֵ", 
};

const	static	char*	lpszConstZGStat[]=
{
	"��ͨ", 
	"֧·", 
	"�ӵ�", 
};

const	static	char*	lpszConstSourceStatus[]=
{
	"��Դ", 
	"��Դ", 
};

IMPLEMENT_DYNAMIC(CProtTranDialog, CDialog)

CProtTranDialog::CProtTranDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CProtTranDialog::IDD, pParent)
{
	m_pProtParam = NULL;
	m_pProtTran = NULL;
}

CProtTranDialog::~CProtTranDialog()
{
}

void CProtTranDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CProtTranDialog, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CProtTranDialog ��Ϣ��������

BOOL CProtTranDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectBuf;

	if (!m_pProtParam || !m_pProtTran)
		EndDialog(IDCANCEL);

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndBaseTran.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_BASETRAN_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndBaseTran.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndBaseTran.SetExtendedStyle(m_wndBaseTran.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndBaseTran.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBaseTranColumn)/sizeof(char*); i++)
		m_wndBaseTran.InsertColumn(i, lpszBaseTranColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtTranIk.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTTRANIK_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtTranIk.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtTranIk.SetExtendedStyle(m_wndProtTranIk.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtTranIk.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtTranIkColumn)/sizeof(char*); i++)
		m_wndProtTranIk.InsertColumn(i, lpszProtTranIkColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtTranI0.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTTRANI0_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtTranI0.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtTranI0.SetExtendedStyle(m_wndProtTranI0.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtTranI0.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtTranI0Column)/sizeof(char*); i++)
		m_wndProtTranI0.InsertColumn(i, lpszProtTranI0Column[i],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndBaseTran,		_T("���������Ϣ"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndProtTranIk,		_T("��ѹ�������ϱ���"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndProtTranI0,		_T("��ѹ���ӵع��ϱ���"),	-1, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CProtTranDialog::RefreshBaseTranList(CProtGraph* pGraph)
{
	int		nDev, nRow, nCol;
	int		nLink;
	char	szBuf[260];
	std::string	strNeighbour;

	m_wndBaseTran.DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<m_pProtTran->m_ProtTranArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nDev+1);
		m_wndBaseTran.InsertItem(nRow, szBuf);	m_wndBaseTran.SetItemData(nRow, nRow);

		nCol=1;
		strNeighbour.clear();

		m_wndBaseTran.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szName);
		if (m_pProtTran->m_ProtTranArray[nDev].bLoadTran)
			m_wndBaseTran.SetItemText(nRow, nCol++, "��");
		else
			m_wndBaseTran.SetItemText(nRow, nCol++, "��");

		m_wndBaseTran.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szVoltH);
		m_wndBaseTran.SetItemText(nRow, nCol++, lpszConstZGStat[m_pProtTran->m_ProtTranArray[nDev].nZGStatH]);
		m_wndBaseTran.SetItemText(nRow, nCol++, lpszConstSourceStatus[m_pProtTran->m_ProtTranArray[nDev].bPowerH]);

		if (m_pProtTran->m_ProtTranArray[nDev].bPowerH)
		{
			sprintf(szBuf, "%d[%s %s]", m_pProtTran->m_ProtTranArray[nDev].nTopoBusH, m_pProtTran->m_ProtTranArray[nDev].szSub, m_pProtTran->m_ProtTranArray[nDev].szVoltH);		m_wndBaseTran.SetItemText(nRow, nCol++, szBuf);
			for (nLink=0; nLink<(int)pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusH].sN1BranArray.size(); nLink++)
			{
				if (pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusH].sN1BranArray[nLink].nBranType != PG_POWERTRANSFORMER || stricmp(pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusH].sN1BranArray[nLink].strBranName.c_str(), m_pProtTran->m_ProtTranArray[nDev].szName) != 0)
				{
					sprintf(szBuf, "[%s %s]", PGGetTableDesp(pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusH].sN1BranArray[nLink].nBranType), pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusH].sN1BranArray[nLink].strBranName.c_str());
					strNeighbour.append(szBuf).append("; ");
				}
			}
			m_wndBaseTran.SetItemText(nRow, nCol++, strNeighbour.c_str());
		}
		nRow++;

		if (m_pProtTran->m_ProtTranArray[nDev].b3Wind)
		{
			m_wndBaseTran.InsertItem(nRow, "");	m_wndBaseTran.SetItemData(nRow, nRow);

			nCol=3;
			strNeighbour.clear();

			m_wndBaseTran.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szVoltM);
			m_wndBaseTran.SetItemText(nRow, nCol++, lpszConstZGStat[m_pProtTran->m_ProtTranArray[nDev].nZGStatM]);
			m_wndBaseTran.SetItemText(nRow, nCol++, lpszConstSourceStatus[m_pProtTran->m_ProtTranArray[nDev].bPowerM]);

			if (m_pProtTran->m_ProtTranArray[nDev].bPowerM)
			{
				sprintf(szBuf, "%d[%s %s]", m_pProtTran->m_ProtTranArray[nDev].nTopoBusM, m_pProtTran->m_ProtTranArray[nDev].szSub, m_pProtTran->m_ProtTranArray[nDev].szVoltM);		m_wndBaseTran.SetItemText(nRow, nCol++, szBuf);
				for (nLink=0; nLink<(int)pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusM].sN1BranArray.size(); nLink++)
				{
					if (pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusM].sN1BranArray[nLink].nBranType != PG_POWERTRANSFORMER || stricmp(pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusM].sN1BranArray[nLink].strBranName.c_str(), m_pProtTran->m_ProtTranArray[nDev].szName) != 0)
					{
						sprintf(szBuf, "[%s %s]", PGGetTableDesp(pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusM].sN1BranArray[nLink].nBranType), pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusM].sN1BranArray[nLink].strBranName.c_str());
						strNeighbour.append(szBuf).append("; ");
					}
				}
				m_wndBaseTran.SetItemText(nRow, nCol++, strNeighbour.c_str());

			}
			nRow++;
		}

		m_wndBaseTran.InsertItem(nRow, "");	m_wndBaseTran.SetItemData(nRow, nRow);

		nCol=3;
		strNeighbour.clear();

		m_wndBaseTran.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szVoltL);
		m_wndBaseTran.SetItemText(nRow, nCol++, lpszConstZGStat[m_pProtTran->m_ProtTranArray[nDev].nZGStatL]);
		m_wndBaseTran.SetItemText(nRow, nCol++, lpszConstSourceStatus[m_pProtTran->m_ProtTranArray[nDev].bPowerL]);

		if (m_pProtTran->m_ProtTranArray[nDev].bPowerL)
		{
			sprintf(szBuf, "%d[%s %s]", m_pProtTran->m_ProtTranArray[nDev].nTopoBusL, m_pProtTran->m_ProtTranArray[nDev].szSub, m_pProtTran->m_ProtTranArray[nDev].szVoltL);		m_wndBaseTran.SetItemText(nRow, nCol++, szBuf);
			for (nLink=0; nLink<(int)pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusL].sN1BranArray.size(); nLink++)
			{
				if (pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusL].sN1BranArray[nLink].nBranType != PG_POWERTRANSFORMER || stricmp(pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusL].sN1BranArray[nLink].strBranName.c_str(), m_pProtTran->m_ProtTranArray[nDev].szName) != 0)
				{
					sprintf(szBuf, "[%s %s]", PGGetTableDesp(pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusL].sN1BranArray[nLink].nBranType), pGraph->m_SettingGPArray[m_pProtTran->m_ProtTranArray[nDev].nTopoBusL].sN1BranArray[nLink].strBranName.c_str());
					strNeighbour.append(szBuf).append("; ");
				}
			}
			m_wndBaseTran.SetItemText(nRow, nCol++, strNeighbour.c_str());

		}
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBaseTranColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndBaseTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndBaseTran.GetColumnWidth(nCol);
		m_wndBaseTran.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		if (m_wndBaseTran.GetItemCount() <= 0)
			nHeaderWidth = m_wndBaseTran.GetColumnWidth(nCol);

		m_wndBaseTran.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtTranDialog::RefreshProtTranIkList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtTranIk.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtTran->m_ProtTranArray.size(); nProt++)
	{
		if (bFilter)
		{
			if (m_pProtTran->m_ProtTranArray[nProt].fKksen3H > m_pProtParam->m_ProtSetting.fProtTranKksen3 &&
				m_pProtTran->m_ProtTranArray[nProt].fKksen3M > m_pProtParam->m_ProtSetting.fProtTranKksen3 &&
				m_pProtTran->m_ProtTranArray[nProt].fKksen3L > m_pProtParam->m_ProtSetting.fProtTranKksen3)
				continue;
		}

		sprintf(szBuf, "%d", nProt+1);
		m_wndProtTranIk.InsertItem(nRow, szBuf);	m_wndProtTranIk.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtTranIk.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nProt].szName);
		m_wndProtTranIk.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nProt].szVoltH);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fItmaxH);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fItminH);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkmaxHNear);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkminHNear);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkmaxHFar);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkminHFar);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIobmaxH);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIobminH);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkunbH);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkdz1H);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkdz3H);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fUopH);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fKksen3H);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		nRow++;

		if (m_pProtTran->m_ProtTranArray[nProt].b3Wind)
		{
			m_wndProtTranIk.InsertItem(nRow, "");	m_wndProtTranIk.SetItemData(nRow, nRow);
			nCol=2;
			m_wndProtTranIk.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nProt].szVoltM);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fItmaxM);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fItminM);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkmaxMNear);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkminMNear);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkmaxMFar);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkminMFar);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIobmaxM);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIobminM);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkunbM);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkdz1M);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkdz3M);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fUopM);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fKksen3M);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}

		m_wndProtTranIk.InsertItem(nRow, "");	m_wndProtTranIk.SetItemData(nRow, nRow);
		nCol=2;
		m_wndProtTranIk.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nProt].szVoltL);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fItmaxL);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fItminL);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkmaxLNear);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkminLNear);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkmaxLFar);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkminLFar);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIobmaxL);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIobminL);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkunbL);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkdz1L);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fIkdz3L);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fUopL);		m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nProt].fKksen3L);	m_wndProtTranIk.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtTranIkColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtTranIk.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtTranIk.GetColumnWidth(nCol);
		m_wndProtTranIk.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtTranIk.GetItemCount() <= 0)
		nHeaderWidth = m_wndProtTranIk.GetColumnWidth(nCol);

		m_wndProtTranIk.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtTranDialog::RefreshProtTranI0List(const unsigned char bFilter)
{
	int		nDev, nRow, nCol;
	char	szBuf[260];

	m_wndProtTranI0.DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<m_pProtTran->m_ProtTranArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nDev+1);
		m_wndProtTranI0.InsertItem(nRow, szBuf);	m_wndProtTranI0.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtTranI0.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szName);
		nCol=2;
		m_wndProtTranI0.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szVoltH);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0tmaxH);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0tminH);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kmaxHNear);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kminHNear);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kmaxHFar);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kminHFar);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0dz1H);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0dz2H);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		nRow++;

		if (m_pProtTran->m_ProtTranArray[nDev].b3Wind)
		{
			m_wndProtTranI0.InsertItem(nRow, "");	m_wndProtTranI0.SetItemData(nRow, nRow);
			nCol=2;
			m_wndProtTranI0.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szVoltM);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0tmaxM);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0tminM);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kmaxMNear);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kminMNear);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kmaxMFar);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kminMFar);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0dz1M);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0dz2M);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}

		m_wndProtTranI0.InsertItem(nRow, "");	m_wndProtTranI0.SetItemData(nRow, nRow);
		nCol=2;
		m_wndProtTranI0.SetItemText(nRow, nCol++, m_pProtTran->m_ProtTranArray[nDev].szVoltL);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0tmaxL);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0tminL);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kmaxLNear);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kminLNear);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kmaxLFar);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0kminLFar);	m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0dz1L);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtTran->m_ProtTranArray[nDev].fI0dz2L);		m_wndProtTranI0.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtTranI0Column)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtTranI0.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtTranI0.GetColumnWidth(nCol);
		m_wndProtTranI0.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtTranI0.GetItemCount() <= 0)
		nHeaderWidth = m_wndProtTranI0.GetColumnWidth(nCol);

		m_wndProtTranI0.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtTranDialog::ExcelOut(ExcelAccessor* pExcel)
{
	int		nRow, nCol, nFieldNum;

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndBaseTran.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("���������Ϣ"));
		pExcel->SetCurSheet(_T("���������Ϣ"));
		nFieldNum=sizeof(lpszBaseTranColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszBaseTranColumn[nCol]));
		for (nRow=0; nRow<m_wndBaseTran.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndBaseTran.GetItemText(nRow, nCol));
		}
	}
	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtTranIk.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("��ѹ�������ϱ���"));
		pExcel->SetCurSheet(_T("��ѹ�������ϱ���"));
		nFieldNum=sizeof(lpszProtTranIkColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtTranIkColumn[nCol]));
		for (nRow=0; nRow<m_wndProtTranIk.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtTranIk.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtTranI0.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("��ѹ���ӵع��ϱ���"));
		pExcel->SetCurSheet(_T("��ѹ���ӵع��ϱ���"));
		nFieldNum=sizeof(lpszProtTranI0Column)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtTranI0Column[nCol]));
		for (nRow=0; nRow<m_wndProtTranI0.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtTranI0.GetItemText(nRow, nCol));
		}
	}
}

void CProtTranDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}
