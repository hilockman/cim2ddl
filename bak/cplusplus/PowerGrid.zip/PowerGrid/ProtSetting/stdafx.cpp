
// stdafx.cpp : ֻ������׼�����ļ���Դ�ļ�
// ProtTunning.pch ����ΪԤ����ͷ
// stdafx.obj ������Ԥ����������Ϣ

#include "stdafx.h"

#if (!defined(WIN64))
#	pragma comment(lib, "../../lib/PGMemDB.lib")
#	pragma message("ProtSetting Link LibX86 PGMemDB.lib")
#else					 
#	pragma comment(lib, "../../lib_x64/PGMemDB.lib")
#	pragma message("ProtSetting Link LibX64 PGMemDB.lib")
#endif

#ifdef _USEPROTDEVICEDLL_
#	if (!defined(WIN64))
#		pragma comment(lib, "../../lib/PGProtDevice.lib")
#		pragma message("ProtSetting Link LibX86 PGProtDevice.lib")
#	else					 
#		pragma comment(lib, "../../lib_x64/PGProtDevice.lib")
#		pragma message("ProtSetting Link LibX64 PGProtDevice.lib")
#	endif
#else
#	if (!defined(WIN64))
#		ifdef _DEBUG
#			pragma comment(lib, "../../lib/libPGProtDeviceMDd.lib")
#			pragma message("ProtSetting Link LibX86 libPGProtDeviceMDd.lib")
#		else
#			pragma comment(lib, "../../lib/libPGProtDeviceMD.lib")
#			pragma message("ProtSetting Link LibX86 libPGProtDeviceMD.lib")
#		endif
#	else
#		ifdef _DEBUG
#			pragma comment(lib, "../../lib_x64/libPGProtDeviceMDd.lib")
#			pragma message("ProtSetting Link LibX64 libPGProtDeviceMDd.lib")
#		else
#			pragma comment(lib, "../../lib_x64/libPGProtDeviceMD.lib")
#			pragma message("ProtSetting Link LibX64 libPGProtDeviceMD.lib")
#		endif
#	endif
#endif // _USEPROTDEVICEDLL_

#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../lib/libTinyXmlMDd.lib")
#		pragma message("ProtSetting Link LibX86 libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../lib/libTinyXmlMD.lib")
#		pragma message("ProtSetting Link LibX86 libTinyXmlMD.lib")
#	endif
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../lib_x64/libTinyXmlMDd.lib")
#		pragma message("ProtSetting Link LibX64 libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../lib_x64/libTinyXmlMD.lib")
#		pragma message("ProtSetting Link LibX64 libTinyXmlMD.lib")
#	endif
#endif
