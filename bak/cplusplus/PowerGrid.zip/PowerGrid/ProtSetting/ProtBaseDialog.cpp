// ProtBaseDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtBaseDialog.h"


// CProtBaseDialog �Ի���
#define		IDC_BASELINE_LIST	10001
#define		IDC_BASETRAN_LIST	10002

static	char*	lpszFaultName[]=
{
	"�����·", 
	"�����·", 
	"�����·", 
	"����ӵ�", 
};

IMPLEMENT_DYNAMIC(CProtBaseDialog, CDialog)

CProtBaseDialog::CProtBaseDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CProtBaseDialog::IDD, pParent)
{
	m_pProtParam = NULL;
}

CProtBaseDialog::~CProtBaseDialog()
{
}

void CProtBaseDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CProtBaseDialog, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CProtBaseDialog ��Ϣ��������

BOOL CProtBaseDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	CRect	rectBuf;
	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndProtLineParam.			Create(IDD_PARAM_PROTLINE_DIALOG,	&m_wndTab);
	m_wndProtDeviceParam.		Create(IDD_PARAM_PROTDEVICE_DIALOG,	&m_wndTab);


	if (!m_wndBusTree.Create(WS_VISIBLE | WS_CHILD , rectBuf, &m_wndTab, 30))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndBusTree.ModifyStyle(0, TVS_SHOWSELALWAYS|TVS_LINESATROOT|TVS_DISABLEDRAGDROP|TVS_HASBUTTONS|TVS_HASLINES);
	m_wndBusTree.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));

	m_wndTab.AddTab (&m_wndProtLineParam,	_T("��·��������У�˲���"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndProtDeviceParam,	_T("������������У�˲���"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndBusTree,			_T("����ͼ"),				-1, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CProtBaseDialog::RefreshGraphTree(std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int				nVolt, nBus, nOBus, nType;
	char			szBuf[260];
	TV_INSERTSTRUCT itemTree;
	HTREEITEM		hRoot, hItem, hSubItem;

	m_wndBusTree.DeleteAllItems();

	for (nBus=0; nBus<(int)sGPArray.size(); nBus++)
	{
		if (!sGPArray[nBus].bValid)
			continue;

		nVolt=g_pPGBlock->m_TopoBusArray[nBus].nVolt;
		sprintf(szBuf, "Bus[%d %s %s] OppBus=%d OneNeighbor=%d TwoNeighbor=%d ", sGPArray[nBus].nTopoBus, g_pPGBlock->m_VoltageLevelArray[nVolt].szSub, g_pPGBlock->m_VoltageLevelArray[nVolt].szName, 
			sGPArray[nBus].nOLBusArray.size(), sGPArray[nBus].sN1BranArray.size(), sGPArray[nBus].sN2BranArray.size());

		itemTree.hParent=TVI_ROOT;
		itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
		itemTree.item.pszText=szBuf;
		itemTree.item.cchTextMax=260;
		itemTree.item.lParam=0;
		itemTree.item.state=0;//TVIS_EXPANDED;
		itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
		hRoot=m_wndBusTree.InsertItem(&itemTree);

		for (nType=0; nType<ConstMaxSccFault; nType++)
		{
			sprintf(szBuf, "%s ��·����(A) [��=%f ��=%f ��=%f] [A=%f B=%f C=%f]", lpszFaultName[nType], 
				sGPArray[nBus].fI1[nType], 
				sGPArray[nBus].fI2[nType], 
				sGPArray[nBus].fI0[nType], 
				sGPArray[nBus].fIa[nType], 
				sGPArray[nBus].fIb[nType], 
				sGPArray[nBus].fIc[nType]);

			itemTree.hParent=hRoot;
			itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
			itemTree.item.pszText=szBuf;
			itemTree.item.cchTextMax=260;
			itemTree.item.lParam=0;
			itemTree.item.state=TVIS_EXPANDED;
			itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
			m_wndBusTree.InsertItem(&itemTree);
		}

		for (i=0; i<(int)sGPArray[nBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER)
			{
				if (sGPArray[nBus].sN1BranArray[i].nBranSide == ConstTranSideH)
				{
					sprintf(szBuf, "һ������[%s %s@H] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].fRate);
				}
				else if (sGPArray[nBus].sN1BranArray[i].nBranSide == ConstTranSideM)
				{
					sprintf(szBuf, "һ������[%s %s@M] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].fRate);
				}
				else if (sGPArray[nBus].sN1BranArray[i].nBranSide == ConstTranSideL)
				{
					sprintf(szBuf, "һ������[%s %s@L] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].fRate);
				}
			}
			else if (sGPArray[nBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT)
			{
				if (sGPArray[nBus].sN1BranArray[i].nBranSide == ConstLineSideI)
				{
					sprintf(szBuf, "һ������[%s %s(%s %s)@I] Opp=%d Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].strSubI.c_str(), sGPArray[nBus].sN1BranArray[i].strSubJ.c_str(), sGPArray[nBus].sN1BranArray[i].nToTopoBus, sGPArray[nBus].sN1BranArray[i].fRate);
				}
				else
				{
					sprintf(szBuf, "һ������[%s %s(%s %s)@J] Opp=%d Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].strSubI.c_str(), sGPArray[nBus].sN1BranArray[i].strSubJ.c_str(), sGPArray[nBus].sN1BranArray[i].nToTopoBus, sGPArray[nBus].sN1BranArray[i].fRate);
				}
			}
			else
			{
				if (sGPArray[nBus].sN1BranArray[i].nBranSide == ConstLineSideI)
				{
					sprintf(szBuf, "һ������[%s %s@I] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].fRate);
				}
				else
				{
					sprintf(szBuf, "һ������[%s %s@J] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN1BranArray[i].nBranType), 
						sGPArray[nBus].sN1BranArray[i].strBranName.c_str(), sGPArray[nBus].sN1BranArray[i].fRate);
				}
			}
			itemTree.hParent=hRoot;
			itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
			itemTree.item.pszText=szBuf;
			itemTree.item.cchTextMax=260;
			itemTree.item.lParam=0;
			itemTree.item.state=TVIS_EXPANDED;
			itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
			hItem=m_wndBusTree.InsertItem(&itemTree);

			for (nType=0; nType<ConstMaxSccFault; nType++)
			{
				itemTree.hParent=hItem;
				itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
				itemTree.item.cchTextMax=260;
				itemTree.item.lParam=0;
				itemTree.item.state=TVIS_EXPANDED;
				itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;

				sprintf(szBuf, "%s ��·����(A) [��=%.1f ��=%.1f ��=%.1f A=%.1f B=%.1f C=%.1f]", lpszFaultName[nType], 
					sGPArray[nBus].sN1BranArray[i].fI1[nType], 
					sGPArray[nBus].sN1BranArray[i].fI2[nType], 
					sGPArray[nBus].sN1BranArray[i].fI0[nType], 
					sGPArray[nBus].sN1BranArray[i].fIa[nType], 
					sGPArray[nBus].sN1BranArray[i].fIb[nType], 
					sGPArray[nBus].sN1BranArray[i].fIc[nType]);
				itemTree.item.pszText=szBuf;
				m_wndBusTree.InsertItem(&itemTree);
			}
		}

		for (nOBus=0; nOBus<(int)sGPArray[nBus].nOLBusArray.size(); nOBus++)
		{
			nVolt=g_pPGBlock->m_TopoBusArray[sGPArray[nBus].nOLBusArray[nOBus]].nVolt;
			sprintf(szBuf, "OppBus[%d %s %s]", sGPArray[nBus].nOLBusArray[nOBus], g_pPGBlock->m_VoltageLevelArray[nVolt].szSub, g_pPGBlock->m_VoltageLevelArray[nVolt].szName);
			itemTree.hParent=hRoot;
			itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
			itemTree.item.pszText=szBuf;
			itemTree.item.cchTextMax=260;
			itemTree.item.lParam=0;
			itemTree.item.state=TVIS_EXPANDED;
			itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
			hItem=m_wndBusTree.InsertItem(&itemTree);

			for (i=0; i<(int)sGPArray[nBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nBus].sN2BranArray[i].nFrTopoBus != sGPArray[nBus].nOLBusArray[nOBus])
					continue;

				if (sGPArray[nBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER)
				{
					if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstTranSideH)
					{
						sprintf(szBuf, "��������[%s %s@H] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstTranSideM)
					{
						sprintf(szBuf, "��������[%s %s@M] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstTranSideL)
					{
						sprintf(szBuf, "��������[%s %s@L] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
				}
				else if (sGPArray[nBus].sN2BranArray[i].nBranType == PG_ACLINESEGMENT)
				{
					if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstLineSideI)
					{
						sprintf(szBuf, "��������[%s %s(%s %s)@I] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].strSubI.c_str(), sGPArray[nBus].sN2BranArray[i].strSubJ.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else
					{
						sprintf(szBuf, "��������[%s %s(%s %s)@J] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].strSubI.c_str(), sGPArray[nBus].sN2BranArray[i].strSubJ.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
				}
				else
				{
					if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstLineSideI)
					{
						sprintf(szBuf, "��������[%s %s@I] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else
					{
						sprintf(szBuf, "��������[%s %s@J] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
				}

				itemTree.hParent=hItem;
				itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
				itemTree.item.pszText=szBuf;
				itemTree.item.cchTextMax=260;
				itemTree.item.lParam=0;
				itemTree.item.state=TVIS_EXPANDED;
				itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
				hSubItem=m_wndBusTree.InsertItem(&itemTree);

				for (nType=0; nType<ConstMaxSccFault; nType++)
				{
					itemTree.hParent=hSubItem;
					itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
					itemTree.item.pszText=szBuf;
					itemTree.item.cchTextMax=260;
					itemTree.item.lParam=0;
					itemTree.item.state=TVIS_EXPANDED;
					itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;

					sprintf(szBuf, "%s ��·����(A) [��=%.1f ��=%.1f ��=%.1f A=%.1f B=%.1f C=%.1f]", lpszFaultName[nType], 
						sGPArray[nBus].sN2BranArray[i].fI1[nType], 
						sGPArray[nBus].sN2BranArray[i].fI2[nType], 
						sGPArray[nBus].sN2BranArray[i].fI0[nType], 
						sGPArray[nBus].sN2BranArray[i].fIa[nType], 
						sGPArray[nBus].sN2BranArray[i].fIb[nType], 
						sGPArray[nBus].sN2BranArray[i].fIc[nType]);
					itemTree.item.pszText=szBuf;
					m_wndBusTree.InsertItem(&itemTree);
				}
			}
		}


		for (nOBus=0; nOBus<(int)sGPArray[nBus].nOTBusArray.size(); nOBus++)
		{
			nVolt=g_pPGBlock->m_TopoBusArray[sGPArray[nBus].nOTBusArray[nOBus]].nVolt;
			sprintf(szBuf, "OppBus[%d %s %s]", sGPArray[nBus].nOTBusArray[nOBus], g_pPGBlock->m_VoltageLevelArray[nVolt].szSub, g_pPGBlock->m_VoltageLevelArray[nVolt].szName);
			itemTree.hParent=hRoot;
			itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
			itemTree.item.pszText=szBuf;
			itemTree.item.cchTextMax=260;
			itemTree.item.lParam=0;
			itemTree.item.state=TVIS_EXPANDED;
			itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
			hItem=m_wndBusTree.InsertItem(&itemTree);

			for (i=0; i<(int)sGPArray[nBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nBus].sN2BranArray[i].nFrTopoBus != sGPArray[nBus].nOTBusArray[nOBus])
					continue;

				if (sGPArray[nBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER)
				{
					if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstTranSideH)
					{
						sprintf(szBuf, "��������[%s %s@H] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstTranSideM)
					{
						sprintf(szBuf, "��������[%s %s@M] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstTranSideL)
					{
						sprintf(szBuf, "��������[%s %s@L] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
				}
				else if (sGPArray[nBus].sN2BranArray[i].nBranType == PG_ACLINESEGMENT)
				{
					if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstLineSideI)
					{
						sprintf(szBuf, "��������[%s %s(%s %s)@I] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].strSubI.c_str(), sGPArray[nBus].sN2BranArray[i].strSubJ.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else
					{
						sprintf(szBuf, "��������[%s %s(%s %s)@J] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].strSubI.c_str(), sGPArray[nBus].sN2BranArray[i].strSubJ.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
				}
				else
				{
					if (sGPArray[nBus].sN2BranArray[i].nBranSide == ConstLineSideI)
					{
						sprintf(szBuf, "��������[%s %s@I] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
					else
					{
						sprintf(szBuf, "��������[%s %s@J] Rated=%.1f", PGGetTableDesp(sGPArray[nBus].sN2BranArray[i].nBranType), 
							sGPArray[nBus].sN2BranArray[i].strBranName.c_str(), sGPArray[nBus].sN2BranArray[i].fRate);
					}
				}
				itemTree.hParent=hItem;
				itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
				itemTree.item.pszText=szBuf;
				itemTree.item.cchTextMax=260;
				itemTree.item.lParam=0;
				itemTree.item.state=TVIS_EXPANDED;
				itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;
				hSubItem=m_wndBusTree.InsertItem(&itemTree);

				for (nType=0; nType<ConstMaxSccFault; nType++)
				{
					itemTree.hParent=hSubItem;
					itemTree.item.mask=TVIF_TEXT | TVIF_PARAM | TVIF_HANDLE | TVIF_STATE;
					itemTree.item.pszText=szBuf;
					itemTree.item.cchTextMax=260;
					itemTree.item.lParam=0;
					itemTree.item.state=TVIS_EXPANDED;
					itemTree.item.stateMask=TVIS_BOLD | TVIS_EXPANDED;

					sprintf(szBuf, "%s ��·����(A) [��=%.1f ��=%.1f ��=%.1f A=%.1f B=%.1f C=%.1f]", lpszFaultName[nType], 
						sGPArray[nBus].sN2BranArray[i].fI1[nType], 
						sGPArray[nBus].sN2BranArray[i].fI2[nType], 
						sGPArray[nBus].sN2BranArray[i].fI0[nType], 
						sGPArray[nBus].sN2BranArray[i].fIa[nType], 
						sGPArray[nBus].sN2BranArray[i].fIb[nType], 
						sGPArray[nBus].sN2BranArray[i].fIc[nType]);
					itemTree.item.pszText=szBuf;
					m_wndBusTree.InsertItem(&itemTree);
				}
			}
		}
	}
}

void CProtBaseDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}
