#pragma once


// CProtDeviceParamDialog �Ի���

class CParamProtDeviceDialog : public CDialog
{
	DECLARE_DYNAMIC(CParamProtDeviceDialog)

public:
	CParamProtDeviceDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CParamProtDeviceDialog();
	void InitProt(CProtParam* pParam)
	{
		m_pProtParam = pParam;
	};

// �Ի�������
	enum { IDD = IDD_PARAM_PROTDEVICE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnEnChangeProtParam();
	afx_msg void OnBnClickedProtParam();

	DECLARE_MESSAGE_MAP()
private:
	CProtParam*	m_pProtParam;
};
