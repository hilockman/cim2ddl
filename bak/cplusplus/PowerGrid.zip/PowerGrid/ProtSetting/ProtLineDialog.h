#pragma once

#include "../../Common/Excel/ExcelAccessor.h"

// CProtLineDialog �Ի���

class CProtLineDialog : public CDialog
{
	DECLARE_DYNAMIC(CProtLineDialog)

public:
	CProtLineDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProtLineDialog();

	void InitProt(CProtParam* pProtParam, CProtLine* pProtLine)
	{
		m_pProtParam = pProtParam;
		m_pProtLine = pProtLine;
	};
	void Refresh(CProtGraph* pGraph, const unsigned char bFilter)
	{
		RefreshBaseLineList(pGraph);
		RefreshProtLineIkList(bFilter);
		RefreshProtLineI0List(bFilter);
	};
	void	ExcelOut(ExcelAccessor* pExcel);

// �Ի�������
	enum { IDD = IDD_PROTLINE_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndBaseLine, m_wndProtLineIk, m_wndProtLineI0;

private:
	void RefreshBaseLineList(CProtGraph* pGraph);
	void RefreshProtLineIkList(const unsigned char bFilter);
	void RefreshProtLineI0List(const unsigned char bFilter);
private:
	CProtParam*	m_pProtParam;
	CProtLine*	m_pProtLine;
};
