// ProtTunningDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtSettingDlg.h"
#include "../../Common/Excel/ExcelAccessor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CProtTunningDlg �Ի���

CProtSettingDlg::CProtSettingDlg(CWnd* pParent /*=NULL*/)
: CDialog(CProtSettingDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CProtSettingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CProtSettingDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_MAXMODE_SETTING, &CProtSettingDlg::OnBnClickedMaxModeSetting)
	ON_BN_CLICKED(IDC_BROWSE_MAXC, &CProtSettingDlg::OnBnClickedBrowseMaxc)
	ON_BN_CLICKED(IDC_BROWSE_MINC, &CProtSettingDlg::OnBnClickedBrowseMinc)
	ON_BN_CLICKED(IDC_BROWSE_AUTOCAD, &CProtSettingDlg::OnBnClickedBrowseAutocad)
	ON_BN_CLICKED(IDC_CLEAR, &CProtSettingDlg::OnBnClickedClear)
	ON_BN_CLICKED(IDC_SAVEAS_EXCEL, &CProtSettingDlg::OnBnClickedSaveasExcel)
	ON_BN_CLICKED(IDC_CHECKING, &CProtSettingDlg::OnBnClickedChecking)
	ON_BN_CLICKED(IDC_SHOW_FILTER, &CProtSettingDlg::OnBnClickedShowFilter)
	ON_BN_CLICKED(IDC_SET_PARAM, &CProtSettingDlg::OnBnClickedSetParam)
	ON_BN_CLICKED(IDC_MINMODE_SETTING, &CProtSettingDlg::OnBnClickedMinModeSetting)
	ON_BN_CLICKED(IDC_SC_SCAN, &CProtSettingDlg::OnBnClickedScScan)
END_MESSAGE_MAP()


// CProtTunningDlg ��Ϣ��������

BOOL CProtSettingDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	m_ProtParam.Init();
	m_wndProtSccScan.SetProtGraph(&m_ProtGraph);

	GetDlgItem(IDC_AUTOCAD)->SetWindowText(g_szAutoCAD);
	GetDlgItem(IDC_MAXC_MODE)->SetWindowText(g_szMaxModeDwg);
	GetDlgItem(IDC_MINC_MODE)->SetWindowText(g_szMinModeDwg);

	CRect	rectDummy;
	GetDlgItem(IDC_TAB)->GetWindowRect(&rectDummy);
	ScreenToClient(&rectDummy);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectDummy, this, 1, CMFCTabCtrl::LOCATION_TOP);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	m_wndProtBase.InitProt(&m_ProtParam);
	m_wndProtLine.InitProt(&m_ProtParam, &m_ProtLine);
	m_wndProtTran.InitProt(&m_ProtParam, &m_ProtTran);
	m_wndProtDevice.InitProt(&m_ProtBus, &m_ProtGen, &m_ProtCap, &m_ProtReac, &m_ProtMotor, &m_ProtBreaker);

	m_wndProtSccScan.	Create(IDD_PROTSCCSCAN_DIALOG,	&m_wndTab);
	m_wndProtBase.		Create(IDD_PROTBASE_DIALOG,		&m_wndTab);
	m_wndProtLine.		Create(IDD_PROTLINE_DIALOG,		&m_wndTab);
	m_wndProtTran.		Create(IDD_PROTTRAN_DIALOG,		&m_wndTab);
	m_wndProtDevice.	Create(IDD_PROTDEVICE_DIALOG,	&m_wndTab);

	m_wndTab.AddTab (&m_wndProtSccScan,		_T("��·������"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndProtBase,		_T("������Ϣ"),			-1, FALSE);

	m_wndTab.AddTab (&m_wndProtLine,		_T("��·����"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndProtTran,		_T("��ѹ������"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndProtDevice,		_T("�����豸����"),		-1, FALSE);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CProtSettingDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
		pWnd->RedrawWindow();//ʹ�����ػ�
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CProtSettingDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CProtSettingDlg::OnBnClickedMaxModeSetting()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	char	szBuffer[260];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
// 	if (access(g_szAutoCAD, 0) != 0)
// 	{
// 		pListBox->AddString("AutoCAD����������");
// 		pListBox->SetCurSel(pListBox->GetCount()-1);
// 		return;
// 	}
// 	if (access(g_szMaxModeDwg, 0) != 0)
// 	{
// 		pListBox->AddString("������ʽ������");
// 		pListBox->SetCurSel(pListBox->GetCount()-1);
// 		return;
// 	}
	dBeg=clock();

	sprintf(szBuffer, "**********��ʼ���м̵籣����ʽ��������**********");
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

// 	//////////////////////////////////////////////////////////////////////////
// 	//	��ģ
// 	std::string	strScr=PrepareAcadScr(g_szMaxModeDwg);
// 	if (access(g_szAutoCAD, 0) == 0)
// 		sprintf(szBuffer, "\"%s\" /b \"%s\" /nologo", g_szAutoCAD, strScr.c_str());
// 	else
// 		sprintf(szBuffer, "\"C:\\Program Files\\Autodesk\\AutoCAD 2011\\acad\" /b \"%s\" /nologo", strScr.c_str());
// 	Log(g_lpszLogFile, "%s\n", szBuffer);
// 	printf("%s\n", szBuffer);
// 
// 	StartProcess(szBuffer, g_szRunDir, SW_SHOW);
// 
// 	dEnd=clock();
// 	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
// 	sprintf(szBuffer, "    ������ʽ��ģ��ɣ���ʱ = %d����", nDur);
// 	pListBox->AddString(szBuffer);
// 	pListBox->SetCurSel(pListBox->GetCount()-1);

	//////////////////////////////////////////////////////////////////////////
	//	��·ɨ��
	sprintf(szBuffer, "%s/PGShortCircuit.exe", g_szRunDir);
	if (access(szBuffer, 0) != 0)
		return;
	sprintf(szBuffer, "%s/PGShortCircuit.exe Run %d", g_szRunDir, EnumSccType_ProtScan);
	StartProcess(szBuffer, g_szRunDir, SW_HIDE);

	if (!m_ProtGraph.FormSettingGraph(g_pPGBlock))
	{
		AfxMessageBox("�γ�������ʽ����");
		return;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·����ɨ�������ɺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_wndProtSccScan.RefreshBusCombo();	//	��·��������ʼ������ĸ��
	m_wndProtBase.RefreshGraphTree(m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��ȡ��·������������ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	//	��Ҫ�ڵ���ͼ���ɺ�
	m_ProtLine.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtTran.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtBus.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtGen.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtCap.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtReac.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtMotor.	Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtBreaker.	Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    �̵籣��ģ�ͳ�ʼ����ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Line.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtTran.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Tran.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtBus.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "   Bus.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtGen.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Gen.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtMotor.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Motor.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtCap.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Cap.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtReac.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Reac.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtBreaker.SetScValue(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·������������ֵ��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.		SettingMaxMode(&m_ProtParam.m_ProtSetting, m_ProtGraph.m_SettingGPArray);
	m_ProtTran.		SettingMaxMode(m_ProtLine.m_ProtLineArray, m_ProtGraph.m_SettingGPArray);
	m_ProtBus.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtGen.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtCap.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtReac.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtMotor.	Setting(&m_ProtParam.m_ProtSetting);
	m_ProtBreaker.	Setting(&m_ProtParam.m_ProtSetting, m_ProtTran.m_ProtTranArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ���㹲�ƺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	sprintf(szBuffer, "**********�̵籣����ʽ�����������**********", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	Refresh();
}

void CProtSettingDlg::OnBnClickedMinModeSetting()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	char	szBuffer[260];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
// 	if (access(g_szAutoCAD, 0) != 0)
// 	{
// 		pListBox->AddString("AutoCAD����������");
// 		pListBox->SetCurSel(pListBox->GetCount()-1);
// 		return;
// 	}
// 	if (access(g_szMinModeDwg, 0) != 0)
// 	{
// 		pListBox->AddString("������ʽ������");
// 		pListBox->SetCurSel(pListBox->GetCount()-1);
// 		return;
// 	}
	dBeg=clock();

	sprintf(szBuffer, "**********��ʼ���м̵籣��С��ʽ��������**********");
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

// 	//////////////////////////////////////////////////////////////////////////
// 	//	��ģ
// 	m_ProtLine.		Backup();
// 	m_ProtTran.		Backup();
// 	g_ProtBus.		Backup();
// 	m_ProtGen.		Backup();
// 	m_ProtCap.		Backup();
// 	m_ProtReac.		Backup();
// 	m_ProtMotor.	Backup();
// 	m_ProtBreaker.	Backup();

// 	std::string	strScr=PrepareAcadScr(g_szMinModeDwg);
// 	if (access(g_szAutoCAD, 0) == 0)
// 		sprintf(szBuffer, "\"%s\" /b \"%s\" /nologo", g_szAutoCAD, strScr.c_str());
// 	else
// 		sprintf(szBuffer, "\"C:\\Program Files\\Autodesk\\AutoCAD 2011\\acad\" /b \"%s\" /nologo", strScr.c_str());
// 	Log(g_lpszLogFile, "%s\n", szBuffer);
// 	printf("%s\n", szBuffer);
// 
// 	StartProcess(szBuffer, g_szRunDir, SW_SHOW);

// 	m_ProtLine.		Restore();
// 	m_ProtTran.		Restore();
// 	g_ProtBus.		Restore();
// 	m_ProtGen.		Restore();
// 	m_ProtCap.		Restore();
// 	m_ProtReac.		Restore();
// 	m_ProtMotor.	Restore();
// 	m_ProtBreaker.	Restore();

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ����С��ʽ��ģ��ɣ���ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	//////////////////////////////////////////////////////////////////////////
	//	��·ɨ��
	sprintf(szBuffer, "%s/PGShortCircuit.exe", g_szRunDir);
	if (access(szBuffer, 0) != 0)
		return;
	sprintf(szBuffer, "%s/PGShortCircuit.exe Run %d", g_szRunDir, EnumSccType_ProtScan);
	StartProcess(szBuffer, g_szRunDir, SW_HIDE);

	if (!m_ProtGraph.FormSettingGraph(g_pPGBlock))
	{
		AfxMessageBox("�γ�����С��ʽ����");
		return;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·����ɨ�������ɺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_wndProtSccScan.RefreshBusCombo();	//	��·��������ʼ������ĸ��
	m_wndProtBase.RefreshGraphTree(m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��ȡ��·������������ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	//	��Ҫ�ڵ���ͼ���ɺ�
	m_ProtLine.SetScValue	(g_pPGBlock, ConstMinMode, m_ProtGraph.m_SettingGPArray);
	m_ProtTran.SetScValue	(g_pPGBlock, ConstMinMode, m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·������������ֵ��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.		SettingMinMode(m_ProtGraph.m_SettingGPArray);
	m_ProtTran.		SettingMinMode(m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ���㹲�ƺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	sprintf(szBuffer, "**********�̵籣��С��ʽ�����������**********", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	Refresh();
}

void CProtSettingDlg::OnBnClickedChecking()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	char	szBuffer[260];

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
// 	if (access(g_szAutoCAD, 0) != 0)
// 	{
// 		pListBox->AddString("AutoCAD����������");
// 		pListBox->SetCurSel(pListBox->GetCount()-1);
// 		return;
// 	}
// 	if (access(g_szMinModeDwg, 0) != 0)
// 	{
// 		pListBox->AddString("У�˷�ʽ������");
// 		pListBox->SetCurSel(pListBox->GetCount()-1);
// 		return;
// 	}
	dBeg=clock();

	sprintf(szBuffer, "**********��ʼ���м̵籣��У�˼���**********");
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	//////////////////////////////////////////////////////////////////////////
	//	��ģ
// 	m_ProtLine.		Backup();
// 	m_ProtTran.		Backup();
// 	g_ProtBus.		Backup();
// 	m_ProtGen.		Backup();
// 	m_ProtCap.		Backup();
// 	m_ProtReac.		Backup();
// 	m_ProtMotor.	Backup();
// 	m_ProtBreaker.	Backup();

// 	std::string	strScr=PrepareAcadScr(g_szMinModeDwg);
// 	if (access(g_szAutoCAD, 0) == 0)
// 		sprintf(szBuffer, "\"%s\" /b \"%s\" /nologo", g_szAutoCAD, strScr.c_str());
// 	else
// 		sprintf(szBuffer, "\"C:\\Program Files\\Autodesk\\AutoCAD 2011\\acad\" /b \"%s\" /nologo", strScr.c_str());
// 	Log(g_lpszLogFile, "%s\n", szBuffer);
// 	printf("%s\n", szBuffer);
// 
// 	StartProcess(szBuffer, g_szRunDir, SW_SHOW);

// 	m_ProtLine.		Restore();
// 	m_ProtTran.		Restore();
// 	g_ProtBus.		Restore();
// 	m_ProtGen.		Restore();
// 	m_ProtCap.		Restore();
// 	m_ProtReac.		Restore();
// 	m_ProtMotor.	Restore();
// 	m_ProtBreaker.	Restore();

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    У�˷�ʽ��ģ��ɣ���ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	//////////////////////////////////////////////////////////////////////////
	//	��·ɨ��
	sprintf(szBuffer, "%s/PGShortCircuit.exe", g_szRunDir);
	if (access(szBuffer, 0) != 0)
		return;
	sprintf(szBuffer, "%s/PGShortCircuit.exe Run %d", g_szRunDir, EnumSccType_ProtScan);
	StartProcess(szBuffer, g_szRunDir, SW_HIDE);
	if (!m_ProtGraph.FormCheckingGraph(g_pPGBlock))
	{
		AfxMessageBox("�γ�У�˷�ʽ����");
		return;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·����ɨ�������ɺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_wndProtSccScan.RefreshBusCombo();	//	��·��������ʼ������ĸ��

	//////////////////////////////////////////////////////////////////////////
	//	����С��ʽ��·�����¼
	m_wndProtBase.RefreshGraphTree(m_ProtGraph.m_CheckingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��ȡ��·������������ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtTran.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtBus.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtGen.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtMotor.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtCap.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtReac.SetScValue	(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);
	m_ProtBreaker.SetScValue(g_pPGBlock, ConstChkMode, m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·������������ֵ��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.		Checking();
	m_ProtTran.		Checking();
	m_ProtBus.		Checking();
	m_ProtGen.		Checking();
	m_ProtCap.		Checking();
	m_ProtReac.		Checking();
	m_ProtMotor.	Checking();
	m_ProtBreaker.	Checking();

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ���㹲�ƺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	sprintf(szBuffer, "**********�̵籣��У�˼������**********", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	Refresh();
}

void CProtSettingDlg::OnBnClickedBrowseAutocad()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="exe";
	CString	defaultFileName=g_szAutoCAD;
	CString	fileFilter="AutoCAD(*.exe)|*.exe;*.EXE|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("AutoCAD�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	strcpy(g_szAutoCAD, dlg.GetPathName());
	GetDlgItem(IDC_AUTOCAD)->SetWindowText(g_szAutoCAD);
	SaveIni();
}

void CProtSettingDlg::OnBnClickedBrowseMaxc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="dwg";
	CString	defaultFileName=g_szMaxModeDwg;
	CString	fileFilter="AutoCAD(*.dwg)|*.dwg;*.DWG|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("AutoCADͼֽ");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	strcpy(g_szMaxModeDwg, dlg.GetPathName());
	GetDlgItem(IDC_MAXC_MODE)->SetWindowText(g_szMaxModeDwg);
	SaveIni();
}

void CProtSettingDlg::OnBnClickedBrowseMinc()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt="dwg";
	CString	defaultFileName=g_szMinModeDwg;
	CString	fileFilter="AutoCAD(*.dwg)|*.dwg;*.DWG|�����ļ�(*.*)|*.*||";
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(TRUE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("AutoCADͼֽ");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	strcpy(g_szMinModeDwg, dlg.GetPathName());
	GetDlgItem(IDC_MINC_MODE)->SetWindowText(g_szMinModeDwg);
	SaveIni();
}

void CProtSettingDlg::OnBnClickedClear()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	pListBox->ResetContent();
}

void CProtSettingDlg::Refresh()
{
	CButton*		pButton=(CButton*)GetDlgItem(IDC_SHOW_FILTER);
	unsigned char	bFilter=pButton->GetCheck();

	m_wndProtLine.Refresh(&m_ProtGraph, bFilter);
	m_wndProtTran.Refresh(&m_ProtGraph, bFilter);
	m_wndProtDevice.Refresh(bFilter);
}

void CProtSettingDlg::OnBnClickedSaveasExcel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	m_wndProtLine.ExcelOut(&xls);
	m_wndProtTran.ExcelOut(&xls);
	m_wndProtDevice.ExcelOut(&xls);

	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));
}

void CProtSettingDlg::OnBnClickedShowFilter()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	Refresh();
}

void CProtSettingDlg::OnBnClickedSetParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	m_ProtLine.		SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtTran.		SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtBus.		SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtGen.		SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtCap.		SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtReac.		SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtMotor.	SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
	m_ProtBreaker.	SetDefaultProtParam(&m_ProtParam.m_ProtSetting);
}

void CProtSettingDlg::OnBnClickedScScan()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	clock_t	dBeg, dEnd;
	int		nDur;
	char	szBuffer[260];

	dBeg = clock();

	CListBox*	pListBox=(CListBox*)GetDlgItem(IDC_MESG_LIST);
	//////////////////////////////////////////////////////////////////////////
	//	��·ɨ��
	sprintf(szBuffer, "%s/PGShortCircuit.exe", g_szRunDir);
	if (access(szBuffer, 0) != 0)
		return;
	sprintf(szBuffer, "%s/PGShortCircuit.exe Run %d", g_szRunDir, EnumSccType_ProtScan);
	StartProcess(szBuffer, g_szRunDir, SW_HIDE);

	if (!m_ProtGraph.FormSettingGraph(g_pPGBlock))
	{
		AfxMessageBox("�γ�������ʽ����");
		return;
	}

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·����ɨ�������ɺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_wndProtSccScan.RefreshBusCombo();	//	��·��������ʼ������ĸ��
	m_wndProtBase.RefreshGraphTree(m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��ȡ��·������������ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	//	��Ҫ�ڵ���ͼ���ɺ�
	m_ProtLine.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtTran.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtBus.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtGen.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtCap.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtReac.		Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtMotor.	Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);
	m_ProtBreaker.	Init(g_pPGBlock, &m_ProtParam.m_ProtSetting);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    �̵籣��ģ�ͳ�ʼ����ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Line.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtTran.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Tran.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtBus.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "   Bus.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtGen.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Gen.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtMotor.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Motor.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtCap.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Cap.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtReac.SetScValue	(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);
	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    Reac.SetScValue��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtBreaker.SetScValue(g_pPGBlock, ConstMaxMode, m_ProtGraph.m_SettingGPArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ��·������������ֵ��ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	m_ProtLine.		SettingMaxMode(&m_ProtParam.m_ProtSetting, m_ProtGraph.m_SettingGPArray);
	m_ProtTran.		SettingMaxMode(m_ProtLine.m_ProtLineArray, m_ProtGraph.m_SettingGPArray);
	m_ProtBus.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtGen.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtCap.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtReac.		Setting(&m_ProtParam.m_ProtSetting);
	m_ProtMotor.	Setting(&m_ProtParam.m_ProtSetting);
	m_ProtBreaker.	Setting(&m_ProtParam.m_ProtSetting, m_ProtTran.m_ProtTranArray);

	dEnd=clock();
	nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	sprintf(szBuffer, "    ���㹲�ƺ�ʱ = %d����", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	sprintf(szBuffer, "**********�̵籣����ʽ�����������**********", nDur);
	pListBox->AddString(szBuffer);
	pListBox->SetCurSel(pListBox->GetCount()-1);

	Refresh();
}
