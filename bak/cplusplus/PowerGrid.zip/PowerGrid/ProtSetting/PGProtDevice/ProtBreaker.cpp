#include "PGProtDevice.h"
#include "ProtBreaker.h"

static	tagMemDBField	g_PGProtBreakerFieldArray[]=
{
	{	PROTBREAKER_NAME,			"Name",					"ĸ����·������",							MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_LONG,		0,	NULL,	},
	{	PROTBREAKER_TOPOBUS,			"TopoBus",				"����ĸ��",									MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},

	{	PROTBREAKER_ILINEMAX,		"ILineMax",				"��·�������(A)",						MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_ITRANMAX,		"ITranMax",				"��ѹ���������(A)",					MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_LOWVBREAKER,		"LowVBreaker",			"��ѹ��·��(�Ա�ѹ����Ϊ�ж�ԭ��)",			MDBFieldCategoryBase,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},

	{	PROTBREAKER_IKMAX,			"IkMax",				"����·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_IKMIN,			"IkMin",				"��С��·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBREAKER_KKP1,			"Kkp1",					"����:����������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_KKLM1,			"Kklm1",				"����:�����������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_KKP2,			"Kkp2",					"����:����������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_KKR,				"Kkr",					"����:�ϻ������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBREAKER_IKDZ1,			"Ikdz1",				"������α�����������(A)",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_IKDZ2,			"Ikdz2",				"������α�����������(A)",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_IRDZ,			"Irdz",					"�ϻ�������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBREAKER_KSEN1,			"Ksen1",				"У��:�����������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBREAKER_KSEN2,			"Ksen2",				"У��:�����������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBREAKER_BREAKERPTR,		"BreakerPtr",			"�豸����",									MDBFieldCategoryAid,	MDB_INT,	sizeof(int),			0,	NULL,	},
};

CProtBreaker::CProtBreaker(void)
{
}

CProtBreaker::~CProtBreaker(void)
{
}

void CProtBreaker::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	register int	i;
	int			nBreaker, nDev, nNode;
	int			nNodeINum, nNodeIArray[400];
	int			nNodeJNum, nNodeJArray[400];
	tagProtBreaker	sProtBreaker;

	for (nBreaker=0; nBreaker<pPGBlock->m_nRecordNum[PG_BREAKER]; nBreaker++)
	{
		if (pPGBlock->m_BreakerArray[nBreaker].nInnerType != PGEnum_BreakerInnerType_BrBus)
			continue;
		if (pPGBlock->m_BreakerArray[nBreaker].nNodeI < 0 || pPGBlock->m_BreakerArray[nBreaker].nNodeJ < 0)
			continue;

		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[nBreaker].nNodeI].bOpen=1;
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[nBreaker].nNodeJ].bOpen=1;
	}

	m_ProtBreakerArray.clear();
	for (nBreaker=0; nBreaker<pPGBlock->m_nRecordNum[PG_BREAKER]; nBreaker++)
	{
		if (pPGBlock->m_BreakerArray[nBreaker].nInnerType != PGEnum_BreakerInnerType_BrBus)
			continue;
		if (pPGBlock->m_BreakerArray[nBreaker].nNodeI < 0 || pPGBlock->m_BreakerArray[nBreaker].nNodeJ < 0)
			continue;

		memset(&sProtBreaker, 0, sizeof(tagProtBreaker));

		sProtBreaker.fKkp1 = pSetting->fProtBreakerKkp1;
		sProtBreaker.fKklm1 = pSetting->fProtBreakerKklm1;
		sProtBreaker.fKkp2 = pSetting->fProtBreakerKkp2;
		sProtBreaker.fKkr = pSetting->fProtBreakerKkr;

		sprintf(sProtBreaker.szName, "%s.%s.%s", pPGBlock->m_BreakerArray[nBreaker].szSub, pPGBlock->m_BreakerArray[nBreaker].szVolt, pPGBlock->m_BreakerArray[nBreaker].szName);
		sProtBreaker.nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[nBreaker].nNodeI].nTopoBus;

		sProtBreaker.fILineRateMax = 0;
		sProtBreaker.fITranRateMax = 0;
		sProtBreaker.bLowVBreaker = 1;

		PGTraverseVolt(pPGBlock, pPGBlock->m_BreakerArray[nBreaker].nNodeI, Y_CheckStatus, Y_CheckStatus, N_BreakerBound, N_BreakerBound, nNodeINum, nNodeIArray);
		PGTraverseVolt(pPGBlock, pPGBlock->m_BreakerArray[nBreaker].nNodeJ, Y_CheckStatus, Y_CheckStatus, N_BreakerBound, N_BreakerBound, nNodeJNum, nNodeJArray);
		for (nNode=0; nNode<nNodeINum; nNode++)
		{
			for (i=pPGBlock->m_ConnectivityNodeArray[nNodeIArray[nNode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeIArray[nNode]+1].nACLineSegmentRange; i++)
			{
				nDev=pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;
				sProtBreaker.fILineRateMax = max(pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur, sProtBreaker.fILineRateMax);
			}

			for (i=pPGBlock->m_ConnectivityNodeArray[nNodeIArray[nNode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeIArray[nNode]+1].nTransformerWindingRange; i++)
			{
				nDev=pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding;
				if (pPGBlock->m_PowerTransformerArray[pPGBlock->m_TransformerWindingArray[nDev].nTran].nNodeL != nNodeIArray[nNode])
					sProtBreaker.bLowVBreaker = 0;

				sProtBreaker.fITranRateMax = (float)max(1000*pPGBlock->m_TransformerWindingArray[nDev].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nominalVoltage, sProtBreaker.fITranRateMax);
			}
		}
		for (nNode=0; nNode<nNodeJNum; nNode++)
		{
			for (i=pPGBlock->m_ConnectivityNodeArray[nNodeJArray[nNode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeJArray[nNode]+1].nACLineSegmentRange; i++)
			{
				nDev=pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;
				sProtBreaker.fILineRateMax = max(pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur, sProtBreaker.fILineRateMax);
			}

			for (i=pPGBlock->m_ConnectivityNodeArray[nNodeJArray[nNode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeJArray[nNode]+1].nTransformerWindingRange; i++)
			{
				nDev=pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding;
				if (pPGBlock->m_PowerTransformerArray[pPGBlock->m_TransformerWindingArray[nDev].nTran].nNodeL != nNodeJArray[nNode])
					sProtBreaker.bLowVBreaker = 0;

				sProtBreaker.fITranRateMax = (float)max(1000*pPGBlock->m_TransformerWindingArray[nDev].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nominalVoltage, sProtBreaker.fITranRateMax);
			}
		}
		sProtBreaker.nBreaker = nBreaker;
		m_ProtBreakerArray.push_back(sProtBreaker);
	}

	for (nBreaker=0; nBreaker<pPGBlock->m_nRecordNum[PG_BREAKER]; nBreaker++)
	{
		if (pPGBlock->m_BreakerArray[nBreaker].nInnerType != PGEnum_BreakerInnerType_BrBus)
			continue;
		if (pPGBlock->m_BreakerArray[nBreaker].nNodeI < 0 || pPGBlock->m_BreakerArray[nBreaker].nNodeJ < 0)
			continue;

		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[nBreaker].nNodeI].bOpen=0;
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[nBreaker].nNodeJ].bOpen=0;
	}
}

void CProtBreaker::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nProt, nBreaker, nTopoBus;
	char	szBuffer[260];

	for (nProt=0; nProt<m_ProtBreakerArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ�豸���������С��·����
		nBreaker=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_BREAKER]; i++)
		{
			if (pPGBlock->m_BreakerArray[i].nInnerType != PGEnum_BreakerInnerType_BrBus)
				continue;

			sprintf(szBuffer, "%s.%s.%s", pPGBlock->m_BreakerArray[i].szSub, pPGBlock->m_BreakerArray[i].szVolt, pPGBlock->m_BreakerArray[i].szName);
			if (stricmp(szBuffer, m_ProtBreakerArray[nProt].szName) == 0)
			{
				nBreaker=i;
				break;
			}
		}
		if (nBreaker < 0)
			continue;

		nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BreakerArray[nBreaker].nNodeI].nTopoBus;
		if (nMode == ConstMaxMode)
		{
			m_ProtBreakerArray[nProt].fIkmax = sGPArray[nTopoBus].fIa[FLT3];					//	�����·����
			m_ProtBreakerArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
		else
		{
			m_ProtBreakerArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
	}
}

void CProtBreaker::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtBreakerArray.size(); i++)
	{
		m_ProtBreakerArray[i].fKkp1 = pSetting->fProtBreakerKkp1;
		m_ProtBreakerArray[i].fKklm1 = pSetting->fProtBreakerKklm1;
		m_ProtBreakerArray[i].fKkp2 = pSetting->fProtBreakerKkp2;
	}
}

void CProtBreaker::Setting(tagProtSetting* pSetting, const std::vector<tagProtTran>& sProtTran)
{
	int		nProt;
	for (nProt=0; nProt<m_ProtBreakerArray.size(); nProt++)
	{
		m_ProtBreakerArray[nProt].fIkdz1 = 0;
		m_ProtBreakerArray[nProt].fIkdz2 = 0;
		m_ProtBreakerArray[nProt].fIrdz = 0;
		m_ProtBreakerArray[nProt].fKsen1 = 0;
		m_ProtBreakerArray[nProt].fKsen2 = 0;
	}

	for (nProt=0; nProt<m_ProtBreakerArray.size(); nProt++)
	{
		if (m_ProtBreakerArray[nProt].fKkp1 > FLT_MIN)
			m_ProtBreakerArray[nProt].fIkdz1 = ResolveProtTranMinIdz1(sProtTran, m_ProtBreakerArray[nProt].nTopoBus)/m_ProtBreakerArray[nProt].fKkp1;

		m_ProtBreakerArray[nProt].fIkdz2 = m_ProtBreakerArray[nProt].fKkp2*ResolveProtTranMinIdz3(sProtTran, m_ProtBreakerArray[nProt].nTopoBus);;
		if (m_ProtBreakerArray[nProt].bLowVBreaker)
			m_ProtBreakerArray[nProt].fIrdz = m_ProtBreakerArray[nProt].fITranRateMax*m_ProtBreakerArray[nProt].fKkr;
	}
}

void CProtBreaker::Checking()
{
	int		nProt;
	for (nProt=0; nProt<m_ProtBreakerArray.size(); nProt++)
	{
		m_ProtBreakerArray[nProt].fKsen1 = 0;
		m_ProtBreakerArray[nProt].fKsen2 = 0;
	}

	for (nProt=0; nProt<m_ProtBreakerArray.size(); nProt++)
	{
		if (m_ProtBreakerArray[nProt].fIkdz1 > FLT_MIN)
			m_ProtBreakerArray[nProt].fKsen1=m_ProtBreakerArray[nProt].fIkmin/m_ProtBreakerArray[nProt].fIkdz1;
		if (m_ProtBreakerArray[nProt].fIkdz2 > FLT_MIN)
			m_ProtBreakerArray[nProt].fKsen2=m_ProtBreakerArray[nProt].fIkmin/m_ProtBreakerArray[nProt].fIkdz2;
	}
}

float CProtBreaker::ResolveProtTranMinIdz3(const std::vector<tagProtTran>& sProtTranArray, const int nStartTopoBus)
{
	int		nProt;
	float	fIdz;

	fIdz=0;
	for (nProt=0; nProt<sProtTranArray.size(); nProt++)
	{
		if (sProtTranArray[nProt].nTopoBusH == nStartTopoBus)
		{
			if (sProtTranArray[nProt].fIkdz3H < FLT_MIN)
				continue;

			fIdz = (fIdz < FLT_MIN) ? sProtTranArray[nProt].fIkdz3H : min(fIdz, sProtTranArray[nProt].fIkdz3H);
		}
		else if (sProtTranArray[nProt].nTopoBusM == nStartTopoBus)
		{
			if (sProtTranArray[nProt].fIkdz3M < FLT_MIN)
				continue;

			fIdz = (fIdz < FLT_MIN) ? sProtTranArray[nProt].fIkdz3M : min(fIdz, sProtTranArray[nProt].fIkdz3M);
		}
		else if (sProtTranArray[nProt].nTopoBusL == nStartTopoBus)
		{
			if (sProtTranArray[nProt].fIkdz3L < FLT_MIN)
				continue;

			fIdz = (fIdz < FLT_MIN) ? sProtTranArray[nProt].fIkdz3L : min(fIdz, sProtTranArray[nProt].fIkdz3L);
		}
	}

	return fIdz;
}

float CProtBreaker::ResolveProtTranMinIdz1(const std::vector<tagProtTran>& sProtTranArray, const int nStartTopoBus)
{
	int		nProt;
	float	fIdz;

	fIdz=0;
	for (nProt=0; nProt<sProtTranArray.size(); nProt++)
	{
		if (sProtTranArray[nProt].nTopoBusH == nStartTopoBus)
		{
			if (sProtTranArray[nProt].fIkdz1H < FLT_MIN)
				continue;

			fIdz = (fIdz < FLT_MIN) ? sProtTranArray[nProt].fIkdz1H : min(fIdz, sProtTranArray[nProt].fIkdz1H);
		}
		else if (sProtTranArray[nProt].nTopoBusM == nStartTopoBus)
		{
			if (sProtTranArray[nProt].fIkdz1M < FLT_MIN)
				continue;

			fIdz = (fIdz < FLT_MIN) ? sProtTranArray[nProt].fIkdz1M : min(fIdz, sProtTranArray[nProt].fIkdz1M);
		}
		else if (sProtTranArray[nProt].nTopoBusL == nStartTopoBus)
		{
			if (sProtTranArray[nProt].fIkdz1L < FLT_MIN)
				continue;

			fIdz = (fIdz < FLT_MIN) ? sProtTranArray[nProt].fIkdz1L : min(fIdz, sProtTranArray[nProt].fIkdz1L);
		}
	}
	return fIdz;
}

void CProtBreaker::Backup()
{
	m_ProtArray.assign(m_ProtBreakerArray.begin(), m_ProtBreakerArray.end());
}

void CProtBreaker::Restore()
{
	m_ProtBreakerArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}
