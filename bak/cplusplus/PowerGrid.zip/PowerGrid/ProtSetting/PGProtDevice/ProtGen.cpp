#include "PGProtDevice.h"
#include "ProtGen.h"


static	tagMemDBField	g_PGProtGenFieldArray[]=
{
	{	PROTGEN_NAME,				"Name",					"���������",								MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_LONG,		0,	NULL,	},
	{	PROTGEN_TOPOBUS,				"TopoBus",				"����ĸ��",									MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},
	{	PROTGEN_RATE,				"Rate",					"�����(A)",								MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTGEN_IKMAX,				"IkMax",				"����·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_IKMINNEAR,			"IkminNear",			"�豸���˹�����С��·����(A)",				MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_IKMINFAR,			"IkminFar",				"�豸Զ�˹�����С��·����(A)",				MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTGEN_KDREL,				"Kdrel",				"����:�ݲ���ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_KKREL,				"Kkrel",				"����:���������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_KKRES,				"Kkres",				"����:������������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_KAP,					"Kap",					"����:�����ڷ���Ӱ��ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_KSS,					"Kss",					"����:����������ͬ��ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTGEN_IUNBMAX,				"IunbMax",				"�ݲ����ƽ�����(A)",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_IDDZ,				"Iddz",					"�ݲ����������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_IKDZ,				"Ikdz",					"����������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTGEN_KKSENNEAR,			"KksenNear",			"У��:����������������ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTGEN_KKSENFAR,			"KksenFar",				"У��:��������Զ������ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTGEN_GENPTR,				"GenPtr",				"���������",								MDBFieldCategoryAid,	MDB_SHORT,	sizeof(short),			0,	NULL,	},
};

CProtGen::CProtGen(void)
{
}

CProtGen::~CProtGen(void)
{
}

void CProtGen::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	int			nSub, nVolt, nGen;
	tagProtGen	sProtGen;

	m_ProtGenArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nGen=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nGen<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nGen++)
			{
				if (pPGBlock->m_SynchronousMachineArray[nGen].nNode < 0)
					continue;
				if (pPGBlock->m_SynchronousMachineArray[nGen].bDistribution)
					continue;

				memset(&sProtGen, 0, sizeof(tagProtGen));
				sProtGen.fKkrel = pSetting->fProtGenKkrel;
				sProtGen.fKkres = pSetting->fProtGenKkres;
				sProtGen.fKdrel = pSetting->fProtGenKdrel;
				sProtGen.fKap = pSetting->fProtGenKap;
				sProtGen.fKss = pSetting->fProtGenKss;

				sProtGen.fRate = (float)(1000*pPGBlock->m_SynchronousMachineArray[nGen].fPMax/0.85/1.732/pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				if (pPGBlock->m_SynchronousMachineArray[nGen].nNode >= 0)
					sProtGen.nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_SynchronousMachineArray[nGen].nNode].nTopoBus;
				sprintf(sProtGen.szName, "%s.%s.%s", pPGBlock->m_SynchronousMachineArray[nGen].szSub, pPGBlock->m_SynchronousMachineArray[nGen].szVolt, pPGBlock->m_SynchronousMachineArray[nGen].szName);

				sProtGen.nGen = nGen;

				m_ProtGenArray.push_back(sProtGen);
			}
		}
	}
}

void CProtGen::Backup()
{
	m_ProtArray.assign(m_ProtGenArray.begin(), m_ProtGenArray.end());
}

void CProtGen::Restore()
{
	m_ProtGenArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}

void CProtGen::SetAllScValue(tagPGBlock* pPGBlock, const int nProt, const int nGen, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nOpp;
	int		nTopoBus, nOppTopoBus;
	float	fInogen, fIgen, fSccB, fSccG;

	nTopoBus = pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus;

	fInogen = 0;
	for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		fInogen += sGPArray[nTopoBus].sN1BranArray[i].fIa[FLT3];							//	��ʽ�����·����
	m_ProtGenArray[nProt].fIkmax = sGPArray[nTopoBus].fIa[FLT3]-fInogen;			//	��ʽ�·���������������·���� = ĸ�߹��ϵ���-֧·����

	fInogen = 0;
	for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		fInogen += sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];							//	��ʽ�����·����
	m_ProtGenArray[nProt].fIkminNear=sGPArray[nTopoBus].fIb[FLT2]-fInogen;		//	��ʽ�·���������������·���� = ĸ�߹��ϵ���-֧·����

	for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)					//	�����������·
	{
		fSccG=fSccB=0;
		nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];

		for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)				//	����֧·����
				fSccB += sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2];
		}
		for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
		{
			if (sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)				//	ͨ��TopoBus����ϵ㹩��ĵ�������Ϊ��·�������ڲ��������������Զ�������֧·������Ϊ��������͹���֧·������
				fSccG += sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2];
		}
		fIgen = fSccB-fSccG;
		if (fIgen < FLT_MIN)
			continue;
		m_ProtGenArray[nProt].fIkminFar = (m_ProtGenArray[nProt].fIkminFar < FLT_MIN) ? fIgen : min(m_ProtGenArray[nProt].fIkminFar, fIgen);
	}
	if (m_ProtGenArray[nProt].fIkminFar < FLT_MIN)
	{
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			fSccG=fSccB=0;
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];

			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus != nTopoBus)			//	����֧·�뷢���ĸ������
					continue;
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && sGPArray[nOppTopoBus].sN2BranArray[i].nToTopoBus == nOppTopoBus)		//	����֧·����
					fSccB += sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2];
			}
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus != nTopoBus)			//	����֧·�뷢���ĸ������
					continue;
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && sGPArray[nOppTopoBus].sN2BranArray[i].nToTopoBus == nOppTopoBus)		//	����֧·����
					continue;

				fSccG += sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2];
			}
			fIgen = fSccB-fSccG;
			if (fIgen < FLT_MIN)
				continue;

			m_ProtGenArray[nProt].fIkminFar = (m_ProtGenArray[nProt].fIkminFar < FLT_MIN) ? fIgen : min(m_ProtGenArray[nProt].fIkminFar, fIgen);
		}
	}
}

void CProtGen::SetMinScValue(tagPGBlock* pPGBlock, const int nProt, const int nGen, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nOpp;
	int		nTopoBus, nOppTopoBus;
	float	fInogen, fIgen, fSccB, fSccG;

	nTopoBus = pPGBlock->m_SynchronousMachineArray[nGen].nTopoBus;

	fInogen = 0;
	for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		fInogen += sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];							//	�����·����
	m_ProtGenArray[nProt].fIkminNear=sGPArray[nTopoBus].fIb[FLT2]-fInogen;		//	����������������·����

	for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
	{
		fSccG=fSccB=0;
		nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];

		for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
		{
			if (sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)				//	�������ڵ�FrTopoBus�ǶԶ�ĸ��(������Ӧ���Ƿ����ĸ��)��ToTopoBus�ǶԶ�ĸ�ߵĶԶ�ĸ��
				fSccG += sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2];
		}
		for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)				//	������ѹ��֧·�ĶԶ�ĸ����Ч��
				fSccB += sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2];
		}
		fIgen = fSccB-fSccG;
		if (fIgen < FLT_MIN)
			continue;

		m_ProtGenArray[nProt].fIkminFar = (m_ProtGenArray[nProt].fIkminFar < FLT_MIN) ? fIgen : min(m_ProtGenArray[nProt].fIkminFar, fIgen);
	}
	if (m_ProtGenArray[nProt].fIkminFar < FLT_MIN)
	{
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			fSccG=fSccB=0;
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];

			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)				//	�������ڵ�FrTopoBus�ǶԶ�ĸ��(������Ӧ���Ƿ����ĸ��)��ToTopoBus�ǶԶ�ĸ�ߵĶԶ�ĸ��
					fSccG += sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2];
			}
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
					fSccB += sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2];
			}
			fIgen = fSccB-fSccG;
			if (fIgen < FLT_MIN)
				continue;

			m_ProtGenArray[nProt].fIkminFar = (m_ProtGenArray[nProt].fIkminFar < FLT_MIN) ? fIgen : min(m_ProtGenArray[nProt].fIkminFar, fIgen);
		}
	}
}

void CProtGen::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nProt, nGen;
	char	szBuffer[260];

	for (nProt=0; nProt<m_ProtGenArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ�豸���������С��·����
		nGen=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SYNCHRONOUSMACHINE]; i++)
		{
			if (pPGBlock->m_SynchronousMachineArray[i].bDistribution)
				continue;
			if (pPGBlock->m_SynchronousMachineArray[i].bOutage)
				continue;

			sprintf(szBuffer, "%s.%s.%s", pPGBlock->m_SynchronousMachineArray[i].szSub, pPGBlock->m_SynchronousMachineArray[i].szVolt, pPGBlock->m_SynchronousMachineArray[i].szName);
			if (stricmp(szBuffer, m_ProtGenArray[nProt].szName) == 0)
			{
				nGen=i;
				break;
			}
		}
		if (nGen < 0)
			continue;

		if (nMode == ConstMaxMode)
		{
			SetAllScValue(pPGBlock, nProt, nGen, sGPArray);
		}
		else
		{
			SetMinScValue(pPGBlock, nProt, nGen, sGPArray);
		}
	}
}

void CProtGen::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtGenArray.size(); i++)
	{
		m_ProtGenArray[i].fKkrel = pSetting->fProtGenKkrel;
		m_ProtGenArray[i].fKkres = pSetting->fProtGenKkres;
		m_ProtGenArray[i].fKdrel = pSetting->fProtGenKdrel;
		m_ProtGenArray[i].fKap = pSetting->fProtGenKap;
		m_ProtGenArray[i].fKss = pSetting->fProtGenKss;
	}
}

//////////////////////////////////////////////////////////////////////////
//	����������
void CProtGen::Setting(tagProtSetting* pSetting)
{
	int		nProt;

	for (nProt=0; nProt<m_ProtGenArray.size(); nProt++)
	{
		m_ProtGenArray[nProt].fIunbmax=0;
		m_ProtGenArray[nProt].fIddz=0;
		m_ProtGenArray[nProt].fIkdz=0;
		m_ProtGenArray[nProt].fKksenNear=0;
		m_ProtGenArray[nProt].fKksenFar=0;
	}
	for (nProt=0; nProt<m_ProtGenArray.size(); nProt++)
	{
		m_ProtGenArray[nProt].fIunbmax = m_ProtGenArray[nProt].fKap*m_ProtGenArray[nProt].fKss*pSetting->fProtKer*m_ProtGenArray[nProt].fIkmax;
		m_ProtGenArray[nProt].fIddz = m_ProtGenArray[nProt].fKdrel*m_ProtGenArray[nProt].fIunbmax;

		if (m_ProtGenArray[nProt].fKkres > FLT_MIN)
			m_ProtGenArray[nProt].fIkdz = m_ProtGenArray[nProt].fKkrel*m_ProtGenArray[nProt].fRate/m_ProtGenArray[nProt].fKkres;
	}
}

void CProtGen::Checking()
{
	int		nProt;

	for (nProt=0; nProt<m_ProtGenArray.size(); nProt++)
	{
		m_ProtGenArray[nProt].fKksenNear=0;
		m_ProtGenArray[nProt].fKksenFar=0;
	}
	for (nProt=0; nProt<m_ProtGenArray.size(); nProt++)
	{
		if (m_ProtGenArray[nProt].fIkdz > FLT_MIN)	m_ProtGenArray[nProt].fKksenNear = m_ProtGenArray[nProt].fIkminNear/m_ProtGenArray[nProt].fIkdz;
		if (m_ProtGenArray[nProt].fIkdz > FLT_MIN)	m_ProtGenArray[nProt].fKksenFar = m_ProtGenArray[nProt].fIkminFar/m_ProtGenArray[nProt].fIkdz;
	}
}
