#include "PGProtDevice.h"
#include "ProtReac.h"

static	std::vector<tagProtReac>		m_ProtArray;

static	tagMemDBField	g_ProtReacFieldArray[]=
{
	{	PROTREAC_NAME,				"Name",					"�����翹������",							MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_LONG,		0,	NULL,	},
	{	PROTREAC_TOPOBUS,			"TopoBus",				"����ĸ��",									MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},
	{	PROTREAC_RATE,				"Rate",					"�����(A)",								MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTREAC_IKMAX,				"IkMax",				"����·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_IKMIN,				"IkMin",				"��С��·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTREAC_KDREL,				"Kdrel",				"����:���������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_KKREL1,				"Kkrel1",				"����:˲ʱ�����ٶϱ����ɿ�ϵ��",			MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_KKREL3,				"Kkrel3",				"����:���������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_KKRES3,				"Kkres3",				"����:������������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTREAC_IDDZ,				"Iddz",					"�������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_IKDZ1,				"Ikdz1",				"˲ʱ�����ٶ���������(A)",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_IKDZ3,				"Ikdz3",				"����������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTREAC_KSEN1,				"Ksen1",				"У��:˲ʱ�����ٶ�����ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTREAC_KSEN3,				"Ksen3",				"У��:������������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTREAC_REACPTR,			"ReacPtr",				"�豸����",									MDBFieldCategoryAid,	MDB_SHORT,	sizeof(short),			0,	NULL,	},
};

CProtReac::CProtReac(void)
{
}

CProtReac::~CProtReac(void)
{
}

void CProtReac::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	int			nSub, nVolt, nReac;
	tagProtReac	sProtReac;

	m_ProtReacArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nReac=pPGBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nReac<pPGBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nReac++)
			{
				if (pPGBlock->m_ShuntCompensatorArray[nReac].nNode < 0)
					continue;
				if (pPGBlock->m_ShuntCompensatorArray[nReac].fCap > FLT_MIN)
					continue;

				memset(&sProtReac, 0, sizeof(tagProtReac));
				sProtReac.fKdrel = pSetting->fProtReacKdrel;
				sProtReac.fKkrel1 = pSetting->fProtReacKkrel1;
				sProtReac.fKkrel3 = pSetting->fProtReacKkrel3;
				sProtReac.fKkres3 = pSetting->fProtReacKkres3;

				sprintf(sProtReac.szName, "%s.%s.%s", pPGBlock->m_ShuntCompensatorArray[nReac].szSub, pPGBlock->m_ShuntCompensatorArray[nReac].szVolt, pPGBlock->m_ShuntCompensatorArray[nReac].szName);
				if (pPGBlock->m_ShuntCompensatorArray[nReac].nNode >= 0)
					sProtReac.nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ShuntCompensatorArray[nReac].nNode].nTopoBus;
				sProtReac.fRate = (float)(1000*pPGBlock->m_ShuntCompensatorArray[nReac].fCap/1.732/pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);

				sProtReac.nReac = nReac;
				m_ProtReacArray.push_back(sProtReac);
			}
		}
	}
}

void CProtReac::Backup()
{
	m_ProtArray.assign(m_ProtReacArray.begin(), m_ProtReacArray.end());
}

void CProtReac::Restore()
{
	m_ProtReacArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}

void CProtReac::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nProt, nReac, nTopoBus;
	char	szBuffer[260];

	for (nProt=0; nProt<m_ProtReacArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ��·���������С��·����
		nReac=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; i++)
		{
			if (pPGBlock->m_ShuntCompensatorArray[i].bDistribution)
				continue;
			if (pPGBlock->m_ShuntCompensatorArray[i].fCap > FLT_MIN)
				continue;


			sprintf(szBuffer, "%s.%s.%s", pPGBlock->m_ShuntCompensatorArray[i].szSub, pPGBlock->m_ShuntCompensatorArray[i].szVolt, pPGBlock->m_ShuntCompensatorArray[i].szName);
			if (stricmp(szBuffer, m_ProtReacArray[nProt].szName) == 0)
			{
				nReac=i;
				break;
			}
		}
		if (nReac < 0)
			continue;

		nTopoBus = pPGBlock->m_ShuntCompensatorArray[nReac].nTopoBus;
		if (nMode == ConstMaxMode)
		{
			m_ProtReacArray[nProt].fIkmax = sGPArray[nTopoBus].fIa[FLT3];					//	�����·����
			m_ProtReacArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
		else
		{
			m_ProtReacArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
	}
}

void CProtReac::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtReacArray.size(); i++)
	{
		m_ProtReacArray[i].fKdrel = pSetting->fProtReacKdrel;
		m_ProtReacArray[i].fKkrel1 = pSetting->fProtReacKkrel1;
		m_ProtReacArray[i].fKkrel3 = pSetting->fProtReacKkrel3;
		m_ProtReacArray[i].fKkres3 = pSetting->fProtReacKkres3;
	}
}

void CProtReac::Setting(tagProtSetting* pSetting)
{
	int		nProt;

	for (nProt=0; nProt<m_ProtReacArray.size(); nProt++)
	{
		m_ProtReacArray[nProt].fIddz=0;	
		m_ProtReacArray[nProt].fIkdz1=0;	
		m_ProtReacArray[nProt].fIkdz3=0;	
		m_ProtReacArray[nProt].fKsen1=0;	
		m_ProtReacArray[nProt].fKsen3=0;	
	}

	for (nProt=0; nProt<m_ProtReacArray.size(); nProt++)
	{
		m_ProtReacArray[nProt].fIddz = m_ProtReacArray[nProt].fKdrel*m_ProtReacArray[nProt].fRate;
		m_ProtReacArray[nProt].fIkdz1 = m_ProtReacArray[nProt].fKkrel1*m_ProtReacArray[nProt].fRate;
		m_ProtReacArray[nProt].fIkdz3 = m_ProtReacArray[nProt].fKkrel3*m_ProtReacArray[nProt].fRate;
	}
}

void CProtReac::Checking()
{
	int		nProt;

	for (nProt=0; nProt<m_ProtReacArray.size(); nProt++)
	{
		m_ProtReacArray[nProt].fKsen1=0;	
		m_ProtReacArray[nProt].fKsen3=0;	
	}

	for (nProt=0; nProt<m_ProtReacArray.size(); nProt++)
	{
		if (m_ProtReacArray[nProt].fIkdz1 > FLT_MIN)	m_ProtReacArray[nProt].fKsen1=m_ProtReacArray[nProt].fIkmin/m_ProtReacArray[nProt].fIkdz1;
		if (m_ProtReacArray[nProt].fIkdz3 > FLT_MIN)	m_ProtReacArray[nProt].fKsen3=m_ProtReacArray[nProt].fIkmin/m_ProtReacArray[nProt].fIkdz3;
	}
}
