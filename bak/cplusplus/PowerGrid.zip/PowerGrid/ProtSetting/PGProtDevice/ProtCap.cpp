#include "PGProtDevice.h"
#include "ProtCap.h"

static	std::vector<tagProtCap>		m_ProtArray;

static	tagMemDBField	g_ProtCapFieldArray[]=
{
	{	PROTCAP_NAME,				"Name",					"��������������",							MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_LONG,		0,	NULL,	},
	{	PROTCAP_TOPOBUS,				"TopoBus",				"����ĸ��",									MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},
	{	PROTCAP_RATE,				"Rate",					"�����(A)",								MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTCAP_IKMAX,				"IkMax",				"����·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTCAP_IKMIN,				"IkMin",				"��С��·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTCAP_KKREL2,				"Kkrel2",				"����:��ʱ�����ٶϱ����ɿ�ϵ��",			MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTCAP_KKREL3,				"Kkrel3",				"����:���������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTCAP_KKRES3,				"Kkres3",				"����:������������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTCAP_IKDZ2,				"Ikdz2",				"��ʱ�����ٶ���������(A)",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTCAP_IKDZ3,				"Ikdz3",				"����������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTCAP_KSEN2,				"Ksen2",				"У��:��ʱ�����ٶ�����ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTCAP_KSEN3,				"Ksen3",				"У��:������������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTCAP_CAPPTR,				"CapPtr",				"��������������",							MDBFieldCategoryAid,	MDB_SHORT,	sizeof(short),			0,	NULL,	},
};

CProtCap::CProtCap(void)
{
}

CProtCap::~CProtCap(void)
{
}

void CProtCap::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	int			nSub, nVolt, nCap;
	tagProtCap	sProtCap;

	m_ProtCapArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nCap=pPGBlock->m_VoltageLevelArray[nVolt].nShuntCompensatorRange; nCap<pPGBlock->m_VoltageLevelArray[nVolt+1].nShuntCompensatorRange; nCap++)
			{
				if (pPGBlock->m_ShuntCompensatorArray[nCap].nNode < 0)
					continue;
				if (pPGBlock->m_ShuntCompensatorArray[nCap].fCap < FLT_MIN)
					continue;

				memset(&sProtCap, 0, sizeof(tagProtCap));
				sProtCap.fKkrel2 = pSetting->fProtCapKkrel2;
				sProtCap.fKkrel3 = pSetting->fProtCapKkrel3;
				sProtCap.fKkres3 = pSetting->fProtCapKkres3;

				sprintf(sProtCap.szName, "%s.%s.%s", pPGBlock->m_ShuntCompensatorArray[nCap].szSub, pPGBlock->m_ShuntCompensatorArray[nCap].szVolt, pPGBlock->m_ShuntCompensatorArray[nCap].szName);
				if (pPGBlock->m_ShuntCompensatorArray[nCap].nNode >= 0)
					sProtCap.nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_ShuntCompensatorArray[nCap].nNode].nTopoBus;
				sProtCap.fRate = (float)(1000*pPGBlock->m_ShuntCompensatorArray[nCap].fCap/1.732/pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);

				sProtCap.nCap = nCap;
				m_ProtCapArray.push_back(sProtCap);
			}
		}
	}
}

void CProtCap::Backup()
{
	m_ProtArray.assign(m_ProtCapArray.begin(), m_ProtCapArray.end());
}

void CProtCap::Restore()
{
	m_ProtCapArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}

void CProtCap::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nProt, nCap, nTopoBus;
	char	szBuffer[260];

	for (nProt=0; nProt<m_ProtCapArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ�豸���������С��·����
		nCap=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_SHUNTCOMPENSATOR]; i++)
		{
			if (pPGBlock->m_ShuntCompensatorArray[i].bDistribution)
				continue;
			if (pPGBlock->m_ShuntCompensatorArray[i].fCap < FLT_MIN)
				continue;

			sprintf(szBuffer, "%s.%s.%s", pPGBlock->m_ShuntCompensatorArray[i].szSub, pPGBlock->m_ShuntCompensatorArray[i].szVolt, pPGBlock->m_ShuntCompensatorArray[i].szName);
			if (stricmp(szBuffer, m_ProtCapArray[nProt].szName) == 0)
			{
				nCap=i;
				break;
			}
		}
		if (nCap < 0)
			continue;

		nTopoBus = pPGBlock->m_ShuntCompensatorArray[nCap].nTopoBus;
		if (nMode == ConstMaxMode)
		{
			m_ProtCapArray[nProt].fIkmax = sGPArray[nTopoBus].fIa[FLT3];					//	�����·����
			m_ProtCapArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
		else
		{
			m_ProtCapArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
	}
}

void CProtCap::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtCapArray.size(); i++)
	{
		m_ProtCapArray[i].fKkrel2 = pSetting->fProtCapKkrel2;
		m_ProtCapArray[i].fKkrel3 = pSetting->fProtCapKkrel3;
		m_ProtCapArray[i].fKkres3 = pSetting->fProtCapKkres3;
	}
}

void CProtCap::Setting(tagProtSetting* pSetting)
{
	int		nProt;

	for (nProt=0; nProt<m_ProtCapArray.size(); nProt++)
	{
		m_ProtCapArray[nProt].fIkdz2 = 0;
		m_ProtCapArray[nProt].fIkdz3 = 0;
		m_ProtCapArray[nProt].fKsen2 = 0;
		m_ProtCapArray[nProt].fKsen3 = 0;
	}

	for (nProt=0; nProt<m_ProtCapArray.size(); nProt++)
	{
		m_ProtCapArray[nProt].fIkdz2 = m_ProtCapArray[nProt].fKkrel2*m_ProtCapArray[nProt].fRate;
		m_ProtCapArray[nProt].fIkdz3 = m_ProtCapArray[nProt].fKkrel3*m_ProtCapArray[nProt].fRate;
	}
}

void CProtCap::Checking()
{
	int		nProt;

	for (nProt=0; nProt<m_ProtCapArray.size(); nProt++)
	{
		m_ProtCapArray[nProt].fKsen2 = 0;
		m_ProtCapArray[nProt].fKsen3 = 0;
	}

	for (nProt=0; nProt<m_ProtCapArray.size(); nProt++)
	{
		if (m_ProtCapArray[nProt].fIkdz2 > FLT_MIN)	m_ProtCapArray[nProt].fKsen2=m_ProtCapArray[nProt].fIkmin/m_ProtCapArray[nProt].fIkdz2;
		if (m_ProtCapArray[nProt].fIkdz3 > FLT_MIN)	m_ProtCapArray[nProt].fKsen3=m_ProtCapArray[nProt].fIkmin/m_ProtCapArray[nProt].fIkdz3;
	}
}
