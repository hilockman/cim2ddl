#include "PGProtDevice.h"
#include "ProtMotor.h"


static	tagMemDBField	g_PGProtMotorFieldArray[]=
{
	{	PROTMOTOR_NAME,				"Name",					"�綯������",								MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_LONG,		0,	NULL,	},
	{	PROTMOTOR_TOPOBUS,			"TopoBus",				"����ĸ��",									MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},
	{	PROTMOTOR_RATE,				"Rate",					"�����(A)",								MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTMOTOR_IKMAX,				"IkMax",				"����·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_IKMIN,				"IkMin",				"��С��·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTMOTOR_KST,				"Kst",					"����:�綯��������������",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_KDREL,				"Kdrel",				"����:�ݲ���ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_KKREL,				"Kkrel",				"����:���������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_KKRES,				"Kkres",				"����:������������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_KAP,				"Kap",					"����:�����ڷ���Ӱ��ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_KSS,				"Kss",					"����:����������ͬ��ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTMOTOR_IUNBMAX,			"IunbMax",				"�ݲ����ƽ�����(A)",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_IDDZ,				"Iddz",					"�ݲ����������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_IKDZ,				"Ikdz",					"����������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTMOTOR_KDSEN,				"Kdsen",				"У��:�ݲ������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTMOTOR_KKSEN,				"Kksen",				"У��:������������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTMOTOR_LOADPTR,			"LoadPtr",				"�豸����",									MDBFieldCategoryAid,	MDB_INT,	sizeof(int),			0,	NULL,	},
};

CProtMotor::CProtMotor(void)
{
}

CProtMotor::~CProtMotor(void)
{
}

int CProtMotor::FindLoadByProtName(tagPGBlock* pPGBlock, const char* lpszProtName)
{
	register int	i;
	char	szBuffer[260];

	for (i=0; i<pPGBlock->m_nRecordNum[PG_ENERGYCONSUMER]; i++)
	{
		if (pPGBlock->m_EnergyConsumerArray[i].bDistribution)
			continue;
		sprintf(szBuffer, "%s.%s.%s", pPGBlock->m_EnergyConsumerArray[i].szSub, pPGBlock->m_EnergyConsumerArray[i].szVolt, pPGBlock->m_EnergyConsumerArray[i].szName);
		if (stricmp(szBuffer, lpszProtName) == 0)
		{
			return i;
			break;
		}
	}
	return -1;
}

void CProtMotor::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	int			nSub, nVolt, nLoad;
	tagProtMotor	sProtMotor;

	m_ProtMotorArray.clear();
	for (nSub=0; nSub<pPGBlock->m_nRecordNum[PG_SUBSTATION]; nSub++)
	{
		for (nVolt=pPGBlock->m_SubstationArray[nSub].nVoltageLevelRange; nVolt<pPGBlock->m_SubstationArray[nSub+1].nVoltageLevelRange; nVolt++)
		{
			for (nLoad=pPGBlock->m_VoltageLevelArray[nVolt].nEnergyConsumerRange; nLoad<pPGBlock->m_VoltageLevelArray[nVolt+1].nEnergyConsumerRange; nLoad++)
			{
				if (pPGBlock->m_EnergyConsumerArray[nLoad].nNode < 0)
					continue;
				if (pPGBlock->m_EnergyConsumerArray[nLoad].fMotorCapacity < FLT_MIN)	//	ĸ���ϵ綯����������
					continue;

				memset(&sProtMotor, 0, sizeof(tagProtMotor));

				sProtMotor.fKst = pSetting->fProtLoadKst;
				sProtMotor.fKdrel = pSetting->fProtLoadKdrel;
				sProtMotor.fKkrel = pSetting->fProtLoadKkrel;
				sProtMotor.fKkres = pSetting->fProtLoadKkres;
				sProtMotor.fKap = pSetting->fProtLoadKap;
				sProtMotor.fKss = pSetting->fProtLoadKss;

				sprintf(sProtMotor.szName, "%s.%s.%s", pPGBlock->m_EnergyConsumerArray[nLoad].szSub, pPGBlock->m_EnergyConsumerArray[nLoad].szVolt, pPGBlock->m_EnergyConsumerArray[nLoad].szName);
				sProtMotor.nTopoBus = pPGBlock->m_EnergyConsumerArray[nLoad].nTopoBus;

				if (pPGBlock->m_EnergyConsumerArray[nLoad].fMotorCapacity > FLT_MIN)
					sProtMotor.fRate = (float)(pPGBlock->m_EnergyConsumerArray[nLoad].fMotorCapacity/1.732/pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);
				else
					sProtMotor.fRate = (float)(1000*sqrt(pPGBlock->m_EnergyConsumerArray[nLoad].fPlanP*pPGBlock->m_EnergyConsumerArray[nLoad].fPlanP+pPGBlock->m_EnergyConsumerArray[nLoad].fPlanQ*pPGBlock->m_EnergyConsumerArray[nLoad].fPlanQ)/1.732/pPGBlock->m_VoltageLevelArray[nVolt].nominalVoltage);

				sProtMotor.nLoad = nLoad;
				m_ProtMotorArray.push_back(sProtMotor);
			}
		}
	}
}

void CProtMotor::Backup()
{
	m_ProtArray.assign(m_ProtMotorArray.begin(), m_ProtMotorArray.end());
}

void CProtMotor::Restore()
{
	m_ProtMotorArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}

void CProtMotor::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	int		nProt, nLoad, nTopoBus;

	for (nProt=0; nProt<m_ProtMotorArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ��·���������С��·����
		nLoad=FindLoadByProtName(pPGBlock, m_ProtMotorArray[nProt].szName);
		if (nLoad < 0)
			continue;

		nTopoBus = pPGBlock->m_EnergyConsumerArray[nLoad].nTopoBus;
		if (nMode == ConstMaxMode)
		{
			m_ProtMotorArray[nProt].fIkmax = sGPArray[nTopoBus].fIa[FLT3];					//	�����·����
			m_ProtMotorArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
		else
		{
			m_ProtMotorArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];					//	�����·����
		}
	}
}

void CProtMotor::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtMotorArray.size(); i++)
	{
		m_ProtMotorArray[i].fKst   = pSetting->fProtLoadKst;
		m_ProtMotorArray[i].fKdrel = pSetting->fProtLoadKdrel;
		m_ProtMotorArray[i].fKkrel = pSetting->fProtLoadKkrel;
		m_ProtMotorArray[i].fKkres = pSetting->fProtLoadKkres;
		m_ProtMotorArray[i].fKap = pSetting->fProtLoadKap;
		m_ProtMotorArray[i].fKss = pSetting->fProtLoadKss;
	}
}

void CProtMotor::Setting(tagProtSetting* pSetting)
{
	int		nProt;
	float	fIstart;

	for (nProt=0; nProt<m_ProtMotorArray.size(); nProt++)
	{
		m_ProtMotorArray[nProt].fIunbmax=0;		
		m_ProtMotorArray[nProt].fIddz=0;		
		m_ProtMotorArray[nProt].fIkdz=0;		
		m_ProtMotorArray[nProt].fKdsen=0;		
		m_ProtMotorArray[nProt].fKksen=0;		
	}
	for (nProt=0; nProt<m_ProtMotorArray.size(); nProt++)
	{
		fIstart=m_ProtMotorArray[nProt].fKst*m_ProtMotorArray[nProt].fRate;

		m_ProtMotorArray[nProt].fIkdz = m_ProtMotorArray[nProt].fKkrel*fIstart;		//	�����������

		m_ProtMotorArray[nProt].fIunbmax = m_ProtMotorArray[nProt].fKap*m_ProtMotorArray[nProt].fKss*pSetting->fProtKer*fIstart;
		m_ProtMotorArray[nProt].fIddz = m_ProtMotorArray[nProt].fKdrel*m_ProtMotorArray[nProt].fIunbmax;
	}
}

void CProtMotor::Checking()
{
	int		nProt;

	for (nProt=0; nProt<m_ProtMotorArray.size(); nProt++)
	{
		m_ProtMotorArray[nProt].fKdsen=0;		
		m_ProtMotorArray[nProt].fKksen=0;		
	}
	for (nProt=0; nProt<m_ProtMotorArray.size(); nProt++)
	{
		if (m_ProtMotorArray[nProt].fIkdz > FLT_MIN)	m_ProtMotorArray[nProt].fKksen = m_ProtMotorArray[nProt].fIkmin/m_ProtMotorArray[nProt].fIkdz;
	}
}
