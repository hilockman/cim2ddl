#include "PGProtDevice.h"

const	char*	g_lpszLogFile="ProtRelay.log";

#if (!defined(WIN64))
#	pragma comment(lib, "../../../lib/PGMemDB.lib")
#else					 
#	pragma comment(lib, "../../../lib_x64/PGMemDB.lib")
#endif

#if (!defined(WIN64))
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX86 TinyXml.lib")
#else
#	ifdef _DEBUG
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMDd.lib")
#	else
#		pragma comment(lib, "../../../lib_x64/libTinyXmlMD.lib")
#	endif
#	pragma message("Link LibX64 TinyXml.lib")
#endif

void AppendUniqueInteger(const int nInteger, std::vector<int>& nIntArray)
{
	register int	i;
	unsigned char	bExist;

	bExist=0;
	for (i=0; i<(int)nIntArray.size(); i++)
	{
		if (nIntArray[i] == nInteger)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		nIntArray.push_back(nInteger);
}

void SortInteger(std::vector<int>& nArray, int nDn0, int nUp0)
{
	if (nUp0 <= nDn0)
		return;

	int nDn = nDn0;
	int nUp = nUp0;

	int	nBuf=nArray[(nDn0+nUp0)/2];
	while (nDn <= nUp)
	{
		while (nDn < nUp0 && nArray[nDn] < nBuf)
			++nDn;
		while (nUp > nDn0 && nArray[nUp] > nBuf)
			--nUp;

		if (nDn <= nUp)
		{
			std::swap(nArray[nDn], nArray[nUp]);

			++nDn;
			--nUp;
		}
	}

	if (nDn0 < nUp)
		SortInteger(nArray, nDn0, nUp);

	if (nDn < nUp0 )
		SortInteger(nArray, nDn, nUp0);
}
