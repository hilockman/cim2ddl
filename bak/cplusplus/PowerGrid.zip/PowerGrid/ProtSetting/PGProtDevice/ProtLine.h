#pragma once

#include "ProtDefine.h"
#include "ProtParam.h"

enum	_ProtEnum_Field_Line_	{
	PROTLINE_NAME=0,

	PROTLINE_SUBI,
	PROTLINE_SUBJ,
	PROTLINE_VOLT,
	PROTLINE_NORMINALVOLT,
	PROTLINE_RATE,
	PROTLINE_TOPOBUSI,
	PROTLINE_TOPOBUSJ,

	PROTLINE_POWERED,
	PROTLINE_SRCGENI,
	PROTLINE_SRCGENJ,
	PROTLINE_ZGROUND,
	PROTLINE_ZGTOPOBUSI,
	PROTLINE_ZGTOPOBUSJ,

	PROTLINE_IKMAXI,
	PROTLINE_I0MAXI,
	PROTLINE_I0TRANI,

	PROTLINE_IKMININEAR,
	PROTLINE_I0MININEAR,
	PROTLINE_IKMINIFAR,
	PROTLINE_I0MINIFAR,

	PROTLINE_IKMAXJ,
	PROTLINE_I0MAXJ,
	PROTLINE_I0TRANJ,

	PROTLINE_IKMINJNEAR,
	PROTLINE_I0MINJNEAR,
	PROTLINE_IKMINJFAR,
	PROTLINE_I0MINJFAR,

	PROTLINE_IKINTOTRANI,
	PROTLINE_IKINTOTRANJ,

	PROTLINE_N1IKMINI,
	PROTLINE_N1I0MINI,
	PROTLINE_N1IKMINJ,
	PROTLINE_N1I0MINJ,
	PROTLINE_N1IKMINIBUS,
	PROTLINE_N1I0MINIBUS,
	PROTLINE_N1IKMINJBUS,
	PROTLINE_N1I0MINJBUS,

	PROTLINE_KREL1,
	PROTLINE_KREL2,
	PROTLINE_KLM2,
	PROTLINE_KRELP3,
	PROTLINE_KRELL3,
	PROTLINE_K0REL1,
	PROTLINE_K0REL2,
	PROTLINE_K0REL3,
	PROTLINE_K0REL4,

	PROTLINE_KZREL1,
	PROTLINE_KZTREL1,
	PROTLINE_KZP2,
	PROTLINE_KZLM2,
	PROTLINE_KZFH3,

	PROTLINE_KZ0REL1,
	PROTLINE_KZT0REL1,
	PROTLINE_KZ0P2,
	PROTLINE_KZ0LM2,
	PROTLINE_KZ0P3,
	PROTLINE_KZ0LM3,

	PROTLINE_IKDZ2USINGKLM,
	PROTLINE_IKDZ3COORD3,
	PROTLINE_I0PROTINTOTRAN	,
	PROTLINE_I0DZ2COORD2,
	PROTLINE_I0DZ3COORD3,
	PROTLINE_I0DZ3UNB,

	PROTLINE_ZPROTINTOTRAN,
	PROTLINE_ZDZ2COORD2,
	PROTLINE_ZDZ2USINGKLM,
	PROTLINE_ZDZ3COORD3,
	PROTLINE_ZDZ3USINGKFH,

	PROTLINE_Z0PROTINTOTRAN,
	PROTLINE_Z0DZ2COORD2,
	PROTLINE_Z0DZ2USINGKLM,
	PROTLINE_Z0DZ3COORD3,
	PROTLINE_Z0DZ3USINGKLM,

	PROTLINE_IDZ1I,
	PROTLINE_IDZ2I,
	PROTLINE_IDZ3I,

	PROTLINE_I0DZ1I,
	PROTLINE_I0DZ2I,
	PROTLINE_I0DZ3I,
	PROTLINE_I0DZ1INTOTRANI,

	PROTLINE_ZDZ1I,
	PROTLINE_ZDZ2I,
	PROTLINE_ZDZ3I,

	PROTLINE_Z0DZ1I,
	PROTLINE_Z0DZ2I,
	PROTLINE_Z0DZ3I,

	PROTLINE_IDZ1J,
	PROTLINE_IDZ2J,
	PROTLINE_IDZ3J,

	PROTLINE_I0DZ1J,
	PROTLINE_I0DZ2J,
	PROTLINE_I0DZ3J,
	PROTLINE_I0DZ1INTOTRANJ,

	PROTLINE_ZDZ1J,
	PROTLINE_ZDZ2J,
	PROTLINE_ZDZ3J,

	PROTLINE_Z0DZ1J,
	PROTLINE_Z0DZ2J,
	PROTLINE_Z0DZ3J,

	PROTLINE_KSEN1I,
	PROTLINE_KSEN2I,
	PROTLINE_KSEN3I,

	PROTLINE_K0SEN1I,
	PROTLINE_K0SEN2I,
	PROTLINE_K0SEN3I,

	PROTLINE_KSEN1J,
	PROTLINE_KSEN2J,
	PROTLINE_KSEN3J,

	PROTLINE_K0SEN1J,
	PROTLINE_K0SEN2J,
	PROTLINE_K0SEN3J,

	PROTLINE_ACLINESEGMENTPTR,
};

typedef	struct	_Prot_Line_	{
	char			szName[MDB_CHARLEN];

	char			szSubI[MDB_CHARLEN];
	char			szSubJ[MDB_CHARLEN];
	char			szVolt[MDB_CHARLEN_SHORTER];
	float			fNorminalVolt;
	float			fRate;
	int				nTopoBusI;
	int				nTopoBusJ;

	unsigned char	bPowered;
	short			nSrcGenI;
	short			nSrcGenJ;
	unsigned char	bZGround;
	int				nZGBusI;
	int				nZGBusJ;

	//////////////////////////////////////////////////////////////////////////
	//	��·���������С��·����
	float			fIkmaxI;
	float			fI0maxI;
	float			fI0TranI;

	float			fIkminINear;
	float			fI0minINear;
	float			fIkminIFar;
	float			fI0minIFar;

	float			fIkmaxJ;
	float			fI0maxJ;
	float			fI0TranJ;

	float			fIkminJNear;
	float			fI0minJNear;
	float			fIkminJFar;
	float			fI0minJFar;

	unsigned char	bIkIntoTranI;
	unsigned char	bIkIntoTranJ;

	//////////////////////////////////////////////////////////////////////////
	//	��·����һ�����������С��·����������·�򰴱�ѹ���Բ��
	float			fN1IkminI;
	float			fN1I0minI;
	float			fN1IkminJ;
	float			fN1I0minJ;
	char			szN1IkminIBus[MDB_CHARLEN];
	char			szN1I0minIBus[MDB_CHARLEN];
	char			szN1IkminJBus[MDB_CHARLEN];
	char			szN1I0minJBus[MDB_CHARLEN];

	//////////////////////////////////////////////////////////////////////////
	//	�����������ϵ��
	float			fKkrel1;
	float			fKkrel2;
	float			fKklm2;
	float			fKkrelP3;
	float			fKkrelL3;
	float			fK0rel1;
	float			fK0rel2;
	float			fK0rel3;
	float			fK0rel4;

	float			fKZrel1;
	float			fKZTrel1;
	float			fKZp2;
	float			fKZlm2;
	float			fKZfh3;

	float			fKZ0rel1;
	float			fKZT0rel1;
	float			fKZ0p2;
	float			fKZ0lm2;
	float			fKZ0p3;
	float			fKZ0lm3;

	unsigned char	bIkdz2UsingKlm;
	unsigned char	bIkdz3Coord3;
	unsigned char	bI0ProtIntoTran;
	unsigned char	bI0dz2Coord2;
	unsigned char	bI0dz3Coord3;
	unsigned char	bI0dz3Unb;

	unsigned char	bZProtIntoTran;
	unsigned char	bZdz2Coord2;
	unsigned char	bZdz2UsingKlm;
	unsigned char	bZdz3Coord3;
	unsigned char	bZdz3UsingKfh;

	unsigned char	bZ0ProtIntoTran;
	unsigned char	bZ0dz2Coord2;
	unsigned char	bZ0dz2UsingKlm;
	unsigned char	bZ0dz3Coord3;
	unsigned char	bZ0dz3UsingKlm;

	//////////////////////////////////////////////////////////////////////////
	//	I�ౣ������ֵ
	float			fIkdz1I;
	float			fIkdz2I;
	float			fIkdz3I;

	float			fI0dz1I;
	float			fI0dz2I;
	float			fI0dz3I;
	unsigned char	bI0dzIntoTranI;

	float			fZkdz1I;
	float			fZkdz2I;
	float			fZkdz3I;

	float			fZ0dz1I;
	float			fZ0dz2I;
	float			fZ0dz3I;

	//////////////////////////////////////////////////////////////////////////
	//	J�ౣ������ֵ
	float			fIdz1J;
	float			fIdz2J;
	float			fIdz3J;

	float			fI0dz1J;
	float			fI0dz2J;
	float			fI0dz3J;
	unsigned char	bI0dzIntoTranJ;

	float			fZdz1J;
	float			fZdz2J;
	float			fZdz3J;

	float			fZ0dz1J;
	float			fZ0dz2J;
	float			fZ0dz3J;

	//////////////////////////////////////////////////////////////////////////
	//	I�ౣ������ϵ��
	float			fKsen1I;
	float			fKsen2I;
	float			fKsen3I;

	float			fK0sen1I;
	float			fK0sen2I;
	float			fK0sen3I;

	//////////////////////////////////////////////////////////////////////////
	//	J�ౣ������ϵ��
	float			fKsen1J;
	float			fKsen2J;
	float			fKsen3J;

	float			fK0sen1J;
	float			fK0sen2J;
	float			fK0sen3J;

	short			nACLineSegment;
}	tagProtLine;

//////////////////////////////////////////////////////////////////////////
//	��·������δ���Ǵ����翹�����������翹��������������
class PGPROTDEVICE_EXPORTS CProtLine
{
public:
	CProtLine(void);
	~CProtLine(void);

public:
	std::vector<tagProtLine>	m_ProtLineArray;

public:
	void	Init (tagPGBlock* pPGBlock, tagProtSetting* pSetting);
	void	SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray);
	void	SetDefaultProtParam(tagProtSetting* pSetting);

	void	SettingMaxMode(tagProtSetting* pSetting, std::vector<tagGraphPoint>& sGPArray);
	//	����Ҫ���������������ı���������������
	void	SettingMinMode(std::vector<tagGraphPoint>& sGPArray);

	void	Checking();
	void	Backup();
	void	Restore();

private:
	void SetLineAllScValue(tagPGBlock* pPGBlock, const int nProt, const int nLine, std::vector<tagGraphPoint>& sGPArray);
	void SetLineMinScValue(tagPGBlock* pPGBlock, const int nProt, const int nLine, std::vector<tagGraphPoint>& sGPArray);

	//	������·��ָ��֧·֮��ķ�֧ϵ��
	float Line2BranKf1(const int nLineTun, unsigned char nLineSide, const short nFitBranType, const char* lpszFitBranName, std::vector<tagGraphPoint>& sGPArray);
	float Line2BranKf0(const int nLineTun, unsigned char nLineSide, const short nFitBranType, const char* lpszFitBranName, std::vector<tagGraphPoint>& sGPArray);

	int FindLineByProtLineName(tagPGBlock* pPGBlock, const char* lpszProtName);
	int FindProtByProtLineName(const char* lpszProtName);

	//	�Զ�����·����ֵ�������Ƚ�������
	void SettingI(std::vector<tagGraphPoint>& sGPArray);
	void SettingI2(std::vector<tagGraphPoint>& sGPArray);
	void SettingI3(std::vector<tagGraphPoint>& sGPArray);

	void SettingI0(tagProtSetting* pSetting, std::vector<tagGraphPoint>& sGPArray);
	void SettingI01(std::vector<tagGraphPoint>& sGPArray);
	void SettingI02(std::vector<tagGraphPoint>& sGPArray);
	void SettingI03(tagProtSetting* pSetting, std::vector<tagGraphPoint>& sGPArray);


	float	ResolveTranIkunb(const int nStartTopoBus, const char* lpszTranName, std::vector<tagGraphPoint>& sGPArray);

private:
	std::vector<int>			m_nZGBusArray;
	void FormZGBusArray(tagPGBlock* pPGBlock);	//	�γ�����ӵ�ĸ�߱�

private:
	std::vector<tagProtLine>	m_ProtArray;
};
