#include "PGProtDevice.h"
#include "ProtBus.h"

static	tagMemDBField	g_PGProtBusFieldArray[]=
{
	{	PROTBUS_NAME,				"Name",					"ĸ������",									MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_LONG,		0,	NULL,	},
	{	PROTBUS_TOPOBUS,				"TopoBus",				"����ĸ��",									MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},

	{	PROTBUS_IBRANKMAX,			"IbrankMax",			"֧·����·����(A)",						MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_IBRANEMAX,			"IbraneMax",			"֧·��󸺺ɵ���(A)",						MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_IKMIN,				"IkMin",				"��С��·����(A)",							MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBUS_KUNBREL,				"Kunbrel",				"����:��ƽ������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_KBRKREL,				"Kbrkrel",				"����:���ζ��߿ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_FAULTUNB,			"Faultunb",				"����:�ⲿ��·����������ƽ�����(A)",		MDBFieldCategoryParam,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},

	{	PROTBUS_IKOP,				"Ikop",					"�ⲿ��·���㲻ƽ�����(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_ILOP,				"Ilop",					"��󸺺ɼ��㲻ƽ�����(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_IOOP,				"Ioop",					"��ܶ��ζ��߲������������(A)",			MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTBUS_IKDZ,				"Ikdz",					"����������������(A)",						MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBUS_KSEN,				"Ksen",					"У��:���������ϵ��",					MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTBUS_BUSPTR,				"BusPtr",				"ĸ������",									MDBFieldCategoryAid,	MDB_SHORT,	sizeof(short),			0,	NULL,	},
};

CProtBus::CProtBus(void)
{
}

CProtBus::~CProtBus(void)
{
}

void CProtBus::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	register int	i;
	int			nBus, nDev, nNode;
	int			nNodeNum, nNodeArray[400];
	tagProtBus	sProtBus;

	for (nBus=0; nBus<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nBus++)
	{
		if (pPGBlock->m_BusbarSectionArray[nBus].nNode < 0)
			continue;
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].bOpen=1;
	}

	//m_ProtBusArray.clear();

	m_ProtBusArray.clear();
	for (nBus=0; nBus<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nBus++)
	{
		if (pPGBlock->m_BusbarSectionArray[nBus].nNode < 0)
			continue;

		memset(&sProtBus, 0, sizeof(tagProtBus));
		sProtBus.fKunbrel = pSetting->fProtBusKunbrel;
		sProtBus.fKbrkrel = pSetting->fProtBusKbrkrel;
		sProtBus.bFaultUnb = pSetting->bProtBusFaultUnb;

		sprintf(sProtBus.szName, "%s.%s.%s", pPGBlock->m_BusbarSectionArray[nBus].szSub, pPGBlock->m_BusbarSectionArray[nBus].szVolt, pPGBlock->m_BusbarSectionArray[nBus].szName);
		if (pPGBlock->m_BusbarSectionArray[nBus].nNode >= 0)
			sProtBus.nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].nTopoBus;

		sProtBus.fIbranemax = 0;
		PGTraverseVolt(pPGBlock, pPGBlock->m_BusbarSectionArray[nBus].nNode, Y_CheckStatus, Y_CheckStatus, N_BreakerBound, N_BusBound, nNodeNum, nNodeArray);
		for (nNode=0; nNode<nNodeNum; nNode++)
		{
			for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nACLineSegmentRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nACLineSegmentRange; i++)
			{
				nDev=pPGBlock->m_EdgeACLineSegmentArray[i].nACLineSegment;
				sProtBus.fIbranemax = max(pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur, sProtBus.fIbranemax);
			}
			for (i=pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]].nTransformerWindingRange; i<pPGBlock->m_ConnectivityNodeArray[nNodeArray[nNode]+1].nTransformerWindingRange; i++)
			{
				nDev=pPGBlock->m_EdgeTransformerWindingArray[i].nTransformerWinding;
				sProtBus.fIbranemax = (float)max(1000*pPGBlock->m_TransformerWindingArray[nDev].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_ConnectivityNodeArray[nNode].nVoltageLevelPtr].nominalVoltage, sProtBus.fIbranemax);
			}
		}

		if (sProtBus.fKunbrel < FLT_MIN)
		{
			sProtBus.fKunbrel = pSetting->fProtBusKunbrel;
			sProtBus.bFaultUnb = pSetting->bProtBusFaultUnb;
		}
		if (sProtBus.fKbrkrel < FLT_MIN)	{	sProtBus.fKbrkrel = pSetting->fProtBusKbrkrel;	}

		sProtBus.nBus = nBus;
		m_ProtBusArray.push_back(sProtBus);
	}

	for (nBus=0; nBus<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; nBus++)
	{
		if (pPGBlock->m_BusbarSectionArray[nBus].nNode < 0)
			continue;
		pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].bOpen=0;
	}
}

void CProtBus::Backup()
{
	m_ProtArray.assign(m_ProtBusArray.begin(), m_ProtBusArray.end());
}

void CProtBus::Restore()
{
	m_ProtBusArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}

void CProtBus::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nProt, nBus;
	int		nTopoBus;
	float	fMaxBranScc;
	char	szBuffer[260];

	for (nProt=0; nProt<m_ProtBusArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ���������С��·����
		nBus=-1;
		for (i=0; i<pPGBlock->m_nRecordNum[PG_BUSBARSECTION]; i++)
		{
			sprintf(szBuffer, "%s.%s.%s", pPGBlock->m_BusbarSectionArray[i].szSub, pPGBlock->m_BusbarSectionArray[i].szVolt, pPGBlock->m_BusbarSectionArray[i].szName);
			if (stricmp(szBuffer, m_ProtBusArray[nProt].szName) == 0)
			{
				nBus=i;
				break;
			}
		}
		if (nBus < 0)
			continue;

		nTopoBus = pPGBlock->m_ConnectivityNodeArray[pPGBlock->m_BusbarSectionArray[nBus].nNode].nTopoBus;
		if (nMode == ConstMaxMode)
		{
			fMaxBranScc = 0;
			for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
				fMaxBranScc = max(fMaxBranScc, sGPArray[nTopoBus].sN1BranArray[i].fIa[FLT3]);
			m_ProtBusArray[nProt].fIbrankmax = fMaxBranScc;

			m_ProtBusArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];
		}
		else
		{
			m_ProtBusArray[nProt].fIkmin = sGPArray[nTopoBus].fIb[FLT2];
		}
	}
}

void CProtBus::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtBusArray.size(); i++)
	{
		m_ProtBusArray[i].fKunbrel = pSetting->fProtBusKunbrel;
		m_ProtBusArray[i].fKbrkrel = pSetting->fProtBusKbrkrel;
		m_ProtBusArray[i].bFaultUnb = pSetting->bProtBusFaultUnb;
	}
}

//////////////////////////////////////////////////////////////////////////
//	ĸ�߲����
//		����Ӧ�ɿ���������������ƽ��������������һԪ���������λ�·����ʱ�ɸ��ɵ���������������
//	IDZ��KK��fI��IFHmax
//	IDZ��KK��IFHmax
//		�̲ģ��ɿ�����ⲿ�������ƽ�����
void CProtBus::Setting(tagProtSetting* pSetting)
{
	int		nProt;

	for (nProt=0; nProt<m_ProtBusArray.size(); nProt++)
	{
		m_ProtBusArray[nProt].fIkop=0;
		m_ProtBusArray[nProt].fIlop=0;
		m_ProtBusArray[nProt].fIoop=0;
		m_ProtBusArray[nProt].fIdz=0;
		m_ProtBusArray[nProt].fKsen=0;
	}

	for (nProt=0; nProt<m_ProtBusArray.size(); nProt++)
	{
		m_ProtBusArray[nProt].fIkop = m_ProtBusArray[nProt].fKunbrel*pSetting->fProtKer*m_ProtBusArray[nProt].fIbrankmax;		//	����ⲿ��·�������������
		m_ProtBusArray[nProt].fIlop = m_ProtBusArray[nProt].fKunbrel*pSetting->fProtKer*m_ProtBusArray[nProt].fIbranemax;		//	������ƽ������������������
		m_ProtBusArray[nProt].fIoop = m_ProtBusArray[nProt].fKbrkrel*m_ProtBusArray[nProt].fIbranemax;										//	��ܶ��ζ��߲������������

		m_ProtBusArray[nProt].fIdz=0;
		if (m_ProtBusArray[nProt].bFaultUnb)
			m_ProtBusArray[nProt].fIdz = m_ProtBusArray[nProt].fIkop;
		m_ProtBusArray[nProt].fIdz = max(m_ProtBusArray[nProt].fIdz, m_ProtBusArray[nProt].fIlop);
		m_ProtBusArray[nProt].fIdz = max(m_ProtBusArray[nProt].fIdz, m_ProtBusArray[nProt].fIoop);
	}
}

void CProtBus::Checking()
{
	int		nProt;

	for (nProt=0; nProt<m_ProtBusArray.size(); nProt++)
	{
		m_ProtBusArray[nProt].fKsen=0;
	}

	for (nProt=0; nProt<m_ProtBusArray.size(); nProt++)
	{
		m_ProtBusArray[nProt].fKsen = m_ProtBusArray[nProt].fIkmin/m_ProtBusArray[nProt].fIdz;
	}
}
