#include "PGProtDevice.h"
#include "ProtTran.h"

static	tagMemDBField	g_ProtTranFieldArray[]=
{
	{	PROTTRAN_NAME,				"Name",					"��ѹ������",								MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN,			0,	NULL,	},
	{	PROTTRAN_SUB,				"Sub",					"��վ",										MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN,			0,	NULL,	},

	{	PROTTRAN_VOLTH,				"VoltH",				"��ѹ����ѹ�ȼ�",							MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_SHORTER,	0,	NULL,	},
	{	PROTTRAN_VOLTM,				"VoltM",				"��ѹ����ѹ�ȼ�",							MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_SHORTER,	0,	NULL,	},
	{	PROTTRAN_VOLTL,				"VoltL",				"��ѹ����ѹ�ȼ�",							MDBFieldCategoryBase,	MDB_STRING,	MDB_CHARLEN_SHORTER,	0,	NULL,	},
	{	PROTTRAN_3WIND,				"ThreeWind",			"��������",								MDBFieldCategoryBase,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_TOPOBUSH,			"TopoBusH",				"��ѹ������ĸ��",							MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},
	{	PROTTRAN_TOPOBUSM,			"TopoBusM",				"��ѹ������ĸ��",							MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},
	{	PROTTRAN_TOPOBUSL,			"TopoBusL",				"��ѹ������ĸ��",							MDBFieldCategoryBase,	MDB_INT,	sizeof(int),			0,	NULL,	},

	{	PROTTRAN_RATEVOLTH,			"RateVoltH",			"��ѹ�����ѹ(kV)",						MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_RATEVOLTM,			"RateVoltM",			"��ѹ�����ѹ(kV)",						MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_RATEVOLTL,			"RateVoltL",			"��ѹ�����ѹ(kV)",						MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_RATEH,				"RateH",				"��ѹ�������(A)",						MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_RATEM,				"RateM",				"��ѹ�������(A)",						MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_RATEL,				"RateL",				"��ѹ�������(A)",						MDBFieldCategoryBase,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_LOADTRAN,			"LoadTran",				"���ɱ�ѹ��",								MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_POWERH,				"PowerH",				"��ѹ���Դ���",							MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_POWERM,				"PowerM",				"��ѹ���Դ���",							MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_POWERL,				"PowerL",				"��ѹ���Դ���",							MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_ZGSTATH,			"ZGStatH",				"��ѹ��������",							MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_ZGSTATM,			"ZGStatM",				"��ѹ��������",							MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},
	{	PROTTRAN_ZGSTATL,			"ZGStatL",				"��ѹ��������",							MDBFieldCategoryAid,	MDB_BIT,	sizeof(unsigned char),	0,	NULL,	},

	{	PROTTRAN_ITMAXH,				"ItmaxH",				"��ѹ���ѹ���ڲ�����·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_ITMAXM,				"ItmaxM",				"��ѹ���ѹ���ڲ�����·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_ITMAXL,				"ItmaxL",				"��ѹ���ѹ���ڲ�����·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_ITMINH,				"ItminH",				"��ѹ���ѹ���ڲ���С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_ITMINM,				"ItminM",				"��ѹ���ѹ���ڲ���С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_ITMINL,				"ItminL",				"��ѹ���ѹ���ڲ���С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0TMAXH,			"I0tmaxH",				"��ѹ���ѹ���ڲ�����������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0TMAXM,			"I0tmaxM",				"��ѹ���ѹ���ڲ�����������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0TMAXL,			"I0tmaxL",				"��ѹ���ѹ���ڲ�����������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0TMINH,			"I0tminH",				"��ѹ���ѹ���ڲ���С�������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0TMINM,			"I0tminM",				"��ѹ���ѹ���ڲ���С�������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0TMINL,			"I0tminL",				"��ѹ���ѹ���ڲ���С�������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IOBMAXH,			"IobmaxH",				"��ѹ��Բ��������·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IOBMAXM,			"IobmaxM",				"��ѹ��Բ��������·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IOBMAXL,			"IobmaxL",				"��ѹ��Բ��������·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IOBMINH,			"IobminH",				"��ѹ��Բ������С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IOBMINM,			"IobminM",				"��ѹ��Բ������С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IOBMINL,			"IobminL",				"��ѹ��Բ������С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKMAXHNEAR,			"IkmaxHNear",			"��ѹ��ĸ�߹�������·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMAXMNEAR,			"IkmaxMNear",			"��ѹ��ĸ�߹�������·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMAXLNEAR,			"IkmaxLNear",			"��ѹ��ĸ�߹�������·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKMINHNEAR,			"IkminHNear",			"��ѹ��ĸ�߹�����С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMINMNEAR,			"IkminMNear",			"��ѹ��ĸ�߹�����С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMINLNEAR,			"IkminLNear",			"��ѹ��ĸ�߹�����С��·����(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0KMAXHNEAR,		"I0kmaxHNear",			"��ѹ��ĸ�߹�������������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMAXMNEAR,		"I0kmaxMNear",			"��ѹ��ĸ�߹�������������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMAXLNEAR,		"I0kmaxLNear",			"��ѹ��ĸ�߹�������������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0KMINHNEAR,		"I0kminHNear",			"��ѹ��ĸ�߹�����С�������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMINMNEAR,		"I0kminMNear",			"��ѹ��ĸ�߹�����С�������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMINLNEAR,		"I0kminLNear",			"��ѹ��ĸ�߹�����С�������(A)",			MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKMAXHFAR,			"IkmaxHFar",			"��ѹ��һ��������·ĩ��������·����(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMAXMFAR,			"IkmaxMFar",			"��ѹ��һ��������·ĩ��������·����(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMAXLFAR,			"IkmaxLFar",			"��ѹ��һ��������·ĩ��������·����(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKMINHFAR,			"IkminHFar",			"��ѹ��һ��������·ĩ������С��·����(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMINMFAR,			"IkminMFar",			"��ѹ��һ��������·ĩ������С��·����(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKMINLFAR,			"IkminLFar",			"��ѹ��һ��������·ĩ������С��·����(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0KMAXHFAR,			"I0kmaxHFar",			"��ѹ��һ��������·ĩ��������������(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMAXMFAR,			"I0kmaxMFar",			"��ѹ��һ��������·ĩ��������������(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMAXLFAR,			"I0kmaxLFar",			"��ѹ��һ��������·ĩ��������������(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0KMINHFAR,			"I0kminHFar",			"��ѹ��һ��������·ĩ������С�������(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMINMFAR,			"I0kminMFar",			"��ѹ��һ��������·ĩ������С�������(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0KMINLFAR,			"I0kminLFar",			"��ѹ��һ��������·ĩ������С�������(A)",	MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKUNBH,				"IkunbH",				"��ѹ�಻ƽ�����(A)",						MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKUNBM,				"IkunbM",				"��ѹ�಻ƽ�����(A)",						MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKUNBL,				"IkunbL",				"��ѹ�಻ƽ�����(A)",						MDBFieldCategoryAid,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_KKSLM1,				"Kkslm1",				"����:��Դ�������α�������ϵ��",			MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KKLLM1,				"Kkllm1",				"����:���ɲ������α�������ϵ��",			MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KKREL3,				"Kkrel3",				"����:���������ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KKRES3,				"Kkres3",				"����:������������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_KUOP,				"Kuop",					"����:��ѹ������ѹֵ",						MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KUOPREL,			"Kuoprel",				"����:��ѹ�����ɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KUOPRES,			"Kuopres",				"����:��ѹ��������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_K0LM1,				"K0lm1",				"����:����������ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_K0REL2,				"K0rel2",				"����:�����οɿ�ϵ��",					MDBFieldCategoryParam,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKDZ1H,				"Ikdz1H",				"��ѹ�ฺ�ɲ�������������������(A)",		MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKDZ1M,				"Ikdz1M",				"��ѹ�ฺ�ɲ�������������������(A)",		MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKDZ1L,				"Ikdz1L",				"��ѹ�ฺ�ɲ�������������������(A)",		MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_IKDZ3H,				"Ikdz3H",				"��ѹ�����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKDZ3M,				"Ikdz3M",				"��ѹ�����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_IKDZ3L,				"Ikdz3L",				"��ѹ�����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_UOPH,				"UopH",					"��ѹ�ิѹ����������ѹ(kV)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_UOPM,				"UopM",					"��ѹ�ิѹ����������ѹ(kV)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_UOPL,				"UopL",					"��ѹ�ิѹ����������ѹ(kV)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0DZ1H,				"I0dz1H",				"��ѹ����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0DZ1M,				"I0dz1M",				"��ѹ����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0DZ1L,				"I0dz1L",				"��ѹ����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_I0DZ2H,				"I0dz2H",				"��ѹ����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0DZ2M,				"I0dz2M",				"��ѹ����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_I0DZ2L,				"I0dz2L",				"��ѹ����������������(A)",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_KKSEN3H,			"Kksen3H",				"У��:��ѹ�������������ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KKSEN3M,			"Kksen3M",				"У��:��ѹ�������������ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},
	{	PROTTRAN_KKSEN3L,			"Kksen3L",				"У��:��ѹ�������������ϵ��",				MDBFieldCategoryOutput,	MDB_FLOAT,	sizeof(float),			0,	NULL,	},

	{	PROTTRAN_POWERTRANSFORMERPTR, "PowerTransformerPtr",	"��ѹ������",								MDBFieldCategoryAid,	MDB_SHORT,	sizeof(short),			0,	NULL,	},
};

extern	const	char*		g_lpszLogFile;
extern	void	Log(const char* lpszLogFile, char* pformat, ...);
extern	void	ClearLog(const char* lpszLogFile);


CProtTran::CProtTran(void)
{
}

CProtTran::~CProtTran(void)
{
}

int CProtTran::FindTranByProtTranName(tagPGBlock* pPGBlock, const char* lpszProtTranName)
{
	register int	i;
	char	szBuffer[260];

	for (i=0; i<pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; i++)
	{
		sprintf(szBuffer, "%s.%s", pPGBlock->m_PowerTransformerArray[i].szSub, pPGBlock->m_PowerTransformerArray[i].szName);
		if (stricmp(szBuffer, lpszProtTranName) == 0)
		{
			return i;
			break;
		}
	}
	return -1;
}

void CProtTran::Init(tagPGBlock* pPGBlock, tagProtSetting* pSetting)
{
	register int	i;
	int		nVolt, nTran, nDev, nNode;
	int		nNodeHNum, nNodeHArray[400];
	int		nNodeMNum, nNodeMArray[400];
	int		nNodeLNum, nNodeLArray[400];
	int		nNodeNum, *pnNodeArray;
	unsigned char	nPowerWind;
	std::vector<unsigned char>	bProcArray;

	pnNodeArray=(int*)malloc(sizeof(int)*pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);
	if (!pnNodeArray)
		return;

	bProcArray.resize(pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]);

	m_ProtTranArray.resize(pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]);
	for (i=0; i<pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; i++)
		memset(&m_ProtTranArray[i], 0, sizeof(tagProtTran));

	//////////////////////////////////////////////////////////////////////////
	//	�ж������Դ���
	for (nTran=0; nTran<pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nTran++)
	{
		m_ProtTranArray[nTran].fKkslm1 = pSetting->fProtTranKkslm1;
		m_ProtTranArray[nTran].fKkllm1 = pSetting->fProtTranKkllm1;
		m_ProtTranArray[nTran].fKkrel3 = pSetting->fProtTranKkrel3;
		m_ProtTranArray[nTran].fKkres3 = pSetting->fProtTranKkres3;

		m_ProtTranArray[nTran].fKuop   = pSetting->fProtTranKuop;
		m_ProtTranArray[nTran].fKuoprel = pSetting->fProtTranKuoprel;
		m_ProtTranArray[nTran].fKuopres = pSetting->fProtTranKuopres;

		m_ProtTranArray[nTran].fK0lm1 = pSetting->fProtTranK0lm1;
		m_ProtTranArray[nTran].fK0rel2 = pSetting->fProtTranK0rel2;

		for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)	pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;

		nNodeHNum = nNodeMNum = nNodeLNum = 0;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindH >= 0)
		{
			if (pPGBlock->m_PowerTransformerArray[nTran].nWindNum == 3)
			{
				m_ProtTranArray[nTran].fRateVoltH = (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bTranMidSide == 1) ?
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].fRatedkVJ : pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].fRatedkVI;
			}
			else
			{
				m_ProtTranArray[nTran].fRateVoltH = pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].fRatedkVI;
			}
			m_ProtTranArray[nTran].fRateH = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nTran].nVoltH].nominalVoltage);
		}
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindM >= 0)
		{
			m_ProtTranArray[nTran].fRateVoltM = (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bTranMidSide == 1) ?
				pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].fRatedkVJ : pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].fRatedkVI;
			m_ProtTranArray[nTran].fRateM = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nTran].nVoltM].nominalVoltage);
		}
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindL >= 0)
		{
			if (pPGBlock->m_PowerTransformerArray[nTran].nWindNum == 3)
			{
				m_ProtTranArray[nTran].fRateVoltL = (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].bTranMidSide == 1) ?
					pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].fRatedkVJ : pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].fRatedkVI;
			}
			else
			{
				m_ProtTranArray[nTran].fRateVoltL = pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].fRatedkVJ;
			}

			m_ProtTranArray[nTran].fRateL = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nTran].nVoltL].nominalVoltage);
		}
		m_ProtTranArray[nTran].nPowerTransformer = nTran;

		m_ProtTranArray[nTran].nTopoBusH=pPGBlock->m_PowerTransformerArray[nTran].nTopoBusH;		//	����ĸ��
		m_ProtTranArray[nTran].nTopoBusM=pPGBlock->m_PowerTransformerArray[nTran].nTopoBusM;		//	����ĸ��
		m_ProtTranArray[nTran].nTopoBusL=pPGBlock->m_PowerTransformerArray[nTran].nTopoBusL;		//	����ĸ��

		pPGBlock->m_PowerTransformerArray[nTran].bOpen=1;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindH >= 0)	pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bOpen=1;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindM >= 0)	pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bOpen=1;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindL >= 0)	pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].bOpen=1;

		sprintf(m_ProtTranArray[nTran].szName, "%s.%s", pPGBlock->m_PowerTransformerArray[nTran].szSub, pPGBlock->m_PowerTransformerArray[nTran].szName);

		strcpy(m_ProtTranArray[nTran].szSub, pPGBlock->m_PowerTransformerArray[nTran].szSub);
		strcpy(m_ProtTranArray[nTran].szVoltH, pPGBlock->m_PowerTransformerArray[nTran].szVoltH);
		strcpy(m_ProtTranArray[nTran].szVoltM, pPGBlock->m_PowerTransformerArray[nTran].szVoltM);
		strcpy(m_ProtTranArray[nTran].szVoltL, pPGBlock->m_PowerTransformerArray[nTran].szVoltL);
		m_ProtTranArray[nTran].b3Wind = (pPGBlock->m_PowerTransformerArray[nTran].nWindNum == 3) ? 1 : 0;

		if (pPGBlock->m_PowerTransformerArray[nTran].nWindNum == 3)
		{
			if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].nWindingType == PGEnumTransformerWinding_WindConnectio_3WD)
			{
				m_ProtTranArray[nTran].nZGStatH = m_ProtTranArray[nTran].nZGStatM = m_ProtTranArray[nTran].nZGStatL = 0;
				if (pPGBlock->m_PowerTransformerArray[nTran].nWindH >= 0 && pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bNeutralStatus == 0)
				{
					m_ProtTranArray[nTran].nZGStatH = 2;	//	����ӵ�
				}
				if (pPGBlock->m_PowerTransformerArray[nTran].nWindM >= 0 && pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bNeutralStatus == 0)
				{
					m_ProtTranArray[nTran].nZGStatM = 2;	//	����ӵ�
				}
			}
			else if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].nWindingType == PGEnumTransformerWinding_WindConnectio_3WY || pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].nWindingType == PGEnumTransformerWinding_WindConnectio_3WAuto)
			{
				if (pPGBlock->m_PowerTransformerArray[nTran].nWindH >= 0 && pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bNeutralStatus == 0)
				{
					m_ProtTranArray[nTran].nZGStatH = 1;	//	����֧·
				}
				if (pPGBlock->m_PowerTransformerArray[nTran].nWindM >= 0 && pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bNeutralStatus == 0)
				{
					m_ProtTranArray[nTran].nZGStatM = 1;	//	����֧·
				}
				if (pPGBlock->m_PowerTransformerArray[nTran].nWindL >= 0 && pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].bNeutralStatus == 0)
				{
					m_ProtTranArray[nTran].nZGStatL = 1;	//	����֧·
				}
			}
		}
		else
		{
			if (pPGBlock->m_PowerTransformerArray[nTran].nWindH >= 0)
			{
				if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bNeutralStatus == 0)
				{
					if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].nWindingType == PGEnumTransformerWinding_WindConnectio_2WYY)
					{
						m_ProtTranArray[nTran].nZGStatH = 1;	//	����֧·
						m_ProtTranArray[nTran].nZGStatL = 1;	//	����֧·
					}
					else if (pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].nWindingType == PGEnumTransformerWinding_WindConnectio_2WYD)
					{
						m_ProtTranArray[nTran].nZGStatH = 2;	//	����ӵ�
						m_ProtTranArray[nTran].nZGStatL = 0;	//	����ͨ
					}
				}
			}
		}

		if (pPGBlock->m_PowerTransformerArray[nTran].nNodeH >= 0)	PGTraverseVolt(pPGBlock, pPGBlock->m_PowerTransformerArray[nTran].nNodeH, Y_CheckStatus, Y_CheckStatus, N_BreakerBound, N_BusBound, nNodeHNum, nNodeHArray);
		if (pPGBlock->m_PowerTransformerArray[nTran].nNodeM >= 0)	PGTraverseVolt(pPGBlock, pPGBlock->m_PowerTransformerArray[nTran].nNodeM, Y_CheckStatus, Y_CheckStatus, N_BreakerBound, N_BusBound, nNodeMNum, nNodeMArray);
		if (pPGBlock->m_PowerTransformerArray[nTran].nNodeL >= 0)	PGTraverseVolt(pPGBlock, pPGBlock->m_PowerTransformerArray[nTran].nNodeL, Y_CheckStatus, Y_CheckStatus, N_BreakerBound, N_BusBound, nNodeLNum, nNodeLArray);
		for (i=0; i<nNodeHNum; i++)	pPGBlock->m_ConnectivityNodeArray[nNodeHArray[i]].bOpen=1;
		for (i=0; i<nNodeMNum; i++)	pPGBlock->m_ConnectivityNodeArray[nNodeMArray[i]].bOpen=1;
		for (i=0; i<nNodeLNum; i++)	pPGBlock->m_ConnectivityNodeArray[nNodeLArray[i]].bOpen=1;

		//Log(g_lpszLogFile, "�ж����� : %s [%d %d %d]\n", m_ProtTranArray[nTran].szTranName, nNodeHNum, nNodeMNum, nNodeLNum);

		nPowerWind=0;
		for (i=0; i<(int)bProcArray.size(); i++)
			bProcArray[i]=0;
		for (nNode=0; nNode<nNodeHNum; nNode++)
		{
			if (bProcArray[nNodeHArray[nNode]])
				continue;

			PGTraverseNet(pPGBlock, nNodeHArray[nNode], Y_CheckStatus, 0, nNodeNum, pnNodeArray);
			for (i=0; i<nNodeNum; i++)
				bProcArray[pnNodeArray[i]]=1;

			for (i=0; i<nNodeNum; i++)
			{
				nVolt=pPGBlock->m_ConnectivityNodeArray[pnNodeArray[i]].nVoltageLevelPtr;
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
				{
					if (pPGBlock->m_SynchronousMachineArray[nDev].nNode == pnNodeArray[i])
					{
						//Log(g_lpszLogFile, "    H�����ӷ���� [%s %s]\n", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szName);
						m_ProtTranArray[nTran].bPowerH=1;
						nPowerWind++;
						goto _HPowerOut_;
					}
				}
			}
		}
_HPowerOut_:;

		for (i=0; i<(int)bProcArray.size(); i++)
			bProcArray[i]=0;
		for (nNode=0; nNode<nNodeMNum; nNode++)
		{
			if (bProcArray[nNodeMArray[nNode]])
				continue;

			PGTraverseNet(pPGBlock, nNodeMArray[nNode], Y_CheckStatus, 0, nNodeNum, pnNodeArray);
			for (i=0; i<nNodeNum; i++)
				bProcArray[pnNodeArray[i]]=1;

			for (i=0; i<nNodeNum; i++)
			{
				nVolt=pPGBlock->m_ConnectivityNodeArray[pnNodeArray[i]].nVoltageLevelPtr;
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
				{
					if (pPGBlock->m_SynchronousMachineArray[nDev].nNode == pnNodeArray[i])
					{
						//Log(g_lpszLogFile, "    M�����ӷ���� [%s %s]\n", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szName);
						m_ProtTranArray[nTran].bPowerM=1;
						nPowerWind++;
						goto _MPowerOut_;
					}
				}
			}
		}
_MPowerOut_:;

		for (i=0; i<(int)bProcArray.size(); i++)
			bProcArray[i]=0;
		for (nNode=0; nNode<nNodeLNum; nNode++)
		{
			if (bProcArray[nNodeLArray[nNode]])
				continue;

			PGTraverseNet(pPGBlock, nNodeLArray[nNode], Y_CheckStatus, 0, nNodeNum, pnNodeArray);
			for (i=0; i<nNodeNum; i++)
				bProcArray[pnNodeArray[i]]=1;

			for (i=0; i<nNodeNum; i++)
			{
				nVolt=pPGBlock->m_ConnectivityNodeArray[pnNodeArray[i]].nVoltageLevelPtr;
				for (nDev=pPGBlock->m_VoltageLevelArray[nVolt].nSynchronousMachineRange; nDev<pPGBlock->m_VoltageLevelArray[nVolt+1].nSynchronousMachineRange; nDev++)
				{
					if (pPGBlock->m_SynchronousMachineArray[nDev].nNode == pnNodeArray[i])
					{
						//Log(g_lpszLogFile, "    L�����ӷ���� [%s %s]\n", pPGBlock->m_SynchronousMachineArray[nDev].szSub, pPGBlock->m_SynchronousMachineArray[nDev].szName);
						m_ProtTranArray[nTran].bPowerL=1;
						nPowerWind++;
						goto _LPowerOut_;
					}
				}
			}
		}
_LPowerOut_:;

		if (nPowerWind <= 1)
			m_ProtTranArray[nTran].bLoadTran=1;

		pPGBlock->m_PowerTransformerArray[nTran].bOpen=0;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindH >= 0)	pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bOpen=0;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindM >= 0)	pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bOpen=0;
		if (pPGBlock->m_PowerTransformerArray[nTran].nWindL >= 0)	pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].bOpen=0;
	}

	for (i=0; i<pPGBlock->m_nRecordNum[PG_CONNECTIVITYNODE]; i++)	pPGBlock->m_ConnectivityNodeArray[i].bOpen=0;
	free(pnNodeArray);
}

void CProtTran::Backup()
{
	m_ProtArray.assign(m_ProtTranArray.begin(), m_ProtTranArray.end());
}

void CProtTran::Restore()
{
	m_ProtTranArray.assign(m_ProtArray.begin(), m_ProtArray.end());
}

void CProtTran::SetTranAllScValue(tagPGBlock* pPGBlock, const int nProt, const int nTran, std::vector<tagGraphPoint> sGPArray)
{
	register int	i;
	int		nOpp, nTopoBus, nOppTopoBus;
	float	fBuffer;
	clock_t	dBeg, dEnd;
	int		nDur;

	dBeg=clock();

	m_ProtTranArray[nProt].fIkunbH = ResolveTranIkunb(pPGBlock->m_PowerTransformerArray[nTran].nTopoBusH, m_ProtTranArray[nProt].szName, sGPArray);
	m_ProtTranArray[nProt].fIkunbM = ResolveTranIkunb(pPGBlock->m_PowerTransformerArray[nTran].nTopoBusM, m_ProtTranArray[nProt].szName, sGPArray);
	m_ProtTranArray[nProt].fIkunbL = ResolveTranIkunb(pPGBlock->m_PowerTransformerArray[nTran].nTopoBusL, m_ProtTranArray[nProt].szName, sGPArray);

	//dEnd=clock();
	//nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
	//Log(g_lpszLogFile, "        �������಻ƽ�������ʱ = %d ����\n", nDur);

	nTopoBus = pPGBlock->m_PowerTransformerArray[nTran].nTopoBusH;
	if (nTopoBus > 0 && !pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bOutage)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�ڲ����ϵ�������ĸ�߶�·����������
		m_ProtTranArray[nProt].fItmaxH = sGPArray[nTopoBus].fIa[FLT3];
		m_ProtTranArray[nProt].fI0tmaxH = max(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		m_ProtTranArray[nProt].fItminH = sGPArray[nTopoBus].fIb[FLT2];
		m_ProtTranArray[nProt].fI0tminH = min(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ���Ͻ��˵����������С��·�������ӵص������Ե�ȵ�λ=0���������Ӧ��Ϊ0
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fIkmaxHNear = sGPArray[nTopoBus].sN1BranArray[i].fIa[FLT3];
				m_ProtTranArray[nProt].fIkminHNear = sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];
				break;
			}
		}
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fI0kmaxHNear = max(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				m_ProtTranArray[nProt].fI0kminHNear = min(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				break;
			}
		}

		// 		dEnd=clock();
		// 		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		// 		Log(g_lpszLogFile, "        ��ֵ��·���˵�����ʱ = %d ����\n", nDur);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ����Զ�˵����������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT && sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIkmaxHFar = max(m_ProtTranArray[nProt].fIkmaxHFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIa[FLT3]);
					m_ProtTranArray[nProt].fI0kmaxHFar = max(m_ProtTranArray[nProt].fI0kmaxHFar, max(sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]));

					if (sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIkminHFar = (m_ProtTranArray[nProt].fIkminHFar < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIkminHFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2]);

					fBuffer=0;
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1]);
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]);
					if (fBuffer > FLT_MIN)
						m_ProtTranArray[nProt].fI0kminHFar = (m_ProtTranArray[nProt].fI0kminHFar < FLT_MIN) ? fBuffer : min(m_ProtTranArray[nProt].fI0kminHFar, fBuffer);
				}
			}
		}

		// 		dEnd=clock();
		// 		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		// 		Log(g_lpszLogFile, "        ��ֵ��·Զ�˵�����ʱ = %d ����\n", nDur);

		//////////////////////////////////////////////////////////////////////////
		//	������ϣ��Բ�����������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOppTopoBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nProt].szName) == 0 && sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIobmaxH = max(m_ProtTranArray[nProt].fIobmaxH, sGPArray[nOppTopoBus].sN2BranArray[i].fIa[FLT3]);

					if (sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] > FLT_MIN)
					{
						m_ProtTranArray[nProt].fIobminH = (m_ProtTranArray[nProt].fIobminH < FLT_MIN) ?
							sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIobminH, sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2]);
					}
				}
			}
		}

		// 		dEnd=clock();
		// 		nDur=(int)((1000.0*(double)(dEnd-dBeg))/CLOCKS_PER_SEC);
		// 		Log(g_lpszLogFile, "        ��ֵ��ѹ���Զ˵�����ʱ = %d ����\n", nDur);
	}

	nTopoBus = pPGBlock->m_PowerTransformerArray[nTran].nTopoBusM;
	if (nTopoBus > 0 && !pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bOutage)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�ڲ����ϵ���
		m_ProtTranArray[nProt].fItmaxM = sGPArray[nTopoBus].fIa[FLT3];
		m_ProtTranArray[nProt].fI0tmaxM = max(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		m_ProtTranArray[nProt].fItminM = sGPArray[nTopoBus].fIb[FLT2];
		m_ProtTranArray[nProt].fI0tminM = min(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ���Ͻ��˵����������С��·�������ӵص������Ե�ȵ�λ=0���������Ӧ��Ϊ0
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fIkmaxMNear = sGPArray[nTopoBus].sN1BranArray[i].fIa[FLT3];
				m_ProtTranArray[nProt].fIkminMNear = sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];
				break;
			}
		}
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fI0kmaxMNear = max(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				m_ProtTranArray[nProt].fI0kminMNear = min(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				break;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ����Զ�˵����������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT && sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIkmaxMFar = max(m_ProtTranArray[nProt].fIkmaxMFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIa[FLT3]);
					m_ProtTranArray[nProt].fI0kmaxMFar = max(m_ProtTranArray[nProt].fI0kmaxMFar, max(sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]));

					if (sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIkminMFar = (m_ProtTranArray[nProt].fIkminMFar < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIkminMFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2]);

					fBuffer=0;
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1]);
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]);
					if (fBuffer > FLT_MIN)
						m_ProtTranArray[nProt].fI0kminMFar = (m_ProtTranArray[nProt].fI0kminMFar < FLT_MIN) ? fBuffer : min(m_ProtTranArray[nProt].fI0kminMFar, fBuffer);
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	������ϣ��Բ�����������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOppTopoBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nProt].szName) == 0 && sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIobmaxM = max(m_ProtTranArray[nProt].fIobmaxM, sGPArray[nOppTopoBus].sN2BranArray[i].fIa[FLT3]);

					if (sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] > FLT_MIN)
					{
						m_ProtTranArray[nProt].fIobminM = (m_ProtTranArray[nProt].fIobminM < FLT_MIN) ?
							sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIobminM, sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2]);
					}
				}
			}
		}
	}

	nTopoBus = pPGBlock->m_PowerTransformerArray[nTran].nTopoBusL;
	if (nTopoBus > 0 && !pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].bOutage)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�ڲ����ϵ���
		m_ProtTranArray[nProt].fItmaxL = sGPArray[nTopoBus].fIa[FLT3];
		m_ProtTranArray[nProt].fI0tmaxL = max(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		m_ProtTranArray[nProt].fItminL = sGPArray[nTopoBus].fIb[FLT2];
		m_ProtTranArray[nProt].fI0tminL = min(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ���Ͻ��˵����������С��·����
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fIkmaxLNear = sGPArray[nTopoBus].sN1BranArray[i].fIa[FLT3];
				m_ProtTranArray[nProt].fIkminLNear = sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];
				break;
			}
		}
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fI0kmaxLNear = max(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				m_ProtTranArray[nProt].fI0kminLNear = min(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				break;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ����Զ�˵����������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT && sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIkmaxLFar = max(m_ProtTranArray[nProt].fIkmaxLFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIa[FLT3]);
					m_ProtTranArray[nProt].fI0kmaxLFar = max(m_ProtTranArray[nProt].fI0kmaxLFar, max(sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]));

					m_ProtTranArray[nProt].fIkminLFar = (m_ProtTranArray[nProt].fIkminLFar < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIkminLFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2]);

					fBuffer=0;
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1]);
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]);
					if (fBuffer > FLT_MIN)
						m_ProtTranArray[nProt].fI0kminLFar = (m_ProtTranArray[nProt].fI0kminLFar < FLT_MIN) ? fBuffer : min(m_ProtTranArray[nProt].fI0kminLFar, fBuffer);
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	������ϣ��Բ�����������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOppTopoBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nProt].szName) == 0 && sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIobmaxL = max(m_ProtTranArray[nProt].fIobmaxL, sGPArray[nOppTopoBus].sN2BranArray[i].fIa[FLT3]);
					if (sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] > FLT_MIN)
					{
						m_ProtTranArray[nProt].fIobminL = (m_ProtTranArray[nProt].fIobminL < FLT_MIN) ?
							sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIobminL, sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2]);
					}
				}
			}
		}
	}
}

void CProtTran::SetTranMinScValue(tagPGBlock* pPGBlock, const int nProt, const int nTran, std::vector<tagGraphPoint> sGPArray)
{
	register int	i;
	int		nOpp;
	int		nTopoBus, nOppTopoBus;
	float	fBuffer;

	nTopoBus = pPGBlock->m_PowerTransformerArray[nTran].nTopoBusH;
	if (nTopoBus > 0 && !pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindH].bOutage)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�ڲ����ϵ�������С��·����
		m_ProtTranArray[nProt].fItminH = sGPArray[nTopoBus].fIb[FLT2];
		m_ProtTranArray[nProt].fI0tminH = min(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ���Ͻ��˵�������С��·����
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fIkminHNear = sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];
				break;
			}
		}
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fI0kminHNear = min(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				break;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ����Զ�˵�������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT && sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
				{
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIkminHFar = (m_ProtTranArray[nProt].fIkminHFar < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIkminHFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2]);

					fBuffer=0;
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1]);
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]);
					if (fBuffer > FLT_MIN)
						m_ProtTranArray[nProt].fI0kminHFar = (m_ProtTranArray[nProt].fI0kminHFar < FLT_MIN) ? fBuffer : min(m_ProtTranArray[nProt].fI0kminHFar, fBuffer);
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	������ϣ��Բ��������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOppTopoBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nProt].szName) == 0 && sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)
				{
					if (sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIobminH = (m_ProtTranArray[nProt].fIobminH < FLT_MIN) ? sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIobminH, sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2]);
				}
			}
		}
	}

	nTopoBus = pPGBlock->m_PowerTransformerArray[nTran].nTopoBusM;
	if (nTopoBus > 0 && !pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindM].bOutage)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�ڲ����ϵ�������С��·����
		m_ProtTranArray[nProt].fItminM = sGPArray[nTopoBus].fIb[FLT2];
		m_ProtTranArray[nProt].fI0tminM = min(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ���Ͻ��˵�������С��·����
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fIkminMNear = sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];
				break;
			}
		}
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fI0kminMNear = min(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				break;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ����Զ�˵�������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT && sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
				{
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIkminMFar = (m_ProtTranArray[nProt].fIkminMFar < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIkminMFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2]);

					fBuffer=0;
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1]);
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]);
					if (fBuffer > FLT_MIN)
						m_ProtTranArray[nProt].fI0kminMFar = (m_ProtTranArray[nProt].fI0kminMFar < FLT_MIN) ? fBuffer : min(m_ProtTranArray[nProt].fI0kminMFar, fBuffer);
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	������ϣ��Բ��������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOppTopoBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nProt].szName) == 0 && sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)
				{
					if (sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIobminM = (m_ProtTranArray[nProt].fIobminM < FLT_MIN) ? sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIobminM, sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2]);
				}
			}
		}
	}

	nTopoBus = pPGBlock->m_PowerTransformerArray[nTran].nTopoBusL;
	if (nTopoBus > 0 && !pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nTran].nWindL].bOutage)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�ڲ����ϵ�������С��·����
		m_ProtTranArray[nProt].fItminL = sGPArray[nTopoBus].fIb[FLT2];
		m_ProtTranArray[nProt].fI0tminL = min(sGPArray[nTopoBus].fI0[FLT1], sGPArray[nTopoBus].fI0[FLT4]);

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ���Ͻ��˵�������С��·����
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fIkminLNear = sGPArray[nTopoBus].sN1BranArray[i].fIb[FLT2];
				break;
			}
		}
		for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
		{
			if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), m_ProtTranArray[nTran].szName) == 0)
			{
				m_ProtTranArray[nProt].fI0kminLNear = min(sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT1], sGPArray[nTopoBus].sN1BranArray[i].fI0[FLT4]);
				break;
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	�ⲿ����Զ�˵�������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN1BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN1BranArray[i].nBranType == PG_ACLINESEGMENT && sGPArray[nOppTopoBus].sN1BranArray[i].nToTopoBus == nTopoBus)
				{
					m_ProtTranArray[nProt].fIkminLFar = (m_ProtTranArray[nProt].fIkminLFar < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIkminLFar, sGPArray[nOppTopoBus].sN1BranArray[i].fIb[FLT2]);

					fBuffer=0;
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT1]);
					if (sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] > FLT_MIN)
						fBuffer = (fBuffer < FLT_MIN) ? sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4] : min(fBuffer, sGPArray[nOppTopoBus].sN1BranArray[i].fI0[FLT4]);
					if (fBuffer > FLT_MIN)
						m_ProtTranArray[nProt].fI0kminLFar = (m_ProtTranArray[nProt].fI0kminLFar < FLT_MIN) ? fBuffer : min(m_ProtTranArray[nProt].fI0kminLFar, fBuffer);
				}
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	������ϣ��Բ��������С��·����
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOppTopoBus=sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (i=0; i<(int)sGPArray[nOppTopoBus].sN2BranArray.size(); i++)
			{
				if (sGPArray[nOppTopoBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOppTopoBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nProt].szName) == 0 && sGPArray[nOppTopoBus].sN2BranArray[i].nFrTopoBus == nTopoBus)
				{
					if (sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] > FLT_MIN)
						m_ProtTranArray[nProt].fIobminL = (m_ProtTranArray[nProt].fIobminL < FLT_MIN) ? sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2] : min(m_ProtTranArray[nProt].fIobminL, sGPArray[nOppTopoBus].sN2BranArray[i].fIb[FLT2]);
				}
			}
		}
	}
}

float CProtTran::Tran2BranKf1(const int nTranTun, const unsigned char nTranSide, const short nFitBranType, const char* lpszFitBranName, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nTopoBus, nOBus;
	float	fIfl, fInl;
	float	fBuffer, fKbrmax, fKbrmin;

	nTopoBus = -1;
	switch (nTranSide)
	{
	case	ConstTranSideH:
		nTopoBus = m_ProtTranArray[nTranTun].nTopoBusH;
		break;
	case	ConstTranSideM:
		nTopoBus = m_ProtTranArray[nTranTun].nTopoBusM;
		break;
	case	ConstTranSideL:
		nTopoBus = m_ProtTranArray[nTranTun].nTopoBusL;
		break;
	}
	if (nTopoBus < 0)
		return 1;

	//Log(g_lpszLogFile, "������· : %s <-> %s I��֧ϵ��\n", m_ProtTranArray[nTranTun].szName, m_ProtTranArray[nLineFit].szName);
	//////////////////////////////////////////////////////////////////////////
	//	���� I-J �����֧ϵ��
	fKbrmax = fKbrmin = 0;
	fIfl=fInl=0;

	nOBus=-1;
	for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
	{
		if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == nFitBranType && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), lpszFitBranName) == 0)
		{
			nOBus=sGPArray[nTopoBus].sN1BranArray[i].nToTopoBus;
			break;
		}
	}
	if (nOBus < 0)
		return 1;

	for (i=0; i<(int)sGPArray[nOBus].sN2BranArray.size(); i++)
	{
		if (sGPArray[nOBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nTranTun].szName) == 0)
		{
			fInl = sGPArray[nOBus].sN2BranArray[i].fIa[FLT3];					//	����֧·һ������֧·�����������ϵ�Ķ�������֧·
			//Log(g_lpszLogFile, "        %s ����ĸ�� = %s %s ���ϵ��� = %f\n", m_ProtTranArray[nTranTun].szSub, 
			//	pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nOBus].nVolt].szSub, 
			//	pPGBlock->m_VoltageLevelArray[pPGBlock->m_TopoBusArray[nOBus].nVolt].szName, fInl);
			break;
		}
	}
	if (fInl < FLT_MIN)
		return 1;

	for (i=0; i<(int)sGPArray[nOBus].sN1BranArray.size(); i++)
	{
		if (sGPArray[nOBus].sN1BranArray[i].nBranType == nFitBranType && stricmp(sGPArray[nOBus].sN1BranArray[i].strBranName.c_str(), lpszFitBranName) == 0)
		{
			fIfl = max(fIfl, sGPArray[nOBus].sN1BranArray[i].fIa[FLT3]);	//	����֧·����
			if (fIfl < FLT_MIN)
				continue;

			//Log(g_lpszLogFile, "                ���ϵ��� = %f ֧·[%s]���� = %s\n", fIfl, PGGetTableDesp(sGPArray[nOBus].sN1BranArray[i].nBranType), sGPArray[nOBus].sN1BranArray[i].strBranName.c_str());
			fBuffer=fIfl/fInl;
			fKbrmax=max(fKbrmax, fBuffer);
			fKbrmin=(fKbrmin < FLT_MIN) ? fBuffer : min(fKbrmin, fBuffer);
		}
	}
	return (fKbrmin > FLT_MIN) ? fKbrmin : 1;
}

float CProtTran::Tran2BranKf0(const int nTranTun, const unsigned char nTranSide, const short nFitBranType, const char* lpszFitBranName, std::vector<tagGraphPoint>& sGPArray)
{
	register int	i;
	int		nTopoBus, nOBus;
	float	fIfl, fInl;
	float	fBuffer, fKbrmax, fKbrmin;

	nTopoBus = -1;
	switch (nTranSide)
	{
	case	ConstTranSideH:
		nTopoBus = m_ProtTranArray[nTranTun].nTopoBusH;
		break;
	case	ConstTranSideM:
		nTopoBus = m_ProtTranArray[nTranTun].nTopoBusM;
		break;
	case	ConstTranSideL:
		nTopoBus = m_ProtTranArray[nTranTun].nTopoBusL;
		break;
	}
	if (nTopoBus < 0)
		return 1;

	if (stricmp(m_ProtTranArray[nTranTun].szSub, "110kV�����") == 0)
		Log(g_lpszLogFile, "�����ѹ��(%d) : %s <-> %s ��֧ϵ��\n", nTranSide, m_ProtTranArray[nTranTun].szName, lpszFitBranName);
	//////////////////////////////////////////////////////////////////////////
	//	���� I-J �����֧ϵ��
	fKbrmax = fKbrmin = 0;
	fIfl=fInl=0;
	nOBus=-1;

	for (i=0; i<(int)sGPArray[nTopoBus].sN1BranArray.size(); i++)
	{
		if (sGPArray[nTopoBus].sN1BranArray[i].nBranType == nFitBranType && stricmp(sGPArray[nTopoBus].sN1BranArray[i].strBranName.c_str(), lpszFitBranName) == 0)
		{
			nOBus=sGPArray[nTopoBus].sN1BranArray[i].nToTopoBus;
			break;
		}
	}
	if (nOBus < 0)
	{
		if (stricmp(m_ProtTranArray[nTranTun].szSub, "110kV�����") == 0)
			Log(g_lpszLogFile, "        û���ҵ�����ĸ��\n");
		return 1;
	}

	for (i=0; i<(int)sGPArray[nOBus].sN2BranArray.size(); i++)
	{
		if (sGPArray[nOBus].sN2BranArray[i].nBranType == PG_POWERTRANSFORMER && stricmp(sGPArray[nOBus].sN2BranArray[i].strBranName.c_str(), m_ProtTranArray[nTranTun].szName) == 0)
		{
			fInl = sGPArray[nOBus].sN2BranArray[i].fI0[FLT1];					//	����֧·һ������֧·�����������ϵ�Ķ�������֧·
			break;
		}
	}
	if (fInl < FLT_MIN)
	{
		if (stricmp(m_ProtTranArray[nTranTun].szSub, "110kV�����") == 0)
			Log(g_lpszLogFile, "        ��ѹ�����ϵ���Ϊ0\n");
		return 1;
	}

	for (i=0; i<(int)sGPArray[nOBus].sN1BranArray.size(); i++)
	{
		if (sGPArray[nOBus].sN1BranArray[i].nBranType == nFitBranType && stricmp(sGPArray[nOBus].sN1BranArray[i].strBranName.c_str(), lpszFitBranName) == 0)
		{
			fIfl = max(fIfl, sGPArray[nOBus].sN1BranArray[i].fI0[FLT1]);	//	����֧·����
			if (fIfl < FLT_MIN)
				continue;

			if (stricmp(m_ProtTranArray[nTranTun].szSub, "110kV�����") == 0)
				Log(g_lpszLogFile, "                ��·���ϵ��� = %f ֧·[%s]���� = %s\n", fIfl, PGGetTableDesp(sGPArray[nOBus].sN1BranArray[i].nBranType), sGPArray[nOBus].sN1BranArray[i].strBranName.c_str());
			fBuffer=fIfl/fInl;
			fKbrmax=max(fKbrmax, fBuffer);
			fKbrmin=(fKbrmin < FLT_MIN) ? fBuffer : min(fKbrmin, fBuffer);
		}
	}
	return (fKbrmin > FLT_MIN) ? fKbrmin : 1;
}

void CProtTran::SetScValue(tagPGBlock* pPGBlock, const unsigned char nMode, std::vector<tagGraphPoint>& sGPArray)
{
	int		nProt, nTran;

	for (nProt=0; nProt<m_ProtTranArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	��ȡ��ѹ��һ�����������С��·����
		nTran=FindTranByProtTranName(pPGBlock, m_ProtTranArray[nProt].szName);
		if (nTran < 0)
			continue;

		if (nMode == ConstMaxMode)
		{
			SetTranAllScValue(pPGBlock, nProt, nTran, sGPArray);
		}
		else
		{
			SetTranMinScValue(pPGBlock, nProt, nTran, sGPArray);
		}
	}
}

void CProtTran::SetDefaultProtParam(tagProtSetting* pSetting)
{
	register int	i;
	for (i=0; i<m_ProtTranArray.size(); i++)
	{
		m_ProtTranArray[i].fKkslm1		= pSetting->fProtTranKkslm1 ;
		m_ProtTranArray[i].fKkllm1		= pSetting->fProtTranKkllm1 ;
		m_ProtTranArray[i].fKkrel3		= pSetting->fProtTranKkrel3 ;
		m_ProtTranArray[i].fKkres3		= pSetting->fProtTranKkres3 ;

		m_ProtTranArray[i].fKuop			= pSetting->fProtTranKuop ;
		m_ProtTranArray[i].fKuoprel		= pSetting->fProtTranKuoprel;
		m_ProtTranArray[i].fKuopres		= pSetting->fProtTranKuopres;

		m_ProtTranArray[i].fK0lm1			= pSetting->fProtTranK0lm1;		
		m_ProtTranArray[i].fK0rel2		= pSetting->fProtTranK0rel2;		
	}
}

void CProtTran::SettingMaxMode(const std::vector<tagProtLine>&sProtLineArray, std::vector<tagGraphPoint>& sGPArray)
{
	int		nProt;

	for (nProt=0; nProt<m_ProtTranArray.size(); nProt++)
	{
		m_ProtTranArray[nProt].fIkdz1H=0;		
		m_ProtTranArray[nProt].fIkdz1M=0;		
		m_ProtTranArray[nProt].fIkdz1L=0;		

		m_ProtTranArray[nProt].fIkdz3H=0;		
		m_ProtTranArray[nProt].fIkdz3M=0;		
		m_ProtTranArray[nProt].fIkdz3L=0;		

		m_ProtTranArray[nProt].fUopH=0;			
		m_ProtTranArray[nProt].fUopM=0;			
		m_ProtTranArray[nProt].fUopL=0;			

		m_ProtTranArray[nProt].fI0dz1H=0;		
		m_ProtTranArray[nProt].fI0dz1M=0;		
		m_ProtTranArray[nProt].fI0dz1L=0;		

		m_ProtTranArray[nProt].fI0dz2H=0;		
		m_ProtTranArray[nProt].fI0dz2M=0;		
		m_ProtTranArray[nProt].fI0dz2L=0;		

		m_ProtTranArray[nProt].fKksen3H=0;		
		m_ProtTranArray[nProt].fKksen3M=0;		
		m_ProtTranArray[nProt].fKksen3L=0;		
	}

	for (nProt=0; nProt<m_ProtTranArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	������α������������㱾��ĸ��������������
		if (!m_ProtTranArray[nProt].bPowerH)
		{
			if (m_ProtTranArray[nProt].fKkllm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1H = m_ProtTranArray[nProt].fIkminHNear/m_ProtTranArray[nProt].fKkllm1;	//	����ĸ�߹�����������
		}
		else
		{
			if (m_ProtTranArray[nProt].fKkslm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1H = m_ProtTranArray[nProt].fIobminH/m_ProtTranArray[nProt].fKkslm1;		//	�Բ�ĸ�߹�����������
		}
		if (!m_ProtTranArray[nProt].bPowerM)
		{
			if (m_ProtTranArray[nProt].fKkllm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1M = m_ProtTranArray[nProt].fIkminMNear/m_ProtTranArray[nProt].fKkllm1;	//	����ĸ�߹�����������
		}
		else
		{
			if (m_ProtTranArray[nProt].fKkslm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1M = m_ProtTranArray[nProt].fIobminM/m_ProtTranArray[nProt].fKkslm1;		//	�Բ�ĸ�߹�����������
		}
		if (!m_ProtTranArray[nProt].bPowerL)
		{
			if (m_ProtTranArray[nProt].fKkllm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1L = m_ProtTranArray[nProt].fIkminLNear/m_ProtTranArray[nProt].fKkllm1;	//	����ĸ�߹�����������
		}
		else
		{
			if (m_ProtTranArray[nProt].fKkslm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1L = m_ProtTranArray[nProt].fIobminL/m_ProtTranArray[nProt].fKkslm1;		//	�Բ�ĸ�߹�����������
		}

		//////////////////////////////////////////////////////////////////////////
		//	�����������������㸺�ɵ�������
		m_ProtTranArray[nProt].fIkdz3H = m_ProtTranArray[nProt].fKkrel3*m_ProtTranArray[nProt].fRateH;				//	����󸺺ɵ�������
		if (m_ProtTranArray[nProt].fKkres3 > FLT_MIN)
			m_ProtTranArray[nProt].fIkdz3H /= m_ProtTranArray[nProt].fKkres3;

		m_ProtTranArray[nProt].fUopH = m_ProtTranArray[nProt].fKuop*m_ProtTranArray[nProt].fRateVoltH;
		if (m_ProtTranArray[nProt].fKuoprel > FLT_MIN)
			m_ProtTranArray[nProt].fUopH /= m_ProtTranArray[nProt].fKuoprel;
		if (m_ProtTranArray[nProt].fKuopres > FLT_MIN)
			m_ProtTranArray[nProt].fUopH /= m_ProtTranArray[nProt].fKkres3;


		m_ProtTranArray[nProt].fIkdz3M = m_ProtTranArray[nProt].fKkrel3*m_ProtTranArray[nProt].fRateM;				//	����󸺺ɵ�������
		if (m_ProtTranArray[nProt].fKkres3 > FLT_MIN)
			m_ProtTranArray[nProt].fIkdz3M /= m_ProtTranArray[nProt].fKkres3;

		m_ProtTranArray[nProt].fUopM = m_ProtTranArray[nProt].fKuop*m_ProtTranArray[nProt].fRateVoltM;
		if (m_ProtTranArray[nProt].fKuoprel > FLT_MIN)
			m_ProtTranArray[nProt].fUopM /= m_ProtTranArray[nProt].fKuoprel;
		if (m_ProtTranArray[nProt].fKuopres > FLT_MIN)
			m_ProtTranArray[nProt].fUopM /= m_ProtTranArray[nProt].fKkres3;


		m_ProtTranArray[nProt].fIkdz3L = m_ProtTranArray[nProt].fKkrel3*m_ProtTranArray[nProt].fRateL;				//	����󸺺ɵ�������
		if (m_ProtTranArray[nProt].fKkres3 > FLT_MIN)
			m_ProtTranArray[nProt].fIkdz3L /= m_ProtTranArray[nProt].fKkres3;

		m_ProtTranArray[nProt].fUopL = m_ProtTranArray[nProt].fKuop*m_ProtTranArray[nProt].fRateVoltL;
		if (m_ProtTranArray[nProt].fKuoprel > FLT_MIN)
			m_ProtTranArray[nProt].fUopL /= m_ProtTranArray[nProt].fKuoprel;
		if (m_ProtTranArray[nProt].fKuopres > FLT_MIN)
			m_ProtTranArray[nProt].fUopL /= m_ProtTranArray[nProt].fKkres3;

		//////////////////////////////////////////////////////////////////////////
		//	�����α������������㱾��ĸ��������������
		if (m_ProtTranArray[nProt].nZGStatH != 0)
		{
			if (m_ProtTranArray[nProt].fK0lm1 > FLT_MIN)
				m_ProtTranArray[nProt].fI0dz1H = m_ProtTranArray[nProt].fI0kminHNear/m_ProtTranArray[nProt].fK0lm1;		//	������ĸ��������������
		}
		if (m_ProtTranArray[nProt].nZGStatM != 0)
		{
			if (m_ProtTranArray[nProt].fK0lm1 > FLT_MIN)
				m_ProtTranArray[nProt].fI0dz1M = m_ProtTranArray[nProt].fI0kminMNear/m_ProtTranArray[nProt].fK0lm1;		//	������ĸ��������������
		}
		if (m_ProtTranArray[nProt].nZGStatL != 0)
		{
			if (m_ProtTranArray[nProt].fK0lm1 > FLT_MIN)
				m_ProtTranArray[nProt].fI0dz1L = m_ProtTranArray[nProt].fI0kminLNear/m_ProtTranArray[nProt].fK0lm1;		//	������ĸ��������������
		}

		//////////////////////////////////////////////////////////////////////////
		//	�����α�������������·��ĩһ�����򱣻����
		if (m_ProtTranArray[nProt].nZGStatH != 0)
		{
			m_ProtTranArray[nProt].fI0dz2H = m_ProtTranArray[nProt].fK0rel2*ResolveProtLineMaxI0dz(sProtLineArray, nProt, m_ProtTranArray[nProt].nTopoBusH, sGPArray);
		}
		if (m_ProtTranArray[nProt].nZGStatM != 0)
		{
			m_ProtTranArray[nProt].fI0dz2M = m_ProtTranArray[nProt].fK0rel2*ResolveProtLineMaxI0dz(sProtLineArray, nProt, m_ProtTranArray[nProt].nTopoBusM, sGPArray);
		}
		if (m_ProtTranArray[nProt].nZGStatL != 0)
		{
			m_ProtTranArray[nProt].fI0dz2L = m_ProtTranArray[nProt].fK0rel2*ResolveProtLineMaxI0dz(sProtLineArray, nProt, m_ProtTranArray[nProt].nTopoBusL, sGPArray);
		}
	}
}

void CProtTran::SettingMinMode(std::vector<tagGraphPoint>& sGPArray)
{
	int		nProt;

	for (nProt=0; nProt<m_ProtTranArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	������α������������㱾��ĸ��������������
		if (!m_ProtTranArray[nProt].bPowerH)
		{
			if (m_ProtTranArray[nProt].fKkllm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1H = m_ProtTranArray[nProt].fIkminHNear/m_ProtTranArray[nProt].fKkllm1;	//	����ĸ�߹�����������
		}
		else
		{
			if (m_ProtTranArray[nProt].fKkslm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1H = m_ProtTranArray[nProt].fIobminH/m_ProtTranArray[nProt].fKkslm1;		//	�Բ�ĸ�߹�����������
		}
		if (!m_ProtTranArray[nProt].bPowerM)
		{
			if (m_ProtTranArray[nProt].fKkllm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1M = m_ProtTranArray[nProt].fIkminMNear/m_ProtTranArray[nProt].fKkllm1;	//	����ĸ�߹�����������
		}
		else
		{
			if (m_ProtTranArray[nProt].fKkslm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1M = m_ProtTranArray[nProt].fIobminM/m_ProtTranArray[nProt].fKkslm1;		//	�Բ�ĸ�߹�����������
		}
		if (!m_ProtTranArray[nProt].bPowerL)
		{
			if (m_ProtTranArray[nProt].fKkllm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1L = m_ProtTranArray[nProt].fIkminLNear/m_ProtTranArray[nProt].fKkllm1;	//	����ĸ�߹�����������
		}
		else
		{
			if (m_ProtTranArray[nProt].fKkslm1 > FLT_MIN)
				m_ProtTranArray[nProt].fIkdz1L = m_ProtTranArray[nProt].fIobminL/m_ProtTranArray[nProt].fKkslm1;		//	�Բ�ĸ�߹�����������
		}

		//////////////////////////////////////////////////////////////////////////
		//	�����α������������㱾��ĸ��������������
		if (m_ProtTranArray[nProt].nZGStatH != 0)
		{
			if (m_ProtTranArray[nProt].fK0lm1 > FLT_MIN)
				m_ProtTranArray[nProt].fI0dz1H = m_ProtTranArray[nProt].fI0kminHNear/m_ProtTranArray[nProt].fK0lm1;		//	������ĸ��������������
		}
		if (m_ProtTranArray[nProt].nZGStatM != 0)
		{
			if (m_ProtTranArray[nProt].fK0lm1 > FLT_MIN)
				m_ProtTranArray[nProt].fI0dz1M = m_ProtTranArray[nProt].fI0kminMNear/m_ProtTranArray[nProt].fK0lm1;		//	������ĸ��������������
		}
		if (m_ProtTranArray[nProt].nZGStatL != 0)
		{
			if (m_ProtTranArray[nProt].fK0lm1 > FLT_MIN)
				m_ProtTranArray[nProt].fI0dz1L = m_ProtTranArray[nProt].fI0kminLNear/m_ProtTranArray[nProt].fK0lm1;		//	������ĸ��������������
		}
	}
}

void CProtTran::Checking()
{
	int		nProt;

	for (nProt=0; nProt<m_ProtTranArray.size(); nProt++)
	{
		m_ProtTranArray[nProt].fKksen3H=0;		
		m_ProtTranArray[nProt].fKksen3M=0;		
		m_ProtTranArray[nProt].fKksen3L=0;		
	}

	for (nProt=0; nProt<m_ProtTranArray.size(); nProt++)
	{
		//////////////////////////////////////////////////////////////////////////
		//	�������������ȼ��㣬�ȵ�Դ���������Բ�ĸ�ߣ����ɲఴ����ĸ�߶�·��С��·����
		if (m_ProtTranArray[nProt].fIkdz3H > FLT_MIN)
		{
			if (m_ProtTranArray[nProt].bPowerH)
				m_ProtTranArray[nProt].fKksen3H = m_ProtTranArray[nProt].fIobminH/m_ProtTranArray[nProt].fIkdz3H;		//	�����ȵ�Դ�ఴ�Բ�ĸ����С��·����
			else
				m_ProtTranArray[nProt].fKksen3H = m_ProtTranArray[nProt].fIkminHNear/m_ProtTranArray[nProt].fIkdz3H;	//	������ĸ�߶�·��С��·����
		}
		if (m_ProtTranArray[nProt].fIkdz3M > FLT_MIN)
		{
			if (m_ProtTranArray[nProt].bPowerM)
				m_ProtTranArray[nProt].fKksen3M = m_ProtTranArray[nProt].fIobminM/m_ProtTranArray[nProt].fIkdz3M;		//	�����ȵ�Դ�ఴ�Բ�ĸ����С��·����
			else																							
				m_ProtTranArray[nProt].fKksen3M = m_ProtTranArray[nProt].fIkminMNear/m_ProtTranArray[nProt].fIkdz3M;	//	������ĸ�߶�·��С��·����
		}
		if (m_ProtTranArray[nProt].fIkdz3L > FLT_MIN)
		{
			if (m_ProtTranArray[nProt].bPowerL)
				m_ProtTranArray[nProt].fKksen3L = m_ProtTranArray[nProt].fIobminL/m_ProtTranArray[nProt].fIkdz3L;		//	�����ȵ�Դ�ఴ�Բ�ĸ����С��·����
			else																							
				m_ProtTranArray[nProt].fKksen3L = m_ProtTranArray[nProt].fIkminLNear/m_ProtTranArray[nProt].fIkdz3L;	//	������ĸ�߶�·��С��·����
		}
	}
}

float CProtTran::ResolveProtLineMaxI0dz(const std::vector<tagProtLine>& sProtLineArray, const int nTranTun, const int nStartTopoBus, std::vector<tagGraphPoint>& sGPArray)
{
	int		nProt, nTran;
	float	fI0dz, fKbr0;

	fI0dz=0;
	for (nProt=0; nProt<sProtLineArray.size(); nProt++)
	{
		if (sProtLineArray[nProt].nTopoBusI == nStartTopoBus)
		{

			if (sProtLineArray[nProt].fI0dz3I > FLT_MIN)
			{
				fI0dz = max(fI0dz, sProtLineArray[nProt].fI0dz3I);
			}
			else if (sProtLineArray[nProt].fI0dz2I > FLT_MIN)
			{
				fI0dz = max(fI0dz, sProtLineArray[nProt].fI0dz2I);
			}
			else if (sProtLineArray[nProt].fI0dz1I > FLT_MIN)
			{
				fI0dz = max(fI0dz, sProtLineArray[nProt].fI0dz1I);
			}
			if (fI0dz > FLT_MIN)
			{
				fKbr0=Tran2BranKf0(nTranTun, ConstTranSideH, PG_ACLINESEGMENT, sProtLineArray[nProt].szName, sGPArray);
				Log(g_lpszLogFile, "********************��֧ϵ�� = %f\n", fKbr0);
				fI0dz /= fKbr0;
			}
		}
		else if (sProtLineArray[nProt].nTopoBusJ == nStartTopoBus)
		{
			if (sProtLineArray[nProt].fI0dz3J > FLT_MIN)
			{
				fI0dz = max(fI0dz, sProtLineArray[nProt].fI0dz3J);
			}
			else if (sProtLineArray[nProt].fI0dz2J > FLT_MIN)
			{
				fI0dz = max(fI0dz, sProtLineArray[nProt].fI0dz2J);
			}
			else if (sProtLineArray[nProt].fI0dz1J > FLT_MIN)
			{
				fI0dz = max(fI0dz, sProtLineArray[nProt].fI0dz1J);
			}
			if (fI0dz > FLT_MIN)
			{
				fKbr0=Tran2BranKf0(nTranTun, ConstTranSideH, PG_ACLINESEGMENT, sProtLineArray[nProt].szName, sGPArray);
				Log(g_lpszLogFile, "********************��֧ϵ�� = %f\n", fKbr0);
				fI0dz /= fKbr0;
			}
		}
	}

	return fI0dz;
}


//////////////////////////////////////////////////////////////////////////
//	��������ϣ�������·�����������������·������Ҳ���ڣ�Ϊ���ඨ����������ͬ�������ˣ�����ģ����ȫ��ͬ
float CProtTran::ResolveTranIkunb(const int nStartTopoBus, const char* lpszTranName, std::vector<tagGraphPoint> sGPArray)
{
	register int	i;
	int		nOpp, nOBus;
	float	fIkunb;

	if (nStartTopoBus < 0)
		return 0;

	//Log(g_lpszLogFile, "    TBusNum = %d\n", sGPArray[nStartTopoBus].nOTBusArray.size());

	fIkunb=0;
	for (nOpp=0; nOpp<(int)sGPArray[nStartTopoBus].nOTBusArray.size(); nOpp++)
	{
		nOBus=sGPArray[nStartTopoBus].nOTBusArray[nOpp];
		//Log(g_lpszLogFile, "        OppBus[%d] N2 = %d\n", nOBus, sGPArray[nOBus].sN2BranArray.size());

		for (i=0; i<(int)sGPArray[nOBus].sN2BranArray.size(); i++)
		{
			if (sGPArray[nOBus].sN2BranArray[i].nBranType != PG_POWERTRANSFORMER || stricmp(sGPArray[nOBus].sN2BranArray[i].strBranName.c_str(), lpszTranName) != 0 || sGPArray[nOBus].sN2BranArray[i].nFrTopoBus != nStartTopoBus)
				continue;

			fIkunb = max(fIkunb, sGPArray[nOBus].sN2BranArray[i].fIa[FLT3]);
			break;
		}
	}

	return fIkunb;
}
