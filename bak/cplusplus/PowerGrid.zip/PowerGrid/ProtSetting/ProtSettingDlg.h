
// ProtTunningDlg.h : ͷ�ļ�
//

#pragma once
#include "ProtSccScanDialog.h"
#include "ProtBaseDialog.h"
#include "ProtLineDialog.h"
#include "ProtTranDialog.h"
#include "ProtDeviceDialog.h"

#include "ProtGraph.h"
#include "PGProtDevice/ProtParam.h"
#include "PGProtDevice/ProtLine.h"
#include "PGProtDevice/ProtTran.h"
#include "PGProtDevice/ProtBus.h"
#include "PGProtDevice/ProtGen.h"
#include "PGProtDevice/ProtCap.h"
#include "PGProtDevice/ProtReac.h"
#include "PGProtDevice/ProtMotor.h"
#include "PGProtDevice/ProtBreaker.h"

// CProtTunningDlg �Ի���
class CProtSettingDlg : public CDialog
{
// ����
public:
	CProtSettingDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PROTSETTING_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBnClickedMaxModeSetting();
	afx_msg void OnBnClickedMinModeSetting();
	afx_msg void OnBnClickedChecking();
	afx_msg void OnBnClickedBrowseAutocad();
	afx_msg void OnBnClickedBrowseMaxc();
	afx_msg void OnBnClickedBrowseMinc();
	afx_msg void OnBnClickedClear();
	afx_msg void OnBnClickedSaveasExcel();
	afx_msg void OnBnClickedShowFilter();
	afx_msg void OnBnClickedSetParam();
	afx_msg void OnBnClickedScScan();
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl			m_wndTab;

	CProtSccScanDialog	m_wndProtSccScan;
	CProtBaseDialog		m_wndProtBase;
	CProtLineDialog		m_wndProtLine;
	CProtTranDialog		m_wndProtTran;
	CProtDeviceDialog	m_wndProtDevice;

private:
	void Refresh();

private:
	CProtGraph		m_ProtGraph;
	CProtParam		m_ProtParam;
	CProtLine		m_ProtLine;
	CProtTran		m_ProtTran;
	CProtBus		m_ProtBus;
	CProtGen		m_ProtGen;
	CProtCap		m_ProtCap;
	CProtReac		m_ProtReac;
	CProtMotor		m_ProtMotor;
	CProtBreaker	m_ProtBreaker;
public:
};
