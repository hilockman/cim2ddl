#pragma once

#include "../../Common/Excel/ExcelAccessor.h"

// CProtBaseDialog �Ի���
#include "ProtParamDialogLine.h"
#include "ProtParamDialogDevice.h"

class CProtBaseDialog : public CDialog
{
	DECLARE_DYNAMIC(CProtBaseDialog)

public:
	CProtBaseDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProtBaseDialog();
	void InitProt(CProtParam* pParam)
	{
		m_pProtParam = pParam;
		m_wndProtLineParam.			InitProt(m_pProtParam);
		m_wndProtDeviceParam.		InitProt(m_pProtParam);
	};

	void RefreshGraphTree(std::vector<tagGraphPoint>& sGPArray);

// �Ի�������
	enum { IDD = IDD_PROTBASE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:

private:
	CMFCTabCtrl					m_wndTab;
	CTreeCtrl					m_wndBusTree;
	CParamProtLineDialog		m_wndProtLineParam;
	CParamProtDeviceDialog		m_wndProtDeviceParam;
private:
	CProtParam*					m_pProtParam;
};
