#pragma once


// CProtLineParamDialog �Ի���

class CParamProtLineDialog : public CDialog
{
	DECLARE_DYNAMIC(CParamProtLineDialog)

public:
	CParamProtLineDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CParamProtLineDialog();
	void InitProt(CProtParam* pParam)
	{
		m_pProtParam = pParam;
	};

// �Ի�������
	enum { IDD = IDD_PARAM_PROTLINE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	afx_msg void OnEnChangeProtParam();
	afx_msg void OnBnClickedProtParam();

	DECLARE_MESSAGE_MAP()
private:
	CProtParam*	m_pProtParam;
};
