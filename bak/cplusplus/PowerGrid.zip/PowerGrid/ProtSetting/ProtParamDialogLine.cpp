// ProtLineParamDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtParamDialogLine.h"


// CProtLineParamDialog �Ի���

static	unsigned char	m_bUIFreeze=0;

IMPLEMENT_DYNAMIC(CParamProtLineDialog, CDialog)

CParamProtLineDialog::CParamProtLineDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CParamProtLineDialog::IDD, pParent)
{
	m_pProtParam = NULL;
}

CParamProtLineDialog::~CParamProtLineDialog()
{
}

void CParamProtLineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CParamProtLineDialog, CDialog)
	ON_EN_CHANGE(IDC_PROTLINE_KKREL1  , &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KKREL2  , &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KKLM2  , &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KKRELP3 , &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KKRELL3 , &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_K0REL1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_K0REL2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_K0REL3, &CParamProtLineDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTLINE_KZREL1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZTREL1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZP2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZLM2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZFH, &CParamProtLineDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTLINE_KZ0REL1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZT0REL1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZ0P2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZ0LM2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZ0P3, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KZ0LM3, &CParamProtLineDialog::OnEnChangeProtParam)

	ON_BN_CLICKED(IDC_PROTLINE_IKDZ2_LM, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_IKDZ3_COORD, &CParamProtLineDialog::OnBnClickedProtParam)

	ON_BN_CLICKED(IDC_PROTLINE_I0DZ1_INTRAN, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_I0DZ2_COORD, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_I0DZ3_COORD, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_I0DZ3_UNB, &CParamProtLineDialog::OnBnClickedProtParam)

	ON_BN_CLICKED(IDC_PROTLINE_ZDZ1_INTRAN, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_ZDZ2_COORD, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_ZDZ2_LM, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_ZDZ3_COORD, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_ZDZ3_FH, &CParamProtLineDialog::OnBnClickedProtParam)

	ON_BN_CLICKED(IDC_PROTLINE_Z0DZ1_INTRAN, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_Z0DZ2_COORD, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_Z0DZ2_LM, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_Z0DZ3_COORD, &CParamProtLineDialog::OnBnClickedProtParam)
	ON_BN_CLICKED(IDC_PROTLINE_Z0DZ3_LM, &CParamProtLineDialog::OnBnClickedProtParam)

	//////////////////////////////////////////////////////////////////////////
	//	Checking
	//////////////////////////////////////////////////////////////////////////
	ON_EN_CHANGE(IDC_PROTLINE_KKSEN1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KKSEN2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_KKSEN3, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_K0SEN1, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_K0SEN2, &CParamProtLineDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLINE_K0SEN3, &CParamProtLineDialog::OnEnChangeProtParam)
END_MESSAGE_MAP()


// CProtLineParamDialog ��Ϣ��������

BOOL CParamProtLineDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	char	szBuf[260];
	CButton*	pButton;

	if (!m_pProtParam)
		EndDialog(IDCANCEL);

	m_bUIFreeze = 1;

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKkrel1 	);		GetDlgItem(IDC_PROTLINE_KKREL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKkrel2 	);		GetDlgItem(IDC_PROTLINE_KKREL2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKklm2  	);		GetDlgItem(IDC_PROTLINE_KKLM2 )->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKkrelP3	);		GetDlgItem(IDC_PROTLINE_KKRELP3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKkrelL3	);		GetDlgItem(IDC_PROTLINE_KKRELL3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineK0rel1 	);		GetDlgItem(IDC_PROTLINE_K0REL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineK0rel2 	);		GetDlgItem(IDC_PROTLINE_K0REL2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineK0rel3 	);		GetDlgItem(IDC_PROTLINE_K0REL3)->SetWindowText(szBuf);

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZrel1	);		GetDlgItem(IDC_PROTLINE_KZREL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZTrel1	);		GetDlgItem(IDC_PROTLINE_KZTREL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZp2		);		GetDlgItem(IDC_PROTLINE_KZP2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZlm2		);		GetDlgItem(IDC_PROTLINE_KZLM2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZfh3		);		GetDlgItem(IDC_PROTLINE_KZFH)->SetWindowText(szBuf);

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZ0rel1	);		GetDlgItem(IDC_PROTLINE_KZ0REL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZT0rel1	);		GetDlgItem(IDC_PROTLINE_KZT0REL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZ0p2		);		GetDlgItem(IDC_PROTLINE_KZ0P2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZ0lm2	);		GetDlgItem(IDC_PROTLINE_KZ0LM2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZ0p3		);		GetDlgItem(IDC_PROTLINE_KZ0P3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKZ0lm3	);		GetDlgItem(IDC_PROTLINE_KZ0LM3)->SetWindowText(szBuf);

	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_IKDZ2_LM);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineIkdz2UsingKlm	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_IKDZ3_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineIkdz3Coord3	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ1_INTRAN);				pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineI0ProtIntoTran	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ2_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineI0dz2Coord2	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ3_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineI0dz3Coord3	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ3_UNB);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineI0dz3Unb		);

	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ1_INTRAN);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZProtIntoTran	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ2_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZdz2Coord2		);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ2_LM);						pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZdz2UsingKlm	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ3_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZdz3Coord3		);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ3_FH);						pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZdz3UsingKfh	);

	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ1_INTRAN);				pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZ0ProtIntoTran	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ2_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZ0dz2Coord2	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ2_LM);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZ0dz2UsingKlm	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ3_COORD);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZ0dz3Coord3	);
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ3_LM);					pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtLineZ0dz3UsingKlm	);

	//////////////////////////////////////////////////////////////////////////
	//	Checking
	//////////////////////////////////////////////////////////////////////////
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKksen1);		GetDlgItem(IDC_PROTLINE_KKSEN1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKksen2);		GetDlgItem(IDC_PROTLINE_KKSEN2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineKksen3);		GetDlgItem(IDC_PROTLINE_KKSEN3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineK0sen1);		GetDlgItem(IDC_PROTLINE_K0SEN1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineK0sen2);		GetDlgItem(IDC_PROTLINE_K0SEN2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLineK0sen3);		GetDlgItem(IDC_PROTLINE_K0SEN3)->SetWindowText(szBuf);

	m_bUIFreeze=0;

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CParamProtLineDialog::OnEnChangeProtParam()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];

	if (m_bUIFreeze)
		return;

	GetDlgItem(IDC_PROTLINE_KKREL1 )->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKkrel1 	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KKREL2 )->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKkrel2 	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KKLM2  )->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKklm2 	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KKRELP3)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKkrelP3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KKRELL3)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKkrelL3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_K0REL1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineK0rel1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_K0REL2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineK0rel2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_K0REL3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineK0rel3	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTLINE_KZREL1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZrel1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZTREL1)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKZTrel1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZP2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZp2		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZLM2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZlm2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZFH)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZfh3	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTLINE_KZ0REL1)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKZ0rel1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZT0REL1)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtLineKZT0rel1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZ0P2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZ0p2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZ0LM2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZ0lm2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZ0P3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZ0p3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KZ0LM3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKZ0lm3	= (float)atof(szBuf);

	//////////////////////////////////////////////////////////////////////////
	//	Checking
	//////////////////////////////////////////////////////////////////////////
	GetDlgItem(IDC_PROTLINE_KKSEN1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKksen1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KKSEN2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKksen2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_KKSEN3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineKksen3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_K0SEN1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineK0sen1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_K0SEN2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineK0sen2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLINE_K0SEN3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLineK0sen3	= (float)atof(szBuf);
}

void CParamProtLineDialog::OnBnClickedProtParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton;

	if (m_bUIFreeze)
		return;

	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_IKDZ2_LM);		m_pProtParam->m_ProtSetting.bProtLineIkdz2UsingKlm	=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_IKDZ3_COORD);		m_pProtParam->m_ProtSetting.bProtLineIkdz3Coord3		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ1_INTRAN);	m_pProtParam->m_ProtSetting.bProtLineI0ProtIntoTran	=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ2_COORD);		m_pProtParam->m_ProtSetting.bProtLineI0dz2Coord2		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ3_COORD);		m_pProtParam->m_ProtSetting.bProtLineI0dz3Coord3		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_I0DZ3_UNB);		m_pProtParam->m_ProtSetting.bProtLineI0dz3Unb			=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ1_INTRAN);		m_pProtParam->m_ProtSetting.bProtLineZProtIntoTran	=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ2_COORD);		m_pProtParam->m_ProtSetting.bProtLineZdz2Coord2		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ2_LM);			m_pProtParam->m_ProtSetting.bProtLineZdz2UsingKlm		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ3_COORD);		m_pProtParam->m_ProtSetting.bProtLineZdz3Coord3		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_ZDZ3_FH);			m_pProtParam->m_ProtSetting.bProtLineZdz3UsingKfh		=pButton->GetCheck();

	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ1_INTRAN);	m_pProtParam->m_ProtSetting.bProtLineZ0ProtIntoTran	=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ2_COORD);		m_pProtParam->m_ProtSetting.bProtLineZ0dz2Coord2		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ2_LM);		m_pProtParam->m_ProtSetting.bProtLineZ0dz2UsingKlm	=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ3_COORD);		m_pProtParam->m_ProtSetting.bProtLineZ0dz3Coord3		=pButton->GetCheck();
	pButton=(CButton*)GetDlgItem(IDC_PROTLINE_Z0DZ3_LM);		m_pProtParam->m_ProtSetting.bProtLineZ0dz3UsingKlm	=pButton->GetCheck();
}
