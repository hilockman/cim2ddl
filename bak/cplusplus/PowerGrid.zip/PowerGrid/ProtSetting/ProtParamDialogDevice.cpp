// ProtDeviceParamDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtParamDialogDevice.h"


// CProtDeviceParamDialog �Ի���

static	unsigned char	m_bUIFreeze=0;

IMPLEMENT_DYNAMIC(CParamProtDeviceDialog, CDialog)

CParamProtDeviceDialog::CParamProtDeviceDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CParamProtDeviceDialog::IDD, pParent)
{
	m_pProtParam = NULL;
}

CParamProtDeviceDialog::~CParamProtDeviceDialog()
{
}

void CParamProtDeviceDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CParamProtDeviceDialog, CDialog)
	ON_EN_CHANGE(IDC_PROT_KER, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTTRAN_KKREL3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTTRAN_KKRES3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTTRAN_KKSLM1, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTTRAN_KKLLM1, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTTRAN_UOP, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTTRAN_UOPREL, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTTRAN_UOPRES, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTBUS_KUNBREL, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTBUS_KBRKREL, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTGEN_KDREL, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTGEN_KKREL, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTGEN_KKRES, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTGEN_KAP, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTGEN_KSS, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTLOAD_KST, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLOAD_KDREL, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLOAD_KKREL3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLOAD_KLRES, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLOAD_KAP, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTLOAD_KSS, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTCAP_KKREL2, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTCAP_KKREL3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTCAP_KKRES3, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTREAC_KDREL, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTREAC_KKREL1, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTREAC_KKREL3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTREAC_KKRES3, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_EN_CHANGE(IDC_PROTBREAKER_KKLM1, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTBREAKER_KKP2, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTBREAKER_KKR, &CParamProtDeviceDialog::OnEnChangeProtParam)

	ON_BN_CLICKED(IDC_PROTBUS_FAULTUNB, &CParamProtDeviceDialog::OnBnClickedProtParam)

	//////////////////////////////////////////////////////////////////////////
	//	Checking
	//////////////////////////////////////////////////////////////////////////
	ON_EN_CHANGE(IDC_PROTTRAN_KKSEN3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTGEN_KKSEN3NEAR, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTGEN_KKSEN3FAR, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTCAP_KKSEN2, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTCAP_KKSEN3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTREAC_KKSEN1, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTREAC_KKSEN3, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTBREAKER_KKSEN1, &CParamProtDeviceDialog::OnEnChangeProtParam)
	ON_EN_CHANGE(IDC_PROTBREAKER_KKSEN2, &CParamProtDeviceDialog::OnEnChangeProtParam)
END_MESSAGE_MAP()


// CProtDeviceParamDialog ��Ϣ��������

BOOL CParamProtDeviceDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	char	szBuf[260];

	CButton*	pButton;

	if (!m_pProtParam)
		EndDialog(IDCANCEL);

	m_bUIFreeze = 1;

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtKer);				GetDlgItem(IDC_PROT_KER)->SetWindowText(szBuf);

	//////////////////////////////////////////////////////////////////////////
	//	Setting
	//////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKkslm1);		GetDlgItem(IDC_PROTTRAN_KKSLM1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKkllm1);		GetDlgItem(IDC_PROTTRAN_KKLLM1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKkrel3);		GetDlgItem(IDC_PROTTRAN_KKREL3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKkres3);		GetDlgItem(IDC_PROTTRAN_KKRES3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranK0lm1	);		GetDlgItem(IDC_PROTTRAN_K0LM1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranK0rel2);		GetDlgItem(IDC_PROTTRAN_K0REL2)->SetWindowText(szBuf);

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKuop		);	GetDlgItem(IDC_PROTTRAN_UOP)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKuoprel	);	GetDlgItem(IDC_PROTTRAN_UOPREL)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKuopres	);	GetDlgItem(IDC_PROTTRAN_UOPRES)->SetWindowText(szBuf);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBusKunbrel);		GetDlgItem(IDC_PROTBUS_KUNBREL)->SetWindowText(szBuf);	
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBusKbrkrel);		GetDlgItem(IDC_PROTBUS_KBRKREL)->SetWindowText(szBuf);	
	pButton=(CButton*)GetDlgItem(IDC_PROTBUS_FAULTUNB);						pButton->SetCheck(m_pProtParam->m_ProtSetting.bProtBusFaultUnb);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKdrel);		GetDlgItem(IDC_PROTGEN_KDREL)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKkrel);		GetDlgItem(IDC_PROTGEN_KKREL)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKkres);		GetDlgItem(IDC_PROTGEN_KKRES)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKap);			GetDlgItem(IDC_PROTGEN_KAP)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKss);			GetDlgItem(IDC_PROTGEN_KSS)->SetWindowText(szBuf);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLoadKst);			GetDlgItem(IDC_PROTLOAD_KST)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLoadKdrel);		GetDlgItem(IDC_PROTLOAD_KDREL)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLoadKkrel);		GetDlgItem(IDC_PROTLOAD_KKREL3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLoadKkres);		GetDlgItem(IDC_PROTLOAD_KLRES)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLoadKap);			GetDlgItem(IDC_PROTLOAD_KAP)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtLoadKss);			GetDlgItem(IDC_PROTLOAD_KSS)->SetWindowText(szBuf);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtCapKkrel2);		GetDlgItem(IDC_PROTCAP_KKREL2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtCapKkrel3);		GetDlgItem(IDC_PROTCAP_KKREL3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtCapKkres3);		GetDlgItem(IDC_PROTCAP_KKRES3)->SetWindowText(szBuf);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtReacKdrel);		GetDlgItem(IDC_PROTREAC_KDREL)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtReacKkrel1);		GetDlgItem(IDC_PROTREAC_KKREL1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtReacKkrel3);		GetDlgItem(IDC_PROTREAC_KKREL3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtReacKkres3);		GetDlgItem(IDC_PROTREAC_KKRES3)->SetWindowText(szBuf);
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBreakerKkp1);		GetDlgItem(IDC_PROTBREAKER_KKP1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBreakerKklm1);	GetDlgItem(IDC_PROTBREAKER_KKLM1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBreakerKkp2);		GetDlgItem(IDC_PROTBREAKER_KKP2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBreakerKkr);		GetDlgItem(IDC_PROTBREAKER_KKR)->SetWindowText(szBuf);

	//////////////////////////////////////////////////////////////////////////
	//	Checking
	//////////////////////////////////////////////////////////////////////////
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtTranKksen3);		GetDlgItem(IDC_PROTTRAN_KKSEN3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKksen3Near);	GetDlgItem(IDC_PROTGEN_KKSEN3NEAR)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtGenKksen3Far);	GetDlgItem(IDC_PROTGEN_KKSEN3FAR)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtCapKksen2);		GetDlgItem(IDC_PROTCAP_KKSEN2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtCapKksen3);		GetDlgItem(IDC_PROTCAP_KKSEN3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtReacKksen1);		GetDlgItem(IDC_PROTREAC_KKSEN1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtReacKksen3);		GetDlgItem(IDC_PROTREAC_KKSEN3)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBreakerKsen1);	GetDlgItem(IDC_PROTBREAKER_KKSEN1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.2f", m_pProtParam->m_ProtSetting.fProtBreakerKsen2);	GetDlgItem(IDC_PROTBREAKER_KKSEN2)->SetWindowText(szBuf);

	m_bUIFreeze=0;

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CParamProtDeviceDialog::OnEnChangeProtParam()
{
	// TODO:  ����ÿؼ��� RICHEDIT �ؼ���������
	// ���ʹ�֪ͨ��������д CDialog::OnInitDialog()
	// ���������� CRichEditCtrl().SetEventMask()��
	// ͬʱ�� ENM_CHANGE ��־�������㵽�����С�

	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	char	szBuf[260];

	if (m_bUIFreeze)
		return;

	GetDlgItem(IDC_PROT_KER)->GetWindowText(szBuf, 260);			m_pProtParam->m_ProtSetting.fProtKer			= (float)atof(szBuf);

	GetDlgItem(IDC_PROTTRAN_KKSLM1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKkslm1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTTRAN_KKLLM1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKkllm1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTTRAN_KKREL3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKkrel3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTTRAN_KKRES3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKkres3	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTTRAN_UOP)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKuop		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTTRAN_UOPREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKuoprel	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTTRAN_UOPRES)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKuopres	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTBUS_KUNBREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtBusKunbrel	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTBUS_KBRKREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtBusKbrkrel	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTGEN_KKREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtGenKkrel		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTGEN_KKRES)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtGenKkres		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTGEN_KDREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtGenKdrel		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTGEN_KAP)->GetWindowText(szBuf, 260);			m_pProtParam->m_ProtSetting.fProtGenKap		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTGEN_KSS)->GetWindowText(szBuf, 260);			m_pProtParam->m_ProtSetting.fProtGenKss		= (float)atof(szBuf);

	GetDlgItem(IDC_PROTLOAD_KST)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLoadKst		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLOAD_KDREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLoadKdrel	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLOAD_KKREL3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLoadKkrel	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLOAD_KLRES)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLoadKkres	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLOAD_KAP)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLoadKap		= (float)atof(szBuf);
	GetDlgItem(IDC_PROTLOAD_KSS)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtLoadKss		= (float)atof(szBuf);

	GetDlgItem(IDC_PROTCAP_KKREL2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtCapKkrel2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTCAP_KKREL3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtCapKkrel3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTCAP_KKRES3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtCapKkres3	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTREAC_KDREL)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtReacKdrel	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTREAC_KKREL1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtReacKkrel1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTREAC_KKREL3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtReacKkrel3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTREAC_KKRES3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtReacKkres3	= (float)atof(szBuf);

	GetDlgItem(IDC_PROTBREAKER_KKP1)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtBreakerKkp1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTBREAKER_KKLM1)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtBreakerKklm1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTBREAKER_KKP2)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtBreakerKkp2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTBREAKER_KKR)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtBreakerKkr	= (float)atof(szBuf);

	//////////////////////////////////////////////////////////////////////////
	//	Checking
	//////////////////////////////////////////////////////////////////////////
	GetDlgItem(IDC_PROTTRAN_KKSEN3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtTranKksen3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTGEN_KKSEN3NEAR)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtGenKksen3Near= (float)atof(szBuf);
	GetDlgItem(IDC_PROTGEN_KKSEN3FAR)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtGenKksen3Far	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTCAP_KKSEN2)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtCapKksen2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTCAP_KKSEN3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtCapKksen3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTREAC_KKSEN1)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtReacKksen1	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTREAC_KKSEN3)->GetWindowText(szBuf, 260);		m_pProtParam->m_ProtSetting.fProtReacKksen3	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTBREAKER_KKSEN1)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtBreakerKsen2	= (float)atof(szBuf);
	GetDlgItem(IDC_PROTBREAKER_KKSEN2)->GetWindowText(szBuf, 260);	m_pProtParam->m_ProtSetting.fProtBreakerKsen2	= (float)atof(szBuf);
}

void CParamProtDeviceDialog::OnBnClickedProtParam()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CButton*	pButton;

	if (m_bUIFreeze)
		return;

	pButton=(CButton*)GetDlgItem(IDC_PROTBUS_FAULTUNB);				m_pProtParam->m_ProtSetting.bProtBusFaultUnb=pButton->GetCheck();
}
