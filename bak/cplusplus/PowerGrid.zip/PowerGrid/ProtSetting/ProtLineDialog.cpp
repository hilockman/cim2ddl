// ProtLineDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtLineDialog.h"


// CProtLineDialog �Ի���
#define		IDC_BASELINE_LIST	10001
#define		IDC_PROTLINEIK_LIST	10003
#define		IDC_PROTLINEI0_LIST	10004

static	char*	lpszBaseLineColumn[]=
{
	"���", 
	"�豸��", 
	"�����", 
	//"����", 
	//"�翹", 
	//"����翹", 

	"����ӵ�", 
	"��Դ���", 
	"����ĸ��", 
	"����ĸ��", 
	"���ɲ������豸", 
};

static	char*	lpszProtLineIkColumn[]=
{
	"���", 
	"�豸��", 
	"��վ", 
	"ĩ��վ", 
	"�����", 

	"ĩ������", 
	"����С����", 
	"ĩ��С����", 
	"��ĩ��С����", 
//	"��ĩĸ��", 

	"˲ʱ�ٶ�����", 
	"��ʱ�ٶ�����", 
	"����������", 

	"˲ʱ�ٶ�����ϵ��", 
	"��ʱ�ٶ�����ϵ��", 
	"����������ϵ��", 
};

static	char*	lpszProtLineI0Column[]=
{
	"���", 
	"�豸��", 
	"��վ", 
	"ĩ��վ", 
	"�����", 

	"ĩ������", 
	"����С����", 
	"ĩ��С����", 
	"��ĩ��С����", 
	"��ĩĸ��", 

	"����������", 
	"����������", 
	"����������", 

	"����������ϵ��", 
	"����������ϵ��", 
	"����������ϵ��", 
};

IMPLEMENT_DYNAMIC(CProtLineDialog, CDialog)

CProtLineDialog::CProtLineDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CProtLineDialog::IDD, pParent)
{
	m_pProtParam = NULL;
	m_pProtLine = NULL;
}

CProtLineDialog::~CProtLineDialog()
{
}

void CProtLineDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CProtLineDialog, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CProtLineDialog ��Ϣ��������

BOOL CProtLineDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectBuf;

	if (!m_pProtParam || !m_pProtLine)
		EndDialog(IDCANCEL);

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndBaseLine.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_BASELINE_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndBaseLine.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndBaseLine.SetExtendedStyle(m_wndBaseLine.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndBaseLine.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBaseLineColumn)/sizeof(char*); i++)
		m_wndBaseLine.InsertColumn(i, lpszBaseLineColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtLineIk.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTLINEIK_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtLineIk.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtLineIk.SetExtendedStyle(m_wndProtLineIk.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtLineIk.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtLineIkColumn)/sizeof(char*); i++)
		m_wndProtLineIk.InsertColumn(i, lpszProtLineIkColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtLineI0.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTLINEI0_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtLineI0.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtLineI0.SetExtendedStyle(m_wndProtLineI0.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtLineI0.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtLineI0Column)/sizeof(char*); i++)
		m_wndProtLineI0.InsertColumn(i, lpszProtLineI0Column[i],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndBaseLine,		_T("��·������Ϣ"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndProtLineIk,		_T("��·�����ϱ���"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndProtLineI0,		_T("��·�ӵع��ϱ���"),		-1, FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CProtLineDialog::RefreshBaseLineList(CProtGraph* pGraph)
{
	int		nDev, nLink, nRow, nCol;
	int		nEndBus;
	char	szBuf[260];
	std::string	strNeighbour;

	m_wndBaseLine.DeleteAllItems();

	nRow=0;
	for (nDev=0; nDev<m_pProtLine->m_ProtLineArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nDev+1);
		m_wndBaseLine.InsertItem(nRow, szBuf);	m_wndBaseLine.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s %s", m_pProtLine->m_ProtLineArray[nDev].szVolt, m_pProtLine->m_ProtLineArray[nDev].szName);
		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nDev].fRate);	m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
		//sprintf(szBuf, "%f", m_pProtLine->m_ProtLineArray[nDev].fR);		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
		//sprintf(szBuf, "%f", m_pProtLine->m_ProtLineArray[nDev].fX);		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);

		if (m_pProtLine->m_ProtLineArray[nDev].bZGround == 1)		strcpy(szBuf, "I��");
		else if (m_pProtLine->m_ProtLineArray[nDev].bZGround == 2)	strcpy(szBuf, "J��");
		else if (m_pProtLine->m_ProtLineArray[nDev].bZGround == 3)	strcpy(szBuf, "����");
		else														strcpy(szBuf, "");
		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);

		strNeighbour.clear();
		if (m_pProtLine->m_ProtLineArray[nDev].bPowered == 0)
		{
			strcpy(szBuf, "����");	m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
		}
		else if (m_pProtLine->m_ProtLineArray[nDev].bPowered == 1)
		{
			strcpy(szBuf, "I��");	m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nDev].nTopoBusI, m_pProtLine->m_ProtLineArray[nDev].szSubI);		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nDev].nTopoBusJ, m_pProtLine->m_ProtLineArray[nDev].szSubJ);		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);

			nEndBus=m_pProtLine->m_ProtLineArray[nDev].nTopoBusJ;
			for (nLink=0; nLink<(int)pGraph->m_SettingGPArray[nEndBus].sN1BranArray.size(); nLink++)
			{
				if (pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].nBranType != PG_ACLINESEGMENT ||
					stricmp(pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].strBranName.c_str(), m_pProtLine->m_ProtLineArray[nDev].szName) != 0)
				{
					sprintf(szBuf, "[%s %s]", PGGetTableDesp(pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].nBranType), pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].strBranName.c_str());
					strNeighbour.append(szBuf).append("; ");
				}
			}
			m_wndBaseLine.SetItemText(nRow, nCol++, strNeighbour.c_str());
		}
		else if (m_pProtLine->m_ProtLineArray[nDev].bPowered == 2)
		{
			strcpy(szBuf, "J��");	m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nDev].nTopoBusJ, m_pProtLine->m_ProtLineArray[nDev].szSubJ);		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nDev].nTopoBusI, m_pProtLine->m_ProtLineArray[nDev].szSubI);		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);

			nEndBus=m_pProtLine->m_ProtLineArray[nDev].nTopoBusI;
			for (nLink=0; nLink<(int)pGraph->m_SettingGPArray[nEndBus].sN1BranArray.size(); nLink++)
			{
				if (pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].nBranType != PG_ACLINESEGMENT ||
					pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].strBranName.c_str(), m_pProtLine->m_ProtLineArray[nDev].szName)
				{
					sprintf(szBuf, "[%s %s]", PGGetTableDesp(pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].nBranType), pGraph->m_SettingGPArray[nEndBus].sN1BranArray[nLink].strBranName.c_str());
					strNeighbour.append(szBuf).append("; ");
				}
			}
			m_wndBaseLine.SetItemText(nRow, nCol++, strNeighbour.c_str());
		}
		else
		{
			strcpy(szBuf, "��Դ");		m_wndBaseLine.SetItemText(nRow, nCol++, szBuf);
		}

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBaseLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndBaseLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndBaseLine.GetColumnWidth(nCol);
		m_wndBaseLine.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		if (m_wndBaseLine.GetItemCount() <= 0)
			nHeaderWidth = m_wndBaseLine.GetColumnWidth(nCol);

		m_wndBaseLine.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtLineDialog::RefreshProtLineIkList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	int		nBusI, nBusJ;
	unsigned char	b2Row;
	char	szBuf[260];

	m_wndProtLineIk.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtLine->m_ProtLineArray.size(); nProt++)
	{
		if (bFilter)
		{
			if (m_pProtLine->m_ProtLineArray[nProt].fKsen1I > m_pProtParam->m_ProtSetting.fProtLineKksen1 &&
				m_pProtLine->m_ProtLineArray[nProt].fKsen2I > m_pProtParam->m_ProtSetting.fProtLineKksen2 &&
				m_pProtLine->m_ProtLineArray[nProt].fKsen3I > m_pProtParam->m_ProtSetting.fProtLineKksen3 &&
				m_pProtLine->m_ProtLineArray[nProt].fKsen1J > m_pProtParam->m_ProtSetting.fProtLineKksen1 &&
				m_pProtLine->m_ProtLineArray[nProt].fKsen2J > m_pProtParam->m_ProtSetting.fProtLineKksen2 &&
				m_pProtLine->m_ProtLineArray[nProt].fKsen3J > m_pProtParam->m_ProtSetting.fProtLineKksen3)
				continue;
		}

		nBusI=g_pPGBlock->m_ACLineSegmentArray[nProt].nTopoBusI;
		nBusJ=g_pPGBlock->m_ACLineSegmentArray[nProt].nTopoBusJ;

		nCol=1;
		b2Row = (m_pProtLine->m_ProtLineArray[nProt].bPowered == 0) ? 1 : 0;

		sprintf(szBuf, "%d", nProt+1);	m_wndProtLineIk.InsertItem(nRow, szBuf);	m_wndProtLineIk.SetItemData(nRow, nRow);
		sprintf(szBuf, "%s %s", m_pProtLine->m_ProtLineArray[nProt].szVolt, m_pProtLine->m_ProtLineArray[nProt].szName);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
		if (b2Row)
		{
			m_wndProtLineIk.InsertItem(nRow+1, "");	m_wndProtLineIk.SetItemData(nRow+1, nRow+1);
		}

		if (m_pProtLine->m_ProtLineArray[nProt].bPowered == 0 || m_pProtLine->m_ProtLineArray[nProt].bPowered == 1)
		{
			nCol=2;
			//sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nProt].nTopoBusI, m_pProtLine->m_ProtLineArray[nProt].szSubI);
			strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubI);				m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubJ);				m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fRate);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			if (m_pProtLine->m_ProtLineArray[nProt].bIkIntoTranI)
				sprintf(szBuf, "%.1f", -m_pProtLine->m_ProtLineArray[nProt].fIkmaxI);
			else
				sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkmaxI);
																					m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkminINear);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkminIFar);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fN1IkminI);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
//																					m_wndProtLineIk.SetItemText(nRow, nCol++, m_pProtLine->m_ProtLineArray[nProt].szN1IkminIBus);

			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkdz1I);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkdz2I);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkdz3I);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fKsen1I);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fKsen2I);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fKsen3I);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}

		if (m_pProtLine->m_ProtLineArray[nProt].bPowered == 0 || m_pProtLine->m_ProtLineArray[nProt].bPowered == 2)
		{
			nCol=2;
			//sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nProt].nTopoBusJ, m_pProtLine->m_ProtLineArray[nProt].szSubJ);
			strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubJ);				m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubI);				m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fRate);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
																					m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			if (m_pProtLine->m_ProtLineArray[nProt].bIkIntoTranJ)
				sprintf(szBuf, "%.1f", -m_pProtLine->m_ProtLineArray[nProt].fIkmaxJ);
			else
				sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkmaxJ);
																					m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkminJNear);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIkminJFar);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fN1IkminJ);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
//																					m_wndProtLineIk.SetItemText(nRow, nCol++, m_pProtLine->m_ProtLineArray[nProt].szN1IkminJBus);

			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIdz1J);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIdz2J);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fIdz3J);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);

			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fKsen1J);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fKsen2J);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fKsen3J);		m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtLineIkColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtLineIk.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtLineIk.GetColumnWidth(nCol);
		m_wndProtLineIk.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtLineIk.GetItemCount() <= 0)
		nHeaderWidth = m_wndProtLineIk.GetColumnWidth(nCol);

		m_wndProtLineIk.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtLineDialog::RefreshProtLineI0List(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	int		nBusI, nBusJ;
	char	szBuf[260];

	m_wndProtLineI0.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtLine->m_ProtLineArray.size(); nProt++)
	{
		if (m_pProtLine->m_ProtLineArray[nProt].fNorminalVolt < 100)
			continue;

		if (bFilter)
		{
			if (m_pProtLine->m_ProtLineArray[nProt].fK0sen1I > m_pProtParam->m_ProtSetting.fProtLineK0sen1 &&
				m_pProtLine->m_ProtLineArray[nProt].fK0sen2I > m_pProtParam->m_ProtSetting.fProtLineK0sen2 &&
				m_pProtLine->m_ProtLineArray[nProt].fK0sen3I > m_pProtParam->m_ProtSetting.fProtLineK0sen3 &&
				m_pProtLine->m_ProtLineArray[nProt].fK0sen1J > m_pProtParam->m_ProtSetting.fProtLineK0sen1 &&
				m_pProtLine->m_ProtLineArray[nProt].fK0sen2J > m_pProtParam->m_ProtSetting.fProtLineK0sen2 &&
				m_pProtLine->m_ProtLineArray[nProt].fK0sen3J > m_pProtParam->m_ProtSetting.fProtLineK0sen3)
				continue;
		}

		nBusI=g_pPGBlock->m_ACLineSegmentArray[nProt].nTopoBusI;
		nBusJ=g_pPGBlock->m_ACLineSegmentArray[nProt].nTopoBusJ;

		sprintf(szBuf, "%d", nRow+1);	m_wndProtLineI0.InsertItem(nRow, szBuf);	m_wndProtLineI0.SetItemData(nRow, nRow);
		nCol=1;
		sprintf(szBuf, "%s %s", m_pProtLine->m_ProtLineArray[nProt].szVolt, m_pProtLine->m_ProtLineArray[nProt].szName);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		//sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nProt].nTopoBusI, m_pProtLine->m_ProtLineArray[nProt].szSubI);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
		strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubI);				m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubJ);				m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fRate);		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0maxI);		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0minINear);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0minIFar);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fN1I0minI);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
//																				m_wndProtLineI0.SetItemText(nRow, nCol++, m_pProtLine->m_ProtLineArray[nProt].szN1I0minIBus);

		if (m_pProtLine->m_ProtLineArray[nProt].bI0dzIntoTranI)
			sprintf(szBuf, "-%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0dz1I);
		else
			sprintf(szBuf, "%.1f",  m_pProtLine->m_ProtLineArray[nProt].fI0dz1I);
																				m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0dz2I);		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0dz3I);		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fK0sen1I);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fK0sen2I);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fK0sen3I);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		nRow++;

		m_wndProtLineI0.InsertItem(nRow, "");	m_wndProtLineI0.SetItemData(nRow, nRow);
		nCol=2;
		//sprintf(szBuf, "%d[%s]", m_pProtLine->m_ProtLineArray[nProt].nTopoBusJ, m_pProtLine->m_ProtLineArray[nProt].szSubJ);	m_wndProtLineIk.SetItemText(nRow, nCol++, szBuf);
		strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubJ);				m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		strcpy(szBuf, m_pProtLine->m_ProtLineArray[nProt].szSubI);				m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fRate);		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0maxJ);		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0minJNear);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0minJFar);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fN1I0minJ);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
//																				m_wndProtLineI0.SetItemText(nRow, nCol++, m_pProtLine->m_ProtLineArray[nProt].szN1I0minJBus);

		if (m_pProtLine->m_ProtLineArray[nProt].bI0dzIntoTranJ)
			sprintf(szBuf, "-%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0dz1J);
		else
			sprintf(szBuf, "%.1f",  m_pProtLine->m_ProtLineArray[nProt].fI0dz1J);
		m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0dz2J);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fI0dz3J);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fK0sen1J);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fK0sen2J);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtLine->m_ProtLineArray[nProt].fK0sen3J);	m_wndProtLineI0.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtLineI0Column)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtLineI0.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtLineI0.GetColumnWidth(nCol);
		m_wndProtLineI0.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtLineI0.GetItemCount() <= 0)
		nHeaderWidth = m_wndProtLineI0.GetColumnWidth(nCol);

		m_wndProtLineI0.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtLineDialog::ExcelOut(ExcelAccessor* pExcel)
{
	int		nRow, nCol, nFieldNum;

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndBaseLine.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("��·������Ϣ"));
		pExcel->SetCurSheet(_T("��·������Ϣ"));
		nFieldNum=sizeof(lpszBaseLineColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszBaseLineColumn[nCol]));
		for (nRow=0; nRow<m_wndBaseLine.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndBaseLine.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtLineIk.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("��·�����ϱ���"));
		pExcel->SetCurSheet(_T("��·�����ϱ���"));
		nFieldNum=sizeof(lpszProtLineIkColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtLineIkColumn[nCol]));
		for (nRow=0; nRow<m_wndProtLineIk.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtLineIk.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtLineI0.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("��·�ӵع��ϱ���"));
		pExcel->SetCurSheet(_T("��·�ӵع��ϱ���"));
		nFieldNum=sizeof(lpszProtLineI0Column)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtLineI0Column[nCol]));
		for (nRow=0; nRow<m_wndProtLineI0.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtLineI0.GetItemText(nRow, nCol));
		}
	}
}

void CProtLineDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}
