#pragma once

#include "../../Common/Excel/ExcelAccessor.h"

// CProtDevTunningDialog �Ի���

class CProtDeviceDialog : public CDialog
{
	DECLARE_DYNAMIC(CProtDeviceDialog)

public:
	CProtDeviceDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProtDeviceDialog();

	void InitProt(CProtBus* pProtBus, CProtGen* pProtGen, CProtCap* pProtCap, CProtReac* pProtReac, CProtMotor* pProtMotor, CProtBreaker* pProtBreaker)
	{
		m_pProtBus = pProtBus;
		m_pProtGen = pProtGen;
		m_pProtCap = pProtCap;
		m_pProtReac = pProtReac;
		m_pProtMotor = pProtMotor;
		m_pProtBreaker = pProtBreaker;
	};
	void	Refresh(const unsigned char bFilter)
	{
		RefreshProtBusList(bFilter);
		RefreshProtGenList(bFilter);
		RefreshProtCapList(bFilter);
		RefreshProtReacList(bFilter);
		RefreshProtMotorList(bFilter);
		RefreshProtBreakerList(bFilter);
	};

	void	ExcelOut(ExcelAccessor* pExcel);

// �Ի�������
	enum { IDD = IDD_PROTDEVICE_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl				m_wndTab;
	CMFCListCtrl			m_wndProtBus, m_wndProtGen, m_wndProtCap, m_wndProtReac, m_wndProtMotor, m_wndProtBreaker;

private:
	void RefreshProtBusList(const unsigned char bFilter);
	void RefreshProtGenList(const unsigned char bFilter);
	void RefreshProtCapList(const unsigned char bFilter);
	void RefreshProtReacList(const unsigned char bFilter);
	void RefreshProtMotorList(const unsigned char bFilter);
	void RefreshProtBreakerList(const unsigned char bFilter);
private:
	CProtBus*		m_pProtBus;
	CProtGen*		m_pProtGen;
	CProtCap*		m_pProtCap;
	CProtReac*		m_pProtReac;
	CProtMotor*		m_pProtMotor;
	CProtBreaker*	m_pProtBreaker;
};
