#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtGraph.h"

extern	int		StartProcess(char* lpszCmd, const char* lpszPath, WORD swType);
extern	int		ReadBusSccScanResult(std::vector<tagBusSccScan>& sPTScanBusArray);

CProtGraph::CProtGraph(void)
{
}

CProtGraph::~CProtGraph(void)
{
}

void CProtGraph::InitGraphEdge(tagGraphEdge& sBuffer)
{
	register int	i;

	sBuffer.nFaultTopoBus = -1;
	sBuffer.nBranType = 0;
	sBuffer.strBranName.clear();
	sBuffer.nBranPtr = -1;
	sBuffer.strSubI.clear();
	sBuffer.strSubJ.clear();
	sBuffer.nBranSide = 0;
	sBuffer.nFrTopoBus = -1;
	sBuffer.nToTopoBus = -1;
	sBuffer.fRate = 0;
	for (i=0; i<ConstMaxSccFault; i++)
	{
		sBuffer.fIa[i]=0;	//	�����·����
		sBuffer.fIb[i]=0;	//	�����·����
		sBuffer.fIc[i]=0;	//	�����·����
		sBuffer.fI1[i]=0;	//	A���·����
		sBuffer.fI2[i]=0;	//	B���·����
		sBuffer.fI0[i]=0;	//	C���·����
	}
};

void CProtGraph::InitGraphPoint(tagGraphPoint& sBuffer)
{
	register int	i;

	sBuffer.bValid = 0;
	sBuffer.nTopoBus = -1;
	for (i=0; i<ConstMaxSccFault; i++)
	{
		sBuffer.fI1[i]=0;	//	ĸ�������·����
		sBuffer.fI2[i]=0;	//	ĸ�߸����·����
		sBuffer.fI0[i]=0;	//	ĸ�������·����
		sBuffer.fIa[i]=0;	//	ĸ��A���·����
		sBuffer.fIb[i]=0;	//	ĸ��B���·����
		sBuffer.fIc[i]=0;	//	ĸ��C���·����
	}
	sBuffer.nOLBusArray.clear();
	sBuffer.nOTBusArray.clear();
	sBuffer.sN1BranArray.clear();
	sBuffer.sN2BranArray.clear();
};

int CProtGraph::FormSettingGraph(tagPGBlock* pPGBlock)
{
 	ReadBusSccScanResult(m_SccBusScanArray);
	InitGraph(pPGBlock, m_SettingGPArray);
	AssignGraph(m_SccBusScanArray, m_SettingGPArray);

	return 1;
}

int CProtGraph::FormCheckingGraph(tagPGBlock* pPGBlock)
{
	ReadBusSccScanResult(m_SccBusScanArray);
	InitGraph(pPGBlock, m_CheckingGPArray);
	AssignGraph(m_SccBusScanArray, m_CheckingGPArray);

	return 1;
}

//////////////////////////////////////////////////////////////////////////
//	ͼ�Ǵӹ��ϵ���չ��˼·������֯
//		һ������������ϵ�������֧·���������ڱ�ѹ����Ϊ�������;
//		������������Բ�ĸ��������֧·�����ڱ�ѹ����Բ�ĸ�߲������
//	������·���������ǲ�����������ϵ��֧·����ѹ�������֣����ǶԲ�ĸ�������ֵ�
void CProtGraph::InitGraph(tagPGBlock* pPGBlock, std::vector<tagGraphPoint>& sGPArray)
{
	int				nDev, nOpp, nTopoBus, nOTopoBus;
	char			szBuf[260];
	tagGraphPoint	busBuffer;
	tagGraphEdge	branBuffer;

	sGPArray.clear();
	InitGraphEdge(branBuffer);

	PGMemDBTopo(pPGBlock);
	PGMemDBIsland(pPGBlock);

	sGPArray.resize(pPGBlock->m_nRecordNum[PG_TOPOBUS]);
	for (nTopoBus=0; nTopoBus<(int)sGPArray.size(); nTopoBus++)
		InitGraphPoint(sGPArray[nTopoBus]);

	for (nTopoBus=3; nTopoBus<pPGBlock->m_nRecordNum[PG_TOPOBUS]; nTopoBus++)
	{
		if (pPGBlock->m_IslandArray[pPGBlock->m_TopoBusArray[nTopoBus].nIsland].bDead)
			continue;

		sGPArray[nTopoBus].bValid = 1;
		sGPArray[nTopoBus].nTopoBus = nTopoBus;

		branBuffer.nFaultTopoBus = nTopoBus;

		//////////////////////////////////////////////////////////////////////////
		//	һ��������Ϣ����������ĸ�ߺ�֧·
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
		{
			if (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nTopoBus || pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ == nTopoBus)
			{
				branBuffer.nBranType = PG_ACLINESEGMENT;
				branBuffer.nBranPtr = nDev;
				branBuffer.strSubI = pPGBlock->m_ACLineSegmentArray[nDev].szSubI;
				branBuffer.strSubJ = pPGBlock->m_ACLineSegmentArray[nDev].szSubJ;
				branBuffer.strBranName = pPGBlock->m_ACLineSegmentArray[nDev].szName;
				branBuffer.nBranSide = (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nTopoBus) ? ConstLineSideI : ConstLineSideJ;
				branBuffer.nFrTopoBus = nTopoBus;
				branBuffer.nToTopoBus = (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nTopoBus) ? pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ : pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI;
				branBuffer.fRate = pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur;

				AppendUniqueInteger(branBuffer.nToTopoBus, sGPArray[nTopoBus].nOLBusArray);
				sGPArray[nTopoBus].sN1BranArray.push_back(branBuffer);
			}
		}
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nDev++)
		{
			if (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nTopoBus || pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ == nTopoBus)
			{
				sprintf(szBuf, "%s.%s.%s", pPGBlock->m_SeriesCompensatorArray[nDev].szSub, pPGBlock->m_SeriesCompensatorArray[nDev].szVolt, pPGBlock->m_SeriesCompensatorArray[nDev].szName);
				branBuffer.nBranType = PG_SERIESCOMPENSATOR;
				branBuffer.nBranPtr = nDev;
				branBuffer.strSubI = pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
				branBuffer.strSubJ = pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
				branBuffer.nBranSide = (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nTopoBus) ? ConstLineSideI : ConstLineSideJ;
				branBuffer.strBranName = szBuf;
				branBuffer.nFrTopoBus = nTopoBus;
				branBuffer.nToTopoBus = (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nTopoBus) ? pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ : pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI;
				branBuffer.fRate = 0;

				AppendUniqueInteger(branBuffer.nToTopoBus, sGPArray[nTopoBus].nOLBusArray);
				sGPArray[nTopoBus].sN1BranArray.push_back(branBuffer);
			}
		}
		for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nDev++)
		{
			sprintf(szBuf, "%s.%s", pPGBlock->m_PowerTransformerArray[nDev].szSub, pPGBlock->m_PowerTransformerArray[nDev].szName);
			branBuffer.nBranType = PG_POWERTRANSFORMER;
			branBuffer.nBranPtr = nDev;
			branBuffer.strSubI = pPGBlock->m_PowerTransformerArray[nDev].szSub;
			branBuffer.strSubJ = pPGBlock->m_PowerTransformerArray[nDev].szSub;
			branBuffer.strBranName = szBuf;
			branBuffer.nFrTopoBus = nTopoBus;
			branBuffer.nToTopoBus = -1;
			if (pPGBlock->m_PowerTransformerArray[nDev].nWindNum != 3)
				branBuffer.nToTopoBus = (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nTopoBus) ? pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL : pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH;

			if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nTopoBus)
			{
				branBuffer.nBranSide = ConstTranSideH;
				branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindH].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltH].nominalVoltage);
				if (pPGBlock->m_PowerTransformerArray[nDev].nNodeM >= 0)
					AppendUniqueInteger(pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM, sGPArray[nTopoBus].nOTBusArray);
				if (pPGBlock->m_PowerTransformerArray[nDev].nNodeL >= 0)
					AppendUniqueInteger(pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL, sGPArray[nTopoBus].nOTBusArray);
				sGPArray[nTopoBus].sN1BranArray.push_back(branBuffer);
			}
			if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nTopoBus)
			{
				branBuffer.nBranSide = ConstTranSideM;
				branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindM].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltM].nominalVoltage);
				if (pPGBlock->m_PowerTransformerArray[nDev].nNodeH >= 0)
					AppendUniqueInteger(pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH, sGPArray[nTopoBus].nOTBusArray);
				if (pPGBlock->m_PowerTransformerArray[nDev].nNodeL >= 0)
					AppendUniqueInteger(pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL, sGPArray[nTopoBus].nOTBusArray);
				sGPArray[nTopoBus].sN1BranArray.push_back(branBuffer);
			}
			if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nTopoBus)
			{
				branBuffer.nBranSide = ConstTranSideL;
				branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindL].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltL].nominalVoltage);
				if (pPGBlock->m_PowerTransformerArray[nDev].nNodeH >= 0)
					AppendUniqueInteger(pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH, sGPArray[nTopoBus].nOTBusArray);
				if (pPGBlock->m_PowerTransformerArray[nDev].nNodeM >= 0)
					AppendUniqueInteger(pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM, sGPArray[nTopoBus].nOTBusArray);
				sGPArray[nTopoBus].sN1BranArray.push_back(branBuffer);
			}
		}

		//////////////////////////////////////////////////////////////////////////
		//	��·�Բ�ĸ��������������
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOLBusArray.size(); nOpp++)
		{
			nOTopoBus = sGPArray[nTopoBus].nOLBusArray[nOpp];
			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
			{
				if (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI != nOTopoBus && pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ != nOTopoBus)
					continue;
				if (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nTopoBus || pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ == nTopoBus)
					continue;

				branBuffer.nBranType = PG_ACLINESEGMENT;
				branBuffer.nBranPtr = nDev;
				branBuffer.strSubI = pPGBlock->m_ACLineSegmentArray[nDev].szSubI;
				branBuffer.strSubJ = pPGBlock->m_ACLineSegmentArray[nDev].szSubJ;
				branBuffer.strBranName = pPGBlock->m_ACLineSegmentArray[nDev].szName;
				branBuffer.nBranSide = (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nOTopoBus) ? ConstLineSideI : ConstLineSideJ;
				branBuffer.nFrTopoBus = nOTopoBus;
				branBuffer.nToTopoBus = (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == branBuffer.nFrTopoBus) ? pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ : pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI;
				branBuffer.fRate = pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur;
				sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
			}
			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nDev++)
			{
				if (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI != nOTopoBus && pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ != nOTopoBus)
					continue;
				if (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nTopoBus || pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ == nTopoBus)
					continue;

				sprintf(szBuf, "%s.%s.%s", pPGBlock->m_SeriesCompensatorArray[nDev].szSub, pPGBlock->m_SeriesCompensatorArray[nDev].szVolt, pPGBlock->m_SeriesCompensatorArray[nDev].szName);
				branBuffer.nBranType = PG_SERIESCOMPENSATOR;
				branBuffer.nBranPtr = nDev;
				branBuffer.strSubI = pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
				branBuffer.strSubJ = pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
				branBuffer.strBranName = szBuf;
				branBuffer.nBranSide = (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nOTopoBus) ? ConstLineSideI : ConstLineSideJ;
				branBuffer.nFrTopoBus = nOTopoBus;
				branBuffer.nToTopoBus = (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == branBuffer.nFrTopoBus) ? pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ : pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI;
				branBuffer.fRate = 0;
				sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
			}

			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nDev++)
			{
				sprintf(szBuf, "%s.%s", pPGBlock->m_PowerTransformerArray[nDev].szSub, pPGBlock->m_PowerTransformerArray[nDev].szName);
				branBuffer.nBranType = PG_POWERTRANSFORMER;
				branBuffer.nBranPtr = nDev;
				branBuffer.strSubI = pPGBlock->m_PowerTransformerArray[nDev].szSub;
				branBuffer.strSubJ = pPGBlock->m_PowerTransformerArray[nDev].szSub;
				branBuffer.strBranName = szBuf;
				branBuffer.nFrTopoBus = nOTopoBus;
				branBuffer.nToTopoBus = -1;
				if (pPGBlock->m_PowerTransformerArray[nDev].nWindNum != 3)
					branBuffer.nToTopoBus = (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == branBuffer.nFrTopoBus) ? pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL : pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH;
				else
				{
					if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nTopoBus || pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nTopoBus || pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nTopoBus)
						branBuffer.nToTopoBus = nTopoBus;
				}
				//////////////////////////////////////////////////////////////////////////
				//	�������ڲ�����ѹ�������������ѹ����·�ж�
				//if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nTopoBus ||
				//	pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nTopoBus ||
				//	pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nTopoBus)
				//	continue;

				if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nOTopoBus)
				{
					branBuffer.nBranSide = ConstTranSideH;
					branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindH].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltH].nominalVoltage);
					sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
				}
				if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nOTopoBus)
				{
					branBuffer.nBranSide = ConstTranSideM;
					branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindM].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltM].nominalVoltage);
					sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
				}
				if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nOTopoBus)
				{
					branBuffer.nBranSide = ConstTranSideL;
					branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindL].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltL].nominalVoltage);
					sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
				}
			}
		}


		//////////////////////////////////////////////////////////////////////////
		//	����Բ�ĸ����������������·
		for (nOpp=0; nOpp<(int)sGPArray[nTopoBus].nOTBusArray.size(); nOpp++)
		{
			nOTopoBus = sGPArray[nTopoBus].nOTBusArray[nOpp];
			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_ACLINESEGMENT]; nDev++)
			{
				if (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI != nOTopoBus && pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ != nOTopoBus)
					continue;
				if (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nTopoBus || pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ == nTopoBus)
					continue;

				branBuffer.nBranType = PG_ACLINESEGMENT;
				branBuffer.nBranPtr = nDev;
				branBuffer.strBranName = pPGBlock->m_ACLineSegmentArray[nDev].szName;
				branBuffer.strSubI = pPGBlock->m_ACLineSegmentArray[nDev].szSubI;
				branBuffer.strSubJ = pPGBlock->m_ACLineSegmentArray[nDev].szSubJ;
				branBuffer.nBranSide = (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == nOTopoBus) ? ConstLineSideI : ConstLineSideJ;
				branBuffer.nFrTopoBus = nOTopoBus;
				branBuffer.nToTopoBus = (pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI == branBuffer.nFrTopoBus) ? pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusJ : pPGBlock->m_ACLineSegmentArray[nDev].nTopoBusI;
				branBuffer.fRate = pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur;
				sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
			}
			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_SERIESCOMPENSATOR]; nDev++)
			{
				if (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI != nOTopoBus && pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ != nOTopoBus)
					continue;
				if (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nTopoBus || pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ == nTopoBus)
					continue;

				sprintf(szBuf, "%s.%s.%s", pPGBlock->m_SeriesCompensatorArray[nDev].szSub, pPGBlock->m_SeriesCompensatorArray[nDev].szVolt, pPGBlock->m_SeriesCompensatorArray[nDev].szName);
				branBuffer.nBranType = PG_SERIESCOMPENSATOR;
				branBuffer.nBranPtr = nDev;
				branBuffer.strBranName = pPGBlock->m_SeriesCompensatorArray[nDev].szName;
				branBuffer.strSubI = pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
				branBuffer.strSubJ = pPGBlock->m_SeriesCompensatorArray[nDev].szSub;
				branBuffer.nBranSide = (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == nOTopoBus) ? ConstLineSideI : ConstLineSideJ;
				branBuffer.nFrTopoBus = nOTopoBus;
				branBuffer.nToTopoBus = (pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI == branBuffer.nFrTopoBus) ? pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusJ : pPGBlock->m_SeriesCompensatorArray[nDev].nTopoBusI;
				branBuffer.fRate = 0;
				sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
			}

			for (nDev=0; nDev<pPGBlock->m_nRecordNum[PG_POWERTRANSFORMER]; nDev++)
			{
				sprintf(szBuf, "%s.%s", pPGBlock->m_PowerTransformerArray[nDev].szSub, pPGBlock->m_PowerTransformerArray[nDev].szName);
				branBuffer.nBranType = PG_POWERTRANSFORMER;
				branBuffer.nBranPtr = nDev;
				branBuffer.strBranName = szBuf;
				branBuffer.strSubI = pPGBlock->m_PowerTransformerArray[nDev].szSub;
				branBuffer.strSubJ = pPGBlock->m_PowerTransformerArray[nDev].szSub;
				branBuffer.nFrTopoBus = nOTopoBus;
				branBuffer.nToTopoBus = -1;
				if (pPGBlock->m_PowerTransformerArray[nDev].nWindNum != 3)
					branBuffer.nToTopoBus = (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == branBuffer.nFrTopoBus) ? pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL : pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH;
				else
				{
					if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nTopoBus || pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nTopoBus || pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nTopoBus)
						branBuffer.nToTopoBus = nTopoBus;
				}
				//////////////////////////////////////////////////////////////////////////
				//	�������ڲ�����ѹ�������������ѹ����·�ж�
				//if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nTopoBus ||
				//	pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nTopoBus ||
				//	pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nTopoBus)
				//	continue;

				if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusH == nOTopoBus)
				{
					branBuffer.nBranSide = ConstTranSideH;
					branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindH].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltH].nominalVoltage);
					sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
				}
				if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusM == nOTopoBus)
				{
					branBuffer.nBranSide = ConstTranSideM;
					branBuffer.nToTopoBus = -1;
					branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindM].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltM].nominalVoltage);
					sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
				}
				if (pPGBlock->m_PowerTransformerArray[nDev].nTopoBusL == nOTopoBus)
				{
					branBuffer.nBranSide = ConstTranSideL;
					branBuffer.fRate = (float)(1000*pPGBlock->m_TransformerWindingArray[pPGBlock->m_PowerTransformerArray[nDev].nWindL].fRatedMva/1.732/pPGBlock->m_VoltageLevelArray[pPGBlock->m_PowerTransformerArray[nDev].nVoltL].nominalVoltage);
					sGPArray[nTopoBus].sN2BranArray.push_back(branBuffer);
				}
			}
		}
	}
}

void CProtGraph::AssignGraph(std::vector<tagBusSccScan>& sSccBusScanArray, std::vector<tagGraphPoint>& sGPArray)
{
	int				nBus, nDev, nType, nTopoBus, nDevIndex;

	if (sSccBusScanArray.size() != sGPArray.size())
		return;

	for (nBus=0; nBus<(int)sGPArray.size(); nBus++)
	{
		if (!sGPArray[nBus].bValid)
			continue;

		nTopoBus=sGPArray[nBus].nTopoBus;
		for (nType=0; nType<ConstMaxSccFault; nType++)
		{
			sGPArray[nBus].fI1[nType]=sSccBusScanArray[nTopoBus].fSccI1[nType];
			sGPArray[nBus].fI2[nType]=sSccBusScanArray[nTopoBus].fSccI2[nType];
			sGPArray[nBus].fI0[nType]=sSccBusScanArray[nTopoBus].fSccI0[nType];
			sGPArray[nBus].fIa[nType]=sSccBusScanArray[nTopoBus].fSccIa[nType];
			sGPArray[nBus].fIb[nType]=sSccBusScanArray[nTopoBus].fSccIb[nType];
			sGPArray[nBus].fIc[nType]=sSccBusScanArray[nTopoBus].fSccIc[nType];
		}

		for (nDev=0; nDev<(int)sGPArray[nBus].sN1BranArray.size(); nDev++)
		{
			nDevIndex=sGPArray[nBus].sN1BranArray[nDev].nBranPtr;
			for (nType=0; nType<ConstMaxSccFault; nType++)
			{
				switch (sGPArray[nBus].sN1BranArray[nDev].nBranType)
				{
				case	PG_ACLINESEGMENT:
					{
						sGPArray[nBus].sN1BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fI1[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fI2[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fI0[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fIa[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fIb[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fIc[nType];
						break;
				case	PG_POWERTRANSFORMER:
					switch (sGPArray[nBus].sN1BranArray[nDev].nBranSide)
					{
					case	ConstTranSideH:
						sGPArray[nBus].sN1BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIH1[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIH2[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIH0[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIHa[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIHb[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIHc[nType];
						break;
					case	ConstTranSideM:
						sGPArray[nBus].sN1BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIM1[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIM2[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIM0[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIMa[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIMb[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIMc[nType];
						break;
					case	ConstTranSideL:
						sGPArray[nBus].sN1BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL1[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL2[nType];
						sGPArray[nBus].sN1BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL0[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILa[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILb[nType];
						sGPArray[nBus].sN1BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILc[nType];
						break;
					}
					break;
				case	PG_SERIESCOMPENSATOR:
					sGPArray[nBus].sN1BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fI1[nType];
					sGPArray[nBus].sN1BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fI2[nType];
					sGPArray[nBus].sN1BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fI0[nType];
					sGPArray[nBus].sN1BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fIa[nType];
					sGPArray[nBus].sN1BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fIb[nType];
					sGPArray[nBus].sN1BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fIc[nType];
					break;
					}
				}
			}
		}

		for (nDev=0; nDev<(int)sGPArray[nBus].sN2BranArray.size(); nDev++)
		{
			nDevIndex=sGPArray[nBus].sN2BranArray[nDev].nBranPtr;
// 			if (nBus == 26)
// 				Log(g_lpszLogFile, "����ͼ��ֵ: �������� ����[%s] ���� = %d �� = %d\n", PGGetTableDesp(sGPArray[nBus].sN2BranArray[nDev].nBranType), nDevIndex, sGPArray[nBus].sN2BranArray[nDev].nBranSide);

			for (nType=0; nType<ConstMaxSccFault; nType++)
			{
				switch (sGPArray[nBus].sN2BranArray[nDev].nBranType)
				{
				case	PG_ACLINESEGMENT:
					sGPArray[nBus].sN2BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fI1[nType];
					sGPArray[nBus].sN2BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fI2[nType];
					sGPArray[nBus].sN2BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fI0[nType];
					sGPArray[nBus].sN2BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fIa[nType];
					sGPArray[nBus].sN2BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fIb[nType];
					sGPArray[nBus].sN2BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sLineArray[nDevIndex].fIc[nType];
					break;
				case	PG_POWERTRANSFORMER:
					switch (sGPArray[nBus].sN2BranArray[nDev].nBranSide)
					{
					case	ConstTranSideH:
						sGPArray[nBus].sN2BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIH1[nType];
						sGPArray[nBus].sN2BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIH2[nType];
						sGPArray[nBus].sN2BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIH0[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIHa[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIHb[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIHc[nType];
						break;
					case	ConstTranSideM:
						sGPArray[nBus].sN2BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIM1[nType];
						sGPArray[nBus].sN2BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIM2[nType];
						sGPArray[nBus].sN2BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIM0[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIMa[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIMb[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIMc[nType];
						break;
					case	ConstTranSideL:
// 						if (nBus == 26)
// 							Log(g_lpszLogFile, "        ֵ=%.1f %.1f %.1f %.1f %.1f %.1f\n", 
// 									sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL1[nType], 
// 									sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL2[nType], 
// 									sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL0[nType], 
// 									sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILa[nType], 
// 									sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILb[nType], 
// 									sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILc[nType]);
						sGPArray[nBus].sN2BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL1[nType];
						sGPArray[nBus].sN2BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL2[nType];
						sGPArray[nBus].sN2BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fIL0[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILa[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILb[nType];
						sGPArray[nBus].sN2BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sTranArray[nDevIndex].fILc[nType];
						break;
					}
					break;
				case	PG_SERIESCOMPENSATOR:
					sGPArray[nBus].sN2BranArray[nDev].fI1[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fI1[nType];
					sGPArray[nBus].sN2BranArray[nDev].fI2[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fI2[nType];
					sGPArray[nBus].sN2BranArray[nDev].fI0[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fI0[nType];
					sGPArray[nBus].sN2BranArray[nDev].fIa[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fIa[nType];
					sGPArray[nBus].sN2BranArray[nDev].fIb[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fIb[nType];
					sGPArray[nBus].sN2BranArray[nDev].fIc[nType]=sSccBusScanArray[nTopoBus].sSCapArray[nDevIndex].fIc[nType];
					break;
				}
			}
		}
	}
}

void CProtGraph::AppendUniqueInteger(const int nInteger, std::vector<int>& nIntArray)
{
	register int	i;
	unsigned char	bExist;

	bExist=0;
	for (i=0; i<(int)nIntArray.size(); i++)
	{
		if (nIntArray[i] == nInteger)
		{
			bExist=1;
			break;
		}
	}
	if (!bExist)
		nIntArray.push_back(nInteger);
}
