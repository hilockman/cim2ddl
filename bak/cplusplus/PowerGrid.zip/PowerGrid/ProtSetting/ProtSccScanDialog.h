#pragma once


// CSccScanDialog �Ի���

class CProtSccScanDialog : public CDialog
{
	DECLARE_DYNAMIC(CProtSccScanDialog)

public:
	CProtSccScanDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CProtSccScanDialog();

	void	SetProtGraph(CProtGraph* pGraph)
	{
		m_pProtGraph=pGraph;
	};

// �Ի�������
	enum { IDD = IDD_PROTSCCSCAN_DIALOG };

protected:
	afx_msg void OnPaint();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	afx_msg void OnCbnSelchangeTopobusCombo();
	afx_msg void OnCbnSelchangeFaultypeCombo();
	afx_msg void OnBnClickedExcelOut();
	DECLARE_MESSAGE_MAP()

private:
	CMFCTabCtrl		m_wndTab;
	CMFCListCtrl	m_wndLineListCtrl, m_wndTranListCtrl, m_wndSCapListCtrl;

public:
	void	RefreshBusCombo();
	void	RefreshUI();

private:
	void	RefreshBusResult(const int nTopoBus, const int nFaultType);
	void	RefreshLineList(const int nTopoBus, const int nFaultType);
	void	RefreshTranList(const int nTopoBus, const int nFaultType);
	void	RefreshSCapList(const int nTopoBus, const int nFaultType);
	std::string	GetBusName(const int nTopoBus);

private:
	CProtGraph* m_pProtGraph;
public:
};
