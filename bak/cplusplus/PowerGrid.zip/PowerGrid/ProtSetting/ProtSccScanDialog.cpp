// SccScanDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtSccScanDialog.h"
#include "../../Common/Excel/ExcelAccessor.h"

// CSccScanDialog �Ի���

#define		IDC_SCCLINE_LIST	10001
#define		IDC_SCCTRAN_LIST	10002
#define		IDC_SCCSCAP_LIST	10003

static	char*	lpszExcelOutBusColumn[]=
{
	"���", 
	"ĸ��", 
	"�����������", 
	"���ฺ�����", 
	"�����������", 
	"����A�����", 
	"����B�����", 
	"����C�����", 

	"�����������", 
	"���ฺ�����", 
	"�����������", 
	"����A�����", 
	"����B�����", 
	"����C�����", 

	"�����������", 
	"���ฺ�����", 
	"�����������", 
	"����A�����", 
	"����B�����", 
	"����C�����", 
};

static	char*	lpszExcelOutLineColumn[]=
{
	"��·ĸ��", 
	"��·", 
	"�����", 

	"�����������", 
	"���ฺ�����", 
	"�����������", 
	"����A�����", 
	"����B�����", 
	"����C�����", 

	"�����������", 
	"���ฺ�����", 
	"�����������", 
	"����A�����", 
	"����B�����", 
	"����C�����", 

	"�����������", 
	"���ฺ�����", 
	"�����������", 
	"����A�����", 
	"����B�����", 
	"����C�����", 
};

static	char*	lpszExcelOutTranColumn[]=
{
	"��·ĸ��", 
	"��ѹ��", 

	"�ߵ�ѹ",
	"�߶����",
	"������������", 
	"����߸������", 
	"������������", 
	"�����A�����", 
	"�����B�����", 
	"�����C�����",

	"������������", 
	"����߸������", 
	"������������", 
	"�����A�����", 
	"�����B�����", 
	"�����C�����", 

	"������������", 
	"����߸������", 
	"������������", 
	"�����A�����", 
	"�����B�����", 
	"�����C�����", 

	"�е�ѹ",
	"�ж����",
	"�������������", 
	"�����и������", 
	"�������������", 
	"������A�����", 
	"������B�����", 
	"������C�����", 

	"�������������", 
	"�����и������", 
	"�������������", 
	"������A�����", 
	"������B�����", 
	"������C�����", 

	"�������������", 
	"�����и������", 
	"�������������", 
	"������A�����", 
	"������B�����", 
	"������C�����", 

	"�͵�ѹ",
	"�Ͷ����",
	"������������", 
	"����͸������", 
	"������������", 
	"�����A�����", 
	"�����B�����", 
	"�����C�����", 

	"������������", 
	"����͸������", 
	"������������", 
	"�����A�����", 
	"�����B�����", 
	"�����C�����", 

	"������������", 
	"����͸������", 
	"������������", 
	"�����A�����", 
	"�����B�����", 
	"�����C�����", 
};

static	char*	lpszBaseLineColumn[]=
{
	"���", 
	"��·", 
	"�����", 
	"�������", 
	"�������", 
	"�������", 
	"A�����", 
	"B�����", 
	"C�����", 
};

static	char*	lpszBaseTranColumn[]=
{
	"���", 
	"��ѹ��", 
	"��ѹ", 
	"�����", 
	"�������", 
	"�������", 
	"�������", 
	"A�����", 
	"B�����", 
	"C�����", 
};

static	char*	lpszSccSCapColumn[]=
{
	"���", 
	"����", 
	"�����", 
	"�������", 
	"�������", 
	"�������", 
	"A�����", 
	"B�����", 
	"C�����", 
};

IMPLEMENT_DYNAMIC(CProtSccScanDialog, CDialog)

CProtSccScanDialog::CProtSccScanDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CProtSccScanDialog::IDD, pParent)
{
	m_pProtGraph=NULL;
}

CProtSccScanDialog::~CProtSccScanDialog()
{
}

void CProtSccScanDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CProtSccScanDialog, CDialog)
	ON_CBN_SELCHANGE(IDC_TOPOBUS_COMBO, &CProtSccScanDialog::OnCbnSelchangeTopobusCombo)
	ON_CBN_SELCHANGE(IDC_FAULTYPE_COMBO, &CProtSccScanDialog::OnCbnSelchangeFaultypeCombo)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_EXCEL_OUT, &CProtSccScanDialog::OnBnClickedExcelOut)
END_MESSAGE_MAP()


// CSccScanDialog ��Ϣ��������

BOOL CProtSccScanDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectBuf;
	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndLineListCtrl.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_SCCLINE_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndLineListCtrl.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndLineListCtrl.SetExtendedStyle(m_wndLineListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndLineListCtrl.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBaseLineColumn)/sizeof(char*); i++)
		m_wndLineListCtrl.InsertColumn(i, lpszBaseLineColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndTranListCtrl.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_SCCTRAN_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndTranListCtrl.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndTranListCtrl.SetExtendedStyle(m_wndTranListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndTranListCtrl.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszBaseTranColumn)/sizeof(char*); i++)
		m_wndTranListCtrl.InsertColumn(i, lpszBaseTranColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndSCapListCtrl.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_SCCSCAP_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndSCapListCtrl.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndSCapListCtrl.SetExtendedStyle(m_wndSCapListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndSCapListCtrl.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszSccSCapColumn)/sizeof(char*); i++)
		m_wndSCapListCtrl.InsertColumn(i, lpszSccSCapColumn[i],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndLineListCtrl,	_T("��·"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndTranListCtrl,	_T("����"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndSCapListCtrl,	_T("����"),		-1, FALSE);

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_FAULTYPE_COMBO);
	pComboBox->ResetContent();
	pComboBox->AddString("�����·");
	pComboBox->AddString("�����·");
	pComboBox->AddString("�����·");
	pComboBox->AddString("����ӵ�");
	pComboBox->SetCurSel(2);

	RefreshBusCombo();

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CProtSccScanDialog::RefreshBusCombo()
{
	register int	i;
	char	szBuff[260];

	if (!m_pProtGraph)
		return;

	CComboBox*	pComboBox=(CComboBox*)GetDlgItem(IDC_TOPOBUS_COMBO);
	pComboBox->ResetContent();
	for (i=0; i<(int)m_pProtGraph->m_SccBusScanArray.size(); i++)
	{
		if (!m_pProtGraph->m_SccBusScanArray[i].bValid)
			continue;

		sprintf(szBuff, "%d", i);
		pComboBox->AddString(szBuff);
	}
	pComboBox->SetCurSel(0);
	RefreshUI();
}

void CProtSccScanDialog::RefreshUI()
{
	int		nTopoBus, nFaultType;
	char	szBuf[260];
	CComboBox*	pComboBox;

	if (!m_pProtGraph)
		return;

	pComboBox=(CComboBox*)GetDlgItem(IDC_TOPOBUS_COMBO);
	nTopoBus=pComboBox->GetCurSel();
	if (nTopoBus == CB_ERR)
		return;
	pComboBox->GetLBText(nTopoBus, szBuf);
	nTopoBus=atoi(szBuf);
	if (nTopoBus <= 0 || nTopoBus >= (int)m_pProtGraph->m_SccBusScanArray.size())
		return;

	sprintf(szBuf, "%s %s", g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_TopoBusArray[nTopoBus].nVolt].szSub, g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_TopoBusArray[nTopoBus].nVolt].szName);
	GetDlgItem(IDC_TOPOBUS_DESP)->SetWindowText(szBuf);

	pComboBox=(CComboBox*)GetDlgItem(IDC_FAULTYPE_COMBO);
	nFaultType=pComboBox->GetCurSel();
	if (nFaultType == CB_ERR)
		return;

	RefreshBusResult(nTopoBus, nFaultType);
	RefreshLineList(nTopoBus, nFaultType);
	RefreshTranList(nTopoBus, nFaultType);
	RefreshSCapList(nTopoBus, nFaultType);
}

void CProtSccScanDialog::RefreshBusResult(const int nTopoBus, const int nFaultType)
{
	char	szBuf[260];
	if (!m_pProtGraph)
		return;

	sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI1[nFaultType]);	GetDlgItem(IDC_I1)->SetWindowText(szBuf);
	sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI2[nFaultType]);	GetDlgItem(IDC_I2)->SetWindowText(szBuf);
	sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI0[nFaultType]);	GetDlgItem(IDC_I0)->SetWindowText(szBuf);
	sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIa[nFaultType]);	GetDlgItem(IDC_IA)->SetWindowText(szBuf);
	sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIb[nFaultType]);	GetDlgItem(IDC_IB)->SetWindowText(szBuf);
	sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIc[nFaultType]);	GetDlgItem(IDC_IC)->SetWindowText(szBuf);
}

void CProtSccScanDialog::RefreshLineList(const int nTopoBus, const int nFaultType)
{
	int		nDev, nRow, nCol;
	char	szBuf[260];

	m_wndLineListCtrl.DeleteAllItems();
	if (!m_pProtGraph)
		return;

	nRow=0;
	for (nDev=0; nDev<(int)m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nDev+1);
		m_wndLineListCtrl.InsertItem(nRow, szBuf);	m_wndLineListCtrl.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s [%s - %s]", g_pPGBlock->m_ACLineSegmentArray[nDev].szName, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubI, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubJ);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", g_pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur);				m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI1[nFaultType]);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI2[nFaultType]);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI0[nFaultType]);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIa[nFaultType]);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIb[nFaultType]);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIc[nFaultType]);	m_wndLineListCtrl.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBaseLineColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndLineListCtrl.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndLineListCtrl.GetColumnWidth(nCol);
		m_wndLineListCtrl.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndLineListCtrl.GetColumnWidth(nCol);

		m_wndLineListCtrl.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtSccScanDialog::RefreshTranList(const int nTopoBus, const int nFaultType)
{
	int		nDev;
	int		nRow, nCol;
	char	szBuf[260];

	m_wndTranListCtrl.DeleteAllItems();
	if (!m_pProtGraph)
		return;

	nRow=0;
	for (nDev=0; nDev<(int)m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nDev+1);
		m_wndTranListCtrl.InsertItem(nRow, szBuf);	m_wndTranListCtrl.SetItemData(nRow, nRow);
		nCol=1;
		sprintf(szBuf, "%s - %s", g_pPGBlock->m_PowerTransformerArray[nDev].szSub, g_pPGBlock->m_PowerTransformerArray[nDev].szName);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);

		m_wndTranListCtrl.SetItemText(nRow, nCol++, g_pPGBlock->m_PowerTransformerArray[nDev].szVoltH);
		sprintf(szBuf, "%.1f", 1000*g_pPGBlock->m_TransformerWindingArray[g_pPGBlock->m_PowerTransformerArray[nDev].nWindH].fRatedMva/1.732/g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_PowerTransformerArray[nDev].nVoltH].nominalVoltage);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH1[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH2[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH0[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHa[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHb[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHc[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		nRow++;

		if (g_pPGBlock->m_PowerTransformerArray[nDev].nWindM >= 0)
		{
			m_wndTranListCtrl.InsertItem(nRow, "");		m_wndTranListCtrl.SetItemData(nRow, nRow);
			nCol=2;
			m_wndTranListCtrl.SetItemText(nRow, nCol++, g_pPGBlock->m_PowerTransformerArray[nDev].szVoltM);
			sprintf(szBuf, "%.1f", 1000*g_pPGBlock->m_TransformerWindingArray[g_pPGBlock->m_PowerTransformerArray[nDev].nWindM].fRatedMva/1.732/g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_PowerTransformerArray[nDev].nVoltM].nominalVoltage);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM1[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM2[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM0[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMa[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMb[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMc[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
			nRow++;
		}

		m_wndTranListCtrl.InsertItem(nRow, "");		m_wndTranListCtrl.SetItemData(nRow, nRow);
		nCol=2;
		m_wndTranListCtrl.SetItemText(nRow, nCol++, g_pPGBlock->m_PowerTransformerArray[nDev].szVoltL);
		sprintf(szBuf, "%.1f", 1000*g_pPGBlock->m_TransformerWindingArray[g_pPGBlock->m_PowerTransformerArray[nDev].nWindL].fRatedMva/1.732/g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_PowerTransformerArray[nDev].nVoltL].nominalVoltage);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL1[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL2[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL0[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILa[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILb[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILc[nFaultType]);	m_wndTranListCtrl.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszBaseTranColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndTranListCtrl.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndTranListCtrl.GetColumnWidth(nCol);
		m_wndTranListCtrl.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndTranListCtrl.GetColumnWidth(nCol);

		m_wndTranListCtrl.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtSccScanDialog::RefreshSCapList(const int nTopoBus, const int nFaultType)
{
	int		nDev, nRow, nCol;
	char	szBuf[260];

	m_wndSCapListCtrl.DeleteAllItems();
	if (!m_pProtGraph)
		return;

	nRow=0;
	for (nDev=0; nDev<(int)m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray.size(); nDev++)
	{
		sprintf(szBuf, "%d", nDev+1);
		m_wndSCapListCtrl.InsertItem(nRow, szBuf);	m_wndSCapListCtrl.SetItemData(nRow, nRow);

		nCol=1;
		sprintf(szBuf, "%s %s %s", g_pPGBlock->m_SeriesCompensatorArray[nDev].szSub, g_pPGBlock->m_SeriesCompensatorArray[nDev].szVolt, g_pPGBlock->m_SeriesCompensatorArray[nDev].szName);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", g_pPGBlock->m_SeriesCompensatorArray[nDev].fRated);				m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray[nDev].fI1[nFaultType]);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray[nDev].fI2[nFaultType]);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray[nDev].fI0[nFaultType]);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray[nDev].fIa[nFaultType]);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray[nDev].fIb[nFaultType]);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sSCapArray[nDev].fIc[nFaultType]);	m_wndSCapListCtrl.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszSccSCapColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndSCapListCtrl.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndSCapListCtrl.GetColumnWidth(nCol);
		m_wndSCapListCtrl.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		nHeaderWidth = m_wndSCapListCtrl.GetColumnWidth(nCol);

		m_wndSCapListCtrl.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtSccScanDialog::OnCbnSelchangeTopobusCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshUI();
}

void CProtSccScanDialog::OnCbnSelchangeFaultypeCombo()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	RefreshUI();
}

void CProtSccScanDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}

std::string	CProtSccScanDialog::GetBusName(const int nTopoBus)
{
	register int	i;
	char	szBuf[260];

	for (i=g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_TopoBusArray[nTopoBus].nVolt].nBusbarSectionRange; i<g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_TopoBusArray[nTopoBus].nVolt+1].nBusbarSectionRange; i++)
	{
		if (g_pPGBlock->m_BusbarSectionArray[i].nTopoBus == nTopoBus)
		{
			sprintf(szBuf, "%s %s %s", g_pPGBlock->m_BusbarSectionArray[i].szSub, g_pPGBlock->m_BusbarSectionArray[i].szVolt, g_pPGBlock->m_BusbarSectionArray[i].szName);
			return szBuf;
		}
	}
	return "";
}

void CProtSccScanDialog::OnBnClickedExcelOut()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString	fileExt=_T("xls");
	CString	defaultFileName=_T("");
	CString	fileFilter=_T("Excel�ļ�(*.xls)|*.xls;*.XLS|�����ļ�(*.*)|*.*||");
	DWORD	dwFlags = OFN_ENABLESIZING | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;

	CFileDialog	dlg(FALSE, fileExt, 
		defaultFileName, 
		dwFlags, 
		fileFilter, 
		NULL);

	dlg.m_ofn.lpstrTitle=_T("����Excel�ļ�");
	dlg.m_ofn.lpstrInitialDir=_T("");
	dlg.m_ofn.lStructSize=sizeof(dlg.m_ofn);

	if (dlg.DoModal() == IDCANCEL)
		return;

	ExcelAccessor	xls;
	xls.Create(dlg.GetPathName());

	int	nTopoBus, nDev, nFaultType, nRow, nCol, nFieldNum;
	char	szBuf[260];
	std::string	strBus;

	xls.AddSheet(_T("ĸ�߶�·��Ϣ"));
	xls.SetCurSheet(_T("ĸ�߶�·��Ϣ"));
	nFieldNum=sizeof(lpszExcelOutBusColumn)/sizeof(char*);

	for (nCol=0; nCol<nFieldNum; nCol++)
		xls.AddCell(CString(lpszExcelOutBusColumn[nCol]));

	for (nTopoBus=3; nTopoBus<g_pPGBlock->m_nRecordNum[PG_TOPOBUS]; nTopoBus++)
	{
		if (!m_pProtGraph->m_SccBusScanArray[nTopoBus].bValid)
			continue;
		strBus = GetBusName(nTopoBus);
		if (strBus.empty())
			continue;

		xls.NewLine();
		sprintf(szBuf, "%d", nTopoBus+1);
		xls.AddCell(szBuf);

		xls.AddCell(strBus.c_str());

		nFaultType = 2;
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI1[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI2[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI0[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIa[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIb[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIc[nFaultType]);	xls.AddCell(szBuf);

		nFaultType = 1;
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI1[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI2[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI0[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIa[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIb[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIc[nFaultType]);	xls.AddCell(szBuf);

		nFaultType = 0;
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI1[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI2[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccI0[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIa[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIb[nFaultType]);	xls.AddCell(szBuf);
		sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].fSccIc[nFaultType]);	xls.AddCell(szBuf);
	}

	xls.AddSheet(_T("��·��·��Ϣ"));
	xls.SetCurSheet(_T("��·��·��Ϣ"));
	nFieldNum=sizeof(lpszExcelOutLineColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		xls.AddCell(CString(lpszExcelOutLineColumn[nCol]));

	for (nTopoBus=3; nTopoBus<g_pPGBlock->m_nRecordNum[PG_TOPOBUS]; nTopoBus++)
	{
		if (!m_pProtGraph->m_SccBusScanArray[nTopoBus].bValid)
			continue;
		strBus = GetBusName(nTopoBus);
		if (strBus.empty())
			continue;

		for (nDev=0; nDev<(int)m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray.size(); nDev++)
		{
			xls.NewLine();
			xls.AddCell(strBus.c_str());

			sprintf(szBuf, "%s [%s - %s]", g_pPGBlock->m_ACLineSegmentArray[nDev].szName, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubI, g_pPGBlock->m_ACLineSegmentArray[nDev].szSubJ);
			xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", g_pPGBlock->m_ACLineSegmentArray[nDev].fRatedCur);
			xls.AddCell(szBuf);

			nFaultType = 2;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIc[nFaultType]);	xls.AddCell(szBuf);

			nFaultType = 1;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIc[nFaultType]);	xls.AddCell(szBuf);

			nFaultType = 0;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fI0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sLineArray[nDev].fIc[nFaultType]);	xls.AddCell(szBuf);
		}

		xls.NewLine();
	}

	xls.AddSheet(_T("��ѹ����·��Ϣ"));
	xls.SetCurSheet(_T("��ѹ����·��Ϣ"));
	nFieldNum=sizeof(lpszExcelOutTranColumn)/sizeof(char*);
	for (nCol=0; nCol<nFieldNum; nCol++)
		xls.AddCell(CString(lpszExcelOutTranColumn[nCol]));

	for (nTopoBus=3; nTopoBus<g_pPGBlock->m_nRecordNum[PG_TOPOBUS]; nTopoBus++)
	{
		if (!m_pProtGraph->m_SccBusScanArray[nTopoBus].bValid)
			continue;
		strBus = GetBusName(nTopoBus);
		if (strBus.empty())
			continue;

		for (nDev=0; nDev<(int)m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray.size(); nDev++)
		{
			xls.NewLine();
			xls.AddCell(strBus.c_str());

			sprintf(szBuf, "%s - %s", g_pPGBlock->m_PowerTransformerArray[nDev].szSub, g_pPGBlock->m_PowerTransformerArray[nDev].szName);
			xls.AddCell(szBuf);

			xls.AddCell(g_pPGBlock->m_PowerTransformerArray[nDev].szVoltH);
			sprintf(szBuf, "%.1f", 1000*g_pPGBlock->m_TransformerWindingArray[g_pPGBlock->m_PowerTransformerArray[nDev].nWindH].fRatedMva/1.732/g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_PowerTransformerArray[nDev].nVoltH].nominalVoltage);
			xls.AddCell(szBuf);

			nFaultType=2;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHc[nFaultType]);	xls.AddCell(szBuf);

			nFaultType=1;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHc[nFaultType]);	xls.AddCell(szBuf);

			nFaultType=0;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIH0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIHc[nFaultType]);	xls.AddCell(szBuf);

			if (g_pPGBlock->m_PowerTransformerArray[nDev].nWindM >= 0)
			{
				xls.AddCell(g_pPGBlock->m_PowerTransformerArray[nDev].szVoltM);
				sprintf(szBuf, "%.1f", 1000*g_pPGBlock->m_TransformerWindingArray[g_pPGBlock->m_PowerTransformerArray[nDev].nWindM].fRatedMva/1.732/g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_PowerTransformerArray[nDev].nVoltM].nominalVoltage);
				xls.AddCell(szBuf);

				nFaultType=2;
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM1[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM2[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM0[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMa[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMb[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMc[nFaultType]);	xls.AddCell(szBuf);

				nFaultType=1;																							
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM1[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM2[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM0[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMa[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMb[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMc[nFaultType]);	xls.AddCell(szBuf);

				nFaultType=0;																							
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM1[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM2[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIM0[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMa[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMb[nFaultType]);	xls.AddCell(szBuf);
				sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIMc[nFaultType]);	xls.AddCell(szBuf);
			}
			else
			{
				xls.AddCell("");
				xls.AddCell("");

				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");

				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");

				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
				xls.AddCell("");
			}

			xls.AddCell(g_pPGBlock->m_PowerTransformerArray[nDev].szVoltL);
			sprintf(szBuf, "%.1f", 1000*g_pPGBlock->m_TransformerWindingArray[g_pPGBlock->m_PowerTransformerArray[nDev].nWindL].fRatedMva/1.732/g_pPGBlock->m_VoltageLevelArray[g_pPGBlock->m_PowerTransformerArray[nDev].nVoltL].nominalVoltage);
			xls.AddCell(szBuf);

			nFaultType=2;
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILc[nFaultType]);	xls.AddCell(szBuf);

			nFaultType=1;																							
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILc[nFaultType]);	xls.AddCell(szBuf);

			nFaultType=0;																							
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL1[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL2[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fIL0[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILa[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILb[nFaultType]);	xls.AddCell(szBuf);
			sprintf(szBuf, "%.1f", m_pProtGraph->m_SccBusScanArray[nTopoBus].sTranArray[nDev].fILc[nFaultType]);	xls.AddCell(szBuf);
		}

		xls.NewLine();
	}
	xls.Flush();
	xls.SaveAndClose();
	ExcelAccessor::ShowXlsOnly(CString(dlg.GetPathName()));
}
