// ProtDevTunningDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ProtSettingApp.h"
#include "ProtDeviceDialog.h"


// CProtDeviceDialog �Ի���

#define		IDC_PROTBUS_LIST	10021
#define		IDC_PROTGEN_LIST	10031
#define		IDC_PROTCAP_LIST	10041
#define		IDC_PROTMOTOR_LIST	10051

static	char*	lpszProtBusColumn[]=
{
	"���", 
	"ĸ����", 
	"����·����", 
	"���֧·����", 
	"��С��·����", 
	"���������", 
	"�����ϵ��", 
};

static	char*	lpszProtGenColumn[]=
{
	"���", 
	"�豸��", 
	"�����", 
	"����·����", 
	"���󱸶�·����", 
	"Զ�󱸶�·����", 
	"�ݲƽ�����", 
	"�ݲ���������", 
	"����������", 
	"��������ϵ��", 
	"Զ������ϵ��", 
};

static	char*	lpszProtCapColumn[]=
{
	"���", 
	"�豸��", 
	"�����", 
	"����·����", 
	"��С��·����", 
	"��ʱ�����ٶ϶�ֵ", 
	"������ֵ", 
	"��ʱ�����ٶ�����ϵ��", 
	"��������ϵ��", 
};

static	char*	lpszProtReacColumn[]=
{
	"���", 
	"�豸��", 
	"�����", 
	"����·����", 
	"��С��·����", 
	"�������ֵ", 
	"˲ʱ�����ٶ϶�ֵ", 
	"������ֵ", 
	"˲ʱ�����ٶ�����ϵ��", 
	"��������ϵ��", 
};

static	char*	lpszProtMotorColumn[]=
{
	"���", 
	"�豸��", 
	"�����", 
	"����·����", 
	"��С��·����", 
	"������������", 
	"�ݲƽ�����", 
	"�ݲ���������", 
	"��������ϵ��", 
};

static	char*	lpszProtBreakerColumn[]=
{
	"���", 
	"�豸��", 
	"��ѹ�ֶο���", 
	"����·����", 
	"��С��·����", 
	"�������", 
	"�������", 
	"�ϻ�����", 
	"�����������ϵ��", 
};

IMPLEMENT_DYNAMIC(CProtDeviceDialog, CDialog)

CProtDeviceDialog::CProtDeviceDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CProtDeviceDialog::IDD, pParent)
{
	m_pProtBus = NULL;
	m_pProtGen = NULL;
	m_pProtCap = NULL;
	m_pProtReac = NULL;
	m_pProtMotor = NULL;
	m_pProtBreaker = NULL;
}

CProtDeviceDialog::~CProtDeviceDialog()
{
}

void CProtDeviceDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CProtDeviceDialog, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CProtDevTunningDialog ��Ϣ��������

BOOL CProtDeviceDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	register int	i;
	CRect	rectBuf;

	if (!m_pProtBus || !m_pProtGen || !m_pProtCap || !m_pProtReac || !m_pProtMotor || !m_pProtBreaker)
		EndDialog(IDCANCEL);

	GetDlgItem(IDC_TAB)->GetWindowRect(&rectBuf);
	ScreenToClient(&rectBuf);
	m_wndTab.Create (CMFCTabCtrl::STYLE_3D_ONENOTE, rectBuf, this, 1, CMFCTabCtrl::LOCATION_BOTTOM);
	m_wndTab.EnableAutoColor (TRUE);
	m_wndTab.EnableTabSwap (FALSE);

	if (!m_wndProtBus.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTBUS_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtBus.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtBus.SetExtendedStyle(m_wndProtBus.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtBus.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtBusColumn)/sizeof(char*); i++)
		m_wndProtBus.InsertColumn(i, lpszProtBusColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtGen.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTGEN_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtGen.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtGen.SetExtendedStyle(m_wndProtGen.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtGen.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtGenColumn)/sizeof(char*); i++)
		m_wndProtGen.InsertColumn(i, lpszProtGenColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtCap.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTCAP_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtCap.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtCap.SetExtendedStyle(m_wndProtCap.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtCap.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtCapColumn)/sizeof(char*); i++)
		m_wndProtCap.InsertColumn(i, lpszProtCapColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtReac.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTCAP_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtReac.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtReac.SetExtendedStyle(m_wndProtReac.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtReac.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtReacColumn)/sizeof(char*); i++)
		m_wndProtReac.InsertColumn(i, lpszProtReacColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtMotor.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTMOTOR_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtMotor.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtMotor.SetExtendedStyle(m_wndProtMotor.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtMotor.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtMotorColumn)/sizeof(char*); i++)
		m_wndProtMotor.InsertColumn(i, lpszProtMotorColumn[i],	LVCFMT_LEFT,	100);

	if (!m_wndProtBreaker.Create(WS_VISIBLE | WS_CHILD |  LVS_REPORT , rectBuf, &m_wndTab, IDC_PROTMOTOR_LIST))
	{
		TRACE0("δ�ܴ�����������\n");
		return -1;      // δ�ܴ���
	}
	m_wndProtBreaker.ModifyStyle(0, LVS_SINGLESEL|LVS_REPORT|LVS_SHOWSELALWAYS);
	m_wndProtBreaker.SetExtendedStyle(m_wndProtBreaker.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_wndProtBreaker.SetFont(CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT)));
	for (i=0; i<sizeof(lpszProtBreakerColumn)/sizeof(char*); i++)
		m_wndProtBreaker.InsertColumn(i, lpszProtBreakerColumn[i],	LVCFMT_LEFT,	100);

	m_wndTab.AddTab (&m_wndProtBus,			_T("ĸ�߱���"),			-1, FALSE);
	m_wndTab.AddTab (&m_wndProtGen,			_T("���������"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndProtCap,			_T("��������������"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndProtReac,		_T("�����翹������"),	-1, FALSE);
	m_wndTab.AddTab (&m_wndProtMotor,		_T("�綯������"),		-1, FALSE);
	m_wndTab.AddTab (&m_wndProtBreaker,		_T("ĸ��/�ֶο��ر���"), -1, FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CProtDeviceDialog::RefreshProtBusList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtBus.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtBus->m_ProtBusArray.size(); nProt++)
	{
		sprintf(szBuf, "%d", nProt+1);
		m_wndProtBus.InsertItem(nRow, szBuf);	m_wndProtBus.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtBus.SetItemText(nRow, nCol++, m_pProtBus->m_ProtBusArray[nProt].szName);

		sprintf(szBuf, "%f", m_pProtBus->m_ProtBusArray[nProt].fIbrankmax);	m_wndProtBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtBus->m_ProtBusArray[nProt].fIbranemax);	m_wndProtBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtBus->m_ProtBusArray[nProt].fIkmin);	m_wndProtBus.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtBus->m_ProtBusArray[nProt].fIdz);		m_wndProtBus.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtBus->m_ProtBusArray[nProt].fKsen);		m_wndProtBus.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtBusColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtBus.GetColumnWidth(nCol);
		m_wndProtBus.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtBus.GetItemCount() <= 0)
			nHeaderWidth = m_wndProtBus.GetColumnWidth(nCol);

		m_wndProtBus.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtDeviceDialog::RefreshProtGenList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtGen.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtGen->m_ProtGenArray.size(); nProt++)
	{
		sprintf(szBuf, "%d", nProt+1);
		m_wndProtGen.InsertItem(nRow, szBuf);	m_wndProtGen.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtGen.SetItemText(nRow, nCol++, m_pProtGen->m_ProtGenArray[nProt].szName);

		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fRate);		m_wndProtGen.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fIkmax);		m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fIkminNear);	m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fIkminFar);	m_wndProtGen.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fIunbmax);	m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fIddz);		m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fIkdz);		m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fKksenNear);	m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtGen->m_ProtGenArray[nProt].fKksenFar);	m_wndProtGen.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtGenColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtGen.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtGen.GetColumnWidth(nCol);
		m_wndProtGen.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtGen.GetItemCount() <= 0)
			nHeaderWidth = m_wndProtGen.GetColumnWidth(nCol);

		m_wndProtGen.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtDeviceDialog::RefreshProtCapList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtCap.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtCap->m_ProtCapArray.size(); nProt++)
	{
		sprintf(szBuf, "%d", nProt+1);
		m_wndProtCap.InsertItem(nRow, szBuf);	m_wndProtCap.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtCap.SetItemText(nRow, nCol++, m_pProtCap->m_ProtCapArray[nProt].szName);

		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fRate);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fIkmax);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fIkmin);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fIkdz2);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fIkdz3);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fKsen2);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtCap->m_ProtCapArray[nProt].fKsen3);		m_wndProtCap.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtCapColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtCap.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtCap.GetColumnWidth(nCol);
		m_wndProtCap.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtCap.GetItemCount() <= 0)
			nHeaderWidth = m_wndProtCap.GetColumnWidth(nCol);

		m_wndProtCap.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtDeviceDialog::RefreshProtReacList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtReac.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtReac->m_ProtReacArray.size(); nProt++)
	{
		sprintf(szBuf, "%d", nProt+1);
		m_wndProtReac.InsertItem(nRow, szBuf);	m_wndProtReac.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtReac.SetItemText(nRow, nCol++, m_pProtReac->m_ProtReacArray[nProt].szName);

		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fRate);		m_wndProtReac.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fIkmax);	m_wndProtReac.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fIkmin);	m_wndProtReac.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fIddz);		m_wndProtReac.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fIkdz1);	m_wndProtReac.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fIkdz3);	m_wndProtReac.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fKsen1);	m_wndProtReac.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtReac->m_ProtReacArray[nProt].fKsen3);	m_wndProtReac.SetItemText(nRow, nCol++, szBuf);

		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtReacColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtReac.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtReac.GetColumnWidth(nCol);
		m_wndProtReac.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtReac.GetItemCount() <= 0)
			nHeaderWidth = m_wndProtReac.GetColumnWidth(nCol);

		m_wndProtReac.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtDeviceDialog::RefreshProtMotorList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtMotor.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtMotor->m_ProtMotorArray.size(); nProt++)
	{
		sprintf(szBuf, "%d", nProt+1);
		m_wndProtMotor.InsertItem(nRow, szBuf);	m_wndProtMotor.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtMotor.SetItemText(nRow, nCol++, m_pProtMotor->m_ProtMotorArray[nProt].szName);

		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fRate);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fIkmax);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fIkmin);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fIkdz);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fIunbmax);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fIddz);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtMotor->m_ProtMotorArray[nProt].fKksen);	m_wndProtMotor.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtMotorColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtMotor.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtMotor.GetColumnWidth(nCol);
		m_wndProtMotor.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtMotor.GetItemCount() <= 0)
			nHeaderWidth = m_wndProtMotor.GetColumnWidth(nCol);

		m_wndProtMotor.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtDeviceDialog::RefreshProtBreakerList(const unsigned char bFilter)
{
	int		nProt, nRow, nCol;
	char	szBuf[260];

	m_wndProtBreaker.DeleteAllItems();

	nRow=0;
	for (nProt=0; nProt<m_pProtBreaker->m_ProtBreakerArray.size(); nProt++)
	{
		sprintf(szBuf, "%d", nProt+1);
		m_wndProtBreaker.InsertItem(nRow, szBuf);	m_wndProtBreaker.SetItemData(nRow, nRow);

		nCol=1;
		m_wndProtBreaker.SetItemText(nRow, nCol++, m_pProtBreaker->m_ProtBreakerArray[nProt].szName);

		if (m_pProtBreaker->m_ProtBreakerArray[nProt].bLowVBreaker == 0)
			strcpy(szBuf, "��");
		else
			strcpy(szBuf, "��");
		m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtBreaker->m_ProtBreakerArray[nProt].fIkmax);	m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtBreaker->m_ProtBreakerArray[nProt].fIkmin);	m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtBreaker->m_ProtBreakerArray[nProt].fIkdz1);	m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtBreaker->m_ProtBreakerArray[nProt].fIkdz2);	m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);

		sprintf(szBuf, "%f", m_pProtBreaker->m_ProtBreakerArray[nProt].fIrdz);	m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);
		sprintf(szBuf, "%f", m_pProtBreaker->m_ProtBreakerArray[nProt].fKsen2);	m_wndProtBreaker.SetItemText(nRow, nCol++, szBuf);
		nRow++;
	}

	int	nColWidth, nHeaderWidth;
	for (nCol=0; nCol<sizeof(lpszProtBreakerColumn)/sizeof(char*); nCol++)
	{
		nColWidth=nHeaderWidth=0;
		m_wndProtBreaker.SetColumnWidth(nCol, LVSCW_AUTOSIZE);
		nColWidth = m_wndProtBreaker.GetColumnWidth(nCol);
		m_wndProtBreaker.SetColumnWidth(nCol, LVSCW_AUTOSIZE_USEHEADER);
		//if (m_wndProtBreaker.GetItemCount() <= 0)
			nHeaderWidth = m_wndProtBreaker.GetColumnWidth(nCol);

		m_wndProtBreaker.SetColumnWidth(nCol, max(nColWidth, nHeaderWidth));
	}
}

void CProtDeviceDialog::ExcelOut(ExcelAccessor* pExcel)
{
	int		nRow, nCol, nFieldNum;

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtBus.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("ĸ�߱���"));
		pExcel->SetCurSheet(_T("ĸ�߱���"));
		nFieldNum=sizeof(lpszProtBusColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtBusColumn[nCol]));
		for (nRow=0; nRow<m_wndProtBus.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtBus.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtGen.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("���������"));
		pExcel->SetCurSheet(_T("���������"));
		nFieldNum=sizeof(lpszProtGenColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtGenColumn[nCol]));
		for (nRow=0; nRow<m_wndProtGen.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtGen.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtCap.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("��������������"));
		pExcel->SetCurSheet(_T("��������������"));
		nFieldNum=sizeof(lpszProtCapColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtCapColumn[nCol]));
		for (nRow=0; nRow<m_wndProtCap.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtCap.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtReac.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("�����翹������"));
		pExcel->SetCurSheet(_T("�����翹������"));
		nFieldNum=sizeof(lpszProtReacColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtReacColumn[nCol]));
		for (nRow=0; nRow<m_wndProtReac.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtReac.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtMotor.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("�綯������"));
		pExcel->SetCurSheet(_T("�綯������"));
		nFieldNum=sizeof(lpszProtMotorColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtMotorColumn[nCol]));
		for (nRow=0; nRow<m_wndProtMotor.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtMotor.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	//
	if (m_wndProtBreaker.GetItemCount() > 0)
	{
		pExcel->AddSheet(_T("ĸ���ֶο��ر���"));
		pExcel->SetCurSheet(_T("ĸ���ֶο��ر���"));
		nFieldNum=sizeof(lpszProtBreakerColumn)/sizeof(char*);

		for (nCol=0; nCol<nFieldNum; nCol++)
			pExcel->AddCell(CString(lpszProtBreakerColumn[nCol]));
		for (nRow=0; nRow<m_wndProtBreaker.GetItemCount(); nRow++)
		{
			pExcel->NewLine();
			for (nCol=0; nCol<nFieldNum; nCol++)
				pExcel->AddCell(m_wndProtBreaker.GetItemText(nRow, nCol));
		}
	}

	//////////////////////////////////////////////////////////////////////////
}

void CProtDeviceDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting
	// TODO: �ڴ˴�������Ϣ�����������
	// ��Ϊ��ͼ��Ϣ���� CDialog::OnPaint()
	CWnd* pWnd=m_wndTab.GetActiveWnd();//�õ������ľ��
	pWnd->RedrawWindow();//ʹ�����ػ�
}
