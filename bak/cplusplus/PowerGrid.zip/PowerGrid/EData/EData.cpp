// EData.cpp: implementation of the CEData class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "EData.h"


extern	void	PrintMessage(const char* lpszMesg);
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEData::CEData()
{
    m_EBaseValueArray.clear();
    m_ESubstationArray.clear();
    m_EBusArray.clear();
    m_EAClineArray.clear();
    m_EUnitArray.clear();
    m_ETransformerArray.clear();
    m_ELoadArray.clear();
    m_ECompensator_PArray.clear();
    m_ECompensator_SArray.clear();
    m_EConverterArray.clear();
    m_EDClineArray.clear();
    m_EIslandArray.clear();
    m_ETopoNodeArray.clear();
    m_EBreakerArray.clear();
    m_EDisconnectorArray.clear();
    m_EGroundDisconnectorArray.clear();

    m_EBaseValueOrder=0;
    m_ESubstationOrder=0;
    m_EBusOrder=0;
    m_EAClineOrder=0;
    m_EUnitOrder=0;
    m_ETransformerOrder=0;
    m_ELoadOrder=0;
    m_Compensator_POrder=0;
    m_EBreakerOrder=0;
    m_EDisconnectorOrder=0;
    m_EGroundDisconnectorOrder=0;
}

CEData::~CEData()
{
    m_EBaseValueArray.clear();
    m_ESubstationArray.clear();
    m_EBusArray.clear();
    m_EAClineArray.clear();
    m_EUnitArray.clear();
    m_ETransformerArray.clear();
    m_ELoadArray.clear();
    m_ECompensator_PArray.clear();
    m_ECompensator_SArray.clear();
    m_EConverterArray.clear();
    m_EDClineArray.clear();
    m_EIslandArray.clear();
    m_ETopoNodeArray.clear();
    m_EBreakerArray.clear();
    m_EDisconnectorArray.clear();
    m_EGroundDisconnectorArray.clear();
}

void	CEData::EDataLog(const char* lpszMesg)
{
#ifdef	_DEBUG
    char	szTempPath[260], szFileName[260];
    FILE*	fp;

    GetTempPath(260, szTempPath);

    sprintf(szFileName, "%s/ScadaEFile.log", szTempPath);
    fp=fopen(szFileName, "a");
    if (fp != NULL)
    {
        fprintf(fp, "%s\n", lpszMesg);

        fflush(fp);
        fclose(fp);
    }
#endif
}

void	CEData::EDataCls()
{
#ifdef	_DEBUG
    char	szTempPath[260], szFileName[260];
    GetTempPath(260, szTempPath);
    sprintf(szFileName, "%s/ScadaEFile.log", szTempPath);
    unlink(szFileName);
#endif
}

#ifdef	QT_DLL
void CEData::check(CCimData* pCim)
{
    int	nEData, nCim;
    char	szDev[2*RDFLEN];

    if (!pCim)
    {
        return;
    }

    for (nEData=0; nEData<m_ESubstationArray.size(); nEData++)
    {
        m_ESubstationArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_SubstationArray.size(); nCim++)
        {
            if (strcmp(pCim->m_SubstationArray[nCim].szPackName, m_ESubstationArray[nEData].szName) == 0)
            {
                m_ESubstationArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_EBusArray.size(); nEData++)
    {
        m_EBusArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_BusbarSectionArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_BusbarSectionArray[nCim].szPackSub, pCim->m_BusbarSectionArray[nCim].szPackName);
            if (strcmp(szDev, m_EBusArray[nEData].szName) == 0)
            {
                m_EBusArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_EAClineArray.size(); nEData++)
    {
        m_EAClineArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_ACLineSegmentArray.size(); nCim++)
        {
            strcpy(szDev, pCim->m_ACLineSegmentArray[nCim].szPackName);
            if (strcmp(szDev, m_EAClineArray[nEData].szName) == 0)
            {
                m_EAClineArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_ETransformerArray.size(); nEData++)
    {
        m_ETransformerArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_TransformerWindingArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_PowerTransformerArray[nCim].szPackSub, pCim->m_PowerTransformerArray[nCim].szPackName);
            if (strcmp(szDev, m_ETransformerArray[nEData].szName) == 0)
            {
                m_ETransformerArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_EUnitArray.size(); nEData++)
    {
        m_EUnitArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_SynchronousMachineArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_SynchronousMachineArray[nCim].szPackSub, pCim->m_SynchronousMachineArray[nCim].szPackName);
            if (strcmp(szDev, m_EUnitArray[nEData].szName) == 0)
            {
                m_EUnitArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_ELoadArray.size(); nEData++)
    {
        m_ELoadArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_EnergyConsumerArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_EnergyConsumerArray[nCim].szPackSub, pCim->m_EnergyConsumerArray[nCim].szPackName);
            if (strcmp(szDev, m_ELoadArray[nEData].szName) == 0)
            {
                m_ELoadArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_ECompensator_PArray.size(); nEData++)
    {
        m_ECompensator_PArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_CompensatorArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_CompensatorArray[nCim].szPackSub, pCim->m_CompensatorArray[nCim].szPackName);
            if (strcmp(szDev, m_ECompensator_PArray[nEData].szName) == 0)
            {
                m_ECompensator_PArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_EBreakerArray.size(); nEData++)
    {
        m_EBreakerArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_BreakerArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_BreakerArray[nCim].szPackSub, pCim->m_BreakerArray[nCim].szPackName);
            if (strcmp(szDev, m_EBreakerArray[nEData].szName) == 0)
            {
                m_EBreakerArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_EDisconnectorArray.size(); nEData++)
    {
        m_EDisconnectorArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_DisconnectorArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_DisconnectorArray[nCim].szPackSub, pCim->m_DisconnectorArray[nCim].szPackName);
            if (strcmp(szDev, m_EDisconnectorArray[nEData].szName) == 0)
            {
                m_EDisconnectorArray[nEData].bCheckOK=1;
                break;
            }
        }
    }

    for (nEData=0; nEData<m_EGroundDisconnectorArray.size(); nEData++)
    {
        m_EGroundDisconnectorArray[nEData].bCheckOK=0;
        for (nCim=0; nCim<pCim->m_GroundDisconnectorArray.size(); nCim++)
        {
            sprintf(szDev, "%s.%s", pCim->m_GroundDisconnectorArray[nCim].szPackSub, pCim->m_GroundDisconnectorArray[nCim].szPackName);
            if (strcmp(szDev, m_EGroundDisconnectorArray[nEData].szName) == 0)
            {
                m_EGroundDisconnectorArray[nEData].bCheckOK=1;
                break;
            }
        }
    }
}
#endif
