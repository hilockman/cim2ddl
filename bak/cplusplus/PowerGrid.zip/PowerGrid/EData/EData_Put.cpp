#include "stdafx.h"
#include "EData.h"

double CEData::checkPValue(const float fVolt, const float fP)
{
    if (fVolt < 30)
    {
        if (fabs(fP) > 50*1.25)
        {
            return 0;
        }
    }
    else if (fVolt < 80)
    {
        if (fabs(fP) > 80*1.25)
        {
            return 0;
        }
    }
    else if (fVolt < 100)
    {
        if (fabs(fP) > 114*1.25)
        {
            return 0;
        }
    }
    else if (fVolt < 200)
    {
        if (fabs(fP) > 305*2)
        {
            return 0;
        }
    }
    else if (fVolt < 400)
    {
        if (fabs(fP) > 686*2)
        {
            return 0;
        }
    }
    else if (fVolt < 600)
    {
        if (fabs(fP) > 1082*2)
        {
            return 0;
        }
    }

    return fP;
}

double CEData::checkQValue(const float fVolt, const float fQ)
{
    if (fVolt < 30)
    {
        if (fabs(fQ) > 50*1.25)
        {
            return 0;
        }
    }
    else if (fVolt < 80)
    {
        if (fabs(fQ) > 80*1.25)
        {
            return 0;
        }
    }
    else if (fVolt < 100)
    {
        if (fabs(fQ) > 114*1.25)
        {
            return 0;
        }
    }
    else if (fVolt < 200)
    {
        if (fabs(fQ) > 305*2)
        {
            return 0;
        }
    }
    else if (fVolt < 400)
    {
        if (fabs(fQ) > 686*2)
        {
            return 0;
        }
    }
    else if (fVolt < 600)
    {
        if (fabs(fQ) > 1082*2)
        {
            return 0;
        }
    }

    return fQ;
}

double CEData::checkVValue(const float fVolt, const float fV)
{
    return fV;
}
