#include "stdafx.h"
#include "EData.h"

int CEData::read(const char* lpszFileName, const int bPackedName)
{
    register int	i;
    int		nChar;
    FILE*	fp;
    char	szLine[1024], szParser[1024];
    char	szClass[260], szEntity[260];
    char	szMesg[1024];
    int		nLen, bread;
    int		nContentType;
    int		nColNum, nColIndex[100];
    FILE*	fpDebug;
    char	szFileName[260], szTempPath[260];

#if (defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_WIN64) || defined(__WIN64__) || defined(WIN64))
    GetTempPath(260, szTempPath);
    sprintf(szFileName, "%s/readEFile.dbg", szTempPath);
#else
    strcpy(szTempPath, "/tmp");
    sprintf(szFileName, "%s/readEFile.dbg", szTempPath);
#endif

    fp=fopen(lpszFileName, "r");
    if (fp == NULL)
        return 0;

    fpDebug=fopen(szFileName, "w");

    m_nClassNum=0;
    for (i=0; i<100; i++)
        memset(m_szClassArray[i], 0, 100);

    memset(&m_Entity, 0, sizeof(tagEDataEntity));
    m_EBaseValueArray.clear();
    m_ESubstationArray.clear();
    m_EBusArray.clear();
    m_EAClineArray.clear();
    m_EUnitArray.clear();
    m_ETransformerArray.clear();
    m_ELoadArray.clear();
    m_ECompensator_PArray.clear();
    m_ECompensator_SArray.clear();
    m_EConverterArray.clear();
    m_EDClineArray.clear();
    m_EIslandArray.clear();
    m_ETopoNodeArray.clear();
    m_EBreakerArray.clear();
    m_EDisconnectorArray.clear();
    m_EGroundDisconnectorArray.clear();

    nContentType=-1;
    while (!feof(fp))
    {
        memset(szLine, 0, 1024);
        fgets(szLine, 1024, fp);
        if (strlen(szLine) <= 0)
            continue;

        nLen=bread=0;
        for (i=0; i<(int)strlen(szLine); i++)
        {
            if (szLine[i] == '\'')
            {
                szLine[i]=' ';
                nChar=i+1;
                bread=(int)strlen(szLine);
                while (nChar < (int)strlen(szLine))
                {
                    if (szLine[nChar] == '\'')
                    {
                        szLine[nChar]=' ';
                        break;
                    }
                    if (szLine[nChar] == ' ')
                    {
                        szLine[nChar]='_';
                    }
                    nChar++;
                }
            }
        }
        bread=0;
        for (i=0; i<(int)strlen(szLine); i++)
        {
            if ((szLine[i] == ' ' || szLine[i] == '\t') && !bread)
            {
                continue;
            }
            else
            {
                bread=1;
            }
            szParser[nLen++]=szLine[i];
        }
        szParser[nLen]='\0';

        if (isComment(szParser))
        {
            // PrintMessage(szParser);
            continue;
        }
        if (isEntity(szParser))
        {
            readEntity(szParser);
            continue;
        }
        if (strncmp(szParser, "</", 2) == 0)
        {
            if (nContentType == EData_Substation)
            {
                for (i=0; i<(int)m_ESubstationArray.size(); i++)
                {
                    sprintf(szMesg, "Substation(%d-%d)  (%s) (%d) (%s) (%s) (%d) (%d) (%s) ", 
                            m_ESubstationArray.size(), i, 
                            m_ESubstationArray[i].szName, 
                            m_ESubstationArray[i].nVolt, 
                            m_ESubstationArray[i].szType, 
                            m_ESubstationArray[i].szConfig, 
                            m_ESubstationArray[i].nNodes, 
                            m_ESubstationArray[i].nIslands, 
                            m_ESubstationArray[i].szIsland);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Bus)
            {
                for (i=0; i<(int)m_EBusArray.size(); i++)
                {
                    sprintf(szMesg, "Bus(%d-%d)  (%s) (%d) (%s) (%.2f) (%.2f) (%d) ", 
                            m_EBusArray.size(), i, 
                            m_EBusArray[i].szName, 
                            m_EBusArray[i].nVolt, 
                            m_EBusArray[i].szNode, 
                            m_EBusArray[i].fV, 
                            m_EBusArray[i].fAng, 
                            m_EBusArray[i].nOff);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_ACline)
            {
                for (i=0; i<(int)m_EAClineArray.size(); i++)
                {
                    sprintf(szMesg, "ACline(%d-%d)  (%s) (%d) (%d) (%.2f) (%.2f) (%.2f) (%s) (%s) (%.2f) (%.2f) (%.2f) (%.2f) (%d) (%d) ", 
                            m_EAClineArray.size(), i, 
                            m_EAClineArray[i].szName, 
                            m_EAClineArray[i].nVolt, 
                            m_EAClineArray[i].nEq, 
                            m_EAClineArray[i].fR, 
                            m_EAClineArray[i].fX, 
                            m_EAClineArray[i].fB, 
                            m_EAClineArray[i].szI_node, 
                            m_EAClineArray[i].szJ_node, 
                            m_EAClineArray[i].fI_P, 
                            m_EAClineArray[i].fI_Q, 
                            m_EAClineArray[i].fJ_P, 
                            m_EAClineArray[i].fJ_Q, 
                            m_EAClineArray[i].nI_off, 
                            m_EAClineArray[i].nJ_off);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Transformer)
            {
                for (i=0; i<(int)m_ETransformerArray.size(); i++)
                {
                    sprintf(szMesg, "Transformer(%d-%d) (%s) (%d) (%d) (%d) (%d) (%d) (%d) (%d) (%d) (%d) (%d) (%.5f) (%.5f) (%d) (%d) (%d) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%s) (%s) (%s) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%.5f) (%d) (%d) (%d) (%d) (%d) ", 
                            m_ETransformerArray.size(), i, 
                            m_ETransformerArray[i].szName, 
                            m_ETransformerArray[i].nType, 
                            m_ETransformerArray[i].nI_Vol, 
                            m_ETransformerArray[i].nK_Vol, 
                            m_ETransformerArray[i].nJ_Vol, 
                            m_ETransformerArray[i].nI_S, 
                            m_ETransformerArray[i].nK_S, 
                            m_ETransformerArray[i].nJ_S, 
                            m_ETransformerArray[i].nItap_H, 
                            m_ETransformerArray[i].nItap_L, 
                            m_ETransformerArray[i].nItap_E, 
                            m_ETransformerArray[i].fItap_C, 
                            m_ETransformerArray[i].fItap_V, 
                            m_ETransformerArray[i].nKtap_H, 
                            m_ETransformerArray[i].nKtap_L, 
                            m_ETransformerArray[i].nKtap_E, 
                            m_ETransformerArray[i].fKtap_C, 
                            m_ETransformerArray[i].fKtap_V, 
                            m_ETransformerArray[i].fJtap_V, 
                            m_ETransformerArray[i].fRi, 
                            m_ETransformerArray[i].fXi, 
                            m_ETransformerArray[i].fRk, 
                            m_ETransformerArray[i].fXk, 
                            m_ETransformerArray[i].fRj, 
                            m_ETransformerArray[i].fXj, 
                            m_ETransformerArray[i].szI_node, 
                            m_ETransformerArray[i].szK_node, 
                            m_ETransformerArray[i].szJ_node, 
                            m_ETransformerArray[i].fI_P, 
                            m_ETransformerArray[i].fI_Q, 
                            m_ETransformerArray[i].fK_P, 
                            m_ETransformerArray[i].fK_Q, 
                            m_ETransformerArray[i].fJ_P, 
                            m_ETransformerArray[i].fJ_Q, 
                            m_ETransformerArray[i].nI_tap, 
                            m_ETransformerArray[i].nK_tap, 
                            m_ETransformerArray[i].nI_off, 
                            m_ETransformerArray[i].nK_off, 
                            m_ETransformerArray[i].nJ_off);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Unit)
            {
                for (i=0; i<(int)m_EUnitArray.size(); i++)
                {
                    sprintf(szMesg, "Unit(%d-%d)  (%s) (%d) (%s) (%.2f) (%.2f) (%d) (%s) (%.2f) (%.2f) (%.2f) (%.2f) (%d) ", 
                            m_EUnitArray.size(), i, 
                            m_EUnitArray[i].szName, 
                            m_EUnitArray[i].nEq, 
                            m_EUnitArray[i].szPosition, 
                            m_EUnitArray[i].fV_Rate, 
                            m_EUnitArray[i].fP_Rate, 
                            m_EUnitArray[i].nVolt_n, 
                            m_EUnitArray[i].szNode, 
                            m_EUnitArray[i].fP, 
                            m_EUnitArray[i].fQ, 
                            m_EUnitArray[i].fUe, 
                            m_EUnitArray[i].fAng, 
                            m_EUnitArray[i].nOff);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Load)
            {
                for (i=0; i<(int)m_ELoadArray.size(); i++)
                {
                    sprintf(szMesg, "Load(%d-%d)  (%s) (%d) (%d) (%s) (%s) (%.2f) (%.2f) (%d) ", 
                            m_ELoadArray.size(), i, 
                            m_ELoadArray[i].szName, 
                            m_ELoadArray[i].nVolt, 
                            m_ELoadArray[i].nEq, 
                            m_ELoadArray[i].szPosition, 
                            m_ELoadArray[i].szNode, 
                            m_ELoadArray[i].fP, 
                            m_ELoadArray[i].fQ, 
                            m_ELoadArray[i].nOff);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Breaker)
            {
                for (i=0; i<(int)m_EBreakerArray.size(); i++)
                {
                    sprintf(szMesg, "Breaker(%d-%d)  (%s) (%d) (%s) ", 
                            m_EBreakerArray.size(), i, 
                            m_EBreakerArray[i].szName, 
                            m_EBreakerArray[i].nYx, 
                            m_EBreakerArray[i].szYx_Status);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Breaker+100)
            {
                for (i=0; i<(int)m_EDisconnectorArray.size(); i++)
                {
                    sprintf(szMesg, "Disconnector(%d-%d)  (%s) (%d) (%s) ", 
                            m_EDisconnectorArray.size(), i, 
                            m_EDisconnectorArray[i].szName, 
                            m_EDisconnectorArray[i].nYx, 
                            m_EDisconnectorArray[i].szYx_Status);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            if (nContentType == EData_Breaker+200)
            {
                for (i=0; i<(int)m_EGroundDisconnectorArray.size(); i++)
                {
                    sprintf(szMesg, "GroundDisconnector(%d-%d)  (%s) (%d) (%s) ", 
                            m_EGroundDisconnectorArray.size(), i, 
                            m_EGroundDisconnectorArray[i].szName, 
                            m_EGroundDisconnectorArray[i].nYx, 
                            m_EGroundDisconnectorArray[i].szYx_Status);
                    if (fpDebug != NULL)
                    {
                        fprintf(fpDebug, "%s\n", szMesg);
                    }
                }
            }
            nContentType=-1;
            nColNum=0;
        }
        else if (strncmp(szParser, "<", 1) == 0)
        {
            memset(szClass, 0, 260);
            memset(szEntity, 0, 260);
            if (readClass(szParser, szClass, szEntity))
            {
                if (STRICMP(szClass, "BaseValue") == 0)
                {
                    nColNum=0;
                    nContentType=EData_BaseValue;
                }
                else if (STRICMP(szClass, "Substation") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Substation;
                }
                else if (STRICMP(szClass, "Bus") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Bus;
                }
                else if (STRICMP(szClass, "Breaker") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Breaker;
                }
                else if (STRICMP(szClass, "Discr") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Breaker+100;
                }
                else if (STRICMP(szClass, "GroundDiscr") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Breaker+200;
                }
                else if (STRICMP(szClass, "ACline") == 0)
                {
                    nColNum=0;
                    nContentType=EData_ACline;
                }
                else if (STRICMP(szClass, "Transformer") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Transformer;
                }
                else if (STRICMP(szClass, "Unit") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Unit;
                }
                else if (STRICMP(szClass, "Load") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Load;
                }
                else if (STRICMP(szClass, "Compensator_P") == 0)
                {
                    nColNum=0;
                    nContentType=EData_Compensator_P;
                }
                else if (STRICMP(szClass, "DCline") == 0)
                {
                    nColNum=0;
                    nContentType=EData_DCline;
                }
                else
                {
                    nColNum=0;
                    nContentType=-1;
                }
            }
        }
        switch (nContentType)	//	Ŀǰ����DCLINE��CONVERT��COMPENSATOR_S
        {
        case	EData_BaseValue:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readBaseValueData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Substation:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readSubstationData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Bus:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readBusData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_ACline:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readAClineData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Transformer:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readTransformerData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Unit:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readUnitData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Load:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readLoadData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Compensator_P:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readCompensator_PData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Breaker:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readBreakerData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Breaker+100:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readDiscrData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Breaker+200:
            if (isAttribute(szParser))
            {
                nColNum=0;
                readAttributes(nContentType, szParser, &nColNum, nColIndex);
            }
            if (isData(szParser) && nColNum > 0)
            {
                readGroundDiscrData(bPackedName, szParser, nColNum, nColIndex);
            }
            break;
        case	EData_Island:
            break;
        case	EData_TopoNode:
            break;
        default:
            break;
        }
    }

    fclose(fp);

    if (fpDebug != NULL)
    {
        fflush(fpDebug);
        fclose(fpDebug);
    }
    return 1;
}

void CEData::readAttributes(const int nTable, char* lpszParser, int* pnColNum, int nColIndex[])
{
    register int	i, j;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];

    if (strncmp(lpszParser, "@", 1) != 0)
    {
        return;
    }

    (*pnColNum)=nEle=0;
    lpszToken=strtok(lpszParser, " \t\n@");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n@");
    }

    (*pnColNum)=nEle;
    for (i=0; i<nEle; i++)
    {
        nColIndex[i]=-1;
        switch (nTable)
        {
        case	EData_BaseValue:
            for (j=0; j<sizeof(lpszBaseValueAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszBaseValueAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Substation:
            for (j=0; j<sizeof(lpszSubstationAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszSubstationAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Bus:
            for (j=0; j<sizeof(lpszBusAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszBusAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_ACline:
            for (j=0; j<sizeof(lpszAClineAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszAClineAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Transformer:
            for (j=0; j<sizeof(lpszTransformerAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszTransformerAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Unit:
            for (j=0; j<sizeof(lpszUnitAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszUnitAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Load:
            for (j=0; j<sizeof(lpszLoadAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszLoadAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Compensator_P:
            for (j=0; j<sizeof(lpszCompensator_PAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszCompensator_PAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        case	EData_Breaker:
        case	EData_Breaker+100:
        case	EData_Breaker+200:
            for (j=0; j<sizeof(lpszYXAttributes)/sizeof(char*); j++)
            {
                if (STRICMP(lpszYXAttributes[j], szEle[i]) == 0)
                {
                    nColIndex[i]=j;
                    break;
                }
            }
            break;
        default:
            break;
        }
    }
}

void CEData::readEntity(char* lpszParser)
{

}

void CEData::readBaseValueData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];

    tagEBaseValue	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEBaseValue));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nValue=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szUnit, szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_EBaseValueArray.push_back(vBuf);
}

void CEData::readSubstationData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagESubstation	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagESubstation));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nVolt=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szType, szEle[i]);
            break;
        case	3:
            strcpy(vBuf.szConfig, szEle[i]);
            break;
        case	4:
            vBuf.nNodes=atoi(szEle[i]);
            break;
        case	5:
            vBuf.nIslands=atoi(szEle[i]);
            break;
        case	6:
            strcpy(vBuf.szIsland, szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_ESubstationArray.push_back(vBuf);
}

void CEData::readBusData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagEBus	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEBus));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nVolt=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szNode, szEle[i]);
            break;
        case	3:
            vBuf.fV=(float)atof(szEle[i]);
            break;
        case	4:
            vBuf.fAng=(float)atof(szEle[i]);
            break;
        case	5:
            vBuf.nOff=atoi(szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_EBusArray.push_back(vBuf);
}

void CEData::readAClineData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagEACline	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEACline));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nVolt=atoi(szEle[i]);
            break;
        case	2:
            vBuf.nEq=atoi(szEle[i]);
            break;
        case	3:
            vBuf.fR=(float)atof(szEle[i]);
            break;
        case	4:
            vBuf.fX=(float)atof(szEle[i]);
            break;
        case	5:
            vBuf.fB=(float)atof(szEle[i]);
            break;
        case	6:
            strcpy(vBuf.szI_node, szEle[i]);
            break;
        case	7:
            strcpy(vBuf.szJ_node, szEle[i]);
            break;
        case	8:
            vBuf.fI_P=(float)atof(szEle[i]);
            break;
        case	9:
            vBuf.fI_Q=(float)atof(szEle[i]);
            break;
        case	10:
            vBuf.fI_A=(float)atof(szEle[i]);
            break;
        case	11:
            vBuf.fJ_P=(float)atof(szEle[i]);
            break;
        case	12:
            vBuf.fJ_Q=(float)atof(szEle[i]);
            break;
        case	13:
            vBuf.fJ_A=(float)atof(szEle[i]);
            break;
        case	14:
            vBuf.nI_off=atoi(szEle[i]);
            break;
        case	15:
            vBuf.nJ_off=atoi(szEle[i]);
            break;
        case	16:
            strcpy(vBuf.szSubI, szEle[i]);
            break;
        case	17:
            strcpy(vBuf.szSubJ, szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_EAClineArray.push_back(vBuf);
}

void CEData::readUnitData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagEUnit	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEUnit));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nEq=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szPosition, szEle[i]);
            break;
        case	3:
            vBuf.fV_Rate=(float)atof(szEle[i]);
            break;
        case	4:
            vBuf.fP_Rate=(float)atof(szEle[i]);
            break;
        case	5:
            vBuf.nVolt_n=atoi(szEle[i]);
            break;
        case	6:
            strcpy(vBuf.szNode, szEle[i]);
            break;
        case	7:
            vBuf.fP=(float)atof(szEle[i]);
            break;
        case	8:
            vBuf.fQ=(float)atof(szEle[i]);
            break;
        case	9:
            vBuf.fUe=(float)atof(szEle[i]);
            break;
        case	10:
            vBuf.fAng=(float)atof(szEle[i]);
            break;
        case	11:
            vBuf.nOff=atoi(szEle[i]);
            break;
        default:
            break;
        }
    }

    vBuf.bCheckOK=0;
    m_EUnitArray.push_back(vBuf);
}

void CEData::readTransformerData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagETransformer	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagETransformer));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nType=atoi(szEle[i]);
            break;
        case	2:
            vBuf.nI_Vol=atoi(szEle[i]);
            break;
        case	3:
            vBuf.nK_Vol=atoi(szEle[i]);
            break;
        case	4:
            vBuf.nJ_Vol=atoi(szEle[i]);
            break;
        case	5:
            vBuf.nI_S=atoi(szEle[i]);
            break;
        case	6:
            vBuf.nK_S=atoi(szEle[i]);
            break;
        case	7:
            vBuf.nJ_S=atoi(szEle[i]);
            break;
        case	8:
            vBuf.nItap_H=atoi(szEle[i]);
            break;
        case	9:
            vBuf.nItap_L=atoi(szEle[i]);
            break;
        case	10:
            vBuf.nItap_E=atoi(szEle[i]);
            break;
        case	11:
            vBuf.fItap_C=(float)atof(szEle[i]);
            break;
        case	12:
            vBuf.fItap_V=(float)atof(szEle[i]);
            break;
        case	13:
            vBuf.nKtap_H=atoi(szEle[i]);
            break;
        case	14:
            vBuf.nKtap_L=atoi(szEle[i]);
            break;
        case	15:
            vBuf.nKtap_E=atoi(szEle[i]);
            break;
        case	16:
            vBuf.fKtap_C=(float)atof(szEle[i]);
            break;
        case	17:
            vBuf.fKtap_V=(float)atof(szEle[i]);
            break;
        case	18:
            vBuf.fJtap_V=(float)atof(szEle[i]);
            break;
        case	19:
            vBuf.fRi=(float)atof(szEle[i]);
            break;
        case	20:
            vBuf.fXi=(float)atof(szEle[i]);
            break;
        case	21:
            vBuf.fRk=(float)atof(szEle[i]);
            break;
        case	22:
            vBuf.fXk=(float)atof(szEle[i]);
            break;
        case	23:
            vBuf.fRj=(float)atof(szEle[i]);
            break;
        case	24:
            vBuf.fXj=(float)atof(szEle[i]);
            break;
        case	25:
            strcpy(vBuf.szI_node, szEle[i]);
            break;
        case	26:
            strcpy(vBuf.szK_node, szEle[i]);
            break;
        case	27:
            strcpy(vBuf.szJ_node, szEle[i]);
            break;
        case	28:
            vBuf.fI_P=(float)atof(szEle[i]);
            break;
        case	29:
            vBuf.fI_Q=(float)atof(szEle[i]);
            break;
        case	30:
            vBuf.fI_A=(float)atof(szEle[i]);
            break;
        case	31:
            vBuf.fK_P=(float)atof(szEle[i]);
            break;
        case	32:
            vBuf.fK_Q=(float)atof(szEle[i]);
            break;
        case	33:
            vBuf.fK_A=(float)atof(szEle[i]);
            break;
        case	34:
            vBuf.fJ_P=(float)atof(szEle[i]);
            break;
        case	35:
            vBuf.fJ_Q=(float)atof(szEle[i]);
            break;
        case	36:
            vBuf.fJ_A=(float)atof(szEle[i]);
            break;
        case	37:
            vBuf.nI_tap=atoi(szEle[i]);
            break;
        case	38:
            vBuf.nK_tap=atoi(szEle[i]);
            break;
        case	39:
            vBuf.nI_off=atoi(szEle[i]);
            break;
        case	40:
            vBuf.nK_off=atoi(szEle[i]);
            break;
        case	41:
            vBuf.nJ_off=atoi(szEle[i]);
            break;
        default:
            break;
        }
    }

    vBuf.bCheckOK=0;
    m_ETransformerArray.push_back(vBuf);
}

void CEData::readLoadData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagELoad	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagELoad));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nVolt=atoi(szEle[i]);
            break;
        case	2:
            vBuf.nEq=atoi(szEle[i]);
            break;
        case	3:
            strcpy(vBuf.szPosition, szEle[i]);
            break;
        case	4:
            strcpy(vBuf.szNode, szEle[i]);
            break;
        case	5:
            vBuf.fP=(float)atof(szEle[i]);
            break;
        case	6:
            vBuf.fQ=(float)atof(szEle[i]);
            break;
        case	7:
            vBuf.fA=(float)atof(szEle[i]);
            break;
        case	8:
            vBuf.nOff=atoi(szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_ELoadArray.push_back(vBuf);
}

void CEData::readCompensator_PData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagECompensator_P	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagECompensator_P));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nVolt=atoi(szEle[i]);
            break;
        case	2:
            vBuf.fQr=(float)atof(szEle[i]);
            break;
        case	3:
            vBuf.fVr=(float)atof(szEle[i]);
            break;
        case	4:
            strcpy(vBuf.szPosition, szEle[i]);
            break;
        case	5:
            strcpy(vBuf.szNode, szEle[i]);
            break;
        case	6:
            vBuf.fP=(float)atof(szEle[i]);
            break;
        case	7:
            vBuf.fQ=(float)atof(szEle[i]);
            break;
        case	8:
            vBuf.nOff=atoi(szEle[i]);
            break;
        default:
            break;
        }
    }

    vBuf.bCheckOK=0;
    m_ECompensator_PArray.push_back(vBuf);
}

void CEData::readCompensator_SData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{

}

void CEData::readConverterData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{

}

void CEData::readDClineData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{

}

void CEData::readIslandData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{

}

void CEData::readTopoNodeData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{

}

void CEData::readBreakerData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagEYX	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEYX));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nYx=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szYx_Status, szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_EBreakerArray.push_back(vBuf);
}

void CEData::readDiscrData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagEYX	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEYX));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nYx=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szYx_Status, szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_EDisconnectorArray.push_back(vBuf);
}

void CEData::readGroundDiscrData(const int bPackedName, char* lpszParser, int nColNum, int nColIndex[])
{
    register int	i;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];
    tagEYX	vBuf;

    if (strncmp(lpszParser, "#", 1) != 0)
    {
        return;
    }
    memset(&vBuf, 0, sizeof(tagEYX));

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n#");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n");
    }
    if (nEle != nColNum)
    {
        return;
    }

    for (i=0; i<nColNum; i++)
    {
        switch (nColIndex[i])
        {
        case	0:
            strcpy(vBuf.szName, szEle[i]);
            break;
        case	1:
            vBuf.nYx=atoi(szEle[i]);
            break;
        case	2:
            strcpy(vBuf.szYx_Status, szEle[i]);
            break;
        default:
            break;
        }
    }
    vBuf.bCheckOK=0;
    m_EGroundDisconnectorArray.push_back(vBuf);
}

int CEData::readClass(char* lpszParser, char* lpszRetClass, char* lpszRetEntity)
{
    register int	i;
    int		bExist;
    char*	lpszToken;
    int		nEle;
    char	szEle[50][100];

    nEle=0;
    lpszToken=strtok(lpszParser, " \t\n<>:");
    while (lpszToken != NULL)
    {
        strcpy(szEle[nEle++], lpszToken);
        lpszToken=strtok(NULL, " \t\n<>:");
    }
    if (nEle > 1)
    {
        strcpy(lpszRetClass, szEle[0]);
        strcpy(lpszRetEntity, szEle[1]);
        bExist=0;
        for (i=0; i<m_nClassNum; i++)
        {
            if (strcmp(m_szClassArray[i], lpszRetClass) == 0)
            {
                bExist=1;
                break;
            }
        }
        if (!bExist)
        {
            strcpy(m_szClassArray[m_nClassNum++], lpszRetClass);
        }
    }
    else
    {
        return 0;
    }

    return 1;
}

int CEData::isComment(const char* lpszParser)
{
    if (strncmp(lpszParser, "//", 2) == 0)
    {
        return 1;
    }

    return 0;
}

int CEData::isEntity(const char* lpszParser)
{
    if (strncmp(lpszParser, "<!", 2) == 0)
    {
        return 1;
    }

    return 0;
}

int CEData::isAttribute(const char* lpszParser)
{
    if (strncmp(lpszParser, "@", 1) == 0)
    {
        return 1;
    }

    return 0;
}

int CEData::isData(const char* lpszParser)
{
    if (strncmp(lpszParser, "#", 1) == 0)
    {
        return 1;
    }

    return 0;
}