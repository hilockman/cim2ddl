
// EDataViewerView.cpp : CEDataViewerView ���ʵ��
//

#include "stdafx.h"
#include "EDataViewer.h"

#include "EDataViewerDoc.h"
#include "EDataViewerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEDataViewerView

IMPLEMENT_DYNCREATE(CEDataViewerView, CListView)

BEGIN_MESSAGE_MAP(CEDataViewerView, CListView)
	ON_MESSAGE(UM_CLASS_CHANGED,	OnClassChanged)
END_MESSAGE_MAP()

// CEDataViewerView ����/����

CEDataViewerView::CEDataViewerView()
{
	// TODO: �ڴ˴����ӹ������
	m_nCurClass=-1;
}

CEDataViewerView::~CEDataViewerView()
{
}

BOOL CEDataViewerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ
	cs.style &= ~LVS_TYPEMASK;
	cs.style |= WS_BORDER | LVS_SHOWSELALWAYS | LVS_REPORT;// | LVS_OWNERDATA | LVS_OWNERDRAWFIXED;
	return CListView::PreCreateWindow(cs);
}

void CEDataViewerView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();


	// TODO: ���� GetListCtrl() ֱ�ӷ��� ListView ���б��ؼ���
	//  �Ӷ������������ ListView��
	GetListCtrl().SendMessage (LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
}

void CEDataViewerView::OnRButtonUp(UINT nFlags, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CEDataViewerView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
}


// CEDataViewerView ���

#ifdef _DEBUG
void CEDataViewerView::AssertValid() const
{
	CListView::AssertValid();
}

void CEDataViewerView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CEDataViewerDoc* CEDataViewerView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEDataViewerDoc)));
	return (CEDataViewerDoc*)m_pDocument;
}
#endif //_DEBUG


// CEDataViewerView ��Ϣ��������

void CEDataViewerView::Refresh(const int nClass)
{
	register int	i;
	char		szBuf[260];
	int			nCol, nColWidth, nHeaderWidth;
	int			nRowNum, nColNum;

	if (nClass < 0)
	{
		return;
	}

	nRowNum=nColNum=0;
	while (GetListCtrl().DeleteColumn(0));
	if (!GetListCtrl().DeleteAllItems())
	{
		return;
	}

	GetListCtrl().InsertColumn(0, "���");
	GetListCtrl().SetColumnWidth(0, 50);
	switch (nClass)
	{
	case	EData_BaseValue:	//	BaseValue
		nRowNum=(int)g_EData.m_EBaseValueArray.size();
		nColNum=sizeof(lpszBaseValueAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszBaseValueAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EBaseValueArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_EBaseValueArray[i].nValue);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EBaseValueArray[i].szUnit);
			sprintf(szBuf, "%d", g_EData.m_EBaseValueArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Substation:	//	Substation
		nRowNum=(int)g_EData.m_ESubstationArray.size();
		nColNum=sizeof(lpszSubstationAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszSubstationAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ESubstationArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_ESubstationArray[i].nVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ESubstationArray[i].szType);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ESubstationArray[i].szConfig);
			sprintf(szBuf, "%d", g_EData.m_ESubstationArray[i].nNodes);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ESubstationArray[i].nIslands);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ESubstationArray[i].szIsland);
			sprintf(szBuf, "%d", g_EData.m_ESubstationArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Bus:	//	Bus
		nRowNum=(int)g_EData.m_EBusArray.size();
		nColNum=sizeof(lpszBusAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszBusAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EBusArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_EBusArray[i].nVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EBusArray[i].szNode);
			sprintf(szBuf, "%f", g_EData.m_EBusArray[i].fV);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EBusArray[i].fAng);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_EBusArray[i].nOff);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_EBusArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_ACline:	//	ACline
		nRowNum=(int)g_EData.m_EAClineArray.size();
		nColNum=sizeof(lpszAClineAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszAClineAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EAClineArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_EAClineArray[i].nVolt);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_EAClineArray[i].nEq);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fR);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fX);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fB);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EAClineArray[i].szI_node);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EAClineArray[i].szJ_node);

			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fI_P);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fI_Q);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fI_A);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fJ_P);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fJ_Q);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EAClineArray[i].fJ_A);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_EAClineArray[i].nI_off);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_EAClineArray[i].nJ_off);	GetListCtrl().SetItemText(i, nCol++, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EAClineArray[i].szSubI);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EAClineArray[i].szSubJ);
			sprintf(szBuf, "%d", g_EData.m_EAClineArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Unit:	//	Unit
		nRowNum=(int)g_EData.m_EUnitArray.size();
		nColNum=sizeof(lpszUnitAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszUnitAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EUnitArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_EUnitArray[i].nEq);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EUnitArray[i].szPosition);

			sprintf(szBuf, "%f", g_EData.m_EUnitArray[i].fV_Rate);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EUnitArray[i].fP_Rate);	GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_EUnitArray[i].nVolt_n);	GetListCtrl().SetItemText(i, nCol++, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_EUnitArray[i].szNode);

			sprintf(szBuf, "%f", g_EData.m_EUnitArray[i].fP);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EUnitArray[i].fQ);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EUnitArray[i].fUe);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_EUnitArray[i].fAng);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_EUnitArray[i].nOff);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_EUnitArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Transformer:	//	Transformer
		nRowNum=(int)g_EData.m_ETransformerArray.size();
		nColNum=sizeof(lpszTransformerAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszTransformerAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ETransformerArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nType);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nI_Vol);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nK_Vol);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nJ_Vol);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nI_S);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nK_S);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nJ_S);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nItap_H);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nItap_L);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nItap_E);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fItap_C);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fItap_V);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nKtap_H);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nKtap_L);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nKtap_E);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fKtap_C);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fKtap_V);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fJtap_V);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fRi);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fXi);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fRk);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fXk);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fRj);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fXj);			GetListCtrl().SetItemText(i, nCol++, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ETransformerArray[i].szI_node);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ETransformerArray[i].szK_node);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ETransformerArray[i].szJ_node);

			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fI_P);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fI_Q);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fI_A);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fK_P);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fK_Q);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fK_A);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fJ_P);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fJ_Q);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ETransformerArray[i].fJ_A);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nI_tap);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nK_tap);		GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nI_off);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nK_off);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].nJ_off);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ETransformerArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Load:	//	Load
		nRowNum=(int)g_EData.m_ELoadArray.size();
		nColNum=sizeof(lpszLoadAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszLoadAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ELoadArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_ELoadArray[i].nVolt);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ELoadArray[i].nEq);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ELoadArray[i].szPosition);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ELoadArray[i].szNode);

			sprintf(szBuf, "%f", g_EData.m_ELoadArray[i].fP);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ELoadArray[i].fQ);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ELoadArray[i].fA);			GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ELoadArray[i].nOff);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ELoadArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Compensator_P:	//	Compensator_P
		nRowNum=(int)g_EData.m_ECompensator_PArray.size();
		nColNum=sizeof(lpszCompensator_PAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszCompensator_PAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ECompensator_PArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_ECompensator_PArray[i].nVolt);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ECompensator_PArray[i].fQr);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ECompensator_PArray[i].fVr);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ECompensator_PArray[i].szPosition);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ECompensator_PArray[i].szNode);

			sprintf(szBuf, "%f", g_EData.m_ECompensator_PArray[i].fP);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ECompensator_PArray[i].fQ);			GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ECompensator_PArray[i].nOff);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ECompensator_PArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;

	case	EData_Compensator_S:	//	Compensator_S
		nRowNum=(int)g_EData.m_ECompensator_SArray.size();
		nColNum=sizeof(lpszCompensator_SAttributes)/sizeof(char*);
		for (i=0; i<nColNum; i++)
			GetListCtrl().InsertColumn(i+1, lpszCompensator_SAttributes[i]);
		for (i=0; i<nRowNum; i++)
		{
			nCol=1;
			sprintf(szBuf, "%d", i+1);
			GetListCtrl().InsertItem(i, szBuf);

			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ECompensator_SArray[i].szName);
			sprintf(szBuf, "%d", g_EData.m_ECompensator_SArray[i].nVolt);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ECompensator_SArray[i].fQr);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%f", g_EData.m_ECompensator_SArray[i].fVr);			GetListCtrl().SetItemText(i, nCol++, szBuf);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ECompensator_SArray[i].szI_node);
			GetListCtrl().SetItemText(i, nCol++, g_EData.m_ECompensator_SArray[i].szJ_node);

			sprintf(szBuf, "%f", g_EData.m_ECompensator_SArray[i].fZk);			GetListCtrl().SetItemText(i, nCol++, szBuf);

			sprintf(szBuf, "%d", g_EData.m_ECompensator_SArray[i].nOff);		GetListCtrl().SetItemText(i, nCol++, szBuf);
			sprintf(szBuf, "%d", g_EData.m_ECompensator_SArray[i].bCheckOK);	GetListCtrl().SetItemText(i, nCol++, szBuf);
		}
		break;


	default:
		break;
	}
	for (i=1; i<=nColNum; i++)
	{
		nColWidth=nHeaderWidth=0;

		GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE);
		nColWidth = GetListCtrl().GetColumnWidth(i);
		if (nRowNum <= 0)
		{
			GetListCtrl().SetColumnWidth(i, LVSCW_AUTOSIZE_USEHEADER);
			nHeaderWidth =GetListCtrl().GetColumnWidth(i);
		}

		GetListCtrl().SetColumnWidth(i, max(nColWidth, nHeaderWidth));
	}
}

LRESULT CEDataViewerView::OnClassChanged(WPARAM wParam, LPARAM lParam)
{
	TRACE("ViewOnClassChanged: %d\n", wParam);
	if (m_nCurClass != wParam && wParam >= 0)
	{
		m_nCurClass=(int)wParam;
		Refresh(m_nCurClass);
	}
	return 0;
}
