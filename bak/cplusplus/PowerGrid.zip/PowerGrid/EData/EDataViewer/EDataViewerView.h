
// EDataViewerView.h : CEDataViewerView ��Ľӿ�
//


#pragma once


class CEDataViewerView : public CListView
{
protected: // �������л�����
	CEDataViewerView();
	DECLARE_DYNCREATE(CEDataViewerView)

// ����
public:
	CEDataViewerDoc* GetDocument() const;

// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); // ������һ�ε���

// ʵ��
public:
	virtual ~CEDataViewerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg LRESULT OnClassChanged(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
private:
	void Refresh(const int nClass);
	int m_nCurClass;
protected:
//	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
};

#ifndef _DEBUG  // EDataViewerView.cpp �еĵ��԰汾
inline CEDataViewerDoc* CEDataViewerView::GetDocument() const
{
	return reinterpret_cast<CEDataViewerDoc*>(m_pDocument);
}
#endif

