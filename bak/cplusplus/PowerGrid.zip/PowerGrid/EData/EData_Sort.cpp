#include "stdafx.h"
#include "EData.h"

void	CEData::sort( const char* lpszClass, const int nCol)
{
    register int	i, j;

    if (STRICMP(lpszClass, "BaseValue") == 0)
    {
        for (i=0; i<(int)m_EBaseValueArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EBaseValueArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EBaseValueOrder == 0)
                    {
                        if (strcmp(m_EBaseValueArray[i].szName, m_EBaseValueArray[j].szName) > 0)
                        {
                            std::swap(m_EBaseValueArray[i], m_EBaseValueArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EBaseValueArray[i].szName, m_EBaseValueArray[j].szName) < 0)
                        {
                            std::swap(m_EBaseValueArray[i], m_EBaseValueArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EBaseValueOrder == 0)
                    {
                        if (m_EBaseValueArray[i].bCheckOK > m_EBaseValueArray[j].bCheckOK)
                        {
                            std::swap(m_EBaseValueArray[i], m_EBaseValueArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EBaseValueArray[i].bCheckOK < m_EBaseValueArray[j].bCheckOK)
                        {
                            std::swap(m_EBaseValueArray[i], m_EBaseValueArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EBaseValueOrder = (m_EBaseValueOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Substation") == 0)
    {
        for (i=0; i<(int)m_ESubstationArray.size(); i++)
        {
            for (j=i+1; j<(int)m_ESubstationArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_ESubstationOrder == 0)
                    {
                        if (strcmp(m_ESubstationArray[i].szName, m_ESubstationArray[j].szName) > 0)
                        {
                            std::swap(m_ESubstationArray[i], m_ESubstationArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_ESubstationArray[i].szName, m_ESubstationArray[j].szName) < 0)
                        {
                            std::swap(m_ESubstationArray[i], m_ESubstationArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_ESubstationOrder == 0)
                    {
                        if (m_ESubstationArray[i].bCheckOK > m_ESubstationArray[j].bCheckOK)
                        {
                            std::swap(m_ESubstationArray[i], m_ESubstationArray[j]);
                        }
                    }
                    else
                    {
                        if (m_ESubstationArray[i].bCheckOK < m_ESubstationArray[j].bCheckOK)
                        {
                            std::swap(m_ESubstationArray[i], m_ESubstationArray[j]);
                        }
                    }
                    break;
                default:
                    break;
                }
            }
        }
        m_ESubstationOrder = (m_ESubstationOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Bus") == 0)
    {
        for (i=0; i<(int)m_EBusArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EBusArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EBusOrder == 0)
                    {
                        if (strcmp(m_EBusArray[i].szName, m_EBusArray[j].szName) > 0)
                        {
                            std::swap(m_EBusArray[i], m_EBusArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EBusArray[i].szName, m_EBusArray[j].szName) < 0)
                        {
                            std::swap(m_EBusArray[i], m_EBusArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EBusOrder == 0)
                    {
                        if (m_EBusArray[i].bCheckOK > m_EBusArray[j].bCheckOK)
                        {
                            std::swap(m_EBusArray[i], m_EBusArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EBusArray[i].bCheckOK < m_EBusArray[j].bCheckOK)
                        {
                            std::swap(m_EBusArray[i], m_EBusArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EBusOrder = (m_EBusOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Breaker") == 0)
    {
        for (i=0; i<(int)m_EBreakerArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EBreakerArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EBreakerOrder == 0)
                    {
                        if (strcmp(m_EBreakerArray[i].szName, m_EBreakerArray[j].szName) > 0)
                        {
                            std::swap(m_EBreakerArray[i], m_EBreakerArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EBreakerArray[i].szName, m_EBreakerArray[j].szName) < 0)
                        {
                            std::swap(m_EBreakerArray[i], m_EBreakerArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EBreakerOrder == 0)
                    {
                        if (m_EBreakerArray[i].bCheckOK > m_EBreakerArray[j].bCheckOK)
                        {
                            std::swap(m_EBreakerArray[i], m_EBreakerArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EBreakerArray[i].bCheckOK < m_EBreakerArray[j].bCheckOK)
                        {
                            std::swap(m_EBreakerArray[i], m_EBreakerArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EBreakerOrder = (m_EBreakerOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Discr") == 0)
    {
        for (i=0; i<(int)m_EDisconnectorArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EDisconnectorArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EDisconnectorOrder == 0)
                    {
                        if (strcmp(m_EDisconnectorArray[i].szName, m_EDisconnectorArray[j].szName) > 0)
                        {
                            std::swap(m_EDisconnectorArray[i], m_EDisconnectorArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EDisconnectorArray[i].szName, m_EDisconnectorArray[j].szName) < 0)
                        {
                            std::swap(m_EDisconnectorArray[i], m_EDisconnectorArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EDisconnectorOrder == 0)
                    {
                        if (m_EDisconnectorArray[i].bCheckOK > m_EDisconnectorArray[j].bCheckOK)
                        {
                            std::swap(m_EDisconnectorArray[i], m_EDisconnectorArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EDisconnectorArray[i].bCheckOK < m_EDisconnectorArray[j].bCheckOK)
                        {
                            std::swap(m_EDisconnectorArray[i], m_EDisconnectorArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EDisconnectorOrder = (m_EDisconnectorOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "GroundDiscr") == 0)
    {
        for (i=0; i<(int)m_EGroundDisconnectorArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EGroundDisconnectorArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EGroundDisconnectorOrder == 0)
                    {
                        if (strcmp(m_EGroundDisconnectorArray[i].szName, m_EGroundDisconnectorArray[j].szName) > 0)
                        {
                            std::swap(m_EGroundDisconnectorArray[i], m_EGroundDisconnectorArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EGroundDisconnectorArray[i].szName, m_EGroundDisconnectorArray[j].szName) < 0)
                        {
                            std::swap(m_EGroundDisconnectorArray[i], m_EGroundDisconnectorArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EGroundDisconnectorOrder == 0)
                    {
                        if (m_EGroundDisconnectorArray[i].bCheckOK > m_EGroundDisconnectorArray[j].bCheckOK)
                        {
                            std::swap(m_EGroundDisconnectorArray[i], m_EGroundDisconnectorArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EGroundDisconnectorArray[i].bCheckOK < m_EGroundDisconnectorArray[j].bCheckOK)
                        {
                            std::swap(m_EGroundDisconnectorArray[i], m_EGroundDisconnectorArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EGroundDisconnectorOrder = (m_EGroundDisconnectorOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "ACline") == 0)
    {
        for (i=0; i<(int)m_EAClineArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EAClineArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EAClineOrder == 0)
                    {
                        if (strcmp(m_EAClineArray[i].szName, m_EAClineArray[j].szName) > 0)
                        {
                            std::swap(m_EAClineArray[i], m_EAClineArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EAClineArray[i].szName, m_EAClineArray[j].szName) < 0)
                        {
                            std::swap(m_EAClineArray[i], m_EAClineArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EAClineOrder == 0)
                    {
                        if (m_EAClineArray[i].bCheckOK > m_EAClineArray[j].bCheckOK)
                        {
                            std::swap(m_EAClineArray[i], m_EAClineArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EAClineArray[i].bCheckOK < m_EAClineArray[j].bCheckOK)
                        {
                            std::swap(m_EAClineArray[i], m_EAClineArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EAClineOrder = (m_EAClineOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Transformer") == 0)
    {
        for (i=0; i<(int)m_ETransformerArray.size(); i++)
        {
            for (j=i+1; j<(int)m_ETransformerArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_ETransformerOrder == 0)
                    {
                        if (strcmp(m_ETransformerArray[i].szName, m_ETransformerArray[j].szName) > 0)
                        {
                            std::swap(m_ETransformerArray[i], m_ETransformerArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_ETransformerArray[i].szName, m_ETransformerArray[j].szName) < 0)
                        {
                            std::swap(m_ETransformerArray[i], m_ETransformerArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_ETransformerOrder == 0)
                    {
                        if (m_ETransformerArray[i].bCheckOK > m_ETransformerArray[j].bCheckOK)
                        {
                            std::swap(m_ETransformerArray[i], m_ETransformerArray[j]);
                        }
                    }
                    else
                    {
                        if (m_ETransformerArray[i].bCheckOK < m_ETransformerArray[j].bCheckOK)
                        {
                            std::swap(m_ETransformerArray[i], m_ETransformerArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_ETransformerOrder = (m_ETransformerOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Unit") == 0)
    {
        for (i=0; i<(int)m_EUnitArray.size(); i++)
        {
            for (j=i+1; j<(int)m_EUnitArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_EUnitOrder == 0)
                    {
                        if (strcmp(m_EUnitArray[i].szName, m_EUnitArray[j].szName) > 0)
                        {
                            std::swap(m_EUnitArray[i], m_EUnitArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_EUnitArray[i].szName, m_EUnitArray[j].szName) < 0)
                        {
                            std::swap(m_EUnitArray[i], m_EUnitArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_EUnitOrder == 0)
                    {
                        if (m_EUnitArray[i].bCheckOK > m_EUnitArray[j].bCheckOK)
                        {
                            std::swap(m_EUnitArray[i], m_EUnitArray[j]);
                        }
                    }
                    else
                    {
                        if (m_EUnitArray[i].bCheckOK < m_EUnitArray[j].bCheckOK)
                        {
                            std::swap(m_EUnitArray[i], m_EUnitArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_EUnitOrder = (m_EUnitOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Load") == 0)
    {
        for (i=0; i<(int)m_ELoadArray.size(); i++)
        {
            for (j=i+1; j<(int)m_ELoadArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_ELoadOrder == 0)
                    {
                        if (strcmp(m_ELoadArray[i].szName, m_ELoadArray[j].szName) > 0)
                        {
                            std::swap(m_ELoadArray[i], m_ELoadArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_ELoadArray[i].szName, m_ELoadArray[j].szName) < 0)
                        {
                            std::swap(m_ELoadArray[i], m_ELoadArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_ELoadOrder == 0)
                    {
                        if (m_ELoadArray[i].bCheckOK > m_ELoadArray[j].bCheckOK)
                        {
                            std::swap(m_ELoadArray[i], m_ELoadArray[j]);
                        }
                    }
                    else
                    {
                        if (m_ELoadArray[i].bCheckOK < m_ELoadArray[j].bCheckOK)
                        {
                            std::swap(m_ELoadArray[i], m_ELoadArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_ELoadOrder = (m_ELoadOrder == 0) ? 1 : 0;
    }
    else if (STRICMP(lpszClass, "Compensator_P") == 0)
    {
        for (i=0; i<(int)m_ECompensator_PArray.size(); i++)
        {
            for (j=i+1; j<(int)m_ECompensator_PArray.size(); j++)
            {
                switch (nCol)
                {
                case	0:
                    if (m_Compensator_POrder == 0)
                    {
                        if (strcmp(m_ECompensator_PArray[i].szName, m_ECompensator_PArray[j].szName) > 0)
                        {
                            std::swap(m_ECompensator_PArray[i], m_ECompensator_PArray[j]);
                        }
                    }
                    else
                    {
                        if (strcmp(m_ECompensator_PArray[i].szName, m_ECompensator_PArray[j].szName) < 0)
                        {
                            std::swap(m_ECompensator_PArray[i], m_ECompensator_PArray[j]);
                        }
                    }
                    break;
                case	1:
                    if (m_Compensator_POrder == 0)
                    {
                        if (m_ECompensator_PArray[i].bCheckOK > m_ECompensator_PArray[j].bCheckOK)
                        {
                            std::swap(m_ECompensator_PArray[i], m_ECompensator_PArray[j]);
                        }
                    }
                    else
                    {
                        if (m_ECompensator_PArray[i].bCheckOK < m_ECompensator_PArray[j].bCheckOK)
                        {
                            std::swap(m_ECompensator_PArray[i], m_ECompensator_PArray[j]);
                        }
                    }
                    break;
                }
            }
        }
        m_Compensator_POrder = (m_Compensator_POrder == 0) ? 1 : 0;
    }
}
